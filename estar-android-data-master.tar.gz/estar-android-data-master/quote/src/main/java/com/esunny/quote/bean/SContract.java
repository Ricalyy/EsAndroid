package com.esunny.quote.bean;

import com.esunny.data.bean.SQuoteSnapShot;
import com.esunny.data.bean.SQuoteSnapShotL2;

/**
 * @author Peter Fu
 * @date 2020/10/10
 */
public class SContract {
    private String ContractNo;
    private SQuoteSnapShot SnapShot = new SQuoteSnapShot();                            //可能为空，订阅收到行情才创建
    private SQuoteSnapShotL2 BidL2 = new SQuoteSnapShotL2();                                //买挂单深度
    private SQuoteSnapShotL2 AskL2 = new SQuoteSnapShotL2();                                //卖挂单深度

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public SQuoteSnapShot getSnapShot() {
        return SnapShot;
    }

    public void setSnapShot(SQuoteSnapShot snapShot) {
        SnapShot = snapShot;
    }

    public SQuoteSnapShotL2 getBidL2() {
        return BidL2;
    }

    public void setBidL2(SQuoteSnapShotL2 bidL2) {
        BidL2 = bidL2;
    }

    public SQuoteSnapShotL2 getAskL2() {
        return AskL2;
    }

    public void setAskL2(SQuoteSnapShotL2 askL2) {
        AskL2 = askL2;
    }
}
