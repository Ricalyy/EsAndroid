package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.math.BigInteger;

public class QteLV2Data {

    private BigInteger UpdateTime;     //行情更新时间
    private int DepthLength;    //深度部分长度,不包括本结构
    private short DepthCount;     //QDepDetail的数量

    public BigInteger getUpdateTime() {
        return UpdateTime;
    }

    public void setUpdateTime(BigInteger updateTime) {
        UpdateTime = updateTime;
    }

    public int getDepthLength() {
        return DepthLength;
    }

    public void setDepthLength(int depthLength) {
        DepthLength = depthLength;
    }

    public short getDepthCount() {
        return DepthCount;
    }

    public void setDepthCount(short depthCount) {
        DepthCount = depthCount;
    }

}
