package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;
import com.esunny.quote.EsQuoteProtocol;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Peter Fu
 * @date 2020/10/9
 */
public class QteSnapShotData extends ApiStruct {

    private static final Object object = new Object();
    private static QteSnapShotData sPoolData;

    private BigInteger UpdateTime;     //行情更新时间
    private int FieldCount;     //QSnapShotField的数量
//    QteSnapShotField FieldData[1];   //数据字段的起始位置，无数据时此结构不包含此字段长度
    private List<QteSnapShotField> FieldData = new ArrayList<>();

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public BigInteger getUpdateTime() {
        return UpdateTime;
    }

    public void setUpdateTime(BigInteger updateTime) {
        UpdateTime = updateTime;
    }

    public int getFieldCount() {
        return FieldCount;
    }

    public void setFieldCount(int fieldCount) {
        FieldCount = fieldCount;
    }

    public List<QteSnapShotField> getFieldData() {
        return FieldData;
    }

    public void setFieldData(List<QteSnapShotField> fieldData) {
        FieldData = fieldData;
    }

    public static QteSnapShotData getObject() {
        synchronized (object) {
            if (sPoolData != null) {
                QteSnapShotData data = sPoolData;
                data.FieldCount = 0;
                data.UpdateTime = null;
                data.FieldData = new ArrayList<>();
                return data;
            }
        }
        return new QteSnapShotData();
    }

    public void recycle() {
        FieldCount = 0;
        UpdateTime = null;
        FieldData = new ArrayList<>();

        synchronized (object) {
            sPoolData = this;
        }
    }

}
