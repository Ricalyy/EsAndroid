package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author huang
 */
public class QteCommTimeBucketReq extends ApiStruct {
    public static final int STRUCT_LENGTH = 21;
    private String CommodityId;

    public String getCommodityId() {
        return CommodityId;
    }

    public void setCommodityId(String templateNo) {
        CommodityId = templateNo;
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CommodityId, 21));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
