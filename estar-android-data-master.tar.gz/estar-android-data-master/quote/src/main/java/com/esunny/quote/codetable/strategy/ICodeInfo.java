package com.esunny.quote.codetable.strategy;

/**
 * @author Peter Fu
 * @date 2020/10/14
 */

import android.content.Context;

import com.esunny.quote.codetable.model.CodeTableModel;
import com.esunny.data.database.table.TUpdateManager;

import java.text.SimpleDateFormat;

/**
 * 不同类别的码表所需要的操作接口。
 */
public interface ICodeInfo {
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式

    void saveDBDataToCache(CodeTableModel model);

    void clearDBData(CodeTableModel model);

    void saveDataToDB(Context context);

    int getIndex();

    int getUpdateCode(TUpdateManager manager);
}
