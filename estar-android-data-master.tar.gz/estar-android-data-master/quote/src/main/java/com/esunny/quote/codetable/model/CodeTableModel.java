package com.esunny.quote.codetable.model;

import android.content.Context;
import android.text.TextUtils;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.Currency;
import com.esunny.data.bean.Exchange;
import com.esunny.data.bean.OptionContractPair;
import com.esunny.data.bean.OptionSeries;
import com.esunny.data.database.gen.TCommodityDao;
import com.esunny.data.database.gen.TContractDao;
import com.esunny.data.database.gen.TCurrencyDao;
import com.esunny.data.database.gen.TExchangeDao;
import com.esunny.data.database.gen.TUpdateManagerDao;
import com.esunny.quote.EsQuoteData;
import com.esunny.data.database.DBManager;
import com.esunny.data.database.table.TCommodity;
import com.esunny.data.database.table.TContract;
import com.esunny.data.database.table.TCurrency;
import com.esunny.data.database.table.TExchange;
import com.esunny.data.database.table.TUpdateManager;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * @author Peter Fu
 * @date 2020/10/13
 */
public class CodeTableModel {

    private final static String TAG = "CodeTableModel";

    private Context mContext;

    List<String> optionExchangeList = Arrays.asList("ZCE", "DCE", "SHFE", "CFFEX", "SSE", "SZSE", "CBOT", "CME", "COMEX", "NYMEX", "ICUS", "ICEU",
            "HKEX", "LME", "EUREX", "SGX", "OSE", "TAIFEX", "KRX", "BMD");

    List<String> ExchangeList = Arrays.asList("ZCE", "DCE", "SHFE", "INE","CFFEX", "SGE","SSE", "SZSE", "CBOT", "CBOT*", "CBOE","CME", "CME*", "COMEX", "COMEX*","NYMEX", "NYMEX*",
            "ICUS", "ICUS*","ICEU", "ICEU*", "HKEX", "HKEX*", "LME", "LME*", "EUREX", "EUREX*", "SGX", "SGX*", "APEX", "TOCOM", "FOREX", "BMD", "ASX", "KRX","OSE", "TFEX", "DGCX",
            "EURONEXT", "ICSG", "MGEX","TAIFEX");

    public CodeTableModel(Context context) {
        this.mContext = context;
    }

    public void saveCurrency() {
    }

    public void clearDataBase(String tableName) {
        if (tableName == null) {
            return;
        }

        switch (tableName) {
            case TCurrencyDao.TABLENAME:
                DBManager.getInstance().getDaoSession().getTCurrencyDao().deleteAll();
                break;
            case TExchangeDao.TABLENAME:
                DBManager.getInstance().getDaoSession().getTExchangeDao().deleteAll();
                break;
            case TCommodityDao.TABLENAME:
                DBManager.getInstance().getDaoSession().getTCommodityDao().deleteAll();
                break;
            case TContractDao.TABLENAME:
                DBManager.getInstance().getDaoSession().getTContractDao().deleteAll();
                break;
//            case TChargeCommodityDao.TABLENAME:
//                DBManager.getInstance().getDaoSession().getTChargeCommodityDao().deleteAll();
//                break;
            default:
                break;
        }

        List<TUpdateManager> tUpdateManagerList = DBManager.getInstance()
                .getDaoSession().getTUpdateManagerDao()
                .queryBuilder().where(TUpdateManagerDao.Properties.TableName.eq(tableName)).list();

        if (tUpdateManagerList != null) {
            DBManager.getInstance()
                    .getDaoSession().getTUpdateManagerDao().deleteInTx(tUpdateManagerList);
        }
    }

    public Currency getCurrency(String currencyNo) {
        Map<String, Currency> currencyMap = EsQuoteData.getInstance().getCurrencyMap();
        Currency currency = currencyMap.get(currencyNo);
        if (currency != null) {
            return currency;
        }

        TCurrency tCurrency = null;
        if (tCurrency == null) {
            tCurrency = DBManager.getInstance()
                    .getDaoSession().getTCurrencyDao()
                    .queryBuilder().where(TCurrencyDao.Properties.CurrencyNo.eq(currencyNo)).unique();

            if (tCurrency == null) {
                return null;
            }
        }

        currency = new Currency();
        currency.setCurrencyNo(tCurrency.getCurrencyNo());
        currency.setExchangeRate(tCurrency.getExchangeRate());
        currency.setInterestRate(tCurrency.getInterestRate());

        currencyMap.put(currencyNo, currency);
        return currency;
    }

    public Exchange getExchange(String exchangeNo) {
        Map<String, Exchange> exchangeMap = EsQuoteData.getInstance().getExchangeMap();
        if(exchangeMap.get(exchangeNo) != null) {
            return exchangeMap.get(exchangeNo);
        }

        TExchange tExchange = DBManager.getInstance()
                .getDaoSession().getTExchangeDao()
                .queryBuilder().where(TExchangeDao.Properties.ExchangeNo.eq(exchangeNo)).unique();
        if (tExchange == null) {
            return null;
        }

        Exchange exchange = new Exchange();
        exchange.setExchangeNo(exchangeNo);
        exchange.setExchangeName(tExchange.getExchangeName());

        exchangeMap.put(exchangeNo, exchange);
        return exchange;
    }

    public Commodity getCommodity(String commodityId) {
        if (commodityId == null || commodityId.isEmpty()) return null;

        Map<String, Commodity> commodityMap = EsQuoteData.getInstance().getCommodityMap();

        Commodity commodity = commodityMap.get(commodityId);
        if (commodity != null) {
            return commodity;
        }

        TCommodity tCommodity = DBManager.getInstance()
                .getDaoSession().getTCommodityDao()
                .queryBuilder().where(TCommodityDao.Properties.CommodityId.eq(commodityId)).unique();
        if (tCommodity == null) {
            return null;
        }

        commodity = new Commodity();

        commodity.setCommodityNo(tCommodity.getCommodityId());
        commodity.setCommodityName(tCommodity.getCommodityName());
        double priceTick = tCommodity.getPriceTick();
        int pirceDeno = tCommodity.getPriceDeno();
        commodity.setPriceNume(priceTick);
        commodity.setPriceDeno(pirceDeno);
        commodity.setPriceTick(priceTick/pirceDeno);
        commodity.setPricePrec((short) calPrice(priceTick));
        commodity.setPriceMultiple(tCommodity.getPriceMultiple());
        commodity.setTradeDot(tCommodity.getCommodityDot());
        commodity.setExerciseDot(tCommodity.getExecuteDot());
        commodity.setCoverMode(tCommodity.getCoverMode().charAt(0));
        commodity.setSpreadDirect(tCommodity.getSpreadDirect().charAt(0));
        commodity.setOptionExercise(tCommodity.getExecuteWay().charAt(0));
        commodity.setOptionProperty(tCommodity.getOptionType().charAt(0));
        commodity.setMaxSingleOrderQty(BigInteger.valueOf(tCommodity.getMaxSingleOrderQty()));
        commodity.setMaxPositionQty(BigInteger.valueOf(tCommodity.getMaxPositionQty()));

        commodity.setExchange(getExchange(tCommodity.getExchangeNo()));
        commodity.setCurrency(getCurrency(tCommodity.getCurrencyNo()));
        Contract targetContract1 = getContract(tCommodity.getRCommodityId1(), true);
        if (targetContract1 != null) {
            commodity.setTargetContract1(targetContract1.getContractNo());
        }
        Commodity targetCommodity1 = getCommodity(tCommodity.getRCommodityId1());
        if (targetCommodity1 != null) {
            commodity.setTargetCommodity1(targetCommodity1.getCommodityNo());
        }
        Commodity targetCommodity2 = getCommodity(tCommodity.getRCommodityId2());
        if (targetCommodity2 != null) {
            commodity.setTargetCommodity2(targetCommodity2.getCommodityNo());
        }

        commodityMap.put(commodityId, commodity);
        return commodity;
    }

    private int calPrice(double price) {
        for (int i = 0; i < 10; i++) {
            double value = price * Math.pow(10, i);
            if (value - Math.floor(value) < 0.0000000001) {
                return i;
            }
        }
        return 9;
    }

    public Contract getContract(String contractNo, boolean isTransferRealContract) {
        if (TextUtils.isEmpty(contractNo)) {
            return null;
        }

        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();
        Map<String, Contract> realContractMap = EsQuoteData.getInstance().getContractUnderLyMap();
        Contract contract = contractMap.get(contractNo);
        if (contract != null && !isTransferRealContract) {
            return contract;
        } else if (contract != null) {
            Contract realContract = realContractMap.get(contractNo);
            return realContract != null ? realContract : contract;
        }

        TContract tContract = null;

        tContract = DBManager.getInstance()
                .getDaoSession().getTContractDao()
                .queryBuilder().where(TContractDao.Properties.ContractNo.eq(contractNo)).unique();

        if (tContract == null) {
            return null;
        }

        contract = new Contract();
        if (isTransferRealContract) {
            contract.setContractNo(tContract.getRealContractNo());
        } else {
            contract.setContractNo(tContract.getContractNo());
        }
        Commodity commodity = getCommodity(tContract.getTCommodityId());
        contract.setCommodity(commodity);
        if (!tContract.getContractName().isEmpty()) {
            contract.setContractName(tContract.getContractName());
        } else {
            contract.setContractName(getContractNameByCommodity(contract.getContractNo(), commodity));
        }

        contractMap.put(contractNo, contract);
        if (!contractNo.equals(tContract.getRealContractNo())) {
            realContractMap.put(contractNo, getContract(tContract.getRealContractNo(), false));
        }
        return contract;
    }

    public String getContractNameByCommodity(String contractNo, Commodity commodity) {
        String[] strArray = contractNo.split("\\|");

        String type = strArray[strArray.length-1];
        String typeStr = "type";
        int languageInApp = EsDataApi.getLanguageType();

        if ("MAIN".equals(type)) {
            if (languageInApp == EsDataConstant.S_ANDROID_CHS) {
                typeStr = "主连";
            } else if (languageInApp == EsDataConstant.S_ANDROID_CHT) {
                typeStr = "主連";
            }
        } else if ("INDEX".equals(type)) {
            if (languageInApp == EsDataConstant.S_ANDROID_CHS) {
                typeStr = "指数";
            } else if (languageInApp == EsDataConstant.S_ANDROID_CHT) {
                typeStr = "指數";
            }
        } else if ("NEARBY".equals(type)) {
            if (languageInApp == EsDataConstant.S_ANDROID_CHS) {
                typeStr = "近月";
            } else if (languageInApp == EsDataConstant.S_ANDROID_CHT) {
                typeStr = "近月";
            }
        } else if (type.contains("SUM")) {
            typeStr = "总量";
        } else if (strArray.length == 5) {
            // 套利合约, SPD|s|SA|009|101
            typeStr = strArray[strArray.length - 2] + "|" + strArray[strArray.length - 1];
        } else {
            // 合约交割日期
            typeStr = strArray[strArray.length - 1];
        }

        String commodityName = commodity.getCommodityName();

        return commodityName + typeStr;
    }

    public List<Contract> getContractListByCommodity(String plateNo, final List<String> commodityNoList) {
        Map<String, List<Contract>> contractByCommodityNoMap = EsQuoteData.getInstance().getContractByCommodityNoMap();
        List<Contract> list = contractByCommodityNoMap.get(plateNo);

        if (list != null) {
            return list;
        } else {
            list = new ArrayList<>();
        }

        List<TContract> tContractList = DBManager.getInstance()
                .getDaoSession().getTContractDao()
                .queryBuilder().where(TContractDao.Properties.TCommodityId.in(commodityNoList)).list();

        Collections.sort(tContractList, new Comparator<TContract>() {
            @Override
            public int compare(TContract o1, TContract o2) {
                int commodityIndex = commodityNoList.indexOf(o1.getTCommodityId()) - commodityNoList.indexOf(o2.getTCommodityId());
                if (commodityIndex == 0) {
                    return o1.getContractNo().compareTo(o2.getContractNo());
                } else {
                    return commodityIndex;
                }
            }
        });

        for (TContract tContract : tContractList) {
            if (tContract == null) {
                continue;
            }
            list.add(toContract(tContract, false));
        }

        contractByCommodityNoMap.put(plateNo, list);

        return new ArrayList<>(list);
    }

    private Contract toContract(TContract tContract, boolean isShowRealContractNo) {
        Contract contract = new Contract();
        Commodity commodity = getCommodity(tContract.getTCommodityId());
        contract.setCommodity(commodity);
        if (!tContract.getContractName().isEmpty()) {
            contract.setContractName(tContract.getContractName());
        } else {
            contract.setContractName(getContractNameByCommodity(tContract.getContractNo(), commodity));
        }
        if (isShowRealContractNo) {
            contract.setContractNo(tContract.getRealContractNo());
        } else {
            contract.setContractNo(tContract.getContractNo());
        }
        return contract;
    }

    public List<Commodity> getOptionCommodityList() {
        List<Commodity> optionCommodityList = EsQuoteData.getInstance().getOptionCommodityList();

        if (optionCommodityList != null && optionCommodityList.size() > 0) {
            return optionCommodityList;
        }

        optionCommodityList = new ArrayList<>();
        Map<String, Commodity> commodityMap = EsQuoteData.getInstance().getCommodityMap();

        List<TCommodity> tCommodityList = DBManager.getInstance()
                .getDaoSession().getTCommodityDao()
                .queryBuilder().where(TCommodityDao.Properties.CommodityId.like("%|O|%")).list();

        Collections.sort(tCommodityList, new Comparator<TCommodity>() {
            @Override
            public int compare(TCommodity o1, TCommodity o2) {
                return optionExchangeList.indexOf(o1.getExchangeNo()) - optionExchangeList.indexOf(o2.getExchangeNo());
            }
        });
        for (TCommodity tCommodity : tCommodityList) {
            if (tCommodity == null) {
                continue;
            }
            Commodity commodity = toCommodity(tCommodity);
            optionCommodityList.add(commodity);

            if (commodityMap.get(tCommodity.getCommodityId()) == null) {
                commodityMap.put(tCommodity.getCommodityId(), commodity);
            }

        }

        return optionCommodityList;
    }

    private Commodity toCommodity(TCommodity tCommodity) {
        Commodity commodity = new Commodity();

        commodity.setCommodityNo(tCommodity.getCommodityId());
        commodity.setCommodityName(tCommodity.getCommodityName());
        commodity.setCoverMode(tCommodity.getCoverMode().charAt(0));
        double priceTick = tCommodity.getPriceTick();
        commodity.setPriceNume(priceTick);
        commodity.setPriceDeno(tCommodity.getPriceDeno());
        commodity.setPriceTick(tCommodity.getPriceTick());
        commodity.setPriceMultiple(tCommodity.getPriceMultiple());
        commodity.setExerciseDot(tCommodity.getExecuteDot());
        commodity.setPricePrec((short) calPrice(priceTick));
        commodity.setTradeDot(tCommodity.getCommodityDot());
        commodity.setSpreadDirect(tCommodity.getSpreadDirect().charAt(0));
        commodity.setOptionExercise(tCommodity.getExecuteWay().charAt(0));
        commodity.setOptionProperty(tCommodity.getOptionType().charAt(0));
        commodity.setMaxSingleOrderQty(BigInteger.valueOf(tCommodity.getMaxSingleOrderQty()));
        commodity.setMaxPositionQty(BigInteger.valueOf(tCommodity.getMaxPositionQty()));

        commodity.setExchange(getExchange(tCommodity.getExchangeNo()));
        commodity.setCurrency(getCurrency(tCommodity.getCurrencyNo()));
        Contract targetContract1 = getContract(tCommodity.getRCommodityId1(), true);
        if (targetContract1 != null) {
            commodity.setTargetContract1(targetContract1.getContractNo());
        }
        Commodity targetCommodity1 = getCommodity(tCommodity.getRCommodityId1());
        if (targetCommodity1 != null) {
            commodity.setTargetCommodity1(targetCommodity1.getCommodityNo());
        }
        Commodity targetCommodity2 = getCommodity(tCommodity.getRCommodityId2());
        if (targetCommodity2 != null) {
            commodity.setTargetCommodity2(targetCommodity2.getCommodityNo());
        }

        return commodity;
    }

    public List<OptionSeries> getOptionSeriesOfCommodity(String commodityNo) {
        if(commodityNo == null || commodityNo.isEmpty()) {
            return new ArrayList<>();
        }
        Map<String, List<OptionSeries>> optionSeriesByCommodityMap = EsQuoteData.getInstance().getOptionSeriesByCommodityNoMap();
        Map<String, List<OptionContractPair>> optionContractPairByOptionSeriesNoMap = EsQuoteData.getInstance().getOptionContractPairByOptionSeriesNoMap();

        List<OptionSeries> result = optionSeriesByCommodityMap.get(commodityNo);
        if (result != null && result.size() > 0) {
            return result;
        } else {
            result = new ArrayList<>();
        }

        Commodity commodity = getCommodity(commodityNo);
        if (commodity == null) {
            return result;
        }

        Commodity commodity1 = getCommodity(commodity.getTargetCommodity1());
        Contract contract1 = getContract(commodity.getTargetContract1(), true);

        if (commodity1 == null && contract1 == null) {
            return result;
        }

        List<Contract> contractList = getContractByCommodity(commodityNo);
        List<String> seriesNoList = new ArrayList<>();
        StringBuilder buffer = new StringBuilder();

        String pattern = ".+\\d+C\\d+$";
        for (Contract contract : contractList) {
            if (contract == null) continue;

            String contractNo = contract.getContractNo();
            if (!Pattern.matches(pattern, contractNo)) continue;

            int cIndex = contractNo.lastIndexOf("C");
            String seriesNo = contractNo.substring(0, cIndex);
            String strikePrice = contractNo.substring(cIndex + 1);

            if (!seriesNoList.contains(seriesNo)) {
                seriesNoList.add(seriesNo);

                Contract targetContract = contract1;
                if (targetContract == null) {
                    String targetContractNo = seriesNo.replace("|O|", "|F|");
                    targetContract = getContract(targetContractNo, true);
                }

                OptionSeries optionSeries = new OptionSeries();
                optionSeries.setCommodity(commodity);
                optionSeries.setTargetContract(targetContract);
                optionSeries.setSeriesNo(seriesNo);
                result.add(optionSeries);
            }

            OptionContractPair optionContractPair = new OptionContractPair();
            optionContractPair.setStrikePrice(strikePrice);
            optionContractPair.setContract1(contract);
            buffer.setLength(0);
            buffer.append(seriesNo).append("P").append(strikePrice);
            String contract2No = buffer.toString();
            optionContractPair.setContract2(getContract(contract2No, true));

            List<OptionContractPair> optionContractPairList = optionContractPairByOptionSeriesNoMap.get(seriesNo);
            if (optionContractPairList == null) {
                optionContractPairList = new ArrayList<>();
            }
            optionContractPairList.add(optionContractPair);
            optionContractPairByOptionSeriesNoMap.put(seriesNo, optionContractPairList);
        }

        optionSeriesByCommodityMap.put(commodityNo, result);

        return result;
    }

    public List<Contract> getContractByCommodity(String commodityNo) {
        Map<String, List<Contract>> contractByCommodityNoMap = EsQuoteData.getInstance().getContractByCommodityNoMap();
        List<Contract> list = contractByCommodityNoMap.get(commodityNo);
        if (list != null) {
            return list;
        } else {
            list = new ArrayList<>();
        }

        List<TContract> tContractList = null;

        tContractList = DBManager.getInstance()
                .getDaoSession().getTContractDao()
                .queryBuilder().where(TContractDao.Properties.TCommodityId.eq(commodityNo)).list();

        for (TContract tContract : tContractList) {
            if (tContract == null) {
                continue;
            }
            list.add(toContract(tContract, false));

        }

        contractByCommodityNoMap.put(commodityNo, list);

        return list;
    }

    public List<OptionContractPair> getOptionContractPairOfSeriesNo(String seriesNo) {
        Map<String, List<OptionContractPair>> optionContractPairByOptionSeriesNoMap = EsQuoteData.getInstance().getOptionContractPairByOptionSeriesNoMap();
        List<OptionContractPair> result = optionContractPairByOptionSeriesNoMap.get(seriesNo);

        if (result != null) return result;

        int index = seriesNo.lastIndexOf("|");
        String commodityNo = seriesNo.substring(0, index);
        getOptionSeriesOfCommodity(commodityNo);
        return optionContractPairByOptionSeriesNoMap.get(seriesNo);
    }
}
