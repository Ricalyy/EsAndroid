package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class QteKLineReq extends ApiStruct {
    public final static int STRUCT_LENGTH = 72;
    private int HopeCount;       //期望数量（扩展使用）
    private String ContractId;      //合约ID
    private char KLineType;       //K线类型
    private long BeginTime;       //查询开始时间 所有数据查询均是从尾部开始，begintime表示的是截止时间，无begintime最大查询500根
    private long EndTime;         //查询结束时间 0就是从末尾查，注意：数据结果中不包含与begintime和endtime相等的数据

    public String getContractId() {
        return ContractId;
    }

    public void setContractId(String contractId) {
        ContractId = contractId;
    }

    public char getKLineType() {
        return KLineType;
    }

    public void setKLineType(char KLineType) {
        this.KLineType = KLineType;
    }

    public int getHopeCount() {
        return HopeCount;
    }

    public void setHopeCount(int hopeCount) {
        HopeCount = hopeCount;
    }

    public long getBeginTime() {
        return BeginTime;
    }

    public void setBeginTime(long beginTime) {
        BeginTime = beginTime;
    }

    public long getEndTime() {
        return EndTime;
    }

    public void setEndTime(long endTime) {
        EndTime = endTime;
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.putInt(HopeCount);
        buffer.put(stringToByte(ContractId,51));
        buffer.put(charToByte(KLineType));
        buffer.putLong(BeginTime);
        buffer.putLong(EndTime);
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
