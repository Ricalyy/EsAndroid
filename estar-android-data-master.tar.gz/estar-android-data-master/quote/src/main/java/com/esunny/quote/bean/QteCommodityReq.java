package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/9/21
 */
public class QteCommodityReq extends ApiStruct {

    public final static int STRUCT_LENGTH = 21;

    private String CommodityId;          //填空从头开始查，续查每次把应答包发回请求

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CommodityId, 21));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCommodityId(util.getString(21));
    }

    public String getCommodityId() {
        return CommodityId;
    }

    public void setCommodityId(String commodityId) {
        CommodityId = commodityId;
    }
}
