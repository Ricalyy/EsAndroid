package com.esunny.quote.codetable.strategy;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.Contract;
import com.esunny.data.database.gen.TContractDao;
import com.esunny.data.util.EsLog;
import com.esunny.quote.EsQuoteData;
import com.esunny.data.database.DBManager;
import com.esunny.quote.codetable.CodeTable;
import com.esunny.quote.codetable.model.CodeTableModel;
import com.esunny.data.database.table.TContract;
import com.esunny.data.database.table.TUpdateManager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author Peter Fu
 * @date 2020/10/14
 */
public class TContractCodeInfo implements ICodeInfo {
    private static final String TAG = "TContractCodeInfo";

    //    private TContract tContract = new TContract();
//    private ParseUtil util = ParseUtil.wrap(null);

    @Override
    public void saveDBDataToCache(CodeTableModel model) {
//        model.saveContract();
    }

    @Override
    public void clearDBData(CodeTableModel model) {
        model.clearDataBase(TContractDao.TABLENAME);
    }

    @Override
    public void saveDataToDB(Context context) {
        Log.d(TAG, "start save Contract");
        long updateId = CodeTable.getInstance().saveSateBeforeUpdate(context, TContractDao.TABLENAME);

        //TODO 分期货合约与期权合约数据库进行优化。
        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();
        Map<String, Contract> underLayContractMap = EsQuoteData.getInstance().getContractUnderLyMap();
        List<TContract> list = new ArrayList<>();

        int languageType = EsDataApi.getLanguageType();
        for (Map.Entry<String, Contract> set :  contractMap.entrySet()) {
            Contract contract = set.getValue();
            Contract realContract = underLayContractMap.get(set.getKey());

            TContract tContract = new TContract();

            if (languageType == EsDataConstant.S_ANDROID_CHS) {
                tContract.setCHSContractName(contract.getContractName());
            } else if (languageType == EsDataConstant.S_ANDROID_ENU) {
                tContract.setENUContractName(contract.getContractName());
            } else if (languageType == EsDataConstant.S_ANDROID_CHT) {
                tContract.setCHTContractName(contract.getContractName());
            }

            tContract.setContractNo(set.getKey());
            if (realContract != null) {
                tContract.setRealContractNo(realContract.getContractNo());
            } else {
                tContract.setRealContractNo(set.getKey());
            }
            if (contract.getCommodity() != null) {
                tContract.setTCommodityId(contract.getCommodity().getCommodityNo());
            }

            list.add(tContract);
        }

        DBManager.getInstance().getDaoSession()
                .getTContractDao().insertOrReplaceInTx(list);

        CodeTable.getInstance().saveStateAfterUpdate(context, updateId);
        Log.d(TAG, "end save contract, list size : " +  list.size() + ", update id : " + updateId);
    }

    @Override
    public int getIndex() {
        return 3;
    }

    @Override
    public int getUpdateCode(TUpdateManager manager) {
        // 获取存取结果信息判断

        boolean result = manager.getResult();
        if (!result) {
            return 0;
        }

        // 获取语言信息判断
        int languageInDb = manager.getLanguage();
        int languageInApp = EsDataApi.getLanguageType();

        if (languageInDb != languageInApp) {
            return 0;
        }

        // 获取时间信息判断, 以月为单位更新
        String dateDate = manager.getDateTime();
        Date date = null;
        try {
            if (!TextUtils.isEmpty(dateDate)) {
                date = df.parse(dateDate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        int nowDay = calendar.get(Calendar.DAY_OF_YEAR);

        calendar.setTime(date);
        int updateDay = calendar.get(Calendar.DAY_OF_YEAR);
        calendar.clear();

        boolean isUpdate = nowDay != updateDay;

        // 同步过合约，说明同时也同步了ContractName,ContractUnderlay
        int updateCode = isUpdate ? 0 : (1 << getIndex()) + 16 + 64;
        EsLog.d(TAG, "update code : %d", updateCode);
        return updateCode;
    }

}