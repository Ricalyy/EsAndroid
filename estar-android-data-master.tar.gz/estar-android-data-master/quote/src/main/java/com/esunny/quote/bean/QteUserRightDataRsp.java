package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author huang
 */
public class QteUserRightDataRsp extends ApiStruct {

    private String UserName;                                // 行情账号用户名
    private char RightType;                               // 授权项目类型
    private String RightNo;                                 // 品种组or插件号
    private String BeginDate;                               // 开始日期
    private String ExpireData;                              // 结束日期

    public QteUserRightDataRsp(byte[] struct) {
        byteToBean(struct);
    }

    public static QteUserRightDataRsp toParse(byte[] struct) {
        return new QteUserRightDataRsp(struct);
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public char getRightType() {
        return RightType;
    }

    public void setRightType(char rightType) {
        RightType = rightType;
    }

    public String getRightNo() {
        return RightNo;
    }

    public void setRightNo(String rightNo) {
        RightNo = rightNo;
    }

    public String getBeginDate() {
        return BeginDate;
    }

    public void setBeginDate(String beginDate) {
        BeginDate = beginDate;
    }

    public String getExpireData() {
        return ExpireData;
    }

    public void setExpireData(String expireData) {
        ExpireData = expireData;
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setUserName(util.getString(51));
        setRightType(util.getChar());
        setRightNo(util.getString(21));
        setBeginDate(util.getString(11));
        setExpireData(util.getString(11));
    }
}
