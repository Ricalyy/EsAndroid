package com.esunny.quote.codetable.strategy;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.Exchange;
import com.esunny.data.database.gen.TExchangeDao;
import com.esunny.data.util.EsLog;
import com.esunny.quote.EsQuoteData;
import com.esunny.data.database.DBManager;
import com.esunny.quote.codetable.CodeTable;
import com.esunny.quote.codetable.model.CodeTableModel;
import com.esunny.data.database.table.TExchange;
import com.esunny.data.database.table.TUpdateManager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author Peter Fu
 * @date 2020/10/15
 */
public class TExchangeCodeInfo implements ICodeInfo{

    private static final String TAG = "TExchangeCodeInfo";

    @Override
    public void saveDBDataToCache(CodeTableModel model) {

    }

    @Override
    public void clearDBData(CodeTableModel model) {
        model.clearDataBase(TExchangeDao.TABLENAME);
    }

    @Override
    public void saveDataToDB(Context context) {
        if (context == null) {
            return;
        }

        Log.d(TAG, "start save exchange");

        long updateId = CodeTable.getInstance().saveSateBeforeUpdate(context, TExchangeDao.TABLENAME);
        Map<String, Exchange> exchangeMap = EsQuoteData.getInstance().getExchangeMap();

        List<TExchange> list = new ArrayList<>();
        for (Map.Entry<String, Exchange> set :  exchangeMap.entrySet()) {
            Exchange exchange = set.getValue();
            TExchange tExchange = new TExchange();

            tExchange.setExchangeNo(set.getKey());
            int languageType = EsDataApi.getLanguageType();
            if (languageType == EsDataConstant.S_ANDROID_CHS) {
                tExchange.setCHSName(exchange.getExchangeName());
            } else if (languageType == EsDataConstant.S_ANDROID_ENU) {
                tExchange.setENUName(exchange.getExchangeName());
            } else if (languageType == EsDataConstant.S_ANDROID_CHT) {
                tExchange.setCHTName(exchange.getExchangeName());
            }

            tExchange.setUpdateId(updateId);
            list.add(tExchange);
        }

        DBManager.getInstance().getDaoSession()
                .getTExchangeDao().insertOrReplaceInTx(list);

        CodeTable.getInstance().saveStateAfterUpdate(context, updateId);
        Log.d(TAG, "end save exchange, list size : " +  list.size());
    }

    @Override
    public int getIndex() {
        return 1;
    }

    @Override
    public int getUpdateCode(TUpdateManager manager) {
        // 获取存取结果信息判断
        boolean result = manager.getResult();
        if (!result) {
            return 0;
        }

        // 获取时间信息判断, 以月为单位更新
        String dateDate = manager.getDateTime();
        Date date = null;
        try {
            if (!TextUtils.isEmpty(dateDate)) {
                date = df.parse(dateDate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        int nowMonth = calendar.get(Calendar.MONTH);
        int nowYear = calendar.get(Calendar.YEAR);
        calendar.setTime(date);
        int updateMonth = calendar.get(Calendar.MONTH);
        int updateYear = calendar.get(Calendar.YEAR);
        calendar.clear();

        boolean isUpdate = nowMonth != updateMonth || nowYear != updateYear;

        int updateCode = isUpdate ? 0 : 1 << getIndex();
        EsLog.d(TAG, "TExchange updateCode : " + updateCode);

        return updateCode;
    }
}
