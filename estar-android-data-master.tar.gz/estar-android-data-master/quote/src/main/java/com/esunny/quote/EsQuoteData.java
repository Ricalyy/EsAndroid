package com.esunny.quote;


import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.Currency;
import com.esunny.data.bean.Exchange;
import com.esunny.data.bean.OptionContractPair;
import com.esunny.data.bean.OptionSeries;
import com.esunny.quote.bean.QteStockContData;
import com.esunny.quote.bean.RegUserCommGroupQryRsp;
import com.esunny.quote.bean.RegUserPluginQryRsp;
import com.esunny.quote.bean.SChargeInfo;
import com.esunny.quote.bean.SContract;
import com.esunny.quote.bean.SHisMinTimeBucket;
import com.esunny.quote.bean.SHisQuoteDef;
import com.esunny.quote.bean.SHisQuoteMinuteDef;
import com.esunny.data.bean.SQuoteUserInfo;
import com.esunny.quote.bean.STimeBucketDef;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class EsQuoteData {

    private int QuoteKey;
    private int HisQuoteKey;
    private int HisQuoteSessionId = 1;

    // 行情状态，未初始化时未0，行情数据初始化完成为1
    private volatile boolean QuoteStatus = false;

    // 历史行情状态，未初始化时未0，历史行情数据初始化完成为1
    private boolean HisQuoteStatus = false;

    // 行情连接的地址
    private AddrInfo mQuoteAddressInfo = new AddrInfo();
    // 历史行情连接的地址
    private AddrInfo mHisQuoteAddressInfo = new AddrInfo();

    /**
     * 记录行情数据请求完成状态标志位
     * {@link EsQuoteProtocol#SUCCESS_COMPLETED_FLAG}
     */
    private volatile int mQuoteDataFlag = 0;

//    private SQuoteUserInfo mQuoteUserInfo = new SQuoteUserInfo();
    // 用户品种组权限的哈希表，key  为 品种组号
    private Map<String, RegUserCommGroupQryRsp> mUserCommGroupMap = new HashMap<>();

    private Map<String, RegUserPluginQryRsp> mUserPluginMap = new HashMap<>();
    //收费品种数据
    private Map<String, SChargeInfo> mChargeCommodityMap = new HashMap<>((int) (1000 / 0.75));
    // 收费交易所 key 为exchangeNo
    private List<String> mChargeExchageList = new ArrayList<>();
//    // 权限数据
//    private Map<String, QteUserRightData> mUserRightDataMap = new HashMap<>((int) (1000 / 0.75));
    // 股票数据
    private Map<String, QteStockContData> mStockContDataMap = new HashMap<>((int) (1000 / 0.75));
    // 时间模板
    private Map<String, STimeBucketDef> mTimeBucketDefDataMap = new HashMap<>((int) (1000 / 0.75));
    // 计算时间模板
    private Map<String, STimeBucketDef> mCommTimeBucketDataMap = new HashMap<>((int) (1000 / 0.75));
    // 历史时间模板
    private Map<String, SHisMinTimeBucket> mHisMinTimeBucketDataMap = new HashMap<>((int) (1000 / 0.75));
    // 期权序列，Key : SerialNo Value : OptionSeries
    private Map<String, OptionSeries> mOptionSeriesDataMap = new HashMap<>((int) (1000 / 0.75));
    // key 为 期权品种号， value 为 期权品种对应的系列列表
    private ConcurrentHashMap<String, List<OptionSeries>> mOptionSeriesByCommodityNoMap = new ConcurrentHashMap<>((int) (1000 / 0.75));

    // 币种数据
    private Map<String, Currency> mCurrencyMap = new ConcurrentHashMap<>();
    // 交易所数据
    private Map<String, Exchange> mExchangeMap = new ConcurrentHashMap<>();
    // 所有的品种数据
    private Map<String, Commodity> mCommodityMap = new ConcurrentHashMap<>((int) (2000 / 0.75));
    // 期权品种数据
    private List<Commodity> mOptionCommodityList = new ArrayList<>((int) (1000 / 0.75));
    //  key为 期权系列号SerireNo, value 为系列号对应的期权合约对列表
    private ConcurrentHashMap<String, List<OptionContractPair>> mOptionContractPairByOptionSeriesNoMap = new ConcurrentHashMap<>((int) (1000 / 0.75));
    // 所有的合约数据
    private Map<String, Contract> mContractMap = new ConcurrentHashMap<>((int) (270000 / 0.75));
    // key : 期权品种号 CommodityNo, Value : 期权品种对应的合约列表
    private ConcurrentHashMap<String, List<Contract>> mContractByOptionCommodityNoMap = new ConcurrentHashMap<>(1024);
    // 普通品种对应的合约列表 key: 普通品种号，Value : 普通品种对应的合约列表
    private ConcurrentHashMap<String, List<Contract>> mContractByCommodityNoMap = new ConcurrentHashMap<>(1024);
    // 真实虚拟合约对应
    private Map<String, Contract> mContractUnderLyMap = new ConcurrentHashMap<>((int) (5000 / 0.75));
    // 合约行情订阅统计，对应G_QuoteSub。 Key : contractNo, Value : 订阅次数
    private Map<String, Integer> mQuoteSub = new ConcurrentHashMap<>();
    // 合约行情快照表， Key : 合约号 ， Value ： 合约行情数据的合并体
    private Map<String, SContract> mSContractSnapData = new ConcurrentHashMap<>();
    // 历史数据
    private Map<String, SHisQuoteDef> mSHisQuoteDefMap = new ConcurrentHashMap<>();
    // 历史分钟数据
    private Map<String, SHisQuoteMinuteDef> mSHisQuoteMinuteDefMap = new HashMap<>();

    private EsQuoteData() {
    }

    public void setQuoteAddress(AddrInfo address) {
        this.mQuoteAddressInfo = address;
    }

    public AddrInfo getQuoteAddress () {
        return mQuoteAddressInfo;
    }

    public void setHisQuoteAddress(AddrInfo address) {
        this.mHisQuoteAddressInfo = address;
    }

    public AddrInfo getHisQuoteAddress () {
        return mHisQuoteAddressInfo;
    }

    private static class SingletonClassInstance {
        private static final EsQuoteData INSTANCE = new EsQuoteData();
    }

    public static EsQuoteData getInstance() {
        return EsQuoteData.SingletonClassInstance.INSTANCE;
    }

    public int getHisQuoteSessionId() {
        return HisQuoteSessionId;
    }

    public void setHisQuoteSessionId(int hisQuoteSessionId) {
        HisQuoteSessionId = hisQuoteSessionId;
    }

    public int getQuoteKey() {
        return QuoteKey;
    }

    public void setQuoteKey(int quoteKey) {
        QuoteKey = quoteKey;
    }

    public int getHisQuoteKey() {
        return HisQuoteKey;
    }

    public void setHisQuoteKey(int hisQuoteKey) {
        HisQuoteKey = hisQuoteKey;
    }

    public String getUserNo() {
        return "";
    }

    public String getPassword() {
        return "";
    }

    public boolean getQuoteStatus() {
        return QuoteStatus;
    }

    public void setQuoteStatus(boolean quoteStatus) {
        QuoteStatus = quoteStatus;
    }

    public boolean getHisQuoteStatus() {
        return HisQuoteStatus;
    }

    public void setHisQuoteStatus(boolean hisQuoteStatus) {
        HisQuoteStatus = hisQuoteStatus;
    }

//    public SQuoteUserInfo getmQuoteUserInfo() {
//        return mQuoteUserInfo;
//    }

//    public void setQuoteUserInfo(SQuoteUserInfo mQuoteUserInfo) {
//        this.mQuoteUserInfo = mQuoteUserInfo;
//    }

    public int getQuoteDataFlag() {
        return mQuoteDataFlag;
    }

    public void setQuoteDataFlag(int mQuoteDataFlag) {
        this.mQuoteDataFlag = mQuoteDataFlag;
    }

    public Map<String, SChargeInfo> getChargeCommodityMap() {
        return mChargeCommodityMap;
    }

    public List<String> getChargeExchageList() {
        return mChargeExchageList;
    }

    public Map<String, QteStockContData> getStockContData() {
        return mStockContDataMap;
    }

    public void setStockContData(Map<String, QteStockContData> mStockContData) {
        this.mStockContDataMap = mStockContData;
    }

    public ConcurrentHashMap<String, List<OptionSeries>> getOptionSeriesByCommodityNoMap() {
        return mOptionSeriesByCommodityNoMap;
    }

    public void setOptionSeriesByCommodityNoMap(ConcurrentHashMap<String, List<OptionSeries>> optionSeriesByCommodityNoMap) {
        this.mOptionSeriesByCommodityNoMap = optionSeriesByCommodityNoMap;
    }

    public Map<String, Currency> getCurrencyMap() {
        return mCurrencyMap;
    }

    public void setCurrencyMap(Map<String, Currency> currencyMap) {
        this.mCurrencyMap = currencyMap;
    }

    public Map<String, Exchange> getExchangeMap() {
        return mExchangeMap;
    }

    public void setExchangeMap(Map<String, Exchange> exchangeMap) {
        this.mExchangeMap = exchangeMap;
    }

    public Map<String, Contract> getContractMap() {
        return mContractMap;
    }

    public void setContractMap(Map<String, Contract> contract) {
        this.mContractMap = contract;
    }

    public ConcurrentHashMap<String, List<Contract>> getContractByOptionCommodityNoMap() {
        return mContractByOptionCommodityNoMap;
    }

    public void setContractByOptionCommodityNoMap(ConcurrentHashMap<String, List<Contract>> contractByCommodityNoMap) {
        this.mContractByOptionCommodityNoMap = contractByCommodityNoMap;
    }

    public ConcurrentHashMap<String, List<Contract>> getContractByCommodityNoMap() {
        return mContractByCommodityNoMap;
    }

    public void setContractByCommodityNoMap(ConcurrentHashMap<String, List<Contract>> mContractByCommodityNoMap) {
        this.mContractByCommodityNoMap = mContractByCommodityNoMap;
    }

    public Map<String, Commodity> getCommodityMap() {
        return mCommodityMap;
    }

    public void setCommodityMap(Map<String, Commodity> commodityMap) {
        this.mCommodityMap = commodityMap;
    }

    public List<Commodity> getOptionCommodityList() {
        return mOptionCommodityList;
    }

    public void setOptionCommodityList(List<Commodity> optionCommoditysSet) {
        this.mOptionCommodityList = optionCommoditysSet;
    }

    public ConcurrentHashMap<String, List<OptionContractPair>> getOptionContractPairByOptionSeriesNoMap() {
        return mOptionContractPairByOptionSeriesNoMap;
    }

    public void setOptionContractPairByOptionSeriesNoMap(ConcurrentHashMap<String, List<OptionContractPair>> optionContractPairByOptionSeriesNoMap) {
        this.mOptionContractPairByOptionSeriesNoMap = optionContractPairByOptionSeriesNoMap;
    }

    public Map<String, Contract> getContractUnderLyMap() {
        return mContractUnderLyMap;
    }

    public void setContractUnderLyMap(Map<String, Contract> contractUnderLyMap) {
        this.mContractUnderLyMap = contractUnderLyMap;
    }

    public Map<String, Integer> getQuoteSub() {
        return mQuoteSub;
    }

    public Map<String, SContract> getSContractSnapData() {
        return mSContractSnapData;
    }

    public void setSContractSnapData(Map<String, SContract> mSContractSnapData) {
        this.mSContractSnapData = mSContractSnapData;
    }

    public Map<String, STimeBucketDef> getTimeBucketDefDataMap() {
        return mTimeBucketDefDataMap;
    }

    public void setTimeBucketDefDataMap(Map<String, STimeBucketDef> mTimeBucketDefData) {
        this.mTimeBucketDefDataMap = mTimeBucketDefData;
    }

    public Map<String, STimeBucketDef> getCommTimeBucketDataMap() {
        return mCommTimeBucketDataMap;
    }

    public void setCommTimeBucketDataMap(Map<String, STimeBucketDef> mCommTimeBucketData) {
        this.mCommTimeBucketDataMap = mCommTimeBucketData;
    }

    public Map<String, SHisMinTimeBucket> getHisMinTimeBucketDataMap() {
        return mHisMinTimeBucketDataMap;
    }

    public void setHisMinTimeBucketDataMap(Map<String, SHisMinTimeBucket> mHisMinTimeBucketDataMap) {
        this.mHisMinTimeBucketDataMap = mHisMinTimeBucketDataMap;
    }

    public Map<String, SHisQuoteDef> getSHisQuoteDefMap() {
        return mSHisQuoteDefMap;
    }

    public void setSHisQuoteDefMap(Map<String, SHisQuoteDef> mSHisQuoteDefMap) {
        this.mSHisQuoteDefMap = mSHisQuoteDefMap;
    }

    public Map<String, SHisQuoteMinuteDef> getSHisQuoteMinuteDefMap() {
        return mSHisQuoteMinuteDefMap;
    }

    public void setSHisQuoteMinuteDefMap(Map<String, SHisQuoteMinuteDef> mSHisQuoteMinuteDefMap) {
        this.mSHisQuoteMinuteDefMap = mSHisQuoteMinuteDefMap;
    }

    public Map<String, RegUserCommGroupQryRsp> getUserCommGroupMap() {
        return mUserCommGroupMap;
    }

    public Map<String, RegUserPluginQryRsp> getUserPluginMap() {
        return mUserPluginMap;
    }
}
