package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.util.ParseUtil;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/10/9
 */
public class QteSnapShotField extends ApiStruct {
    public final static int STRUCT_LENGTH = 9;

    private char FieldMean;     //本数据域含义

    private double Price;         //价格字段取本值
    private BigInteger Qty;           //数量字段取本值
    private BigInteger DateTime;      //日期时间字段取本值
    private int Date;          //日期字段取本值
    private int Time;          //时间字段取本值
    private char Str;           //字符串字段取本值
    private char Char;          //字符类型取本值

    public QteSnapShotField(byte[] buf) {
        byteToBean(buf);
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);


        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);

        setFieldMean(util.getChar());
        switch (getFieldMean()) {
            case EsNativeProtocol.S_FID_PREPOSITIONQTY:
            case EsNativeProtocol.S_FID_TOTALQTY:
            case EsNativeProtocol.S_FID_POSITIONQTY:
            case EsNativeProtocol.S_FID_LASTQTY:
            case EsNativeProtocol.S_FID_BESTBIDQTY:
            case EsNativeProtocol.S_FID_BESTASKQTY:
            case EsNativeProtocol.S_FID_IMPLIEDBIDQTY:
            case EsNativeProtocol.S_FID_IMPLIEDASKQTY:
            case EsNativeProtocol.S_FID_TOTALBIDQTY:
            case EsNativeProtocol.S_FID_TOTALASKQTY:
                setQty(util.getLongLong());
                break;
            case EsNativeProtocol.S_FID_PRECLOSINGPRICE:
            case EsNativeProtocol.S_FID_PRESETTLEPRICE:
            case EsNativeProtocol.S_FID_OPENINGPRICE:
            case EsNativeProtocol.S_FID_LASTPRICE:
            case EsNativeProtocol.S_FID_HIGHPRICE:
            case EsNativeProtocol.S_FID_LOWPRICE:
            case EsNativeProtocol.S_FID_HISHIGHPRICE:
            case EsNativeProtocol.S_FID_HISLOWPRICE:
            case EsNativeProtocol.S_FID_LIMITUPPRICE:
            case EsNativeProtocol.S_FID_LIMITDOWNPRICE:
            case EsNativeProtocol.S_FID_AVERAGEPRICE:
            case EsNativeProtocol.S_FID_CLOSINGPRICE:
            case EsNativeProtocol.S_FID_SETTLEPRICE:
            case EsNativeProtocol.S_FID_BESTBIDPRICE:
            case EsNativeProtocol.S_FID_BESTASKPRICE:
            case EsNativeProtocol.S_FID_IMPLIEDBIDPRICE:
            case EsNativeProtocol.S_FID_IMPLIEDASKPRICE:
            case EsNativeProtocol.S_FID_TOTALTURNOVER:
                setPrice(util.getDouble());
                break;
            default:
                break;
        }
    }

    public char getFieldMean() {
        return FieldMean;
    }

    public void setFieldMean(char fieldMean) {
        FieldMean = fieldMean;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double price) {
        Price = price;
    }

    public BigInteger getQty() {
        return Qty;
    }

    public void setQty(BigInteger qty) {
        Qty = qty;
    }

    public BigInteger getDateTime() {
        return DateTime;
    }

    public void setDateTime(BigInteger dateTime) {
        DateTime = dateTime;
    }

    public int getDate() {
        return Date;
    }

    public void setDate(int date) {
        Date = date;
    }

    public int getTime() {
        return Time;
    }

    public void setTime(int time) {
        Time = time;
    }

    public char getStr() {
        return Str;
    }

    public void setStr(char str) {
        Str = str;
    }

    public char getChar() {
        return Char;
    }

    public void setChar(char aChar) {
        Char = aChar;
    }

    public static QteSnapShotField toParse(byte[] bytes) {
        return new QteSnapShotField(bytes);
    }
}
