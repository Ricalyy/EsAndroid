package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/10/9
 */
public class QteSnapShotReq extends ApiStruct {
    public static final int STRUCT_LENGTH = 51;

    private String CommodityId = null;   //品种编号(后台之间订阅使用品种)
    private String ContractId = null;    //合约编号(客户端向后台订阅使用合约)

    public int getStructLength() {
        if (ContractId != null) {
            return 51;
        } else {
            return 21;
        }
    }

    public String getCommodityId() {
        return CommodityId;
    }

    public void setCommodityId(String commodityId) {
        CommodityId = commodityId;
    }

    public String getContractId() {
        return ContractId;
    }

    public void setContractId(String contractId) {
        ContractId = contractId;
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        if (ContractId != null) {
            buffer.put(stringToByte(ContractId, 51));
        } else {
            buffer.put(stringToByte(CommodityId, 51));
        }
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
