package com.esunny.quote.bean;

import java.math.BigInteger;

public class QteDepthNewDetail {
    private short Action;         //操作，高4位标示买卖，低4位表示增加和修改
    private short Level;          //价格深度
    private BigInteger Qty;            //深度数量
    private double Price;          //深度价格

    public short getAction() {
        return Action;
    }

    public void setAction(short action) {
        Action = action;
    }

    public short getLevel() {
        return Level;
    }

    public void setLevel(short level) {
        Level = level;
    }

    public BigInteger getQty() {
        return Qty;
    }

    public void setQty(BigInteger qty) {
        Qty = qty;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double price) {
        Price = price;
    }
}
