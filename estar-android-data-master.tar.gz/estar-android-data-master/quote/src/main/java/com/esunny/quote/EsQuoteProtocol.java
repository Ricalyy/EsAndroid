package com.esunny.quote;

public class EsQuoteProtocol {

    public final static char CSP_SUBSYSTEM_QUOTE = 0x02;    //行情平台

    /**
     * 记录行情请求完成情况，使用二进制记录
     */
    public final static int NONE_FLAG = 0;
    public final static int CURRENCY_COMPLETED_FLAG = 0b000000001;
    public final static int EXCHANGE_COMPLETED_FLAG = 0b000000010;
    public final static int COMMODITY_COMPLETED_FLAG = 0b000000100;
    public final static int CONTRACT_COMPLETED_FLAG = 0b000001000;
    public final static int CONTRACT_NAME_COMPLETED_FLAG = 0b000010000;
    public final static int OPTION_EXPIRE_COMPLETED_FLAG = 0b000100000;
    public final static int CONTRACT_UNDERLAY_COMPLETED_FLAG = 0b001000000;
    public final static int CHARGE_COMMODITY_COMPLETED_FLAG = 0b010000000;
    public final static int STOCK_CONTRACT_COMPLETED_FLAG = 0b100000000;
    public final static int SUCCESS_COMPLETED_FLAG = 0b111111111;

    /**
     * 数据帧数据内容类型
     */
    //明文数据帧
    public final static char CSP_FRAME_PLAIN = '1';
    //RSA公钥加密
    public final static char CSP_FRAME_RSA = '2';
    //压缩数据帧
    public final static char CSP_FRAME_LZO = '3';
    //加密数据帧
    public final static char CSP_FRAME_IDEA = '4';
    //压缩加密数据帧(先压缩后加密)
    public final static char CSP_FRAME_LZO_IDEA = '5';

    public final static String QTE_DEFAULT_LICENSE_NO = "epolestar v9.3";//极星客户端授权号
    public final static String QTE_DEFAULT_LICENSE_NO_NEW = "epolestar v9.3.1";//极星客户端授权号 30版以后用该授权号（客户端发送品种组）

    public final static int CMD_QTE_NEW_LOGON_REQ = 0x0008;
    public final static int CMD_QTE_NEW_LOGON_RSP = 0x0009;

    /////////////////////////////////////登录//////////////////////////////////////////
    public final static int CMD_QTE_LOGON_REQ = 0x0004;
    public final static int CMD_QTE_LOGON_RSP = 0x0005;

    /////////////////////////////////////客户权限///////////////////////////////
    public final static int CMD_QTE_USER_RIGHT_REQ = 0x0B70;
    public final static int CMD_QTE_USER_RIGHT_RSP = 0x0B71;
    public final static int CMD_QTE_USER_RIGHT_DATA_RSP = 0x0B72;

    /////////////////////////////////////币种信息查询/////////////////////////////
    public final static int CMD_QTE_CURRENCY_REQ = 0x0100;
    public final static int CMD_QTE_CURRENCY_RSP = 0x0101;
    public final static int CMD_QTE_CURRENCY_DATA_RSP = 0x0102;

    /////////////////////////////////////交易所信息查询///////////////////////////
    public final static int CMD_QTE_EXCHANGE_REQ = 0x0110;
    public final static int CMD_QTE_EXCHANGE_RSP = 0x0111;
    public final static int CMD_QTE_EXCHANGE_DATA_RSP = 0x0112;

    //////////////////////////////////////品种信息查询//////////////////////////////////
    public final static int CMD_QTE_COMMODITY_REQ = 0x0120;
    public final static int CMD_QTE_COMMODITY_RSP = 0x0121;
    public final static int CMD_QTE_COMMODITY_DATA_RSP = 0x0122;

    /////////////////////////////////////收费品种查询///////////////////////////////////
    public final static int CMD_QTE_CHARGE_COMMODITY_REQ = 0x0123;
    public final static int CMD_QTE_CHARGE_COMMODITY_RSP = 0x0124;
    public final static int CMD_QTE_CHARGE_COMMODITY_DATA_RSP = 0x0125;

    /////////////////////////////////////合约信息查询////////////////////////////////
    public final static int CMD_QTE_CONTRACT_REQ = 0x0130;
    public final static int CMD_QTE_CONTRACT_RSP = 0x0131;
    public final static int CMD_QTE_CONTRACT_DATA_RSP = 0x0132;

    //////////////////////////////////////合约名称查询//////////////////////////////
    public final static int CMD_QTE_CONT_NAME_REQ = 0x0133;
    public final static int CMD_QTE_CONT_NAME_RSP = 0x0134;
    public final static int CMD_QTE_CONT_NAME_DATA_RSP = 0x0135;

    /////////////////////////////////////虚拟合约与真实合约关系查询/////////////////
    public final static int CMD_QTE_CONT_UNDERLY_REQ = 0x0150;
    public final static int CMD_QTE_CONT_UNDERLY_RSP = 0x0151;
    public final static int CMD_QTE_CONT_UNDERLY_DATA_RSP = 0x0152;
    public final static int CMD_QTE_CONT_UNDERLY_NOTICE = 0x0153;

    ////////////////////////////////////个股期货合约信息//////////////////////////////
    public final static int CMD_QTE_STOCK_CONT_REQ = 0x0170;
    public final static int CMD_QTE_STOCK_CONT_RSP = 0x0171;
    public final static int CMD_QTE_STOCK_CONT_DATA_RSP = 0x0172;

    /////////////////////////////////////期权序列到期日查询////////////////////////////////
    public final static int CMD_QTE_OPTION_EXPIRE_REQ = 0x0140;
    public final static int CMD_QTE_OPTION_EXPIRE_RSP = 0x0141;
    public final static int CMD_QTE_OPTION_EXPIRE_DATA_RSP = 0x0142;

    //////////////////////////////////////时间模板查询/////////////////////////////////
    public final static int CMD_QTE_TIME_BUCKET_REQ = 0x0B00;
    public final static int CMD_QTE_TIME_BUCKET_RSP = 0x0B01;
    public final static int CMD_QTE_TIME_BUCKET_DATA_RSP = 0x0B02;

    /////////////////////////////////////品种时间模板关系查询/////////////////////////
    public final static int CMD_QTE_COMM_TIME_BUCKET_REQ = 0x0B06;
    public final static int CMD_QTE_COMM_TIME_BUCKET_RSP = 0x0B07;
    public final static int CMD_QTE_COMM_TIME_BUCKET_DATA_RSP = 0x0B08;

    /////////////////////////////////////用于修补大商所将夜盘闭市时间缩短后分时图显示不正确的bug///////////////////////////////
    public final static int CMD_QTE_HIS_COMMODITY_TEMPLATE_REQ = 0x0B50;
    public final static int CMD_QTE_HIS_COMMODITY_TEMPLATE_RSP = 0x0B51;
    public final static int CMD_QTE_HIS_COMMODITY_TEMPLATE_DATA_RSP = 0x0B52;

    /////////////////////////////////////K线查询///////////////////////////////////
    public final static int CMD_QTE_KLINE_REQ = 0x0B10;
    public final static int CMD_QTE_KLINE_RSP = 0x0B11;
    public final static int CMD_QTE_KLINE_DATA_RSP = 0x0B12;
    public final static int CMD_QTE_KLINE_DATA_NOTICE = 0x0B13;

    //行情订阅请求,普通行情和深度行情都推送
    public final static int CMD_QTE_SNAPSHOT_SUB = 0x0A00;
    //普通行情退订请求
    public final static int CMD_QTE_SNAPSHOTUN_SUB = 0x0A01;
    //普通行情订阅数据
    public final static int CMD_QTE_SNAPSHOTLV1_RSP = 0x0A02;
    //普通行情推送消息
    public final static int CMD_QTE_SNAPSHOTLV1_NOTICE = 0x0A03;
    //深度行情订阅数据
    public final static int CMD_QTE_SNAPSHOTLV2_RSP = 0x0A04;
    //深度行情推送消息
    public final static int CMD_QTE_SNAPSHOTLV2_NOTICE = 0x0A05;
    //品种或合约状态变化通知
    public final static int CMD_QTE_STATS_NOTICE = 0x0A06;

    public final static char QTE_USERRIGHT_GROUP = 'G';  //品种组
    public final static char QTE_USERRIGHT_PLUGIN = 'P';  //插件
}