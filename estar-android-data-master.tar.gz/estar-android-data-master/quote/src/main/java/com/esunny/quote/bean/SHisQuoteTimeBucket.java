package com.esunny.quote.bean;

import com.esunny.data.bean.HisQuoteTimeBucket;

/**
 * @author huang
 */
public class SHisQuoteTimeBucket {
    private int Index;
    private long BeginTime;
    private long EndTime;
    private char TradeState;
    private char DateFlag;
    private int CalCount;

    public int getIndex() {
        return Index;
    }

    public void setIndex(int index) {
        Index = index;
    }

    public long getBeginTime() {
        return BeginTime;
    }

    public void setBeginTime(long beginTime) {
        BeginTime = beginTime;
    }

    public long getEndTime() {
        return EndTime;
    }

    public void setEndTime(long endTime) {
        EndTime = endTime;
    }

    public char getTradeState() {
        return TradeState;
    }

    public void setTradeState(char tradeState) {
        TradeState = tradeState;
    }

    public char getDateFlag() {
        return DateFlag;
    }

    public void setDateFlag(char dateFlag) {
        DateFlag = dateFlag;
    }

    public int getCalCount() {
        return CalCount;
    }

    public void setCalCount(int calCount) {
        CalCount = calCount;
    }

    public HisQuoteTimeBucket toHisQuoteTimeBucket() {
        HisQuoteTimeBucket timeBucket = new HisQuoteTimeBucket();
        timeBucket.setIndex((short) Index);
        timeBucket.setBeginTime(BeginTime);
        timeBucket.setCalCount((short) CalCount);
        timeBucket.setDateFlag(DateFlag);
        timeBucket.setEndTime(EndTime);
        timeBucket.setTradeState(TradeState);
        return timeBucket;
    }
}
