package com.esunny.quote;

import android.content.Context;
import android.text.TextUtils;
import android.util.SparseArray;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.api.server.RoutingTable;
import com.esunny.data.api.server.EsQuoteApi;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.HisQuoteData;
import com.esunny.data.bean.HisQuoteTimeBucket;
import com.esunny.data.bean.KLinePeriod;
import com.esunny.data.bean.OptionContractPair;
import com.esunny.data.bean.OptionSeries;
import com.esunny.data.bean.Plate;
import com.esunny.data.bean.QuoteField;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.bean.SImpliedDepthL2;
import com.esunny.data.bean.SQuoteField;
import com.esunny.data.bean.SQuoteFieldL2;
import com.esunny.data.bean.SQuoteSnapShot;
import com.esunny.data.bean.SQuoteSnapShotL2;
import com.esunny.data.util.EsCommonUtil;
import com.esunny.mobile.EsApiData;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.UnixJNI;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.mobile.bean.rsp.PkgPlateCodeRsp;
import com.esunny.quote.bean.QteKLineData;
import com.esunny.quote.bean.QteKLineReq;
import com.esunny.quote.bean.QteSnapShotReq;
import com.esunny.quote.bean.RegUserCommGroupQryRsp;
import com.esunny.quote.bean.RegUserPluginQryRsp;
import com.esunny.quote.bean.SChargeInfo;
import com.esunny.quote.bean.SContract;
import com.esunny.quote.bean.SHisMinTimeBucket;
import com.esunny.quote.bean.SHisQuoteDef;
import com.esunny.quote.bean.SHisQuoteTimeBucket;
import com.esunny.data.bean.SQuoteUserInfo;
import com.esunny.quote.bean.STimeBucketDef;
import com.esunny.quote.codetable.CodeTable;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import static com.esunny.data.api.EsDataConstant.TIME_TYPE_YEAR_MONTH_DATA;

@Route(path = RoutingTable.ES_QUOTE_API)
public class EsQuoteApiImp implements EsQuoteApi {
    private Context mContext;

    @Override
    public void init(Context context) {
        mContext = context;
    }

    @Override
    public void setQuoteClientKey(int key) {
        EsQuoteData.getInstance().setQuoteKey(key);
    }

    @Override
    public void setQuoteAddress(AddrInfo address) {
        EsQuoteData.getInstance().setQuoteAddress(address);
    }

    @Override
    public void setHisQuoteAddress(AddrInfo addrInfo) {
        EsQuoteData.getInstance().setHisQuoteAddress(addrInfo);
    }

    @Override
    public void setHisQuoteClientKey(int key) {
        EsQuoteData.getInstance().setHisQuoteKey(key);
    }

    @Override
    public CallbackDispatcher getDispatcher() {
        return new EsQuoteDispatcher();
    }

    @Override
    public Map<String, Commodity> getCommodityMap() {
        return EsQuoteData.getInstance().getCommodityMap();
    }

    @Override
    public Map<String, Contract> getContractMap() {
        return EsQuoteData.getInstance().getContractMap();
    }

    @Override
    public List<Commodity> getCommodityOfPlate(Plate plate) {
        List<Commodity> res = new ArrayList<>();
        if (plate == null) {
            return res;
        }

        List<PkgPlateCodeRsp> plateCodeRspList = EsApiData.getInstance().getPlateCodeRspList();
        for (PkgPlateCodeRsp pkgPlateCodeRsp : plateCodeRspList) {
            if (!plate.getPlateNo().equals(pkgPlateCodeRsp.getPlateNo())) {
                continue;
            }
            Commodity  commodity = getCommodityByPlateCode(pkgPlateCodeRsp);
            if (commodity != null && !res.contains(commodity)) {
                res.add(commodity);
            }
        }

        return res;
    }

    /**
     * 获取所有期权品种
     *
     * @return 品种列表
     */
    @Override
    public List<Commodity> getOptionCommodity() {
        return new ArrayList<>(CodeTable.getInstance().getOptionCommodityList());
    }

    /**
     * 获取期权品种的所有期权合约
     *
     * @param commodity 品种
     * @return 期权合约列表
     */
    @Override
    public List<OptionSeries> getOptionSeriesOfCommodity(Commodity commodity) {
        List<OptionSeries> res = new ArrayList<>();
        if (commodity == null) {
            return res;
        }
        String commodityNo = commodity.getCommodityNo();
        if (commodityNo == null) {
            return res;
        }

        res = CodeTable.getInstance().getOptionSeriesOfCommodity(commodityNo);
        return res;
    }

    @Override
    public List<OptionContractPair> getOptionContractPair(OptionSeries series) {
        List<OptionContractPair> res = new ArrayList<>();
        if (series == null) {
            return res;
        }
        if (TextUtils.isEmpty(series.getSeriesNo())) {
            return res;
        }

        res = CodeTable.getInstance().getOptionContractPairOfSeriesNo(series.getSeriesNo());
        return res;
    }

    @Override
    public Commodity getCommodityData(String companyNo, String userNo, String addrNo, String commodityNo) {
        return CodeTable.getInstance().getCommodity(commodityNo);
    }

    @Override
    public Commodity getCommodity(String commodityNo) {
        return CodeTable.getInstance().getCommodity(commodityNo);
    }

    @Override
    public boolean checkChargeCommodity(Contract contract) {
        return false;
    }

    @Override
    public int qryContractSort(char type, String[] contractNoList) {
        return 0;
    }

    @Override
    public Contract getContract(String contractNo) {
        return CodeTable.getInstance().getContract(contractNo, false);
    }

    @Override
    public Contract getQuoteContract(String contractNo) {
        if (contractNo == null) {
            return null;
        }

        Contract contract = getContract(contractNo);
        if (contract != null &&
                contract.isArbitrageContract() && !contractNo.startsWith("SPD|")) {
            contractNo = switchArbitrageContractNo(contract);
            contract = getContract(contractNo);
        }

        return contract;
    }

    private String switchArbitrageContractNo(Contract contract) {
        if (contract != null) {
            String contractNo = contract.getContractNo();
            if (contract.isArbitrageContract()) {
                String[] arr = contractNo.split("\\|");
                int len = arr.length;
                if (len > 2) {
                    String targetCommodity1Str = contract.getCommodity().getTargetCommodity1();
                    String targetCommodity2Str = contract.getCommodity().getTargetCommodity2();
                    Commodity targetCommodity1 = EsQuoteData.getInstance().getCommodityMap().get(targetCommodity1Str);
                    Commodity targetCommodity2 = EsQuoteData.getInstance().getCommodityMap().get(targetCommodity2Str);

                    if (contractNo.startsWith("SPD|")) {
                        String commodityNo = targetCommodity1.getCommodityNo();
                        String[] arrNo = commodityNo.split("\\|");
                        if (targetCommodity2 == null) {
                            return String.format("%s|S|%s|%s|%s", arrNo[0], arr[len - 3], arr[len - 2], arr[len - 1]);
                        } else {
                            return String.format("%s|M|%s|%s", arrNo[0], arr[2].replace("-", "&"), arr[len - 1]);
                        }
                    } else {
                        String str = String.format("%s|%s", "SPD", arr[1].toLowerCase());
                        if (targetCommodity2 == null) {
                            return String.format("%s|%s|%s|%s", str, arr[len - 3], arr[len - 2], arr[len - 1]);
                        } else {
                            return String.format("%s|%s|%s|%s", str, arr[2].replace("&", "-"), arr[len - 1], arr[len - 1]);
                        }
                    }
                }
            }
            return contractNo;
        }
        return "";
    }

    @Override
    public Contract getTradeContract(String contractNo) {
        if (contractNo == null) {
            return null;
        }

        if (isLMEMonth(contractNo)) {
            String[] aar = contractNo.split("\\|");
            if (aar.length > 0) {
                contractNo = contractNo.replace(aar[aar.length - 1], "3M");
            }
        }

        Contract contract = getRealContract(contractNo);
        if (contract == null) {
            contract = getContract(contractNo);
        }

        if (contract == null) {
            return null;
        }

        if (contract.isArbitrageContract() && contractNo.startsWith("SPD|")) {
            contractNo = switchArbitrageContractNo(contract);
            contract = getContract(contractNo);
        }

        return contract;
    }

    private boolean isLMEMonth(String contractNo) {
        if (contractNo != null) {
            if (contractNo.startsWith("LME")) {
                return !contractNo.endsWith("3M");
            }
        }
        return false;
    }

    @Override
    public Contract getRealContract(String contractNo) {
        return CodeTable.getInstance().getContract(contractNo, true);
    }

    @Override
    public int getQuoteCodeUpdate() {
        return CodeTable.getInstance().getUpdateCode();
    }

    @Override
    public void mannualUpdate() {

    }

    @Override
    public void initCodeTable(Context mContext) {
        CodeTable.getInstance().init(mContext);
    }

    @Override
    public List<HisQuoteTimeBucket> getBaseTimeBucketData(String commodityNo, long date) {
        ArrayList<HisQuoteTimeBucket> hisBuckets = new ArrayList<>();
        STimeBucketDef timeBucketDef = null;
        Map<String, SHisMinTimeBucket> hisMinTimeBucketDataMap = EsQuoteData.getInstance().getHisMinTimeBucketDataMap();
        Map<String, STimeBucketDef> timeBucketDefDataMap = EsQuoteData.getInstance().getTimeBucketDefDataMap();
        Map<String, STimeBucketDef> commTimeBucketDataMap = EsQuoteData.getInstance().getCommTimeBucketDataMap();
        if (date > 0) {
            if (hisMinTimeBucketDataMap.containsKey(commodityNo)) {
                SHisMinTimeBucket sHisMinTimeBucket = hisMinTimeBucketDataMap.get(commodityNo);
                if (sHisMinTimeBucket != null && sHisMinTimeBucket.getBeginDate() <= date && date <= sHisMinTimeBucket.getEndDate()) {
                    String templateNo = sHisMinTimeBucket.getTemplateNo();
                    if (timeBucketDefDataMap.containsKey(templateNo)) {
                        timeBucketDef = timeBucketDefDataMap.get(templateNo);
                    }
                }
            }
        }
        if (commTimeBucketDataMap.containsKey(commodityNo) && timeBucketDef == null) {
            timeBucketDef = commTimeBucketDataMap.get(commodityNo);
        }
        if (timeBucketDef != null) {
            int baseCount = timeBucketDef.getBaseCount();
            for (int i = 0; i < baseCount; i++) {
                SHisQuoteTimeBucket bucket = timeBucketDef.getBaseTbs().get(i);
                hisBuckets.add(bucket.toHisQuoteTimeBucket());
            }
        }
        return hisBuckets;
    }

    @Override
    public List<HisQuoteTimeBucket> getCalTimeBucketData(String commodityNo, long date) {
        ArrayList<HisQuoteTimeBucket> hisBuckets = new ArrayList<>();
        STimeBucketDef timeBucketDef = null;
        Map<String, SHisMinTimeBucket> hisMinTimeBucketDataMap = EsQuoteData.getInstance().getHisMinTimeBucketDataMap();
        Map<String, STimeBucketDef> timeBucketDefDataMap = EsQuoteData.getInstance().getTimeBucketDefDataMap();
        Map<String, STimeBucketDef> commTimeBucketDataMap = EsQuoteData.getInstance().getCommTimeBucketDataMap();
        if (date > 0) {
            if (hisMinTimeBucketDataMap.containsKey(commodityNo)) {
                SHisMinTimeBucket sHisMinTimeBucket = hisMinTimeBucketDataMap.get(commodityNo);
                if (sHisMinTimeBucket != null && sHisMinTimeBucket.getBeginDate() <= date && date <= sHisMinTimeBucket.getEndDate()) {
                    String templateNo = sHisMinTimeBucket.getTemplateNo();
                    if (timeBucketDefDataMap.containsKey(templateNo)) {
                        timeBucketDef = timeBucketDefDataMap.get(templateNo);
                    }
                }
            }
        }
        if (commTimeBucketDataMap.containsKey(commodityNo) && timeBucketDef == null) {
            timeBucketDef = commTimeBucketDataMap.get(commodityNo);
        }
        if (timeBucketDef != null) {
            int calCount = timeBucketDef.getCalCount();
            for (int i = 0; i < calCount; i++) {
                SHisQuoteTimeBucket bucket = timeBucketDef.getCalTbs().get(i);
                hisBuckets.add(bucket.toHisQuoteTimeBucket());
            }
        }
        return hisBuckets;
    }

    @Override
    public QuoteField[][] getQuoteField(Contract contract) {
        if (contract == null) {
            return null;
        }
        SImpliedDepthL2 implied = new SImpliedDepthL2();

        SQuoteSnapShotL2 bid = new SQuoteSnapShotL2();
        SQuoteSnapShotL2 ask = new SQuoteSnapShotL2();

        int result = getDepthImpliedSnapshot(contract.getContractNo(), bid, ask, implied);

        if (result != 1) {
            bid = getSnapShotL2Bid(contract.getContractNo());
            ask = getSnapShotL2Ask(contract.getContractNo());
        }

        SparseArray<SQuoteFieldL2> buyData = bid.getData();
        SparseArray<SQuoteFieldL2> sellData = ask.getData();

        QuoteField[] buyDataArr = new QuoteField[EsNativeProtocol.MAX_L2_DEPTH];
        QuoteField[] sellDataArr = new QuoteField[EsNativeProtocol.MAX_L2_DEPTH];

        for (int i = 0; i < EsNativeProtocol.MAX_L2_DEPTH; i++) {
            SQuoteFieldL2 bd = buyData.get(i);
            QuoteField bdNew = null;
            if (bd != null) {
                bdNew = bd.toQuoteField();
                if (i + 1 == implied.getBidPriceDepth()) {
                    bdNew.setImpliedPrice(true);
                }
                if (i + 1 == implied.getBidQtyDepth()) {
                    bdNew.setImpliedQty(true);
                }
            }
            buyDataArr[i] = bdNew;

            SQuoteFieldL2 sd = sellData.get(i);
            QuoteField sdNew = null;
            if (sd != null) {
                sdNew = sd.toQuoteField();
                if (i + 1 == implied.getAskPriceDepth()) {
                    sdNew.setImpliedPrice(true);
                }
                if (i + 1 == implied.getAskQtyDepth()) {
                    sdNew.setImpliedQty(true);
                }
            }

            sellDataArr[i] = sdNew;
        }

        return new QuoteField[][]{buyDataArr, sellDataArr};
    }

    @Override
    public List<HisQuoteData> getMinData(Contract contract) {
        ArrayList<HisQuoteData> arrayList = new ArrayList<>();
        SparseArray<HisQuoteData> dataSparseArray = new SparseArray<>();
        //比较当前交易日，取出数据
        boolean validity = false;
        double totalPrice = 0;
        double sumOfVolume = 0;
        if (contract != null) {
            String contractNo = contract.getContractNo();
            long tradeDate = 0;

            Map<String, SHisQuoteDef> hisQuoteDefMap = EsQuoteData.getInstance().getSHisQuoteDefMap();
            Map<String, STimeBucketDef> commTimeBucketDataMap = EsQuoteData.getInstance().getCommTimeBucketDataMap();
            STimeBucketDef timeBucketDef = commTimeBucketDataMap.get(contract.getCommodity().getCommodityNo());
            SHisQuoteDef hisQuoteDef = hisQuoteDefMap.get(contractNo);
            List<QteKLineData> mOrderLines = hisQuoteDef.getMOrderLines();
            if (!mOrderLines.isEmpty()) {
                tradeDate = mOrderLines.get(0).getTradeDate();
            }
            List<SHisQuoteTimeBucket> timeBuckets = timeBucketDef.getCalTbs();

            long lastEndTime = -1;
            BigInteger timeStamp = null;
            String date = tradeDate + "";
            HisQuoteData preHisQuoteData = new HisQuoteData();
            for (int i = 0; i < mOrderLines.size(); i++) {
                QteKLineData lineData = mOrderLines.get(i);
                HisQuoteData hisQuoteData = lineData.toHisQuoteData();
                if (hisQuoteData != null && tradeDate == hisQuoteData.getTradeDate()) {
                    timeStamp = new BigInteger(hisQuoteData.getDateTimeStamp());
                    long endTime = timeStamp.longValue() % 1000000000L;
                    dataSparseArray.put((int) endTime, hisQuoteData);
                    if (lastEndTime < 0) {
                        lastEndTime = endTime;
                    }
                }
            }
            for (SHisQuoteTimeBucket item : timeBuckets) {
                long calTime = item.getEndTime();
                HisQuoteData hisQuoteData = dataSparseArray.get((int) calTime);
                if (hisQuoteData != null) {
                    validity = true;
                    timeStamp = new BigInteger(hisQuoteData.getDateTimeStamp());
                    date = EsDataApi.formatTime(timeStamp.toString(), TIME_TYPE_YEAR_MONTH_DATA);
                } else {
                    hisQuoteData = preHisQuoteData.clone();

                    if (timeStamp != null && item.getTradeState() == EsQuoteConstant.S_TRADESTATE_CONTINUOUS) {
                        date = EsDataApi.formatTime(timeStamp.toString(), TIME_TYPE_YEAR_MONTH_DATA);
                    }

                    BigInteger dateTimeStamp = new BigInteger(date +
                            String.format(Locale.getDefault(), "%0" + 9 + "d", calTime));
                    //标准17位，20101010010100000
                    hisQuoteData.setDateTimeStamp(dateTimeStamp);
                    hisQuoteData.setVolume(BigInteger.ZERO);
                }
                hisQuoteData.setPreKlineEntity(preHisQuoteData);
                hisQuoteData.setValidity(validity);

                //计算均价：
                if (hisQuoteData.getVolume().doubleValue() != 0) {
                    totalPrice += hisQuoteData.getClosePrice() * hisQuoteData.getVolume().doubleValue();
                    sumOfVolume += hisQuoteData.getVolume().doubleValue();
                }
                hisQuoteData.setAvgPrice(totalPrice / sumOfVolume);
                preHisQuoteData = hisQuoteData;
                arrayList.add(hisQuoteData);

                if (lastEndTime == calTime) {
                    break;
                }
            }
        }
        return arrayList;
    }

    @Override
    public List<HisQuoteData> getKLineData(Contract contract, KLinePeriod period, int endIndex, int len) {
        long index = 0;
        ArrayList<HisQuoteData> arrayList = new ArrayList<>();
        if (contract == null || period == null || len < 1) {
            return null;
        }
        //由于KLineEntity需要上一个数据
        //因此，多获取一个数据
        int size = len + 1;
        String tradeDate = "";
        String contractNo = contract.getContractNo();
        char kLineType = period.getKLineType();
        int slice = period.getKLineSlice();
        Map<String, SHisQuoteDef> hisQuoteDefMap = EsQuoteData.getInstance().getSHisQuoteDefMap();
        SHisQuoteDef hisQuoteDef = hisQuoteDefMap.get(contractNo);


        if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_MINUTE) {
            if (slice < 1) {
                slice = 1;
            }
            List<QteKLineData> mOrderLines = hisQuoteDef.getMOrderLines();
            for (int i = 0; i < mOrderLines.size(); i++) {
                QteKLineData lineData = mOrderLines.get(i);
                HisQuoteData quoteData = new HisQuoteData();
                if (!arrayList.isEmpty()) {
                    quoteData = arrayList.get(0);
                }
                HisQuoteData data = null;
                if (slice == 1) {
                    data = lineData.toHisQuoteData();
                } else {
                    //其余分钟线处理
                    if (index != 0 && index == lineData.getKLineIndex() / slice + lineData.getTradeDate()) {
                        //合并
                        BigInteger kLineQty = lineData.getKLineQty();
                        BigInteger volume = quoteData.getVolume();
                        quoteData.setVolume(kLineQty.add(volume));
                        quoteData.setOpenPrice(lineData.getOpeningPrice());
                        if (lineData.getHighPrice() > quoteData.getHighPrice()) {
                            quoteData.setHighPrice(lineData.getHighPrice());
                        }
                        if (lineData.getLowPrice() < quoteData.getLowPrice()) {
                            quoteData.setLowPrice(lineData.getLowPrice());
                        }
                    } else {
                        //新增
                        index = lineData.getKLineIndex() / slice + lineData.getTradeDate();
                        data = lineData.toHisQuoteData();
                    }
                }
                if (data != null) {
                    arrayList.add(0, data);
                }
            }
        } else if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_DAY) {
            if (slice > 30 && slice != 255) {
                slice = 30;
            } else if (slice < 1) {
                slice = 1;
            }
            List<QteKLineData> dOrderLines = hisQuoteDef.getDOrderLines();
            for (int i = 0; i < dOrderLines.size(); i++) {
                QteKLineData lineData = dOrderLines.get(i);
                HisQuoteData quoteData = new HisQuoteData();
                if (!arrayList.isEmpty()) {
                    quoteData = arrayList.get(0);
                }

                HisQuoteData data = null;
                if (slice == 1) {
                    data = lineData.toHisQuoteData();
                } else if (slice == 7) {
                    tradeDate = String.valueOf(lineData.getTradeDate());
                    int weekIndex = EsCommonUtil.getWeekIndex(tradeDate);
                    long key = weekIndex + lineData.getTradeDate() / 10000 * 10000;
                    data = dealSliceKLineData(lineData, quoteData, key);
                } else if (slice == 30) {
                    long key = lineData.getTradeDate() / 100 * 100;
                    data = dealSliceKLineData(lineData, quoteData, key);
                } else if (slice == 255) {
                    long key = lineData.getTradeDate() / 10000 * 10000;
                    data = dealSliceKLineData(lineData, quoteData, key);
                } else {
                    //其余日线处理
                    tradeDate = String.valueOf(lineData.getTradeDate());
                    int dayIndex = EsCommonUtil.getDayIndex(tradeDate);
                    long key = dayIndex / slice + lineData.getTradeDate() / 10000 * 10000;
                    data = dealSliceKLineData(lineData, quoteData, key);
                }
                if (data != null) {
                    arrayList.add(0, data);
                }
            }

        } else if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_TICK) {

        } else {
            return arrayList;
        }

        int usedIndex = arrayList.size() - endIndex;
        detectionCacheKLineData(contractNo, kLineType, slice, size, usedIndex);
        return arrayList.subList(Math.max(usedIndex - len, 0), usedIndex);
    }

    @Override
    public String getContractName(String contractNo) {
        if (contractNo == null) {
            return null;
        }
        String res;

        Contract contract = getContract(contractNo);

        if (contract != null) {
            res = CodeTable.getInstance().getContractName(contractNo, contract.getCommodity());
        } else {
            Map<String, Commodity> commodityMap = EsQuoteData.getInstance().getCommodityMap();

            if (contractNo.contains("|")) {
                String name = contractNo.substring(0, contractNo.lastIndexOf("|"));
                String no = contractNo.substring(contractNo.lastIndexOf("|") + 1);
                Commodity commodity = commodityMap.get(name);
                if (commodity != null) {
                    res = commodity.getCommodityName() + no;
                } else {
                    res = contractNo;
                }
            } else {
                res = contractNo;
            }
        }
        return res;
    }

    @Override
    public AddrInfo getAddrInfo(char system, String companyNo, String userNo, String addrNo) {
        if (system == EsNativeProtocol.S_SRVSRC_QUOTE) {
            return EsQuoteData.getInstance().getQuoteAddress();
        } else {
            return EsQuoteData.getInstance().getHisQuoteAddress();
        }
    }

    @Override
    public int quoteLogin(String userNo, String password) {
        if (userNo == null || password == null) {
            return 1;
        }

        if (userNo.isEmpty()) {
            return 2;
        }

        SQuoteUserInfo quoteUserInfo = EsApiData.getInstance().getQuoteUserInfo();

        //同名认证成功 返回-1
        if (userNo.equals(quoteUserInfo.getLoginNo()) && password.equals(quoteUserInfo.getPackageNo()) && quoteUserInfo.getbCertSuccessed()) {
            return -1;
        }

        quoteUserInfo.setLoginNo(userNo);
        quoteUserInfo.setPassWord(password);

        //TODO NewsUtil中 各个登录状态补充完LoginState这里要恢复
//        if (EsApiData.getInstance().getLoginState() == 0) {
//            return 0;
//        }

        quoteUserInfo.setErrorCode(0);
        quoteUserInfo.setbCertSuccessed(false);
        quoteUserInfo.setErrorText(null);

        // 通过断线重连去重新登录行情
        if (UnixJNI.S_IsOpenTcp(EsQuoteData.getInstance().getQuoteKey())) {
            quoteUserInfo.setbReLoginClose(true);
            UnixJNI.S_Close(EsQuoteData.getInstance().getQuoteKey());
        }
        return 0;
    }

    @Override
    public int quoteLogout() {
        SQuoteUserInfo quoteUserInfo = EsApiData.getInstance().getQuoteUserInfo();
        //认证登出
        quoteUserInfo.setbCertSuccessed(false);
        Map<String, RegUserCommGroupQryRsp> userCommonGroup = EsQuoteData.getInstance().getUserCommGroupMap();
        userCommonGroup.clear();
        ResetChargeInfoHash(0);//重置收费品种
        Map<String, SChargeInfo> chargeCommodityMap = EsQuoteData.getInstance().getChargeCommodityMap();
        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();
        Map<String, SContract> sContractSnapData = EsQuoteData.getInstance().getSContractSnapData();
        for (Map.Entry<String, Contract>  entry : contractMap.entrySet()) {
            Contract contract = entry.getValue();
            if (contract == null || contract.getCommodity() == null) {
                continue;
            }
            SContract sContract = sContractSnapData.get(contract.getContractNo());
            if (chargeCommodityMap.containsKey(contract.getCommodity().getCommodityNo()) && sContract != null && sContract.getSnapShot() != null) {
                sContract.setSnapShot(null);
                sContract.setAskL2(null);
                sContract.setBidL2(null);
            }
        }

        //登出价格预警
        LogoutMonitor();

        return 0;
    }

    @Override
    public QuoteLoginInfo quoteLoginInfo() {
        QuoteLoginInfo quoteLoginInfo = new QuoteLoginInfo();

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        quoteLoginInfo.setLoginNo(userInfo.getLoginNo());
        quoteLoginInfo.setPassWord(userInfo.getPassWord());
        quoteLoginInfo.setErrorCode(userInfo.getErrorCode());
        quoteLoginInfo.setErrorText(userInfo.getErrorText());

        return quoteLoginInfo;
    }

    @Override
    public boolean isQuoteLogin() {
        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        if (userInfo.getErrorCode() == 0 && userInfo.getbCertSuccessed() && !TextUtils.isEmpty(userInfo.getLoginNo())) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int unSubAllQuote() {
        Map<String, Integer> quoteSubMap = EsQuoteData.getInstance().getQuoteSub();
        for (String contractNo : quoteSubMap.keySet()) {
//            unSubQuote(contractNo);
            if (contractNo == null) {
                continue;
            }
            QuoteSend(contractNo, false);
        }
        quoteSubMap.clear();
        return 0;
    }

    @Override
    public boolean isCoverTContract(Commodity commodity) {
        if (commodity == null) {
            return false;
        }
        return commodity.getCoverMode() == EsDataConstant.S_COVER_TODAY;
    }

    @Override
    public boolean hasExchangePermission(String exchangeNo) {
        List<String> exchangeList = EsQuoteData.getInstance().getChargeExchageList();

        return exchangeList.contains(exchangeNo);
    }

    @Override
    public boolean hasContractPermission(Contract contract) {
        if (contract == null || contract.getCommodity() == null) {
            return false;
        }

        Map<String, SContract> sContractMap = EsQuoteData.getInstance().getSContractSnapData();
        Map<String, SChargeInfo> chargeInfoMap = EsQuoteData.getInstance().getChargeCommodityMap();
        boolean isContainsCommodity = false;
        for (String key : chargeInfoMap.keySet()) {
            SChargeInfo sChargeInfo = chargeInfoMap.get(key);
            if (contract.getCommodity().getCommodityNo().equals(sChargeInfo.getCommodityNo())) {
                isContainsCommodity = true;
            }
        }
        return !isContainsCommodity || (sContractMap.containsKey(contract.getContractNo()) && sContractMap.get(contract.getContractNo()).getSnapShot() != null);
    }

    @Override
    public boolean isMainContract(String contractNo) {
        if (contractNo.contains("MAIN")) {
            return true;
        } else {
            Contract contract = EsDataApi.getRealContract(getMainContractNo(contractNo));
            if (contract != null && Objects.equals(contract.getContractNo(), contractNo)) {
                return true;
            } else {
                return false;
            }
        }
    }

    @Override
    public String getMainContractNo(String realContractNo){
        if (realContractNo.contains("MAIN")){
            return realContractNo;
        }
        String[] arrayStr = realContractNo.split("\\|");
        StringBuilder builder = new StringBuilder();
        builder.append(arrayStr[0]).append("|Z|");
        for (int i = 2; i < arrayStr.length-1; i++){
            builder.append(arrayStr[i]).append("|");
        }
        builder.append("MAIN");
        return builder.toString();
    }

    @Override
    public boolean hasTCPermission() {
        Map<String, RegUserPluginQryRsp> userPluginMap = EsQuoteData.getInstance().getUserPluginMap();
        return userPluginMap.containsKey("TradeCenterKLine");
    }

    @Override
    public String optionToTarget(String contractNo) {
        String price;
        String target;
        String[] strArray = contractNo.split("\\|");
        if (strArray[strArray.length - 1].contains("C")) {
            price = contractNo.split("C")[contractNo.split("C").length - 1];
            target = contractNo.replace("C" + price, "").replace("|O|", "|F|");
        } else {
            price = contractNo.split("P")[contractNo.split("P").length - 1];
            target = contractNo.replace("P" + price, "").replace("|O|", "|F|");
        }
        return target;
    }

    private String[] plusOneExchangeNos = {"HKEX"};
    @Override
    public boolean isPlusOneExchange(String exChangeNo) {
        for (String unAvailableMarketPriceExchangeNo : plusOneExchangeNos) {
            if (unAvailableMarketPriceExchangeNo.equals(exChangeNo.trim())) {
                return true;
            }
        }
        return false;
    }

    private void LogoutMonitor() {

    }

    void ResetChargeInfoHash(int size) {
        Map<String, SChargeInfo> chargeCommodityMap = EsQuoteData.getInstance().getChargeCommodityMap();
        Map<String, RegUserCommGroupQryRsp> userCommonGroupMap = EsQuoteData.getInstance().getUserCommGroupMap();
        if (chargeCommodityMap.size() == 0) {
            return;
        }
        List<String> chargeExchangeList = EsQuoteData.getInstance().getChargeExchageList();
        chargeExchangeList.clear();

        for (String key : chargeCommodityMap.keySet()) {
            SChargeInfo info = chargeCommodityMap.get(key);
            if (size == 0) {
                info.setIsPay(false);
            } else {
                boolean isExit = userCommonGroupMap.containsKey(info.getGroupNo());
                info.setIsPay(isExit);
            }

            if (!info.getIsPay() && !chargeExchangeList.contains(info.getExchangeNo())) {
                chargeExchangeList.add(info.getExchangeNo());
            }
        }
    }

    @Override
    public List<Contract> getContractOfPlate(Plate plate) {
        List<Contract> res = new ArrayList<>();
        if (plate == null) {
            return res;
        }

        List<PkgPlateCodeRsp> pkgPlateCodeRspSet = EsApiData.getInstance().getPlateCodeRspList();

        final List<String> commodityIdList = new ArrayList<>();
        for (PkgPlateCodeRsp pkgPlateCodeRsp : pkgPlateCodeRspSet) {
            if (!plate.getPlateNo().equals(pkgPlateCodeRsp.getPlateNo())) {
                continue;
            }

            char attr = pkgPlateCodeRsp.getPlateCodeAttr();
            String plateCode = pkgPlateCodeRsp.getPlateCode();
            if (attr == EsNativeProtocol.S_PCODE_COMMODITY) {
                commodityIdList.add(plateCode);
//                res.addAll(contractListMap.get(plateCode));
            } else if (attr == EsNativeProtocol.S_PCODE_VIRTUAL_CONTRACT && getRealContract(plateCode) != null) {
                res.add(getRealContract(plateCode));
            } else if (attr == EsNativeProtocol.S_PCODE_REAL_CONTRACT && getContract(plateCode) != null) {
//                Contract contract = contractMap.get(plateCode);
                Contract contract = getContract(plateCode);
                if (contract != null) {
                    if (contract.getContractNo().startsWith("LME") && (contract.getContractNo().endsWith("|3M") || contract.getContractNo().endsWith("|C"))) {
                        res.add(contract);
                    } else {
                        commodityIdList.add(plateCode);
//                        res.addAll(contractListMap.get(plateCode));
                    }
                }
            }
        }

        if (commodityIdList.size() > 0) {
            List<Contract> temp = CodeTable.getInstance().getContractListByCommodity(plate.getPlateNo(), commodityIdList);
            Collections.sort(temp, new Comparator<Contract>() {
                @Override
                public int compare(Contract o1, Contract o2) {
                    if (o1.getCommodity() == null || o2.getCommodity() == null) {
                        return 0;
                    }
                    int commodityIndex = commodityIdList.indexOf(o1.getCommodity().getCommodityNo()) - commodityIdList.indexOf(o2.getCommodity().getCommodityNo());
                    if (commodityIndex == 0) {
                        return o1.getContractNo().compareTo(o2.getContractNo());
                    } else {
                        return commodityIndex;
                    }
                }
            });
            res.addAll(temp);
        }

        return res;
    }

    @Override
    public int subQuote(String contractNo) {
        if (contractNo == null) {
            return -1;
        }

        Map<String, Integer> quoteSub = EsQuoteData.getInstance().getQuoteSub();
        Integer count = quoteSub.get(contractNo);

        if (count == null) {
            count = 0;
        }

        count++;
        quoteSub.put(contractNo, count);

        if (count == 1) {
            QuoteSend(contractNo, true);
        }
        return count;
    }

    @Override
    public int unSubQuote(String contractNo) {
        if (TextUtils.isEmpty(contractNo)) {
            return -1;
        }

        Map<String, Integer> quoteSubMap = EsQuoteData.getInstance().getQuoteSub();
        if (quoteSubMap.containsKey(contractNo)) {
            quoteSubMap.remove(contractNo);

            QuoteSend(contractNo, false);
        }

        return 0;
    }

    private void QuoteSend(String contractNo, boolean isSub) {
        int protocolCode = isSub ? EsQuoteProtocol.CMD_QTE_SNAPSHOT_SUB : EsQuoteProtocol.CMD_QTE_SNAPSHOTUN_SUB;

        QteSnapShotReq qteSnapShotReq = new QteSnapShotReq();
        qteSnapShotReq.setContractId(contractNo);

        CspSessionHead head = CspSessionHead.getCspSessionHead(protocolCode,
                EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, qteSnapShotReq.getStructLength());

        int key = EsQuoteData.getInstance().getQuoteKey();
        EsDataApi.sendMsg(key, EsQuoteProtocol.CSP_FRAME_PLAIN, head, qteSnapShotReq.beanToByte());
    }

    @Override
    public int subHisQuote(String contractNo) {
        int sessionId = EsQuoteData.getInstance().getHisQuoteSessionId();
        Map<String, SContract> contractSnapData = EsQuoteData.getInstance().getSContractSnapData();
        Map<String, STimeBucketDef> commTimeBucketDataMap = EsQuoteData.getInstance().getCommTimeBucketDataMap();
        Map<String, SHisQuoteDef> hisQuoteDefMap = EsQuoteData.getInstance().getSHisQuoteDefMap();
        String commodity = getCommodityId(contractNo);

        STimeBucketDef sTimeBucketDef = commTimeBucketDataMap.get(commodity);
        SContract sContract = contractSnapData.get(contractNo);
        SHisQuoteDef sHisQuoteDef = hisQuoteDefMap.get(contractNo);
        if (sContract == null || sTimeBucketDef == null) {
            return 0;
        }
        if (sHisQuoteDef != null) {
            int refCount = sHisQuoteDef.getRefCount();
            if (refCount > 0) {
                sHisQuoteDef.setRefCount(refCount + 1);
                return 2;
            }
        }
        sessionId++;
        SHisQuoteDef hisQuoteDef = new SHisQuoteDef(sessionId);
        hisQuoteDef.setContractNo(contractNo);
        hisQuoteDef.setTimeBucket(sTimeBucketDef);
        hisQuoteDef.setMContractNo(contractNo);
        hisQuoteDef.setDContractNo(contractNo);
        hisQuoteDefMap.put(contractNo, hisQuoteDef);

        // 发送查询
        qryHisQuoteSend(contractNo, EsQuoteConstant.QTE_KLINE_TYPE_MINUTE, EsNativeProtocol.HOPE_MINUTE_LINE_COUNT, 0, sessionId);
        qryHisQuoteSend(contractNo, EsQuoteConstant.QTE_KLINE_TYPE_DAY, EsNativeProtocol.HOPE_DAY_LINE_COUNT, 0, sessionId);
        qryHisQuoteSend(contractNo, EsQuoteConstant.QTE_KLINE_TYPE_TICK, EsNativeProtocol.MAX_TICK_LINE_COUNT, 0, sessionId);

        // 查询即时行情
        subQuote(contractNo);

        EsQuoteData.getInstance().setHisQuoteSessionId(sessionId);
        return 0;
    }

    @Override
    public int unSubHisQuote(String contractNo) {
        return 0;
    }

    @Override
    public int subMinQuote(String contractNo, long day) {
        return 0;
    }

    @Override
    public SQuoteSnapShot getSnapShot(String contractNo) {
        Map<String, SContract> sContractDataMap = EsQuoteData.getInstance().getSContractSnapData();
        SContract sContract = sContractDataMap.get(contractNo);
        if (sContract == null) {
            return null;
        } else {
            return sContract.getSnapShot();
        }
    }

    private void detectionCacheKLineData(String contractNo, char kLineType, int slice, int size, int usedIndex) {
        Map<String, SHisQuoteDef> hisQuoteDefMap = EsQuoteData.getInstance().getSHisQuoteDefMap();
        SHisQuoteDef hisQuoteDef = hisQuoteDefMap.get(contractNo);
        List<QteKLineData> mOrderLines = hisQuoteDef.getMOrderLines();
        List<QteKLineData> dOrderLines = hisQuoteDef.getDOrderLines();
        int needSize = size * slice;
        if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_MINUTE) {
            if (mOrderLines.size() - usedIndex - needSize > EsNativeProtocol.MINUTE_CACHE_THRESHOLD_COUNT) {
                return;
            }
            hisQuoteDef.setMReqCount(needSize * 2);
            qryHisQuoteSend(contractNo, kLineType, needSize * 2, hisQuoteDef.getMDateTime(), hisQuoteDef.getSessionId());
        } else if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_DAY) {
            if (dOrderLines.size() - usedIndex - needSize > EsNativeProtocol.DAY_CACHE_THRESHOLD_COUNT) {
                return;
            }
            hisQuoteDef.setDReqCount(needSize * 2);
            qryHisQuoteSend(contractNo, kLineType, needSize * 2, hisQuoteDef.getDDateTime(), hisQuoteDef.getSessionId());
        }
    }

    private HisQuoteData dealSliceKLineData(QteKLineData lineData, HisQuoteData quoteData, long key) {
        long date;
        date = quoteData.getTradeDate();
        if (key == date) {
            BigInteger kLineQty = lineData.getKLineQty();
            BigInteger volume = quoteData.getVolume();
            quoteData.setVolume(kLineQty.add(volume));
            quoteData.setOpenPrice(lineData.getOpeningPrice());
            if (lineData.getHighPrice() > quoteData.getHighPrice()) {
                quoteData.setHighPrice(lineData.getHighPrice());
            }
            if (lineData.getLowPrice() < quoteData.getLowPrice()) {
                quoteData.setLowPrice(lineData.getLowPrice());
            }
            return null;
        } else {
            HisQuoteData hisQuoteData = lineData.toHisQuoteData();
            hisQuoteData.setTradeDate(key);
            return hisQuoteData;
        }
    }

    private void qryHisQuoteSend(String contractNo, char kLineType, int reqCount, long endTime, long sessionId) {
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsQuoteProtocol.CMD_QTE_KLINE_REQ,
                EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, QteKLineReq.STRUCT_LENGTH);
        head.setSessionId(sessionId);
        QteKLineReq qteKLineReq = new QteKLineReq();
        if (EsQuoteConstant.QTE_KLINE_TYPE_MINUTE == kLineType) {
            qteKLineReq.setHopeCount(reqCount - 1);
        } else if (EsQuoteConstant.QTE_KLINE_TYPE_DAY == kLineType) {
            qteKLineReq.setHopeCount(reqCount - 1);
        } else if (EsQuoteConstant.QTE_KLINE_TYPE_TICK == kLineType) {
            qteKLineReq.setHopeCount(EsNativeProtocol.MAX_TICK_LINE_COUNT - 1);
        }
        qteKLineReq.setKLineType(kLineType);
        qteKLineReq.setEndTime(endTime);
        qteKLineReq.setContractId(contractNo);
        EsDataApi.sendMsg(EsQuoteData.getInstance().getHisQuoteKey(), EsQuoteProtocol.CSP_FRAME_PLAIN, head, qteKLineReq.beanToByte());
    }

    private String getCommodityId(String contractNo) {
        int indexOf = contractNo.lastIndexOf("|");
        if (indexOf > 0) {
            return contractNo.substring(0, indexOf);
        } else {
            return contractNo;
        }
    }

    private Commodity getCommodityByPlateCode(PkgPlateCodeRsp pkgPlateCodeRsp) {
        Commodity res = null;
        if (pkgPlateCodeRsp == null || pkgPlateCodeRsp.getPlateCode().isEmpty()) {
            return res;
        }
        Map<String, Commodity> commodityMap = EsQuoteData.getInstance().getCommodityMap();
        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();

        char attr = pkgPlateCodeRsp.getPlateCodeAttr();
        if (attr == EsNativeProtocol.S_PCODE_COMMODITY) {
            // 品种content为P F O，先将commodity提取出来
            String commodityType = pkgPlateCodeRsp.getPlateCode().split("\\|")[1];
            if ("P".equals(commodityType) || "F".equals(commodityType) || "O".equals(commodityType)) {
                res = commodityMap.get(pkgPlateCodeRsp.getPlateCode());
            }
        } else if (attr == EsNativeProtocol.S_PCODE_VIRTUAL_CONTRACT && contractMap.get(pkgPlateCodeRsp.getPlateCode()) != null) {
            res = contractMap.get(pkgPlateCodeRsp.getPlateCode()).getCommodity();
        } else if (attr == EsNativeProtocol.S_PCODE_REAL_CONTRACT && contractMap.get(pkgPlateCodeRsp.getPlateCode()) != null) {
            res = contractMap.get(pkgPlateCodeRsp.getPlateCode()).getCommodity();
        }
        return res;
    }

    private int getDepthImpliedSnapshot(String contractNo, SQuoteSnapShotL2 bid, SQuoteSnapShotL2 ask, SImpliedDepthL2 implied) {
        Map<String, SContract> sContractDataMap = EsQuoteData.getInstance().getSContractSnapData();
        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();
        SContract sContract = sContractDataMap.get(contractNo);
        Contract contract = contractMap.get(contractNo);
        if (sContract == null || contract == null) {
            return 0;
        } else {
            SQuoteSnapShot snapShot = sContract.getSnapShot();
            SparseArray<SQuoteField> data = snapShot.getData();
            SQuoteField im_bid_qty = data.get(EsNativeProtocol.S_FID_IMPLIEDBIDQTY);
            SQuoteField im_ask_qty = data.get(EsNativeProtocol.S_FID_IMPLIEDASKQTY);
            boolean use_bid = im_bid_qty == null || (im_bid_qty.getFidAttr() == EsNativeProtocol.S_FIDATTR_NONE || im_bid_qty.getQty().compareTo(BigInteger.ZERO) <= 0);
            boolean use_ask = im_ask_qty == null || (im_ask_qty.getFidAttr() == EsNativeProtocol.S_FIDATTR_NONE || im_ask_qty.getQty().compareTo(BigInteger.ZERO) <= 0);
            if (use_bid && use_ask) {
                return 0;
            }
            SQuoteField im_bid_price = data.get(EsNativeProtocol.S_FID_IMPLIEDBIDPRICE);
            SQuoteField im_ask_price = data.get(EsNativeProtocol.S_FID_IMPLIEDASKPRICE);

            Commodity commodity = contract.getCommodity();
            if (commodity == null) {
                return 0;
            }
            double tick = commodity.getPriceTick() / 2;

            //bid
            int rfid = 0;
            SparseArray<SQuoteFieldL2> wdata = bid.getData();
            for (int wfid = 0; wfid < EsNativeProtocol.MAX_L2_DEPTH; wfid++) {
                SQuoteFieldL2 rdata = sContract.getBidL2().getData().get(rfid);
                boolean invalid = false;
                if (rdata.getQty().compareTo(BigInteger.ZERO) <= 0) {
                    invalid = true;
                }
                if (use_bid && invalid) {
                    break;
                }
                if (!invalid) {//买卖价有效时，需要判断 隐含是否有效
                    if (use_bid || (rdata.getPrice() - im_bid_price.getPrice() > tick)) {//无隐含价 或 买价更优
                        wdata.get(wfid).setQty(rdata.getQty());
                        wdata.get(wfid).setPrice(rdata.getPrice());
                        rfid++;
                        continue;
                    } else if (Math.abs(rdata.getPrice() - im_bid_price.getPrice()) < tick) {//价格相等，数量合并
                        implied.setBidQtyDepth((short) (wfid + 1));
                        wdata.get(wfid).setQty(rdata.getQty().add(im_bid_qty.getQty()));
                        wdata.get(wfid).setPrice(rdata.getPrice());
                        rfid++;
                        use_bid = true;
                        continue;
                    }
                }
                //买价无效 或者 隐含价更优
                wdata.get(wfid).setQty(im_bid_qty.getQty());
                wdata.get(wfid).setPrice(im_bid_price.getPrice());
                implied.setBidQtyDepth((short) (wfid + 1));
                implied.setBidPriceDepth((short) (wfid + 1));
                use_bid = true;

                //买价无效，跳出循环
                if (invalid)
                    break;
            }
            bid.setData(wdata);

            //ask
            rfid = 0;
            wdata = ask.getData();
            for (int wfid = 0; wfid < EsNativeProtocol.MAX_L2_DEPTH; wfid++) {
                SQuoteFieldL2 rdata = sContract.getAskL2().getData().get(rfid);
                boolean invalid = false;
                if (rdata.getQty().compareTo(BigInteger.ZERO) <= 0) {
                    invalid = true;
                }
                if (use_ask && invalid) {
                    break;
                }
                if (!invalid) {//买卖价有效时，需要判断 隐含是否有效
                    if (use_ask || (im_ask_price.getPrice() - rdata.getPrice() > tick)) {//无隐含价 或 买价更优
                        wdata.get(wfid).setQty(rdata.getQty());
                        wdata.get(wfid).setPrice(rdata.getPrice());
                        rfid++;
                        continue;
                    } else if (Math.abs(rdata.getPrice() - im_ask_price.getPrice()) < tick) {//价格相等，数量合并
                        implied.setAskQtyDepth((short) (wfid + 1));
                        wdata.get(wfid).setQty(rdata.getQty().add(im_ask_qty.getQty()));
                        wdata.get(wfid).setPrice(rdata.getPrice());
                        rfid++;
                        use_ask = true;
                        continue;
                    }
                }
                //买价无效 或者 隐含价更优
                wdata.get(wfid).setQty(im_ask_qty.getQty());
                wdata.get(wfid).setPrice(im_bid_price.getPrice());
                implied.setBidQtyDepth((short) (wfid + 1));
                implied.setBidPriceDepth((short) (wfid + 1));
                use_ask = true;

                //买价无效，跳出循环
                if (invalid)
                    break;
            }
            ask.setData(wdata);
        }
        return 1;
    }

    private SQuoteSnapShotL2 getSnapShotL2Bid(String contractNo) {
        Map<String, SContract> sContractDataMap = EsQuoteData.getInstance().getSContractSnapData();
        SContract sContract = sContractDataMap.get(contractNo);
        if (sContract == null) {
            return new SQuoteSnapShotL2();
        }
        return sContract.getBidL2();
    }

    private SQuoteSnapShotL2 getSnapShotL2Ask(String contractNo) {
        Map<String, SContract> sContractDataMap = EsQuoteData.getInstance().getSContractSnapData();
        SContract sContract = sContractDataMap.get(contractNo);
        if (sContract == null) {
            return new SQuoteSnapShotL2();
        }
        return sContract.getAskL2();
    }
}
