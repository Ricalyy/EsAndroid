package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.data.bean.Currency;
import com.esunny.data.bean.Exchange;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/9/22
 */
public class QteExchangeData extends ApiStruct {


    public final static int STRUCT_LENGTH = 62;

    private String ExchangeNo;      //交易所代码
    private String ExchangeName;    //交易所名称

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(ExchangeNo, 11));
        buffer.put(stringToByte(ExchangeNo, 51));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setExchangeNo(util.getString(11));
        setExchangeName(util.getString(51));
    }

    public static Exchange toExchange(byte[] data) {
        if (data == null || data.length == 0) {
            return null;
        }
        ParseUtil util = ParseUtil.wrap(data);

        Exchange exchange = new Exchange();
        exchange.setExchangeNo(util.getString(11));
        exchange.setExchangeName(util.getString(51));
        return exchange;
    }

    public String getExchangeNo() {
        return ExchangeNo;
    }

    public void setExchangeNo(String exchangeNo) {
        ExchangeNo = exchangeNo;
    }

    public String getExchangeName() {
        return ExchangeName;
    }

    public void setExchangeName(String exchangeName) {
        ExchangeName = exchangeName;
    }
}
