package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

public class QteLoginRsp extends ApiStruct {

    public final static int STRUCT_LENGTH = 60;

    private char ModuleType;
    private String UserName;
    private int MaxLoginCount;
    private int LoginCount;

    public QteLoginRsp(byte[] buf) {
        byteToBean(buf);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        ModuleType = util.getChar();
        UserName = util.getString(51);
        MaxLoginCount = util.getInt();
        LoginCount = util.getInt();
    }

    public char getModuleType() {
        return ModuleType;
    }

    public String getUserName() {
        return UserName;
    }

    public int getMaxLoginCount() {
        return MaxLoginCount;
    }

    public int getLoginCount() {
        return LoginCount;
    }
}
