package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.mobile.util.ParseUtil;
import com.esunny.quote.EsQuoteProtocol;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author huang
 */
public class QteExchangeReq extends ApiStruct {

    public final static int STRUCT_LENGTH = 11;

    private String ExchangeNo;


    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(ExchangeNo, 11));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setExchangeNo(util.getString(11));
    }

    public static CspSessionHead getSessionHead(int protocolCode) {
        return CspSessionHead.getCspSessionHead(protocolCode, EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, STRUCT_LENGTH);
    }

    public String getExchangeNo() {
        return ExchangeNo;
    }

    public void setExchangeNo(String exchangeNo) {
        ExchangeNo = exchangeNo;
    }
}
