package com.esunny.quote.bean;


import java.util.ArrayList;
import java.util.List;

/**
 * @author huang
 */
public class STimeBucketDef {
    private int BaseCount = 0;
    private int CalCount = 0;
    private List<SHisQuoteTimeBucket> BaseTbs;
    private List<SHisQuoteTimeBucket> CalTbs;
    private List<SHisQuoteTimeBucket> CalTbsByTime;

    public STimeBucketDef() {
        BaseTbs = new ArrayList<>();
        CalTbs = new ArrayList<>();
        CalTbsByTime = new ArrayList<>();
    }

    public int getBaseCount() {
        return BaseCount;
    }

    public void setBaseCount(int baseCount) {
        BaseCount = baseCount;
    }

    public int getCalCount() {
        return CalCount;
    }

    public void setCalCount(int calCount) {
        CalCount = calCount;
    }

    public List<SHisQuoteTimeBucket> getBaseTbs() {
        return BaseTbs;
    }

    public void setBaseTbs(List<SHisQuoteTimeBucket> baseTbs) {
        BaseTbs = baseTbs;
    }

    public List<SHisQuoteTimeBucket> getCalTbs() {
        return CalTbs;
    }

    public void setCalTbs(List<SHisQuoteTimeBucket> calTbs) {
        CalTbs = calTbs;
    }

    public List<SHisQuoteTimeBucket> getCalTbsByTime() {
        return CalTbsByTime;
    }

    public void setCalTbsByTime(List calTbsByTime) {
        CalTbsByTime = calTbsByTime;
    }

}
