package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/9/23
 */
public class QteOptionExpireReq extends ApiStruct {

    public static final int STRUCT_LENGTH = 51;

    private String OptionSerialId;    //期权序列编号

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(OptionSerialId, 51));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setOptionSerialId(util.getString(51));
    }

    public String getOptionSerialId() {
        return OptionSerialId;
    }

    public void setOptionSerialId(String optionSerialId) {
        OptionSerialId = optionSerialId;
    }
}
