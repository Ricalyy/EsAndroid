package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.mobile.util.ParseUtil;
import com.esunny.quote.EsQuoteProtocol;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/9/21
 */
public class QteUserRightReq extends ApiStruct {

    public final static int STRUCT_LENGTH = 51;

    private String UserName;// 行情账号用户名

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(UserName, 51));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setUserName(util.getString(51));
    }

    public static CspSessionHead getSessionHead(int protocolCode) {
        return CspSessionHead.getCspSessionHead(protocolCode, EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, STRUCT_LENGTH);
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }
}
