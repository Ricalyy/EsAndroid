package com.esunny.quote.codetable.strategy;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.Commodity;
import com.esunny.data.database.gen.TCommodityDao;
import com.esunny.quote.EsQuoteData;
import com.esunny.data.database.DBManager;
import com.esunny.quote.codetable.CodeTable;
import com.esunny.quote.codetable.model.CodeTableModel;
import com.esunny.data.database.table.TCommodity;
import com.esunny.data.database.table.TUpdateManager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author Peter Fu
 * @date 2020/10/14
 */
public class TCommodityCodeInfo implements ICodeInfo {
    private static final String TAG = "TCommodityCodeInfo";

    @Override
    public void saveDBDataToCache(CodeTableModel model) {
//        model.saveCommodity();
    }

    @Override
    public void clearDBData(CodeTableModel model) {
        model.clearDataBase(TCommodityDao.TABLENAME);
    }

    @Override
    public void saveDataToDB(Context context) {
        Log.d(TAG, "start save commodity");
        long updateId = CodeTable.getInstance().saveSateBeforeUpdate(context, TCommodityDao.TABLENAME);

        Map<String, Commodity>commodityMap = EsQuoteData.getInstance().getCommodityMap();

        List<TCommodity> list = new ArrayList<>();
        for (Map.Entry<String, Commodity> set :  commodityMap.entrySet()) {
            Commodity commodity = set.getValue();

            TCommodity tCommodity = new TCommodity();
            tCommodity.setCommodityId(commodity.getCommodityNo());
            if (commodity.getExchange() != null) {
                tCommodity.setExchangeNo(commodity.getExchange().getExchangeNo());
            }
            if (commodity.getCurrency() != null){
                tCommodity.setCurrencyNo(commodity.getCurrency().getCurrencyNo());
            }

            int languageType = EsDataApi.getLanguageType();
            if (languageType == EsDataConstant.S_ANDROID_CHS) {
                tCommodity.setCHSName(commodity.getCommodityName());
            } else if (languageType == EsDataConstant.S_ANDROID_ENU) {
                tCommodity.setENUName(commodity.getCommodityName());
            } else if (languageType == EsDataConstant.S_ANDROID_CHT) {
                tCommodity.setCHTName(commodity.getCommodityName());
            }

            tCommodity.setCommodityDot(commodity.getTradeDot());
            tCommodity.setOptionType(String.valueOf(commodity.getOptionProperty()));
            tCommodity.setSpreadDirect(String.valueOf(commodity.getSpreadDirect()));
            tCommodity.setExecuteWay(String.valueOf(commodity.getOptionExercise()));
            tCommodity.setCoverMode(String.valueOf(commodity.getCoverMode()));
            tCommodity.setPriceTick(commodity.getPriceTick());
            tCommodity.setPriceDeno(commodity.getPriceDeno());
            tCommodity.setPriceMultiple(commodity.getPriceMultiple());
            tCommodity.setExecuteDot(commodity.getExerciseDot());
            tCommodity.setMaxSingleOrderQty(commodity.getMaxSingleOrderQty().intValue());
            tCommodity.setMaxPositionQty(commodity.getMaxPositionQty().intValue());
            tCommodity.setRCommodityId1(commodity.getTargetCommodity1());
            tCommodity.setRCommodityId2(commodity.getTargetCommodity2());
            tCommodity.setUpdateId(updateId);

            list.add(tCommodity);
        }

        DBManager.getInstance().getDaoSession()
                .getTCommodityDao().insertOrReplaceInTx(list);

        CodeTable.getInstance().saveStateAfterUpdate(context, updateId);
        Log.d(TAG, "end save commodity, list size : " +  list.size() + ", update id : " + updateId);
    }

    @Override
    public int getIndex() {
        return 2;
    }

    @Override
    public int getUpdateCode(TUpdateManager manager) {
        // 获取存取结果信息判断
        boolean result = manager.getResult();
        if (!result) {
            return 0;
        }

        // 获取语言信息判断
        int languageInDb = manager.getLanguage();
        int languageInApp = EsDataApi.getLanguageType();

        if (languageInDb != languageInApp) {
            return 0;
        }

        // 获取时间信息判断, 以月为单位更新
        String dateDate = manager.getDateTime();
        Date date = null;
        try {
            if (!TextUtils.isEmpty(dateDate)) {
                date = df.parse(dateDate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        int nowDay = calendar.get(Calendar.DAY_OF_YEAR);

        calendar.setTime(date);
        int updateDay = calendar.get(Calendar.DAY_OF_YEAR);
        calendar.clear();

        boolean isUpdate = nowDay != updateDay;

        return isUpdate ? 0 : 1 << getIndex();
    }

}

