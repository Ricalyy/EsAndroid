package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;


/**
 * @author huang
 */
public class QteCommodityData extends ApiStruct {
    public final static int STRUCT_LENGTH = 384;

    private String CommodityId = "";        //品种编号
    private String ExchangeNo = "";         //交易所代码,必填(管理终端控制)
    private String CurrencyNo = "";         //币种代码,必填(管理终端控制)
    private String CommodityName = "";       //名称
    private double CommodityDot = 0.0;       //每手乘数
    private char OptionType;           //期权类型
    private char SpreadDirect;         //组合方向
    private char ExecuteWay;           //行权方式
    private char CoverMode;            //平仓模式
    private double PriceTick = 0.0;          //最小变动价
    private int PriceDeno = 0;             //报价分母
    private String QuoteUnitName = "";        //报价单位名称
    private String TradingUnitName = "";      //交易单位名称
    private String DepositGroupNo = "";       //大边保证金组组号
    private float PriceMultiple = 0;        //执行价格倍数
    private double ExecuteDot = 0.0;           //行权乘数
    private int MaxSingleOrderQty = 0;       //最大下单量
    private int MaxPositionQty = 0;          //最大持仓量
    private String RCommodityId1 = "";        //依赖品种1
    private String RCommodityId2 = "";        //依赖品种2
    private String RCommodityId3 = "";        //依赖品种3
    private String RCommodityId4 = "";        //依赖品种4
    private char Operator1;              //运算符1
    private char Operator2;              //运算符2
    private char Operator3;              //运算符3
    private double PriceProp1 = 0.0;           //价格配比1
    private double PriceProp2 = 0.0;           //价格配比2
    private double PriceProp3 = 0.0;           //价格配比3
    private double PriceProp4 = 0.0;           //价格配比4
    private int QtyProp1 = 0;                //数量配比1
    private int QtyProp2 = 0;                //数量配比2
    private int QtyProp3 = 0;                //数量配比3
    private int QtyProp4 = 0;                //数量配比4

    public QteCommodityData(byte[] buf){
         byteToBean(buf);
    }

    public String getCommodityId() {
        return CommodityId;
    }

    public void setCommodityId(String commodityId) {
        CommodityId = commodityId;
    }

    public String getExchangeNo() {
        return ExchangeNo;
    }

    public void setExchangeNo(String exchangeNo) {
        ExchangeNo = exchangeNo;
    }

    public String getCurrencyNo() {
        return CurrencyNo;
    }

    public void setCurrencyNo(String currencyNo) {
        CurrencyNo = currencyNo;
    }

    public String getCommodityName() {
        return CommodityName;
    }

    public void setCommodityName(String CommodityName) {
        this.CommodityName = CommodityName;
    }

    public double getCommodityDot() {
        return CommodityDot;
    }

    public void setCommodityDot(double commodityDot) {
        CommodityDot = commodityDot;
    }

    public char getOptionType() {
        return OptionType;
    }

    public void setOptionType(char optionType) {
        OptionType = optionType;
    }

    public char getSpreadDirect() {
        return SpreadDirect;
    }

    public void setSpreadDirect(char spreadDirect) {
        SpreadDirect = spreadDirect;
    }

    public char getExecuteWay() {
        return ExecuteWay;
    }

    public void setExecuteWay(char executeWay) {
        ExecuteWay = executeWay;
    }

    public char getCoverMode() {
        return CoverMode;
    }

    public void setCoverMode(char coverMode) {
        CoverMode = coverMode;
    }

    public double getPriceTick() {
        return PriceTick;
    }

    public void setPriceTick(double priceTick) {
        PriceTick = priceTick;
    }

    public int getPriceDeno() {
        return PriceDeno;
    }

    public void setPriceDeno(int priceDeno) {
        PriceDeno = priceDeno;
    }

    public String getQuoteUnitName() {
        return QuoteUnitName;
    }

    public void setQuoteUnitName(String quoteUnitName) {
        QuoteUnitName = quoteUnitName;
    }

    public String getTradingUnitName() {
        return TradingUnitName;
    }

    public void setTradingUnitName(String tradingUnitName) {
        TradingUnitName = tradingUnitName;
    }

    public String getDepositGroupNo() {
        return DepositGroupNo;
    }

    public void setDepositGroupNo(String depositGroupNo) {
        DepositGroupNo = depositGroupNo;
    }

    public float getPriceMultiple() {
        return PriceMultiple;
    }

    public void setPriceMultiple(float priceMultiple) {
        PriceMultiple = priceMultiple;
    }

    public double getExecuteDot() {
        return ExecuteDot;
    }

    public void setExecuteDot(double executeDot) {
        ExecuteDot = executeDot;
    }

    public int getMaxSingleOrderQty() {
        return MaxSingleOrderQty;
    }

    public void setMaxSingleOrderQty(int maxSingleOrderQty) {
        MaxSingleOrderQty = maxSingleOrderQty;
    }

    public int getMaxPositionQty() {
        return MaxPositionQty;
    }

    public void setMaxPositionQty(int maxPositionQty) {
        MaxPositionQty = maxPositionQty;
    }

    public String getRCommodityId1() {
        return RCommodityId1;
    }

    public void setRCommodityId1(String RCommodityId1) {
        this.RCommodityId1 = RCommodityId1;
    }

    public String getRCommodityId2() {
        return RCommodityId2;
    }

    public void setRCommodityId2(String RCommodityId2) {
        this.RCommodityId2 = RCommodityId2;
    }

    public String getRCommodityId3() {
        return RCommodityId3;
    }

    public void setRCommodityId3(String RCommodityId3) {
        this.RCommodityId3 = RCommodityId3;
    }

    public String getRCommodityId4() {
        return RCommodityId4;
    }

    public void setRCommodityId4(String RCommodityId4) {
        this.RCommodityId4 = RCommodityId4;
    }

    public char getOperator1() {
        return Operator1;
    }

    public void setOperator1(char operator1) {
        Operator1 = operator1;
    }

    public char getOperator2() {
        return Operator2;
    }

    public void setOperator2(char operator2) {
        Operator2 = operator2;
    }

    public char getOperator3() {
        return Operator3;
    }

    public void setOperator3(char operator3) {
        Operator3 = operator3;
    }

    public double getPriceProp1() {
        return PriceProp1;
    }

    public void setPriceProp1(double priceProp1) {
        PriceProp1 = priceProp1;
    }

    public double getPriceProp2() {
        return PriceProp2;
    }

    public void setPriceProp2(double priceProp2) {
        PriceProp2 = priceProp2;
    }

    public double getPriceProp3() {
        return PriceProp3;
    }

    public void setPriceProp3(double priceProp3) {
        PriceProp3 = priceProp3;
    }

    public double getPriceProp4() {
        return PriceProp4;
    }

    public void setPriceProp4(double priceProp4) {
        PriceProp4 = priceProp4;
    }

    public int getQtyProp1() {
        return QtyProp1;
    }

    public void setQtyProp1(int qtyProp1) {
        QtyProp1 = qtyProp1;
    }

    public int getQtyProp2() {
        return QtyProp2;
    }

    public void setQtyProp2(int qtyProp2) {
        QtyProp2 = qtyProp2;
    }

    public int getQtyProp3() {
        return QtyProp3;
    }

    public void setQtyProp3(int qtyProp3) {
        QtyProp3 = qtyProp3;
    }

    public int getQtyProp4() {
        return QtyProp4;
    }

    public void setQtyProp4(int qtyProp4) {
        QtyProp4 = qtyProp4;
    }


    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CommodityId, 21));
        buffer.put(stringToByte(ExchangeNo, 11));
        buffer.put(stringToByte(CurrencyNo, 11));
        buffer.put(stringToByte(CommodityName, 51));
        buffer.putDouble(CommodityDot);
        buffer.put(charToByte(OptionType));
        buffer.put(charToByte(SpreadDirect));
        buffer.put(charToByte(ExecuteWay));
        buffer.put(charToByte(CoverMode));
        buffer.putDouble(PriceTick);
        buffer.putShort((short) PriceDeno);
        buffer.putFloat(PriceMultiple);
        buffer.putDouble(ExecuteDot);
        buffer.put(stringToByte(QuoteUnitName, 51));
        buffer.put(stringToByte(TradingUnitName, 51));
        buffer.put(stringToByte(DepositGroupNo, 11));
        buffer.putInt(MaxSingleOrderQty);
        buffer.putInt(MaxPositionQty);
        buffer.put(stringToByte(RCommodityId1, 21));
        buffer.put(stringToByte(RCommodityId2, 21));
        buffer.put(stringToByte(RCommodityId3, 21));
        buffer.put(stringToByte(RCommodityId4, 21));
        buffer.put(charToByte(Operator1));
        buffer.put(charToByte(Operator2));
        buffer.put(charToByte(Operator3));
        buffer.putDouble(PriceProp1);
        buffer.putDouble(PriceProp2);
        buffer.putDouble(PriceProp3);
        buffer.putDouble(PriceProp4);
        buffer.putInt(QtyProp1);
        buffer.putInt(QtyProp2);
        buffer.putInt(QtyProp3);
        buffer.putInt(QtyProp4);
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCommodityId(util.getString(21));
        setExchangeNo(util.getString(11));
        setCurrencyNo(util.getString(11));
        setCommodityName(util.getString(51));
        setCommodityDot(util.getDouble());
        setOptionType(util.getChar());
        setSpreadDirect(util.getChar());
        setExecuteWay(util.getChar());
        setCoverMode(util.getChar());
        setPriceTick(util.getDouble());
        setPriceDeno(util.getUnsignedShort());
        setPriceMultiple(util.getFloat());
        setExecuteDot(util.getDouble());
        setQuoteUnitName(util.getString(51));
        setTradingUnitName(util.getString(51));
        setDepositGroupNo(util.getString(11));
        setMaxSingleOrderQty(util.getInt());
        setMaxPositionQty(util.getInt());
        setRCommodityId1(util.getString(21));
        setRCommodityId2(util.getString(21));
        setRCommodityId3(util.getString(21));
        setRCommodityId4(util.getString(21));
        setOperator1(util.getChar());
        setOperator2(util.getChar());
        setOperator3(util.getChar());
        setPriceProp1(util.getDouble());
        setPriceProp2(util.getDouble());
        setPriceProp3(util.getDouble());
        setPriceProp4(util.getDouble());
        setQtyProp1(util.getInt());
        setQtyProp2(util.getInt());
        setQtyProp3(util.getInt());
        setQtyProp4(util.getInt());
    }

    public static QteCommodityData toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new QteCommodityData(data);
        } else {
            return null;
        }
    }
}
