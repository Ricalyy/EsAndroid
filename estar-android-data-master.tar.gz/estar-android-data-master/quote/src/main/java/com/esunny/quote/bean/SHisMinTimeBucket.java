package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;

public class SHisMinTimeBucket extends ApiStruct {
    private String CommodityId;
    private String TemplateNo;
    private long BeginDate;
    private long EndDate;

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCommodityId() {
        return CommodityId;
    }

    public void setCommodityId(String commodityId) {
        CommodityId = commodityId;
    }

    public String getTemplateNo() {
        return TemplateNo;
    }

    public void setTemplateNo(String templateNo) {
        TemplateNo = templateNo;
    }

    public long getBeginDate() {
        return BeginDate;
    }

    public void setBeginDate(long beginDate) {
        BeginDate = beginDate;
    }

    public long getEndDate() {
        return EndDate;
    }

    public void setEndDate(long endDate) {
        EndDate = endDate;
    }
}
