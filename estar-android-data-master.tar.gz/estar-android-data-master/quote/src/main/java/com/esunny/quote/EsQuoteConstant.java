package com.esunny.quote;

/**
 * @author huang
 */
public class EsQuoteConstant {
    public static final char S_TRADESTATE_BID = '1';    //集合竞价
    public static final char S_TRADESTATE_MATCH = '2';    //集合竞价撮合
    public static final char S_TRADESTATE_CONTINUOUS = '3';    //连续交易
    public static final char S_TRADESTATE_PAUSED = '4';    //暂停
    public static final char S_TRADESTATE_CLOSE = '5';    //闭式
    public static final char S_TRADESTATE_DEALLAST = '6';    //闭市处理时间
    public static final char S_TRADESTATE_SWITCHTRADE = '0';    //交易日切换时间
    public static final char S_TRADESTATE_UNKNOWN = 'N';    //未知状态
    public static final char S_TRADESTATE_INITIALIZE = 'I';    //正初始化
    public static final char S_TRADESTATE_READY = 'R';    //准备就绪

    public static final char QTE_KLINE_TYPE_TICK = 'T'; //分笔明细
    public static final char QTE_KLINE_TYPE_MINUTE = 'M'; //分钟
    public static final char QTE_KLINE_TYPE_DAY = 'D'; //日线

}
