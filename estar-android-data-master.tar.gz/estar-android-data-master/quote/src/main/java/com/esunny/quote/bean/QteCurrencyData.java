package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.data.bean.Currency;
import com.esunny.data.bean.Exchange;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/9/22
 */
public class QteCurrencyData extends ApiStruct {

    public final static int STRUCT_LENGTH = 27;

    private String                 CurrencyNo;
    private double              ExchangeRate;     //汇率，小数形式
    private double                       InterestRate;     //利率，小数形式

    private QteCurrencyData(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CurrencyNo, 11));
        buffer.putDouble(ExchangeRate);
        buffer.putDouble(InterestRate);
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCurrencyNo(util.getString(11));
        setExchangeRate(util.getDouble());
        setInterestRate(util.getDouble());
    }

    public static Currency toCurrency(byte[] data) {
        if (data == null || data.length == 0) {
            return null;
        }
        ParseUtil util = ParseUtil.wrap(data);

        Currency currency = new Currency();
        currency.setCurrencyNo(util.getString(11));
        currency.setExchangeRate(util.getDouble());
        currency.setInterestRate(util.getDouble());
        return currency;
    }

    public static QteCurrencyData toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new QteCurrencyData(data);
        } else {
            return null;
        }
    }

    public String getCurrencyNo() {
        return CurrencyNo;
    }

    public void setCurrencyNo(String currencyNo) {
        CurrencyNo = currencyNo;
    }

    public double getExchangeRate() {
        return ExchangeRate;
    }

    public void setExchangeRate(double exchangeRate) {
        ExchangeRate = exchangeRate;
    }

    public double getInterestRate() {
        return InterestRate;
    }

    public void setInterestRate(double interestRate) {
        InterestRate = interestRate;
    }
}
