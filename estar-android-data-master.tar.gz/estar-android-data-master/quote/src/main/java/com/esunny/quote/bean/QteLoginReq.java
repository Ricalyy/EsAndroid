package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class QteLoginReq extends ApiStruct {

    //1+51+21+51
    public final static int STRUCT_LENGTH = 124;

    private char ModuleType;
    private String UserName;
    private String Password;
    private String LicenseNo;

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(charToByte(ModuleType));
        buffer.put(stringToByte(UserName, 51));
        buffer.put(stringToByte(Password, 21));
        buffer.put(stringToByte(LicenseNo, 51));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setModuleType(util.getChar());
        setUserName(util.getString(51));
        setPassword(util.getString(21));
        setLicenseNo(util.getString(51));
    }

    public void setModuleType(char moduleType) {
        ModuleType = moduleType;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public void setLicenseNo(String licenseNo) {
        LicenseNo = licenseNo;
    }
}
