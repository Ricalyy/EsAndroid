package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/16
 */
public class RegUserPluginQryRsp extends ApiStruct {
    private String             UUId;               //用户唯一ID
    private String          UserNo;
    private String         PluginNo;
    private String          GroupNo;
    private String                   BeginDate;
    private String                   EndDate;
    private char          OperateRight;

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setUUId(util.getString(11));
        setUserNo(util.getString(51));
        setPluginNo(util.getString(21));
        setGroupNo(util.getString(21));
        setBeginDate(util.getString(11));
        setEndDate(util.getString(11));
        setOperateRight(util.getChar());
    }

    public String getUUId() {
        return UUId;
    }

    public void setUUId(String UUId) {
        this.UUId = UUId;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getPluginNo() {
        return PluginNo;
    }

    public void setPluginNo(String pluginNo) {
        PluginNo = pluginNo;
    }

    public String getGroupNo() {
        return GroupNo;
    }

    public void setGroupNo(String groupNo) {
        GroupNo = groupNo;
    }

    public String getBeginDate() {
        return BeginDate;
    }

    public void setBeginDate(String beginDate) {
        BeginDate = beginDate;
    }

    public String getEndDate() {
        return EndDate;
    }

    public void setEndDate(String endDate) {
        EndDate = endDate;
    }

    public char getOperateRight() {
        return OperateRight;
    }

    public void setOperateRight(char operateRight) {
        OperateRight = operateRight;
    }
}
