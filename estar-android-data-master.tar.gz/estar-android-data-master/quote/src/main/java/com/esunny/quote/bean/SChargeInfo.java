package com.esunny.quote.bean;

/**
 * @author huang
 */
public class SChargeInfo {
    private String CommodityNo;        //收费品种
    private String ExchangeNo;
    private String GroupNo;            //防止品种组与交易所号不同，目前的品种组均为交易所号
    private boolean isPay;

    public String getCommodityNo() {
        return CommodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        CommodityNo = commodityNo;
    }

    public String getExchangeNo() {
        return ExchangeNo;
    }

    public void setExchangeNo(String exchangeNo) {
        ExchangeNo = exchangeNo;
    }

    public String getGroupNo() {
        return GroupNo;
    }

    public void setGroupNo(String groupNo) {
        GroupNo = groupNo;
    }

    public boolean getIsPay() {
        return isPay;
    }

    public void setIsPay(boolean isPay) {
        this.isPay = isPay;
    }

}
