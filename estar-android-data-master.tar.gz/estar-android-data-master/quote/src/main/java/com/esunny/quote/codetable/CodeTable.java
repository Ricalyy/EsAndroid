package com.esunny.quote.codetable;

import android.content.Context;

import com.alibaba.android.arouter.launcher.ARouter;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.server.EsQuoteApi;
import com.esunny.data.api.server.RoutingTable;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.Currency;
import com.esunny.data.bean.Exchange;
import com.esunny.data.bean.OptionContractPair;
import com.esunny.data.bean.OptionSeries;
import com.esunny.data.database.gen.TCommodityDao;
import com.esunny.data.database.gen.TContractDao;
import com.esunny.data.database.gen.TCurrencyDao;
import com.esunny.data.database.gen.TExchangeDao;
import com.esunny.data.database.gen.TUpdateManagerDao;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.data.database.DBManager;
import com.esunny.quote.codetable.model.CodeTableModel;
import com.esunny.quote.codetable.strategy.ICodeInfo;
import com.esunny.data.database.table.TUpdateManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Peter Fu
 * @date 2020/9/22
 */
public class CodeTable {

    private static final String TAG = "CodeTable";

    private Context mContext;
    // 本地是否缓存码表，默认为false
    private boolean mIsSaveCodeDataLocally = true;
    private int mUpdateCode = -1;
    private EsQuoteApi mQuoteApi;

    private CodeTableModel mModel;

    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式

    private CodeTable() {
        mQuoteApi = (EsQuoteApi) ARouter.getInstance().build(RoutingTable.ES_QUOTE_API).navigation();
    }

    private static class CodeTableHolder{
        private final static CodeTable INSTANCE = new CodeTable();
    }

    public static CodeTable getInstance() {
        return CodeTableHolder.INSTANCE;
    }

    public void init(Context context) {
        mContext = context;

        mIsSaveCodeDataLocally = EsSPHelperProxy.getIsSaveCodeTable(context);

//        mUpdateCode = queryUpdateCodeInDB();
        mModel = new CodeTableModel(mContext);
    }

    public boolean getIsSaveCodeDataLocally() {
        return mIsSaveCodeDataLocally;
    }

    /**
     * 同步所有类别信息到码表数据库
     * updateCode用法 可参照 StarApiAndroid.S_Startup
     */
    public void saveDataToDB(int updateCode) {
        ICodeInfo codeInfo;
        String tableName = null;

        if ((updateCode & 1) == 1 && (updateCode & 8) == 0) {
            // 含有币种，但是合约没的时候依旧需要同步，因同步合约C中需要币种信息
            tableName = TCurrencyDao.TABLENAME;
        } else if ((updateCode & 2) == 2 && (updateCode & 8) == 0) {
            tableName = TExchangeDao.TABLENAME;
        } else if ((updateCode & 4) == 4 && (updateCode & 8) == 0) {
            tableName = TCommodityDao.TABLENAME;
        } else if ((updateCode & 8) == 8) {
            tableName = TContractDao.TABLENAME;
        } else if ((updateCode & 128) == 128) {
//            tableName = TChargeCommodityDao.TABLENAME;
        }

        if (tableName != null) {
            codeInfo = getCodeInfo(tableName);
            if (codeInfo != null) {
                codeInfo.clearDBData(mModel);
                codeInfo.saveDataToDB(mContext);
                EsLog.d(TAG, "update data to Table : " + tableName);
            }
        }
    }

    private int queryUpdateCodeInDB() {
        int result = 0;

        EsLog.d(TAG, "is update code data : " + mIsSaveCodeDataLocally);
        // 如果配置本地不缓存码表信息，则全部更新
        if (!mIsSaveCodeDataLocally) {
            return result;
        }

        List<String> tableNameList = getTableNameFromUpdateManager();
        for (String str : tableNameList) {
            EsLog.d(TAG, "get code info, table name : " + str);
            TUpdateManager tUpdateManager = getNewestTUpdateManager(str);
            if (tUpdateManager == null) {
                continue;
            }

            ICodeInfo codeInfo = getCodeInfo(str);
            if (codeInfo == null) {
                continue;
            }

            result += codeInfo.getUpdateCode(tUpdateManager);
        }


        EsLog.d(TAG, "update code : " + result);
        return result;
    }

    /**
     * 不同类别的码表所需要的操作接口。
     * @param tableName 表名
     * @return
     */
    private ICodeInfo getCodeInfo(String tableName) {
        ICodeInfo codeInfo = null;

        String className = String.format("%s.%sCodeInfo", ICodeInfo.class.getPackage().getName(), tableName);

        EsLog.d(TAG, "getCodeInfo class name is " + className);
        try {
            codeInfo = (ICodeInfo) Class.forName(className).newInstance();
        } catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return codeInfo;
    }

    /**
     * 从TUpdateManager表中
     * 返回 表名对应的码表信息最新的一条信息
     * @param tableName 表名
     * @return
     */
    public TUpdateManager getNewestTUpdateManager(String tableName){
                TUpdateManagerDao updateManagerDao = DBManager.getInstance().getDaoSession()
                .getTUpdateManagerDao();

        List<TUpdateManager> tUpdateManagerList = updateManagerDao.queryBuilder()
                .where(TUpdateManagerDao.Properties.TableName.eq(tableName)).orderDesc(TUpdateManagerDao.Properties.Id).list();

        if (tUpdateManagerList != null && tUpdateManagerList.size() > 0) {
            return tUpdateManagerList.get(0);
        } else {
            EsLog.d(TAG, "updateManager is null, table name : " + tableName);
        }
        return null;
    }

    /**
     * 从updateManager中通过获取表名信息，了解存储了什么类型的信息
     * @return
     */
    public List<String> getTableNameFromUpdateManager() {
        List<String> result = new ArrayList<>();
        List<TUpdateManager> updateManagerList = DBManager.getInstance()
                .getDaoSession()
                .getTUpdateManagerDao().queryBuilder().list();

        for (TUpdateManager manager : updateManagerList) {
            String tableName = manager.getTableName();
            if (!result.contains(tableName)) {
                result.add(tableName);
            }
        }

        return result;
    }

    public int getUpdateCode() {
        if (!mIsSaveCodeDataLocally) {
            return 0;
        }
        if(mUpdateCode > 0) {
            return mUpdateCode;
        }

        mUpdateCode = queryUpdateCodeInDB();
        EsLog.d(TAG, "update code : %d", mUpdateCode);
        return mUpdateCode;
    }

    public long saveSateBeforeUpdate(Context context, String tableName) {
        TUpdateManager tUpdateManager = new TUpdateManager();
        tUpdateManager.setDateTime(df.format(new Date()));
        tUpdateManager.setTableName(tableName);
        tUpdateManager.setResult(false);
        tUpdateManager.setLanguage(EsDataApi.getLanguageType());

        return DBManager.getInstance().getDaoSession()
                .getTUpdateManagerDao().insert(tUpdateManager);
    }

    public void saveStateAfterUpdate(Context context,long id) {
        TUpdateManagerDao updateManagerDao = DBManager.getInstance().getDaoSession()
                .getTUpdateManagerDao();

        TUpdateManager tUpdateManager = updateManagerDao.queryBuilder().where(TUpdateManagerDao.Properties.Id.eq(id)).build().unique();
        if (tUpdateManager != null) {
            tUpdateManager.setResult(true);
            updateManagerDao.update(tUpdateManager);
        }
    }


    public Contract getContract(String contractNo, boolean isTransferRealContract) {
        if (contractNo == null || contractNo.isEmpty()) {
            return null;
        }
        return mModel.getContract(contractNo, isTransferRealContract);
    }

    public String getContractName(String contractNo, Commodity commodity) {
        if (contractNo == null || commodity == null) {
            return null;
        }

        return mModel.getContractNameByCommodity(contractNo, commodity);
    }

    public List<Contract> getContractListByCommodity(String plateNo, List<String> commodityNoList) {
        if (commodityNoList == null || commodityNoList.isEmpty()) {
            return null;
        }
        return mModel.getContractListByCommodity(plateNo, commodityNoList);
    }

    public List<Commodity> getOptionCommodityList() {
        return mModel.getOptionCommodityList();
    }

    public Currency getCurrency(String currencyNo) {
        return mModel.getCurrency(currencyNo);
    }

    public Exchange getExchange(String exchangeNo) {
        return mModel.getExchange(exchangeNo);
    }

    public Commodity getCommodity(String commodityId) {
        return mModel.getCommodity(commodityId);
    }

    /**
     * 获取品种对应的所有期权系列
     * @param commodityNo
     * @return
     */
    public List<OptionSeries> getOptionSeriesOfCommodity(String commodityNo) {
        if (commodityNo == null || commodityNo.isEmpty()) {
            return new ArrayList<>();
        }

        return mModel.getOptionSeriesOfCommodity(commodityNo);
    }

    public List<OptionContractPair> getOptionContractPairOfSeriesNo(String seriesNo) {
        if (((mUpdateCode & 12) != 12) || seriesNo == null || seriesNo.isEmpty()) {
            return new ArrayList<>();
        }
        return mModel.getOptionContractPairOfSeriesNo(seriesNo);
    }
}
