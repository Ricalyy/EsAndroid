package com.esunny.quote.bean;


import com.esunny.data.api.inter.ApiStruct;
import com.esunny.data.bean.HisQuoteData;

import java.math.BigInteger;

public class QteKLineData extends ApiStruct {
    private String ContractId;      //合约ID
    private char KLineType;       //K线类型
    private int KLineIndex;      //K线索引  tick每笔连续序号，min交易分钟序号，day无效
    private long TradeDate;       //交易日   tick无效，min可能和时间戳不同，day和时间戳相同
    private BigInteger DateTimeStamp;   //时间戳，不同数据类型，精度不同
    private BigInteger TotalQty;       //行情快照 总成交量
    private BigInteger PositionQty;    //行情快照 持仓量
    private double LastPrice;      //最新价（收盘价）

    private BigInteger KLineQty;       //K线成交量 day  min
    private double OpeningPrice;   //开盘价  day  min
    private double HighPrice;      //最高价  day  min
    private double LowPrice;       //最低价  day  min
    private double SettlePrice;    //结算价  day  min

    private long LastQty;        //明细现手  tick
    private int PositionChg;    //持仓量变化 tick
    private double BuyPrice;       //买价 tick
    private double SellPrice;      //卖价 tick
    private double BuyQty;         //买量 tick
    private double SellQty;        //卖量 tick


    public String getContractId() {
        return ContractId;
    }

    public void setContractId(String contractId) {
        ContractId = contractId;
    }

    public char getKLineType() {
        return KLineType;
    }

    public void setKLineType(char KLineType) {
        this.KLineType = KLineType;
    }

    public int getKLineIndex() {
        return KLineIndex;
    }

    public void setKLineIndex(int KLineIndex) {
        this.KLineIndex = KLineIndex;
    }

    public long getTradeDate() {
        return TradeDate;
    }

    public void setTradeDate(long tradeDate) {
        TradeDate = tradeDate;
    }

    public BigInteger getDateTimeStamp() {
        return DateTimeStamp;
    }

    public void setDateTimeStamp(BigInteger dateTimeStamp) {
        DateTimeStamp = dateTimeStamp;
    }

    public BigInteger getTotalQty() {
        return TotalQty;
    }

    public void setTotalQty(BigInteger totalQty) {
        TotalQty = totalQty;
    }

    public BigInteger getPositionQty() {
        return PositionQty;
    }

    public void setPositionQty(BigInteger positionQty) {
        PositionQty = positionQty;
    }

    public double getLastPrice() {
        return LastPrice;
    }

    public void setLastPrice(double lastPrice) {
        LastPrice = lastPrice;
    }

    public BigInteger getKLineQty() {
        return KLineQty;
    }

    public void setKLineQty(BigInteger KLineQty) {
        this.KLineQty = KLineQty;
    }

    public double getOpeningPrice() {
        return OpeningPrice;
    }

    public void setOpeningPrice(double openingPrice) {
        OpeningPrice = openingPrice;
    }

    public double getHighPrice() {
        return HighPrice;
    }

    public void setHighPrice(double highPrice) {
        HighPrice = highPrice;
    }

    public double getLowPrice() {
        return LowPrice;
    }

    public void setLowPrice(double lowPrice) {
        LowPrice = lowPrice;
    }

    public double getSettlePrice() {
        return SettlePrice;
    }

    public void setSettlePrice(double settlePrice) {
        SettlePrice = settlePrice;
    }

    public long getLastQty() {
        return LastQty;
    }

    public void setLastQty(long lastQty) {
        LastQty = lastQty;
    }

    public int getPositionChg() {
        return PositionChg;
    }

    public void setPositionChg(int positionChg) {
        PositionChg = positionChg;
    }

    public double getBuyPrice() {
        return BuyPrice;
    }

    public void setBuyPrice(double buyPrice) {
        BuyPrice = buyPrice;
    }

    public double getSellPrice() {
        return SellPrice;
    }

    public void setSellPrice(double sellPrice) {
        SellPrice = sellPrice;
    }

    public double getBuyQty() {
        return BuyQty;
    }

    public void setBuyQty(double buyQty) {
        BuyQty = buyQty;
    }

    public double getSellQty() {
        return SellQty;
    }

    public void setSellQty(double sellQty) {
        SellQty = sellQty;
    }

    public HisQuoteData toHisQuoteData() {
        if (KLineQty == null) {
            KLineQty = BigInteger.ZERO;
        }
        HisQuoteData hisQuoteData = new HisQuoteData();
        hisQuoteData.setTradeDate(TradeDate);
        hisQuoteData.setDateTimeStamp(DateTimeStamp);
        hisQuoteData.setTotalQty(TotalQty);
        hisQuoteData.setPosition(PositionQty);
        hisQuoteData.setClosePrice(LastPrice);

        hisQuoteData.setVolume(KLineQty);
        hisQuoteData.setOpenPrice(OpeningPrice);
        hisQuoteData.setHighPrice(HighPrice);
        hisQuoteData.setLowPrice(LowPrice);
        hisQuoteData.setSettlePrice(SettlePrice);
        return hisQuoteData;
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
