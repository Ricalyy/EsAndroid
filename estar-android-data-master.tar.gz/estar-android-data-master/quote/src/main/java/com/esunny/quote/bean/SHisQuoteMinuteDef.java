package com.esunny.quote.bean;

import java.util.ArrayList;
import java.util.List;

public class SHisQuoteMinuteDef {
    private int RefCount;                   //订阅计数
    private String ContractNo;
    private int MReqCount;              //单次请求的总数据了
    private long MSessionId;                  //当前数据的SessionId
    private long MTradeDate;
    private int MrIndex;
    private int MwIndex;
    private List<QteKLineData> MLines = new ArrayList<>();

    public int getRefCount() {
        return RefCount;
    }

    public void setRefCount(int refCount) {
        RefCount = refCount;
    }

    public int getMReqCount() {
        return MReqCount;
    }

    public void setMReqCount(int MReqCount) {
        this.MReqCount = MReqCount;
    }

    public long getMSessionId() {
        return MSessionId;
    }

    public void setMSessionId(long MSessionId) {
        this.MSessionId = MSessionId;
    }

    public long getMTradeDate() {
        return MTradeDate;
    }

    public void setMTradeDate(long MTradeDate) {
        this.MTradeDate = MTradeDate;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public int getMrIndex() {
        return MrIndex;
    }

    public void setMrIndex(int mrIndex) {
        MrIndex = mrIndex;
    }

    public int getMwIndex() {
        return MwIndex;
    }

    public void setMwIndex(int mwIndex) {
        MwIndex = mwIndex;
    }

    public List<QteKLineData> getMLines() {
        return MLines;
    }

    public void setMLines(List<QteKLineData> MLines) {
        this.MLines = MLines;
    }
}
