package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author huang
 */
public class QteTimeBucketReq extends ApiStruct {
    public static final int STRUCT_LENGTH = 11;
    private String TemplateNo;

    public String getTemplateNo() {
        return TemplateNo;
    }

    public void setTemplateNo(String templateNo) {
        TemplateNo = templateNo;
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(TemplateNo, 11));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
