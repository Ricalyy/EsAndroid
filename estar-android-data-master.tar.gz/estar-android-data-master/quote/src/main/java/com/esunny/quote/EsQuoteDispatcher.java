package com.esunny.quote;

import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;

import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.EsEventConstant;
import com.esunny.data.api.event.HisQuoteEvent;
import com.esunny.data.api.event.QuoteEvent;
import com.esunny.data.api.inter.ApiStruct;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.ContractSortData;
import com.esunny.data.bean.ContractSortInfo;
import com.esunny.data.bean.Currency;
import com.esunny.data.bean.Exchange;
import com.esunny.data.bean.OptionContractPair;
import com.esunny.data.bean.OptionSeries;
import com.esunny.data.bean.SQuoteFieldL2;
import com.esunny.data.bean.SQuoteSnapShotL2;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.simplethread.SimpleRunnable;
import com.esunny.data.util.simplethread.TaskManager;
import com.esunny.mobile.EsApiData;
import com.esunny.quote.bean.QteDepthNewDetail;
import com.esunny.quote.bean.QteKLineData;
import com.esunny.quote.bean.QteKLineReq;
import com.esunny.quote.bean.QteLV2Data;
import com.esunny.quote.bean.QteSnapShotReq;
import com.esunny.quote.bean.QteUserRightDataRsp;
import com.esunny.quote.bean.RegUserCommGroupQryRsp;
import com.esunny.quote.bean.RegUserPluginQryRsp;
import com.esunny.quote.bean.SHisQuoteDef;
import com.esunny.quote.bean.SHisQuoteMinuteDef;
import com.esunny.quote.codetable.CodeTable;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.mobile.util.ParseUtil;
import com.esunny.quote.bean.QteCommTimeBucketReq;
import com.esunny.quote.bean.QteContUnderlyReq;
import com.esunny.quote.bean.QteContractReq;
import com.esunny.quote.bean.QteCurrencyData;
import com.esunny.quote.bean.QteCurrencyReq;
import com.esunny.quote.bean.QteExchangeData;
import com.esunny.quote.bean.QteExchangeReq;
import com.esunny.quote.bean.QteCommodityReq;
import com.esunny.quote.bean.QteLoginReq;
import com.esunny.quote.bean.QteLoginRsp;
import com.esunny.quote.bean.QteSnapShotData;
import com.esunny.quote.bean.QteSnapShotField;
import com.esunny.quote.bean.QteTimeBucketReq;
import com.esunny.quote.bean.SContract;
import com.esunny.quote.bean.SHisMinTimeBucket;
import com.esunny.quote.bean.SHisQuoteTimeBucket;
import com.esunny.quote.bean.QteOptionExpireReq;
import com.esunny.quote.bean.QteStockContData;
import com.esunny.quote.bean.QteUserRightReq;
import com.esunny.quote.bean.SChargeInfo;
import com.esunny.data.bean.SQuoteField;
import com.esunny.data.bean.SQuoteSnapShot;
import com.esunny.data.bean.SQuoteUserInfo;
import com.esunny.quote.bean.STimeBucketDef;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;


public class EsQuoteDispatcher extends CallbackDispatcher {

    private final String TAG = getClass().getSimpleName();

    List<String> optionExchangeList = Arrays.asList("ZCE", "DCE", "SHFE", "CFFEX", "SSE", "SZSE", "CBOT", "CME", "COMEX", "NYMEX", "ICUS", "ICEU",
            "HKEX", "LME", "EUREX", "SGX", "OSE", "TAIFEX", "KRX", "BMD");

    boolean mIsCompleteContractName = false, mIsCompleteContractUnderly = false;

    @Override
    public int dispatch(char action, byte[] data) {

        if (isQuote()) {
            return disPatchQuote(action, data);
        } else if (isHisQuote()) {
            return disPatchHisQuote(action, data);
        }

        return 0;
    }

    private int disPatchQuote(char action, byte[] data) {

        if (action == EVENT_TCP_CONNECT) {
            QuoteEvent.Builder builder = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_CONNECT);
            sendEvent(builder.buildEvent());

//            if (EsApiData.getInstance().getLoginState() == 0) {
//                return 0;
//            }

            loginQuote();
            return 0;
        }

        if (action == EVENT_TCP_DISCONNECT) {
            QuoteEvent.Builder builder = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_DISCONNECT);
            sendEvent(builder.buildEvent());
            return 0;
        }

        if (action == EVENT_TCP_RESET_DATA) {
            return 0;
        }

        byte[] headArr = new byte[CspSessionHead.STRUCT_LENGTH];
        System.arraycopy(data, 0, headArr, 0, CspSessionHead.STRUCT_LENGTH);

        int dataLen = data.length - CspSessionHead.STRUCT_LENGTH;
        byte[] buf = new byte[dataLen];
        System.arraycopy(data, CspSessionHead.STRUCT_LENGTH, buf, 0, dataLen);
        CspSessionHead head = new CspSessionHead(headArr);
        switch (head.getProtocolCode()) {
            //即时行情
            case EsQuoteProtocol.CMD_QTE_SNAPSHOTLV1_RSP:
            case EsQuoteProtocol.CMD_QTE_SNAPSHOTLV1_NOTICE:
                OnSnapShotLV1(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_SNAPSHOTLV2_RSP:
            case EsQuoteProtocol.CMD_QTE_SNAPSHOTLV2_NOTICE:
                OnSnapShotLV2(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_NEW_LOGON_RSP:
                onLoginQuote(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CURRENCY_RSP:
                currencyRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CURRENCY_DATA_RSP:
                currencyData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_EXCHANGE_RSP:
                exchangeRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_EXCHANGE_DATA_RSP:
                exchangeData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_COMMODITY_RSP:
                commodityRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_COMMODITY_DATA_RSP:
                commodityData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CONTRACT_RSP:
                contractRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CONTRACT_DATA_RSP:
                contractData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CONT_UNDERLY_RSP:
                contractUnderlyRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CONT_UNDERLY_DATA_RSP:
                contractUnderlyData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CONT_NAME_RSP:
                contractNameRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CONT_NAME_DATA_RSP:
                contractNameData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_OPTION_EXPIRE_RSP:
                optionExpireRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_OPTION_EXPIRE_DATA_RSP:
                optionExpireData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CHARGE_COMMODITY_RSP:
                chargeCommodityRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CHARGE_COMMODITY_DATA_RSP:
                OnChargeCommodity(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_STOCK_CONT_RSP:
                stockContRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_STOCK_CONT_DATA_RSP:
                stockContData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_USER_RIGHT_RSP:
                ResetChargeInfoHash(EsQuoteData.getInstance().getUserCommGroupMap().size());
                break;
            case EsQuoteProtocol.CMD_QTE_USER_RIGHT_DATA_RSP:
                OnUserRightData(buf, head);
                break;
            default:
                break;
        }

        return 0;
    }

    private void ResetChargeInfoHash(int size) {
        Map<String, SChargeInfo> chargeCommodityMap = EsQuoteData.getInstance().getChargeCommodityMap();
        Map<String, RegUserCommGroupQryRsp> userCommonGroupMap = EsQuoteData.getInstance().getUserCommGroupMap();
        if (chargeCommodityMap.size() == 0) {
            return;
        }
        List<String> chargeExchangeList = EsQuoteData.getInstance().getChargeExchageList();
        chargeExchangeList.clear();

        for (String key : chargeCommodityMap.keySet()) {
            SChargeInfo info = chargeCommodityMap.get(key);
            if (size == 0) {
                info.setIsPay(false);
            } else {
                boolean isExit = userCommonGroupMap.containsKey(info.getGroupNo());
                info.setIsPay(isExit);
            }

            if (!info.getIsPay() && !chargeExchangeList.contains(info.getExchangeNo())) {
                chargeExchangeList.add(info.getExchangeNo());
            }
        }
    }

    private void OnSnapShotLV1(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        Map<String, SContract> sContractSnapData = EsQuoteData.getInstance().getSContractSnapData();
        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();

        ParseUtil util = ParseUtil.wrap(buf);
        int start = 0;
        for (int i = 0; i < count; i++) {
            int len = util.getUnsignedChar();
            start += 1;

            String contractNo = util.getString(len);
            if (TextUtils.isEmpty(contractNo)) {
                break;
            }
//            EsLog.d(TAG, "OnSnapShotLV1 contract no : %s", contractNo);
            start += len;

            BigInteger updateTime = util.getLongLong();
            start += 8;

            int snapShotFieldCount = util.getUnsignedChar();
            start += 1;

            SContract sContract = sContractSnapData.get(contractNo);
            if (sContract == null) {
                sContract = new SContract();
                sContract.setContractNo(contractNo);
            }
            sContractSnapData.put(contractNo, sContract);
            SQuoteSnapShot snapShot = sContract.getSnapShot();

            BigInteger totalqty = BigInteger.ZERO;
            double totalPrice = 0;
            int ave = 0;

            boolean isESIF = contractNo.startsWith("ESFI|");

            for (int j = 0; j < snapShotFieldCount; j++) {
                if (start + QteSnapShotField.STRUCT_LENGTH > buf.length) {
                    continue;
                }

                byte[] struct = new byte[QteSnapShotField.STRUCT_LENGTH];
                System.arraycopy(buf, start, struct, 0, QteSnapShotField.STRUCT_LENGTH);
                QteSnapShotField snapShotfield = QteSnapShotField.toParse(struct);
                start += QteSnapShotField.STRUCT_LENGTH;

                // Finished to parse Field data
                if (snapShotfield.getFieldMean() >= EsNativeProtocol.S_FID_MEAN_COUNT) {
                    continue;
                }

                checkArray(snapShot.getData(), snapShotfield.getFieldMean());
                checkArray(0, sContract.getBidL2().getData());
                checkArray(0, sContract.getAskL2().getData());

                SQuoteField quoteField = snapShot.getData().get(snapShotfield.getFieldMean());

                quoteField.setQty(snapShotfield.getQty());
                quoteField.setPrice(snapShotfield.getPrice());
                quoteField.setFidAttr(EsNativeProtocol.S_FIDATTR_VALID);

                switch (snapShotfield.getFieldMean()) {
                    case EsNativeProtocol.S_FID_TOTALQTY:
                        totalqty = snapShotfield.getQty();
                        break;
                    case EsNativeProtocol.S_FID_BESTBIDPRICE:
                        sContract.getBidL2().getData().get(0).setPrice(snapShotfield.getPrice());
                        break;
                    case EsNativeProtocol.S_FID_BESTBIDQTY:
                        sContract.getBidL2().getData().get(0).setQty(snapShotfield.getQty());
                        break;
                    case EsNativeProtocol.S_FID_BESTASKPRICE:
                        sContract.getAskL2().getData().get(0).setPrice(snapShotfield.getPrice());
                        break;
                    case EsNativeProtocol.S_FID_BESTASKQTY:
                        sContract.getAskL2().getData().get(0).setQty(snapShotfield.getQty());
                        break;
                    case EsNativeProtocol.S_FID_TOTALTURNOVER:
                        totalPrice = snapShotfield.getPrice();
                        break;
                    case EsNativeProtocol.S_FID_AVERAGEPRICE:
                        ave = 1;
                        break;
                    case EsNativeProtocol.S_FID_CIRCULATION:
                        if (isESIF) {
                            checkArray(snapShot.getData(), EsNativeProtocol.S_FID_CODE);
                            snapShot.getData().get(EsNativeProtocol.S_FID_CODE).setQty(snapShotfield.getQty());
                            snapShot.getData().get(EsNativeProtocol.S_FID_CODE).setFidAttr(EsNativeProtocol.S_FIDATTR_VALID);
                        }
                        break;
                    case EsNativeProtocol.S_FID_UNDERLYCONT:
                        if (isESIF) {
                            checkArray(snapShot.getData(), EsNativeProtocol.S_FID_NAME);
                            snapShot.getData().get(EsNativeProtocol.S_FID_NAME).setQty(snapShotfield.getQty());
                            snapShot.getData().get(EsNativeProtocol.S_FID_NAME).setFidAttr(EsNativeProtocol.S_FIDATTR_VALID);
                        }
                        break;
                    default:
                        break;
                }
            }

            checkArray(snapShot.getData(), EsNativeProtocol.S_FID_DATETIME);
            SQuoteField dateTimeField = snapShot.getData().get(EsNativeProtocol.S_FID_DATETIME);
            dateTimeField.setDateTime(updateTime);
            dateTimeField.setFidAttr(EsNativeProtocol.S_FIDATTR_VALID);

            if (ave == 0 && totalPrice > 0) {
                Contract contract = contractMap.get(contractNo);
                if (contract == null) {
                    return;
                }
                Commodity commodity = contract.getCommodity();
                if (totalqty.compareTo(BigInteger.ZERO) != 0 && commodity.getTradeDot() != 0) {
                    checkArray(snapShot.getData(), EsNativeProtocol.S_FID_AVERAGEPRICE);
                    snapShot.getData().get(EsNativeProtocol.S_FID_AVERAGEPRICE).setPrice(totalPrice / totalqty.intValue() * commodity.getTradeDot());
                    snapShot.getData().get(EsNativeProtocol.S_FID_AVERAGEPRICE).setFidAttr(EsNativeProtocol.S_FIDATTR_VALID);
                }
            }

            QuoteEvent event = new QuoteEvent.Builder(EsDataConstant.S_SRVEVENT_QUOTE).setContractNo(contractNo).buildEvent();
            sendEvent(event);

            // TODO 开始计算历史行情
            if (totalqty.compareTo(BigInteger.ZERO) <= 0) {
                continue;
            }

        }
    }

    private void OnSnapShotLV2(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        Map<String, SContract> sContractSnapData = EsQuoteData.getInstance().getSContractSnapData();

        ParseUtil util = ParseUtil.wrap(buf);
        int start = 0;
        for (int i = 0; i < count; i++) {
            int len = util.getUnsignedChar();
            start += 1;

            String contractNo = util.getString(len);
            if (TextUtils.isEmpty(contractNo)) {
                break;
            }
            start += len;

            QteLV2Data lv2Data = new QteLV2Data();
            BigInteger updateTime = util.getLongLong();
            int depthLength = util.getUnsignedShort();
            short depthCount = util.getUnsignedChar();
            lv2Data.setUpdateTime(updateTime);
            lv2Data.setDepthLength(depthLength);
            lv2Data.setDepthCount(depthCount);
            start += 8 + 2 + 1;

            SContract sContract = sContractSnapData.get(contractNo);
            if (sContract == null || sContract.getBidL2() == null || sContract.getAskL2() == null) {
                continue;
            }
            for (int j = 0; j < depthCount; j++) {
                QteDepthNewDetail newDetail = new QteDepthNewDetail();
                short Action = util.getUnsignedChar();
                short level = util.getUnsignedChar();
                BigInteger qty = util.getLongLong();
                double price = util.getDouble();
                short direct = (short) (Action & 0xf0);
                short action = (short) (Action & 0x0f);

                if (level >= EsNativeProtocol.MAX_L2_DEPTH) {
                    continue;
                }

                newDetail.setAction(Action);
                newDetail.setLevel(level);
                newDetail.setQty(qty);
                newDetail.setPrice(price);

                SQuoteSnapShotL2 snapShotL2;
                if (direct == EsNativeProtocol.QTE_DIRECT_BID) {
                    snapShotL2 = sContract.getBidL2();
                } else {
                    snapShotL2 = sContract.getAskL2();
                }
                switch (action) {
                    case EsNativeProtocol.QTE_DEPTH_ADD:
                        for (int k = snapShotL2.getDataLength() - 1; k > level; k--) {
                            checkArray(k - 1, snapShotL2.getData());
                            checkArray(k, snapShotL2.getData());

                            SQuoteFieldL2 preFieldL2 = snapShotL2.getData().get(k - 1);
                            SQuoteFieldL2 fieldL2 = snapShotL2.getData().get(k);
                            if (preFieldL2.getQty().compareTo(BigInteger.ZERO) > 0) {
                                fieldL2.setPrice(preFieldL2.getPrice());
                                fieldL2.setQty(preFieldL2.getQty());
                            }
                        }
                        checkArray(level, snapShotL2.getData());

                        SQuoteFieldL2 l2 = snapShotL2.getData().get(level, new SQuoteFieldL2());
                        l2.setPrice(price);
                        l2.setQty(qty);
                        break;
                    case EsNativeProtocol.QTE_DEPTH_CHG:
                        checkArray(level, snapShotL2.getData());
                        snapShotL2.getData().get(level, new SQuoteFieldL2()).setPrice(price);
                        snapShotL2.getData().get(level).setQty(qty);
                        break;
                    case EsNativeProtocol.QTE_DEPTH_DEL:
                        for (int k = level; k < snapShotL2.getDataLength(); k++) {
                            snapShotL2.getData().get(k).setQty(BigInteger.ZERO);
                            SQuoteFieldL2 fieldL2 = snapShotL2.getData().get(k + 1);
                            if (fieldL2 == null || fieldL2.getQty().compareTo(BigInteger.ZERO) <= 0) {
                                break;
                            }
                            snapShotL2.getData().get(k).setPrice(fieldL2.getPrice());
                            snapShotL2.getData().get(k).setQty(fieldL2.getQty());
                        }
                        break;
                    case EsNativeProtocol.QTE_DEPTH_CLR:
                        snapShotL2.setData(null);
                        break;
                    default:
                        break;
                }
            }
            QuoteEvent event = new QuoteEvent.Builder(EsDataConstant.S_SRVEVENT_QUOTE).setContractNo(contractNo).buildEvent();
            sendEvent(event);
        }
    }

    private void checkArray(SparseArray<SQuoteField> array, int index) {
        if (array.get(index) == null) {
            array.put(index, new SQuoteField());
        }
    }

    private void checkArray(int index, SparseArray<SQuoteFieldL2> array) {
        if (array.get(index) == null) {
            array.put(index, new SQuoteFieldL2());
        }
    }
    
    private void OnUserRightData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, RegUserCommGroupQryRsp> userCommonGroupMap = EsQuoteData.getInstance().getUserCommGroupMap();
        Map<String, RegUserPluginQryRsp> userPluginMap = EsQuoteData.getInstance().getUserPluginMap();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            QteUserRightDataRsp rsp = QteUserRightDataRsp.toParse(struct);

            if (rsp.getRightType() == EsQuoteProtocol.QTE_USERRIGHT_GROUP) {
                RegUserCommGroupQryRsp content = new RegUserCommGroupQryRsp();
                content.setBeginDate(rsp.getBeginDate());
                content.setExpireDate(rsp.getExpireData());
                content.setUserNo(rsp.getUserName());
                content.setGroupNo(rsp.getRightNo());

                if (userCommonGroupMap.get(content.getGroupNo()) == null) {
                    userCommonGroupMap.put(content.getGroupNo(), content);
                }
            } else if (rsp.getRightType() == EsQuoteProtocol.QTE_USERRIGHT_PLUGIN){
                RegUserPluginQryRsp content = new RegUserPluginQryRsp();
                content.setBeginDate(rsp.getBeginDate());
                content.setEndDate(rsp.getExpireData());
                content.setUserNo(rsp.getUserName());
                content.setPluginNo(rsp.getRightNo());

                if (userPluginMap.get(content.getPluginNo()) == null) {
                    userPluginMap.put(content.getPluginNo(), content);
                }
            }
        }
    }

    private void stockContData(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        Map<String, QteStockContData> stockContMap = EsQuoteData.getInstance().getStockContData();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            String contractId = util.getString(51);
            double contractDot = util.getDouble();
            QteStockContData stockContData = new QteStockContData();
            stockContData.setContractId(contractId);
            stockContData.setContractDot(contractDot);

            stockContMap.put(contractId, stockContData);
        }
    }

    private void stockContRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            onSendQuoteCompleted(EsQuoteProtocol.STOCK_CONTRACT_COMPLETED_FLAG);
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_CHARGE_COMMODITY_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void OnChargeCommodity(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        Map<String, SChargeInfo> chargeCommodityMap = EsQuoteData.getInstance().getChargeCommodityMap();
        Map<String, RegUserCommGroupQryRsp> userCommGroupMap = EsQuoteData.getInstance().getUserCommGroupMap();
        List<String> chargeExchangeList = EsQuoteData.getInstance().getChargeExchageList();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            SChargeInfo chargeInfo = new SChargeInfo();
            String commodityNo = util.getString(21);
            String groupNo = util.getString(21);
            chargeInfo.setCommodityNo(commodityNo);
            chargeInfo.setGroupNo(groupNo);
            if (userCommGroupMap.containsKey(groupNo)) {
                chargeInfo.setIsPay(true);
            } else {
                chargeInfo.setIsPay(false);
            }
            String exchangeNo;
            if (commodityNo.contains("|")) {
                exchangeNo = commodityNo.substring(0, commodityNo.indexOf("|"));
            } else {
                exchangeNo = commodityNo;
            }
            chargeInfo.setExchangeNo(exchangeNo);
            chargeCommodityMap.put(commodityNo, chargeInfo);

            //TODO 收费交易所数据存储
            if (!chargeExchangeList.contains(exchangeNo) && !chargeInfo.getIsPay()) {
                chargeExchangeList.add(exchangeNo);
            }
        }
    }

    private void chargeCommodityRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            onSendQuoteCompleted(EsQuoteProtocol.CHARGE_COMMODITY_COMPLETED_FLAG);
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_CHARGE_COMMODITY_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void optionExpireData(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        Map<String, Commodity> commodityMap = EsQuoteData.getInstance().getCommodityMap();
        ConcurrentHashMap<String, List<OptionSeries>> optionSeriesByCommodityNoMap = EsQuoteData.getInstance().getOptionSeriesByCommodityNoMap();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            // 对应 QteOptionExpireData
            String optionSerialId = util.getString(51);
            long expireDate = util.getUnsignedInt();
            String underlyContId = util.getString(51);

            // 没有 targetContract 则过滤
            if (EsQuoteData.getInstance().getContractMap().get(underlyContId) == null) {
                continue;
            }

            String commodityNo = optionSerialId.substring(0, optionSerialId.lastIndexOf("|"));

            OptionSeries optionSeries = new OptionSeries();
            optionSeries.setSeriesNo(optionSerialId);
            optionSeries.setExpiryDate(expireDate);
//            optionSeries.setCommodity(commodityMap.get(commodityNo));
            optionSeries.setCommodity(CodeTable.getInstance().getCommodity(commodityNo));
            optionSeries.setTargetContract(EsQuoteData.getInstance().getContractMap().get(underlyContId));

            List<OptionSeries> list = optionSeriesByCommodityNoMap.get(commodityNo);
            if (list == null) {
                list = new ArrayList<>();
            }
            list.add(optionSeries);
            optionSeriesByCommodityNoMap.put(commodityNo, list);
        }
        EsQuoteData.getInstance().setOptionSeriesByCommodityNoMap(optionSeriesByCommodityNoMap);
    }

    private void optionExpireRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            onSendQuoteCompleted(EsQuoteProtocol.OPTION_EXPIRE_COMPLETED_FLAG);
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_OPTION_EXPIRE_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void contractNameData(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            int len1 = util.getUnsignedChar();
            String contractNo = util.getString(len1);
            int len2 = util.getUnsignedChar();
            String contractName = util.getString(len2);

            Contract contract = contractMap.get(contractNo);
            if (contract != null) {
                contract.setContractName(contractName);
            } else {
                EsLog.d(TAG, "contractNameData contract : %s is not exit , name is : %s", contractNo, contractName);
            }
        }
    }

    private void contractNameRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            onSendQuoteCompleted(EsQuoteProtocol.CONTRACT_NAME_COMPLETED_FLAG);

            mIsCompleteContractName = true;
            syncContractInfoToDB();
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_CONT_NAME_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void contractUnderlyData(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        Map<String, Contract> contractUnderLyMap = EsQuoteData.getInstance().getContractUnderLyMap();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            int len1 = util.getUnsignedChar();
            String virtualcontractNo = util.getString(len1);
            int len2 = util.getUnsignedChar();
            String realContractNo = util.getString(len2);
            if (virtualcontractNo != null && EsQuoteData.getInstance().getContractMap().get(realContractNo) != null) {
                contractUnderLyMap.put(virtualcontractNo, EsQuoteData.getInstance().getContractMap().get(realContractNo));
            }
        }
    }

    private void contractUnderlyRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            onSendQuoteCompleted(EsQuoteProtocol.CONTRACT_UNDERLAY_COMPLETED_FLAG);

            mIsCompleteContractUnderly = true;
            syncContractInfoToDB();
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_CONT_UNDERLY_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    /**
     * 合约数据结果应答
     */
    private void contractData(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            int len = util.getUnsignedChar();
            String contractNo = util.getString(len);

            String commodityId = contractNo.substring(0, contractNo.lastIndexOf("|"));

            Contract contract = new Contract();
            contract.setContractNo(contractNo);
//            contract.setCommodity(EsQuoteData.getInstance().getCommodityMap().get(commodityId));
            contract.setCommodity(CodeTable.getInstance().getCommodity(commodityId));
            contract.setContractName(getContractNameByCommodity(contractNo, EsQuoteData.getInstance().getCommodityMap().get(commodityId)));
            contractMap.put(contractNo, contract);

            // 存储期权品种和相对应的合约列表
            if (commodityId.contains("|O|")) {
                ConcurrentHashMap<String, List<Contract>> map = EsQuoteData.getInstance().getContractByOptionCommodityNoMap();
                List<Contract> contractList = map.get(commodityId);
                if (contractList == null) {
                    contractList = new ArrayList<>();
                }
                contractList.add(contract);
                map.put(commodityId, contractList);
                EsQuoteData.getInstance().setContractByOptionCommodityNoMap(map);
            } else {
                // 存储普通品种和相对应的合约列表
                ConcurrentHashMap<String, List<Contract>> map = EsQuoteData.getInstance().getContractByCommodityNoMap();
                List<Contract> contractList = map.get(commodityId);
                if (contractList == null) {
                    contractList = new ArrayList<>();
                }
                contractList.add(contract);
                map.put(commodityId, contractList);
                EsQuoteData.getInstance().setContractByCommodityNoMap(map);
            }
        }

        EsQuoteData.getInstance().setContractMap(contractMap);
    }

    private String getContractNameByCommodity(String contractNo, Commodity commodity) {
        if (commodity == null || contractNo == null) {
            return null;
        }
        String[] strArray = contractNo.split("\\|");

        String type = strArray[strArray.length - 1];
        String typeStr = "type";
        int languageInApp = EsDataApi.getLanguageType();

        if ("MAIN".equals(type)) {
            if (languageInApp == EsDataConstant.S_ANDROID_CHS) {
                typeStr = "主连";
            } else if (languageInApp == EsDataConstant.S_ANDROID_CHT) {
                typeStr = "主連";
            }
        } else if ("INDEX".equals(type)) {
            if (languageInApp == EsDataConstant.S_ANDROID_CHS) {
                typeStr = "指数";
            } else if (languageInApp == EsDataConstant.S_ANDROID_CHT) {
                typeStr = "指數";
            }
        } else if ("NEARBY".equals(type)) {
            if (languageInApp == EsDataConstant.S_ANDROID_CHS) {
                typeStr = "近月";
            } else if (languageInApp == EsDataConstant.S_ANDROID_CHT) {
                typeStr = "近月";
            }
        } else if (type.contains("SUM")) {
            typeStr = "";
        } else if (strArray.length == 5) {
            // 套利合约, SPD|s|SA|009|101
            typeStr = strArray[strArray.length - 2] + "|" + strArray[strArray.length - 1];
        } else {
            // 合约交割日期
            typeStr = strArray[strArray.length - 1];
        }

        String commodityName = commodity.getCommodityName();

        return commodityName + typeStr;
    }

    /**
     * 合约请求结果应答
     */
    private void contractRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            commodityLink();
            quoteQryReq(EsQuoteProtocol.CMD_QTE_OPTION_EXPIRE_REQ, QteOptionExpireReq.class, QteOptionExpireReq.STRUCT_LENGTH);
            quoteQryReq(EsQuoteProtocol.CMD_QTE_CONT_UNDERLY_REQ, QteContUnderlyReq.class, QteContUnderlyReq.STRUCT_LENGTH);
            onSendQuoteCompleted(EsQuoteProtocol.CONTRACT_COMPLETED_FLAG);
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_CONTRACT_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    /**
     * 品种关联
     */
    private void commodityLink() {

    }

    /**
     * 品种请求结果应答
     */
    private void commodityRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            onSendQuoteCompleted(EsQuoteProtocol.COMMODITY_COMPLETED_FLAG);
            sendContractReq();

            if ((CodeTable.getInstance().getUpdateCode() & EsQuoteProtocol.COMMODITY_COMPLETED_FLAG) == EsQuoteProtocol.NONE_FLAG) {
                syncQuoteDataToDB(EsQuoteProtocol.COMMODITY_COMPLETED_FLAG);
            }
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_COMMODITY_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void commodityData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, Commodity> commodityMap = EsQuoteData.getInstance().getCommodityMap();
        List<Commodity> commodityList = EsQuoteData.getInstance().getOptionCommodityList();

        byte[] struct = new byte[len];
        ParseUtil util = ParseUtil.wrap(struct);
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            util.clearWrap(struct);
            Commodity commodity = new Commodity();
            commodity.setCommodityNo(util.getString(21));
//            commodity.setExchange(EsQuoteData.getInstance().getExchangeMap().get(util.getString(11)));
            commodity.setExchange(CodeTable.getInstance().getExchange(util.getString(11)));
//            commodity.setCurrency(EsQuoteData.getInstance().getCurrencyMap().get(util.getString(11)));
            commodity.setCurrency(CodeTable.getInstance().getCurrency(util.getString(11)));
            commodity.setCommodityName(util.getString(51));
            commodity.setTradeDot(util.getDouble());
            commodity.setOptionProperty(util.getChar());
            commodity.setSpreadDirect(util.getChar());
            commodity.setOptionExercise(util.getChar());
            commodity.setCoverMode(util.getChar());
            commodity.setPriceNume(util.getDouble());
            commodity.setPriceDeno(util.getUnsignedShort());
            commodity.setPriceTick(commodity.getPriceNume() / commodity.getPriceDeno());
            commodity.setPricePrec((short) calPrice(commodity.getPriceNume()));
            commodity.setPriceMultiple(util.getFloat());
            commodity.setExerciseDot(util.getDouble());
            util.getString(51);
            util.getString(51);
            util.getString(11);
            commodity.setMaxSingleOrderQty(BigInteger.valueOf(util.getInt()));
            commodity.setMaxPositionQty(BigInteger.valueOf(util.getInt()));
            commodity.setTargetCommodity1(util.getString(21));
            commodity.setTargetCommodity2(util.getString(21));
            commodity.setTargetContract1(commodity.getTargetCommodity1());
//            util.getString(21);
//            util.getString(21);
//            util.getChar();
//            util.getChar();
//            util.getChar();
//            util.getDouble();
//            util.getDouble();
//            util.getDouble();
//            util.getDouble();
//            util.getInt();
//            util.getInt();
//            util.getInt();
//            util.getInt();

            commodityMap.put(commodity.getCommodityNo(), commodity);
            if (commodity.getCommodityNo().contains("|O|")) {
                // 含有|O|的不一定是期权品种，期权品种还需要有对应的 targetContract.
                commodityList.add(commodity);
            }
        }

        // 需要对期权品种排序
        Collections.sort(commodityList, new Comparator<Commodity>() {
            @Override
            public int compare(Commodity o1, Commodity o2) {
                return optionExchangeList.indexOf(o1.getExchange().getExchangeNo()) - optionExchangeList.indexOf(o2.getExchange().getExchangeNo());
            }
        });
        EsQuoteData.getInstance().setCommodityMap(commodityMap);
        EsQuoteData.getInstance().setOptionCommodityList(commodityList);
    }

    private int calPrice(double price) {
        for (int i = 0; i < 10; i++) {
            double value = price * Math.pow(10, i);
            if (value - Math.floor(value) < 0.0000000001) {
                return i;
            }
        }
        return 9;
    }


    /**
     * 交易所请求结果应答
     */
    private void exchangeRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            onSendQuoteCompleted(EsQuoteProtocol.EXCHANGE_COMPLETED_FLAG);
            onSendCommodityReq();

            if ((CodeTable.getInstance().getUpdateCode() & EsQuoteProtocol.EXCHANGE_COMPLETED_FLAG) == EsQuoteProtocol.NONE_FLAG) {
//                QuoteEvent event = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_SYNC_DATA_CODE)
//                        .setSrvErrorCode(EsQuoteProtocol.EXCHANGE_COMPLETED_FLAG).buildEvent();
//                sendEvent(event);
                syncQuoteDataToDB(EsQuoteProtocol.EXCHANGE_COMPLETED_FLAG);
            }
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_EXCHANGE_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void exchangeData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

//        Map<String, Exchange> exchangeMap = new HashMap<>((int) (count / 0.75));
        Map<String, Exchange> exchangeMap = EsQuoteData.getInstance().getExchangeMap();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            Exchange rsp = QteExchangeData.toExchange(struct);
            if (rsp == null) {
                continue;
            }

            exchangeMap.put(rsp.getExchangeNo(), rsp);
        }

        EsQuoteData.getInstance().setExchangeMap(exchangeMap);
    }

    /**
     * 币种请求结果应答
     */
    private void currencyRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            onSendQuoteCompleted(EsQuoteProtocol.CURRENCY_COMPLETED_FLAG);
            onSendCommodityReq();

            syncQuoteDataToDB(EsQuoteProtocol.CURRENCY_COMPLETED_FLAG);
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_CURRENCY_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void syncContractInfoToDB() {
        if (mIsCompleteContractUnderly && mIsCompleteContractName) {
            syncQuoteDataToDB(EsQuoteProtocol.CONTRACT_COMPLETED_FLAG);

            mIsCompleteContractName = false;
            mIsCompleteContractUnderly = false;
        }
    }

    private void syncQuoteDataToDB(final int type) {
        EsLog.d(TAG, "syncCodeTableData = " + type);
        if (!CodeTable.getInstance().getIsSaveCodeDataLocally()) {
            return;
        }

        SimpleRunnable simpleRunnable = new SimpleRunnable() {
            @Override
            public void run() {
                CodeTable.getInstance().saveDataToDB(type);
            }
        };

        TaskManager.getInstance().execute(simpleRunnable);
    }

    private void currencyData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

//        Map<String, Currency> currencyMap = new HashMap<>((int) (count / 0.75));
        Map<String, Currency> currencyMap = EsQuoteData.getInstance().getCurrencyMap();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            Currency rsp = QteCurrencyData.toCurrency(struct);
            if (rsp == null) {
                continue;
            }

            currencyMap.put(rsp.getCurrencyNo(), rsp);
        }

        EsQuoteData.getInstance().setCurrencyMap(currencyMap);
    }

    /**
     * 请求品种需要先请求好币种和交易所
     */
    private void onSendCommodityReq() {
        int dataFlag = EsQuoteData.getInstance().getQuoteDataFlag();
        int completeFlag = EsQuoteProtocol.CURRENCY_COMPLETED_FLAG | EsQuoteProtocol.EXCHANGE_COMPLETED_FLAG;
        if ((dataFlag & completeFlag) != completeFlag) {
            return;
        }

        // 已完成币种，交易所请求
        int updateCode = CodeTable.getInstance().getUpdateCode();
        if ((updateCode & EsQuoteProtocol.COMMODITY_COMPLETED_FLAG) == EsQuoteProtocol.COMMODITY_COMPLETED_FLAG) {
            // 码表已有品种数据
            onSendQuoteCompleted(EsQuoteProtocol.COMMODITY_COMPLETED_FLAG);

            sendContractReq();
        } else {
            CspSessionHead head = CspSessionHead.getCspSessionHead(EsQuoteProtocol.CMD_QTE_COMMODITY_REQ,
                    EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, QteCommodityReq.STRUCT_LENGTH);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, new QteCommodityReq().beanToByte());
        }
    }

    private void quoteQryReq(int protocolCode, Class apiStructClass, int struchLength) {
        ApiStruct apiStruct = null;
        try {
            apiStruct = (ApiStruct) apiStructClass.newInstance();
        } catch (IllegalAccessException | InstantiationException e) {
            e.printStackTrace();
        }
        if (apiStruct == null) {
            return;
        }

        CspSessionHead head = CspSessionHead.getCspSessionHead(protocolCode, EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, struchLength);
        sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, apiStruct.beanToByte());
    }

    private void hisQuoteQryReq(int protocolCode, Class apiStructClass, int struchLength) {
        ApiStruct apiStruct = null;
        try {
            apiStruct = (ApiStruct) apiStructClass.newInstance();
        } catch (IllegalAccessException | InstantiationException e) {
            e.printStackTrace();
        }
        if (apiStruct == null) {
            return;
        }

        CspSessionHead head = CspSessionHead.getCspSessionHead(protocolCode, EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, struchLength);
        sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, apiStruct.beanToByte());
    }

    private void onSendQuoteCompleted(int statusFlag) {
        Log.d(TAG, "quote completed flag : " + statusFlag);
        int result = EsQuoteData.getInstance().getQuoteDataFlag() | statusFlag;
        EsQuoteData.getInstance().setQuoteDataFlag(result);
        synchronized (EsQuoteDispatcher.class) {
            if (result == EsQuoteProtocol.SUCCESS_COMPLETED_FLAG) {
                QuoteEvent event = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_QINITCOMPLETED).setSrvErrorCode(0).buildEvent();
                sendEvent(event);

                if (!EsQuoteData.getInstance().getQuoteStatus()) {
                    TaskManager.getInstance().execute(new SimpleRunnable() {
                        @Override
                        public void run() {
                            doOptionSeries();
                        }
                    });

                }

                // 结束重置状态
                EsQuoteData.getInstance().setQuoteStatus(true);
                EsQuoteData.getInstance().setQuoteDataFlag(EsQuoteProtocol.NONE_FLAG);
            }
        }
    }

    private void doOptionSeries() {
        Map<String, Commodity> commodityMap = EsQuoteData.getInstance().getCommodityMap();
        List<Commodity> optionCommodityList = EsQuoteData.getInstance().getOptionCommodityList();
        Map<String, Contract> contractMap = EsQuoteData.getInstance().getContractMap();

        Map<String, List<OptionSeries>> optionSeriesByCommodityNoMap = EsQuoteData.getInstance().getOptionSeriesByCommodityNoMap();

        for (Commodity optionCommodity : optionCommodityList) {
            Commodity targetCommodity1 = commodityMap.get(optionCommodity.getTargetCommodity1());
            Contract targetContract1 = contractMap.get(optionCommodity.getTargetContract1());
            if (targetCommodity1 == null && targetContract1 == null) {
                continue;
            }

            List<Contract> contractList = EsQuoteData.getInstance().getContractByOptionCommodityNoMap().get(optionCommodity.getCommodityNo());
            if (contractList == null || contractList.size() == 0) {
                continue;
            }

            List<OptionSeries> optionSeriesList = optionSeriesByCommodityNoMap.get(optionCommodity.getCommodityNo());
            List<String> seriesNoList = new ArrayList<>();

            StringBuilder buffer = new StringBuilder();

            String pattern = ".+\\d+C\\d+$";
            for (Contract contract : contractList) {
                if (contract == null) continue;

                String contractNo = contract.getContractNo();

                if (!Pattern.matches(pattern, contractNo)) continue;

                int cIndex = contractNo.lastIndexOf("C");
                String seriesNo = contractNo.substring(0, cIndex);
                String strikePrice = contractNo.substring(cIndex + 1);

                if (!seriesNoList.contains(seriesNo)) {
                    seriesNoList.add(seriesNo);
                }

                OptionContractPair optionContractPair = new OptionContractPair();
                optionContractPair.setStrikePrice(strikePrice);
                optionContractPair.setContract1(contract);
                buffer.setLength(0);
                buffer.append(seriesNo).append("P").append(strikePrice);
                String contract2No = buffer.toString();
//                optionContractPair.setContract2(getContract(contract2No, true));
                optionContractPair.setContract2(contractMap.get(contract2No));

                Map<String, List<OptionContractPair>> optionContractPairByOptionSeriesNoMap = EsQuoteData.getInstance().getOptionContractPairByOptionSeriesNoMap();
                List<OptionContractPair> optionContractPairList = optionContractPairByOptionSeriesNoMap.get(seriesNo);
                if (optionContractPairList == null) {
                    optionContractPairList = new ArrayList<>();
                }
                optionContractPairList.add(optionContractPair);
                optionContractPairByOptionSeriesNoMap.put(seriesNo, optionContractPairList);
            }

            if (optionSeriesList != null) {
                // 筛选没有对应期权合约的期权系列
                List<OptionSeries> realOptionSeriesList = new ArrayList<>();
                for (String seriesNo : seriesNoList) {
                    OptionSeries optionSeries = getSeries(seriesNo, optionSeriesList);
                    if (optionSeries != null) {
                        realOptionSeriesList.add(optionSeries);
                    } else {
                        OptionSeries series = new OptionSeries();
//                        series.setCommodity(commodityMap.get(optionCommodity.getCommodityNo()));
                        series.setCommodity(CodeTable.getInstance().getCommodity(optionCommodity.getCommodityNo()));
                        Contract targetContract = targetContract1;
                        if (targetContract == null) {
                            String targetContractNo = seriesNo.replace("|O|", "|F|");
                            targetContract = contractMap.get(targetContractNo);
                            if (targetContract == null) {
                                targetContract = EsQuoteData.getInstance().getContractUnderLyMap().get(targetContractNo);
                            }
                        }
                        series.setTargetContract(targetContract);
                        series.setSeriesNo(seriesNo);
                        realOptionSeriesList.add(series);
                    }
                }

                optionSeriesByCommodityNoMap.put(optionCommodity.getCommodityNo(), realOptionSeriesList);
            }

            // 需要对执行价排序，有时候接收到的顺序不是按大小顺序来的
            Map<String, List<OptionContractPair>> optionContractPairByOptionSeriesNoMap = EsQuoteData.getInstance().getOptionContractPairByOptionSeriesNoMap();
            for (String stringSet : optionContractPairByOptionSeriesNoMap.keySet()) {
                List<OptionContractPair> optionContractPairs = optionContractPairByOptionSeriesNoMap.get(stringSet);
                Collections.sort(optionContractPairs, new Comparator<OptionContractPair>() {
                    @Override
                    public int compare(OptionContractPair o1, OptionContractPair o2) {
                        return Double.compare(Double.parseDouble(o1.getStrikePrice()), Double.parseDouble(o2.getStrikePrice()));
                    }
                });
            }
        }
        QuoteEvent.Builder builder = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_OPTIONCOMPLETED);
        sendEvent(builder.buildEvent());
    }

    private OptionSeries getSeries(String seriesNo, List<OptionSeries> optionSeriesList) {
        OptionSeries res = null;
        if (seriesNo == null || optionSeriesList == null) {
            return res;
        }

        for (OptionSeries optionSeries : optionSeriesList) {
            if (seriesNo.equals(optionSeries.getSeriesNo())) {
                res = optionSeries;
                break;
            }
        }
        return res;
    }

    private int disPatchHisQuote(char action, byte[] data) {

        if (action == EVENT_TCP_CONNECT) {
            HisQuoteEvent.Builder builder = new HisQuoteEvent.Builder(EsEventConstant.S_SRVEVENT_HISQUOTE);
            sendEvent(builder.buildEvent());

            if (!EsApiData.getInstance().getLoginState()) {
                return 0;
            }
            loginHisQuote();
            return 0;
        }

        if (action == EVENT_TCP_DISCONNECT) {
            return 0;
        }

        if (action == EVENT_TCP_RESET_DATA) {
            return 0;
        }

        byte[] headArr = new byte[CspSessionHead.STRUCT_LENGTH];
        System.arraycopy(data, 0, headArr, 0, CspSessionHead.STRUCT_LENGTH);

        int dataLen = data.length - CspSessionHead.STRUCT_LENGTH;
        byte[] buf = new byte[dataLen];
        System.arraycopy(data, CspSessionHead.STRUCT_LENGTH, buf, 0, dataLen);
        CspSessionHead head = new CspSessionHead(headArr);

        switch (head.getProtocolCode()) {
            //历史行情
            case EsQuoteProtocol.CMD_QTE_KLINE_RSP:
                onKLineRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_KLINE_DATA_RSP:
                onKLineData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_LOGON_RSP:
                onLoginHisQuote(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_TIME_BUCKET_RSP:
                timeBucketRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_TIME_BUCKET_DATA_RSP:
                timeBucketData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_COMM_TIME_BUCKET_RSP:
                commTimeBucketRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_COMM_TIME_BUCKET_DATA_RSP:
                commTimeBucketData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_HIS_COMMODITY_TEMPLATE_RSP:
                hisCommodityTemplateRsp(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_HIS_COMMODITY_TEMPLATE_DATA_RSP:
                hisCommodityTemplateData(buf, head);
                break;
            case EsQuoteProtocol.CMD_QTE_CONTRACT_RSP:
                contractSortData(buf, head);
                break;
        }
        return 0;
    }

    private boolean changeContract(String contractNo) {
        String[] split = contractNo.split("\\|");
        if (split.length <= 3) {
            return false;
        }
        if (split[1].equals(String.valueOf(EsDataConstant.QTE_COMM_TYPE_FUTURES))) {
            int length = split[3].length();
            for (int i = 0; i < length; i++) {
                if (!Character.isDigit(split[3].charAt(i))) {
                    return false;
                }
            }
            return length == 3 || length == 4;
        }
        return false;
    }

    private String getPrevContract(String contractNo) {
        String[] split = contractNo.split("\\|");
        int index = contractNo.lastIndexOf("|");
        char[] charArray = contractNo.toCharArray();
        int length = split[3].length();
        if (length == 3) {
            char c1 = contractNo.charAt(index + 1);
            if (c1 <= '0') {
                charArray[index + 1] = '9';
            } else {
                charArray[index + 1] -= 1;
            }
        } else if (length == 4) {
            char c1 = contractNo.charAt(index + 2);
            if (c1 <= '0') {
                charArray[index + 2] = '9';
                charArray[index + 1] -= 1;
            } else {
                charArray[index + 2] -= 1;
            }
        }
        return String.copyValueOf(charArray);
    }

    private void onKLineRsp(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        ParseUtil util = ParseUtil.wrap(buf);

        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_NOT_END) {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_KLINE_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        } else {
            Map<String, SHisQuoteDef> hisQuoteDefMap = EsQuoteData.getInstance().getSHisQuoteDefMap();
            Map<String, SHisQuoteMinuteDef> hisQuoteMinuteDefMap = EsQuoteData.getInstance().getSHisQuoteMinuteDefMap();

            String sessionId = String.valueOf(head.getSessionId());
//            SHisQuoteMinuteDef hisQuoteMinuteDef = hisQuoteMinuteDefMap.get(sessionId);
//            SHisQuoteDef hisQuoteDef = hisQuoteDefMap.get(sessionId);
//            if (hisQuoteMinuteDef != null) {
//                hisQuoteMinuteDef.setMSessionId(EsDataConstant.S_MAX_SESSION_ID);
//                return;
//            }
//            if (hisQuoteDef == null) {
//                return;
//            }
            for (int i = 0; i < count; i++) {
                int hopeCount = util.getInt();
                String contractId = util.getString(51);
                char kLineType = util.getChar();
                long beginTime = util.getLong();
                long endTime = util.getLong();

                SHisQuoteDef hisQuoteDef = hisQuoteDefMap.get(contractId);


                if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_MINUTE) {
                    String mContractNo = hisQuoteDef.getMContractNo();
                    String contractNo = hisQuoteDef.getContractNo();
                    long SessionId = hisQuoteDef.getSessionId();
                    long mSessionId = hisQuoteDef.getMSessionId();
                    int mStartIndex = hisQuoteDef.getMStartIndex();
                    int mEndIndex = hisQuoteDef.getMEndIndex();
                    int mReqCount = hisQuoteDef.getMReqCount();
                    char mReqKlineType = hisQuoteDef.getMReqKlineType();
                    long mDateTime = hisQuoteDef.getMDateTime();
                    hisQuoteDef.setMInQryDataProcess(0);

                    if (hisQuoteDef.getMRspCount() > 0) {
                        hisQuoteDef.setMSessionId(SessionId);//代表重组合约后依然能获取到数据
                        hisQuoteDef.setMReqCount(mReqCount - hisQuoteDef.getMRspCount());
                    } else {
                        if (mSessionId == SessionId) {//当前的MContractNo没有数据了，之前是有数据的
                            hisQuoteDef.setMSessionId(mSessionId + 1);
                        } else if (mSessionId - SessionId == 1) {
                            if (changeContract(mContractNo)) {
                                mContractNo = getPrevContract(mContractNo);
                                hisQuoteDef.setMContractNo(mContractNo);
                                hisQuoteDef.setMSessionId(mSessionId + 1);//代表合约重组过了
                                hisQuoteDefMap.put(mContractNo, hisQuoteDef);
                            } else {
                                hisQuoteDef.setMSessionId(EsDataConstant.S_MAX_SESSION_ID);
                            }
                        } else {
                            hisQuoteDef.setMSessionId(EsDataConstant.S_MAX_SESSION_ID);
                        }
                        if (mEndIndex - mStartIndex < EsNativeProtocol.HOPE_MINUTE_LINE_COUNT && mSessionId == EsDataConstant.S_MAX_SESSION_ID) {
                            HisQuoteEvent.Builder builder = new HisQuoteEvent.Builder(EsEventConstant.S_SRVEVENT_HISQUOTE);
                            builder.setContractNo(contractNo);
                            builder.setKLineType(kLineType);
                            builder.setSessionId(sessionId);
                            sendEvent(builder.buildEvent());
                        }
                    }
                    if (hisQuoteDef.getMReqCount() > 0) {
                        if (mSessionId != EsDataConstant.S_MAX_SESSION_ID && hisQuoteDef.getMInQryDataProcess() == 0) {
                            hisQuoteDef.setMInQryDataProcess(1);
                            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_KLINE_REQ);
                            head.setSessionId(SessionId);
                            QteKLineReq qteKLineReq = new QteKLineReq();
                            qteKLineReq.setHopeCount(hisQuoteDef.getMReqCount() - 1);
                            qteKLineReq.setKLineType(kLineType);
                            qteKLineReq.setEndTime(mDateTime);
                            qteKLineReq.setContractId(mContractNo);
                            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, qteKLineReq.beanToByte());
                        }
                    } else if (mReqKlineType == '1') {
                        HisQuoteEvent.Builder builder = new HisQuoteEvent.Builder(EsEventConstant.S_SRVEVENT_HISQUOTE);
                        builder.setContractNo(contractNo);
                        builder.setKLineType(kLineType);
                        builder.setSessionId(sessionId);
                        sendEvent(builder.buildEvent());
                    }
                    hisQuoteDef.setMRspCount(0);
                } else if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_DAY) {
                    String dContractNo = hisQuoteDef.getDContractNo();
                    String contractNo = hisQuoteDef.getContractNo();
                    long SessionId = hisQuoteDef.getSessionId();
                    long dSessionId = hisQuoteDef.getDSessionId();
                    int dStartIndex = hisQuoteDef.getDStartIndex();
                    int dEndIndex = hisQuoteDef.getDEndIndex();
                    int dReqCount = hisQuoteDef.getDReqCount();
                    int dRspCount = hisQuoteDef.getDRspCount();
                    char dReqKlineType = hisQuoteDef.getDReqKlineType();
                    long dDateTime = hisQuoteDef.getDDateTime();
                    hisQuoteDef.setDInQryDataProcess(0);
                    if (dRspCount > 0) {
                        hisQuoteDef.setDSessionId(SessionId);
                        hisQuoteDef.setDReqCount(dReqCount - dRspCount);
                    } else {
                        if (dSessionId == SessionId) {
                            hisQuoteDef.setDSessionId(dSessionId + 1);
                        } else if (dSessionId - SessionId == 1) {
                            if (changeContract(dContractNo)) {
                                dContractNo = getPrevContract(dContractNo);
                                hisQuoteDef.setDContractNo(dContractNo);
                                hisQuoteDef.setDSessionId(dSessionId + 1);//代表合约重组过了
                                hisQuoteDefMap.put(dContractNo, hisQuoteDef);
                            } else {
                                hisQuoteDef.setDSessionId(EsDataConstant.S_MAX_SESSION_ID);
                            }
                        } else {
                            hisQuoteDef.setDSessionId(EsDataConstant.S_MAX_SESSION_ID);
                        }
                        if (dEndIndex - dStartIndex < EsNativeProtocol.HOPE_DAY_LINE_COUNT && dSessionId == EsDataConstant.S_MAX_SESSION_ID) {
                            HisQuoteEvent.Builder builder = new HisQuoteEvent.Builder(EsEventConstant.S_SRVEVENT_HISQUOTE);
                            builder.setContractNo(contractNo);
                            builder.setKLineType(kLineType);
                            builder.setSessionId(sessionId);
                            sendEvent(builder.buildEvent());
                        }
                    }
                    if (dReqCount > 0) {
                        if (dSessionId != EsDataConstant.S_MAX_SESSION_ID && hisQuoteDef.getDInQryDataProcess() == 0) {
                            hisQuoteDef.setDInQryDataProcess(1);
                            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_KLINE_REQ);
                            head.setSessionId(SessionId);
                            QteKLineReq qteKLineReq = new QteKLineReq();
                            qteKLineReq.setHopeCount(dReqCount - 1);
                            qteKLineReq.setKLineType(kLineType);
                            qteKLineReq.setEndTime(dDateTime);
                            qteKLineReq.setContractId(dContractNo);
                            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, qteKLineReq.beanToByte());
                        }
                    } else if (dReqKlineType == '1') {
                        HisQuoteEvent.Builder builder = new HisQuoteEvent.Builder(EsEventConstant.S_SRVEVENT_HISQUOTE);
                        builder.setContractNo(contractNo);
                        builder.setKLineType(kLineType);
                        builder.setSessionId(sessionId);
                        sendEvent(builder.buildEvent());
                    }
                    hisQuoteDef.setDRspCount(0);
                } else if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_TICK) {

                } else {

                }
            }
        }
    }

    private void saveKLineData(byte[] data, String sessionId, int count) {
        Map<String, SHisQuoteDef> hisQuoteDefMap = EsQuoteData.getInstance().getSHisQuoteDefMap();

        ParseUtil util = ParseUtil.wrap(data);
        String contractId = util.getString(51);
        char kLineType = util.getChar();
        SHisQuoteDef sHisQuoteDef = hisQuoteDefMap.get(contractId);
        if (sHisQuoteDef == null) {
            return;
        }
        int mRspCount = sHisQuoteDef.getMRspCount();
        int dRspCount = sHisQuoteDef.getDRspCount();
        List<QteKLineData> mOrderLines = sHisQuoteDef.getMOrderLines();
        List<QteKLineData> dOrderLines = sHisQuoteDef.getDOrderLines();
        if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_TICK) {
            for (int i = 0; i < count; i++) {
                QteKLineData lineData = new QteKLineData();
                lineData.setContractId(contractId);
                lineData.setKLineType(kLineType);
                lineData.setKLineIndex(util.getInt());
                lineData.setTradeDate(util.getUnsignedInt());
                lineData.setDateTimeStamp(util.getLongLong());
                lineData.setTotalQty(util.getLongLong());
                lineData.setPositionQty(util.getLongLong());
                lineData.setLastPrice(util.getDouble());

                lineData.setLastQty(util.getUnsignedInt());
                lineData.setPositionChg(util.getInt());
                lineData.setBuyPrice(util.getDouble());
                lineData.setSellPrice(util.getDouble());
                lineData.setBuyQty(util.getLong());
                lineData.setSellQty(util.getLong());
            }
        } else {
            for (int i = 0; i < count; i++) {
                QteKLineData lineData = new QteKLineData();
                lineData.setContractId(contractId);
                lineData.setKLineType(kLineType);
                lineData.setKLineIndex(util.getInt());
                lineData.setTradeDate(util.getUnsignedInt());
                lineData.setDateTimeStamp(util.getLongLong());
                lineData.setTotalQty(util.getLongLong());
                lineData.setPositionQty(util.getLongLong());
                lineData.setLastPrice(util.getDouble());

                lineData.setKLineQty(util.getLongLong());
                lineData.setOpeningPrice(util.getDouble());
                lineData.setHighPrice(util.getDouble());
                lineData.setLowPrice(util.getDouble());
                lineData.setSettlePrice(util.getDouble());
                if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_MINUTE) {
                    if (lineData.getDateTimeStamp().compareTo(BigInteger.ZERO) == 0 || sHisQuoteDef.getMDateTime() > 0 && lineData.getDateTimeStamp().longValue() > sHisQuoteDef.getMDateTime()) {
                        continue;
                    }
                    sHisQuoteDef.setMDateTime(lineData.getDateTimeStamp().longValue());
                    mOrderLines.add(lineData);
                } else {
                    sHisQuoteDef.setDDateTime(lineData.getDateTimeStamp().longValue());
                    dOrderLines.add(lineData);
                }
            }
            if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_MINUTE) {
                sHisQuoteDef.setMRspCount(mRspCount + count);
            } else if (kLineType == EsQuoteConstant.QTE_KLINE_TYPE_DAY) {
                sHisQuoteDef.setDRspCount(dRspCount + count);
            }
        }
        HisQuoteEvent.Builder builder = new HisQuoteEvent.Builder(EsEventConstant.S_SRVEVENT_HISQUOTE);
        builder.setContractNo(contractId);
        builder.setKLineType(kLineType);
        builder.setSessionId(sessionId);
        sendEvent(builder.buildEvent());
    }

    private void onKLineData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();
        String sessionId = String.valueOf(head.getSessionId());

        saveKLineData(buf, sessionId, count);


    }

    private void contractSortData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();
        ContractSortInfo info = new ContractSortInfo();

        ParseUtil util = ParseUtil.wrap(buf);
        char sortType = util.getChar();
        int sortCount = util.getUnsignedShort();
        ArrayList<ContractSortData> sortData = new ArrayList<>();
        for (int j = 0; j < sortCount; j++) {
            ContractSortData dataType = new ContractSortData();
            dataType.setValue(util.getFloat());
            dataType.setContractNo(util.getString(51));
            sortData.add(dataType);
        }
        info.setSortType(sortType);
        info.setCount(sortCount);
        info.setSortData(sortData);

        QuoteEvent.Builder builder = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_CONTRACTSORT).setData(info);
        sendEvent(builder.buildEvent());
    }

    private void hisCommodityTemplateRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_NOT_END) {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_HIS_COMMODITY_TEMPLATE_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void hisCommodityTemplateData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, SHisMinTimeBucket> hisMinTimeBucketDataMap = EsQuoteData.getInstance().getHisMinTimeBucketDataMap();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            String commodityId = util.getString(21);
            String templateNo = util.getString(11);
            long beginDate = util.getUnsignedInt();
            long endDate = util.getUnsignedInt();

            if (hisMinTimeBucketDataMap.containsKey(commodityId)) {
                continue;
            }
            SHisMinTimeBucket hisQuoteTimeBucket = new SHisMinTimeBucket();
            hisQuoteTimeBucket.setCommodityId(commodityId);
            hisQuoteTimeBucket.setTemplateNo(templateNo);
            hisQuoteTimeBucket.setBeginDate(beginDate);
            hisQuoteTimeBucket.setEndDate(endDate);

            hisMinTimeBucketDataMap.put(commodityId, hisQuoteTimeBucket);
        }

        EsQuoteData.getInstance().setHisMinTimeBucketDataMap(hisMinTimeBucketDataMap);
    }

    private void commTimeBucketRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            //计算模板
            calculateTimeBucket();
            QuoteEvent.Builder builder = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_HINITCOMPLETED);
            sendEvent(builder.buildEvent());
            EsQuoteData.getInstance().setHisQuoteStatus(true);

            hisQuoteQryReq(EsQuoteProtocol.CMD_QTE_HIS_COMMODITY_TEMPLATE_REQ, QteCommTimeBucketReq.class, QteCommTimeBucketReq.STRUCT_LENGTH);
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_COMM_TIME_BUCKET_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void calculateTimeBucket() {
        Map<String, STimeBucketDef> timeBucketDefDataMap = EsQuoteData.getInstance().getTimeBucketDefDataMap();
        for (Map.Entry<String, STimeBucketDef> entry : timeBucketDefDataMap.entrySet()) {
            String key = entry.getKey();
            STimeBucketDef timeBucketDef = entry.getValue();
            int baseCount = timeBucketDef.getBaseCount();
            int calCount = timeBucketDef.getCalCount();
            int basePos = 0;
            while (true) {
                if (basePos + 1 >= baseCount) {
                    break;
                }
                SHisQuoteTimeBucket beginTimeBucket = timeBucketDef.getBaseTbs().get(basePos++);
                SHisQuoteTimeBucket endTimeBucket = timeBucketDef.getBaseTbs().get(basePos++);
                char currDateFlag = beginTimeBucket.getDateFlag();
                long currTime = beginTimeBucket.getBeginTime();
                char currTradeState = beginTimeBucket.getTradeState();
                char endDateFlag = endTimeBucket.getDateFlag();
                long endTime = endTimeBucket.getBeginTime();
                char endTradeState = endTimeBucket.getTradeState();
                if (EsQuoteConstant.S_TRADESTATE_CONTINUOUS != currTradeState) {
                    break;
                }
                if (EsQuoteConstant.S_TRADESTATE_PAUSED != endTradeState && EsQuoteConstant.S_TRADESTATE_CLOSE != endTradeState) {
                    break;
                }

                while (true) {
                    ArrayList<Object> ret = addOneMinute(currTime);
                    long nextTime = (long) ret.get(1);
                    if (nextTime > endTime && currDateFlag >= endDateFlag) {
                        break;
                    }

                    List<SHisQuoteTimeBucket> calTbs = timeBucketDef.getCalTbs();
                    SHisQuoteTimeBucket tb = new SHisQuoteTimeBucket();
                    List<SHisQuoteTimeBucket> calTbsByTime = timeBucketDef.getCalTbsByTime();

                    tb.setBeginTime(currTime);
                    tb.setEndTime(nextTime);
                    tb.setDateFlag(currDateFlag);
//                    long qindex = currTime / 100000 % 100 + currTime / 10000000 % 100 * 60;
//                    if (qindex < calTbs.size()) {
                    calTbsByTime.add(tb);
//                    }
                    //开始计数
                    if (currTime == beginTimeBucket.getBeginTime()) {
                        beginTimeBucket.setCalCount(calCount);
                        tb.setTradeState(currTradeState);
                    }
                    //计算
                    tb.setIndex(calTbs.size());
                    //结束计数
                    if (nextTime == endTimeBucket.getBeginTime()) {
                        endTimeBucket.setCalCount(calCount);
                        tb.setTradeState(endTradeState);
                    }
                    currTime = nextTime;
                    currDateFlag += (char) ret.get(0);

                    calTbs.add(tb);
                    timeBucketDef.setCalTbs(calTbs);
                    timeBucketDef.setCalTbsByTime(calTbsByTime);
                    calCount += 1;
                    timeBucketDef.setCalCount(calCount);
                }
            }
            timeBucketDefDataMap.put(key, timeBucketDef);
        }
    }

    private ArrayList<Object> addOneMinute(long t) {
        ArrayList<Object> ret = new ArrayList<>();
        long h = t % 1000000000 / 10000000;
        long n = t % 10000000 / 100000;
        long s = t % 100000 / 100;

        n++;
        char T = '\0';

        if (60 == n) {
            n = 0;
            h++;
            if (24 == h) {
                h = 0;
                T = '\1';
            }
        }

        ret.add(T);
        ret.add((h * 10000 + n * 100 + s) * 1000);
        return ret;
    }

    private void commTimeBucketData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, STimeBucketDef> commTimeBucketMap = EsQuoteData.getInstance().getCommTimeBucketDataMap();
        Map<String, STimeBucketDef> timeBucketDefMap = EsQuoteData.getInstance().getTimeBucketDefDataMap();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            String commodityId = util.getString(21);
            String templateNo = util.getString(11);
            if (commTimeBucketMap.containsKey(commodityId)) {
                continue;
            }
            if (!timeBucketDefMap.containsKey(templateNo)) {
                continue;
            }

            STimeBucketDef timeBucketDef = timeBucketDefMap.get(templateNo);
            commTimeBucketMap.put(commodityId, timeBucketDef);
        }

        EsQuoteData.getInstance().setCommTimeBucketDataMap(commTimeBucketMap);
    }

    /**
     * 时间模板结果应答
     */
    private void timeBucketRsp(byte[] buf, CspSessionHead head) {
        if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            hisQuoteQryReq(EsQuoteProtocol.CMD_QTE_COMM_TIME_BUCKET_REQ, QteCommTimeBucketReq.class, QteCommTimeBucketReq.STRUCT_LENGTH);
        } else {
            head.setProtocolCode(EsQuoteProtocol.CMD_QTE_TIME_BUCKET_REQ);
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, buf);
        }
    }

    private void timeBucketData(byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, STimeBucketDef> timeBucketDefMap = EsQuoteData.getInstance().getTimeBucketDefDataMap();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            String templateNo = util.getString(11);
            long beginTime = util.getUnsignedInt();
            char tradingState = util.getChar();
            char dateFlag = util.getChar();

            SHisQuoteTimeBucket hisQuoteTimeBucket = new SHisQuoteTimeBucket();
            hisQuoteTimeBucket.setDateFlag(dateFlag);
            hisQuoteTimeBucket.setTradeState(tradingState);
            hisQuoteTimeBucket.setBeginTime(beginTime);

            STimeBucketDef timeBucketDef = timeBucketDefMap.get(templateNo);
            if (timeBucketDef == null) {
                timeBucketDef = new STimeBucketDef();
            }
            List<SHisQuoteTimeBucket> baseTabs = timeBucketDef.getBaseTbs();
            hisQuoteTimeBucket.setIndex(baseTabs.size() + 1);
            baseTabs.add(hisQuoteTimeBucket);
            timeBucketDef.setBaseTbs(baseTabs);
            timeBucketDef.setBaseCount(timeBucketDef.getBaseCount() + 1);
            timeBucketDefMap.put(templateNo, timeBucketDef);
        }

        EsQuoteData.getInstance().setTimeBucketDefDataMap(timeBucketDefMap);
    }

    private void onLoginHisQuote(byte[] data, CspSessionHead head) {
        if (head == null || head.getFieldCount() == 0 || data == null) {
            return;
        }

        QteLoginRsp rsp = new QteLoginRsp(data);
        QuoteEvent.Builder builder = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_HISLOGIN).setSrvErrorCode((int) head.getErrorCode());
        if (data.length == QteLoginRsp.STRUCT_LENGTH) {
            builder.setUserNo(rsp.getUserName());
        } else {
            builder.setUserNo("");
        }
        sendEvent(builder.buildEvent());

        if (!EsQuoteData.getInstance().getHisQuoteStatus()) {
            hisQuoteQryReq(EsQuoteProtocol.CMD_QTE_TIME_BUCKET_REQ, QteTimeBucketReq.class, QteTimeBucketReq.STRUCT_LENGTH);
        }
    }

    private void loginHisQuote() {
        QteLoginReq req = new QteLoginReq();
        req.setModuleType('A');
        req.setLicenseNo(EsQuoteProtocol.QTE_DEFAULT_LICENSE_NO_NEW);
        req.setUserName(EsQuoteData.getInstance().getUserNo());
        req.setPassword(EsQuoteData.getInstance().getPassword());
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsQuoteProtocol.CMD_QTE_LOGON_REQ, EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, QteLoginReq.STRUCT_LENGTH);
        sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, req.beanToByte());
    }

    private void loginQuote() {
        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();

        QteLoginReq req = new QteLoginReq();
        req.setModuleType('A');
        req.setLicenseNo(EsQuoteProtocol.QTE_DEFAULT_LICENSE_NO_NEW);
        req.setUserName(userInfo.getLoginNo());
        req.setPassword(userInfo.getPassWord());
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsQuoteProtocol.CMD_QTE_NEW_LOGON_REQ, EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, QteLoginReq.STRUCT_LENGTH);
        sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, req.beanToByte());
    }

    private void onLoginQuote(byte[] data, CspSessionHead head) {
        if (head == null || head.getFieldCount() == 0 || data == null) {
            return;
        }

        QteLoginRsp rsp = new QteLoginRsp(data);
        QuoteEvent.Builder builder = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_QUOTELOGIN).setSrvErrorCode((int) head.getErrorCode());
        if (data.length == QteLoginRsp.STRUCT_LENGTH) {
            builder.setUserNo(rsp.getUserName());
        } else {
            builder.setUserNo("");
        }
        sendEvent(builder.buildEvent());

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        if (head.getErrorCode() != 0) {
            userInfo.setErrorCode((int) (head.getErrorCode()&0x00FFFFFF));
            if (!userInfo.getbCertSuccessed()) {
                userInfo.setLoginNo("");
                userInfo.setPassWord("");
            }

            if (EsQuoteData.getInstance().getQuoteStatus()) {
                QuoteEvent.Builder builder1 = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_REGLOGIN)
                        .setUserNo(userInfo.getLoginNo()).setSrvErrorCode((int) head.getErrorCode());
                String errorMessage =
                        EsDataApi.getErrorMessage("QuoteApi", (int) head.getErrorCode(), "");
                builder1.setSrvErrorText(errorMessage);
                sendEvent(builder1.buildEvent());
            }
            return;
        }

        userInfo.setLoginNo(rsp.getUserName());
        if (!TextUtils.isEmpty(userInfo.getLoginNo())) {
            userInfo.setbCertSuccessed(true);
        }

        qryUserRightInfo();

        if (!EsQuoteData.getInstance().getQuoteStatus()) {
            // 初始登录查询
            sendCurrencyReq();
            sendExchangeReq();
            sendChargeCommodityReq();
            sendContractNameReq();
            sendStockContractReq();
        } else {
            ReSubQuoteAll();
            if (userInfo.getErrorCode() != 0) {
                userInfo.setErrorCode(0);
            } else {
                QuoteEvent.Builder builder2 = new QuoteEvent.Builder(EsEventConstant.S_SRVEVENT_REGLOGIN)
                        .setUserNo(userInfo.getLoginNo()).setSrvErrorCode((int) head.getErrorCode());
                sendEvent(builder2.buildEvent());
            }
        }
    }

//    private void sendEvent(int action, Object data, CspSessionHead head, String errortext) {
//        String errorMessage = EsDataApi.getErrorMessage(tu.getTradeLogin().getAddrTypeNo(), (int) head.getErrorCode(), errortext);
//
//        TradeEvent event = new TradeEvent.Builder(action)
//                .setData(data)
//                .setSrvErrorCode((int) head.getErrorCode())
//                .setSrvErrorText(errorMessage)
//                .buildEvent();
//
//        sendEvent(event);
//    }

    private void ReSubQuoteAll() {
        Map<String, Integer> quoteSubMap =EsQuoteData.getInstance().getQuoteSub();

        for (String contractNo : quoteSubMap.keySet()) {
            QteSnapShotReq qteSnapShotReq = new QteSnapShotReq();
            qteSnapShotReq.setContractId(contractNo);

            CspSessionHead head = CspSessionHead.getCspSessionHead(EsQuoteProtocol.CMD_QTE_SNAPSHOT_SUB,
                    EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, qteSnapShotReq.getStructLength());

            EsDataApi.sendMsg(EsQuoteData.getInstance().getQuoteKey(), EsQuoteProtocol.CSP_FRAME_PLAIN, head, qteSnapShotReq.beanToByte());
        }
    }

    private void sendContractNameReq() {
        int codeFlag = CodeTable.getInstance().getUpdateCode();
        if ((codeFlag & EsQuoteProtocol.CONTRACT_NAME_COMPLETED_FLAG) == EsQuoteProtocol.CONTRACT_NAME_COMPLETED_FLAG) {
            onSendQuoteCompleted(EsQuoteProtocol.CONTRACT_NAME_COMPLETED_FLAG);
        } else {
            quoteQryReq(EsQuoteProtocol.CMD_QTE_CONT_NAME_REQ, QteContractReq.class, QteContractReq.STRUCT_LENGTH);
        }
    }

    private void sendStockContractReq() {
        QteContractReq qteContractReq = new QteContractReq();
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsQuoteProtocol.CMD_QTE_STOCK_CONT_REQ, EsQuoteProtocol.CSP_SUBSYSTEM_QUOTE, QteContractReq.STRUCT_LENGTH);
        sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN, head, qteContractReq.beanToByte());
    }

    private void sendChargeCommodityReq() {
        QteExchangeReq qteExchangeReq = new QteExchangeReq();
        sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN,
                QteExchangeReq.getSessionHead(EsQuoteProtocol.CMD_QTE_CHARGE_COMMODITY_REQ), qteExchangeReq.beanToByte());
    }

    private void sendExchangeReq() {
        int codeFlag = CodeTable.getInstance().getUpdateCode();
        if ((codeFlag & EsQuoteProtocol.EXCHANGE_COMPLETED_FLAG) == EsQuoteProtocol.EXCHANGE_COMPLETED_FLAG) {
            // 码表已有交易所数据
            onSendQuoteCompleted(EsQuoteProtocol.EXCHANGE_COMPLETED_FLAG);
            onSendCommodityReq();
        } else {
            QteExchangeReq qteExchangeReq = new QteExchangeReq();
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN,
                    QteExchangeReq.getSessionHead(EsQuoteProtocol.CMD_QTE_EXCHANGE_REQ), qteExchangeReq.beanToByte());
        }
    }

    private void sendCurrencyReq() {
        int codeFlag = CodeTable.getInstance().getUpdateCode();
        if ((codeFlag & EsQuoteProtocol.CURRENCY_COMPLETED_FLAG) == EsQuoteProtocol.CURRENCY_COMPLETED_FLAG) {
            // 码表已有币种数据
            onSendQuoteCompleted(EsQuoteProtocol.CURRENCY_COMPLETED_FLAG);
            onSendCommodityReq();
        } else {
            QteCurrencyReq qteCurrencyReq = new QteCurrencyReq();
            sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN,
                    QteCurrencyReq.getSessionHead(EsQuoteProtocol.CMD_QTE_CURRENCY_REQ), qteCurrencyReq.beanToByte());
        }
    }

    private void sendContractReq() {
        int updateFlag = CodeTable.getInstance().getUpdateCode();

        if ((updateFlag & EsQuoteProtocol.CONTRACT_COMPLETED_FLAG) == EsQuoteProtocol.CONTRACT_COMPLETED_FLAG) {
            commodityLink();
            quoteQryReq(EsQuoteProtocol.CMD_QTE_OPTION_EXPIRE_REQ, QteOptionExpireReq.class, QteOptionExpireReq.STRUCT_LENGTH);

            onSendQuoteCompleted(EsQuoteProtocol.CONTRACT_COMPLETED_FLAG);
            // 有合约数据代表也有了虚拟真实合约对应关系
            onSendQuoteCompleted(EsQuoteProtocol.CONTRACT_UNDERLAY_COMPLETED_FLAG);
        } else {
            quoteQryReq(EsQuoteProtocol.CMD_QTE_CONTRACT_REQ, QteContractReq.class, QteContractReq.STRUCT_LENGTH);
        }
    }

    private void qryUserRightInfo() {
        SQuoteUserInfo quoteUserInfo = EsApiData.getInstance().getQuoteUserInfo();
        if (quoteUserInfo == null || TextUtils.isEmpty(quoteUserInfo.getLoginNo())) {
            return;
        }

        QteUserRightReq qteUserRightReq = new QteUserRightReq();
        qteUserRightReq.setUserName(quoteUserInfo.getLoginNo());
        sendTcpMsg(EsQuoteProtocol.CSP_FRAME_PLAIN,
                QteUserRightReq.getSessionHead(EsQuoteProtocol.CMD_QTE_USER_RIGHT_REQ), qteUserRightReq.beanToByte());
    }

    private boolean isQuote() {
        return mPtr == EsQuoteData.getInstance().getQuoteKey();
    }

    private boolean isHisQuote() {
        return mPtr == EsQuoteData.getInstance().getHisQuoteKey();
    }
}
