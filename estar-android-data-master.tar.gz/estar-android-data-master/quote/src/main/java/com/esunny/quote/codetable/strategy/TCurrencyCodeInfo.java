package com.esunny.quote.codetable.strategy;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

import com.esunny.data.bean.Currency;
import com.esunny.data.database.gen.TCurrencyDao;
import com.esunny.data.util.EsLog;
import com.esunny.quote.EsQuoteData;
import com.esunny.data.database.DBManager;
import com.esunny.quote.codetable.CodeTable;
import com.esunny.quote.codetable.model.CodeTableModel;
import com.esunny.data.database.table.TCurrency;
import com.esunny.data.database.table.TUpdateManager;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author Peter Fu
 * @date 2020/10/14
 */
public class TCurrencyCodeInfo implements ICodeInfo{
    private static final String TAG = "TCurrencyCodeInfo";

    @Override
    public void saveDBDataToCache(CodeTableModel model) {
        model.saveCurrency();
    }

    @Override
    public void clearDBData(CodeTableModel model) {
        model.clearDataBase(TCurrencyDao.TABLENAME);
    }

    @Override
    public void saveDataToDB(Context context) {
        if (context == null) {
            Log.d(TAG, "context is null");
            return;
        }

        Log.d(TAG, "start save currency");

        long updateId = CodeTable.getInstance().saveSateBeforeUpdate(context, TCurrencyDao.TABLENAME);
        Map<String, Currency> currencyMap = EsQuoteData.getInstance().getCurrencyMap();

        List<TCurrency> list = new ArrayList<>();
        for (Map.Entry<String, Currency> set :  currencyMap.entrySet()) {
            Currency currency = set.getValue();
            TCurrency tCurrency = new TCurrency();
            tCurrency.setCurrencyNo(set.getKey());
            tCurrency.setExchangeRate(currency.getExchangeRate());
            tCurrency.setInterestRate(currency.getInterestRate());
            tCurrency.setUpdateId(updateId);
            list.add(tCurrency);
        }

        DBManager.getInstance().getDaoSession()
                .getTCurrencyDao().insertOrReplaceInTx(list);

        CodeTable.getInstance().saveStateAfterUpdate(context, updateId);
        Log.d(TAG, "end save currency, list size : " +  list.size());
    }

    @Override
    public int getIndex() {
        return 0;
    }

    @Override
    public int getUpdateCode(TUpdateManager manager) {
        // 获取存取结果信息判断
        boolean result = manager.getResult();
        if (!result) {
            return 0;
        }

        // 获取时间信息判断, 以月为单位更新
        String dateDate = manager.getDateTime();
        Date date = null;
        try {
            if (!TextUtils.isEmpty(dateDate)) {
                date = df.parse(dateDate);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        Calendar calendar = Calendar.getInstance();
        int nowMonth = calendar.get(Calendar.MONTH);
        int nowYear = calendar.get(Calendar.YEAR);
        calendar.setTime(date);
        int updateMonth = calendar.get(Calendar.MONTH);
        int updateYear = calendar.get(Calendar.YEAR);
        calendar.clear();

        boolean isUpdate = nowMonth != updateMonth || nowYear != updateYear;

        int updateCode = isUpdate ? 0 : 1 << getIndex();
        EsLog.d(TAG, "TCurrency updateCode : " + updateCode);

        return updateCode;
    }
}
