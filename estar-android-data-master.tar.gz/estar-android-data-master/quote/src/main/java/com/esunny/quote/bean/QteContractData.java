package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;

/**
 * @author Peter Fu
 * @date 2020/9/22
 */
public class QteContractData extends ApiStruct {

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
