package com.esunny.quote.bean;

import com.esunny.data.api.inter.ApiStruct;

/**
 * @author huang
 */
public class QteStockContData extends ApiStruct {
    private String ContractId;     //个股期货合约代码
    private double ContractDot;    //个股期货合约每手乘数

    public String getContractId() {
        return ContractId;
    }

    public void setContractId(String contractId) {
        ContractId = contractId;
    }

    public double getContractDot() {
        return ContractDot;
    }

    public void setContractDot(double contractDot) {
        ContractDot = contractDot;
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
