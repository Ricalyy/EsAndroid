package com.esunny.quote.bean;

import com.esunny.mobile.EsNativeProtocol;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class SHisQuoteDef {
    private int RefCount;                   //订阅计数
    private long Priority;                   //优先级，最近被使用的最大
    private long SessionId;                  //当前数据的SessionId

    private String contractNo;              //无合约 则数据无效
    private STimeBucketDef TimeBucket;      //无TimeBucket 则数据无效

    private String MContractNo;            //用于重组合约号，请求更久之前的数据
    private int MInQryDataProcess;      //标记是否正在请求数据
    private char MReqKlineType;          //请求类型 0缓存请求 1是数据量不足请求
    private int MStartIndex;            //最新数据位置
    private int MEndIndex;              //最旧数据位置
    private int MwIndex;                //当前数组存储数据的位置
    private int MRspCount;              //单次应答的总数据量
    private int MReqCount;              //单次请求的总数据了
    private long MSessionId;                  //当前数据的SessionId
    private long MDateTime;              //最旧数据日期
    private List<QteKLineData> MOrderLines;

    private String DContractNo;
    private int DInQryDataProcess;
    private char DReqKlineType;          //请求类型 0缓存请求 1是数据量不足请求
    private int DStartIndex;
    private int DEndIndex;
    private int DwIndex;
    private int DRspCount;              //单次应答的总数据量
    private int DReqCount;              //单次请求的总数据了
    private long DSessionId;
    private long DDateTime;
    private List<QteKLineData> DOrderLines;

    private long TSessionId;
    private int TrIndex;
    private int TwIndex;
    private int TCount;
    private long TDateTime;

    public SHisQuoteDef(int sessionId) {
        RefCount = 1;
        SessionId = sessionId;
        MInQryDataProcess = 0;
        MReqKlineType = 0;
        MwIndex = EsNativeProtocol.HOPE_MINUTE_LINE_COUNT - 1;
        MRspCount = 0;
        MReqCount = EsNativeProtocol.HOPE_MINUTE_LINE_COUNT;
        MSessionId = sessionId;
        MDateTime = 0;
        MOrderLines = new ArrayList<>();
        MEndIndex = EsNativeProtocol.HOPE_MINUTE_LINE_COUNT - 1;
        MStartIndex = EsNativeProtocol.HOPE_MINUTE_LINE_COUNT;
        DInQryDataProcess = 0;
        MReqKlineType = 0;
        DwIndex = 1;
        DRspCount = 0;
        DReqCount = EsNativeProtocol.HOPE_DAY_LINE_COUNT;
        DSessionId = sessionId;
        DDateTime = 0;
        DOrderLines = new ArrayList<>();
        DEndIndex = 1;
        DStartIndex = 2;
        TrIndex = 0;
        TwIndex = 0;
        TCount = 0;
        TSessionId = sessionId;
        TDateTime = 0;
    }

    public long getSessionId() {
        return SessionId;
    }

    public void setSessionId(long sessionId) {
        SessionId = sessionId;
    }

    public int getRefCount() {
        return RefCount;
    }

    public void setRefCount(int refCount) {
        RefCount = refCount;
    }

    public int getMReqCount() {
        return MReqCount;
    }

    public void setMReqCount(int MReqCount) {
        this.MReqCount = MReqCount;
    }

    public long getMSessionId() {
        return MSessionId;
    }

    public void setMSessionId(long MSessionId) {
        this.MSessionId = MSessionId;
    }

    public int getDReqCount() {
        return DReqCount;
    }

    public void setDReqCount(int DReqCount) {
        this.DReqCount = DReqCount;
    }

    public long getDSessionId() {
        return DSessionId;
    }

    public void setDSessionId(long DSessionId) {
        this.DSessionId = DSessionId;
    }

    public long getTSessionId() {
        return TSessionId;
    }

    public void setTSessionId(long TSessionId) {
        this.TSessionId = TSessionId;
    }

    public int getMInQryDataProcess() {
        return MInQryDataProcess;
    }

    public void setMInQryDataProcess(int MInQryDataProcess) {
        this.MInQryDataProcess = MInQryDataProcess;
    }

    public int getMRspCount() {
        return MRspCount;
    }

    public void setMRspCount(int MRspCount) {
        this.MRspCount = MRspCount;
    }

    public String getMContractNo() {
        return MContractNo;
    }

    public void setMContractNo(String MContractNo) {
        this.MContractNo = MContractNo;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public int getMStartIndex() {
        return MStartIndex;
    }

    public void setMStartIndex(int MStartIndex) {
        this.MStartIndex = MStartIndex;
    }

    public int getMEndIndex() {
        return MEndIndex;
    }

    public void setMEndIndex(int MEndIndex) {
        this.MEndIndex = MEndIndex;
    }

    public char getMReqKlineType() {
        return MReqKlineType;
    }

    public void setMReqKlineType(char MReqKlineType) {
        this.MReqKlineType = MReqKlineType;
    }

    public long getMDateTime() {
        return MDateTime;
    }

    public void setMDateTime(long MDateTime) {
        this.MDateTime = MDateTime;
    }

    public STimeBucketDef getTimeBucket() {
        return TimeBucket;
    }

    public void setTimeBucket(STimeBucketDef timeBucket) {
        TimeBucket = timeBucket;
    }

    public char getDReqKlineType() {
        return DReqKlineType;
    }

    public void setDReqKlineType(char DReqKlineType) {
        this.DReqKlineType = DReqKlineType;
    }

    public int getDStartIndex() {
        return DStartIndex;
    }

    public void setDStartIndex(int DStartIndex) {
        this.DStartIndex = DStartIndex;
    }

    public int getDEndIndex() {
        return DEndIndex;
    }

    public void setDEndIndex(int DEndIndex) {
        this.DEndIndex = DEndIndex;
    }

    public int getDwIndex() {
        return DwIndex;
    }

    public void setDwIndex(int dwIndex) {
        DwIndex = dwIndex;
    }

    public int getDRspCount() {
        return DRspCount;
    }

    public void setDRspCount(int DRspCount) {
        this.DRspCount = DRspCount;
    }

    public long getDDateTime() {
        return DDateTime;
    }

    public void setDDateTime(long DDateTime) {
        this.DDateTime = DDateTime;
    }

    public List<QteKLineData> getDOrderLines() {
        return DOrderLines;
    }

    public void setDOrderLines(List<QteKLineData> DOrderLines) {
        this.DOrderLines = DOrderLines;
    }

    public String getDContractNo() {
        return DContractNo;
    }

    public void setDContractNo(String DContractNo) {
        this.DContractNo = DContractNo;
    }

    public List<QteKLineData> getMOrderLines() {
        return MOrderLines;
    }

    public void setMOrderLines(List<QteKLineData> MOrderLines) {
        this.MOrderLines = MOrderLines;
    }

    public int getDInQryDataProcess() {
        return DInQryDataProcess;
    }

    public void setDInQryDataProcess(int DInQryDataProcess) {
        this.DInQryDataProcess = DInQryDataProcess;
    }
}
