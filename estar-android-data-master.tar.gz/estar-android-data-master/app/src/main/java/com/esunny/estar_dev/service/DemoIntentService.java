package com.esunny.estar_dev.service;

/**
 * @author Peter Fu
 * @date 2020/11/20
 */

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.bean.PushClientInfo;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.util.EsLog;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.common.news.EsNewsDetailActivity;
import com.esunny.ui.common.setting.condition.EsTriggeredConditionalOrderActivity;
import com.esunny.ui.common.setting.message.EsMessageActivity;
import com.esunny.ui.common.setting.pricewarning.EsTriggeredPriceWarningActivity;
import com.esunny.ui.common.setting.stoplp.EsTriggeredStopLPOrderActivity;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.util.EsSPHelper;
import com.igexin.sdk.GTIntentService;
import com.igexin.sdk.message.GTCmdMessage;
import com.igexin.sdk.message.GTNotificationMessage;
import com.igexin.sdk.message.GTTransmitMessage;

import java.util.List;

/**
 * 继承 GTIntentService 接收来自个推的消息, 所有消息在线程中回调, 如果注册了该服务, 则务必要在 AndroidManifest中声明, 否则无法接受消息<br>
 * onReceiveMessageData 处理透传消息<br>
 * onReceiveClientId 接收 cid <br>
 * onReceiveOnlineState cid 离线上线通知 <br>
 * onReceiveCommandResult 各种事件处理回执 <br>
 */
public class DemoIntentService extends GTIntentService {

    private final static String COMPANY_KEY = "company";
    private final static String USER_KEY = "user";
    private final static String TARGET_KEY = "target";
    private final static String ADDRESS_KEY = "address";

    private final static String TARGET_ACTIVITY_STRATEGY_ORDER_LIST = "1";
    private final static String TARGET_ACTIVITY_STOP_LOSS_PANEL = "2";
    private final static String TARGET_ACTIVITY_MESSAGE = "3";
    private final static String TARGET_ACTIVITY_MONITOR = "4";
    private final static String TARGET_ACTIVITY_NEWS = "5";

    private volatile static GTTransmitMessage mTransmitMessage;
    private volatile static GTNotificationMessage mNotificationMessage;

    public DemoIntentService() {

    }

    @Override
    public void onReceiveServicePid(Context context, int pid) {
    }

    @Override
    public void onReceiveMessageData(Context context, GTTransmitMessage msg) {
        setTransmitMessage(msg);
        turnToTarget(context);
        EsLog.d(TAG, "onReceiveMessageData: " + new String(msg.getPayload()));
    }

    @Override
    public void onReceiveClientId(Context context, String clientid) {
        EsLog.d(TAG, "onReceiveClientId -> " + "clientid = " + clientid);
        ApplicationInfo appInfo;
        String appKey = "", appMasterSecret = "", appId = "";
        try {
            appInfo = getPackageManager() .getApplicationInfo(getPackageName(), PackageManager.GET_META_DATA);
            appKey = appInfo.metaData.getString("appkey");
            appMasterSecret = appInfo.metaData.getString("appmastersecret");
            appId = appInfo.metaData.getString("appid");
        } catch (PackageManager.NameNotFoundException e) {
            EsLog.e(TAG, "onReceiveClientId", e);
        }

        PushClientInfo pushClientInfo = new PushClientInfo();
        pushClientInfo.setDeviceType('A');
        pushClientInfo.setCID(clientid);
        pushClientInfo.setAppId(appId);
        pushClientInfo.setAppKey(appKey);
        pushClientInfo.setAppMasterSecret(appMasterSecret);
        pushClientInfo.setLangType(EsDataApi.getLanguageType());
        EsDataApi.registPushInfo(pushClientInfo);
    }

    @Override
    public void onReceiveOnlineState(Context context, boolean online) {
        EsLog.d(TAG, "onReceiveOnlineState: " + online);
    }

    @Override
    public void onReceiveCommandResult(Context context, GTCmdMessage cmdMessage) {
        EsLog.d(TAG, "onReceiveCommandResult: " + cmdMessage.getAction());
    }

    @Override
    public void onNotificationMessageArrived(Context context, GTNotificationMessage msg) {
        EsLog.d(TAG, "onNotificationMessageArrived: " + msg.getContent());
    }

    @Override
    public void onNotificationMessageClicked(Context context, GTNotificationMessage msg) {
        setNotificationMessage(msg);
        turnToTarget(context);
        EsLog.d(TAG, "onNotificationMessageClicked: " + msg.getContent());
    }

    private synchronized void setNotificationMessage(GTNotificationMessage msg) {
        mNotificationMessage = msg;
    }

    private synchronized void setTransmitMessage(GTTransmitMessage msg) {
        mTransmitMessage = msg;
    }

    private synchronized boolean needTurnActivity() {
        return mTransmitMessage != null && mNotificationMessage != null && mTransmitMessage.getMessageId().equals(mNotificationMessage.getMessageId());
    }

    private void turnToTarget(Context context) {
        if (needTurnActivity()) {
            String info = new String(mTransmitMessage.getPayload());

            EsLog.d(TAG, "turnToTarget " + info);

            String company = "";
            String user = "";
            String target = "";
            String addr = "";

            String[] arr = info.split(";");

            for (String item : arr) {
                if (item != null && item.length() > 0) {
                    int index = item.indexOf("=");

                    if (index < 0) {
                        continue;
                    }

                    String value = item.substring(index + 1);

                    if (item.startsWith(COMPANY_KEY)) {
                        company = value;
                    } else if (item.startsWith(USER_KEY)) {
                        user = value;
                    } else if (item.startsWith(TARGET_KEY)) {
                        target = value;
                    } else if (item.startsWith(ADDRESS_KEY)) {
                        addr = value;
                    }
                }
            }

            if (TARGET_ACTIVITY_MONITOR.equals(target)) {  //行情登录
                QuoteLoginInfo loginInfo = EsDataApi.quoteLoginInfo();
                if (loginInfo != null && loginInfo.getErrorCode() == 0 && loginInfo.getLoginNo().equals(user)) {
                    Intent intentMessage = new Intent(this, EsTriggeredPriceWarningActivity.class);
                    startActivity(intentMessage);
                } else {
                    EsUIApi.startStarLoginActivity();
                }
            } else if (TARGET_ACTIVITY_NEWS.equals(target)) {  // 新闻推送
                if (!addr.isEmpty()) {
                    addr += "&theme=" + (EsSPHelper.getTheme(context)? 1 : 0);

                    EsLog.d(TAG, "URL = " + addr);
                    Intent intent = new Intent(this, EsNewsDetailActivity.class);
                    intent.putExtra(EsUIConstant.KEY_INTENT_NEWS_DETAILS_URL, addr);
                    startActivity(intent);
                }
            } else if (TARGET_ACTIVITY_STRATEGY_ORDER_LIST.equals(target) ||
                    TARGET_ACTIVITY_STOP_LOSS_PANEL.equals(target) ||
                    TARGET_ACTIVITY_MESSAGE.equals(target)) {
                //交易登录
                List<EsLoginAccountData.LoginAccount> accounts = EsLoginAccountData.getInstance().getmListLoginData();

                if (accounts.size() > 0) {
                    String clickedAccount = company + user + addr;

                    if (clickedAccount.length() > 0) {
                        EsLoginAccountData.LoginAccount currentAccount = EsLoginAccountData.getInstance().getCurrentAccount();
                        String current = currentAccount.getCompanyNo() + currentAccount.getUserNo() + currentAccount.getAddrTypeNo();
                        for (EsLoginAccountData.LoginAccount account: accounts) {
                            if (clickedAccount.equals(account.getCompanyNo()+account.getUserNo() + account.getAddrTypeNo())) {
                                if (!clickedAccount.equals(current)) {
                                    EsLoginAccountData.getInstance().setCurrentAccount(account);
                                }
                                if (TARGET_ACTIVITY_STRATEGY_ORDER_LIST.equals(target)) {
                                    Intent intentTriggeredConditional = new Intent(this, EsTriggeredConditionalOrderActivity.class);
                                    startActivity(intentTriggeredConditional);
                                } else if (TARGET_ACTIVITY_STOP_LOSS_PANEL.equals(target)) {
                                    Intent intentTriggeredStopLP = new Intent(this, EsTriggeredStopLPOrderActivity.class);
                                    startActivity(intentTriggeredStopLP);
                                } else if (TARGET_ACTIVITY_MESSAGE.equals(target)) {
                                    Intent intentMessage = new Intent(this, EsMessageActivity.class);
                                    startActivity(intentMessage);
                                }
                                return;
                            }
                        }
                    }
                }
                EsUIApi.startLoginActivity();
            }
        }
    }
}
