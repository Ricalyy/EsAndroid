package com.esunny.estar_dev;

import android.app.Application;

import com.esunny.quote.codetable.CodeTable;

/**
 * @author Peter Fu
 * @date 2020/10/14
 */
public class EsApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
//        CodeTable.getInstance().init(this);
    }
}
