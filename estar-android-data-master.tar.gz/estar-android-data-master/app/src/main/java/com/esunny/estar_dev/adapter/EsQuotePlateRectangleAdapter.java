package com.esunny.estar_dev.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.esunny.estar_dev.R;
import com.esunny.ui.view.EsFixTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */
public class EsQuotePlateRectangleAdapter extends RecyclerView.Adapter<EsQuotePlateRectangleAdapter.ViewHolder>{

    public interface itemClickListener{
        void onClickPlate(int position);
    }

    List<String> mDataList = new ArrayList<>();
    private itemClickListener mListener;

    public void setDataList(List<String> dataList) {
        this.mDataList = dataList;
    }

    public void setClickListener(itemClickListener listener) {
        this.mListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_quote_plate_item_group_new, parent, false);
        return new EsQuotePlateRectangleAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        if(position > -1 && position < mDataList.size() &&  mDataList.get(position) != null){
            holder.mTvPlate.setText(mDataList.get(position));

            holder.mTvPlate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mListener != null) {
                        mListener.onClickPlate(position);
                    }
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        EsFixTextView mTvPlate;

        public ViewHolder(View itemView) {
            super(itemView);

            mTvPlate = itemView.findViewById(R.id.es_plate_group_name);
        }
    }
}
