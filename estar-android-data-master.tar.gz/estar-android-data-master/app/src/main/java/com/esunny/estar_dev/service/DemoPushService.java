package com.esunny.estar_dev.service;

/**
 * @author Peter Fu
 * @date 2020/11/20
 */
public class DemoPushService extends com.igexin.sdk.PushService {

}
