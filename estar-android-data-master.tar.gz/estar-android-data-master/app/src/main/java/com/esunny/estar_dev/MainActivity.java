package com.esunny.estar_dev;

import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.View;
import com.esunny.data.api.EsDataTrackApi;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.estar_dev.view.EsNavFragment;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.server.NetEventService;
import com.esunny.ui.data.setting.EsNetStateNotification;
import com.esunny.ui.util.EsAppManager;
import com.esunny.ui.util.EsAppPermission;
import com.esunny.ui.util.EsDoubleClickExitHelper;
import com.esunny.ui.util.EsLanguageHelper;
import com.esunny.ui.util.EsPictureFileHelper;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.EsTradeNotification;
import com.umeng.socialize.UMShareAPI;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import skin.support.SkinCompatManager;
import skin.support.utils.SkinPreference;

public class MainActivity extends EsBaseActivity implements EsNavFragment.NavClickListener{

    public String TAG = "MainActivity";

    private EsAppPermission mEsAppPermission;
    protected EsDoubleClickExitHelper mEsDoubleClickExitHelper;//双击后退键，退出程序

    private EsNavFragment mNavBar;//底部导航栏
    private DrawerLayout mDrawerLayout;//抽屉控件

    private int mFlag = 1;

    public static final String SKIN_NAME = "night.skin" ;

    @Override
    protected int getContentView() {
        return R.layout.activity_main;
    }

    @Override
    protected void initData() {
        EventBus.getDefault().register(this);
        super.initData();

        mEsAppPermission = new EsAppPermission(this);

        //TODO 先屏蔽，看日后是否按需获取权限
//        if(!mEsAppPermission.getPermission()){
//            mEsAppPermission.goToSystemSettingPage();
//            return;
//        }

        initAppAction();

        if (!mEsAppPermission.getAlertPermission()) {
            mEsAppPermission.checkSystemAlterByActivity();
        }
    }

    private void initAppAction(){
        // 要在此处初始化，因为传进去的Context是Activity的Context，否则在NetStateNotification的Dialog使用该Context崩溃。
        EsNetStateNotification.getInstance().start(this);

        startService(new Intent(this, NetEventService.class));

        EsTradeNotification.getInstance(this).startNotify();

        mEsDoubleClickExitHelper = new EsDoubleClickExitHelper(this);
        EsPictureFileHelper helper = new EsPictureFileHelper(this);
        //检查更新图片
        helper.checkPicInfo();
        EsDataTrackApi.checkDatabaseStatus(getApplicationContext());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        //底部导航栏
        mNavBar = (EsNavFragment)getSupportFragmentManager().findFragmentById(R.id.fag_nav);
        mNavBar.setNavClickListener(this);
        mNavBar.setup(getSupportFragmentManager(), R.id.main_container, getBaseContext());


        //抽屉控件
        mDrawerLayout = findViewById(R.id.drawer_main);
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, GravityCompat.START);
    }

    public void closeLeftDrawer(View v) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mDrawerLayout.closeDrawer(GravityCompat.START);
            }
        }, 200);
    }

    public void closeRightDrawer(){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                mDrawerLayout.closeDrawer(GravityCompat.END);
            }
        }, 200);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            //判断右抽屉是否打开
            if(mDrawerLayout.isDrawerOpen(GravityCompat.END)){
                closeRightDrawer();
                return false;
            }else if(mDrawerLayout.isDrawerOpen(GravityCompat.START)){
                closeLeftDrawer(null);
                return false;
            } else {
                return mEsDoubleClickExitHelper.onKeyDown(keyCode, event);
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onNavClickListener(int navButtonType) {
        if(navButtonType == EsUIApi.SHOW_QUOTE_FRAGMENT){
            if(mDrawerLayout != null) {
                mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED, GravityCompat.START);
            }
        }else{
            if(mDrawerLayout != null) {
                mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED, GravityCompat.START);
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage messageEvent) {
        int action = messageEvent.getAction();

        if (action == EsEventConstant.E_STAR_ACTION_OPEN_RIGHT_DRAWER) {
            boolean isRightOpen = mDrawerLayout.isDrawerOpen(GravityCompat.END);
            if (isRightOpen) {
                closeLeftDrawer(null);
            } else {
                mDrawerLayout.openDrawer(GravityCompat.END);
            }
        } else if (action == EsEventConstant.E_STAR_ACTION_OPEN_LEFT_DRAWER) {
            boolean isLeftOpen = mDrawerLayout.isDrawerOpen(GravityCompat.START);
            if (isLeftOpen) {
                closeLeftDrawer(null);
            } else {
                mDrawerLayout.openDrawer(GravityCompat.START);
            }
        }else if(action == EsEventConstant.E_STAR_ACTION_CLOSE_RIGHT_DRAWER) {
            closeRightDrawer();
        } else if (action == EsEventConstant.E_STAR_ACTION_RECEIVE_UNREAD_MESSAGE){
            if(messageEvent.getData() != null) {
                mNavBar.showReceiveUnReadMessageByDialog(messageEvent.getData());
                Vibrator vibrator = (Vibrator)this.getSystemService(Service.VIBRATOR_SERVICE);
                if (vibrator != null) {
                    vibrator.vibrate(100);
                }
            }
        } else if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_TO_TRADE) {
            mNavBar.showTradeFragment(messageEvent.getContent());
            closeRightDrawer();
        }else if (action == EsEventConstant.E_STAR_ACTION_CLOSE_LEFT_DRAWER){
            closeLeftDrawer(null);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!EsSPHelper.getTheme(this) && !SKIN_NAME.equals(SkinPreference.getInstance().getSkinName())) {
            SkinCompatManager.getInstance().loadSkin(SKIN_NAME, null, SkinCompatManager.SKIN_LOADER_STRATEGY_ASSETS);
        }

        if (mNavBar != null) {
            mNavBar.checkTradeFragment();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == EsUIConstant.S_STATE_QUOTE_LOGIN_CODE && resultCode == EsUIConstant.S_STATE_QUOTE_LOGIN_APP_EXIT_CODE) {
//            finish();
            EsAppManager.getAppManager().AppExit(this);
        }

        //友盟分享onActivityResult
        UMShareAPI.get(this).onActivityResult(requestCode, resultCode, data);

        // Warnning :  目前先采取500ms延迟处理。
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!mEsAppPermission.getAlertPermission()) {
                    mEsAppPermission.checkSystemAlterByActivity();
                }
            }
        }, 500);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (mFlag == 1){
            EsLanguageHelper.switchLanguage(this, EsLanguageHelper.mNewLanguageType);
        }
        mFlag++;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mEsAppPermission.onRequestPermissionsResult(this, requestCode, permissions, grantResults);
    }
}