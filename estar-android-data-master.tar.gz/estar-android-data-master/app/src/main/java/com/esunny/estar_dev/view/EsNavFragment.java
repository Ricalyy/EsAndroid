package com.esunny.estar_dev.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.bean.MessageData;
import com.esunny.data.util.EsLog;
import com.esunny.estar_dev.R;
import com.esunny.ui.BaseView;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.button.EsNavButton;
import com.esunny.ui.common.EsBaseFragment;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.data.setting.EsMessageData;
import com.esunny.ui.dialog.EsCustomMessageDialog;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */
public class EsNavFragment extends EsBaseFragment implements View.OnClickListener, BaseView {

    private static final String TAG = "EsNavFragment";

    private int mContainerId;
    private int mShowType = EsUIApi.SHOW_FAVORITE_FRAGMENT;
    private EsNavButton mNavFavorite;
    private EsNavButton mNavQuote;
    private EsNavButton mNavOption;
    private EsNavButton mNavTrade;
    private EsNavButton mNavNews;
    private EsNavButton mNavFunds;

    private EsNavButton mCurrentNavButton;
    private FragmentManager mFragmentManager;
    private NavClickListener mNavClickListener;

    final EsCustomMessageDialog[] mCurrentCustomMessageDialog = new EsCustomMessageDialog[1];

    @Override
    protected int getLayoutId() {
        return R.layout.es_fragment_navigation;
    }

    @SuppressLint("CutPasteId")
    @Override
    protected void initWidget(View root) {
        super.initWidget(root);

        mNavOption = new EsNavButton(root.getContext());
        mNavFunds =  new EsNavButton(root.getContext());

        mNavQuote = root.findViewById(R.id.nav_item_quote);
        mNavFavorite = root.findViewById(R.id.nav_item_favorite);
        mNavTrade = root.findViewById(R.id.nav_item_trade);
        mNavNews = root.findViewById(R.id.nav_item_news);

        mNavFavorite.init(R.string.es_icon_tab_favorite, R.string.es_icon_tab_favorite_click, R.string.es_main_tab_name_favorite, EsUIApi.SHOW_FAVORITE_FRAGMENT);
        mNavQuote.init(R.string.es_icon_tab_quote, R.string.es_icon_tab_quote_click, R.string.es_main_tab_name_quote, EsUIApi.SHOW_QUOTE_FRAGMENT);
        mNavOption.init(R.string.es_icon_tab_quote, R.string.es_icon_tab_quote_click, R.string.es_main_tab_name_option, EsUIApi.SHOW_OPTION_FRAGMENT);
        mNavTrade.init(R.string.es_icon_tab_trade_new, R.string.es_icon_tab_trade_click_new, R.string.es_main_tab_name_trade, EsUIApi.SHOW_TRADE_FRAGMENT);
        mNavNews.init(R.string.es_icon_tab_news, R.string.es_icon_tab_news_click, R.string.es_main_tab_name_news, EsUIApi.SHOW_NEW_FRAGMENT);
        mNavFunds.init(R.string.es_icon_tab_quote, R.string.es_icon_tab_quote_click, R.string.es_main_tab_name_quote, EsUIApi.SHOW_FUNDS_FRAGMENT);

        mNavQuote.setOnClickListener(this);
        mNavFavorite.setOnClickListener(this);
        mNavTrade.setOnClickListener(this);
        mNavNews.setOnClickListener(this);

        if (!EsDataApi.isContainTrade()){
            mNavTrade.setVisibility(View.GONE);
        }
        if (!EsDataApi.isContainNews()){
            mNavNews.setVisibility(View.GONE);
        }
    }

    public void setup(FragmentManager manager, int containerId, Context context){
        mFragmentManager = manager;
        mContainerId = containerId;
        initAllFragment();
        initFirstButton();
        //onClick(mNavFavorite);
    }

    private void initAllFragment(){
        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        transaction.add(mContainerId, mNavFavorite.getFragment()).show(mNavFavorite.getFragment());
//        transaction.add(mContainerId, mNavQuote.getFragment()).hide(mNavQuote.getFragment());
//        transaction.add(mContainerId, mNavOption.getFragment()).hide(mNavOption.getFragment());
//        if (EsDataApi.isContainTrade()){
//            transaction.add(mContainerId, mNavTrade.getFragment()).hide(mNavTrade.getFragment());
//        }
//        if (EsDataApi.isContainNews()){
//            transaction.add(mContainerId, mNavNews.getFragment()).hide(mNavNews.getFragment());
//        }
        transaction.commitAllowingStateLoss();
    }

    private void initFirstButton(){
        mCurrentNavButton = mNavFavorite;
        mCurrentNavButton.setSelected(true);
    }

    @Override
    public void onClick(View v) {
        if (v instanceof EsNavButton) {
            if (mNavTrade == v && EsLoginAccountData.getInstance().getCurrentAccount() == null) {
                EsUIApi.startLoginActivity(EsEventConstant.E_STAR_MODULE_MUST_TRADE);
            } else {
                //通过外界点击事件，进行回调
                dealOnclick((EsNavButton) v);
            }
        }
    }

    private void dealOnclick(EsNavButton v) {
        int type = v.getType();
        if (mNavClickListener != null) {
            mNavClickListener.onNavClickListener(type);
        }
        if (type < 0) {
            return;
        }
        EsNavButton newNavButton = v;
        if (mCurrentNavButton.getType() == newNavButton.getType()) {
            // 如果两次点击相同的button，则没有必要再进行重复操作
            return;
        }

        mCurrentNavButton.setSelected(false);
        newNavButton.setSelected(true);

        Fragment newFragment = newNavButton.getFragment();
        Fragment oldFragment = mCurrentNavButton.getFragment();

        if(newNavButton.getType() == EsUIApi.SHOW_QUOTE_FRAGMENT) {
            newFragment = getCurrentQuoteFragment();
        } else if (mCurrentNavButton.getType() == EsUIApi.SHOW_QUOTE_FRAGMENT) {
            oldFragment = getCurrentQuoteFragment();
        }

        doTabChanged(oldFragment, newFragment);
        mCurrentNavButton = newNavButton;
    }

    private void doTabChanged(Fragment oldFragment, Fragment newFragment){
        if (oldFragment == null || newFragment == null) {
            return;
        }
        EsLog.d(TAG, "doTabChanged: old = " + oldFragment.getTag() + ", new = " + newFragment.getTag());
        FragmentTransaction transaction = mFragmentManager.beginTransaction();
        if (mFragmentManager.findFragmentById(newFragment.getId()) == null) {
            transaction.add(mContainerId, newFragment);
        }
        transaction.hide(oldFragment);
        transaction.show(newFragment);
        transaction.commitAllowingStateLoss();
    }

    public void showTradeFragment(String contractNo){
        EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_SEND_CONTRACT_TO_TRADE).setSender(EsEventConstant.E_STAR_MODULE_TRADE)
                .setContent(contractNo).buildEvent();
        EventBus.getDefault().postSticky(message);
        //判断是否有当前登录用户
        if (EsLoginAccountData.getInstance().getCurrentAccount() == null) {
            EsUIApi.startLoginActivity();
        } else {
            onClick(mNavTrade);
        }
    }

    //只有QuoteFragment跳转OptionFragment
    public void toOptionFragment() {

        doTabChanged(getCurrentQuoteFragment(), mNavOption.getFragment());
        mShowType = EsUIApi.SHOW_OPTION_FRAGMENT;

        mNavQuote.updateText(R.string.es_main_tab_name_option);
    }

    //只有OptionFragment跳转QuoteOption
    public void toQuoteFragment(){

        doTabChanged(getCurrentQuoteFragment(), mNavQuote.getFragment());
        mShowType = EsUIApi.SHOW_QUOTE_FRAGMENT;

        mNavQuote.updateText(R.string.es_main_tab_name_quote);
    }

    public void toFundsFragment() {
        doTabChanged(getCurrentQuoteFragment(), mNavFunds.getFragment());
        mShowType = EsUIApi.SHOW_FUNDS_FRAGMENT;

        mNavQuote.updateText(R.string.es_main_tab_name_quote);
    }

    public void checkTradeFragment() {
        if (mCurrentNavButton != mNavTrade) {
            return;
        }

        if (EsLoginAccountData.getInstance().getCurrentAccount() != null) {
            return;
        }

        onClick(mNavFavorite);
    }

    private Fragment getCurrentQuoteFragment() {
        if (mShowType == EsUIApi.SHOW_OPTION_FRAGMENT) {
            return mNavOption.getFragment();
        } else if (mShowType == EsUIApi.SHOW_FUNDS_FRAGMENT) {
            return mNavFunds.getFragment();
        }
        return mNavQuote.getFragment();
    }

    public void showReceiveUnReadMessageByDialog(Object messageData){
        if (mCurrentCustomMessageDialog[0] != null && mCurrentCustomMessageDialog[0].isShowing())
            return;
        final EsCustomMessageDialog customMessageDialog = new EsCustomMessageDialog(getContext(), (MessageData) messageData);
        customMessageDialog.setReadMessageListener(new EsCustomMessageDialog.ReadMessageListener() {
            @Override
            public void lastMessage(MessageData sMessageData) {
                List<MessageData> messageDataList = EsMessageData.getInstance().getCurrentUserMsgData();
                // 该sMessageData是上一条的信息
                int index = messageIndexInList(messageDataList, sMessageData);
                int indexOfNowMessage = index - 1;
                if (indexOfNowMessage == -1 || index == 0) {
                    customMessageDialog.cancel();
                }

                if (indexOfNowMessage > -1 && indexOfNowMessage < messageDataList.size()) {
                    MessageData tempData = messageDataList.get(indexOfNowMessage);
                    customMessageDialog.setMessageData(tempData);
                }
            }

            @Override
            public void nextMessage(MessageData sMessageData) {
                List<MessageData> messageDataList = EsMessageData.getInstance().getCurrentUserMsgData();
                // 该sMessageData是上一条的信息
                int index = messageIndexInList(messageDataList, sMessageData);
                int indexOfNowMessage = index + 1;
                if (indexOfNowMessage  == messageDataList.size() || index == messageDataList.size() - 1) {
                    customMessageDialog.cancel();
                }

                if (indexOfNowMessage > -1 && indexOfNowMessage < messageDataList.size()) {
                    MessageData tempData = messageDataList.get(indexOfNowMessage);
                    customMessageDialog.setMessageData(tempData);
                }
            }
        });
        mCurrentCustomMessageDialog[0] = customMessageDialog;
        customMessageDialog.show();
    }

    private int messageIndexInList(List<MessageData> messageDataList, MessageData sMessageData) {
        int index = -1;
        for (int i = 0 ; i < messageDataList.size(); i++){
            if (sMessageData != null && sMessageData.getMsgId() == messageDataList.get(i).getMsgId()) {
                index = i;
                break;
            }
        }
        return index;
    }

    //设置
    public interface NavClickListener{
        void onNavClickListener(int navButtonType);
    }
    public void setNavClickListener(NavClickListener listener){
        mNavClickListener = listener;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage messageEvent) {
        if (messageEvent.getSender() == EsEventConstant.E_STAR_MODULE_QUOTE) {
            int action = messageEvent.getAction();
            if (action == EsEventConstant.E_STAR_ACTION_TO_OPTION) {
                toOptionFragment();
            } else if (action == EsEventConstant.E_STAR_ACTION_TO_QUOTE) {
                toQuoteFragment();
            } else if (action == EsEventConstant.E_STAR_ACTION_TO_FUNDS) {
                toFundsFragment();
            }
        } else if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_TO_SWITCH_FRAGMENT) {
            dealSwitchFragment(messageEvent.getContent());
        }
    }

    private void dealSwitchFragment(String destination) {
        if (mCurrentNavButton == mNavTrade) {
            if (destination.equals("Favorite")) {
                dealOnclick(mNavFavorite);
            } else {
                dealOnclick(mNavQuote);
            }
        }
    }
}
