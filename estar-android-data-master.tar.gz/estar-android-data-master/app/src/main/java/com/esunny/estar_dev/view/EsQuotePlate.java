package com.esunny.estar_dev.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.bean.Plate;
import com.esunny.data.util.simplethread.SimpleRunnable;
import com.esunny.data.util.simplethread.TaskManager;
import com.esunny.estar_dev.R;
import com.esunny.estar_dev.adapter.EsQuotePlateRectangleAdapter;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.data.quote.EsQuoteListData;
import com.esunny.ui.util.EsSPHelper;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */
public class EsQuotePlate extends LinearLayout {

    private final static String CHN_PLATE_NO = "CHN";
    private final static String OPTION_PLATE_NO = "OPTION";
    private final static String SPD_PLATE_NO = "EsunnySpread";

    private final static String FUNDS_PLATE_NO = "FUNDS";

    private Context mContext;

    //所有一级交易所
    private ArrayList<Plate> mGroupPlate = new ArrayList<>();
    //期权、极星套利交易所
    private ArrayList<Plate> mFirstPlateList = new ArrayList<>();

    private HashMap<Plate, List<Plate>> mChildPlates = new HashMap<>();

    //一级交易所
    List<String> mGroupPlateListStr = new ArrayList<>();

    JSONObject mJson = null;

    private Plate mCurrentPlate, mMainPlate;

    public EsQuotePlate(Context context) {
        this(context, null);
    }

    public EsQuotePlate(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public EsQuotePlate(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initWidget(context);
    }

    private void initWidget(Context context) {
        mContext = context;
        LayoutInflater.from(context).inflate(R.layout.es_quote_plate_new, this);

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        TaskManager.getInstance().execute(new SimpleRunnable() {
            @Override
            public void run() {
                initPlateData();
                initQuoteSettingData();
                initRecyclerViewData();
            }
        }, new TaskManager.TaskAsyncHandler() {
            @Override
            public void onFinished() {
                initRecyclerView();
            }
        });
    }

    private void initQuoteSettingData() {
        String dataStr = EsSPHelper.getQuoteSetting(getContext());

        if (dataStr == null || dataStr.isEmpty()) {
            mJson = new JSONObject();
        }else {
            try {
                mJson = new JSONObject(dataStr);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private void initRecyclerViewData() {
        for (Plate plate : mGroupPlate) {
            mGroupPlateListStr.add(plate.getPlateName());
        }
    }

    private void initPlateData() {
        mFirstPlateList.clear();
        mChildPlates.clear();

        List<Plate> plates = EsDataApi.getPlate();
        for (Plate plate : plates) {
            if (plate.isFirstPlate()) {
                //筛选出期权和极星套利
                if (OPTION_PLATE_NO.equals(plate.getPlateNo())
                        || SPD_PLATE_NO.equals(plate.getPlateNo())) {
                    mFirstPlateList.add(plate);
                } else {
                    mGroupPlate.add(plate);
                }

                //只有一级板块存在子板块
                mChildPlates.put(plate, EsDataApi.getChildPlate(plate));
            }
        }

        // 添加资金热点
        Plate fundsPlate = new Plate();
        fundsPlate.setPlateName(getResources().getString(R.string.es_fragment_funds_title));
        fundsPlate.setPlateNo(FUNDS_PLATE_NO);
        mFirstPlateList.add(fundsPlate);

        // 需要将内盘主力放置第一个
        for (Plate plate : mGroupPlate) {
            if (CHN_PLATE_NO.equals(plate.getPlateNo())) {
                List<Plate> children = mChildPlates.get(plate);
                if (children.size() > 0) {
                    for (int i = 0; i < children.size(); i++) {
                        if (("MAIN").equals(children.get(i).getPlateNo())) {
                            Plate mainPlate = children.get(i);
                            mMainPlate = mainPlate;
                            children.remove(mainPlate);
                            children.add(0, mainPlate);
                        }
                    }

                    plate = children.get(0);
                }
                setPlateData(plate);
                return;
            }
        }

        //设置默认
        if (mGroupPlate != null && mGroupPlate.size() > 0) {
            Plate plate = mGroupPlate.get(0);
            if (plate != null) {
                if (!plate.isFirstPlate()) {
                    List<Plate> children = mChildPlates.get(plate);
                    if (children != null && children.size() > 0) {
                        plate = children.get(0);
                        setPlateData(plate);
                        return;
                    }
                }
                setPlateData(plate);
                return;
            }
        }

        if (mFirstPlateList != null && mFirstPlateList.size() > 0) {
            setPlateData(mFirstPlateList.get(0));
        }
    }

    private void initRecyclerView() {
        LinearLayout container = findViewById(R.id.es_quote_plate_rv_container);
        container.removeAllViews();

        //期权、极星套利
        RecyclerView moduleRecyclerView = findViewById(R.id.es_quote_plate_rv_module);
        dealPlateData(moduleRecyclerView,mFirstPlateList);


        //其余交易所
        for (int i = 0; i < mGroupPlate.size(); i++) {
            final List<Plate> childPlateList = new ArrayList<>();
            final ArrayList<Plate> noChildList = new ArrayList<>();
            //获取一级交易所
            final Plate plate = mGroupPlate.get(i);
            //获取二级交易所, 且过滤行情配置中不需要的板块
            final List<Plate> list = mChildPlates.get(plate);

            if (list.size() > 0) {
                //存在二级交易所
                childPlateList.addAll(list);
            } else {
                //相邻无父板块的一级交易所需要合并显示
                childPlateList.add(plate);
                noChildList.add(plate);
                for (int j = i + 1; j < mGroupPlate.size(); j++) {
                    Plate nextPlate = mGroupPlate.get(j);
                    if (mChildPlates.get(nextPlate).size() == 0) {
                        childPlateList.add(nextPlate);
                        noChildList.add(nextPlate);
                        i++;
                    } else {
                        break;
                    }
                }
            }

            RecyclerView item = new RecyclerView(mContext);

            boolean result = dealPlateData(item, childPlateList);

            if (result) {
                View view = View.inflate(mContext, R.layout.es_quote_plate_separate, null);
                container.addView(view);
                container.addView(item);
            }
        }
    }


    private boolean dealPlateData(RecyclerView view, List<Plate> list) {
        List<String> strList = new ArrayList<>();
        final List<Plate> plateData = new ArrayList<>(list);

        for (Plate plate : list) {
            if (plate == null) {
                continue;
            }
            String plateName = plate.getPlateName();
            String plateNo = plate.getPlateNo();
            try {
                if (mJson.has(plateNo) && !mJson.getBoolean(plateNo)) {
                    // 被取消配置的板块不添加。
                    plateData.remove(plate);
                } else {
                    strList.add(plateName);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        if (strList.size() == 0) {
            return false;
        }

        EsQuotePlateRectangleAdapter adapter = new EsQuotePlateRectangleAdapter();
        adapter.setClickListener(new EsQuotePlateRectangleAdapter.itemClickListener() {
            @Override
            public void onClickPlate(int position) {
                Plate plate1 = plateData.get(position);

                navigatePlate(plate1);
            }
        });

        int size = plateData.size();
        int heightCount;
        if (size % 2 == 0) {
            heightCount = size / 2;
        } else {
            heightCount = (size + 1) / 2;
        }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                getContext().getResources().getDimensionPixelSize(R.dimen.x150) * heightCount);
        view.setLayoutParams(params);
        view.setNestedScrollingEnabled(false);
        adapter.setDataList(strList);
        GridLayoutManager layoutManager = new GridLayoutManager(getContext(), 2);
        view.setLayoutManager(layoutManager);
        view.setAdapter(adapter);

        return true;
    }

    private void setPlateData(Plate plate) {
        if (plate == null) {
            return;
        }
        mCurrentPlate = plate;

        if (!FUNDS_PLATE_NO.equals(plate.getPlateNo()) && !plate.isOptionPlate()) {
            EsQuoteListData.getInstance().setPlate(plate);
        }
    }

    private void navigatePlate(Plate plate) {
        if (plate == null) {
            return;
        }
        setPlateData(plate);

        EsEventMessage.Builder builder = new EsEventMessage.Builder(EsEventConstant.E_STAR_MODULE_QUOTE);
        if (FUNDS_PLATE_NO.equals(plate.getPlateNo())) {
            builder.setAction(EsEventConstant.E_STAR_ACTION_TO_FUNDS);
        } else if (plate.isOptionPlate()) {
            builder.setAction(EsEventConstant.E_STAR_ACTION_TO_OPTION);
        } else {
            builder.setAction(EsEventConstant.E_STAR_ACTION_TO_QUOTE);
        }

        EventBus.getDefault().post(builder.buildEvent());
        EventBus.getDefault().post(new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_CLOSE_LEFT_DRAWER).setSender(EsEventConstant.E_STAR_MODULE_OPTION).buildEvent());
    }

    private void switchNewPlate() {
        if (mCurrentPlate == null) {
            return;
        }

        String currentPlateNo = mCurrentPlate.getPlateNo();
        try {
            if (mJson.has(currentPlateNo) && !mJson.getBoolean(currentPlateNo)) {
                navigatePlate(mMainPlate);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage messageEvent) {
        int action = messageEvent.getAction();

        if (action == EsEventConstant.E_STAR_ACTION_REFRESH_QUOTE_SETTING) {
            initQuoteSettingData();
            initRecyclerView();
            switchNewPlate();
        }
    }
}
