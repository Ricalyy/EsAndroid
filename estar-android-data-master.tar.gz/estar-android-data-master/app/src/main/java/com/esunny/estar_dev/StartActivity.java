package com.esunny.estar_dev;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.EsEventConstant;
import com.esunny.data.api.event.HisQuoteEvent;
import com.esunny.data.api.event.QuoteEvent;
import com.esunny.data.util.EsLog;
import com.esunny.quote.EsQuoteProtocol;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.dialog.EsCustomTipsDialog;
import com.esunny.ui.util.EsAppManager;
import com.esunny.ui.util.EsAppUpdate;
import com.esunny.ui.view.EsProcessBarView;
import com.igexin.sdk.IUserLoggerInterface;
import com.igexin.sdk.PushManager;
import com.igexin.sdk.Tag;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class StartActivity extends AppCompatActivity {

    private static final String TAG = "StartActivity";

    private TextView mTextView;
    private EsProcessBarView mProcessBarView;

    private int mCurrentProgress = 0;

    private static final int TOTAL_PROCESS = 8;
    private boolean mIsHQuoteInitCompleted = true;
    private boolean mIsQuoteInitCompleted;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.es_activity_start);

        if (!isTaskRoot()) {
            Intent intent = getIntent();
            if (intent != null) {
                String action = intent.getAction();
                if (intent.hasCategory(Intent.CATEGORY_LAUNCHER) && Intent.ACTION_MAIN.equals(action)) {
                    finish();
                    return;
                }
            }
        }

        mTextView = this.findViewById(R.id.tv_start_loading);
        mProcessBarView = findViewById(R.id.pb_start_loading);

        initProcess();

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        EsDataApi.init(getApplication(), "E00BAFB62C959A009B7ACB7AAC7557FF91343BDA5EF884C874F221317B1BC8F2A73A36A8EA51DA4ED470DC2830094021D470DC2830094021D470DC2830094021");

        EsDataApi.startUp();

        EsUIApi.initConfiguration(getApplicationContext());

        //个推初始化
        PushManager.getInstance().initialize(getApplicationContext());
        Tag tag = new Tag();
        tag.setName(EsUIApi.getVersion(getApplication()));
        int i = PushManager.getInstance().setTag(getApplicationContext(), new Tag[]{tag}, System.currentTimeMillis() +"");
        EsLog.d(TAG, "PUSH TAG = " + i);
    }

    protected void initProcess() {
        if (mTextView != null) {
            mTextView.setVisibility(View.VISIBLE);
            mTextView.setText(getString(R.string.start_loading_init));
        }


        mProcessBarView = findViewById(R.id.pb_start_loading);
        if (mProcessBarView != null) {
            mProcessBarView.setVisibility(View.VISIBLE);
            mProcessBarView.setMax(TOTAL_PROCESS);
        }

        processUpdate();
    }

    protected void connected() {
        if (mTextView != null) {
            mTextView.setText(this.getString(R.string.start_loading_quote_connect));
        }

        processUpdate();
    }

    protected void quoteLogged() {
        if (mTextView != null) {
            mTextView.setText(this.getString(R.string.start_loading_quote_login));
        }

        processUpdate();
    }

    private void processUpdate(){
        mCurrentProgress++;
        if(mProcessBarView != null) {
            mProcessBarView.setProgress(mCurrentProgress);
        }
    }

    protected void qInitCompleted() {
        if (mTextView != null) {
            mTextView.setText(this.getString(R.string.start_loading_quote_init));
        }

        processUpdate();

        mIsQuoteInitCompleted = true;

        initCompleted();
    }

    protected void hConnected() {
        if (mTextView != null) {
            mTextView.setText(this.getString(R.string.start_loading_his_connect));
        }

        processUpdate();
    }

    protected void hisLogged() {
        if (mTextView != null) {
            mTextView.setText(this.getString(R.string.start_loading_his_login));
        }

        processUpdate();
    }

    protected void hInitCompleted() {
        if (mTextView != null) {
            mTextView.setText(this.getString(R.string.start_loading_his_init));
        }

        processUpdate();

        mIsHQuoteInitCompleted = true;

        initCompleted();
    }

    protected void initCompleted() {
        if (mIsQuoteInitCompleted && mIsHQuoteInitCompleted) {
            mCurrentProgress = TOTAL_PROCESS;
            if(mProcessBarView != null) {
                mProcessBarView.setProgress(mCurrentProgress);
            }

//            mNotifyInfo = EsDataApi.getNotifyInfo();
//            mUpdate = new EsAppUpdate(this);

            navigationMain();
        }
    }

    /**
     *  跳转主界面
     */
    protected void navigationMain(){
        // 如果未登录行情账号则需先跳转
//        EsLog.d(TAG, "navigationMain");
        Intent intent = new Intent(this, MainActivity.class);
        this.startActivity(intent);
        finish();
    }

    private void showErrorDialog(int error) {
        EsCustomTipsDialog dialog = EsCustomTipsDialog.create(this,
                getString(R.string.es_base_view_tips) + "(" + error + ")",
                getString(R.string.start_init_error));
        dialog.setCancelListener(new EsCustomTipsDialog.EsCustomTipsDialogListener() {
            @Override
            public void onCancel() {
                finish();
                EsAppManager.getAppManager().AppExit(getBaseContext());
            }
        });

        if (! isFinishing()) {
            dialog.show();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void quoteEvent(QuoteEvent event) {
        int action = event.getAction();
        EsLog.w(TAG, "initCallBack quote event= " + action);
        switch (action) {
            case EsEventConstant.S_SRVEVENT_CONNECT:
                connected();
                break;
            case EsEventConstant.S_SRVEVENT_QUOTELOGIN:
                quoteLogged();
                break;
            case EsEventConstant.S_SRVEVENT_QINITCOMPLETED:
                qInitCompleted();
                break;
            case EsEventConstant.S_SRVEVENT_CONNECTFAIL:
            case EsEventConstant.S_SRVEVENT_INITFAIL:
                showErrorDialog(event.getSrvErrorCode());
                break;
            default:
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void hisQuoteEvent(HisQuoteEvent event) {
        int action = event.getAction();
        EsLog.w(TAG, "initCallBack his event= " + action);
        switch (action) {
            case EsDataConstant.S_SRVEVENT_CONNECT:
                hConnected();
                break;
            case EsDataConstant.S_SRVEVENT_HISLOGIN:
                hisLogged();
                break;
            case EsDataConstant.S_SRVEVENT_HINITCOMPLETED:
                hInitCompleted();
                break;
            case EsDataConstant.S_SRVEVENT_CONNECTFAIL:
            case EsDataConstant.S_SRVEVENT_INITFAIL:
                showErrorDialog(event.getSrvErrorCode());
                break;
            default:
                break;
        }
    }
}