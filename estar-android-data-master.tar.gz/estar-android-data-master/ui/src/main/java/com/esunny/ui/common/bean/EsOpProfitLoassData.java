package com.esunny.ui.common.bean;

import java.util.ArrayList;

public class EsOpProfitLoassData {
    private String mMaxProfit;
    private String mMaxLoss;
    private ArrayList<String> mBalancesPrices;

    public EsOpProfitLoassData() {
        mMaxProfit = "";
        mMaxLoss = "";
        mBalancesPrices = new ArrayList<>();
    }

    public String getMaxProfit() {
        return mMaxProfit;
    }

    public void setMaxProfit(String maxProfit) {
        mMaxProfit = maxProfit;
    }

    public String getMaxLoss() {
        return mMaxLoss;
    }

    public void setMaxLoss(String maxLoss) {
        mMaxLoss = maxLoss;
    }

    public void addBalancePrice(String price){
        mBalancesPrices.add(price);
    }

    public ArrayList<String> getBalancesPrices(){
        return mBalancesPrices;
    }
}
