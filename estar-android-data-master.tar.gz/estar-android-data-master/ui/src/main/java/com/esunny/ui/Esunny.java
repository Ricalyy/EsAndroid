package com.esunny.ui;

import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;

import com.esunny.data.util.EsLog;
import com.esunny.data.api.EsDataTrackApi;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.common.server.NotificationService;
import com.esunny.ui.data.setting.EsNetStateNotification;
import com.esunny.ui.util.EsAppManager;
import com.esunny.ui.util.EsCrashHandler;
import com.esunny.ui.util.EsLanguageHelper;

public class Esunny {

    private final static String TAG = "Esunny";

    private Application app;

    private String packageName = null;

    private Controller controller = new Controller();

    private static volatile Esunny sInstance;

    private Esunny(){}

    private Esunny(Builder builder) {
        this.app = builder.application;
        this.packageName = builder.packageName;

        EsUIApi.initUI(app);
        //app内修改语言配置
        configLanguage();

        app.registerActivityLifecycleCallbacks(controller);

        //写崩溃日志
        EsCrashHandler.getInstance().init(app);

        EsDataTrackApi.init(app);
    }

    public static void init(Esunny esunny) {
        if (esunny == null) {
            throw new RuntimeException("Esunny init error, esunny instance is null");
        }

        if (sInstance == null) {
            synchronized (Esunny.class) {
                if (sInstance == null) {
                    sInstance = esunny;
                    EsLog.d(TAG, "Esunny SDK init completed");
                }
            }
        }
    }

    public static Esunny getInstance() {
        if (sInstance == null) {
            throw new RuntimeException("Please inint first before using of Esunny SDK");
        }
        return sInstance;
    }

    private void onConfigurationChanged() {
        onLanguageChange();
    }

    public static Context attachBaseContext(Context context) {
        return EsLanguageHelper.attachBaseContext(context, EsLanguageHelper.mNewLanguageType);
    }

    private void configLanguage() {
        if (EsLanguageHelper.mNewLanguageType == 0) {
            EsLanguageHelper.mNewLanguageType = EsLanguageHelper.getFavoriteLanguage(app);
        }
        onLanguageChange();
    }

    private void onLanguageChange() {
        EsLanguageHelper.setDefaultLanguage();
        EsLanguageHelper.switchLanguage(app, EsLanguageHelper.mNewLanguageType);
    }

    public static class Builder {
        private final Application application;
        private String packageName = null;

        public Builder(Application app) {
            if (app == null) {
                throw new RuntimeException("Esunny builder error, app instance is null");
            }
            this.application = app;
        }

        public Builder addPackageName(String packageName) {
            this.packageName = packageName;
            return this;
        }

        public Esunny build() {
            return new Esunny(this);
        }
    }

    private final class Controller implements ActivityLifecycleCallbacks, ComponentCallbacks {
        private int mActivityStartCount = 0;

        @Override
        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {

        }

        @Override
        public void onActivityStarted(Activity activity) {
            mActivityStartCount++;
            if(mActivityStartCount == 1) {
                EsUIApi.IsBackground = false;

                if (EsNetStateNotification.getInstance().getIsStartForgroundService()) {
                    EsNetStateNotification.getInstance().setIsStartForgroundService(false);
                    activity.getApplicationContext().stopService(new Intent(activity.getApplicationContext(), NotificationService.class));
                }
            }
        }

        @Override
        public void onActivityResumed(Activity activity) {

        }

        @Override
        public void onActivityPaused(Activity activity) {

        }

        @Override
        public void onActivityStopped(Activity activity) {
            mActivityStartCount--;
            if (mActivityStartCount == 0){
                EsUIApi.IsBackground = true;

                if (!EsNetStateNotification.getInstance().getIsStartForgroundService() && EsAppManager.getAppManager().getTopActivity() != null) {
                    EsNetStateNotification.getInstance().setIsStartForgroundService(true);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        activity.getApplicationContext().startForegroundService(new Intent(activity.getApplicationContext(), NotificationService.class));
                    } else {
                        activity.getApplicationContext().startService(new Intent(activity.getApplicationContext(), NotificationService.class));
                    }
                }
            }
        }

        @Override
        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {

        }

        @Override
        public void onActivityDestroyed(Activity activity) {

        }

        @Override
        public void onConfigurationChanged(Configuration newConfig) {
            Esunny.getInstance().onConfigurationChanged();
        }

        @Override
        public void onLowMemory() {

        }
    }
}
