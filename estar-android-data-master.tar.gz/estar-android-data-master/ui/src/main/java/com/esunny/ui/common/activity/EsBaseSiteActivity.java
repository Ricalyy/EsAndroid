package com.esunny.ui.common.activity;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.login.adapter.EsSiteListAdapter;
import com.esunny.ui.login.data.EsSiteListData;
import com.esunny.ui.login.view.EsHeaderDecoration;
import com.esunny.ui.login.view.EsIndexBar;
import com.esunny.ui.view.EsBaseToolBar;

import static android.widget.RelativeLayout.CENTER_IN_PARENT;

/**
 * Created by chexiaopeng on 2018/6/13.
 */

public class EsBaseSiteActivity extends EsBaseActivity implements EsSiteListAdapter.OnItemClickListener {


    protected RecyclerView mSiteList;
    protected EsSiteListAdapter mListAdapter;
    protected EsIndexBar mEsIndexBar;
    protected EsHeaderDecoration mHeaderDecoration;
    protected EsSiteListData mListData;

    protected ProgressBar mProgressBar;

    protected  void setWidgetData(){}

    @Override
    protected int getContentView() {
        return R.layout.es_login_activity_site_list;
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        initToolbar();
        initProgressBar();

        mSiteList = findViewById(R.id.rv_site_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mSiteList.setLayoutManager(layoutManager);
        mSiteList.setHasFixedSize(true);

        mListAdapter = new EsSiteListAdapter();

        mListAdapter.setOnItemClickListener(this);
        mSiteList.setAdapter(mListAdapter);
        mSiteList.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        mHeaderDecoration = new EsHeaderDecoration(this);
        mSiteList.addItemDecoration(mHeaderDecoration);

        mEsIndexBar = findViewById(R.id.site_list_index_bar);
        mEsIndexBar.setLayoutManager(layoutManager);
        mEsIndexBar.setHintTextView((TextView)findViewById(R.id.tv_index_hint));

        if(mListData != null){
            mListAdapter.setSiteNameList(mListData.getSiteNameList());
            mHeaderDecoration.setTitleList(mListData.getFirstCharList());
            mEsIndexBar.setIndexMap(mListData.getEndIndexMap());
        }
    }

    private void initToolbar(){
        EsBaseToolBar toolbar = findViewById(R.id.activity_sitelist_toolbar);
        toolbar.setSimpleBack(getString(R.string.es_activity_sitelist_commpay_title));
    }

    private void initProgressBar() {

        mProgressBar = new ProgressBar(this);

        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams((int)getResources().getDimension(R.dimen.x150), (int)getResources().getDimension(R.dimen.x150));
        layoutParams.addRule(CENTER_IN_PARENT);

        RelativeLayout relativeLayout = findViewById(R.id.activity_site_list_main);
        relativeLayout.addView(mProgressBar, layoutParams);

        hideProgress();
    }

    protected void hideProgress() {
        if (mProgressBar != null && mProgressBar.getVisibility() == View.VISIBLE) {
            mProgressBar.setVisibility(View.GONE);
        }
    }

    protected void showProgress() {
        if (mProgressBar != null && mProgressBar.getVisibility() == View.GONE) {
            mProgressBar.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void OnClick(View v, int position) {

    }

    protected void updateListData() {
        if (mListData != null) {
            mListAdapter.setSiteNameList(mListData.getSiteNameList());
            mHeaderDecoration.setTitleList(mListData.getFirstCharList());
            mEsIndexBar.setIndexMap(mListData.getEndIndexMap());

            mListAdapter.notifyDataSetChanged();
            mEsIndexBar.requestLayout();
        }
    }
}
