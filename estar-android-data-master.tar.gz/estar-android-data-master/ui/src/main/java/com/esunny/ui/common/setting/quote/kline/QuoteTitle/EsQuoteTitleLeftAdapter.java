package com.esunny.ui.common.setting.quote.kline.QuoteTitle;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.esunny.ui.R;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.util.EstarFieldTransformation;


import java.util.ArrayList;
import java.util.List;

import skin.support.content.res.SkinCompatResources;

public class EsQuoteTitleLeftAdapter extends RecyclerView.Adapter {

    private List<String> mListData = new ArrayList<>();
    private List<String> mLeftData = new ArrayList<>();
    private boolean mSingle = true;
    private Context mContext;

    public EsQuoteTitleLeftAdapter(List<String> list, boolean isSingle, Context context, List<String> leftList) {
        this.mListData = list;
        this.mSingle = isSingle;
        mContext = context;
        this.mLeftData = leftList;

        if (mSingle) {
            mListData.remove(EsUIConstant.QUOTE_RISE);
        } else {
            mListData.remove(EsUIConstant.QUOTE_RISE_AND_DIFF);
        }
    }

    public void setListData(List<String> list, List<String> leftList) {
        this.mListData = list;
        this.mLeftData = leftList;

        if (mSingle) {
            mListData.remove(EsUIConstant.QUOTE_RISE);
        } else {
            mListData.remove(EsUIConstant.QUOTE_RISE_AND_DIFF);
        }
    }

    public void setSingle(boolean single) {
        this.mSingle = single;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_quote_title_single, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, int position) {
        final String s = mListData.get(position);

        String str = "";
        if (mSingle) {
            str = EstarFieldTransformation.getSingleQuoteTitle(mContext, s);
        } else {
            str = EstarFieldTransformation.getActivityDoubleQuoteTitle(mContext, s);
        }

        ((ViewHolder)holder).mTvName.setText(str);

        if (mLeftData.contains(s)) {
            ((ViewHolder)holder).mLinearLayout.setBackgroundColor(SkinCompatResources.getColor(mContext, R.color.es_quote_title_adapter_activity_select));
        } else {
            ((ViewHolder)holder).mLinearLayout.setBackgroundColor(SkinCompatResources.getColor(mContext, R.color.es_quote_title_adapter_activity_no_select));
        }

        ((ViewHolder)holder).mLinearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mLeftData.contains(s)) {
                    mLeftData.remove(s);
                    ((ViewHolder)holder).mLinearLayout.setBackgroundColor(SkinCompatResources.getColor(mContext, R.color.es_quote_title_adapter_activity_no_select));
                } else {
                    mLeftData.add(s);
                    ((ViewHolder)holder).mLinearLayout.setBackgroundColor(SkinCompatResources.getColor(mContext, R.color.es_quote_title_adapter_activity_select));
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return mListData.size();
    }

    private class ViewHolder extends RecyclerView.ViewHolder {
        TextView mTvName;
        LinearLayout mLinearLayout;

        ViewHolder(View itemView) {
            super(itemView);
            mLinearLayout = itemView.findViewById(R.id.es_item_quote_title_ll_main);
            mTvName = itemView.findViewById(R.id.es_item_quote_title_tv_name);
        }
    }
}
