package com.esunny.ui.common.setting.pricewarning;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.util.EstarTransformation;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.ui.R;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class EsTriggeredPriceWarnAdapter extends RecyclerView.Adapter {

    private Context mContext;
    private List<String> mSortTriggeredMonitorData= new ArrayList<>();


    public EsTriggeredPriceWarnAdapter(Context context){
        this.mContext = context;
    }

    public void setMonitorData(List<MonitorOrder> data){
        if(data != null) {
            sortTriggeredData(data);
        }
    }

    private void sortTriggeredData(List<MonitorOrder> data) {
        mSortTriggeredMonitorData.clear();
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i).getData() != null) {
                for (int j = 0; j < data.get(i).getData().length; j++) {
                    String triggeredData = data.get(i).getContractNo() + "#" + data.get(i).getInsertDateTime();
                    triggeredData = triggeredData + "#" + data.get(i).getData()[j].getReason() + "#" + data.get(i).getData()[j].getValue()
                            + "#" + data.get(i).getData()[j].getUpdateTime();
                    mSortTriggeredMonitorData.add(triggeredData);
                }
            }
        }

        Collections.sort(mSortTriggeredMonitorData, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                if (o1 == null || o2 == null) {
                    return 0;
                }

                String time1 = o1.split("#")[4];
                String time2 = o2.split("#")[4];

                if (time1 == null || time2 == null) {
                    return 0;
                }

                time1 = time1.replace(":", "").replace(" ", "").replace("-", "");
                time2 = time2.replace(":", "").replace(" ", "").replace("-", "");

                BigInteger time1L = new BigInteger(time1);
                BigInteger time2L = new BigInteger(time2);

                return time2L.compareTo(time1L);
            }
        });


    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((EsTriggeredPriceWarnAdapter.ViewHolder)holder).setDataOnView(mSortTriggeredMonitorData.get(position));
    }

    @Override
    public int getItemCount() {
        return mSortTriggeredMonitorData == null ? 0 : mSortTriggeredMonitorData.size();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_activity_price_warn_triggered_title,parent,false);
        return new ViewHolder(view);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView mTvContractName;
        TextView mTvTriggerTime;
        TextView mTvCondition;
        TextView mTvInserttime;

        public ViewHolder(View itemView) {
            super(itemView);
            mTvContractName = itemView.findViewById(R.id.es_item_price_warn_triggered_contract_name);
            mTvTriggerTime = itemView.findViewById(R.id.es_item_price_warn_triggered_triggerTime);
            mTvCondition = itemView.findViewById(R.id.es_item_price_warn_triggered_condition);
            mTvInserttime = itemView.findViewById(R.id.es_item_price_warn_triggered_insertTime);
        }

        public void setDataOnView(String data) {
            if (data == null) {
                return;
            }
            String[] param = data.split("#");

            Contract contract = EsDataApi.getQuoteContract(param[0]);
            if (contract != null) {
                mTvContractName.setText(contract.getContractName());
            } else {
                mTvContractName.setText(param[0]);
            }

            mTvInserttime.setText(param[1]);//下单时间

            mTvTriggerTime.setText(param[4]);//触发时间

            String reasonStr = param[2];
            String valueStr = param[3];
            String[] reason = reasonStr.split("\\|");
            String[] value = valueStr.split("\\|");
            StringBuilder tip = new StringBuilder();
            for (int i = 0; i < value.length; i++) {
                int j = i;
                tip.append(EstarTransformation.convertPriceMonitorReachToStr(mContext, contract, reason[i], value[i]));
                if (++j < value.length) {
                    tip.append(";");
                }
            }
            mTvCondition.setText(tip);
        }
    }
}
