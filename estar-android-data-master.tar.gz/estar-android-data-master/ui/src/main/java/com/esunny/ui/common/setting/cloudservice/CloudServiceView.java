package com.esunny.ui.common.setting.cloudservice;

import com.esunny.data.bean.Contract;
import com.esunny.ui.BaseView;

import java.util.List;

public interface CloudServiceView extends BaseView {

    void clearConfigData();

    void syncFavoriteToServer(boolean isSuccess);

    void syncFavoriteContractFromServer(boolean isSuccess);

    void syncSettingFromServer(boolean isSuccess);

    void syncSettingToServer(boolean isSuccess);

    void updateBackupDays(int type, int days);

    void modifyPassword(boolean isSuccess, String text);

    void syncFail();
}