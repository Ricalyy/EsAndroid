package com.esunny.ui.common.setting.condition;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SimpleItemAnimator;

import android.view.View;
import android.widget.HorizontalScrollView;

import com.esunny.data.bean.OrderData;
import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.setting.condition.adapter.EsConditionalOrderAdapter;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsHorizontalScrollView;

import java.util.ArrayList;


/**
 * Created by chexiaopeng on 2018/5/3.
 */

public abstract class EsBaseConditionActivity extends EsBaseActivity implements  EsHorizontalScrollView.OnScrollChangeListener{

    protected EsBaseToolBar mBaseToolBar;
    protected RecyclerView mRecyclerView;
    protected EsHorizontalScrollView mScrollView;
    protected ArrayList<OrderData> mOrderDatas = new ArrayList<>();
    protected RecyclerView.Adapter<? extends RecyclerView.ViewHolder> mAdapter;

    protected  abstract void initViewValue();
    protected  abstract void bindOnClick();
    protected  abstract void initAdapter();
    protected  abstract void getOrderData();

    @Override
    protected void initWidget() {
        super.initWidget();
        initView();
        initAdapter();
        initViewValue();
        bindOnClick();
        initRecycleView();
        initScrollView();
    }

    protected  void initView(){
        mBaseToolBar = findViewById(R.id.es_activity_condition_order_toolbar);
        mRecyclerView = findViewById(R.id.es_activity_condition_order_rv_conditional_order);
    }

    protected  void initRecycleView(){
        // 设置启动列表的修改动画效果(默认为关闭状态)
        RecyclerView.ItemAnimator animator = mRecyclerView.getItemAnimator();
        if (animator instanceof SimpleItemAnimator){
            ((SimpleItemAnimator) animator).setSupportsChangeAnimations(true);
        }
        mRecyclerView.getItemAnimator().setChangeDuration(300);
        mRecyclerView.getItemAnimator().setMoveDuration(300);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);
    }

    @Override
    protected int getContentView() {
        return 0;
    }

    @Override
    protected void initData() {
        super.initData();
        getOrderData();
    }

//    @Override
//    public void onScrollChange(View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
//        if(mAdapter instanceof EsConditionalOrderAdapter){
//            ((EsConditionalOrderAdapter)mAdapter).buttonScroll(scrollX);
//        }
//    }

    private void initScrollView(){
        mScrollView = findViewById(R.id.es_activity_condition_order_scrollerView);
        mScrollView.setOnScrollChangeListener(this);
    }
}
