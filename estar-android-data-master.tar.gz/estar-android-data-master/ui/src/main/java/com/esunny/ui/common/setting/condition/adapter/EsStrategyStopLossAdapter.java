package com.esunny.ui.common.setting.condition.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.OpenOrder;
import com.esunny.ui.R;
import com.esunny.ui.view.EsIconTextView;

import java.util.List;

public class EsStrategyStopLossAdapter extends RecyclerView.Adapter<EsStrategyStopLossAdapter.ViewHolder> {

    private Context mContext;
    private List<OpenOrder> mData;

    public EsStrategyStopLossAdapter(Context context) {
        mContext = context;
    }

    public void setData(List<OpenOrder> list) {
        mData = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_strategy_stop_loss_open_adapter, parent, false);
        return new ViewHolder(view, true);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        OpenOrder openOrder = mData.get(position);
        char strategyType = openOrder.getStrategyType();
        double stopPrice = openOrder.getStopPrice();
        char validType = openOrder.getValidType();

        // 委托价格类型
        holder.mTvStopPrice.setText(String.valueOf(stopPrice));

        String text = "";
        if (strategyType == EsDataConstant.S_ST_STOPLOSS) {
            text = mContext.getString(R.string.es_stop_loss_open_dialog_condition_stop_loss);
            holder.mTvStopPriceType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_loss));
        } else if (strategyType == EsDataConstant.S_ST_STOPPROFIT) {
            text = mContext.getString(R.string.es_stop_loss_open_dialog_condition_stop_profit);
            holder.mTvStopPriceType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_profit));
        }  else if (strategyType == EsDataConstant.S_ST_FLOATSTOPLOSS) {
            text = mContext.getString(R.string.es_stop_loss_open_dialog_condition_stop_loss);
            holder.mTvStopPriceType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_loss_diff));
        } else if (strategyType == EsDataConstant.S_ST_BREAKEVEN) {
            text = mContext.getString(R.string.es_stop_loss_open_dialog_condition_keep);
            holder.mTvStopPriceType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_profit_diff));
        }

        if (validType == EsDataConstant.S_VALIDTYPE_GFD) {
            text += "-" + mContext.getString(R.string.es_strategy_input_view_today);
        } else if (validType == EsDataConstant.S_VALIDTYPE_GTC) {
            text += "-" + mContext.getString(R.string.es_strategy_input_view_long);
        }

        holder.mTvStopType.setText(text);

        // 特殊委托价填setOrderPriceType和setOrderPriceOver，否则setOrderPriceType和setOrderPrice
        holder.mTvDelegatePriceType.setText(openOrder.getPriceStr());
        holder.mIconDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mData.remove(holder.getAdapterPosition());
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView mTvStopType;
        TextView mTvStopPriceType;
        TextView mTvStopPrice;
        TextView mTvDelegatePriceType;
        EsIconTextView mIconDelete;

        public ViewHolder(View itemView, boolean isItem) {
            super(itemView);
            if (isItem) {
                mTvStopType = itemView.findViewById(R.id.es_item_stop_loss_open_tv_stop_type);
                mTvStopPriceType = itemView.findViewById(R.id.es_item_stop_loss_open_tv_stop_price_type);
                mTvStopPrice = itemView.findViewById(R.id.es_item_stop_loss_open_tv_stop_price);
                mTvDelegatePriceType = itemView.findViewById(R.id.es_item_stop_loss_open_tv_delegate_price_type);
                mIconDelete = itemView.findViewById(R.id.es_item_bank_list_etv_check);
            }
        }
    }
}
