package com.esunny.ui.api;

public class RoutingTable {
    private final static String GROUP = "estarUIApi";

    private final static String ES_QUOTE_MODULE = "/" + GROUP + "/quote";
    public final static String ES_QUOTE_FRAGMENT = ES_QUOTE_MODULE + "/quoteFragment";
    public final static String ES_FAVORITE_FRAGMENT = ES_QUOTE_MODULE + "/favoriteFragment";
    public final static String ES_OPTION_FRAGMENT = ES_QUOTE_MODULE + "/optionFragment";
    public final static String ES_FUNDS_FRAGMENT = ES_QUOTE_MODULE + "/fundsFragment";
    public final static String ES_FAVORITE_EDIT_ACTIVITY = ES_QUOTE_MODULE + "/favoriteEditActivity";

    private final static String ES_SEARCH_MODULE = "/" + GROUP + "/search";
    public final static String ES_SEARCH_ACTIVITY = ES_SEARCH_MODULE + "/activity";


    public final static String ES_KLINE_ACTIVITY = ES_QUOTE_MODULE + "/klineActivity";

    private final static String ES_TRADE_MODULE = "/" + GROUP + "/trade";
    public final static String ES_TRADE_FRAGMENT = ES_TRADE_MODULE + "/tradeFragment";

    private final static String ES_COMMON_MODULE = "/" + GROUP + "/common";
    public final static String ES_NEWS_FRAGMENT = ES_COMMON_MODULE + "/newsFragment";
    public final static String ES_LOGIN_FRAGMENT = ES_COMMON_MODULE + "/loginFragment";
    public final static String ES_NEWS_DETAIL_ACTIVITY = ES_COMMON_MODULE + "/loginActivity";

    private final static String ES_LOGIN_MODULE = "/" + GROUP + "/login";
    public final static String ES_LOGIN_ACTIVITY = ES_LOGIN_MODULE + "/activity";
    public final static String ES_COMPANY_LIST_ACTIVITY = ES_LOGIN_MODULE + "/companyListactivity";
    public final static String ES_STAR_LOGIN_ACTIVITY = ES_LOGIN_MODULE + "/statActivity";
    public final static String ES_STAR_STORE_ACTIVITY = ES_LOGIN_MODULE + "/estarStoreActivity";
    public final static String ES_ACCOUNT_SELECT_ACTIVITY = ES_LOGIN_MODULE + "/accountSelectActivity";
    public final static String ES_ACCOUNT_DETAIL_ACTIVITY = ES_LOGIN_MODULE + "/accountDetailActivity";
    public final static String ES_CHOOSE_CURRENCY_NO_ACTIVITY =  ES_LOGIN_MODULE + "/chooseCurrenNoActivity";
    public final static String ES_BILL_STATE_CONFIRM_ACTIVITY = ES_LOGIN_MODULE + "/billStateConfirmActivity";
    public final static String ES_DISCLAIMER_ACTIVITY = ES_LOGIN_MODULE + "/disClaimerActivity";
    public final static String ES_PRIVACY_ACTIVITY = ES_LOGIN_MODULE + "/privacyActivity";
    public final static String ES_NOTICE_ACTIVITY = ES_LOGIN_MODULE + "/noticeActivity";

    private final static String ES_STRATEGY_MODULE = "/" + GROUP + "/strategy";
    public final static String ES_CONDITIONAL_ORDER_ACTIVITY = ES_STRATEGY_MODULE + "/conditionalOrderActivity";
    public final static String ES_STOP_LP_ORDER_ACTIVITY = ES_STRATEGY_MODULE + "/stopLPOrderActivity";
    public final static String ES_PRICE_WARN_ACTIVITY = ES_STRATEGY_MODULE + "/priceWarningActivity";
    public final static String ES_STRATEGY_CONDITION_ACTIVITY = ES_STRATEGY_MODULE + "/strategyActivity";
    public final static String ES_POSITION_STOP_LOSS_PANEL_ACTIVITY = ES_STRATEGY_MODULE + "/positionStopLossPanelActivity";
    public final static String ES_TRIGGERED_CONDITIONAL_ORDER_ACTIVITY = ES_STRATEGY_MODULE + "/esTriggeredConditionalOrderActivity";
    public final static String ES_TRIGGERED_STOP_LOSS_ORDER_ACTIVITY = ES_STRATEGY_MODULE + "/esTriggeredStopLossPanelActivity";

    private final static String ES_SETTING_MODULE = "/" + GROUP + "/setting";
    public final static String ES_BILL_QUERY_ACTIVITY = ES_SETTING_MODULE + "/billQueryActivity";
    public final static String ES_BANK_TRANSFER_ACTIVITY = ES_SETTING_MODULE + "/bankTransferActivity";
    public final static String ES_TRADE_LOG_ACTIVITY = ES_SETTING_MODULE + "/tradeLogActivity";
    public final static String ES_TRADE_SETTING_ACTIVITY = ES_SETTING_MODULE + "/tradeSettingActivity";
    public final static String ES_CHART_SETTING_ACTIVITY = ES_SETTING_MODULE + "/chartSettingActivity";
    public final static String ES_ABOUT_ACTIVITY = ES_SETTING_MODULE + "/aboutActivity";
    public final static String ES_SYSTEM_SETTING_ACTIVITY = ES_SETTING_MODULE + "/systemSettingActivity";
    public final static String ES_PASSWORD_ACTIVITY = ES_SETTING_MODULE + "/passwordActivity";
    public final static String ES_MESSAGE_ACTIVITY = ES_SETTING_MODULE + "/messageActivity";
    public final static String ES_TRADE_ABOUT_ACTIVITY = ES_SETTING_MODULE + "/tradeAboutActivity";
    public final static String ES_SWITCH_LANGUAGE_ACTIVITY = ES_SETTING_MODULE + "/switchLanguageActivity";
    public final static String ES_SWITCH_TEXT_SIZE_ACTIVITY = ES_SETTING_MODULE + "/switchTextSizeActivity";
    public final static String ES_CHOOSE_RINGTONG_ACTIVITY = ES_SETTING_MODULE + "/ChooseRingTongActivity";
    public final static String ES_STOP_LOSS_OPEN_ACTIVITY = ES_LOGIN_MODULE + "/stopLossOpenActivity";

    public final static String ES_OPEN_ONLINE_ACTIVITY = "/estar/esTriggeredStopLossPanelActivity";

    public final static String ES_START_ACTIVITY = "/estar/startActivity";
    public final static String ES_UPDATE_ACTIVITY = "/estar/updateActivity";
}
