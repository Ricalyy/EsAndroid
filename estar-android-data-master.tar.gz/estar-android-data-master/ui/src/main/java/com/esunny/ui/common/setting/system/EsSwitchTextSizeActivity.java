package com.esunny.ui.common.setting.system;

import android.view.View;
import android.widget.RelativeLayout;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsIconTextView;


@Route(path = RoutingTable.ES_SWITCH_TEXT_SIZE_ACTIVITY)
public class EsSwitchTextSizeActivity extends EsBaseActivity implements View.OnClickListener{


    EsBaseToolBar mToolbar;
    RelativeLayout mRlTextSizeXL, mRlTextSizeL, mRlTextSizeM, mRlTextSizeS;
    EsIconTextView mEtvTextXL, mEtvTextL, mEtvTextM, mEtvTextS;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_switch_text_size;
    }

    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindViewValue();
        bindOnClick();
    }


    private void bindViewValue() {
        mToolbar.setSimpleBack(getString(R.string.es_activity_system_setting_choose_text_size));

        switch (EsSPHelperProxy.getQuoteTextSize(this)){
            case EsSPHelperProxy.QUOTE_TEXT_SIZE_XL:
                updateTextSizeCheckUI(mEtvTextXL);
                break;
            case EsSPHelperProxy.QUOTE_TEXT_SIZE_L:
                updateTextSizeCheckUI(mEtvTextL);
                break;
            case EsSPHelperProxy.QUOTE_TEXT_SIZE_M:
                updateTextSizeCheckUI(mEtvTextM);
                break;
            case EsSPHelperProxy.QUOTE_TEXT_SIZE_S:
                updateTextSizeCheckUI(mEtvTextS);
                break;
        }
    }

    private void bindOnClick() {
        mRlTextSizeXL.setOnClickListener(this);
        mRlTextSizeL.setOnClickListener(this);
        mRlTextSizeM.setOnClickListener(this);
        mRlTextSizeS.setOnClickListener(this);
    }

    private void bindView() {
        mToolbar = findViewById(R.id.es_activity_switch_text_size_toolbar);
        mRlTextSizeXL = findViewById(R.id.es_activity_switch_text_size_xl);
        mRlTextSizeL = findViewById(R.id.es_activity_switch_text_size_l);
        mRlTextSizeM = findViewById(R.id.es_activity_switch_text_size_m);
        mRlTextSizeS = findViewById(R.id.es_activity_switch_text_size_s);
        mEtvTextXL = findViewById(R.id.es_activity_etv_switch_text_size_xl);
        mEtvTextL = findViewById(R.id.es_activity_etv_switch_text_size_l);
        mEtvTextM = findViewById(R.id.es_activity_etv_switch_text_size_m);
        mEtvTextS = findViewById(R.id.es_activity_etv_switch_text_size_s);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.es_activity_switch_text_size_xl){
            clickToSwitch(mEtvTextXL);
        }else if (v.getId() == R.id.es_activity_switch_text_size_l){
            clickToSwitch(mEtvTextL);
        }else if (v.getId() == R.id.es_activity_switch_text_size_m){
            clickToSwitch(mEtvTextM);
        }else if (v.getId() == R.id.es_activity_switch_text_size_s){
            clickToSwitch(mEtvTextS);
        }
    }

    private void clickToSwitch(View view) {
        if (isSwitchTextSize(view)) {
            if (view == mEtvTextXL) {
                saveTextSizeConfig(EsSPHelperProxy.QUOTE_TEXT_SIZE_XL);
            } else if (view == mEtvTextL) {
                saveTextSizeConfig(EsSPHelperProxy.QUOTE_TEXT_SIZE_L);
            } else if (view == mEtvTextM) {
                saveTextSizeConfig(EsSPHelperProxy.QUOTE_TEXT_SIZE_M);
            } else if (view == mEtvTextS) {
                saveTextSizeConfig(EsSPHelperProxy.QUOTE_TEXT_SIZE_S);
            }

            updateTextSizeCheckUI(view);
        }
    }

    private boolean isSwitchTextSize(View view){
        if(view.getVisibility() == View.VISIBLE){
//            Toast.makeText(this,
//                    getString(R.string.es_activity_switch_language_has_switched) +
//                            EsLanguageHelper.getLaguageStrByType(this, EsLanguageHelper.getFavoriteLanguage()),
//                    Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void updateTextSizeCheckUI(View view) {
        mEtvTextXL.setVisibility(View.GONE);
        mEtvTextL.setVisibility(View.GONE);
        mEtvTextM.setVisibility(View.GONE);
        mEtvTextS.setVisibility(View.GONE);

        view.setVisibility(View.VISIBLE);
    }

    private void saveTextSizeConfig(int type) {
        EsSPHelperProxy.setQuoteTextSize(this, type);
    }
}
