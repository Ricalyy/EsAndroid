package com.esunny.ui.common.setting.quote.login;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsWebUrlData;
import com.esunny.ui.view.EsBaseToolBar;


public class EsForgetPasswordActivity extends EsBaseActivity {

    static final String ACTIVITY_TYPE_KEY = "type";
    static final int ACTIVITY_TYPE_VALUE_FORGETPASSWORD = 0;
    static final int ACTIVITY_TYPE_VALUE_REGISTER = 1;
    EsBaseToolBar mToolbar;
    WebView webView;
    ProgressBar progressBar;
    private int  Type;

    @Override
    protected void initData() {
        super.initData();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE| WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        Type = getIntent().getIntExtra(ACTIVITY_TYPE_KEY, 0);
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        bindView();
        bindViewValue();
        initWebview();
    }

    private void initWebview() {
        webView.getSettings().setTextZoom(100);
        webView.getSettings().setJavaScriptEnabled(true);
        final WebSettings webSettings = webView.getSettings();
        webSettings.setDomStorageEnabled(true);
        webView.setBackgroundColor(Color.TRANSPARENT);

        webView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
            }
        });

        if (Type == ACTIVITY_TYPE_VALUE_FORGETPASSWORD) {
            webView.loadUrl(EsWebUrlData.getEstarFindPasswordUrl(this));
        } else if (Type == ACTIVITY_TYPE_VALUE_REGISTER) {
            webView.loadUrl(EsWebUrlData.getEstarRegisterUrl(this));
        }
    }

    private void bindViewValue() {
        if (Type == ACTIVITY_TYPE_VALUE_FORGETPASSWORD) {
            mToolbar.setSimpleBack(getString(R.string.es_activity_estar_login_forget_password));
        } else if (Type == ACTIVITY_TYPE_VALUE_REGISTER) {
            mToolbar.setSimpleBack(getString(R.string.es_activity_es_register_title));
        }
    }

    private void bindView() {
        mToolbar = findViewById(R.id.activity_es_forget_toolbar);
        webView = findViewById(R.id.activity_es_forget_webview);
        progressBar = findViewById(R.id.activity_es_forget_progressbar);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_forget_password;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            webView.clearHistory();

            ((ViewGroup) webView.getParent()).removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
