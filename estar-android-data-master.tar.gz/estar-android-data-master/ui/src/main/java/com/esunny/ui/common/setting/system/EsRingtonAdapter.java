package com.esunny.ui.common.setting.system;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esunny.ui.R;
import com.esunny.ui.common.setting.trade.adapter.EsTradePriceChooseListAdapter;
import com.esunny.ui.trade.data.EsTradePriceTypeInfo;
import com.esunny.ui.view.EsIconTextView;

import java.util.List;

/**
 * @author Peter Fu
 * @date 2020/9/24
 */
public class EsRingtonAdapter extends RecyclerView.Adapter<EsRingtonAdapter.ViewHolder> {

    private List<String> mDataList;
    private int mCheckedPosition;
    private OnItemSelected mLister;

    public void setmDataList(List<String> mDataList) {
        this.mDataList = mDataList;
    }

    public interface OnItemSelected {
        void onItemSelected(int position);
    }

    public void setmLister(OnItemSelected mLister) {
        this.mLister = mLister;
    }

    public void setmCheckedPosition(int mCheckedPosition) {
        this.mCheckedPosition = mCheckedPosition;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_choose_defaule_price, parent, false);
        return new ViewHolder(view, true);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        if (position < getItemCount()){
            holder.mTvRingName.setText(mDataList.get(position));

            if (mCheckedPosition == position) {
                holder.etv_check.setVisibility(View.VISIBLE);
            } else {
                holder.etv_check.setVisibility(View.GONE);
            }

            holder.rl_main.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mCheckedPosition = position;
                    if (mLister != null) {
                        mLister.onItemSelected(position);
                    }

                    notifyDataSetChanged();
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return  mDataList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView mTvRingName;
        RelativeLayout rl_main;
        EsIconTextView etv_check;

        public ViewHolder(View itemView, boolean isItem) {
            super(itemView);
            if (isItem) {
                mTvRingName = itemView.findViewById(R.id.es_item_choose_default_price_tv_price_type);
                rl_main = itemView.findViewById(R.id.es_item_choose_default_rl_main);
                etv_check = itemView.findViewById(R.id.es_item_choose_default_price_tv_check);
            }
        }
    }
}
