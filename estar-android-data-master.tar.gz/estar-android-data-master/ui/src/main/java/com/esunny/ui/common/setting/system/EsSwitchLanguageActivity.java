package com.esunny.ui.common.setting.system;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.ui.R;
import com.esunny.ui.api.EsUIBaseAPI;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.dialog.EsCustomTipsDialog;
import com.esunny.ui.util.EsLanguageHelper;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsIconTextView;


@Route(path = RoutingTable.ES_SWITCH_LANGUAGE_ACTIVITY)
public class EsSwitchLanguageActivity extends EsBaseActivity implements View.OnClickListener{

    EsBaseToolBar mToolbar;
    RelativeLayout mRlDefault, mRlChina, mRlEnglish, mRlHonkong;
    EsIconTextView mEtvDefault, mEtvChina, mEtvEnglish, mEtvHongkong;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_switch_language;
    }

    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected void initWidget() {
        bindView();
        bindViewValue();
        bindViewClick();
    }

    private void bindViewClick() {
        mRlDefault.setOnClickListener(this);
        mRlEnglish.setOnClickListener(this);
        mRlChina.setOnClickListener(this);
        mRlHonkong.setOnClickListener(this);
    }

    private void bindViewValue() {
        mToolbar.setSimpleBack(getString(R.string.es_activity_system_setting_switch_language));

        switch (EsLanguageHelper.getFavoriteLanguage(this)){
            case EsLanguageHelper.LOCALE_DEFAULT:
                updateLaguageCheckUI(mEtvDefault);
                break;
            case EsLanguageHelper.LOCALE_ENGLISH:
                updateLaguageCheckUI(mEtvEnglish);
                break;
            case EsLanguageHelper.LOCALE_CHINA:
                updateLaguageCheckUI(mEtvChina);
                break;
            case EsLanguageHelper.LOCALE_HONGKONG:
                updateLaguageCheckUI(mEtvHongkong);
                break;
        }
    }

    private void bindView() {
        mToolbar = findViewById(R.id.es_activity_switch_language_toolbar);
        mRlDefault = findViewById(R.id.es_activity_switch_language_default);
        mRlEnglish = findViewById(R.id.es_activity_switch_language_english);
        mRlChina = findViewById(R.id.es_activity_switch_language_china);
        mRlHonkong = findViewById(R.id.es_activity_switch_language_hokong);
        mEtvDefault = findViewById(R.id.es_activity_switch_language_etv_default);
        mEtvChina = findViewById(R.id.es_activity_switch_language_etv_china);
        mEtvEnglish = findViewById(R.id.es_activity_switch_language_etv_english);
        mEtvHongkong = findViewById(R.id.es_activity_switch_language_etv_hongkong);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.es_activity_switch_language_default){
            clickToSwitch(mEtvDefault);
        }else if (v.getId() == R.id.es_activity_switch_language_english){
            clickToSwitch(mEtvEnglish);
        }else if (v.getId() == R.id.es_activity_switch_language_china){
            clickToSwitch(mEtvChina);
        }else if (v.getId() == R.id.es_activity_switch_language_hokong){
            clickToSwitch(mEtvHongkong);
        }
    }

    private void clickToSwitch(final View view) {
        if (isSwitchLanguage(view)) {
            final EsCustomTipsDialog dialog = EsCustomTipsDialog.create(this,
                    getString(R.string.es_base_view_tips),
                    getString(R.string.es_activity_switch_language_will_be_switched));
            dialog.setCanceledOnTouchOutside(false);
            dialog.setCancelListener(new EsCustomTipsDialog.EsCustomTipsDialogListener() {
                @Override
                public void onCancel() {
                    if (view == mEtvDefault) {
                        saveLanaugeConfig(EsLanguageHelper.LOCALE_DEFAULT);
                    } else if (view == mEtvEnglish) {
                        saveLanaugeConfig(EsLanguageHelper.LOCALE_ENGLISH);
                    } else if (view == mEtvChina) {
                        saveLanaugeConfig(EsLanguageHelper.LOCALE_CHINA);
                    } else if (view == mEtvHongkong) {
                        saveLanaugeConfig(EsLanguageHelper.LOCALE_HONGKONG);
                    }
                    updateLaguageCheckUI(view);
                    dialog.dismiss();
                }
            });
            dialog.show();
        }
    }

    private void updateLaguageCheckUI(View view) {
        mEtvDefault.setVisibility(View.GONE);
        mEtvChina.setVisibility(View.GONE);
        mEtvEnglish.setVisibility(View.GONE);
        mEtvHongkong.setVisibility(View.GONE);

        view.setVisibility(View.VISIBLE);
    }

    private void saveLanaugeConfig(int type){
        EsLanguageHelper.saveFavoriteLanguage(this, type);
    }


    private boolean isSwitchLanguage(View view){
        if(view.getVisibility() == View.VISIBLE){
            ToastHelper.show(this, getString(R.string.es_activity_switch_language_has_switched) +
                    EsUIBaseAPI.getLaguageStrByType(this, EsLanguageHelper.getFavoriteLanguage(this)));
            return false;
        }
        return true;
    }
}
