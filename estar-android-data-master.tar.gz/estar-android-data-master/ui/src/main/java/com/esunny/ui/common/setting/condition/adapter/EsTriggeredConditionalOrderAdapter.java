package com.esunny.ui.common.setting.condition.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.util.EstarTransformation;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.R;
import com.esunny.ui.util.EsCommonUtil;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.EstarFieldTransformation;

import java.util.List;
import java.util.Locale;


public class EsTriggeredConditionalOrderAdapter extends RecyclerView.Adapter<EsTriggeredConditionalOrderAdapter.ViewHolder> {

    public static final int ListTypeCondition = 0;
    public static final int ListTypeStopLossProfit = 1;

    private Context             mContext;
    private int                 mOpenedIndex = -1;
    private int                 mListType = ListTypeCondition;
    private List<OrderData>    mOrderData;

    public void reSetOpenedIndex(){
        mOpenedIndex = -1;
        notifyDataSetChanged();
    }

    public void setListType(int type){
        mListType = type;
    }

    public EsTriggeredConditionalOrderAdapter(Context context){
        this.mContext = context;
    }

    @Override
    public EsTriggeredConditionalOrderAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        if(mListType == ListTypeCondition){
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_cloud_triggered_conditional_order, parent, false);
        }else{
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_cloud_triggered_stop_loss_profit_order, parent, false);
        }

        return new EsTriggeredConditionalOrderAdapter.ViewHolder(view, true);
    }

    @Override
    public void onBindViewHolder(EsTriggeredConditionalOrderAdapter.ViewHolder holder, int position) {
        if (position < getItemCount() && position < mOrderData.size()) {
            final OrderData sOrderData = getItem(position);
            if (sOrderData != null) {
                final String contractNo = sOrderData.getContractNo();
                String contractName = EsDataApi.getContractName(contractNo);
                Contract contract = EsDataApi.getQuoteContract(sOrderData.getContractNo());
                if(contractName == null){
                    contractName = contractNo;
                }
                String triggerTime = sOrderData.getUpdateDateTime();
                String type;
                String condition = "";
                String bonusCondition;
                char strategyType = sOrderData.getStrategyType();
                if (strategyType == EsDataConstant.S_ST_AUTOORDER){
                    condition = mContext.getString(R.string.es_strategy_time_keyboard_opentrigger);
                    type = mContext.getString(R.string.es_strategy_condition_type_time);
                } else if (strategyType == EsDataConstant.S_ST_CONDITION
                    || strategyType == EsDataConstant.S_ST_CONDITION_PARENT
                    || strategyType == EsDataConstant.S_ST_BACKHAND) {//条件单条件
                    if(sOrderData.getTimeCondition().length() == 0 && sOrderData.getTriggerCondition()!=0) {
                        double price = sOrderData.getTriggerPrice();
                        String priceStr;
                        if(contract!=null){
                            priceStr = EsDataApi.formatPrice(contract.getCommodity(),price);
                        }else {
                            priceStr = Double.toString(price);
                        }
                        condition = String.format(Locale.getDefault(),"%s%s%s",
                                EstarTransformation.triggerModeType2Str(mContext, sOrderData.getTriggerMode()),
                                EstarTransformation.conditionCompareType2Str(sOrderData.getTriggerCondition()),priceStr);
                        type = mContext.getString(R.string.es_strategy_condition_type_price);
                    } else {
                        condition = sOrderData.getTimeCondition();
                        type = mContext.getString(R.string.es_strategy_condition_type_time);
                    }

                    if (strategyType == EsDataConstant.S_ST_BACKHAND) {
                        type += "\n-" + mContext.getString(R.string.es_reverse_postion_order_name);
                    } else if (strategyType == EsDataConstant.S_ST_CONDITION_PARENT) {
                        type += "\n-" + mContext.getString(R.string.es_setting_stop_trade);
                    }
                } else {//止损单条件
                    type = EstarTransformation.StrategyType2String(mContext, strategyType);
                    if (contract != null) {
                        condition = String.format(Locale.getDefault(), "%s %s",
                                EstarTransformation.stopPriceType2Str(mContext, strategyType),
                                EsDataApi.formatPrice(contract.getCommodity(), strategyType));
                    }
                }

                if (sOrderData.getOrderWay() == EsDataConstant.S_ORDERWAY_DRAWLINE) {
                    // 对于所有画线下单类型需额外显示为划线下单
                    type = mContext.getString(R.string.es_kline_bottom_draw_line);
                }

                if(sOrderData.getTriggerCondition2()!=0 && (strategyType == EsDataConstant.S_ST_CONDITION
                    || strategyType == EsDataConstant.S_ST_CONDITION_PARENT
                        || strategyType == EsDataConstant.S_ST_BACKHAND)) {//附加条件
                    double price = sOrderData.getTriggerPrice2();
                    String priceStr;
                    if(contract!=null){
                        priceStr = EsDataApi.formatPrice(contract.getCommodity(),price);
                    }else {
                        priceStr = Double.toString(price);
                    }
                    bonusCondition = String.format(Locale.getDefault(),"%s%s%s",
                            EstarTransformation.triggerModeType2Str(mContext, sOrderData.getTriggerMode2()),
                            EstarTransformation.conditionCompareType2Str(sOrderData.getTriggerCondition2()),priceStr);
                }else {
                    bonusCondition = mContext.getString(R.string.es_strategy_bonus_condition_null);
                }

                String direct = EstarTransformation.Direct2BuySellString(mContext, sOrderData.getDirect()) + EstarTransformation.Offset2String(mContext, sOrderData.getOffset());
                String qty = sOrderData.getOrderQty().toString();
                String avTime = EstarTransformation.conditionValidType2Str(mContext, sOrderData.getValidType());
                String insertTime = sOrderData.getInsertDateTime();

                String orderPrice;

                if(sOrderData.getOrderPriceType() == EsDataConstant.S_PT_ABS){
                    if(contract!=null){
                        orderPrice = EsDataApi.formatPrice(contract.getCommodity(),sOrderData.getOrderPrice());
                    }else {
                        orderPrice = EsCommonUtil.formatDouble(sOrderData.getOrderPrice());
                    }
                }else {
                    orderPrice = EstarTransformation.apiPriceTypeToStr(mContext, sOrderData.getOrderPriceType());
                    if(sOrderData.getOrderPriceOver()!=0 && contract!=null){
                        if(sOrderData.getOrderPriceOver() < 0){
                            orderPrice =orderPrice + String.valueOf((int)(sOrderData.getOrderPriceOver() / contract.getCommodity().getTickPrice()))+
                                    mContext.getString(R.string.es_strategy_condition_list_tick);
                        }else{
                            orderPrice =orderPrice + "+" + String.valueOf((int)(sOrderData.getOrderPriceOver() / contract.getCommodity().getTickPrice()))+
                                    mContext.getString(R.string.es_strategy_condition_list_tick);
                        }
                    }
                }

                String hedgeString = EstarTransformation.Hedge2String(mContext, sOrderData.getHedge(), contractNo) ;
                holder.mTvHedge.setText(hedgeString);

                //Update UI
                holder.mTvContractNo.setText(contractName);
                holder.mTvStatus.setText(EstarTransformation.OrderState2String(mContext, sOrderData.getOrderState(), sOrderData.getOrderType()));
                holder.mTvStatus.setTextColor(EstarFieldTransformation.getOrderStateColor(mContext, sOrderData.getOrderState()));
                holder.mTvTriggerTime.setText(triggerTime);
                holder.mTvType.setText(type);
                holder.mTvCondition.setText(condition);
                holder.mTvDirect.setText(direct);
                holder.mTvQty.setText(qty);
                holder.mTvAvtime.setText(avTime);
                holder.mTvOrderPrice.setText(orderPrice);
                holder.mTvErrorText.setText(sOrderData.getErrorText());
                holder.mTvInserttime.setText(insertTime);
                holder.bind(position);

                if (mListType == ListTypeCondition) {
                    holder.mTvBonusCondition.setText(bonusCondition);
                    holder.mTvDelegateType.setText(EstarTransformation.delegateWayToStr(mContext, sOrderData.getOrderWay()));
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return mOrderData == null ? 0 : mOrderData.size();
    }

    public OrderData getItem(int position) {
        if (position < mOrderData.size())
            return mOrderData.get(position);
        else return null;
    }

    public void setOrderData(List<OrderData> data) {
        this.mOrderData = data;
    }

    public List<OrderData> getOrderData() {
        return mOrderData;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView mTvContractNo;
        TextView mTvStatus;
        TextView mTvTriggerTime;
        TextView mTvType;
        TextView mTvCondition;
        TextView mTvBonusCondition;
        TextView mTvDirect;
        TextView mTvQty;
        TextView mTvOrderPrice;
        TextView mTvAvtime;
        TextView mTvErrorText;
        TextView mTvInserttime;
        RelativeLayout mRlRevoke;
        TextView mTvDelete;
        TextView mTvDelegateType;
        TextView mTvHedge;
        LinearLayout mLlMain;
        // 实例化
        public ViewHolder(View itemView, boolean isItem) {
            super(itemView);
            if (isItem){
               initItemView();
            }
        }

        // 此方法实现列表的展开和关闭
        public void bind(int pos) {
            if (pos == mOpenedIndex) {
                mRlRevoke.setVisibility(View.VISIBLE);
                mLlMain.setBackgroundResource(R.color.es_bg_ll_condition_order_main_content);
                mRlRevoke.setBackgroundResource(R.color.es_bg_ll_condition_order_main_content);
            } else {
                mRlRevoke.setVisibility(View.GONE);
                mLlMain.setBackgroundResource(R.color.es_bg_item_condition_order);
            }
        }

        private void initItemView() {
            mTvContractNo = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_contract_no);
            mTvStatus = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_status);
            mTvTriggerTime = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_triggerTime);
            mTvType = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_type);
            mTvCondition = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_condition);
            mTvDirect = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_direct);
            mTvQty = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_qty);
            mTvOrderPrice = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_orderPrice);
            mTvAvtime = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_validType);
            mTvErrorText = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_error_text);
            mTvInserttime = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_insertTime);
            mRlRevoke = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_rl_revoke);
            mTvDelete = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_delete);
            mLlMain = itemView.findViewById(R.id.es_item_triggered_conditional_order_ll_main);
            mTvHedge = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_hedge);
            if (mListType == ListTypeCondition) {
                mTvDelegateType = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_order_way);
                mTvBonusCondition = itemView.findViewById(R.id.es_item_cloud_triggered_conditional_order_tv_bonus);
            }
        }
    }
}
