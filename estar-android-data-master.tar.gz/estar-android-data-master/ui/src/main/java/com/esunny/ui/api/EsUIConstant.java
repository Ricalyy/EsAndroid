package com.esunny.ui.api;

public class EsUIConstant {

    //服务类型
    public static final char                        S_SRVSRC_QUOTE            = 'Q';    //行情服务
    public static final char                        S_SRVSRC_HISQUOTE         = 'H';    //历史行情服务
    public static final char                        S_SRVSRC_TRADE            = 'T';    //交易服务
    public static final char                        S_SRVSRC_CLOUD            = 'C';    //云服务
    //k线 合约 列表
    public final static int S_CONTRACT_LIST_QUOTE = 0;
    public final static int S_CONTRACT_LIST_FAVORITE = 1;
    public final static int S_CONTRACT_LIST_FAVORITE_SORT = 2;
    public final static int S_CALL_CONTRACT_LIST_OPTION = 3;
    public final static int S_PUT_CONTRACT_LIST_OPTION = 4;
    public final static int S_MAIN_CONTRACT_LIST_OPTION = 5;

    public static final char S_KLINE_MINUTE            = 'M';    //分钟线
    public static final char S_KLINE_DAY               = 'D';    //日线

    public final static String KEY_SEARCH_SOURCE = "Source";
    public final static String KEY_STATE_CONFIRM_CONTENT = "StateContent";
    public final static String KEY_CONFIRM_LOCALVERSION = "StateContentLocalVersion";
    public final static String KEY_STATE_CONFIRM_TITLE = "StateConfirmTitle";
    public final static String KEY_STATE_CONFIRM_CONFIRM_NAME = "StateConfirmName";
    public final static String KEY_STATE_CONFIRM_CANCEL_NAME = "StateCancelName";
    public final static String KEY_PRIVACY_CONTENT = "Privacy";
    // 是否查看免责声明，从登录处点击风险提示为true，从应用首次安装进去为false
    public final static String KEY_IS_CHECK_STATE_CONFIRM = "Privacy";

    // 股票字符串
    public static final String TRADE_STOCK = "CTPSTOCK";
    public static final String AESCRYPT_GENKEY = "ES_AES_CRYPT_GENKEY";
    // 登录极星用户和密码
    public static final String ESTAR_LOGIN_ACCOUNT = "Estar_login_account";
    public static final String ESTAR_LOGIN_PASSWORD = "Estar_login_password";
    public static final String ESTAR_LOGIN_ACCOUNT_NEW = "Estar_login_account_new";
    public static final String ESTAR_LOGIN_PASSWORD_NEW = "Estar_login_password_new";
    //是否保存极星账号和密码
    public static final String ESTAR_LOGIN_KEEP_PASSWORD = "Estar_login_keep_password";
    //是否保存极星自动登录
    public static final String ESTAR_LOGIN_AUTO_LOGIN = "Estar_login_auto_login";

    public static final short S_EQUITY = 33; //今权益
    public static final short S_FROZENDEPOSIT = 10; //冻结保证金19
    public static final short S_FEE = 11; //手续费(包含交割手续费)
    public static final short S_PROFITRATE = 54; //盈利率
    public static final short S_FLOATPROFITTBT = 24; //逐笔浮赢 TRADE BY TRADE
    public static final short S_FLOATPROFIT = 22; //盯市浮赢(不含LME盯市浮赢)
    public static final short S_RISKRATE = 51; //风险率

    public final static String KEY_INTENT_NEWS_DETAILS_URL = "NewsDetailsUrl";
    public final static String KEY_INTENT_NEWS_QRY_RESULT = "NewsQryResult";

    public static final int S_CHOOSE_CURRENCY_RESULT_CODE = 101;
    public static final int S_STATE_CONFIRM_RESULT_CODE_CONFIRM = 102;
    public static final int S_STATE_CONFIRM_RESULT_CODE_CANCEL = 103;
    public static final int S_PRIVACY_CONFIRM_RESULT_CODE_CANCEL = 104;
    public static final int S_PRIVACY_RESULT_CODE_CONFIRM = 105;
    public static final int S_STATE_CONFIRM_REQUEST_CODE = 202;
    public static final int S_STATE_QUOTE_LOGIN_CODE = 301;
    public static final int S_STATE_QUOTE_LOGIN_APP_EXIT_CODE = 302;
    public static final int S_STATE_QUOTE_LOGIN_LOGIN_SUCCESS_CODE = 303;
    public static final int S_STATE_WELCOME_PAGE_CODE = 401;
    public static final int S_STATE_MULTI_LOGIN_CODE = 501;
    public static final int S_NOTICE_RESULT_CODE_CONFIRM = 601;
    public static final int S_STATE_AUTHENTICATION_REQUEST_CODE = 701;

    public static final int S_UPDATE_RESULT_CODE_CANCEL = 701;

    public static final int TO_KLINE_FROM_CONDITIONAL = 1;
    public static final int TO_KLINE_FROM_STOPLOSSPROFIT = 2;
    public static final int TO_KLINE_FROM_PRICEWARN = 3;
    public static final int TO_KLINE_FROM_SORTQUOTE = 4;

    // 行情单行的title
    public static final String QUOTE_RISE = "rise";
    public static final String QUOTE_RISE_DIFF = "riseDiff";
    public static final String QUOTE_MATCH_QTY = "matchQty";
    public static final String QUOTE_POSITION_QTY = "positionQty";
    public static final String QUOTE_INCREASE_QTY = "increaseQty";
    public static final String QUOTE_BUY_QTY = "buyQty";
    public static final String QUOTE_SELL_QTY = "sellQty";
    public static final String QUOTE_LAST_QTY = "lastQty";
    public static final String QUOTE_BUY_PRICE = "buyPrice";
    public static final String QUOTE_SELL_PRICE = "sellPrice";
    public static final String QUOTE_LAST_PRICE = "lastPrice";
    public static final String QUOTE_SETTLE_PRICE = "settlePrice";
    public static final String QUOTE_AVERAGE_PRICE = "averagePrice";
    public static final String QUOTE_HIGH_PRICE = "highPrice";
    public static final String QUOTE_LOW_PRICE = "lowPrice";
    public static final String QUOTE_LIMIT_UP_PRICE = "limitUpPrice";
    public static final String QUOTE_LIMIT_DOWN_PRICE = "limitDownPrice";


    // 行情双行的title
    public static final String QUOTE_RISE_AND_DIFF = "rise-riseDiff";
    public static final String QUOTE_MATCH_AND_POSITION = "matchQty-positionQty";
    public static final String QUOTE_BUY_SELL_PRICE = "buyPrice-sellPrice";
    public static final String QUOTE_BUY_SELL_QTY = "buyQty-sellQty";
    public static final String QUOTE_HIGH_LOW_PRICE = "highPrice-lowPrice";
    public static final String QUOTE_MAX_MIN_PRICE = "limitUpPrice-limitDownPrice";

    // 成交列表的title
    public static final String TRADE_CONTRACT_NO = "contractNo";
    public static final String TRADE_CONTRACT_NAME = "contractName";
    public static final String TRADE_DIRECT_OFFSET = "directOffset";
    public static final String TRADE_MATCH_PRICE = "matchPrice";
    public static final String TRADE_MATCH_QTY = "matchQty";
    public static final String TRADE_MATCH_TIME = "matchTime";
    public static final String TRADE_MATCH_SOURCE = "matchSource";
    public static final String TRADE_SERVICE_CHARGE = "serviceCharge";
    public static final String TRADE_ROYALTY = "royalty";
    public static final String TRADE_CONTRACT_TYPE = "contractType";
    public static final String TRADE_EXCHANGE = "exchange";
    public static final String TRADE_FLAT_SURPLUS = "flatSurplus";

    // 委托列表的title
    public static final String TRADE_ORDER_STATE = "orderState";
    public static final String TRADE_ORDER_PRICE = "orderPrice";
    public static final String TRADE_ORDER_QTY = "orderQty";
    public static final String TRADE_INSERT_TIME = "insertTime";
    public static final String TRADE_MESSAGE = "message";
    public static final String TRADE_TODAY_PLUS = "todayPlus";
    public static final String TRADE_HEDGE = "hedge";
    public static final String TRADE_ORDER_TYPE = "orderType";
    public static final String TRADE_VALID_TYPE = "validType";
    public static final String TRADE_ORDER_SOURCE = "orderSource";
    public static final String TRADE_ORDER_NO = "orderNo";
    public static final String TRADE_UPDATE_TIME = "updateTime";
    public static final String TRADE_FORCE_COVER = "forceCover";

    // 挂单列表的title
    public static final String TRADE_UPDATE_DATE = "updateDate";

    // 持仓列表的title
    public static final String TRADE_LONG_SHORT = "longShort";
    public static final String TRADE_POSITION_QTY = "positionQty";
    public static final String TRADE_AVAILABLE_QTY = "availableQty";
    public static final String TRADE_COVERED_FREEZE = "coveredFreeze";
    public static final String TRADE_TODAY_QTY = "todayQty";
    public static final String TRADE_COVER_QTY = "coverQty";
    public static final String TRADE_TOTAL_GAINS = "totalGains";
    public static final String TRADE_GAINS = "gains";
    public static final String TRADE_CALCULATE_PRICE = "calculatePrice";
    public static final String TRADE_CASH_DEPOSITE = "cashDeposite";
    public static final String TRADE_SETTLE_PRICE = "settlePrice";
    public static final String TRADE_FUNDS_PROPORTION = "fundsProportion";
    public static final String TRADE_POSITION_AVERAGE_PRICE = "positionAveragePrice";
    public static final String TRADE_MARKET_VALUE = "marketValue";
    public static final String TRADE_VIRTUAL_ACTUAL = "virtualActual";
    public static final String TRADE_OPTION_AVAILABLE_QTY = "optionAvailableQty";
}
