package com.esunny.ui.common.setting.trade;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsWebUrlData;
import com.esunny.ui.view.EsBaseToolBar;


public class EsMonitorCenterActivity extends EsBaseActivity {

    EsBaseToolBar mToolbar;
    WebView webView;
    ProgressBar progressBar;

    @Override
    protected void initData() {
        super.initData();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE| WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        bindView();
        bindViewValue();
        initWebview();
    }

    private void initWebview() {
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setBuiltInZoomControls(true);
        final WebSettings webSettings = webView.getSettings();
        webSettings.setDomStorageEnabled(true);
        webView.setBackgroundColor(Color.TRANSPARENT);

        webView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                view.loadUrl(request.getUrl().toString());
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                progressBar.setVisibility(View.GONE);
            }
        });

        webView.loadUrl(EsWebUrlData.getMonitorCenter(this));
    }

    private void bindViewValue() {
        mToolbar.setSimpleBack(getString(R.string.es_setting_turn_to_monitoring_center));
    }

    private void bindView() {
        mToolbar = findViewById(R.id.activity_es_forget_toolbar);
        webView = findViewById(R.id.activity_es_forget_webview);
        progressBar = findViewById(R.id.activity_es_forget_progressbar);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_forget_password;
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            webView.clearHistory();

            ((ViewGroup) webView.getParent()).removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
