package com.esunny.ui.common.setting.cloudservice;

/**
 * @author xiaosa
 */
public interface CloudServicePresenter {
    void modifyPassword(String oldPassword, String newPassword);

    void clearData();

    void logout();

    void syncFavoriteContractToCloud();

    void syncFavoriteContractFromCloud(boolean isSync);

    void syncPCContractFromCloud();

    void syncSettingToCloud();

    void syncSettingFromCloud(boolean isSync);
}
