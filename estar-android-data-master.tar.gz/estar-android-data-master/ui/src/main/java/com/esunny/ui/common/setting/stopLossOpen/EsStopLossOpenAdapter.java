package com.esunny.ui.common.setting.stopLossOpen;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.OpenOrder;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.R;

import java.util.ArrayList;
import java.util.List;

public class EsStopLossOpenAdapter extends RecyclerView.Adapter<EsStopLossOpenAdapter.ViewHolder> {

    private List<OpenOrder> mDatas;
    Context mContext;
    private List<String> mOrderPriceStr = new ArrayList<>();
    private SparseArray<ViewHolder> mViewHolder = new SparseArray<>();
    private int mOldOpenIndex = -1;
    private boolean mIsFromChange;
    private OnClickItem   mOnRefreshInsertTv;
    private OrderData mMainOrderData;

    public EsStopLossOpenAdapter(Context context, boolean change, OrderData orderData) {
        this.mContext = context;
        mIsFromChange = change;
        mMainOrderData = orderData;
    }

    public void setDatas(List<OpenOrder> mDatas) {
        this.mDatas = mDatas;
    }

    public void setOrderPriceStr(List<String> orderPriceStr) {
        this.mOrderPriceStr = orderPriceStr;
    }

    public void setOnItemClick(OnClickItem onItemClick) {
        mOnRefreshInsertTv = onItemClick;
    }

    public interface OnClickItem {
        void clickUndo(int position);
        void clickCancel(int position);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_stop_loss_open_adapter, parent, false);
        return new ViewHolder(view, true);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        if (position < getItemCount()) {
            if (mViewHolder.size() > 0) {
                for (int i = 0; i < mViewHolder.size(); i++) {
                    if (!holder.equals(mViewHolder.get(i))) {
                        mViewHolder.put(position, holder);
                        break;
                    }
                }
            } else {
                mViewHolder.put(position, holder);
            }


            OpenOrder openOrder = mDatas.get(position);
            char strategyType = openOrder.getStrategyType();
            double stopPrice = openOrder.getStopPrice();
            char validType = openOrder.getValidType();
            // 委托价格类型

            String stopPriceStr;
            Contract contract = EsDataApi.getTradeContract(mMainOrderData.getContractNo());
            if (contract != null) {
                stopPriceStr = EsDataApi.formatPrice(contract.getCommodity(), stopPrice);
            } else {
                stopPriceStr = String.valueOf(stopPrice);
            }
            holder.mTvStopPrice.setText(stopPriceStr);
            if (strategyType == EsDataConstant.S_ST_OPEN_STOPLOSS) {
                holder.mTvStopType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_condition_stop_loss));
                holder.mTvStopPriceType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_loss));
            } else if (strategyType == EsDataConstant.S_ST_OPEN_STOPPROFIT) {
                holder.mTvStopType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_condition_stop_profit));
                holder.mTvStopPriceType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_profit));
            }  else if (strategyType == EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT) {
                holder.mTvStopType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_condition_stop_loss));
                holder.mTvStopPriceType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_loss_diff));
            } else if (strategyType == EsDataConstant.S_ST_OPEN_BREAKEVEN) {
                holder.mTvStopType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_condition_keep));
                holder.mTvStopPriceType.setText(mContext.getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_profit_diff));

                if (mIsFromChange) {
                    holder.mTvStopPrice.setText(String.valueOf(Math.abs(stopPrice - mMainOrderData.getOrderPrice())));
                }
            }

            // 特殊委托价填setOrderPriceType和setOrderPriceOver，否则setOrderPriceType和setOrderPrice
            holder.mTvDelegatePriceType.setText(mOrderPriceStr.get(position));

            if (validType == EsDataConstant.S_VALIDTYPE_GFD) {
                holder.mTvValidePriceType.setText(R.string.es_strategy_input_view_today);
            } else if (validType == EsDataConstant.S_VALIDTYPE_GTC) {
                holder.mTvValidePriceType.setText(R.string.es_strategy_input_view_long);
            }

            holder.mLlMain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (position != mOldOpenIndex && mOldOpenIndex != -1) {
                        mViewHolder.get(mOldOpenIndex).mRlRevoke.setVisibility(View.GONE);
                        holder.mRlRevoke.setVisibility(View.VISIBLE);
                        mOldOpenIndex = position;
                    } else {
                        if (holder.mRlRevoke.getVisibility() == View.GONE) {
                            holder.mRlRevoke.setVisibility(View.VISIBLE);
                            mOldOpenIndex = position;
                        } else {
                            holder.mRlRevoke.setVisibility(View.GONE);
                        }
                    }
                }
            });

            holder.mTvRevoke.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int i = 0; i < mViewHolder.size(); i++) {
                        mViewHolder.get(mOldOpenIndex).mRlRevoke.setVisibility(View.GONE);
                    }
                    mOnRefreshInsertTv.clickUndo(position);
                }
            });

            if (openOrder.getStatus() == EsDataConstant.OPEN_DATA_FROM_ORDER_DATA) {
                holder.mTvCancel.setVisibility(View.VISIBLE);
            } else {
                holder.mTvCancel.setVisibility(View.GONE);
            }

            holder.mTvCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int i = 0; i < mViewHolder.size(); i++) {
                        mViewHolder.get(mOldOpenIndex).mRlRevoke.setVisibility(View.GONE);
                    }
                    mOnRefreshInsertTv.clickCancel(position);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView mTvStopType;
        TextView mTvStopPriceType;
        TextView mTvStopPrice;
        TextView mTvDelegatePriceType;
        TextView mTvValidePriceType;
        TextView mTvRevoke;
        TextView mTvCancel;
        RelativeLayout mRlRevoke;
        LinearLayout mLlMain;

        public ViewHolder(View itemView, boolean isItem) {
            super(itemView);
            if (isItem) {
                mTvStopType = itemView.findViewById(R.id.es_item_stop_loss_open_tv_stop_type);
                mTvStopPriceType = itemView.findViewById(R.id.es_item_stop_loss_open_tv_stop_price_type);
                mTvStopPrice = itemView.findViewById(R.id.es_item_stop_loss_open_tv_stop_price);
                mTvDelegatePriceType = itemView.findViewById(R.id.es_item_stop_loss_open_tv_delegate_price_type);
                mTvValidePriceType = itemView.findViewById(R.id.es_item_stop_loss_open_tv_valide_price_type);
                mLlMain = itemView.findViewById(R.id.es_item_stop_loss_open_ll_main);
                mRlRevoke = itemView.findViewById(R.id.es_item_stop_loss_open_rl_revoke);
                mTvRevoke = itemView.findViewById(R.id.es_item_stop_loss_open_tv_revoke);
                mTvCancel = itemView.findViewById(R.id.es_item_stop_loss_open_tv_cancel);
            }
        }
    }
}
