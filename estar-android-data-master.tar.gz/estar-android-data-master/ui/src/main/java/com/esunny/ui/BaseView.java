package com.esunny.ui;

public interface BaseView {

}
