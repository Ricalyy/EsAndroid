package com.esunny.ui.common.setting.quote.kline;


import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.bean.Plate;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.view.EsBaseToolBar;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;

public class EsQuoteSettingActivity extends EsBaseActivity {

    @BindView(R2.id.es_activity_quote_setting_toolbar)
    EsBaseToolBar mToolBar;
    @BindView(R2.id.es_quote_plate_rv_china)
    RecyclerView mRlChina;
    @BindView(R2.id.es_quote_plate_rv_stock)
    RecyclerView mRlStock;
    @BindView(R2.id.es_quote_plate_rv_foreign)
    RecyclerView mRlForeign;
    @BindView(R2.id.es_quote_plate_rv_other)
    RecyclerView mRlOther;

    //所有一级交易所
    private ArrayList<Plate> mGroupPlate = new ArrayList<>();

    // 内盘交易所
    private List<Plate> mChinaPlateList = new ArrayList<>();
    // 证券
    private List<Plate> mStockPlateList = new ArrayList<>();
    // 外盘
    private List<Plate> mForeignPlateList = new ArrayList<>();
    // 其他
    private List<Plate> mOtherPlateList = new ArrayList<>();

    private HashMap<Plate, List<Plate>> mChildPlates = new HashMap<>();

    private final static String CHN_PLATE_NO = "CHN";
    private final static String FOREIGN_PLATE_NO = "FOR";
    private final static String OPTION_PLATE_NO = "OPTION";
    private final static String SPD_PLATE_NO = "EsunnySpread";

    private final static List<String> STOCK_PLATE = Arrays.asList("SSE", "SZSE");

    JSONObject mJson = null;

    @Override
    protected void initData() {
        super.initData();

        initPlateData();

        initJsonData();
    }

    private void initJsonData() {
        String dataStr = EsSPHelper.getQuoteSetting(this);

        if (dataStr == null || dataStr.isEmpty()) {
            mJson = new JSONObject();
        }else {
            try {
                mJson = new JSONObject(dataStr);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_quote_setting;
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        initViewValue();

        initRecyclerview();
    }

    private void initPlateData() {
        List<Plate> plates = EsDataApi.getPlate();
        for (Plate plate : plates) {
            if (plate.isFirstPlate() && !OPTION_PLATE_NO.equals(plate.getPlateNo()) && !SPD_PLATE_NO.equals(plate.getPlateNo())) {
                //筛选出期权和极星套利
                mGroupPlate.add(plate);
                //只有一级板块存在子板块
                mChildPlates.put(plate, EsDataApi.getChildPlate(plate));
            }
        }


        for (Plate plate : mGroupPlate) {
            if (CHN_PLATE_NO.equals(plate.getPlateNo())) {
                // 需要将内盘主力放置第一个,ZCE放第二个
                List<Plate> children = mChildPlates.get(plate);
                if (children.size() > 0) {
                    for (int i = 0; i < children.size(); i++) {
                        Plate chinaPlate = children.get(i);
                        mChinaPlateList.add(chinaPlate);

                        if (("MAIN").equals(chinaPlate.getPlateNo())) {
                            mChinaPlateList.remove(chinaPlate);
                            mChinaPlateList.add(0, chinaPlate);
                        } else if (("ZCE").equals(children.get(i).getPlateNo())) {
                            mChinaPlateList.remove(chinaPlate);
                            if (mChinaPlateList.size() > 0) {
                                mChinaPlateList.add(1, chinaPlate);
                            } else {
                                mChinaPlateList.add(0, chinaPlate);
                            }
                        }
                    }
                }
            } else if (FOREIGN_PLATE_NO.equals(plate.getPlateNo())) {
                List<Plate> foreignPlateList = mChildPlates.get(plate);
                if (foreignPlateList.size() > 0) {
                    for (Plate foreignPlate : foreignPlateList) {
                        mForeignPlateList.add(foreignPlate);
                    }
                }
            } else if (STOCK_PLATE.contains(plate.getPlateNo())) {
                mStockPlateList.add(plate);
            } else {
                //获取二级交易所
                final List<Plate> list = mChildPlates.get(plate);
                if (list.size() > 0) {
                    mOtherPlateList.addAll(list);
                } else {
                    mOtherPlateList.add(plate);
                }
            }
        }


    }

    private void initViewValue() {
        mToolBar.setSimpleBack(this.getString(R.string.es_activity_chart_setting_my_quote_setting));
    }

    private void initRecyclerview() {
        dealPlateData(mRlChina, mChinaPlateList);

        dealPlateData(mRlStock, mStockPlateList);

        dealPlateData(mRlForeign, mForeignPlateList);

        dealPlateData(mRlOther, mOtherPlateList);
    }

    private void dealPlateData(RecyclerView view, List<Plate> list) {
        int size = list.size();
        int heightCount;
        if (size % 3 == 0) {
            heightCount = size / 3;
        } else {
            heightCount = size / 3 + 1;
        }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                getResources().getDimensionPixelSize(R.dimen.x162) * heightCount);
        EsQuoteSettingAdapter adapter = new EsQuoteSettingAdapter();
        view.setLayoutParams(params);
        view.setNestedScrollingEnabled(false);
        adapter.setJsonData(mJson);
        adapter.setDataList(list);
        GridLayoutManager layoutManager = new GridLayoutManager(this, 3);
        view.setLayoutManager(layoutManager);
        view.setAdapter(adapter);
    }

    @Override
    protected void onDestroy() {
        EsSPHelper.setQuoteSetting(this, mJson.toString());

        EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_REFRESH_QUOTE_SETTING).buildEvent();
        EventBus.getDefault().post(message);

        super.onDestroy();
    }
}
