package com.esunny.ui.common.bean;

public class EsOpTactic {

    private int mTacticType;        //策略类型
    private int mTacticID;          //策略ID
    private int mOperate1;          //操作类型1
    private int mOperate2;          //操作类型2
    private int mCondition;         //条件
    private String mTacticName;     //名称
    private int mPLType;            //赢损类型
    private int mTacticIcon;        //IconString
    private int mTacticNightIcon;        //夜晚模式下的ResId
    private String mIntroduction;   //介绍

    public EsOpTactic(){
        mTacticID = EsOpTacticType.TACTIC_ID_NONE;
        mTacticType = EsOpTacticType.TACTIC_TYPE_SINGLE;
        mOperate1 = EsOpTacticType.TACTIC_OPERATE_NONE;
        mOperate1 = EsOpTacticType.TACTIC_OPERATE_NONE;
        mCondition = EsOpTacticType.TACTIC_CONDITION_NONE;
        mTacticName = "";
        mPLType = EsOpTacticType.TACTIC_PROFIT_LOSS_TYPE_PUNLIMIT;
    }

    public int getTacticType() {
        return mTacticType;
    }

    public void setTacticType(int tacticType) {
        mTacticType = tacticType;
    }

    public int getTacticID() {
        return mTacticID;
    }

    public void setTacticID(int tacticID) {
        mTacticID = tacticID;
    }

    public int getOperate1() {
        return mOperate1;
    }

    public void setOperate1(int operate1) {
        mOperate1 = operate1;
    }

    public int getOperate2() {
        return mOperate2;
    }

    public void setOperate2(int operate2) {
        mOperate2 = operate2;
    }

    public int getCondition() {
        return mCondition;
    }

    public void setCondition(int condition) {
        mCondition = condition;
    }

    public String getTacticName() {
        return mTacticName;
    }

    public void setTacticName(String name) {
        mTacticName = name;
    }

    public int getPLType() {
        return mPLType;
    }

    public void setPLType(int PLType) {
        mPLType = PLType;
    }

    public int getTacticIcon() {
        return mTacticIcon;
    }

    public void setTacticIcon(int tacticIcon) {
        mTacticIcon = tacticIcon;
    }

    public String getIntroduction() {
        return mIntroduction;
    }

    public void setIntroduction(String introduction) {
        mIntroduction = introduction;
    }

    public int getTacticNightIcon() {
        return mTacticNightIcon;
    }

    public void setTacticNightIcon(int tacticNightIcon){
        this.mTacticNightIcon = tacticNightIcon;
    }
}

