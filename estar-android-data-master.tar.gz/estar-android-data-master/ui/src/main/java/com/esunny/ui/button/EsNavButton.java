package com.esunny.ui.button;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;

import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.R;
import com.esunny.ui.view.EsIconTextView;

import skin.support.widget.SkinCompatSupportable;

/**
 * Created by chexiaopeng on 2018/1/18.
 */

public class EsNavButton extends FrameLayout implements SkinCompatSupportable {

    private boolean mIsIconTextView = true;
    //该button对应Fragment
    private Fragment mFragment = null;
    private Fragment mOtherFragment = null;

    private int mType;
    private int mOtherType;//暂时使用期权对应OtherType
    private TextView mTitleView;
    private EsIconTextView mIconView;
    private TextView mImageView;

    private int mIconText;
    private int mIconClickText;

    private Drawable mLightIcon;
    private Drawable mLightClickIcon;
    private Drawable mDarkIcon;
    private Drawable mDarkClickIcon;

    public EsNavButton(@NonNull Context context) {
        super(context);
        initWidget();
    }

    public EsNavButton(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initWidget();
    }

    public EsNavButton(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initWidget();
    }

    private void initWidget(){
        LayoutInflater inflater = LayoutInflater.from(getContext());
        inflater.inflate(R.layout.es_navigation_item_view, this, true);
        mImageView = findViewById(R.id.nav_iv_icon_home_page);
        mIconView = findViewById(R.id.nav_tv_icon);
        mTitleView = findViewById(R.id.nav_tv_title);
    }

    public void setSelected(boolean selected){
        super.setSelected(selected);
        mTitleView.setSelected(selected);
        if(mIsIconTextView){
            if(selected){
                mIconView.setText(mIconClickText);
            }else{
                mIconView.setText(mIconText);
            }
        }else{
            changeTheme();
        }
    }

    public void init(@StringRes int iconText, @StringRes int iconClickText, @StringRes int title, int tag){
        mIsIconTextView = true;
        mIconView.setText(iconText);
        mTitleView.setText(title);
        mIconText = iconText;
        mIconClickText = iconClickText;
        mType = tag;
        mIconView.setVisibility(VISIBLE);
        mImageView.setVisibility(GONE);
    }

    public void init(Drawable LightIcon, Drawable LightIconClick, Drawable DarkIcon, Drawable DrakIconClick, @StringRes int title, int type){
        mIsIconTextView = false;
        mTitleView.setText(title);
        mLightIcon = LightIcon;
        mLightClickIcon = LightIconClick;
        mDarkIcon = DarkIcon;
        mDarkClickIcon = DrakIconClick;
        mType = type;
        changeTheme();
        mIconView.setVisibility(GONE);
        mImageView.setVisibility(VISIBLE);
    }

    public void setOtherType(int type){
        mOtherType = type;
    }


    public Fragment getFragment(){
        tagToFragment(mType);
        return mFragment;
    }

    public void setFragment(Fragment fragment) {
        this.mFragment = fragment;
    }

    public String getTag(){
        if (mFragment != null) {
            return mFragment.getTag();
        }
        return "";
    }

    public void setType(int type){
        mType = type;
    }

    public int getType() {
        return mType;
    }

    private void tagToFragment(int type) {
        if(mFragment != null){
            return;
        }

        Fragment fragment = EsUIApi.getFragment(type);

        if (fragment != null) {
            mFragment = fragment;
        }
    }

    public void updateText(@StringRes int title){
        mTitleView.setText(title);
    }

    @Override
    public void applySkin() {
        changeTheme();
    }

    private void changeTheme(){
        if(!mIsIconTextView){
//            if(EsSPHelper.getTheme(getContext())){
//                if(isSelected()){
//                    mImageView.setBackground(mLightClickIcon);
//                }else{
//                    mImageView.setBackground(mLightIcon);
//                }
//            }else{
//                if(isSelected()){
//                    mImageView.setBackground(mDarkClickIcon);
//                }else{
//                    mImageView.setBackground(mDarkIcon);
//                }
//            }
        }
    }
}
