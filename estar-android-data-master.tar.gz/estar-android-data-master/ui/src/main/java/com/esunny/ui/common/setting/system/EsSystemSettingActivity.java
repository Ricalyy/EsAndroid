package com.esunny.ui.common.setting.system;

import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.data.api.EsDataTrackApi;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIBaseAPI;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.util.EsLanguageHelper;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsCusSwitchButton;
import com.esunny.ui.view.EsIconTextView;

import butterknife.BindView;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;
import skin.support.content.res.SkinCompatResources;


@Route(path = RoutingTable.ES_SYSTEM_SETTING_ACTIVITY)
public class EsSystemSettingActivity extends EsBaseActivity implements View.OnClickListener{

    @BindView(R2.id.es_activity_system_setting_switch_is_use_rington)
    EsCusSwitchButton mDisconnectSwitchRingtong;
    @BindView(R2.id.es_activity_system_setting_switch_is_trade_use_rington)
    EsCusSwitchButton mTradeSwitchRingtong;
    @BindView(R2.id.es_activity_system_setting_switch_is_message_use_rington)
    EsCusSwitchButton mMessageSwitchRingtong;
    @BindView(R2.id.es_activity_system_setting_rl_price_warning)
    RelativeLayout mRlWarning;

    EsCusSwitchButton switch_keep_screen_on;
    RelativeLayout rl_clear_favorites, rl_clear_account_info;
    EsIconTextView iv_back;
    RelativeLayout mRlSwitchLanguage;
    TextView mTvLanguage;

    RelativeLayout mRlChooseRington;

    private boolean shouldPlayBeep = true;

    @Override
    protected void initData() {
        super.initData();

    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindViewValue();
        bindOnClick();
        initViewNightColor();

        switch_keep_screen_on.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    EsSPHelperProxy.setIsKeepScreenOn(getBaseContext(), true);
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }else {
                    EsSPHelperProxy.setIsKeepScreenOn(getBaseContext(), false);
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            }
        });

    }

    private void bindViewValue() {
        mTvLanguage.setText(EsUIBaseAPI.getLaguageStrByType(this, EsLanguageHelper.getFavoriteLanguage(this)));
    }

    private void initViewNightColor() {
        switch_keep_screen_on.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        switch_keep_screen_on.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));
        mDisconnectSwitchRingtong.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mDisconnectSwitchRingtong.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));
        mTradeSwitchRingtong.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mTradeSwitchRingtong.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));
        mMessageSwitchRingtong.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mMessageSwitchRingtong.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));
    }

    private void bindView() {
        switch_keep_screen_on = findViewById(R.id.es_activity_system_setting_switch_keep_screen_on);
        rl_clear_favorites = findViewById(R.id.es_activity_system_setting_rl_clear_favorites);
        rl_clear_account_info = findViewById(R.id.es_activity_system_setting_rl_clear_account_info);
        iv_back = findViewById(R.id.es_activity_system_setting_iv_back);
        mRlSwitchLanguage = findViewById(R.id.es_activity_system_setting_rl_switch_language);
        mTvLanguage = findViewById(R.id.es_activity_system_setting_tv_language);

        mRlChooseRington = findViewById(R.id.es_activity_system_setting_rl_choose_rington);
    }

    private void bindOnClick() {
        rl_clear_favorites.setOnClickListener(this);
        rl_clear_account_info.setOnClickListener(this);
        iv_back.setOnClickListener(this);
        mRlSwitchLanguage.setOnClickListener(this);
//        mRlChooseRington.setOnClickListener(this);
    }

    @OnCheckedChanged(R2.id.es_activity_system_setting_switch_is_use_rington)
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        EsSPHelperProxy.setIsUseRington(this, isChecked);
    }

    @OnCheckedChanged(R2.id.es_activity_system_setting_switch_is_trade_use_rington)
    public void onTradeCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        EsSPHelperProxy.setIsUseTradeRington(this,isChecked);
    }

    @OnCheckedChanged(R2.id.es_activity_system_setting_switch_is_message_use_rington)
    public void onMessageCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        EsSPHelperProxy.setIsUseMessageRington(this,isChecked);
    }

    @Override
    protected void onStart() {
        super.onStart();
        switch_keep_screen_on.setChecked(EsSPHelperProxy.getIsKeepScreenOn(this));
        mDisconnectSwitchRingtong.setChecked(EsSPHelperProxy.getIsUseRington(this));
        mTradeSwitchRingtong.setChecked(EsSPHelperProxy.getIsUseTradeRington(this));
        mMessageSwitchRingtong.setChecked(EsSPHelperProxy.getIsUseMessageRington(this));
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_system_setting;
    }

    @Override
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.es_activity_system_setting_rl_clear_favorites) {
            clearFavorites();
        }else if (i == R.id.es_activity_system_setting_rl_clear_account_info){
            clearAccountInfo();
        }else if (i == R.id.es_activity_system_setting_iv_back){
            back();
        }else if (i == R.id.es_activity_system_setting_rl_switch_language){
            switchLanguage();
        }
    }
    @OnClick(R2.id.es_activity_system_setting_rl_price_warning)
    public void priceWarning() {
        startActivity(new Intent(EsSystemSettingActivity.this, EsPriceWarningRingtoneActivity.class));
    }

//    private void chooseRington() {
//        ARouter.getInstance().build(RoutingTable.ES_CHOOSE_RINGTONG_ACTIVITY).navigation();
//    }

    private void switchLanguage() {
        ARouter.getInstance().build(RoutingTable.ES_SWITCH_LANGUAGE_ACTIVITY).navigation();
    }

    public void clearFavorites(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // 设置参数
        builder.setTitle(getString(R.string.es_activity_system_setting_notice))
                .setMessage(getString(R.string.es_activity_system_setting_is_delete_contract))
                .setPositiveButton(getString(R.string.es_save), new DialogInterface.OnClickListener() {// 积极

                    @Override
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        EsFavoriteListData.getInstance().clearFavorite();
                        ToastHelper.show(getApplicationContext(), R.string.es_activity_system_setting_clear_successfully);
                    }
                }).setNegativeButton(getString(R.string.es_cancel), new DialogInterface.OnClickListener() {// 消极

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {
            }
        });
        builder.create().show();
    }

    public void clearAccountInfo(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // 设置参数
        builder.setTitle(getString(R.string.es_activity_system_setting_notice))
                .setMessage(getString(R.string.es_activity_system_setting_is_delete_account_info))
                .setPositiveButton(getString(R.string.es_save), new DialogInterface.OnClickListener() {// 积极

                    @Override
                    public void onClick(DialogInterface dialog,
                                        int which) {
                        EsLoginAccountData.getInstance().clearSavedAccount();
                        ToastHelper.show(getApplicationContext(), R.string.es_activity_system_setting_clear_successfully);
                    }
                }).setNegativeButton(getString(R.string.es_cancel), new DialogInterface.OnClickListener() {// 消极

            @Override
            public void onClick(DialogInterface dialog,
                                int which) {
            }
        });
        builder.create().show();
    }

    public void back(){
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mTvLanguage.setText(EsUIBaseAPI.getLaguageStrByType(this, EsLanguageHelper.getFavoriteLanguage(this)));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        int languageType = EsLanguageHelper.getFavoriteLanguage(this);
        boolean isDisconnectSound = EsSPHelperProxy.getIsUseRington(this);
        boolean isTradeSound = EsSPHelperProxy.getIsUseTradeRington(this);
        boolean isMessageSound = EsSPHelperProxy.getIsUseMessageRington(this);
        boolean isScreenOn = EsSPHelperProxy.getIsKeepScreenOn(this);

        EsDataTrackApi.saveSettingConfiguration(languageType, isDisconnectSound, isTradeSound,
                isMessageSound, isScreenOn);
    }
}
