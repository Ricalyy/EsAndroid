package com.esunny.ui.common.setting.trade;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.BankBalance;
import com.esunny.data.bean.BankBalanceQry;
import com.esunny.data.bean.BankTransferReq;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.MoneyField;
import com.esunny.data.bean.SigningBank;
import com.esunny.data.bean.TransBank;
import com.esunny.data.bean.TransferData;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.setting.trade.adapter.EsTransferRecordAdapter;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.dialog.EsBankTransferDialog;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsIconTextView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;

public class EsBankTransferActivity extends EsBaseActivity implements View.OnClickListener {

    @BindView(R2.id.es_activity_bank_transfer_iv_back)
    EsIconTextView iv_back;
    @BindView(R2.id.es_activity_bank_transfer_tv_bank_no)
    TextView tv_bank_no;
    @BindView(R2.id.es_activity_bank_transfer_itv_query)
    EsIconTextView btn_query;
    @BindView(R2.id.es_activity_bank_transfer_tv_future_to_bank_money)
    TextView tv_future_to_bank_money;
    @BindView(R2.id.es_activity_bank_transfer_tv_bank_to_future_money)
    TextView tv_bank_to_future_money;
    @BindView(R2.id.es_activity_bank_transfer_et_input_money)
    EditText et_input_money;
    @BindView(R2.id.es_activity_bank_transfer_tv_future_to_bank)
    TextView tv_future_to_bank;
    @BindView(R2.id.es_activity_bank_transfer_tv_bank_to_future)
    TextView tv_bank_to_future;
    @BindView(R2.id.es_activity_bank_transfer_rv_transfer_record)
    RecyclerView rv_transfer_record;
    @BindView(R2.id.es_activity_bank_transfer_tv_bank_name)
    TextView tv_bank_name;
    @BindView(R2.id.es_activity_bank_transfer_rl_choose_bank)
    RelativeLayout rl_choose_bank;
    @BindView(R2.id.es_activity_bank_transfer_itv_refresh)
    EsIconTextView itv_refresh;
    @BindView(R2.id.es_activity_bank_transfer_rl_overlay)
    RelativeLayout rl_overlay;

    private final int BANK_CHOOSING_REQUEST = 1;
    HashMap<String, String> mTransferBankHashMap = new HashMap<>();
    ArrayList<String> mSigningBankNoList = new ArrayList<>();
    List<HashMap<String, String>> mSigningBankHashMapList = new ArrayList<>();
    List<SigningBank> mSigningBankList = new ArrayList<>();
    ArrayList<String> mSigningBankCurrencyNoList = new ArrayList();
    List<String> mData = new ArrayList<>();
    List<TransferData> mTransferData = new ArrayList<>();
    EsTransferRecordAdapter mAdapter;

    boolean isMeClick = false;
    SigningBank mCurrentBank;
    String mCompanyNo, mUserNo, mAddrNo;
    String mMoneyPassword, mBankPassword;
    private int mChooseSigningBankIndex = 0;
    EsLoginAccountData.LoginAccount loginAccount;

    AlertDialog dialog_transfer_old, dialog_old;

    private boolean mShowBankMoney;

    @Override
    protected void initData() {
        super.initData();

        if (EsLoginAccountData.getInstance().getCurrentAccount() != null) {
            mCompanyNo = EsLoginAccountData.getInstance().getCurrentAccount().getCompanyNo();
            mUserNo = EsLoginAccountData.getInstance().getCurrentAccount().getUserNo();
            mAddrNo = EsLoginAccountData.getInstance().getCurrentAccount().getAddrTypeNo();
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        bindOnClick();
        querySignAndTransferBank();
        initRecyclerView();
    }

    private void bindOnClick() {
        btn_query.setOnClickListener(this);
        tv_future_to_bank.setOnClickListener(this);
        tv_bank_to_future.setOnClickListener(this);
        iv_back.setOnClickListener(this);
        rl_choose_bank.setOnClickListener(this);
        itv_refresh.setOnClickListener(this);
    }

    private void querySignAndTransferBank() {
        loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        String companyNo = loginAccount.getCompanyNo();
        String userNo = loginAccount.getUserNo();
        String addrNo = loginAccount.getAddrTypeNo();
        rl_overlay.setVisibility(View.VISIBLE);

        EsDataApi.qryTransBank(companyNo, userNo, addrNo);
        EsDataApi.qrySigningBank(companyNo, userNo, addrNo);
    }

    private void initRecyclerView() {
        rv_transfer_record.setBackgroundResource(R.color.es_activity_bank_transfer_detail_bg);
        tv_bank_no.setText(loginAccount.getUserNo());

        mAdapter = new EsTransferRecordAdapter(this, mTransferData);
        mAdapter.setOnItemListener(new EsTransferRecordAdapter.OnItemListener() {
            @Override
            public void onClick(View v, int pos, TransferData transferData) {
                mAdapter.setDefSelect(pos);
            }
        });
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rv_transfer_record.setAdapter(mAdapter);
        rv_transfer_record.setLayoutManager(layoutManager);
        if (loginAccount != null) {
            int b = EsDataApi.qryBankTransfer(loginAccount.getCompanyNo(), loginAccount.getUserNo(), loginAccount.getAddrTypeNo());
        }
    }

    private void queryFuturesValue(SigningBank signingBank) {
        if (signingBank != null) {
            queryFuturesMoney(signingBank.getCompanyNo(), signingBank.getUserNo(), signingBank.getAddressNo());
        }
    }

    private void queryFuturesMoney(String companyNo, String userNo, String addrNo) {
        List<MoneyData> dataList = EsDataApi.getMoneyData(companyNo, userNo, addrNo);
        if (dataList.size() > 0) {
            MoneyData data = dataList.get(0);
            MoneyField[] dataExes = data.getDataEx();
            tv_future_to_bank_money.setText(String.valueOf(new java.text.DecimalFormat("#.00").format(dataExes[EsDataConstant.S_CANCASHOUT].getValue())));
        }
    }

    private void queryBalanceSuccessfully(double balance) {
        // 查询余额成功
        tv_bank_to_future_money.setText(String.valueOf(new java.text.DecimalFormat("#0.00").format(balance)));
        rl_overlay.setVisibility(View.GONE);
    }

    private void queryTransferSuccessfully(TransferData data) {
        addTransferData(data);
    }

    private void queryTransferFail(TransferData transferData) {
        if (isMeClick) {
            AlertDialog.Builder builder_transfer = new AlertDialog.Builder(EsBankTransferActivity.this);
            builder_transfer.setTitle(R.string.es_activity_bank_transfer_error_transfer);
            builder_transfer.setMessage(transferData.getErrorText());
            builder_transfer.setPositiveButton(R.string.es_activity_account_detail_confirm, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder_transfer.setMessage(transferData.getErrorText());

            if (dialog_transfer_old != null && dialog_transfer_old.isShowing()) {
                dialog_transfer_old.dismiss();
            }
            AlertDialog dialog_transfer = builder_transfer.create();
            dialog_transfer_old = dialog_transfer;
            dialog_transfer.show();

            isMeClick = false; //reset
        }

        //addTransferData(transferData);
    }

    private void addTransferData(TransferData data) {
        if (data == null || mTransferData == null) {
            return;
        }

        boolean isContain = false;

        data.setBankNo(mTransferBankHashMap.get(data.getBankNo()));
        for (int i = 0; i < mTransferData.size(); i++) {
            TransferData transferData = mTransferData.get(i);

            if (data.getCompanyNo().equals(transferData.getCompanyNo()) &&
                    data.getUserNo().equals(transferData.getUserNo()) &&
                    data.getAddressNo().equals(transferData.getAddressNo()) &&
                    data.getFutureSerialId() == transferData.getFutureSerialId() &&
                    data.getBankSerialId() == transferData.getBankSerialId() &&
                    data.getBankNo().equals(transferData.getBankNo())) {
                mTransferData.set(i, data);
                isContain = true;
                break;
            }
        }

        if (!isContain) {
            mTransferData.add(data);
        }

        if (mAdapter != null) {
            mAdapter.notifyDataSetChanged();
            rv_transfer_record.scrollToPosition(mTransferData.size() - 1);
        }

        if (isMeClick && data.getTransState() == EsDataConstant.S_TS_Transed) {
            refresh();
            queryAccountValue();
        }

        if (rl_overlay != null && rl_overlay.getVisibility() != View.GONE) {
            rl_overlay.setVisibility(View.GONE);
        }
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_bank_transfer;
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.es_activity_bank_transfer_itv_query) {
            queryAccountValue();
        } else if (i == R.id.es_activity_bank_transfer_tv_future_to_bank) {
            futureToBank();
        } else if (i == R.id.es_activity_bank_transfer_tv_bank_to_future) {
            bankToFuture();
        } else if (i == R.id.es_activity_bank_transfer_iv_back) {
            back();
        } else if (i == R.id.es_activity_bank_transfer_rl_choose_bank) {
            chooseBank();
        } else if (i == R.id.es_activity_bank_transfer_itv_refresh) {
            refresh();
        }
    }

    private void refresh() {
        if (mSigningBankList != null && mChooseSigningBankIndex < mSigningBankList.size()) {
            queryFuturesValue(mSigningBankList.get(mChooseSigningBankIndex));
        }
    }

    private void chooseBank() {
        if (mSigningBankList.size() == 0) {
            ToastHelper.show(EsBankTransferActivity.this, R.string.es_activity_bank_transfer_no_signing_bank);
            return;
        }
        Bundle seriableBundle = new Bundle();
        seriableBundle.putSerializable("signingBankHashMap", (Serializable) mSigningBankHashMapList);

        Intent intent = new Intent(this, EsBankChoosingActivity.class);
        intent.putStringArrayListExtra("singingBankCurrencyNoList", mSigningBankCurrencyNoList);
        intent.putStringArrayListExtra("signingBankNoList", mSigningBankNoList);
        intent.putExtra("chooseSigningBankIndex", mChooseSigningBankIndex);
        intent.putExtras(seriableBundle);
        startActivityForResult(intent, BANK_CHOOSING_REQUEST);
    }

    private void back() {
        finish();
    }

    private void bankToFuture() {
        transferOperation(EsDataConstant.S_TD_ToFutures);
    }

    private void futureToBank() {
        transferOperation(EsDataConstant.S_TD_ToBank);
    }

    public void queryAccountValue() {
        if (mSigningBankList.size() == 0) {
            ToastHelper.show(EsBankTransferActivity.this, R.string.es_activity_bank_transfer_no_signing_bank);
            return;
        }

        if (isMeClick) {
            qryBankBalance(mMoneyPassword, mBankPassword);
        } else {
            final EsBankTransferDialog dialog = new EsBankTransferDialog(this, new EsBankTransferDialog.LeaveMyDialogListener() {
                String bankPwd, moneyPwd;
                @Override
                public void useSelectValue(String bankContentStr, String moneyContentStr) {
                    bankPwd = bankContentStr;
                    moneyPwd = moneyContentStr;
                }
                @Override
                public void onClick(View view) {
                    int i = view.getId();
                    if (i == R.id.es_bank_transfer_choose_dialog_btn_confirm) {// 银行可转出
                        qryBankBalance(moneyPwd, bankPwd);
                    }
                }
            });
            dialog.show();
        }
    }

    private void qryBankBalance(String moneyPassword, String bankPassword) {
        mMoneyPassword = moneyPassword;
        mBankPassword = bankPassword;
        BankBalanceQry bankBalanceQry = new BankBalanceQry();
        bankBalanceQry.setBankNo(mSigningBankNoList.get(mChooseSigningBankIndex));
        bankBalanceQry.setCompanyNo(mCompanyNo);
        bankBalanceQry.setUserNo(mSigningBankList.get(mChooseSigningBankIndex).getUserNo());
        bankBalanceQry.setAddressNo(mAddrNo);
        bankBalanceQry.setBankAccount(mSigningBankList.get(mChooseSigningBankIndex).getBankAccount());
        bankBalanceQry.setCurrencyNo(mSigningBankList.get(mChooseSigningBankIndex).getCurrencyNo());
        bankBalanceQry.setTransAuth(moneyPassword);
        bankBalanceQry.setBankPsw(bankPassword);
        int a = EsDataApi.qryBankBalance(bankBalanceQry);
        rl_overlay.setVisibility(View.VISIBLE);

        mShowBankMoney = true;
    }

    private void transferOperation(final char transferDirec) {
        if (!isAmountCorrect()) {
            return;
        }

        final EsBankTransferDialog dialog = new EsBankTransferDialog(this, new EsBankTransferDialog.LeaveMyDialogListener() {
            String bankPwd, moneyPwd;

            @Override
            public void useSelectValue(String bankContentStr, String moneyContentStr) {
                bankPwd = bankContentStr;
                moneyPwd = moneyContentStr;
                mMoneyPassword = moneyContentStr;
                mBankPassword = bankContentStr;
            }

            @Override
            public void onClick(View view) {
                int i = view.getId();
                if (i == R.id.es_bank_transfer_choose_dialog_btn_confirm) {
                    if (bankPwd.trim().equals("") && moneyPwd.trim().equals("")) {
                        ToastHelper.show(EsBankTransferActivity.this, R.string.es_input_please);
                        return;
                    }

                    if (mCurrentBank != null) {
                        BankTransferReq bankTransferReq = new BankTransferReq();
                        bankTransferReq.setCompanyNo(mCurrentBank.getCompanyNo());
                        bankTransferReq.setUserNo(mCurrentBank.getUserNo());
                        bankTransferReq.setAddressNo(mCurrentBank.getAddressNo());
                        bankTransferReq.setBankNo(mCurrentBank.getBankNo());
                        bankTransferReq.setBankAccount(mCurrentBank.getBankAccount());
                        bankTransferReq.setCurrencyNo(mCurrentBank.getCurrencyNo());
                        bankTransferReq.setTransDirect(transferDirec);
                        bankTransferReq.setTransFund(Double.valueOf(et_input_money.getText().toString()));
                        bankTransferReq.setTransAuth(moneyPwd);
                        bankTransferReq.setBankPsw(bankPwd);
                        int a = EsDataApi.bankTransfer(bankTransferReq);

                        rl_overlay.setVisibility(View.VISIBLE);
                        // 检查完之后确认点击了
                        isMeClick = true;
                    }
                }
            }
        });
        dialog.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            return;
        }

        switch (requestCode) {
            case BANK_CHOOSING_REQUEST:
                if (data != null) {
                    mChooseSigningBankIndex = data.getIntExtra("chooseSigningBankIndex", 0);
                    if (mChooseSigningBankIndex < mSigningBankHashMapList.size() && mChooseSigningBankIndex < mSigningBankNoList.size()) {
                        SigningBank bank = mSigningBankList.get(mChooseSigningBankIndex);
                        String chooseSignBankName = mSigningBankHashMapList.get(mChooseSigningBankIndex).get(mSigningBankNoList.get(mChooseSigningBankIndex));

                        if (mCurrentBank == null || !mCurrentBank.equals(bank)) {
                            tv_bank_to_future_money.setText("");
                        }

                        tv_bank_name.setText(chooseSignBankName + "(" + mSigningBankCurrencyNoList.get(mChooseSigningBankIndex) + ")");

                        mCurrentBank = bank;
                        refresh();
                    }
                }
                break;
            default:
        }
    }

    public boolean isAmountCorrect() {
        if (et_input_money.getText().toString().trim().equals("")) {
            ToastHelper.show(EsBankTransferActivity.this, R.string.es_activity_bank_transfer_input_transfer_amount);
            return false;
        }
        if (Double.valueOf(et_input_money.getText().toString().trim()) == 0) {
            ToastHelper.show(EsBankTransferActivity.this, R.string.es_activity_bank_transfer_amount_is_zero);
            return false;
        }
        if (mSigningBankNoList.size() == 0) {
            ToastHelper.show(EsBankTransferActivity.this, R.string.es_activity_bank_transfer_no_signing_bank);
            return false;
        }
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (tv_bank_to_future_money != null) {
            tv_bank_to_future_money.setText("");
        }
        mShowBankMoney = false;
        if (! EventBus.getDefault().isRegistered(this)){
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (EventBus.getDefault().isRegistered(this)){
            EventBus.getDefault().unregister(this);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();
        Object data = event.getData();
        String companyNo, userNo, addrNo;
        int errorCode;

        switch (action) {
            case EsDataConstant.S_SRVEVENT_QRY_TRANSBANK:
                if (data instanceof TransBank) {
                    TransBank bank = (TransBank) data;
                    String bankName = bank.getBankName();
                    String bankNo = bank.getBankNo();
                    queryTransferBank(bankName, bankNo);
                }
                break;
            case EsDataConstant.S_SRVEVENT_QRY_SIGNBANK:
                if (data instanceof SigningBank && !((SigningBank) data).getBankNo().isEmpty()) {
                    //  有时存在有签约银行数据，但其内容为""的情况
                    SigningBank newSigningBank = (SigningBank) data;
                    boolean isSrvChainEnd = event.getSrvChain();
                    querySigningBank(newSigningBank, isSrvChainEnd);
                } else {
                    queryWithNoSigningBank();
                }
                break;
            case EsDataConstant.S_SRVEVENT_QRY_BALANCE:
                errorCode = event.getSrvErrorCode();
                if (errorCode == 0) {
                    if (data instanceof BankBalance) {
                        BankBalance bankBalance = (BankBalance) data;
                        String bankNo = bankBalance.getBankNo();
                        String currencyNo = bankBalance.getCurrencyNo();
                        double balance = bankBalance.getBalance();
                        queryBalance(bankNo, currencyNo, balance);
                    }
                } else {
                    String errorText = event.getSrvErrorText();
                    queryBalanceError(errorText);
                }
                break;
            case EsDataConstant.S_SRVEVENT_BANKTRANSFER:
            case EsDataConstant.S_SRVEVENT_QRY_TRANSFER:
                if (data instanceof TransferData) {
                    TransferData transferData = (TransferData) data;
                    errorCode = transferData.getErrorCode();
                    queryTransfer(transferData, errorCode);
                }
                break;
            default:
                break;
        }
    }

    private void queryTransferBank(String bankName, String bankNo) {
        mTransferBankHashMap.put(bankNo, bankName);
        rl_overlay.setVisibility(View.GONE);
    }

    private void querySigningBank(SigningBank signingBank, boolean isSrvChainEnd) {
        String tempBankNo = signingBank.getBankNo();

        if (tempBankNo != null && !tempBankNo.isEmpty()) {
            mSigningBankNoList.add(tempBankNo);
            mSigningBankCurrencyNoList.add(signingBank.getCurrencyNo());
        }

        mSigningBankList.add(signingBank);

        if (isSrvChainEnd) {
            // when the flag isEnd is 0, then begin to parse data.

            tv_bank_no.setText(mSigningBankList.get(0).getUserNo());
            mCurrentBank = mSigningBankList.get(0);
            queryFuturesValue(mCurrentBank);

            if (mSigningBankNoList.size() > 0) {
                for (int i = 0; i < mSigningBankNoList.size(); i++) {
                    String signBankNo = mSigningBankNoList.get(i);
                    String signBankName = mTransferBankHashMap.get(mSigningBankNoList.get(i));
                    mData.add(signBankName);
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put(signBankNo, signBankName);
                    mSigningBankHashMapList.add(hashMap);
                }
                tv_bank_name.setText(mSigningBankHashMapList.get(0).get(mSigningBankNoList.get(0)) + "("
                        + mSigningBankCurrencyNoList.get(0) + ")");
                // When finish the inquiries, than show the data.
            } else {
                ToastHelper.show(EsBankTransferActivity.this, R.string.es_activity_bank_transfer_no_signing_bank);
            }
        }
    }

    private void queryWithNoSigningBank() {
        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
        if (account != null) {
            queryFuturesMoney(account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo());
        }
        ToastHelper.show(EsBankTransferActivity.this, R.string.es_activity_bank_transfer_no_signing_bank);
        rl_overlay.setVisibility(View.GONE);
    }

    private void queryBalance(String bankNo, String currencyNo, double balance) {
        if (mCurrentBank != null && mCurrentBank.getBankNo().equals(bankNo)
                && mCurrentBank.getCurrencyNo().equals(currencyNo) && mShowBankMoney) {
            queryBalanceSuccessfully(balance);
        }
    }

    private void queryBalanceError(String errorText) {
        // 余额查询失败
        String errorTextBalanceFail = errorText;
        AlertDialog.Builder builder = new AlertDialog.Builder(EsBankTransferActivity.this);
        builder.setTitle(R.string.es_activity_bank_transfer_error_transfer);
        builder.setMessage(errorTextBalanceFail);
        builder.setPositiveButton(R.string.es_activity_account_detail_confirm, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        if (dialog_old != null && dialog_old.isShowing()) {
            dialog_old.dismiss();
        }
        AlertDialog dialog = builder.create();
        dialog_old = dialog;
        dialog.show();
        rl_overlay.setVisibility(View.GONE);
    }

    private void queryTransfer(TransferData transferData, int errorCode) {
        rl_overlay.setVisibility(View.GONE);
        if (errorCode == 0) {
            queryTransferSuccessfully(transferData);
        } else {
            queryTransferFail(transferData);
        }
    }
}
