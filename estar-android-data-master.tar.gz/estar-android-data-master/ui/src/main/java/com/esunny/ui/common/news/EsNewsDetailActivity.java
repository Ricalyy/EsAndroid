package com.esunny.ui.common.news;

import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.TypedValue;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.esunny.data.api.EsWebApi;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsImageGetter;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.EsShareUtil;
import com.esunny.ui.util.EsTagHandler;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsIconTextView;

import java.io.IOException;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;


@Route(path = RoutingTable.ES_NEWS_DETAIL_ACTIVITY)
public class EsNewsDetailActivity extends EsBaseActivity {

    @BindView(R2.id.es_news_detail_toolbar)
    EsBaseToolBar mBaseToolBar;
    @BindView(R2.id.detail_activity_content_title)
    TextView mTitleContent;
    @BindView(R2.id.detail_activity_news_item_date)
    TextView mPublishTime;
    @BindView(R2.id.detail_activity_item_tag_container)
    LinearLayout mTagContainer;
    @BindView(R2.id.detail_activity_item_share)
    EsIconTextView mShareTv;
    @BindView(R2.id.detail_activity_content_tv)
    TextView mContentTv;
    @BindView(R2.id.detail_activity_total_Ll)
    LinearLayout mActivityTotalLl;

    private int newsID;
    private String NewsTitle = "";
    private String NewsContent = "";
    private String NewsTags = "";
    private String NewsPublishTime = "";

    Handler mHandler = new Handler(Looper.getMainLooper());

    private String mNewsDetailUrl = "http://news.epolestar.xyz/newsH5/CHS/detail.html?newsid=%d&theme=%d";

    @Override
    protected int getContentView() {
        return R.layout.es_news_fragment_detail;
    }

    @Override
    protected void initData() {
        super.initData();
        obtainNewsID();
        dealUrl();
        getNews();
    }

    private void obtainNewsID() {
        String newsDetailsUrl = getIntent().getStringExtra(EsUIConstant.KEY_INTENT_NEWS_DETAILS_URL);
        if (newsDetailsUrl == null) {
            newsID = getIntent().getIntExtra("newsID", 0);
        } else {
            newsID = Integer.parseInt(newsDetailsUrl);
        }
    }

    private void dealUrl() {
        int theme = EsSPHelper.getTheme(this)  ? 1 : 0;
        mNewsDetailUrl = String.format(mNewsDetailUrl, newsID, theme);
    }

    private void getNews() {
        EsWebApi.getNewsDetail(newsID, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                JSONArray jsonArray = JSON.parseArray(response.body().string());
                JSONObject jsonObject = jsonArray.getJSONObject(0);
                JSONArray jsonData = jsonObject.getJSONArray("JsonRspData");
                if (jsonData != null) {
                    NewsTitle = jsonData.getJSONObject(0).getString("NewsTitle");
                    NewsContent = jsonData.getJSONObject(0).getString("NewsContent");
                    NewsTags = jsonData.getJSONObject(0).getString("NewsTag");
                    NewsPublishTime = jsonData.getJSONObject(0).getString("NewsPublishTime");

                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            initView();
                        }
                    });
                }
            }
        });
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        initToolbar();
    }

    private void initView() {
        mTitleContent.setText(NewsTitle);
        mPublishTime.setText(NewsPublishTime);
        // 设置新闻Tag
        addNewsTag(NewsTags);
        // 处理新闻内容
        dealContent();
    }

    private void addNewsTag(String newsTag) {
        String[] tagArray = newsTag.split("\\|");
        for (int index = 0; index < tagArray.length; index++) {
            String tag = tagArray[index];
            if (tag != null && !tag.isEmpty()) {
                TextView tvTag = new TextView(getBaseContext());
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                layoutParams.rightMargin = getBaseContext().getResources().getDimensionPixelSize(R.dimen.x22);
                tvTag.setLayoutParams(layoutParams);
                tvTag.setText(tag);
                tvTag.setTextSize(TypedValue.COMPLEX_UNIT_PX, getBaseContext().getResources().getDimension(R.dimen.x20));
                tvTag.setTextColor(getTagColor(index));
                tvTag.setPadding(getBaseContext().getResources().getDimensionPixelSize(R.dimen.x10), getBaseContext().getResources().getDimensionPixelSize(R.dimen.x3), getBaseContext().getResources().getDimensionPixelSize(R.dimen.x10), getBaseContext().getResources().getDimensionPixelSize(R.dimen.x3));
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setStroke(getBaseContext().getResources().getDimensionPixelSize(R.dimen.x2), getTagColor(index));
                gradientDrawable.setCornerRadius(getBaseContext().getResources().getDimensionPixelSize(R.dimen.x50));
                tvTag.setBackground(gradientDrawable);

                mTagContainer.addView(tvTag);
            }
        }
    }

    @OnClick(R2.id.detail_activity_item_share)
    public void share() {
        EsShareUtil.shareWeb(EsNewsDetailActivity.this, mNewsDetailUrl, NewsTitle, NewsContent);
    }

    /**
     * @param index tag在列表中位置
     * @return 标签颜色，按蓝绿橙循环。
     */
    public int getTagColor(int index) {
        int color = getBaseContext().getResources().getColor(R.color.es_activity_tactic_sell_strike_price_text_color);
        if (index % 3 == 1) {
            color = getBaseContext().getResources().getColor(R.color.es_activity_tactic_buy_strike_price_text_color);
        } else if (index % 3 == 2) {
            color = getBaseContext().getResources().getColor(R.color.es_activity_tactic_sell_strike_price_text_color);
        } else if (index % 3 == 0) {
            color = getBaseContext().getResources().getColor(R.color.es_activity_tatic_order_strategy_profit_way_value_green);
        }
        return color;
    }

    private void dealContent() {
        NewsContent = NewsContent.replaceAll("[\\t\\n]", "");
        mContentTv.setMovementMethod(LinkMovementMethod.getInstance());
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            mContentTv.setText(Html.fromHtml(NewsContent, Html.FROM_HTML_MODE_LEGACY, new EsImageGetter(getBaseContext(), mContentTv), new EsTagHandler(EsNewsDetailActivity.this)));
        } else {
            mContentTv.setText(Html.fromHtml(NewsContent, new EsImageGetter(getBaseContext(), mContentTv), new EsTagHandler(EsNewsDetailActivity.this)));
        }

    }

    private void initToolbar() {
        mBaseToolBar.setSimpleBack(getString(R.string.es_news_detail));
    }

}
