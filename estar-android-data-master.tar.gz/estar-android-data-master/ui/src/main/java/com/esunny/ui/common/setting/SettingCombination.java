package com.esunny.ui.common.setting;

import android.app.Activity;
import android.content.Context;

import com.esunny.data.bean.MoneyField;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.BaseView;
import com.esunny.ui.data.setting.EsLoginAccountData;

public interface SettingCombination {

    interface View extends BaseView{

        void showIsConnectUI(boolean isConnect);

        void showMoneyDetail();

        void showAccountCount();

        void showLoginUI();

        void refreshTitleByAccountCount(int accountCount, String userNo);

        void updateBadgeViewByMessage(boolean isHadUnreadMessage);

        void updateBadgeViewNum(int condition, int stoplp);
    }

    interface Presenter {
        void login();

        void charSetting();

        void tradeSetting();

        void cloundConditionOrder();

        void stopLossAndStopProfit();

        void priceWarn();

        void aboutTrade();

        void message();

        void quoteLogin(Activity activity);

        void openAccount();

        void changeSkin(Context context);

        void setting();

        void about();

        void accountDetail();

        void selectAccount();

        void refreshAccountDataDetail();

        void queryMessage();

        void queryStrategy();

        void turnToStopLossOpen();
    }

    interface Model {
        String getAccountMoneyDetail();

        MoneyField[] getMoneyFieldFromAccount(EsLoginAccountData.LoginAccount account);

        EsLoginAccountData getLoginAccountData();

        void setLastUserInfo(EsLoginAccountData.LoginAccount account);

        boolean isSameUser();

        boolean isHasUnreadMessage(Context context);
    }

}
