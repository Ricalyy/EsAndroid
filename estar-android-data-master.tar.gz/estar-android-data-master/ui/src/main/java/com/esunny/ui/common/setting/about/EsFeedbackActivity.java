package com.esunny.ui.common.setting.about;

import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.MediaStore;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.util.AndroidSysInfoUtils;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsNetHelper;
import com.esunny.ui.R;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsFileUtil;
import com.esunny.ui.util.EsWebUrlData;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.util.picturechoose.ImageSelector;
import com.esunny.ui.view.EsBaseToolBar;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class EsFeedbackActivity extends EsBaseActivity {

    private static final String TAG = "EsFeedbackActivity";

    private static final int REQUEST_CODE_IMAGE = 1000;
    private static final int REQUEST_CODE_PERMISSION = 1001;

    private static final int MSG_SHOW_PROGRESS_BAR = 0;
    private static final int MSG_HIDE_PROGRESS_BAR = 1;
    private static final int MSG_SHOW_TOAST = 2;
    private static final int MSG_TURN_TO_ONLINE = 3;
    private static final int MSG_SUBMIT_INFO = 4;

    private static final int REQUEST_CODE_SELECT_IMG = 1;
    private static final int MAX_SELECT_COUNT = 5;

    private WebView mWebView;
    ProgressBar mProgressBar;

    private String  mDetailUrl = "";
    private ValueCallback<Uri[]> mUploadCallbackAboveL;
    private Handler mHandler;

    private boolean mIsNeedLog;
    private TextView mSubmit;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_feedback;
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        EsBaseToolBar toolBar = findViewById(R.id.es_activity_feedback_toolbar);
        toolBar.setTitle(getString(R.string.es_setting_feedback));
        toolBar.setLeftIcons(R.string.es_icon_toolbar_back);
        toolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if(id == R.id.toolbar_left_first){
                    finish();
                }
            }
        });

        mSubmit = findViewById(R.id.es_activity_feedback_submit);
        mSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mProgressBar != null) {
                    mProgressBar.setVisibility(View.VISIBLE);
                }
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        submit();
                    }
                }).start();
            }
        });

        mProgressBar = findViewById(R.id.es_activity_feedback_progressbar);
        mProgressBar.setVisibility(View.VISIBLE);

        initWebView();
    }

    @Override
    protected void initData() {
        super.initData();

        mDetailUrl = EsWebUrlData.getFeedbackUrl(this);

        mHandler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {

                switch (msg.what){
                    case MSG_SHOW_PROGRESS_BAR:
                    case MSG_HIDE_PROGRESS_BAR:
                        if (mProgressBar != null) {
                            if (msg.what == MSG_SHOW_PROGRESS_BAR) {
                                mProgressBar.setVisibility(View.VISIBLE);
                            } else {
                                mProgressBar.setVisibility(View.GONE);
                            }
                        }
                        break;
                    case MSG_SHOW_TOAST:
                        String str = (String) msg.obj;
                        ToastHelper.show(EsFeedbackActivity.this, str);
                        break;
                    case MSG_TURN_TO_ONLINE:
                        goToQQContract();
                        break;
                    case MSG_SUBMIT_INFO:
                        if (mWebView != null) {
                            String[] obj = (String[]) msg.obj;
                            mWebView.evaluateJavascript("javascript:submitFeedback(\""+ obj[0] + "\" , \""+ obj[1] + "\")", null);
                        }
                        break;
                    default:
                        break;
                }
                return false;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (mUploadCallbackAboveL != null) {
//            if (requestCode == REQUEST_CODE_IMAGE && resultCode == RESULT_OK) {
//                mSelected = Matisse.obtainResult(data);
//                if (mSelected != null) {
//                    int size = mSelected.size();
//                    if (size > 0) {
//                        Uri[] result = new Uri[size];
//                        for (int i = 0; i < size; i++) {
//                            result[i] = mSelected.get(i);
//                        }
//
//                        mUploadCallbackAboveL.onReceiveValue(result);
//                        return;
//                    }
//                }
//            }

//            /storage/emulated/0/Pictures/Screenshots/Screenshot_20191205_113033_com.huawei.android.tips.jpg
//            content://media/external/images/media/24458
//            Uri[] uri = new Uri[1];
//            if (resultCode == RESULT_OK && requestCode == 100) {
//                uri[0] = data.getData();
//                mUploadCallbackAboveL.onReceiveValue(uri);
//                return;
//            }
            if (requestCode == REQUEST_CODE_SELECT_IMG && resultCode == RESULT_OK) {
                showContent(data);
                return;
            } else {
                mUploadCallbackAboveL.onReceiveValue(null);
            }
        }
    }


    private void showContent(Intent data) {
        List<String> paths = ImageSelector.getImagePaths(data);

        if (paths == null || paths.isEmpty()) {
            return;
        }
            int size = paths.size();
            if (size > 0) {
                Uri[] result = new Uri[size];
                for (int i = 0; i < size; i++) {
                    result[i] = getMediaUriFromPath(this, paths.get(i));
                }
                mUploadCallbackAboveL.onReceiveValue(result);
            }
    }

    public static Uri getMediaUriFromPath(Context context, String path) {
        Uri mediaUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        Cursor cursor = context.getContentResolver().query(mediaUri,
                null,
                MediaStore.Images.Media.DISPLAY_NAME + "= ?",
                new String[] {path.substring(path.lastIndexOf("/") + 1)},
                null);

        Uri uri = null;
        if(cursor.moveToFirst()) {
            uri = ContentUris.withAppendedId(mediaUri,
                    cursor.getLong(cursor.getColumnIndex(MediaStore.Images.Media._ID)));
        }
        cursor.close();
        return uri;
    }

    private void initWebView(){
        mWebView = findViewById(R.id.es_activity_feedback_webview);
        mWebView.setFocusable(true);
        mWebView.getSettings().setTextZoom(100);
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);//测试阶段不适用缓存，方便调试
        mWebView.getSettings().setJavaScriptEnabled(true);

        mWebView.getSettings().setDomStorageEnabled(true);
        // 是否允许通过file url加载的Javascript读取本地文件，默认值 false
        mWebView.getSettings().setAllowFileAccessFromFileURLs(false);
        // 是否允许通过file url加载的Javascript读取全部资源(包括文件,http,https)，默认值 false
        mWebView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        String appCachePath = getApplicationContext().getCacheDir().getAbsolutePath();
        mWebView.getSettings().setAppCachePath(appCachePath);
        mWebView.getSettings().setAllowFileAccess(true);
        mWebView.getSettings().setAppCacheEnabled(true);
        mWebView.addJavascriptInterface(new FeedbackJavascript(this), "EsFeedbackUtil");

        //html5本地存储
        mWebView.setBackgroundColor(0);
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.loadUrl(mDetailUrl);
        mWebView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });

        //设置不用系统浏览器打开,直接显示在当前Webview
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                mWebView.loadUrl(url);
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
            }
        });

        mWebView.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onReceivedTitle(WebView view, String title) {
                super.onReceivedTitle(view, title);
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress == 100) {
                    mProgressBar.setVisibility(View.GONE);

                    mSubmit.setVisibility(View.VISIBLE);
                }
                super.onProgressChanged(view, newProgress);
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                mUploadCallbackAboveL = filePathCallback;
                takePhoto();
                return true;
            }
        });
    }

    private void takePhoto() {
        ImageSelector.show(this, REQUEST_CODE_SELECT_IMG, MAX_SELECT_COUNT);
    }

    private void goToQQContract() {
        //400开头的公众号需要替换成对应的web协议的uin（4006156869替换成938026171）
        if (isQQClientAvailable(this.getBaseContext())) {
            String url = "mqqwpa://im/chat?chat_type=crm&uin=938026171&version=1&src_type=web&web_src=http:://wpa.b.qq.com";
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } else {
            ToastHelper.show(this, R.string.es_activity_about_tip_no_QQ);
        }
    }

    private boolean isQQClientAvailable(Context context) {
        // 目前不支持QQ轻聊版，若支持，需要添加则包名检测为com.tencent.qqlite
        final PackageManager packageManager = context.getPackageManager();
        List<PackageInfo> pInfo = packageManager.getInstalledPackages(0);
        if (pInfo != null) {
            for (int index = 0; index < pInfo.size(); index++) {
                String pn = pInfo.get(index).packageName;
                if (pn.equals("com.tencent.mobileqq") || pn.equals("com.tencent.tim")) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    protected void onDestroy() {
        if (mWebView != null) {
            mWebView.setWebViewClient(null);
            mWebView.setWebChromeClient(null);
            mWebView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            mWebView.clearHistory();
//            ((ViewGroup) webView.getParent()).removeView(webView);
            mWebView.destroy();
            mWebView = null;
        }

        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }

        super.onDestroy();
    }

    /**
     * 校验Permission权限
     *
     * @param context    Context
     * @param permission 权限名
     * @return 是否有权限
     */
    private boolean checkPermission(Context context, String permission) {
        boolean result = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {
                return false;
            }
        } else {
            PackageManager pm = context.getPackageManager();
            if (pm.checkPermission(permission, context.getPackageName()) == PackageManager.PERMISSION_GRANTED) {
                result = true;
            }
        }
        return result;
    }

    private String getSystemInfo() {
        String ret = EsUIApi.getVersion(this) + "@"
                + AndroidSysInfoUtils.getOsVersion() + "@"
                + AndroidSysInfoUtils.getSystemLanguage() + "@"
                + AndroidSysInfoUtils.getSystemModel() + "@"
                + AndroidSysInfoUtils.getDeviceBrand() + "@"
                + EsNetHelper.getMac(this) + "@"
                + EsDataApi.getPackageNo();
        QuoteLoginInfo info = EsDataApi.quoteLoginInfo();

        if (info != null) {
            ret += "@" + info.getLoginNo();
        }

        return ret;
    }

    private String getLog() {
        String fileDir = Environment.getExternalStorageDirectory().getPath() + "/Estar/CrashLog/";
        String zipFile =  Environment.getExternalStorageDirectory().getPath() + "/Estar/log.zip";

        try {
            EsFileUtil.ZipFolder(fileDir, zipFile);
        } catch (Exception e) {
            return "";
        }

        File file = new File(zipFile);
        if (!file.exists()) {
            return "";
        }

        byte[] bytes;
        try {
            bytes = EsFileUtil.getFileBytes(file);
        } catch (IOException e) {
            return "";
        }

        if (bytes == null) {
            return "";
        }

        String data = Base64.encodeToString(bytes, Base64.NO_WRAP);

        boolean ret = EsFileUtil.deleteFile(file);
        EsLog.d(TAG, "getLog = " + ret);

        return data;
    }

    private void submit() {
        String info = getSystemInfo();
        String log = "";
        if (mIsNeedLog) {
            log = getLog();
        }

        if (mHandler != null) {
            String[] obj = new String[]{info, log};
            mHandler.sendMessage(mHandler.obtainMessage(MSG_SUBMIT_INFO, obj));
        }
    }

    /**
     * 申请单个权限
     */
    private void startRequestPermision(Activity activity, String permission, int requestCode) {
        ActivityCompat.requestPermissions(activity, new String[]{permission}, requestCode);
    }

    private class FeedbackJavascript{

        private static final String TAG = "FeedbackJavascript";

        private Activity mActivity;

        FeedbackJavascript(Activity activity) {
            mActivity = activity;
        }

        @JavascriptInterface
        public void log(String str) {
            EsLog.d(TAG, str);
        }

        @JavascriptInterface
        public void showToast(String str){

            if (mHandler != null) {
                mHandler.sendMessage(mHandler.obtainMessage(MSG_SHOW_TOAST, str));
            }
        }

        @JavascriptInterface
        public void online() {
            if (mHandler != null) {
                mHandler.sendMessage(mHandler.obtainMessage(MSG_TURN_TO_ONLINE));
            }
        }

        @JavascriptInterface
        public void showProgress(int show) {
            EsLog.d(TAG, "showProgress = " + show);
            if (mHandler != null) {
                mHandler.sendMessage(mHandler.obtainMessage(show));
            }
        }

        @JavascriptInterface
        public void setNeedLog(boolean log) {
            mIsNeedLog = log;
        }
    }
}
