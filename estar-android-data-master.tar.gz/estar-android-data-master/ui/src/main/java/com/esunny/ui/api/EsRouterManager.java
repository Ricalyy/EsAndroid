package com.esunny.ui.api;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import com.alibaba.android.arouter.launcher.ARouter;
import com.esunny.data.api.EsDataApi;
import com.esunny.ui.data.setting.EsLoginAccountData;

import static com.esunny.ui.quote.kline.KLineActivity.KEY_CONTRACT_KLINE;
import static com.esunny.ui.quote.kline.KLineActivity.KEY_INTENT_LIST_POSITION;
import static com.esunny.ui.quote.kline.KLineActivity.KEY_INTENT_SOURCE;

class EsRouterManager {

    static Fragment getFragment(int tag) {
        switch (tag) {
            case EsUIApi.SHOW_FAVORITE_FRAGMENT:
                return (Fragment) ARouter.getInstance().build(RoutingTable.ES_FAVORITE_FRAGMENT).navigation();
            case EsUIApi.SHOW_QUOTE_FRAGMENT:
                return (Fragment) ARouter.getInstance().build(RoutingTable.ES_QUOTE_FRAGMENT).navigation();
            case EsUIApi.SHOW_OPTION_FRAGMENT:
                return (Fragment) ARouter.getInstance().build(RoutingTable.ES_OPTION_FRAGMENT).navigation();
            case EsUIApi.SHOW_TRADE_FRAGMENT:
                if (EsDataApi.isContainTrade()) {
                    return (Fragment) ARouter.getInstance().build(RoutingTable.ES_TRADE_FRAGMENT).navigation();
                }
            case EsUIApi.SHOW_NEW_FRAGMENT:
                if (EsDataApi.isContainNews()) {
                    return (Fragment) ARouter.getInstance().build(RoutingTable.ES_NEWS_FRAGMENT).navigation();
                }
            case EsUIApi.SHOW_SETTING_FRAGMENT:
                return (Fragment) ARouter.getInstance().build(RoutingTable.ES_LOGIN_FRAGMENT).navigation();
            case EsUIApi.SHOW_FUNDS_FRAGMENT:
                return (Fragment) ARouter.getInstance().build(RoutingTable.ES_FUNDS_FRAGMENT).navigation();
            default:
                break;
        }
        return null;
    }

    static void startStartActivity() {
        ARouter.getInstance().build(RoutingTable.ES_START_ACTIVITY).navigation();
    }

    static void startStartActivity(String key, int value) {
        ARouter.getInstance().build(RoutingTable.ES_START_ACTIVITY).withInt(key, value).navigation();
    }

    static void startUpdateActivity() {
        ARouter.getInstance().build(RoutingTable.ES_UPDATE_ACTIVITY).navigation();
    }

    static void startEsKLineActivity(String contractNo) {
        ARouter.getInstance().build(RoutingTable.ES_KLINE_ACTIVITY)
                .withString(KEY_CONTRACT_KLINE, contractNo).navigation();
    }

    static void startEsKLineActivity(int position) {
        ARouter.getInstance().build(RoutingTable.ES_KLINE_ACTIVITY)
                .withInt(KEY_INTENT_LIST_POSITION, position).navigation();
    }

    static void startEsKLineActivity(int position, int source) {
        ARouter.getInstance().build(RoutingTable.ES_KLINE_ACTIVITY)
                .withInt(KEY_INTENT_LIST_POSITION, position)
                .withInt(KEY_INTENT_SOURCE, source)
                .navigation();
    }

    static void startSearchActivity() {
        ARouter.getInstance().build(RoutingTable.ES_SEARCH_ACTIVITY)
                .navigation();
    }

    static void startFavoriteEditActivity() {
        ARouter.getInstance().build(RoutingTable.ES_FAVORITE_EDIT_ACTIVITY)
                .navigation();
    }

    static void startNewsDetailActivity(Context context, String newsID){
        if (EsDataApi.isContainNews()) {
            ARouter.getInstance().build(RoutingTable.ES_NEWS_DETAIL_ACTIVITY)
                .withString(EsUIConstant.KEY_INTENT_NEWS_DETAILS_URL, newsID)
                .navigation();
        }
    }

    static void startConditionalOrderActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_CONDITIONAL_ORDER_ACTIVITY).navigation();
        }
    }

    static void startEsStrategyStopActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_STOP_LP_ORDER_ACTIVITY).navigation();
        }
    }

    static void startEsStrategyStopActivity(String parentNo, char orderType) {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_STOP_LP_ORDER_ACTIVITY)
                    .withString("parentNo", parentNo)
                    .withChar("orderType", orderType).navigation();
        }
    }

    static void startEsPriceWarnActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_PRICE_WARN_ACTIVITY).navigation();
        }
    }

    static void startEsStrategyActivity(String source, String contractNo) {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_STRATEGY_CONDITION_ACTIVITY)
                    .withString("source", source)
                    .withString("contractNo", contractNo)
                    .navigation();
        }
    }

    static void startPositionStopLossPanelActivity(String contractNo, char hedge, char direct,double openPrice,long qty) {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_POSITION_STOP_LOSS_PANEL_ACTIVITY)
                    .withString("contractNo", contractNo)
                    .withChar("hedge", hedge)
                    .withChar("direct", direct)
                    .withDouble("openPrice", openPrice)
                    .withLong("qty", qty).navigation();
        }
    }

    static void startLoginActivity(int position) {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_LOGIN_ACTIVITY).withInt("location", position).navigation();
        }
    }

    static void startCompanyListActivity(Activity cotext, int requestCode) {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_COMPANY_LIST_ACTIVITY).navigation(cotext, requestCode);
        }
    }

    static void startStarLoginActivity() {
        ARouter.getInstance().build(RoutingTable.ES_STAR_LOGIN_ACTIVITY).navigation();
    }

    static void startEstarStoreActivity() {
        ARouter.getInstance().build(RoutingTable.ES_STAR_STORE_ACTIVITY).navigation();
    }

    static void startStarLoginActivity(Activity activity) {
//        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_STAR_LOGIN_ACTIVITY).navigation(activity, EsUIConstant.S_STATE_QUOTE_LOGIN_CODE);
//        }
    }

    static void startBillQueryActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_BILL_QUERY_ACTIVITY).navigation();
        }
    }

    static void startBankTransferActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_BANK_TRANSFER_ACTIVITY).navigation();
        }
    }

//    static void startAccountDetailActivity(EsLoginAccountData.LoginAccount loginAccount) {
//        if (EsDataApi.isContainTrade()) {
//            Bundle bundle = new Bundle();
//            bundle.putString("companyNo",loginAccount.getCompanyNo());
//            bundle.putString("userNo",loginAccount.getUserNo());
//            ARouter.getInstance().build(RoutingTable.ES_ACCOUNT_DETAIL_ACTIVITY).with(bundle).navigation();
//        }
//    }

    static void startAccountSelectActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_ACCOUNT_SELECT_ACTIVITY).navigation();
        }
    }

//    static void startChooseCurrencyNoActivity(EsLoginAccountData.LoginAccount loginAccount, Activity activity) {
//        if (EsDataApi.isContainTrade()) {
//            Bundle bundle = new Bundle();
//            bundle.putString("companyNo",loginAccount.getCompanyNo());
//            bundle.putString("userNo",loginAccount.getUserNo());
//            ARouter.getInstance().build(RoutingTable.ES_CHOOSE_CURRENCY_NO_ACTIVITY)
//                    .with(bundle)
//                    .withString("currencyNo", loginAccount.getCurrencyGroupNo() + "_" + loginAccount.getCurrencyNo())
//                    .navigation(activity, 1);
//        }
//    }

    static void startTradeLogActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_TRADE_LOG_ACTIVITY).navigation();
        }
    }

    static void startTradeSettingActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_TRADE_SETTING_ACTIVITY).navigation();
        }
    }

    static void startChartSettingActivity() {
        ARouter.getInstance().build(RoutingTable.ES_CHART_SETTING_ACTIVITY).navigation();
    }

    static void startAboutActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_ABOUT_ACTIVITY).navigation();
        }
    }

    static void startSystemSettingActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_SYSTEM_SETTING_ACTIVITY).navigation();
        }
    }

    static void startEsAccountDetialActivity(EsLoginAccountData.LoginAccount loginAccount) {
        if (EsDataApi.isContainTrade()) {
            Bundle bundle = new Bundle();
            bundle.putString("companyNo",loginAccount.getCompanyNo());
            bundle.putString("userNo",loginAccount.getUserNo());
            bundle.putString("addrNo",loginAccount.getAddrTypeNo());
            ARouter.getInstance().build(RoutingTable.ES_ACCOUNT_DETAIL_ACTIVITY).with(bundle).navigation();
        }
    }

    static void startPasswordActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_PASSWORD_ACTIVITY).navigation();
        }
    }

    static void startSearchActivity(String source) {
        ARouter.getInstance().build(RoutingTable.ES_SEARCH_ACTIVITY)
                .withString(EsUIConstant.KEY_SEARCH_SOURCE, source)
                .navigation();
    }

//    void startSearchActivityForResult(Activity activity, String source, int requestCode) {
//        ARouter.getInstance().build(RoutingTable.ES_SEARCH_ACTIVITY)
//                .withString(EsDataApi.KEY_SEARCH_SOURCE, source)
//                .navigation(activity, requestCode);
//    }
//
    static void startMessageActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_MESSAGE_ACTIVITY).navigation();
        }
    }

    static void startTradeAboutActivity() {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_TRADE_ABOUT_ACTIVITY).navigation();
        }
    }

    static void startStopLossOpenActivity(String source, String orderNo) {
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_STOP_LOSS_OPEN_ACTIVITY)
                    .withString("source", source)
                    .withString("orderNo", orderNo)
                    .navigation();
        }
    }

    static void startDisclaimerActivity(Activity activity){
        ARouter.getInstance().build(RoutingTable.ES_DISCLAIMER_ACTIVITY)
                .navigation(activity, EsUIConstant.S_STATE_CONFIRM_REQUEST_CODE);
    }

    static void startPrivacyActivity(){
        ARouter.getInstance().build(RoutingTable.ES_PRIVACY_ACTIVITY)
                .navigation();
    }

    static void startNoticeActivity(){
        ARouter.getInstance().build(RoutingTable.ES_NOTICE_ACTIVITY)
                .navigation();
    }

    static void startBillStateConfirmActivity(String content, Activity activity){
        ARouter.getInstance().build(RoutingTable.ES_BILL_STATE_CONFIRM_ACTIVITY)
                .withString(EsUIConstant.KEY_STATE_CONFIRM_CONTENT, content)
                .navigation(activity, EsUIConstant.S_STATE_CONFIRM_REQUEST_CODE);
    }

    static void startEsTriggeredConditionalOrderActivity(){
        if (EsDataApi.isContainTrade()) {
//            if (EsLoginAccountData.getInstance().getCurrentAccount() == null) {
//                startLoginActivity(-1);
//                return;
//            }
            ARouter.getInstance().build(RoutingTable.ES_TRIGGERED_CONDITIONAL_ORDER_ACTIVITY)
                    .navigation();
        }
    }
    static void startEsTriggeredStopLossOrderActivity(){
        if (EsDataApi.isContainTrade()) {
//            if (EsLoginAccountData.getInstance().getCurrentAccount() == null) {
//                startLoginActivity(-1);
//                return;
//            }
            ARouter.getInstance().build(RoutingTable.ES_TRIGGERED_STOP_LOSS_ORDER_ACTIVITY)
                    .navigation();
        }
    }

    static void startOpenOnlineActivity(){
        if (EsDataApi.isContainTrade()) {
            ARouter.getInstance().build(RoutingTable.ES_OPEN_ONLINE_ACTIVITY)
                    .navigation();
        }
    }

    static void startChooseCurrencyNoActivity(EsLoginAccountData.LoginAccount loginAccount, Activity activity) {
        Bundle bundle = new Bundle();
        bundle.putString("companyNo",loginAccount.getCompanyNo());
        bundle.putString("userNo",loginAccount.getUserNo());
        bundle.putString("addrNo",loginAccount.getAddrTypeNo());
        ARouter.getInstance().build(RoutingTable.ES_CHOOSE_CURRENCY_NO_ACTIVITY)
                .with(bundle)
                .withString("currencyNo", loginAccount.getCurrencyGroupNo() + "_" + loginAccount.getCurrencyNo())
                .navigation(activity, 1);
    }
}
