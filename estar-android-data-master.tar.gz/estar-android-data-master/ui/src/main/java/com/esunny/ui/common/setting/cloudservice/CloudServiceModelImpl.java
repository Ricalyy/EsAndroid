package com.esunny.ui.common.setting.cloudservice;

import android.text.TextUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.esunny.data.api.EsWebApi;
import com.esunny.data.bean.Contract;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

/**
 * @author xiaosa
 */
public class CloudServiceModelImpl {

    interface syncContractListener {
        void downLoadFavoriteContract(List<String> contractStrList);
    }

//    private JSONObject jsonObject ;

    public JSONObject getJsonObject() {
        JSONObject jsonObject;
        String str = "{\n" +
                "    \"JsonRspHead\": {\n" +
                "        \"ErrorCode\": 0,\n" +
                "        \"ErrorText\": \"成功\",\n" +
                "        \"TotalCount\": 1\n" +
                "    },\n" +
                "    \"JsonRspData\": {\n" +
                "        \"UserNo\": \"allen123\",\n" +
                "        \"Source\": 1,\n" +
                "        \"ContractList\": [\n" +
                "            \"ZCE|F|CF|101\"\n" +
                "        ],\n" +
                "        \"CLUpdateTime\": \"20200828140759\",\n" +
                "        \"SettingsConfig\": {},\n" +
                "        \"SCUpdateTime\": \"\"\n" +
                "    }\n" +
                "}";

        jsonObject = JSON.parseObject(str);
        return jsonObject;
    }

    public int sendFavoriteContract(List<Contract> contractList) {
        return EsWebApi.sendFavoriteContract(contractList);
    }
}
