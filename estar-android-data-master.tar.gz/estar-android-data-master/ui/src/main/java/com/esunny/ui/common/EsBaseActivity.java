package com.esunny.ui.common;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.view.WindowManager;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.util.AntiHijackService;
import com.esunny.ui.util.EsAppManager;
import com.esunny.ui.util.EsLanguageHelper;

import butterknife.ButterKnife;

public abstract class EsBaseActivity extends AppCompatActivity {

    protected abstract int getContentView();
    protected void initWidget(){}
    protected void initData(){}

    boolean mIsRemove = false;
    boolean mNeedInit = true;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (mNeedInit && !EsDataApi.isInit()) {
            EsUIApi.startStartLoadingActivity();
            finish();
            return;
        }

        initData();

        setContentView(getContentView());
        //初始化数据、控件
        ButterKnife.bind(this);
        initWidget();

        mIsRemove = false;
        EsAppManager.getAppManager().addActivity(this);
    }

    protected void setNeedInit(boolean needInit) {
        mNeedInit = needInit;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (EsSPHelperProxy.getIsKeepScreenOn(this)){
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!EsSPHelperProxy.getIsKeepScreenOn(this)){
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }

        if (isFinishing()) {
            EsAppManager.getAppManager().removeActivity();
            mIsRemove = true;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        AntiHijackService.startCheckHijack(this);
    }

    @Override
    protected void onDestroy() {
//        EsAppManager.getAppManager().removeActivity();
        super.onDestroy();

        if (isFinishing() && !mIsRemove) {
            EsAppManager.getAppManager().removeActivity();
        }
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(EsLanguageHelper.attachBaseContext(newBase, EsLanguageHelper.mNewLanguageType));
    }
}
