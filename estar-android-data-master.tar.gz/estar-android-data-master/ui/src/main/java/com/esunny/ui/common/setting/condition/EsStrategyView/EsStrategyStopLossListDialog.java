package com.esunny.ui.common.setting.condition.EsStrategyView;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.OpenOrder;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.common.setting.condition.EsStrategyData.EsStrategyData;
import com.esunny.ui.common.setting.condition.adapter.EsStrategyStopLossAdapter;
import com.esunny.ui.dialog.EsStopLossOpenDialog;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.EstarFieldTransformation;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsIconTextView;

import java.util.List;

public class EsStrategyStopLossListDialog extends Dialog implements View.OnClickListener, EsStopLossOpenDialog.EsDialogClickListener {

    private Context mContext;
    private EsIconTextView itv_add;
    private List<OpenOrder> mData;
    private RecyclerView rv_list;

    EsStopLossOpenDialog mStopLossDialog;
    EsStrategyStopLossAdapter mAdapter;

    public EsStrategyStopLossListDialog(@NonNull Context context) {
        super(context);
        mContext = context;
    }

    public EsStrategyStopLossListDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);

        mContext = context;
    }

    protected EsStrategyStopLossListDialog(@NonNull Context context, boolean cancelable, @Nullable OnCancelListener cancelListener) {
        super(context, cancelable, cancelListener);

        mContext = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.es_strategy_stoploss_list_dialog);

        initDialogLayoutParams();
        bindView();
        bindOnClick();
        bindRecyclerview();
    }

    // 列表最多展示四项
    private void initDialogLayoutParams() {
        Window window= getWindow();
        WindowManager windowManager = window.getWindowManager();
        WindowManager.LayoutParams layoutParams = window.getAttributes();
        if (EsSPHelper.getTheme(mContext)){
            layoutParams.dimAmount = 0.2f;
        }else {
            layoutParams.dimAmount = 0.6f;
        }
        Display display = windowManager.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        layoutParams.width = size.x;

        window.setAttributes(layoutParams);
        window.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
    }

    private void bindView() {
        rv_list = findViewById(R.id.es_new_custom_list_dialog_rv_list);
        itv_add = findViewById(R.id.es_new_custom_list_dialog_etv_add);
    }

    private void bindOnClick() {
        itv_add.setOnClickListener(this);
    }

    private void bindRecyclerview() {
        mAdapter = new EsStrategyStopLossAdapter(mContext);
        rv_list.setAdapter(mAdapter);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(mContext,
                LinearLayoutManager.VERTICAL, false);
        rv_list.setLayoutManager(layoutManager);
    }

    private void showStopLossDialog(OpenOrder openOrder) {
        if (mData != null && mData.size() > 1) {
            return;
        }

        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (contract == null) {
            ToastHelper.show(mContext, R.string.es_view_trade_threekey_warning_chosecontract);
            return;
        }

        double price = EsStrategyData.getInstance().getmLastPrice();
        mStopLossDialog = new EsStopLossOpenDialog(mContext);
        mStopLossDialog.setContract(contract).setOpenOrder(openOrder)
                .setLastPrice(EsDataApi.formatPrice(contract.getCommodity(), price))
                .setPriceTypeStr(getOrderPriceTypeStr()).setBtnClick(this).show();
    }

    private String getOrderPriceTypeStr() {
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        String specialPrice = EstarFieldTransformation.priceTypeToStr(mContext, EsSPHelperProxy.getDefaultPriceType(mContext));
        if (EsSPHelperProxy.getDefaultPriceType(mContext) == EsSPHelperProxy.S_PT_MARKET && !EsDataApi.isMarketPriceAvailable(contract)) {
            if (EsSPHelper.getMarketPriceSetting(mContext)) {
                ToastHelper.show(mContext, R.string.es_trade_notify_message_trade_contractset_market_price_available);
                specialPrice = EstarFieldTransformation.priceTypeToStr(mContext, EsSPHelperProxy.S_PT_MATCH);
            }
        }
        return specialPrice;
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.es_new_custom_list_dialog_etv_add) {
            showStopLossDialog(new OpenOrder());
        }
    }

    @Override
    public void show() {
        super.show();

        if (mAdapter != null) {
            mData = EsStrategyData.getInstance().getStopLossList();
            mAdapter.setData(mData);
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void clickConfirm(OpenOrder openOrder, String orderPrice) {
        if (mStopLossDialog == null || openOrder == null || mData == null || mAdapter == null) {
            return;
        }

        char type = openOrder.getStrategyType();
        if (type == EsDataConstant.S_ST_OPEN_STOPLOSS) {
            type = EsDataConstant.S_ST_STOPLOSS;
        } else if (type == EsDataConstant.S_ST_OPEN_STOPPROFIT) {
            type = EsDataConstant.S_ST_STOPPROFIT;
        } else if (type == EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT) {
            type = EsDataConstant.S_ST_FLOATSTOPLOSS;
        } else if (type == EsDataConstant.S_ST_OPEN_BREAKEVEN) {
            type = EsDataConstant.S_ST_BREAKEVEN;
        }

        int count = mData.size();
        if (count > 1) {
            return;
        }

        boolean isStopLoss = (type == EsDataConstant.S_ST_STOPLOSS || type == EsDataConstant.S_ST_FLOATSTOPLOSS);
        if (count > 0) {
            for (OpenOrder order : mData) {
                char strategyType = order.getStrategyType();
                if (type == order.getStrategyType() ||
                        (isStopLoss && ((strategyType == EsDataConstant.S_ST_STOPLOSS || strategyType == EsDataConstant.S_ST_FLOATSTOPLOSS)))) {
                    ToastHelper.show(getContext(), R.string.es_stop_loss_open_activity_judge_same_order);
                    return;
                }
            }
        }

        openOrder.setPriceStr(orderPrice);
        openOrder.setStrategyType(type);
        mData.add(openOrder);
        mAdapter.notifyDataSetChanged();
        mStopLossDialog.dismiss();
    }

    @Override
    public void clickCancel() {
        if (mStopLossDialog != null) {
            mStopLossDialog.dismiss();
        }
    }
}
