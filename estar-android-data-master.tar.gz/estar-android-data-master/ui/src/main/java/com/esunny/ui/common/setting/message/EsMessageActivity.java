package com.esunny.ui.common.setting.message;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.RelativeLayout;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.bean.MessageData;
import com.esunny.ui.R;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.ui.data.setting.EsMessageData;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.EsIconTextView;


import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;



@Route(path = RoutingTable.ES_MESSAGE_ACTIVITY)
public class EsMessageActivity extends EsBaseActivity implements View.OnClickListener {

    EsMessageInfoAdapter mMessageInfoAdapter;

    RecyclerView rv_message;
    EsIconTextView itv_back;
    RelativeLayout rl_notice;

    List<MessageData> mMessageList = new ArrayList<>();
    String mUserNo;
    @Override
    protected void initData() {
        EsLoginAccountData.LoginAccount loginAccount;
        super.initData();

        loginAccount = initUserInfo();
        initMessageData(loginAccount);

        mMessageInfoAdapter = new EsMessageInfoAdapter(this, mMessageList);
    }

    private EsLoginAccountData.LoginAccount initUserInfo() {
        EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        if (loginAccount != null) {
            mUserNo = loginAccount.getUserNo();
        }
        return loginAccount;
    }

    private void initMessageData(EsLoginAccountData.LoginAccount loginAccount) {
        // 拿到所有账户的消息列表
        HashMap<String, List<MessageData>> allMessageLHashMap = EsMessageData.getInstance().getMsgData();
        if (mUserNo != null && loginAccount.getCompanyNo() != null && allMessageLHashMap != null) {
            // Key关键字通过EsMessageData中的关键字获取的。
            String key = loginAccount.getUserNo() + "#" + loginAccount.getCompanyNo() + "#" + loginAccount.getAddrTypeNo();
            if (allMessageLHashMap.containsKey(key)) {
                // 拿当前用户的消息列表显示
                mMessageList.addAll(allMessageLHashMap.get(key));
            }
            // 拿没有userNo的信息，即所有人公示信息显示
            if (allMessageLHashMap.containsKey("")) {
                mMessageList.addAll(allMessageLHashMap.get(""));
            }
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindOnClick();

        updateIsShowMessageListUI();
    }

    private void updateIsShowMessageListUI() {
        if(mMessageList != null && mMessageList.size() > 0) {
            initMessListView();
            rl_notice.setVisibility(View.GONE);
        }else {
            rv_message.setVisibility(View.GONE);
            rl_notice.setVisibility(View.VISIBLE);
        }
    }

    private void bindView() {
        rv_message = findViewById(R.id.es_activity_message_rv_message);
        itv_back = findViewById(R.id.es_activity_message_iv_back);
        rl_notice = findViewById(R.id.es_activity_message_rl_no_message_notice);
    }

    private void initMessListView() {
        rv_message.setVisibility(View.VISIBLE);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rv_message.setLayoutManager(layoutManager);
        rv_message.setAdapter(mMessageInfoAdapter);
    }

    private void bindOnClick() {
        itv_back.setOnClickListener(this);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_message;
    }

    @Override
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.es_activity_message_iv_back) {
            back();
        }
    }

    public void back(){
        finish();
    }

    @Override
    protected void onRestart(){
        super.onRestart();

        mMessageInfoAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart(){
        super.onStart();
//        EsMessageData.getInstance().addMessageListener(this);
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
//        EsMessageData.getInstance().removeMessageListener(this);
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    //    @Override
    public void receiveMessage(MessageData messageData) {
        if (isMessageInList(messageData)){
            mMessageList.add(messageData);
            mMessageInfoAdapter.notifyDataSetChanged();
            updateIsShowMessageListUI();
        }
    }

    public boolean isMessageInList(MessageData messageData){
        if(mMessageList != null && mMessageList.size() == 0)
            return true;

        if(messageData != null){
            long messageId = messageData.getMsgId();
            for (int i = 0; i < mMessageList.size(); i++){
                if (mMessageList.get(i).getMsgId() == messageId){
                    break;
                }else if (i == mMessageList.size() - 1){
                    return true;
                }
            }
        }
        return false;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage messageEvent) {
        MessageData messageData = (MessageData)messageEvent.getData();
        if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_RECEIVE_MESSAGE){
            if (isMessageInList(messageData)){
                mMessageList.add(messageData);
                mMessageInfoAdapter.notifyDataSetChanged();
                updateIsShowMessageListUI();
            }
        }
    }

}