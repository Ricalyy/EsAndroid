package com.esunny.ui.common;

import android.os.Bundle;

import com.esunny.ui.BasePresenter;
import com.esunny.ui.R;

public abstract class EsMVPActivity<T extends BasePresenter> extends EsBaseActivity {
    protected T mPresenter;
    protected abstract T createPresenter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mPresenter = createPresenter();
        if (mPresenter != null){
            mPresenter.attactView(this);
        }
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mPresenter != null){
            mPresenter.detachView();
        }
    }
}
