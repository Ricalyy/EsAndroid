package com.esunny.ui.common.setting.quote.kline.QuoteTitle;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.esunny.ui.R;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsCusSwitchButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import skin.support.content.res.SkinCompatResources;


public class EsQuoteTitleSettingActivity extends EsBaseActivity {

    private static final String TAG = "EsQuoteTitleSettingActivity";

    private EsBaseToolBar mToolbar;
    private EsCusSwitchButton mSwitchShowSingle;
    private TextView mTvTitleLeft, mTvTitleRight, mTvTitleFirst, mTvTitleSecond;
    private RecyclerView mRvTitleLeft, mRvTitleRight;
    private List<String> mSingleTotalLeftData = new ArrayList<>();
    private List<String> mSingleTotalRightData = new ArrayList<>();
    private List<String> mTitleSingleLeftData = new ArrayList<>();
    private List<String> mTitleSingleRightData = new ArrayList<>();
    private List<String> mDoubleTotalLeftData = new ArrayList<>();
    private List<String> mDoubleTotalRightData = new ArrayList<>();
    private List<String> mTitleDoubleLeftData = new ArrayList<>();
    private List<String> mTitleDoubleRightData = new ArrayList<>();
    private EsQuoteTitleLeftAdapter mTitleLeftAdapter;
    private EsQuoteTitleRightAdapter mTitleRightAdapter;
    private boolean mIsSingle;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_quote_title_setting;
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindViewValue();
        bindOnClick();
    }

    @Override
    protected void initData() {
        super.initData();
        prepareData();
        initAdapter();
    }

    private void initAdapter() {
        List<String> totalLeft = mIsSingle ? mSingleTotalLeftData : mDoubleTotalLeftData;
        List<String> totalRight = mIsSingle ? mSingleTotalRightData : mDoubleTotalRightData;
        List<String> listLeftData = mIsSingle ? mTitleSingleLeftData : mTitleDoubleLeftData;
        List<String> listRightData = mIsSingle ? mTitleSingleRightData : mTitleDoubleRightData;

        mTitleLeftAdapter = new EsQuoteTitleLeftAdapter(totalLeft, mIsSingle, EsQuoteTitleSettingActivity.this,
                listLeftData);
        mTitleRightAdapter = new EsQuoteTitleRightAdapter(totalRight, mIsSingle, EsQuoteTitleSettingActivity.this,
                listRightData);
    }

    private void prepareData() {
        mIsSingle = EsSPHelper.getIsShowSingle(this);
        String singleString = EsSPHelper.getQuoteSingleTitleConfig(this);
        String doubleString = EsSPHelper.getQuoteDoubleTitleConfig(this);

        if (singleString.isEmpty()) {
            initSingleTitleData();
        } else {
            String[] strings = singleString.split("=");
            mTitleSingleLeftData = new ArrayList<>(Arrays.asList(strings[0].split("\\+")));
            mTitleSingleRightData = new ArrayList<>(Arrays.asList(strings[1].split("\\+")));
        }

        if (doubleString.isEmpty()) {
            initDoubleTitleData();
        } else {
            String[] strings = doubleString.split("=");
            mTitleDoubleLeftData = new ArrayList<>(Arrays.asList(strings[0].split("\\+")));
            mTitleDoubleRightData = new ArrayList<>(Arrays.asList(strings[1].split("\\+")));
        }

        mSingleTotalLeftData = initSingleTitleListData();
        mSingleTotalRightData = initSingleTitleListData();

        mDoubleTotalLeftData = initDoubleTitleListData();
        mDoubleTotalRightData = initDoubleTitleListData();
    }

    private List<String> initDoubleTitleListData() {
        ArrayList<String> list = new ArrayList<>();
        list.add(EsUIConstant.QUOTE_RISE_AND_DIFF);
        list.add(EsUIConstant.QUOTE_MATCH_AND_POSITION);
        list.add(EsUIConstant.QUOTE_BUY_SELL_PRICE);
        list.add(EsUIConstant.QUOTE_BUY_SELL_QTY);
        list.add(EsUIConstant.QUOTE_HIGH_LOW_PRICE);
        list.add(EsUIConstant.QUOTE_MAX_MIN_PRICE);
        return list;
    }

    private List<String> initSingleTitleListData() {
        ArrayList<String> list = new ArrayList<>();
        list.add(EsUIConstant.QUOTE_RISE);
        list.add(EsUIConstant.QUOTE_RISE_DIFF);
        list.add(EsUIConstant.QUOTE_MATCH_QTY);
        list.add(EsUIConstant.QUOTE_POSITION_QTY);
        list.add(EsUIConstant.QUOTE_INCREASE_QTY);
        list.add(EsUIConstant.QUOTE_BUY_QTY);
        list.add(EsUIConstant.QUOTE_SELL_QTY);
        list.add(EsUIConstant.QUOTE_LAST_QTY);
        list.add(EsUIConstant.QUOTE_BUY_PRICE);
        list.add(EsUIConstant.QUOTE_SELL_PRICE);
        list.add(EsUIConstant.QUOTE_AVERAGE_PRICE);
        return list;
    }

    // 这是默认显示的
    private void initSingleTitleData() {
        // 左边的
        mTitleSingleLeftData.add(EsUIConstant.QUOTE_RISE);
        mTitleSingleLeftData.add(EsUIConstant.QUOTE_RISE_DIFF);
        // 右边的
        mTitleSingleRightData.add(EsUIConstant.QUOTE_MATCH_QTY);
        mTitleSingleRightData.add(EsUIConstant.QUOTE_POSITION_QTY);
    }

    // 这是默认显示的
    private void initDoubleTitleData() {
        // 左边的
        mTitleDoubleLeftData.add(EsUIConstant.QUOTE_RISE_AND_DIFF);
        mTitleDoubleLeftData.add(EsUIConstant.QUOTE_BUY_SELL_PRICE);
        // 右边的
        mTitleDoubleRightData.add(EsUIConstant.QUOTE_MATCH_AND_POSITION);
        mTitleDoubleRightData.add(EsUIConstant.QUOTE_BUY_SELL_QTY);
    }

    private void bindView() {
        mToolbar = findViewById(R.id.es_activity_price_calculate_toolbar);
        mTvTitleFirst = findViewById(R.id.es_activity_quote_title_setting_tv_contract_name);
        mTvTitleSecond = findViewById(R.id.es_activity_quote_title_setting_tv_price);
        mTvTitleLeft = findViewById(R.id.es_activity_quote_title_setting_tv_title_one);
        mTvTitleRight = findViewById(R.id.es_activity_quote_title_setting_tv_title_two);
        mRvTitleLeft = findViewById(R.id.es_activity_quote_title_setting_title_one_recycler_view);
        mRvTitleRight = findViewById(R.id.es_activity_quote_title_setting_title_two_recycler_view);

        mSwitchShowSingle = findViewById(R.id.es_activity_quote_title_setting_switch_is_show_single);
        mSwitchShowSingle.setChecked(EsSPHelper.getIsShowSingle(this));
        mSwitchShowSingle.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mSwitchShowSingle.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));
    }

    private void bindViewValue() {
        mToolbar.setSimpleBack(getString(R.string.es_activity_chart_setting_single_double_title_setting));

        changeTvName();

        LinearLayoutManager leftLayoutManager = new LinearLayoutManager(this);
        mRvTitleLeft.setLayoutManager(leftLayoutManager);
        mRvTitleLeft.setAdapter(mTitleLeftAdapter);

        LinearLayoutManager rightLayoutManager = new LinearLayoutManager(this);
        mRvTitleRight.setLayoutManager(rightLayoutManager);
        mRvTitleRight.setAdapter(mTitleRightAdapter);

    }

    private void changeTvName() {
        if (mIsSingle) {
            mTvTitleFirst.setText(R.string.es_quote_title_activity_single_contract);
            mTvTitleSecond.setText(R.string.es_quote_title_activity_single_last);
            mTvTitleLeft.setText(R.string.es_quote_title_activity_single_third);
            mTvTitleRight.setText(R.string.es_quote_title_activity_single_fourth);
        } else {
            mTvTitleFirst.setText(R.string.es_quote_title_activity_double_contract);
            mTvTitleSecond.setText(R.string.es_quote_title_activity_double_last);
            mTvTitleLeft.setText(R.string.es_quote_title_activity_double_third);
            mTvTitleRight.setText(R.string.es_quote_title_activity_double_fourth);
        }
    }

    private void bindOnClick() {
        mSwitchShowSingle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                EsSPHelper.setIsShowSingle(getBaseContext(), isChecked);
                dealChangeSingle(isChecked);
            }
        });
    }

    private void dealChangeSingle(boolean isChecked) {
        mIsSingle = isChecked;
        changeTvName();
        initSingleTitleListData();
        initDoubleTitleListData();
        List<String> totalLeft = mIsSingle ? mSingleTotalLeftData : mDoubleTotalLeftData;
        List<String> totalRight = mIsSingle ? mSingleTotalRightData : mDoubleTotalRightData;
        List<String> listLeftData = mIsSingle ? mTitleSingleLeftData : mTitleDoubleLeftData;
        List<String> listRightData = mIsSingle ? mTitleSingleRightData : mTitleDoubleRightData;

        mTitleLeftAdapter.setSingle(mIsSingle);
        mTitleLeftAdapter.setListData(totalLeft, listLeftData);
        mTitleLeftAdapter.notifyDataSetChanged();

        mTitleRightAdapter.setSingle(mIsSingle);
        mTitleRightAdapter.setListData(totalRight, listRightData);
        mTitleRightAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveSingleData();
        saveDoubleData();
    }

    private void saveDoubleData() {
        StringBuilder sbDouble = new StringBuilder();
        List<String> list = initDoubleTitleListData();
        list.retainAll(mTitleDoubleLeftData);
        int sizeDoubleLeft = list.size();
        for (int i = 0; i < sizeDoubleLeft; i++) {
            sbDouble.append(list.get(i));
            if (i < sizeDoubleLeft - 1) {
                sbDouble.append("+");
            }
        }

        sbDouble.append("=");

        list = initDoubleTitleListData();
        list.retainAll(mTitleDoubleRightData);
        int sizeDoubleRight = list.size();
        for (int i = 0; i < sizeDoubleRight; i++) {
            sbDouble.append(list.get(i));
            if (i < sizeDoubleRight - 1) {
                sbDouble.append("+");
            }
        }
        EsSPHelper.setQuoteDoubleTitleConfig(this, sbDouble.toString());
    }

    private void saveSingleData() {
        StringBuilder sbSingle = new StringBuilder();
        List<String> list = initSingleTitleListData();
        list.retainAll(mTitleSingleLeftData);
        int sizeSingleLeft = list.size();
        for (int i = 0; i < sizeSingleLeft; i++) {
            sbSingle.append(list.get(i));
            if (i < sizeSingleLeft - 1) {
                sbSingle.append("+");
            }
        }
        sbSingle.append("=");
        list = initSingleTitleListData();
        list.retainAll(mTitleSingleRightData);
        int sizeSingleRight = list.size();
        for (int i = 0; i < sizeSingleRight; i++) {
            sbSingle.append(list.get(i));
            if (i < sizeSingleRight - 1) {
                sbSingle.append("+");
            }
        }
        EsSPHelper.setQuoteSingleTitleConfig(this, sbSingle.toString());
    }
}
