package com.esunny.ui.common.setting.stopLossOpen;

import android.content.Context;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.api.event.QuoteEvent;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.api.util.EstarTransformation;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.QuoteBetData;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.OpenOrder;
import com.esunny.data.bean.OrderData;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.dialog.EsCustomDialog;
import com.esunny.ui.dialog.EsCustomTipsDialog;
import com.esunny.ui.dialog.EsMultiSelectKeyboardDialog;
import com.esunny.ui.dialog.EsStopLossOpenDialog;
import com.esunny.ui.dialog.EsTradeLotsKeyboard;
import com.esunny.ui.trade.view.EsTradeContractEditSets;
import com.esunny.ui.trade.view.EsTradeMoneyInfoBar;
import com.esunny.ui.trade.view.EsTradePriceKeyboard;
import com.esunny.ui.trade.view.EsTradePriceKeyboardView;
import com.esunny.ui.trade.view.EsTradeSimplePanel;
import com.esunny.ui.util.EsCalculateUtil;
import com.esunny.ui.util.EsCommonUtil;
import com.esunny.ui.util.EsInsertOrderHelper;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.EstarFieldTransformation;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsIconTextView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;

@Route(path = RoutingTable.ES_STOP_LOSS_OPEN_ACTIVITY)
public class EsStopLossOpenActivity extends EsBaseActivity implements EsMultiSelectKeyboardDialog.OnEsMultiSelectKeyboardDialogListener,
        EsTradePriceKeyboardView.TradePriceKeyboardListener, View.OnClickListener, EsStopLossOpenDialog.EsDialogClickListener, EsStopLossOpenAdapter.OnClickItem {

    private EsBaseToolBar mToolBar;
    private EsTradeMoneyInfoBar mMoneyInfoBar;
    private EsTradeSimplePanel mSimplePanel;
    private EsTradeContractEditSets mContractEdit;
    private EditText mEditTextLots;
    private EditText mEditTextPrice;
    private TextView mInsertTV;
    private TextView mBuyTv;
    private TextView mSellTv;
    private EsIconTextView mContractClickIc;

    @BindView(R2.id.es_activity_stop_open_recycler)
    RecyclerView mRv;

    // 自选合约选择框
    private EsMultiSelectKeyboardDialog mKeyboardContract;
    // 手数选择框
    private EsTradeLotsKeyboard mKeyboardLots;
    // 价格选择框
    private EsTradePriceKeyboard mKeyboardPrice;
    private final static String KEY_SEARCH_SOURCE = "EsStopLossOpen";
    private Contract mContract;
    private EsStopLossOpenDialog mStopLossDialog;

    // 已选择的条件单
    private EsStopLossOpenAdapter mAdapter;
    // 是否T+1
    private boolean mIsAddOne = false;
    // 普通订单长期或者当日有效
    char mValidType = EsDataConstant.S_VALIDTYPE_GFD;
    // 普通订单买卖价。
    double mBuyPrice, mSellPrice;
    QuoteBetData mQuoteBetData;
    private double mJudgePrice;
    private InsertOrder mLossInsertOrder = null;
    private InsertOrder mProfitInsertOrder = null;
    private InsertOrder mBreakInsertEvenOrder = null;
    private String mSource;
    private String mOrderNo;
    private OrderData mMainOrderData = new OrderData();
    private List<String> mOrderPriceStr = new ArrayList<>();
    private List<OpenOrder> mOpenOrderData = new ArrayList<>();
    private List<OrderData> mOrderDatas = new ArrayList<>();
    private boolean mIsFromChange = false;
    private boolean mIsFromKLine = false;
    private long mOrderQty;
    private double mOrderPrice;

    private String FromOfSetting = "settingFragment"; // 表示是从设置进入的开仓止损进行下单
    private String FromOfParOrder = "parOrderAdapter"; // 表示是从改单进入开仓止损进行改单
    private String FromOfKLine = "klineActivity"; // 表示是从K线界面进入开仓止损进行下单

    private final String TAG = getClass().getSimpleName();

    @Override
    protected int getContentView() {
        return R.layout.es_activity_stop_loss_open;
    }

    @Override
    protected void initData() {
        super.initData();

        mSource = getIntent().getStringExtra("source");
        mIsFromChange = FromOfParOrder.equals(mSource);
        mIsFromKLine = FromOfKLine.equals(mSource);
        if (mIsFromChange) {
            mOrderNo = getIntent().getStringExtra("orderNo");
            EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
            List<OrderData>  parorderDataList = EsDataApi.getPutOrderData(account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo(), '\0', "", -1, true);
            if (parorderDataList != null) {
                for (OrderData data : parorderDataList) {
                    if (data != null && data.getOrderNo().equals(mOrderNo)) {
                        mMainOrderData = data;
                        break;
                    }
                }
            }
            mOrderDatas = EsDataApi.getStopLossOrderByOrder(account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo(), mOrderNo);
            orderDataToOpenData(mOrderDatas);
            prepareOrderPriceStr(mOrderDatas);
        } else if (mIsFromKLine){
            String contractNo = getIntent().getStringExtra("orderNo");
            Contract contract = EsDataApi.getTradeContract(contractNo);
            if (contract != null) {
                mContract = contract;
            }
        }

        mAdapter = new EsStopLossOpenAdapter(getApplicationContext(), mIsFromChange, mMainOrderData);
        mAdapter.setDatas(mOpenOrderData);
        mAdapter.setOrderPriceStr(mOrderPriceStr);
        mAdapter.setOnItemClick(this);
        mQuoteBetData = new QuoteBetData();
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        initView();
        initViewValue();
        bindOnClick();
    }

    private void initView() {
        mToolBar = findViewById(R.id.es_activity_stop_open_toolbar);
        mMoneyInfoBar = findViewById(R.id.es_activity_stop_open_money_info);
        mSimplePanel = findViewById(R.id.es_activity_stop_open_panel);
        mContractEdit = findViewById(R.id.es_activity_stop_open_edits);
        mEditTextLots = findViewById(R.id.et_trade_lots);
        mEditTextPrice = findViewById(R.id.et_trade_price);
        mInsertTV = findViewById(R.id.es_activity_stop_open_insert);
        mBuyTv = findViewById(R.id.es_activity_stop_open_buy);
        mSellTv = findViewById(R.id.es_activity_stop_open_sell);
        mContractClickIc = findViewById(R.id.et_trade_contract_ic);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        mRv.setAdapter(mAdapter);

        mRv.setLayoutManager(layoutManager);

        mKeyboardLots = new EsTradeLotsKeyboard(EsStopLossOpenActivity.this, mEditTextLots);
        mKeyboardLots.setOutsideTouchable(true);

        mKeyboardPrice = new EsTradePriceKeyboard(EsStopLossOpenActivity.this, mEditTextPrice, EsDataConstant.S_VALIDTYPE_GFD);
        mKeyboardPrice.setIsPriceLinkage(EsSPHelperProxy.getIsLinkage(this));
        mKeyboardPrice.setOutsideTouchable(true);
        mKeyboardPrice.setListener(this);
    }

    private void initViewValue() {
        mToolBar.setTitle(getString(R.string.es_setting_fragment_stop_open));
        mToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
        mMoneyInfoBar.hideMoneyInfoDots();
        mContractEdit.refreshPlusOneLayout(false);
        refreshFund();

        mContractEdit.setLots(getDefaultQty(this, mContract));
        if (mIsFromChange) {
            if (mOpenOrderData.size() == 3) {
                mInsertTV.setVisibility(View.GONE);
            }
            mContractClickIc.setVisibility(View.GONE);
            mBuyTv.setText(R.string.es_stop_loss_open_activity_confirm_change_order);
            mSellTv.setText(R.string.es_stop_loss_open_activity_confirm_cancel_order);
            Contract contract = EsDataApi.getTradeContract(mMainOrderData.getContractNo());
            if (contract != null) {
                setContract(contract);
            }
            if (mMainOrderData.getOrderQty() != null) {
                mOrderQty = mMainOrderData.getOrderQty().longValue();
            }

            mOrderPrice = mMainOrderData.getOrderPrice();
            mContractEdit.setLots(mOrderQty);
            mEditTextPrice.setText(EsDataApi.formatPrice(contract.getCommodity(), mOrderPrice));
        } else if (mIsFromKLine){
            setContract(mContract);
        }
    }

    private void orderDataToOpenData(List<OrderData> orderData) {
        for (OrderData data : orderData) {
            OpenOrder openOrder = new OpenOrder();

            // 转换子单类型
            char type = data.getStrategyType();
            if (type == EsDataConstant.S_ST_STOPLOSS) {
                type = EsDataConstant.S_ST_OPEN_STOPLOSS;
            } else if (type == EsDataConstant.S_ST_STOPPROFIT) {
                type = EsDataConstant.S_ST_OPEN_STOPPROFIT;
            } else if (type == EsDataConstant.S_ST_FLOATSTOPLOSS) {
                type = EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT;
            } else if (type == EsDataConstant.S_ST_BREAKEVEN) {
                type = EsDataConstant.S_ST_OPEN_BREAKEVEN;
            }

            data.setStrategyType(type);
            openOrder.setStrategyType(type);
            openOrder.setOffset(data.getOffset());
            openOrder.setOrderPriceType(data.getOrderPriceType());
            openOrder.setOrderPriceOver(data.getOrderPriceOver());
            openOrder.setOrderType(data.getOrderType());
            openOrder.setOrderPrice(data.getOrderPrice());
            openOrder.setValidType(data.getValidType());
            openOrder.setStopPrice(data.getStopPrice());
            openOrder.setStopPriceType(data.getStopPriceType());
            openOrder.setStatus(EsDataConstant.OPEN_DATA_FROM_ORDER_DATA);

            if (data.getStrategyType() == EsDataConstant.S_ST_OPEN_BREAKEVEN) {
                openOrder.setBreakPriceDiff(Math.abs(mMainOrderData.getOrderPrice() - data.getStopPrice()));
            }

            mOpenOrderData.add(openOrder);
        }
    }

    private void prepareOrderPriceStr(List<OrderData> orderDatas) {
        for (OrderData data : orderDatas) {
            String orderPrice;
            Contract contract = EsDataApi.getQuoteContract(data.getContractNo());
            if (data.getOrderPriceType() == EsDataConstant.S_PT_ABS) {
                if (contract != null) {
                    orderPrice = EsDataApi.formatPrice(contract.getCommodity(),data.getOrderPrice());
                } else {
                    orderPrice = EsCommonUtil.formatDouble(data.getOrderPrice());
                }
            } else {
                orderPrice = EstarTransformation.apiPriceTypeToStr(this, data.getOrderPriceType());
                if (data.getOrderPriceOver() != 0 && contract != null) {
                    if (data.getOrderPriceOver() < 0) {
                        orderPrice = orderPrice + (int)(data.getOrderPriceOver() / contract.getCommodity().getTickPrice()) +
                                this.getString(R.string.es_strategy_condition_list_tick);
                    } else {
                        orderPrice = orderPrice + "+" + (int)(data.getOrderPriceOver() / contract.getCommodity().getTickPrice()) +
                                this.getString(R.string.es_strategy_condition_list_tick);
                    }
                }
            }
            mOrderPriceStr.add(orderPrice);
        }
    }

    private long getDefaultQty(Context context, Contract contract) {
        long qty = 0L;
        if (contract == null) {
            return qty;
        }
        //默认手数
        Contract realContract = EsDataApi.getTradeContract(contract.getContractNo());
        if (realContract != null) {
            if (!realContract.isStock()) {
                // 非股票合约
                String commodityNo = realContract.getCommodity().getCommodityNo();
                if (commodityNo.contains("|Z|")) {
                    commodityNo = commodityNo.replace("|Z|", "|F|");
                }
                qty = EsSPHelper.getCommodityNumByNo(context, commodityNo);
            } else {
                qty = 1;
            }
        }
        return qty;
    }

    private void bindOnClick() {
        mToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_left_first) {
                    finish();
                }
            }
        });
        initContractEdits();
        mInsertTV.setOnClickListener(this);
        mBuyTv.setOnClickListener(this);
        mSellTv.setOnClickListener(this);
    }

    private void initContractEdits() {
        mContractEdit.setCallback(new EsTradeContractEditSets.ITradeContractEditSetsDataListener() {
            @Override
            public void chooseContract() {
                if (!mIsFromChange && !mIsFromKLine) {
                    if (mKeyboardLots.isShowing()) {
                        mKeyboardLots.dismiss();
                    }
                    if (mKeyboardPrice.isShowing()) {
                        mKeyboardPrice.dismiss();
                    }

                    mKeyboardContract = new EsMultiSelectKeyboardDialog(EsStopLossOpenActivity.this,
                            EsFavoriteListData.getInstance().getFavoriteContractNameList());
                    mKeyboardContract.setListener(EsStopLossOpenActivity.this);
                    mKeyboardContract.show();
                }

            }

            @Override
            public void chooseQty() {
                if (mKeyboardPrice.isShowing()) {
                    mKeyboardPrice.dismiss();
                }
                mKeyboardLots.showAtLocation(mContractEdit.getRootView(), Gravity.BOTTOM, 0, 0);
                mKeyboardLots.setReInput(true);
            }

            @Override
            public void choosePrice() {
                if (mKeyboardLots.isShowing()) {
                    mKeyboardLots.dismiss();
                }
                if (mKeyboardContract != null && mKeyboardContract.isShowing()) {
                    mKeyboardContract.dismiss();
                }

                if (mContract != null) {
                    mKeyboardPrice.EnableMarketPrice(EsDataApi.isMarketPriceAvailable(mContract));
                    mKeyboardPrice.EnableDecimalPoint(!(mContract.getCommodity().getPriceDeno() > 1));
                }

                mKeyboardPrice.showAtLocation(mContractEdit.getRootView(), Gravity.BOTTOM, 0, 0);
                mKeyboardPrice.setReInput(true);
            }

            @Override
            public void setTradeBoardAddOne(boolean isAddOne) {
                mIsAddOne = isAddOne;
            }
        });

    }

    @Override
    public void OnSelect(int index, EsMultiSelectKeyboardDialog dialog) {
        if (dialog == mKeyboardContract) {
            if (index == -1) {
                EsUIApi.startSearchActivity(KEY_SEARCH_SOURCE);
            } else {
                if (index < EsFavoriteListData.getInstance().getFavoriteContractArrayList().size()) {
                    Contract contract = EsFavoriteListData.getInstance().getFavoriteContractArrayList().get(index);
                    setContract(contract);
                    mContractEdit.setLots(getDefaultQty(getApplicationContext(), contract));
                }
            }
        }
    }

    @Override
    public void OnDismiss(EsMultiSelectKeyboardDialog dialog) {

    }

    private void setContract(Contract contract) {
        if (contract != null) {
            Contract realContract = EsDataApi.getTradeContract(contract.getContractNo());
            if (mContract != null) {
                if (!mContract.getContractNo().equals(realContract.getContractNo())) {
                    EsDataApi.unSubQuote(mContract.getContractNo());
                    EsDataApi.subQuote(realContract.getContractNo());
                }
            } else {
                EsDataApi.subQuote(realContract.getContractNo());
            }
            mContract = realContract;
            mContractEdit.setContractOnEdit(realContract.getContractName());
            refreshQuoteData();

            String specialPrice = EstarFieldTransformation.priceTypeToStr(this, EsSPHelperProxy.getDefaultPriceType(this));
            if (EsSPHelperProxy.getDefaultPriceType(this) == EsSPHelperProxy.S_PT_MARKET && !EsDataApi.isMarketPriceAvailable(realContract)) {
                if (EsSPHelper.getMarketPriceSetting(this)) {
                    ToastHelper.show(this, R.string.es_trade_notify_message_trade_contractset_market_price_available);
                    mKeyboardPrice.setSpecialPrice(getString(R.string.es_price_keyboard_counter));
                    specialPrice = EstarFieldTransformation.priceTypeToStr(this, EsSPHelperProxy.S_PT_MATCH);
                }
            }
            // 合约更新后，价格键盘的特殊价也需要更新
            mKeyboardPrice.setSpecialPrice(specialPrice);
        }
    }

    private void refreshQuoteData() {
        mQuoteBetData.setContractData(mContract);
        refreshSimplePanel();
        if (EsSPHelperProxy.getDefaultPriceType(this) == mKeyboardPrice.getSpecialPriceId()) {
            refreshSpecialPrice(mKeyboardPrice.getView());
        }
    }

    private void refreshSimplePanel() {
        double lastPrice = mQuoteBetData.getLastPrice();
        double buyPrice = mQuoteBetData.getBuyPrice();
        double sellPrice = mQuoteBetData.getSellPrice();
        double settlePrice = mQuoteBetData.getPreSettlePrice();
        BigInteger buyQty = mQuoteBetData.getBuyQty();
        BigInteger sellQty = mQuoteBetData.getSellQty();
        BigInteger lastQty = mQuoteBetData.getLastQty();
        mSimplePanel.setPriceDataFromStopLoss(mContract.getCommodity(), lastPrice, buyPrice, sellPrice, settlePrice);
        mSimplePanel.setQtyDataFromStopLoss(buyQty, sellQty, lastQty);
        mSimplePanel.setDataOnView();
    }

    private void refreshFundData(String userNo, String companyNo, String addrNo) {
        if (EsLoginAccountData.getInstance().isCurrentAccount(companyNo, userNo, addrNo)) {
            refreshFund();
        }
    }

    private void refreshFund() {
        EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        if (loginAccount != null) {
            mMoneyInfoBar.refreshFundInfo(loginAccount);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == mInsertTV.getId()) {
            insertStrategyOrder();
        } else if (v.getId() == mBuyTv.getId()) {
            clickBuyButton();
        } else if (v.getId() == mSellTv.getId()) {
            clickSellButton();
        }
    }

    private void clickBuyButton() {
        if (mIsFromChange) {
            insertChangeOrder();
        } else {
            insertOrder(EsDataConstant.S_DIRECT_BUY, mBuyPrice);
        }
    }

    private void clickSellButton() {
        if (mIsFromChange) {
            finish();
        } else {
            insertOrder(EsDataConstant.S_DIRECT_SELL, mSellPrice);
        }
    }

    private void insertChangeOrder() {

        if (mMainOrderData == null) {
            return;
        }

        long currentQty = Long.parseLong(mEditTextLots.getText().toString());

        String price;
        try {
            price = String.valueOf(Double.parseDouble(EsDataApi.getDoubleStrFromFractionStr(mEditTextPrice.getText().toString(), mContract.getCommodity().getPriceDeno())));
        } catch (NumberFormatException e) {
            boolean isBuy = (mMainOrderData.getDirect() == EsDataConstant.S_DIRECT_BUY);

            QuoteBetData data = new QuoteBetData(mContract);
            long commodityPoint = EsSPHelper.getCommodityPoint(this, mContract);
            price = EsCalculateUtil.getPriceBySpecialId(mKeyboardPrice.getSpecialPriceId(), mKeyboardPrice.getExceedPriceId(), data, commodityPoint, isBuy);
        }

        if (mKeyboardPrice.getSpecialPriceId() == EsSPHelperProxy.S_PT_MARKET && EsDataApi.isMarketPriceAvailable(mContract)) {
            mMainOrderData.setOrderType(EsDataConstant.S_ORDERTYPE_MARKET);
            price = "0";
        }

        double currentPrice = EsDataApi.formatOrderPrice(mContract, price, mMainOrderData.getDirect());

        if (currentQty == 0 ||  currentPrice == 0) {
            ToastHelper.show(this, R.string.es_view_trade_threekey_warning_fillpriceqty);
            return;
        }
        if (currentQty == mOrderQty && currentPrice == mOrderPrice) {
            ToastHelper.show(this, R.string.es_stop_loss_open_activity_change_order_check);
            return;
        }

        prepareStrategyInsertOrder(mMainOrderData.getDirect(), currentPrice, new BigInteger(String.valueOf(currentQty)));

        changeOrder(currentQty, currentPrice);
    }

    private void changeOrder(final long currentQty, final double currentPrice) {
        String exchangeNo = mContract.getCommodity().getExchange().getExchangeNo();
        final BigInteger maxOrderQty = EsInsertOrderHelper.getMaxOrderCountOfExchange(exchangeNo, mMainOrderData.getOrderType());

        String orderInsertMessages = String.format(Locale.getDefault(), "%s %s %d%s%s,%s%s",
                EstarTransformation.Direct2BuySellString(this, mMainOrderData.getDirect()), mContract.getContractName(), currentQty,
                this.getString(R.string.es_adapter_trade_parorderlist_cancelorder_message_lots),
                this.getString(R.string.es_baseapi_trademethods_offset_open), this.getString(R.string.es_adapter_trade_parorderlist_cancelorder_message_price),
                EsDataApi.formatPrice(mContract.getCommodity(), currentPrice));

        String lossOrderMessage = "";
        if (mLossInsertOrder != null) {
            lossOrderMessage = "\n" + getStrategyMessage(mLossInsertOrder);
        }
        String profitOrderMessage = "";
        if (mProfitInsertOrder != null) {
            profitOrderMessage =  "\n" + getStrategyMessage(mProfitInsertOrder);
        }
        String brakeOrderMessage = "";
        if (mBreakInsertEvenOrder != null) {
            brakeOrderMessage =  "\n" + getStrategyMessage(mBreakInsertEvenOrder);
        }

        String insertMessages = String.format(Locale.getDefault(), "%s; %s %s %s", orderInsertMessages, lossOrderMessage, profitOrderMessage, brakeOrderMessage);

        final EsCustomDialog dialog = EsCustomDialog.create(this);
        dialog.setTitle(this.getString(R.string.es_trade_option_dialog_changeorder))
                .setContent(insertMessages)
                .setCheckbox(this.getString(R.string.es_base_view_do_not_prompt))
                .setShowDialog(EsSPHelperProxy.isShowChangeOrderPrompt(this))
                .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                    @Override
                    public void onConfirm() {
                        EsSPHelperProxy.setIsShowChangeOrderPrompt(EsStopLossOpenActivity.this, !dialog.isSelectCheckBox());
                        int ret = EsDataApi.modifyStopLossOrder(mMainOrderData, currentPrice, new BigInteger(String.valueOf(currentQty)), maxOrderQty, mLossInsertOrder
                                , mProfitInsertOrder, mBreakInsertEvenOrder);
                        Log.d(TAG, "modifyStopLossOrder = " + ret);
                        dialog.dismiss();
                        finish();
                    }

                    @Override
                    public void onCancel() {
                        dialog.dismiss();
                    }
                }).show();
    }

    private void insertOrder(final char direct, final double price) {
        if (checkCondition() && checkInput()) {
            final InsertOrder ordinaryOrder = initOrder(String.valueOf(price), direct);

            if (ordinaryOrder == null) {
                return;
            }

            QuoteBetData betData = new QuoteBetData(ordinaryOrder.getContract());
            if ((!betData.isPriceValid(price) && !isPriceEquals0(price))
                    || (isPriceEquals0(price) && ordinaryOrder.getOrderType() != EsDataConstant.S_ORDERTYPE_MARKET)) {
                EsCustomDialog dialog = EsCustomDialog.create(this);
                dialog.setTitle(this.getString(R.string.es_base_view_tips))
                        .setContent(this.getString(R.string.es_baseapi_trademethods_price_valid))
                        .setConfirm(this.getString(R.string.es_custom_message_dialog_confirm))
                        .setCancel(this.getString(R.string.es_base_view_cancel))
                        .setCancelable(false)
                        .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                            @Override
                            public void onConfirm() {
                                BigInteger orderQty = BigInteger.valueOf(Long.valueOf(mEditTextLots.getText().toString()));
                                prepareStrategyInsertOrder(direct, price, orderQty);
                                insertOrderWithMessages(ordinaryOrder);
                            }

                            @Override
                            public void onCancel() {
                            }
                        }).show();
            } else {
                BigInteger orderQty = BigInteger.valueOf(Long.valueOf(mEditTextLots.getText().toString()));
                prepareStrategyInsertOrder(direct, price, orderQty);
                insertOrderWithMessages(ordinaryOrder);
            }
        }
    }

    private void insertOrderWithMessages(final InsertOrder ordinaryOrder) {
        String ordinaryOrderMessage = String.format(Locale.getDefault(), "%s %s %d%s%s,%s%s",
                EstarTransformation.Direct2BuySellString(this, ordinaryOrder.getDirect()), mContract.getContractName(), ordinaryOrder.getOrderQty().longValue(),
                this.getString(R.string.es_adapter_trade_parorderlist_cancelorder_message_lots),
                this.getString(R.string.es_baseapi_trademethods_offset_open), this.getString(R.string.es_adapter_trade_parorderlist_cancelorder_message_price),
                EsDataApi.formatPrice(ordinaryOrder.getContract().getCommodity(), EsDataApi.formatOrderPrice(mContract, ordinaryOrder.getOrderPrice(), ordinaryOrder.getDirect())));

        String lossOrderMessage = "";
        if (mLossInsertOrder != null) {
            lossOrderMessage =  "\n" + getStrategyMessage(mLossInsertOrder);
        }
        String profitOrderMessage = "";
        if (mProfitInsertOrder != null) {
            profitOrderMessage =  "\n" + getStrategyMessage(mProfitInsertOrder);
        }
        String brakeOrderMessage = "";
        if (mBreakInsertEvenOrder != null) {
            brakeOrderMessage =  "\n" + getStrategyMessage(mBreakInsertEvenOrder);
        }

        String insertMessages = String.format(Locale.getDefault(), "%s; %s %s %s", ordinaryOrderMessage, lossOrderMessage, profitOrderMessage, brakeOrderMessage);

        final EsCustomDialog dialog = EsCustomDialog.create(EsStopLossOpenActivity.this);
        dialog.setTitle(EsStopLossOpenActivity.this.getString(R.string.es_setting_fragment_stop_open))
                .setContent(insertMessages)
                .setCheckbox(EsStopLossOpenActivity.this.getString(R.string.es_base_view_do_not_prompt))
                .setShowDialog(EsSPHelperProxy.isShowChangeOrderPrompt(this))
                .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                    @Override
                    public void onConfirm() {
                        EsSPHelperProxy.setIsShowChangeOrderPrompt(EsStopLossOpenActivity.this, !dialog.isSelectCheckBox());
                        int sessionId = EsDataApi.openWithStopLossOrder(ordinaryOrder, mLossInsertOrder, mProfitInsertOrder, mBreakInsertEvenOrder);
                        EsLog.d(TAG, "sessionid : " + sessionId);
                    }

                    @Override
                    public void onCancel() {

                    }
                }).show();
    }

    private boolean isPriceEquals0(double price) {
        return Math.abs(price) < Math.pow(10, -10);
    }

    private String getStrategyMessage(InsertOrder order) {
        String orderMessage;
        String directStr = EstarTransformation.Direct2BuySellString(this, order.getDirect());
        String conditionStr = EstarTransformation.StrategyType2String(this, order.getStrategyType());
        String stopPriceStr = EstarTransformation.stopPriceType2Str(this, order.getStopPriceType());

        stopPriceStr += ":" + EsDataApi.formatPrice(mContract.getCommodity(), order.getStopPrice());
        String OrderPriceStr;
        if (order.getOrderPriceType() == EsDataConstant.S_PT_ABS) {
            OrderPriceStr = EsDataApi.formatPrice(mContract.getCommodity(), Double.parseDouble(order.getOrderPrice()));
        } else {
            OrderPriceStr = EstarTransformation.apiPriceTypeToStr(this, order.getOrderPriceType());
            if (order.getOrderPriceOver() != 0) {
                if (order.getOrderPriceOver() < 0) {
                    OrderPriceStr = OrderPriceStr + (int)(order.getOrderPriceOver() / mContract.getCommodity().getTickPrice())+
                            this.getString(R.string.es_strategy_condition_list_tick);
                } else {
                    OrderPriceStr = OrderPriceStr + "+" + (int)(order.getOrderPriceOver() / mContract.getCommodity().getTickPrice())+
                            this.getString(R.string.es_strategy_condition_list_tick);
                }
            }
        }

        orderMessage = String.format(Locale.getDefault(), "%s,%s,%s%s,%s%s;", conditionStr, stopPriceStr, directStr,
                this.getString(R.string.es_baseapi_trademethods_offset_cover), getString(R.string.es_position_stop_loss_order_price), OrderPriceStr);
        return orderMessage;
    }

    private void prepareStrategyInsertOrder(char direct, double price, BigInteger orderQty) {
        char strategyDirect = direct == EsDataConstant.S_DIRECT_BUY ? EsDataConstant.S_DIRECT_SELL : EsDataConstant.S_DIRECT_BUY;

        mLossInsertOrder = null;
        mProfitInsertOrder = null;
        mBreakInsertEvenOrder = null;

        for (int i = 0; i < mOpenOrderData.size(); i++) {
            OpenOrder openOrder = mOpenOrderData.get(i);
            if (openOrder.getStrategyType() == EsDataConstant.S_ST_OPEN_STOPLOSS) {
                mLossInsertOrder = openOrderToInsertOrder(openOrder, strategyDirect, orderQty);
            } else if (openOrder.getStrategyType() == EsDataConstant.S_ST_OPEN_STOPPROFIT) {
                mProfitInsertOrder = openOrderToInsertOrder(openOrder, strategyDirect, orderQty);
            } else if (openOrder.getStrategyType() == EsDataConstant.S_ST_OPEN_BREAKEVEN) {
                mBreakInsertEvenOrder = openOrderToInsertOrder(openOrder, strategyDirect, orderQty);

                double calculatePrice = mBreakInsertEvenOrder.getStopPrice();
                if (mIsFromChange) {
                    calculatePrice = openOrder.getBreakPriceDiff();
                }

                if (direct == EsDataConstant.S_DIRECT_BUY) {
                    price = price + calculatePrice;
                } else {
                    price = price - calculatePrice;
                }

                double formatPrice = EsDataApi.formatOrderPrice(mContract, String.valueOf(price), strategyDirect);
                mBreakInsertEvenOrder.setStopPrice(formatPrice);

            } else if (openOrder.getStrategyType() == EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT) {
                mLossInsertOrder = openOrderToInsertOrder(openOrder, strategyDirect, orderQty);
                // 浮动止损需要添加触发价setTriggerPrice
                int flag = strategyDirect == EsDataConstant.S_DIRECT_BUY ? 1 : -1;
                mLossInsertOrder.setTriggerPrice(mLossInsertOrder.getStopPrice() * flag);
                mLossInsertOrder.setStopPriceType(EsDataConstant.S_SPT_DIFF);
            }
        }
    }


    private boolean checkInput() {
        if (mOpenOrderData.size() < 1) {
            ToastHelper.show(this, R.string.es_stop_loss_open_activity_judge_no_order);
            return false;
        }

        if (mQuoteBetData.isValid()) { // 行情有效才做这些判断
            BigDecimal b = new BigDecimal(mQuoteBetData.getLastPrice());
            BigDecimal c = new BigDecimal(mQuoteBetData.getPreClosingPrice());
            if ((b.setScale(6, BigDecimal.ROUND_HALF_UP).doubleValue()) == 0) {
                if (c.setScale(6, BigDecimal.ROUND_HALF_UP).doubleValue() == 0) {
                    EsCustomTipsDialog.create(this, getString(R.string.es_strategy_title_tips), getString(R.string.es_position_stop_loss_insert_lastprice_zero)).show();
                    return false;
                } else {
                    mJudgePrice = mQuoteBetData.getPreClosingPrice();
                }
            } else {
                mJudgePrice = mQuoteBetData.getLastPrice();
            }
        }
        return true;
    }

    private InsertOrder openOrderToInsertOrder(OpenOrder openOrder, char direct, BigInteger orderQty) {
        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
        InsertOrder insertOrder = EsInsertOrderHelper.defaultOrder(this, account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo(), mContract.getContractNo());
        insertOrder.setStrategyType(openOrder.getStrategyType());
        insertOrder.setOffset(openOrder.getOffset());
        insertOrder.setOrderPriceType(openOrder.getOrderPriceType());
        insertOrder.setOrderPriceOver(openOrder.getOrderPriceOver());
        insertOrder.setOrderType(openOrder.getOrderType());
        insertOrder.setOrderPrice(String.valueOf(EsDataApi.formatOrderPrice(mContract, String.valueOf(openOrder.getOrderPrice()), direct)));
        insertOrder.setValidType(openOrder.getValidType());
        insertOrder.setStopPrice(EsDataApi.formatOrderPrice(mContract, String.valueOf(openOrder.getStopPrice()), direct));
        insertOrder.setStopPriceType(openOrder.getStopPriceType());
        insertOrder.setDirect(direct);
        insertOrder.setOrderQty(orderQty);
        // 因为保本单的stopPrice是价差，防止PTA这种最小变动价为2，但是止盈价差为1，会造成对价差取整为0，然后相加价格没有变动的情况
        if (openOrder.getStrategyType() == EsDataConstant.S_ST_OPEN_BREAKEVEN) {
            insertOrder.setStopPrice(openOrder.getStopPrice());
        }

        return insertOrder;
    }

    private InsertOrder initOrder(String price, char direct) {
        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
        BigInteger qty = BigInteger.valueOf(Long.valueOf(mContractEdit.getLotsStr()));

        if (EsInsertOrderHelper.inputCheck(this, price, qty, account, mContract, mKeyboardPrice.didSetSpecialPrice())) {
            String companyNo = account.getCompanyNo();
            String userNo = account.getUserNo();
            String addrNo = account.getAddrTypeNo();

            final InsertOrder insertOrder = EsInsertOrderHelper.defaultOrder(this, companyNo, userNo, addrNo, mContract.getContractNo());
            insertOrder.setOrderPrice(String.valueOf(EsDataApi.formatOrderPrice(mContract, price, direct)));
            insertOrder.setOrderType(getOrderType(mKeyboardPrice.getSpecialPriceId()));
            insertOrder.setOrderQty(qty);
            insertOrder.setAddOne(mIsAddOne);
            insertOrder.setValidType(mValidType);
            insertOrder.setOffset(EsDataConstant.S_OFFSET_OPEN);
            insertOrder.setHedge(EsSPHelperProxy.getIsHedge(this) ? EsDataConstant.S_HEDGE_HEDGE : EsDataConstant.S_HEDGE_SPECULATE);

            insertOrder.setDirect(direct);
            return insertOrder;
        } else {
            return null;
        }
    }


    private void insertStrategyOrder() {
        if (checkCondition()) {
            showStopLossDialog(new OpenOrder());
        }
    }

    private void showStopLossDialog(OpenOrder openOrder) {
        mStopLossDialog = new EsStopLossOpenDialog(this);
        mStopLossDialog.setContract(mContract);
        mStopLossDialog.setOpenOrder(openOrder);
        mStopLossDialog.setLastPrice(EsDataApi.formatPrice(mContract.getCommodity(), mQuoteBetData.getLastPrice()));
        mStopLossDialog.setPriceTypeStr(getOrderPriceTypeStr());
        mStopLossDialog.setBtnClick(this);
        mStopLossDialog.show();
    }

    private String getOrderPriceTypeStr() {
        String specialPrice = EstarFieldTransformation.priceTypeToStr(this, EsSPHelperProxy.getDefaultPriceType(this));
        if (EsSPHelperProxy.getDefaultPriceType(this) == EsSPHelperProxy.S_PT_MARKET && !EsDataApi.isMarketPriceAvailable(mContract)) {
            if (EsSPHelper.getMarketPriceSetting(this)) {
                ToastHelper.show(this, R.string.es_trade_notify_message_trade_contractset_market_price_available);
                specialPrice = EstarFieldTransformation.priceTypeToStr(this, EsSPHelperProxy.S_PT_MATCH);
            }
        }
        return specialPrice;
    }

    private boolean checkCondition() {
        if (mContract == null) {
            ToastHelper.show(this, R.string.es_stop_loss_open_dialog_order_no_contract);
            return false;
        }

        if (mContract.isStock()) {
            ToastHelper.show(this, R.string.es_stop_loss_open_dialog_order_no_support_stock);
            return false;
        }

        if (mContract.isForeignContract() || mContract.isArbitrageContract()) {
            ToastHelper.show(this, R.string.es_stop_loss_open_dialog_order_no_support);
            return false;
        }

        String contractNo = mContract.getContractNo();
        if (contractNo != null && contractNo.endsWith("INDEX")) {
            ToastHelper.show(this, R.string.es_view_trade_threekey_warning_index_cannot_trade);
            return false;
        }

        String qty = mEditTextLots.getText().toString();
        if (TextUtils.isEmpty(qty) || Double.parseDouble(qty) <= 0) {
            ToastHelper.show(this, R.string.es_stop_loss_open_dialog_order_no_qty);
            return false;
        }

        if (mKeyboardPrice.getSpecialPriceId() != EsSPHelperProxy.S_PT_MARKET && (mBuyPrice <= 0 || mSellPrice <= 0)) {
            ToastHelper.show(this, R.string.es_stop_loss_open_dialog_order_no_price);
            return false;
        } else if (mKeyboardPrice.getSpecialPriceId() == EsSPHelperProxy.S_PT_MARKET && (mBuyPrice < 0 || mSellPrice < 0)) {
            ToastHelper.show(this, R.string.es_stop_loss_open_dialog_order_no_price);
            return false;
        }

        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        if (mContract != null) {
            EsDataApi.unSubQuote(mContract.getContractNo());
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(EsEventMessage messageEvent) {
        int action = messageEvent.getAction();
        if (action == EsEventConstant.E_STAR_ACTION_SELECT_OPTION && messageEvent.getSender() == EsEventConstant.E_STAR_MODULE_SEARCH) {
            if (KEY_SEARCH_SOURCE.equals(messageEvent.getData())) {
                Contract contract = EsDataApi.getQuoteContract(messageEvent.getContent());
                if (contract != null) {
                    setContract(contract);
                    EsFavoriteListData.getInstance().addFavoriteContract(contract, false);
                    mContractEdit.setLots(getDefaultQty(getApplicationContext(), contract));
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void quoteEvent(QuoteEvent event) {
        int action = event.getAction();
        String contractNo = event.getContractNo();
        if (action == EsDataConstant.S_SRVEVENT_QUOTE) {
            if (mContract != null && contractNo.equals(mContract.getContractNo())) {
                refreshQuoteData();
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();
        final String companyNo = event.getCompanyNo();
        final String userNo = event.getUserNo();
        final String addrNo = event.getAddressNo();

        if (action == EsDataConstant.S_SRVEVENT_TRADE_FUND) {
            refreshFundData(companyNo, userNo, addrNo);
        }
    }

    public char getOrderType(int specialId) {
        if (specialId == EsSPHelperProxy.S_PT_MARKET && EsDataApi.isMarketPriceAvailable(mContract)) {
            return EsDataConstant.S_ORDERTYPE_MARKET;
        } else {
            return EsDataConstant.S_ORDERTYPE_LIMIT;
        }
    }

    @Override
    public void customOnPriceKeyDown(EsTradePriceKeyboardView keyboardView, int keyId, boolean isSpecial) {
        if (isSpecial) {
            refreshSpecialPrice(keyboardView);
        } else {
            String realPrice = keyboardView.getPrice();
            mBuyPrice = Double.parseDouble(realPrice);
            mSellPrice = Double.parseDouble(realPrice);
        }
    }

    private void refreshSpecialPrice(EsTradePriceKeyboardView keyboardView) {
        double extraPrice = keyboardView.getExtraPrice();
        int specialPriceId = keyboardView.getSpecialPriceId();
        switch (specialPriceId) {
            case EsSPHelperProxy.S_PT_LSAT:
                // 买卖价均为最新价
                mBuyPrice = mSellPrice = mQuoteBetData.getLastPrice();
                break;
            case EsSPHelperProxy.S_PT_QUEUE:
                mBuyPrice = mQuoteBetData.getBuyPrice();
                mSellPrice = mQuoteBetData.getSellPrice();
                break;
            case EsSPHelperProxy.S_PT_MARKET:
                if (!EsDataApi.isMarketPriceAvailable(mContract) && !EsSPHelper.getMarketPriceSetting(getApplicationContext())) {
                    // 按涨跌停价
                    mBuyPrice = mQuoteBetData.getLimitUpPrice();
                    mSellPrice = mQuoteBetData.getLimitDownPrice();
                } else {
                    // 市价价格不填或者为0
                    mBuyPrice = 0;
                    mSellPrice = 0;
                }
                break;
            case EsSPHelperProxy.S_PT_MATCH:
                mBuyPrice = mQuoteBetData.getSellPrice();
                mSellPrice = mQuoteBetData.getBuyPrice();
                break;
            case EsSPHelperProxy.S_PT_EXCEED:
                long PT = 1;
                double step = 1;
                if (mContract != null) {
                    step = mContract.getCommodity().getTickPrice();
                    PT = EsSPHelper.getCommodityPoint(this, mContract);
                }
                double delta = PT * step;
                switch (mKeyboardPrice.getExceedPriceId()) {
                    case EsSPHelperProxy.S_PT_LSAT:
                        mBuyPrice = mQuoteBetData.getLastPrice() + delta;
                        mSellPrice = mQuoteBetData.getLastPrice() - delta;
                        if (mContract != null && !mContract.isPriceBelowZero()) {
                            mSellPrice = mSellPrice < 0 ? 0 : mSellPrice;
                        }
                        break;
                    case EsSPHelperProxy.S_PT_QUEUE:
                        mBuyPrice = mQuoteBetData.getBuyPrice() + delta;
                        mSellPrice = mQuoteBetData.getSellPrice() - delta;
                        if (mContract != null && !mContract.isPriceBelowZero()) {
                            mSellPrice = mSellPrice < 0 ? 0 : mSellPrice;
                        }
                        break;
                    case EsSPHelperProxy.S_PT_MATCH:
                        mBuyPrice = mQuoteBetData.getSellPrice() + delta;
                        mSellPrice = mQuoteBetData.getBuyPrice() - delta;
                        if (mContract != null && !mContract.isPriceBelowZero()) {
                            mSellPrice = mSellPrice < 0 ? 0 : mSellPrice;
                        }
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }

        if (specialPriceId == EsSPHelperProxy.S_PT_EXCEED) {
            mBuyPrice = mBuyPrice + extraPrice;
            mSellPrice = mSellPrice - extraPrice;
        } else {
            mBuyPrice = mBuyPrice + extraPrice;
            mSellPrice = mSellPrice + extraPrice;
        }
    }

    @Override
    public Contract onGetContract(EsTradePriceKeyboardView keyboardView) {
        return mContract;
    }

    @Override
    public double onGetLastPrice(EsTradePriceKeyboardView keyboardView) {
        return mQuoteBetData.getLastPrice();
    }

    @Override
    public void onChangeValidType(EsTradePriceKeyboardView keyboardView, char ValidType) {
        mValidType = ValidType;
    }

    // 点击添加止损止盈单确认
    @Override
    public void clickConfirm(OpenOrder openOrder, String orderPrice) {
        boolean isAdd = checkInsertOrder(openOrder);
        if (isAdd) {
            mOpenOrderData.add(openOrder);
            mOrderPriceStr.add(orderPrice);
            mAdapter.notifyDataSetChanged();
            mStopLossDialog.dismiss();
        }
        if (mOpenOrderData.size() == 3) {
            mInsertTV.setVisibility(View.GONE);
        }
    }

    private boolean checkInsertOrder(OpenOrder openOrder) {
        if (openOrder == null) {
            return false;
        }

        boolean isStopLoss = (openOrder.getStrategyType() == EsDataConstant.S_ST_OPEN_STOPLOSS || openOrder.getStrategyType() == EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT);
        for (int i = 0; i < mOpenOrderData.size(); i++) {
            char strategyType = mOpenOrderData.get(i).getStrategyType();
            boolean isHasStopLoss = (strategyType == EsDataConstant.S_ST_OPEN_STOPLOSS || strategyType == EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT);
            if (mOpenOrderData.get(i) != null) {
                if (strategyType == openOrder.getStrategyType() || (isStopLoss && isHasStopLoss)) {
                    ToastHelper.show(getApplicationContext(), R.string.es_stop_loss_open_activity_judge_same_order);
                    return false;
                }
            }
        }
        return true;

    }

    // 点击添加止损止盈单取消
    @Override
    public void clickCancel() {
        mStopLossDialog.dismiss();
    }

    @Override
    public void clickUndo(int position) {
        if (position < mOpenOrderData.size()) {
            mOpenOrderData.remove(position);
            mOrderPriceStr.remove(position);
            mInsertTV.setVisibility(View.VISIBLE);
            mAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void clickCancel(final int position) {
        if (position < mOpenOrderData.size()) {
            OpenOrder openData = mOpenOrderData.get(position);
            char strategyType = openData.getStrategyType();
            OrderData orderData = null;
            for (OrderData data : mOrderDatas) {
                if (data.getStrategyType() == strategyType) {
                    orderData = data;
                    break;
                }
            }
            if (orderData != null) {
                final EsCustomDialog customDialog = EsCustomDialog.create(this);
                final OrderData finalOrderData = orderData;
                customDialog.setTitle(this.getString(R.string.es_trade_option_dialog_reverse))
                        .setContent(this.getString(R.string.es_stop_loss_open_activity_cancel_order_message))
                        .setCheckbox(this.getString(R.string.es_base_view_do_not_prompt))
                        .setShowDialog(EsSPHelperProxy.isShowReversePrompt(this))
                        .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                            @Override
                            public void onConfirm() {
                                EsSPHelperProxy.setIsShowReversePrompt(EsStopLossOpenActivity.this, !customDialog.isSelectCheckBox());

                                int ret = EsDataApi.deleteTradeOrder(finalOrderData);
                                if (ret > 0) {
                                    mOpenOrderData.remove(position);
                                    mOrderPriceStr.remove(position);
                                    mInsertTV.setVisibility(View.VISIBLE);
                                    mAdapter.notifyDataSetChanged();
                                }
                                customDialog.dismiss();
                            }

                            @Override
                            public void onCancel() {
                                customDialog.dismiss();
                            }
                }).show();
            }
        }
    }
}
