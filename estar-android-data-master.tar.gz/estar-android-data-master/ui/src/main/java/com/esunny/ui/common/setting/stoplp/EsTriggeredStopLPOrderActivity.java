package com.esunny.ui.common.setting.stoplp;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.R;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.ui.common.setting.condition.EsBaseConditionActivity;
import com.esunny.ui.common.setting.condition.adapter.EsTriggeredConditionalOrderAdapter;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.EsBaseToolBar;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by wb on 2018/11/23.
 */
public class EsTriggeredStopLPOrderActivity extends EsBaseConditionActivity {

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_triggered_stop_loss_profit_order;
    }

    @Override
    protected void initViewValue() {
        mBaseToolBar.setTitle(getString(R.string.es_activity_triggered_stopLP_conditional_order_basetoolbar));
        mBaseToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
    }

    @Override
    protected void bindOnClick() {
        mBaseToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if(id == R.id.toolbar_left_first) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void initAdapter() {
        mAdapter = new EsTriggeredConditionalOrderAdapter(this);
        ((EsTriggeredConditionalOrderAdapter)mAdapter).setOrderData(mOrderDatas);
        ((EsTriggeredConditionalOrderAdapter)mAdapter).setListType(EsTriggeredConditionalOrderAdapter.ListTypeStopLossProfit);
    }

    @Override
    protected void getOrderData() {
        if(mOrderDatas == null){
            mOrderDatas = new ArrayList<>();
        }
        mOrderDatas.clear();
        EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        if (loginAccount == null) {
            return;
        }
        List<OrderData> orderData = getCurrentAccountOrderData(loginAccount.getUserNo(), loginAccount.getCompanyNo(), loginAccount.getAddrTypeNo());
        for (int i = 0; i < orderData.size(); i++) {
            if(orderData.get(i) == null){
                continue;
            }
            if((orderData.get(i).getStrategyType() == EsDataConstant.S_ST_STOPLOSS ||
                    orderData.get(i).getStrategyType() == EsDataConstant.S_ST_STOPPROFIT ||
                    orderData.get(i).getStrategyType() == EsDataConstant.S_ST_FLOATSTOPLOSS ||
                    orderData.get(i).getStrategyType() == EsDataConstant.S_ST_BREAKEVEN ||
                    orderData.get(i).getStrategyType() == EsDataConstant.S_ST_OPEN_STOPLOSS ||
                    orderData.get(i).getStrategyType() == EsDataConstant.S_ST_OPEN_STOPPROFIT ||
                    orderData.get(i).getStrategyType() == EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT ||
                    orderData.get(i).getStrategyType() == EsDataConstant.S_ST_OPEN_BREAKEVEN) &&
                    (orderData.get(i).getOrderState()== EsDataConstant.S_ORDERSTATE_FILLTRIGGERED ||
                    orderData.get(i).getOrderState() == EsDataConstant.S_ORDERSTATE_TRIGGERFAILED ||
                    orderData.get(i).getOrderState() == EsDataConstant.S_ORDERSTATE_FAIL ||
                    orderData.get(i).getOrderState() == EsDataConstant.S_ORDERSTATE_CANCELED||
                    orderData.get(i).getOrderState() == EsDataConstant.S_ORDERSTATE_INVALID||
                    orderData.get(i).getOrderState() == '\u0000')){
                    mOrderDatas.add(orderData.get(i));
            }
        }
    }

    private List<OrderData> getCurrentAccountOrderData(String userNo, String companyNo, String addrNo) {
        return EsDataApi.getOrderData(companyNo, userNo, addrNo, EsDataConstant.S_ST_CONDITION,'\0',"", -1, true);
    }

    @Override
    public void onScrollChange(int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
//        ((EsConditionalOrderAdapter)mAdapter).buttonScroll(scrollX);
    }

    private void updateLists(){
        getOrderData();
        mAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage messageEvent) {
        int action = messageEvent.getAction();

        if (action == EsEventConstant.E_STAR_ACTION_NOTIFY_TRADE_LOGOUT) {
            EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
            if (account == null){
                finish();
            }else {
                getOrderData();
                mAdapter.notifyDataSetChanged();
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();

        if (action == EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER) {
            OrderData data = (OrderData)event.getData();
            if (data == null) {
                return;
            }

            if(data.getStrategyType() == EsDataConstant.S_ST_STOPLOSS
                    || data.getStrategyType() == EsDataConstant.S_ST_STOPPROFIT
                    || data.getStrategyType() == EsDataConstant.S_ST_FLOATSTOPLOSS
                    || data.getStrategyType() == EsDataConstant.S_ST_BREAKEVEN) {
                updateLists();
            }
        }
    }
}
