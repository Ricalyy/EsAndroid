package com.esunny.ui.common.setting;

import android.app.Activity;
import android.content.Context;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.BasePresenter;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIApi;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.util.EsSPHelper;

import org.greenrobot.eventbus.EventBus;

import java.util.List;

import skin.support.SkinCompatManager;
import skin.support.utils.SkinPreference;

public class SettingPresenterImpl extends BasePresenter<SettingCombination.View> implements SettingCombination.Presenter {

    private SettingCombination.Model mModel;
    private Context mContext;

    public SettingPresenterImpl(Context context) {
        this.mContext = context;
        mModel = new SettingModelImpl();
    }

    @Override
    public void login() {
        EsUIApi.startLoginActivity(-1);
    }

    @Override
    public void charSetting() {
        EsUIApi.startChartSettingActivity();
    }

    @Override
    public void tradeSetting() {
        EsUIApi.startTradeSettingActivity();
    }

    @Override
    public void cloundConditionOrder() {
        EsUIApi.startConditionalOrderActivity();
    }

    @Override
    public void stopLossAndStopProfit() {
        EsUIApi.startEsStrategyStopActivity();
    }

    @Override
    public void priceWarn() {
        EsUIApi.startEsPriceWarnActivity();
    }

    @Override
    public void aboutTrade() {
        EsUIApi.startTradeAboutActivity();
    }

    @Override
    public void message() {
        EsUIApi.startMessageActivity();
    }

    @Override
    public void quoteLogin(Activity activity) {
        EsUIApi.startStarLoginActivity(activity);
    }

    @Override
    public void openAccount() {
        EsUIApi.startOpenOnlineActivity();
    }

    @Override
    public void changeSkin(Context context) {
        //获取当前显示的主题
        String name = SkinPreference.getInstance().getSkinName();
        if(name.equals("night.skin")){
            SkinCompatManager.getInstance().restoreDefaultTheme();
            EsSPHelper.setTheme(context, true);
        }else{
//            SkinCompatManager.getInstance().loadSkin("night", null, SkinCompatManager.SKIN_LOADER_STRATEGY_BUILD_IN);
            SkinCompatManager.getInstance().loadSkin("night.skin", null, SkinCompatManager.SKIN_LOADER_STRATEGY_ASSETS);
            EsSPHelper.setTheme(context, false);
        }
        //通知其他模块更新数据
        EventBus.getDefault().post(new EsEventMessage(-1, EsEventConstant.E_STAR_ACTION_CHANGE_THEME));
        //关闭右抽屉
        EventBus.getDefault().post(new EsEventMessage(-1, EsEventConstant.E_STAR_ACTION_CLOSE_RIGHT_DRAWER));
    }

    @Override
    public void setting() {
        EsUIApi.startSystemSettingActivity();
    }

    @Override
    public void about() {
        EsUIApi.startAboutActivity();//打开关于界面
    }

    @Override
    public void accountDetail() {
        EsUIApi.startEsAccountDetailActivity(mModel.getLoginAccountData().getCurrentAccount());
    }

    @Override
    public void selectAccount() {
        EsUIApi.startAccountSelectActivity();
    }

    @Override
    public void turnToStopLossOpen() {
        EsUIApi.startStopLossOPenActivity("settingFragment", "");
    }

    @Override
    public void refreshAccountDataDetail() {
        EsLoginAccountData loginAccountData = mModel.getLoginAccountData();
        if (loginAccountData == null){
            return;
        }

        if (loginAccountData.getCurrentAccount() == null || loginAccountData.getmListLoginData().isEmpty()){
            mView.refreshTitleByAccountCount(0, "");
        }else if (loginAccountData.getmListLoginData().size() == 1){
            mView.refreshTitleByAccountCount(1, mModel.getLoginAccountData().getCurrentAccount().getUserNo());
        }else {
            mView.refreshTitleByAccountCount(2, "" + mModel.getLoginAccountData().getmListLoginData().size());
        }
    }

    @Override
    public void queryMessage() {
        EsLoginAccountData.LoginAccount userInfo = mModel.getLoginAccountData().getCurrentAccount();
        if (userInfo !=null && ! mModel.isSameUser()) {
            EsDataApi.qryMessage(userInfo.getCompanyNo(), userInfo.getUserNo(), userInfo.getAddrTypeNo());
            mModel.setLastUserInfo(userInfo);
        }
        mView.updateBadgeViewByMessage(mModel.isHasUnreadMessage(mContext));
    }

    @Override
    public void queryStrategy() {
        EsLoginAccountData.LoginAccount currentAccount = mModel.getLoginAccountData().getCurrentAccount();
        if (currentAccount != null) {
            List<OrderData> orderData = EsDataApi.getOrderData(currentAccount.getCompanyNo(), currentAccount.getUserNo(), currentAccount.getAddrTypeNo(), EsDataConstant.S_ST_CONDITION, '\0', "", -1, true);
            int condition = 0, stoplp = 0;
            for (OrderData data : orderData) {
                if (data == null) {
                    continue;
                }

                char strategyType = data.getStrategyType();
                char orderState = data.getOrderState();

                switch (strategyType) {
                    case EsDataConstant.S_ST_CONDITION:
                    case EsDataConstant.S_ST_CONDITION_PARENT:
                    case EsDataConstant.S_ST_BACKHAND:
                    case EsDataConstant.S_ST_AUTOORDER:
                        if (judgeConditionState(orderState)) {
                            condition++;
                        }
                        break;
                    case EsDataConstant.S_ST_STOPLOSS:
                    case EsDataConstant.S_ST_STOPPROFIT:
                    case EsDataConstant.S_ST_FLOATSTOPLOSS:
                    case EsDataConstant.S_ST_BREAKEVEN:
                    case EsDataConstant.S_ST_OPEN_STOPLOSS:
                    case EsDataConstant.S_ST_OPEN_STOPPROFIT:
                    case EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT:
                    case EsDataConstant.S_ST_OPEN_BREAKEVEN:
                        if(judgeStopLpState(orderState)){
                            stoplp++;
                        }
                        break;
                    default:
                        break;
                }
            }

            mView.updateBadgeViewNum(condition, stoplp);
        }
    }

    private boolean judgeConditionState(char state) {
        return  state != EsDataConstant.S_ORDERSTATE_FILLTRIGGERED
                && state != EsDataConstant.S_ORDERSTATE_TRIGGERFAILED
                && state != EsDataConstant.S_ORDERSTATE_FAIL
                && state != EsDataConstant.S_ORDERSTATE_CANCELED
                && state != EsDataConstant.S_ORDERSTATE_INVALID
                && state != '\u0000';
    }

    private boolean judgeStopLpState(char state) {
        return  state != EsDataConstant.S_ORDERSTATE_FILLTRIGGERED
                && state != EsDataConstant.S_ORDERSTATE_TRIGGERFAILED
                && state != EsDataConstant.S_ORDERSTATE_FAIL
                && state != EsDataConstant.S_ORDERSTATE_CANCELED
                && state != EsDataConstant.S_ORDERSTATE_INVALID
                && state != EsDataConstant.S_ORDERSTATE_OPENSTOPLOSS
                && state != EsDataConstant.S_ORDERSTATE_STOPLOSS
                && state != '\u0000';
    }

    @Override
    protected void register() {
        super.register();
    }

    @Override
    protected void unRegister() {
        super.unRegister();
    }
}
