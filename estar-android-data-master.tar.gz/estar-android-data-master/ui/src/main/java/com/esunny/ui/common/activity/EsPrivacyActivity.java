package com.esunny.ui.common.activity;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.NotifyInfo;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsPictureFileHelper;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.EsWebUrlData;
import com.esunny.ui.view.EsBaseToolBar;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;

@Route(path = RoutingTable.ES_PRIVACY_ACTIVITY)
public class EsPrivacyActivity extends EsBaseActivity {

    @BindView(R2.id.es_activity_privacy_tv_cancel)
    TextView mTvCancel;
    @BindView(R2.id.es_activity_privacy_tv_confirm)
    TextView mTvConfirm;
    @BindView(R2.id.es_activity_privacy_web_content)
    WebView mWebView;
    @BindView(R2.id.es_privacy_toolbar)
    EsBaseToolBar baseToolBar;
    @BindView(R2.id.es_activity_privacy_ll_choose)
    LinearLayout mLlChoose;

    // 是否从关于中进入隐私
    private boolean mIsAboutIn = false;

    private NotifyInfo mNotifyObject;
//    private String mLocalVersion;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setNeedInit(false);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void initData() {
        super.initData();

//        mLocalVersion = getIntent().getStringExtra(EsUIConstant.KEY_CONFIRM_LOCALVERSION);
        mNotifyObject = EsDataApi.getNotifyInfo();
    }

    @Override
    protected void initWidget() {
        super.initWidget();

//        String content = getIntent().getStringExtra(EsUIConstant.KEY_PRIVACY_CONTENT);
//        if(content != null) {
            // 从关于中点击进入隐私声明
            mIsAboutIn = true;
            baseToolBar.setLeftIconVisible(true, false);
            baseToolBar.setSimpleBack(getString(R.string.es_activity_privacy_confirm_title));
            mLlChoose.setVisibility(View.GONE);
//        } else {
//            mIsAboutIn = false;
//            baseToolBar.setLeftIconVisible(false, false);
//            mLlChoose.setVisibility(View.VISIBLE);
//        }

        baseToolBar.setRightIcons(new int[]{R.string.es_icon_fresh});
        baseToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_right_first) {
                    if (mWebView != null) {
                        mWebView.reload();
                    }
                }
            }
        });

        // 之后需替换，支持换肤
        mWebView.loadUrl(EsWebUrlData.getPrivacyInfoUrl(this));
        mWebView.setFocusable(true);
        mWebView.getSettings().setTextZoom(100);
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);//测试阶段不适用缓存，方便调试
//        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.setBackgroundColor(0);
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });
        //设置不用系统浏览器打开,直接显示在当前Webview
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                mWebView.loadUrl(url);
                return true;
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (mWebView != null) {
            mWebView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            ((ViewGroup) mWebView.getParent()).removeView(mWebView);
            mWebView.destroy();
            mWebView = null;
        }
        super.onDestroy();
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_privacy;
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (!mIsAboutIn) {
            if (keyCode == KeyEvent.KEYCODE_BACK)
                return true;
        }
        return super.onKeyDown(keyCode, event);
    }

//    @OnClick(R2.id.es_activity_privacy_tv_confirm)
//    public void confirm(){
//        EsSPHelper.setPrivacyConfirm(this, true);
//        boolean isWeb = mNotifyObject != null && mNotifyObject.getMsgNotifyType() == EsDataConstant.S_BFT_Html;
//        if (isWeb && isNeedNotice(mNotifyObject)) {
//            Intent intent = new Intent(EsPrivacyActivity.this, EsNoticeActivity.class);
//            startActivity(intent);
//            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
//        } else {
//            EsUIApi.startStartLoadingActivity(this.getClass().getSimpleName(), EsUIConstant.S_PRIVACY_RESULT_CODE_CONFIRM);
//        }
//    }

//    @OnClick(R2.id.es_activity_privacy_tv_cancel)
//    public void cancel(){
//        EsSPHelper.setPrivacyConfirm(this, false);
//        EsUIApi.startStartLoadingActivity(this.getClass().getSimpleName(), EsUIConstant.S_PRIVACY_CONFIRM_RESULT_CODE_CANCEL);
//    }


    /**
     *  通过通知判断是否需要显示通知
     * @return
     */
//    private boolean isNeedNotice(NotifyInfo notifyInfo){
//        if (notifyInfo == null) {
//            return false;
//        }
//
//        long savedId = EsSPHelper.getNoticeId(this);
//        if (savedId == notifyInfo.getMsgNotifyID()) {
//            return false;
//        }
//
//        String startTime = notifyInfo.getMsgNotifyStartDate();
//        String endTime = notifyInfo.getMsgNotifyEndDate();
//
//        SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
//        String currentTime = df.format(new Date());
//
//        if (EsPictureFileHelper.isNeedUsePic(startTime, endTime, currentTime)){
//            return true;
//        } else {
//            return false;
//        }
//    }
}
