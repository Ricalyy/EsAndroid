package com.esunny.ui.common.setting.quote.kline;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.quote.EsKLineData;
import com.esunny.ui.quote.kline.bean.KLineParam;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsIconTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EsIndexParameterActivity extends EsBaseActivity implements View.OnClickListener {

    RecyclerView rv_technical_index, rv_parameter_index;
    EsIconTextView itv_back;
    TextView tv_save;

    HashMap<String, ArrayList<KLineParam>> mKLineParamsHashMap;

    List<String> mKLineParamsKeyList = new ArrayList<>();
    List<KLineParam> mIndexParamAdapterDataList = new ArrayList<>();

    EsTechnicalIndexAdapter mTechnicalIndexAdapter;
    EsIndexParameterAdapter mIndexParameterAdapter;

    private final static String CJL = "CJL";

    @Override
    protected void initData() {
        super.initData();

        initTechnicalAndKLinesParameters();
    }

    private void initTechnicalAndKLinesParameters() {
        mKLineParamsHashMap = EsKLineData.getInstance().getAllParams();
        mKLineParamsKeyList = EsKLineData.getInstance().getAllParamsKey();

        if (mKLineParamsHashMap == null || mKLineParamsKeyList == null) {
            finish();
        }

        int size = mKLineParamsKeyList.size();
        for (int i = size - 1; i >= 0; i--) {
            String key = mKLineParamsKeyList.get(i);
            if (mKLineParamsHashMap.get(key) == null) {
                mKLineParamsKeyList.remove(i);
            }
        }
        mIndexParamAdapterDataList.clear();
        mIndexParamAdapterDataList.addAll(mKLineParamsHashMap.get(mKLineParamsKeyList.get(0)));
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindOnClick();

        initAdapterData();

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        rv_technical_index.setLayoutManager(layoutManager);
        rv_technical_index.setAdapter(mTechnicalIndexAdapter);

        RecyclerView.LayoutManager layoutManager_parameter = new LinearLayoutManager(this);
        rv_parameter_index.setLayoutManager(layoutManager_parameter);
        rv_parameter_index.setAdapter(mIndexParameterAdapter);

    }

    private void initAdapterData() {
        mTechnicalIndexAdapter = new EsTechnicalIndexAdapter(this, mKLineParamsKeyList);
        mTechnicalIndexAdapter.setOnItemListener(new EsTechnicalIndexAdapter.OnItemListener() {
            @Override
            public void onClick(View v, int position, String technicalIndex) {
                mTechnicalIndexAdapter.setDefSelect(position);

                // Adapter中list对象不能变否则无法正常显示list所以先clear再add数据。
                mIndexParamAdapterDataList.clear();
                ArrayList<KLineParam> list = mKLineParamsHashMap.get(technicalIndex);
                if (list != null) {
                    mIndexParamAdapterDataList.addAll(list);
                    mIndexParameterAdapter.setMainKey(technicalIndex);
                    mIndexParameterAdapter.notifyDataSetChanged();

                }
            }
        });

        mIndexParameterAdapter = new EsIndexParameterAdapter(this, mIndexParamAdapterDataList);
        mIndexParameterAdapter.setMainKey(mKLineParamsKeyList.get(0));
        mIndexParameterAdapter.notifyDataSetChanged();
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_index_parameter;
    }

    private void bindView() {
        itv_back = findViewById(R.id.es_activity_index_parameter_iv_back);
        rv_parameter_index = findViewById(R.id.es_activity_index_parameter_urv_parameter_index);
        rv_technical_index = findViewById(R.id.es_activity_index_parameter_rv_technical_index);
        tv_save = findViewById(R.id.es_activity_index_parameter_tv_save);
    }

    private void bindOnClick() {
        itv_back.setOnClickListener(this);
        tv_save.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.es_activity_index_parameter_iv_back) {
            itv_back.requestFocus();
            back();
            //在返回时，同时保存文件
            save();
        } else if (i == R.id.es_activity_index_parameter_tv_save) {
            tv_save.requestFocus();
            save();
            ToastHelper.show(this, R.string.es_index_param_activity_succeed);
        }
    }

    public void save() {
        if (mIndexParameterAdapter.mCurrentEditText != null) {
            mIndexParameterAdapter.mCurrentEditText.clearFocus();

            int position = mTechnicalIndexAdapter.getDefItem();
            if (position >= 0 && position < mKLineParamsKeyList.size()) {
                String key = mKLineParamsKeyList.get(position);
                ArrayList<KLineParam> list = mKLineParamsHashMap.get(key);

                //写入SP
                EsKLineData.getInstance().saveKLineParam(this, key, list);
            }
        }
    }

    public void back() {
        finish();
    }
}
