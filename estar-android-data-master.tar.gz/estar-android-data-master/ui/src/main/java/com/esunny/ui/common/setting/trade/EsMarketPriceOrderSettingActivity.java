package com.esunny.ui.common.setting.trade;

import android.view.View;
import android.widget.RelativeLayout;

import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsIconTextView;

import butterknife.BindView;
import butterknife.OnClick;

public class EsMarketPriceOrderSettingActivity extends EsBaseActivity {

    @BindView(R2.id.es_activity_market_price_setting_toolbar)
    EsBaseToolBar mToolBar;
    @BindView(R2.id.es_market_price_rl_stop_order)
    RelativeLayout mRlStopOrder;
    @BindView(R2.id.es_market_price_rl_price_up_down_order)
    RelativeLayout mRlPriceUpDownOrder;
    @BindView(R2.id.es_item_choose_stop_order_tv_check)
    EsIconTextView mTvCheckStopOrder;
    @BindView(R2.id.es_item_choose_price_up_down_tv_check)
    EsIconTextView mTvCheckPriceUpDownOrder;


    private boolean mIsStopOrder;


    @Override
    protected void initData() {
        super.initData();

        mIsStopOrder = EsSPHelper.getMarketPriceSetting(getApplicationContext());
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_market_price_order_setting;
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        initViewValue();
    }

    private void initViewValue() {
        mToolBar.setSimpleBack(this.getString(R.string.es_activity_market_price_setting));

        updateCheckUI(mIsStopOrder);
    }

    private void updateCheckUI(boolean isSopOrder) {
        if (isSopOrder) {
            mTvCheckStopOrder.setVisibility(View.VISIBLE);
            mTvCheckPriceUpDownOrder.setVisibility(View.GONE);
        } else {
            mTvCheckStopOrder.setVisibility(View.GONE);
            mTvCheckPriceUpDownOrder.setVisibility(View.VISIBLE);
        }
    }

    @OnClick(R2.id.es_market_price_rl_stop_order)
    public void stopOrder() {
        mIsStopOrder = true;
        updateCheckUI(true);

        EsSPHelper.setMarketPriceSetting(getApplicationContext(), true);
    }

    @OnClick(R2.id.es_market_price_rl_price_up_down_order)
    public void priceUpDownOrder() {
        mIsStopOrder = false;
        updateCheckUI(false);
        EsSPHelper.setMarketPriceSetting(getApplicationContext(), false);
    }
}
