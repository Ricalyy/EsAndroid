package com.esunny.ui.common.setting.trade;

import com.esunny.data.bean.BillDetail;
import com.esunny.ui.R;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.chartview.DataEntry;
import com.esunny.ui.view.chartview.PieEntry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class BenefitModelImpl implements EsBenefitCombination.Mode{

    private List<BillDetail> mBillData = new ArrayList<>();

    private Map<String, Float> mBillCommodityProfitMap = new LinkedHashMap<>();

    private Map<String, Float> mBillCommodityFeeMap = new TreeMap<>();

    private float mBfBalance;   // 期初结存  第一天的期末結存的值是表的期初權益

    private float mCfBalance;   //期末结存

    private float mRealizedPL;  //平盈

    private float mMTMPL;   //持仓盯市盈亏

    private float mCommission;  //手续费

    private float mInitialMargin;   //  保证金

    private float mDepositWithdrawal;   //出入金

    @Override
    public EsLoginAccountData.LoginAccount getCurrentAccount() {
        return EsLoginAccountData.getInstance().getCurrentAccount();
    }

    @Override
    public void addBillData(String billDate, String billContent) {
        BillDetail billDetail = new BillDetail();
        billDetail.setBillDate(billDate);

        if (billContent != null && ! billContent.isEmpty()) {
            try {
                billDetail.setBfBalance(Float.valueOf(billStr(billContent, "Balance b/f", "Initial Margin")));
            } catch (NumberFormatException e) {
                billDetail.setBfBalance(0.00f);
            }

            try {
                billDetail.setCfBalance(Float.valueOf(billStr(billContent, "Balance c/f", "Realized P/L")));
            } catch (NumberFormatException e) {
                billDetail.setCfBalance(0.00f);
            }

            try {
                billDetail.setRealizedPL(Float.valueOf(billStr(billContent, "Realized P/L", "Pledge Amount")));
            } catch (NumberFormatException e) {
                billDetail.setRealizedPL(0.00f);
            }

            try {
                billDetail.setMTMPL(Float.valueOf(billStr(billContent, "MTM P/L", "Client Equity")));
            } catch (NumberFormatException e) {
                billDetail.setMTMPL(0.00f);
            }

            try {
                billDetail.setCommission(Float.valueOf(billStr(billContent, "Commission", "Margin Occupied")));
            } catch (NumberFormatException e) {
                billDetail.setMTMPL(0.00f);
            }

            try {
                billDetail.setInitialMargin(Float.valueOf(billStr(billContent, "Margin Occupied", "Exercise Fee")));
            } catch (NumberFormatException e) {
                billDetail.setInitialMargin(0.00f);
            }

            try {
                billDetail.setDepositWithdrawal(Float.valueOf(billStr(billContent, "Deposit/Withdrawal", "Balance c/f")));
            } catch (NumberFormatException e) {
                billDetail.setInitialMargin(0.00f);
            }

            calcBenefit(billContent);
        }

        mBillData.add(billDetail);
    }

    @Override
    public List<BillDetail> getAllBillData() {
        return mBillData;
    }

    @Override
    public void clearAllBillData() {
        mBillData.clear();
    }

    @Override
    public void clearAllBillCommodityData() {
        mBillCommodityProfitMap.clear();
        mBillCommodityFeeMap.clear();
    }

    @Override
    public void calBillValue() {
        // reset value
        mCfBalance = 0.00f;
        mBfBalance = 0.00f;
        mMTMPL = 0.00f;
        mInitialMargin = 0.00f;
        mRealizedPL = 0.00f;
        mCommission = 0.00f;
        mDepositWithdrawal = 0.00f;

        int length = mBillData.size();
        if (length >0) {
            boolean isGetBfBalance = false;

            for (int i = 0; i < length; i++) {
                BillDetail billDetail = mBillData.get(i);
                mRealizedPL += billDetail.getRealizedPL();
                mCommission += billDetail.getCommission();
                mDepositWithdrawal += billDetail.getDepositWithdrawal();

                if (isValidBillData(billDetail)) {
                    mCfBalance = billDetail.getCfBalance();
                    mMTMPL = billDetail.getMTMPL();
                    mInitialMargin = billDetail.getInitialMargin();
                    if (!isGetBfBalance) {
                        mBfBalance = billDetail.getCfBalance();
                        isGetBfBalance = true;
                    }
                }
            }
        }
    }

    @Override
    public float getInitialMargin() {
        return mInitialMargin;
    }

    @Override
    public float getCommission() {
        return mCommission;
    }

    @Override
    public float getBfBanlance() {
        return mBfBalance;
    }

    @Override
    public float getCfBanlance() {
        return mCfBalance;
    }

    @Override
    public float getRealizedPL() {
        return mRealizedPL;
    }

    @Override
    public float getMTMPL() {
        return mMTMPL;
    }

    @Override
    public float getDepositWithdrawal() {
        return mDepositWithdrawal;
    }

    @Override
    public List<DataEntry> getLineChartData() {
        List<DataEntry> entries = new ArrayList<>();
        for (int i = 0; i < mBillData.size(); i++){
            if (isValidBillData(mBillData.get(i))) {
                entries.add(new DataEntry(i, mBillData.get(i).getCfBalance(), mBillData.get(i).getBillDate()));
            }
        }
        return entries;
    }

    @Override
    public List<DataEntry> getBarChartData() {
        List<DataEntry> result = new ArrayList<>();
        int count = 0;
        for (String key : mBillCommodityProfitMap.keySet()){
            result.add(new DataEntry(count, mBillCommodityProfitMap.get(key), key));
            count++;
        }
        return result;
    }

    @Override
    public List<PieEntry> getPieChartData() {
        List<Integer> colorResList = new ArrayList<>();
        colorResList.add(R.color.es_activity_benefit_red);
        colorResList.add(R.color.es_activity_benefit_orange);
        colorResList.add(R.color.es_activity_benefit_green);
        colorResList.add(R.color.es_activity_benefit_light_blue);
        colorResList.add(R.color.es_activity_benefit_dark_blue);
        colorResList.add(R.color.es_activity_benefit_purple);
        colorResList.add(R.color.es_activity_benefit_pink);
        colorResList.add(R.color.es_activity_benefit_blue);
        colorResList.add(R.color.es_activity_benefit_black);
        colorResList.add(R.color.es_activity_benefit_grey);

        List<Map.Entry<String, Float>> list = new ArrayList<>(mBillCommodityFeeMap.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, Float>>() {
            @Override
            public int compare(Map.Entry<String, Float> o1, Map.Entry<String, Float> o2) {
                return o1.getValue().compareTo(o2.getValue());
            }
        });
        Collections.reverse(list);

        List<PieEntry> result = new ArrayList<>();
        int count = 0;
        for (Map.Entry<String, Float> entry : list){
            String key = entry.getKey();
            float commodityFee = mBillCommodityFeeMap.get(key);
            if (count > 8){
                // 一共十个 从这里开始 没有具体品种 都算其他
                key = "其他";
                if (mBillCommodityFeeMap.get(key) == null){
                    mBillCommodityFeeMap.put(key, commodityFee);
                }else {
                    commodityFee += mBillCommodityFeeMap.get(key);
                    mBillCommodityFeeMap.put(key, commodityFee);
                }
                if (count == list.size() - 1){
                    result.add(new PieEntry(result.size(), commodityFee, key, colorResList.get(result.size()), false));
                }
            }else {
                result.add(new PieEntry(count, commodityFee, key, colorResList.get(count), false));
            }
            count++;
        }
        return result;
    }

    @Override
    public boolean isEnoughValidData() {
        int validCount = 0;
        for (BillDetail billDetail : mBillData){
            if (isValidBillData(billDetail)){
                validCount++;
                if (validCount > 1){
                    return true;
                }
            }
        }
        return false;
    }

    private String billStr(String content, String first, String last){
        if (content == null || content.isEmpty()){
            return "0.00";
        }
        if (! content.contains(first)){
            return "0.00";
        }
        if (! content.contains(last)){
            return "0.00";
        }

        int firstIndex = content.indexOf(first);
        int lastIndex = content.indexOf(last);
        if (firstIndex >= lastIndex){
            return "0.00";
        }

        String newBillContent1 = content.substring(firstIndex, lastIndex).trim();

        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < newBillContent1.length(); i++){
            char str = newBillContent1.charAt(i);
            if ( (str > 47 && str < 58) || str == '-' || str == '.'){
                builder.append(str);
            }
        }
        return builder.toString();
    }

    private boolean isValidBillData(BillDetail billDetail){
        if (billDetail.getInitialMargin() == 0.00f && billDetail.getMTMPL() == 0.00f && billDetail.getBfBalance()  == 0.00f && billDetail.getCfBalance() == 0.00f
            && billDetail.getCommission() == 0.00f && billDetail.getRealizedPL() == 0.00f){
            return false;
        }else {
            return true;
        }
    }

    private void calcBenefit(String billContent){
//        HashMap<String, Float> map = new HashMap<>();
        String[] arg = billContent.split("----------------------------------------------------------------------------------------------------");
        if (arg.length < 4 || ! arg[2].contains("成交记录")){
            return;
        }
        String transcationRecord = arg[4];
        String[] record = transcationRecord.split("\n");
        for (int i = 1; i < record.length; i++){
            String detailBill = record[i];
            String[] singleRecord =  detailBill.split("\\|");
            String commodity = singleRecord[3].trim();
            String money = singleRecord[12].trim();
            String fee = singleRecord[11].trim();
            if (mBillCommodityProfitMap.containsKey(commodity)){
                float sumProfit = mBillCommodityProfitMap.get(commodity) + Float.parseFloat(money);
                float sumFee = mBillCommodityFeeMap.get(commodity) + Float.parseFloat(fee);
                mBillCommodityProfitMap.put(commodity, sumProfit);
                mBillCommodityFeeMap.put(commodity, sumFee);
            }else {
                mBillCommodityProfitMap.put(commodity, Float.parseFloat(money));
                mBillCommodityFeeMap.put(commodity, Float.parseFloat(fee));
            }
        }
    }
}
