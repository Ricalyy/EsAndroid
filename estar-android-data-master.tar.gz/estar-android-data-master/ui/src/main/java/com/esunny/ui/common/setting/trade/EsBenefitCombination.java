package com.esunny.ui.common.setting.trade;

import com.esunny.data.bean.BillDetail;
import com.esunny.ui.BaseView;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.chartview.BarChartData;
import com.esunny.ui.view.chartview.DataEntry;
import com.esunny.ui.view.chartview.LineChartData;
import com.esunny.ui.view.chartview.PieEntry;

import java.util.List;

public interface EsBenefitCombination {

    interface View extends BaseView{
        void updateBenefitDataStatisticUI(String bfBalance, String cfBalance, String realizedPL, String MTMPL, String commission, String initialMargin, String depositWithdrawal);

        void updateChart();

        void simulateProgressBar(int progress);

        void noEnoughBillData();
    }

    interface Presenter{

        LineChartData getLineChartData();

        LineChartData gerResetChartData();

        BarChartData getBarChartData();

        BarChartData gerResetBarChartData();

        List<PieEntry> getPieChartData();

        void startQueryBillData(int days);

        void startCusQueryBillData(int days, String date);

        void registerBillCallback();

        void unRegisterBillCallback();

    }

    interface Mode{

        EsLoginAccountData.LoginAccount getCurrentAccount();

        void addBillData(String billDate, String billContent);

        List<BillDetail> getAllBillData();

        void clearAllBillData();

        void clearAllBillCommodityData();

        // 账单结束之后计算账单数据
        void calBillValue();

        float getInitialMargin();

        float getCommission();

        float getBfBanlance();

        float getCfBanlance();

        float getRealizedPL();

        float getMTMPL();

        float getDepositWithdrawal();

        List<DataEntry> getLineChartData();

        List<DataEntry> getBarChartData();

        List<PieEntry> getPieChartData();

        boolean isEnoughValidData();
    }
}
