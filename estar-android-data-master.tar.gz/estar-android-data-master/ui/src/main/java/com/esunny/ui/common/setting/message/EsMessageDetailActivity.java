package com.esunny.ui.common.setting.message;

import android.view.View;
import android.widget.TextView;

import com.esunny.data.bean.MessageData;
import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;

import com.esunny.ui.view.EsIconTextView;

public class EsMessageDetailActivity extends EsBaseActivity implements View.OnClickListener{

    EsIconTextView itv_back;
    TextView tv_title, tv_user, tv_date, tv_content;

    MessageData mMessageData;

    @Override
    protected void initData() {
        super.initData();
        mMessageData =  (MessageData) getIntent().getSerializableExtra("messageData");
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindOnClick();

        initViewValue();
    }

    private void bindView() {
        itv_back = findViewById(R.id.es_activity_bill_query_iv_back);
        tv_title = findViewById(R.id.es_activity_message_detail_tv_title);
        tv_user = findViewById(R.id.es_activity_message_detail_tv_user);
        tv_date = findViewById(R.id.es_activity_message_detail_tv_date);
        tv_content = findViewById(R.id.es_activity_message_detail_tv_content);
    }

    private void bindOnClick() {
        itv_back.setOnClickListener(this);
    }

    private void initViewValue() {
        if (mMessageData != null) {
            tv_title.setText(mMessageData.getTitle());
            tv_date.setText(mMessageData.getSendDateTime());
            tv_user.setText(mMessageData.getSendNo());
            tv_content.setText(mMessageData.getContent());
        };
    }
    @Override
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.es_activity_bill_query_iv_back){
            back();
        }
    }

    private void back() {
        finish();
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_message_detail;
    }

}
