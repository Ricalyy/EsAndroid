package com.esunny.ui.common.bean;

public class EsOpPLDrawData {

    private double mStartPrice;//起始价格
    private double mEndPrice;//终结价格
    private double mMaxDrawProfit;//绘图最大收益
    private double mMaxDrawLoss;//绘图最大损失
    private double mMaxProfit;  //实际最大收益
    private double mMaxLoss;    //实际最大损失
    private boolean mValid;//是否有效

    public double getStartPrice() {
        return mStartPrice;
    }

    public void setStartPrice(double startPrice) {
        mStartPrice = startPrice;
    }

    public double getEndPrice() {
        return mEndPrice;
    }

    public void setEndPrice(double endPrice) {
        mEndPrice = endPrice;
    }

    public double getMaxDrawProfit() {
        return mMaxDrawProfit;
    }

    public void setMaxDrawProfit(double maxDrawProfit) {
        mMaxDrawProfit = maxDrawProfit;
    }

    public double getMaxDrawLoss() {
        return mMaxDrawLoss;
    }

    public void setMaxDrawLoss(double maxDrawLoss) {
        mMaxDrawLoss = maxDrawLoss;
    }

    public boolean isValid() {
        return mValid;
    }

    public void setValid(boolean valid) {
        mValid = valid;
    }

    public double getMaxProfit() {
        return mMaxProfit;
    }

    public void setMaxProfit(double maxProfit) {
        mMaxProfit = maxProfit;
    }

    public double getMaxLoss() {
        return mMaxLoss;
    }

    public void setMaxLoss(double maxLoss) {
        mMaxLoss = maxLoss;
    }
}