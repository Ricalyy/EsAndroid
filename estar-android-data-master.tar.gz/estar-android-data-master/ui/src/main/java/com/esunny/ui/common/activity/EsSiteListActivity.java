package com.esunny.ui.common.activity;

import android.content.Intent;
import android.view.View;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.bean.CloudTradeCompany;
import com.esunny.ui.login.data.EsSiteListData;


import java.util.List;

/**
 * Created by esunny on 07/06/2017.
 */

public class EsSiteListActivity extends EsBaseSiteActivity  {

    @Override
    protected void initData() {
        super.initData();
        List<CloudTradeCompany> list = EsDataApi.getCloudTradeCompanyData("","");

        mListData = new EsSiteListData(list);
    }

    @Override
    public void OnClick(View v, int position) {
        int selectedIndex = position;
        Intent intent = new Intent();
        intent.putExtra("cloudCompany",(CloudTradeCompany)mListData.getCloudTradeCompanies().toArray()[selectedIndex]);
        this.setResult(1,intent);
        finish();
    }
}
