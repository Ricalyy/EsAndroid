package com.esunny.ui.common.setting.condition;

import android.annotation.SuppressLint;
import android.content.Intent;
import androidx.annotation.StringRes;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.api.util.EstarTransformation;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.HisQuoteTimeBucket;
import com.esunny.data.bean.QuoteBetData;
import com.esunny.data.bean.AvailableQty;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.OpenOrder;
import com.esunny.data.bean.OrderData;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.setting.condition.EsStrategyData.EsStrategyData;
import com.esunny.ui.common.setting.condition.EsStrategyView.EsStrategyInputs;
import com.esunny.ui.common.setting.condition.EsStrategyView.EsStrategyPanel;
import com.esunny.ui.common.setting.condition.EsStrategyView.EsStrategyToolBar;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.dialog.EsCustomDialog;
import com.esunny.ui.dialog.EsCustomTipsDialog;
import com.esunny.ui.util.EsInsertOrderHelper;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.ToastHelper;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.OnClick;

@Route(path = RoutingTable.ES_STRATEGY_CONDITION_ACTIVITY)
public class EsStrategyActivity extends EsBaseActivity implements EsStrategyToolBar.OnToolbarListener, EsStrategyData.StrategyDataListener, EsStrategyInputs.OffsetClickListener {

    private static final String TAG = "EsStrategyActivity";

    @BindView(R2.id.trade_strategy_toolbar)
    EsStrategyToolBar mToolBar;
    @BindView(R2.id.trade_strategy_simple_panel)
    EsStrategyPanel mPanel;
    @BindView(R2.id.trade_strategy_inputs)
    EsStrategyInputs mInputs;
    @BindView(R2.id.trade_strategy_button_buy)
    TextView mBtnBuy;
    @BindView(R2.id.trade_strategy_button_sell)
    TextView mBtnSell;
    @BindView(R2.id.trade_strategy_offset_qty)
    LinearLayout mOffsetLL;
    @BindView(R2.id.trade_strategy_offset_qty_buy)
    TextView mOffsetBuy;
    @BindView(R2.id.trade_strategy_offset_qty_sell)
    TextView mOffsetSell;
    @BindView(R2.id.trade_strategy_offset_qty_ll_buy)
    LinearLayout mLlOffsetQtyBuy;
    @BindView(R2.id.trade_strategy_offset_qty_ll_sell)
    LinearLayout mLlOffsetQtySell;

    private EsCustomTipsDialog mTipsDialog;


    //定义check的错误码
    private final int STRATEGY_NORMAL = 0;
    private final int STRATEGY_ERROR_CODE = -1;//其他错误，不下单
    private final int STRATEGY_TIME_TRIGGERED_ERROR_CODE = -2;//下单时间已触发
    private final int STRATEGY_INSUFFICIENT_ERROR_CODE = -3;//持仓不足提示
    private final int STRATEGY_PRICE_TRIGGERED_ERROR_CODE = -4;//价格条件已触发

    private String mContractNo;

    // 是否条件单改单
    private boolean mIsModify;
    // 是否已经撤单了（正式改单之前需要撤销原来的条件单）
    private boolean mIsRevoke = false;
    // 改单的订单
    OrderData mModifyOrderData;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_strategy;
    }

    @Override
    protected void initData() {
        super.initData();
        Intent intent = getIntent();

        mIsModify = intent.getBooleanExtra("modifyCondition", false);

        mModifyOrderData = (OrderData) intent.getSerializableExtra("orderData");

        mContractNo = intent.getStringExtra("contractNo");
        // 是否从K线界面来
        boolean fromKLine = "klineActivity".equals(intent.getStringExtra("source"));
        if (mContractNo == null && mModifyOrderData != null && mIsModify) {
            mContractNo = mModifyOrderData.getContractNo();
        }

        // 先将条件单改单置为默认false
        EsStrategyData.getInstance().setIsModifyConditionOrder(false);
        EsStrategyData.getInstance().setIsFromKLine(fromKLine);
        EsStrategyData.getInstance().setIsOpenTrigger(false);
        EsStrategyData.getInstance().setStopLossList(null);
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        EsStrategyData.getInstance().setCallback(this);
        mInputs.setCallback(this);
        mToolBar.setOnSwitchListener(this);
        if (mContractNo != null) {
            mInputs.setContract(mContractNo);
        }

        if (mIsModify) {
            updateModifyUI();
        }
        // 更新完UI之后再设置是否为条件单改单
        EsStrategyData.getInstance().setIsModifyConditionOrder(mIsModify);
    }

    /**
     *  改单界面需要特殊处理UI
     *  条件单类型不能修改 时间条件单进去就是时间条件单的修改界面
     *  合约不能修改 禁止编辑
     *  开平 长期当日 不能修改 但显示 禁止编辑
     *  其他 手数  价格 条件 可以修改
     */
    private void updateModifyUI() {
        // 判断原订单是时间条件单还是价格条件单
        boolean isPrice = false;
        char strategyType = mModifyOrderData.getStrategyType();
        if(strategyType == EsDataConstant.S_ST_CONDITION
            || strategyType == EsDataConstant.S_ST_CONDITION_PARENT
            || strategyType == EsDataConstant.S_ST_BACKHAND) {//条件单条件
            isPrice = mModifyOrderData.getTimeCondition().length() == 0 && mModifyOrderData.getTriggerCondition() != '\u0000';
        }else if(strategyType == EsDataConstant.S_ST_AUTOORDER){
            isPrice = false;
        }

        Contract contract = EsStrategyData.getInstance().getSelectedContract();

        EsStrategyData.getInstance().setPrice(isPrice);
        EsStrategyData.getInstance().setIsOpenTrigger(strategyType == EsDataConstant.S_ST_AUTOORDER);

        mToolBar.updateModifyUI(isPrice);

        if (isPrice) {
            mInputs.setTriggerPrice(mModifyOrderData.getTriggerCondition(), mModifyOrderData.getTriggerCondition2(),
                    mModifyOrderData.getTriggerPrice(), mModifyOrderData.getTriggerPrice2());
        } else {
            mInputs.setTriggerTime(mModifyOrderData.getTimeCondition(), mModifyOrderData.getTriggerCondition2(), mModifyOrderData.getTriggerPrice2());
        }


        mInputs.switchPriceAndTime(isPrice);
        mInputs.setOrderPriceType(mModifyOrderData.getOrderPriceType(),
                EsDataApi.formatPrice(contract.getCommodity(),mModifyOrderData.getOrderPrice()),
                mModifyOrderData.getOrderPriceOver(), contract.getCommodity().getTickPrice());
        mInputs.setQty(mModifyOrderData.getOrderQty());
        mInputs.setUIIsOpen(mModifyOrderData.getOffset() == EsDataConstant.S_OFFSET_OPEN);
        mInputs.setUIIsToday(mModifyOrderData.getValidType() == EsDataConstant.S_VALIDTYPE_GFD);
        mInputs.modifyCheckUI();
        mInputs.updateAutoOrderUI(strategyType == EsDataConstant.S_ST_AUTOORDER);
        mInputs.showTimeConditionUI();
        mInputs.hideStopLoss();
        if (strategyType == EsDataConstant.S_ST_BACKHAND) {
            mInputs.setReverseOrder();
        }

        mBtnBuy.setText(R.string.es_stop_loss_open_activity_confirm_change_order);
        mBtnSell.setText(R.string.es_stop_loss_open_activity_confirm_cancel_order);

        boolean isBuy = mModifyOrderData.getDirect() == EsDataConstant.S_DIRECT_BUY;
        if (isBuy) {
            mLlOffsetQtyBuy.setVisibility(View.VISIBLE);
            mLlOffsetQtySell.setVisibility(View.GONE);
        } else {
            mLlOffsetQtyBuy.setVisibility(View.GONE);
            mLlOffsetQtySell.setVisibility(View.VISIBLE);
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        if (!EventBus.getDefault().isRegistered(this)) {
            EsStrategyData.getInstance().register();
            EventBus.getDefault().register(this);
        } else {
            EsStrategyData.getInstance().setToSearch(false);
        }

        // 非改单时需要将触发价格使用合约的最新价，改单则使用订单的触发价。
        if (!mIsModify) {
            mInputs.refreshPrices(EsStrategyData.getInstance().getmLastPrice());
        }
        onDataQuote();
        // 显示条件单合约可开可平手数
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (!EsStrategyData.getInstance().isOpen() && contract != null && !contract.isForeignContract()) {
            refreshQty(true);
        } else {
            refreshQty(false);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!EsStrategyData.getInstance().isToSearch()) {
            EsStrategyData.getInstance().unRegister();
        }

        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }

        // 测试小姐姐说除非改单，否则进入的时候都是价格条件单
        EsStrategyData.getInstance().setPrice(true);

        EsStrategyData.getInstance().removeCallback();
    }

    @OnClick({R2.id.trade_strategy_button_buy, R2.id.trade_strategy_button_sell})
    public void onClick(View v) {
        int viewId = v.getId();
        if (mIsModify && viewId == mBtnSell.getId()) {
            // 改单界面，点击取消下单 退出界面。
            finish();
            return;
        }

        // 检测订单状态，是否挂单还存在。
        if (mIsModify) {
            boolean isParOrderExit = false;
            List<OrderData> orderDataList = EsDataApi.getOrderData(mModifyOrderData.getCompanyNo(), mModifyOrderData.getUserNo(), mModifyOrderData.getAddressNo()
                    , mModifyOrderData.getStrategyType(), mModifyOrderData.getOrderState(), mModifyOrderData.getOrderNo(), -1, true);

            for (OrderData orderData : orderDataList) {
                if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_TRIGGERING) {
                    isParOrderExit = true;
                    break;
                }
            }

            if (!isParOrderExit) {
                ToastHelper.show(this, R.string.es_trade_strategy_order_status_changed);
                return;
            }
        }

        Contract contract = EsStrategyData.getInstance().getSelectedContract();

        if (contract == null) {
            ToastHelper.show(this, R.string.es_view_trade_threekey_warning_chosecontract);
            return;
        }

        if (contract.isStock()) {
            ToastHelper.show(this, R.string.es_trade_condition_cannot_is_stockContract);
            return;
        }

        if (contract.isArbitrageContract()) {
            ToastHelper.show(this, R.string.es_trade_position_stoploss_cannot_is_spreadContract);
            return;
        }

        char direct = viewId == mBtnBuy.getId() ? EsDataConstant.S_DIRECT_BUY : EsDataConstant.S_DIRECT_SELL;
        if (mIsModify) {
            direct = mModifyOrderData.getDirect();
        }

        final InsertOrder insert = getStrategyOrderInfo(direct);

        int checkResult = inputStrategyCheck(direct);
        if (checkResult == STRATEGY_NORMAL) {
            inputStrategyNormal(insert);
        }else if (checkResult == STRATEGY_PRICE_TRIGGERED_ERROR_CODE){
            showNoticeText(insert);
        }
    }

    private void inputStrategyNormal(final InsertOrder insert){
        if (EsStrategyData.getInstance().isPrice()) {
            int posRet = checkPosition(insert);
            if (posRet == STRATEGY_INSUFFICIENT_ERROR_CODE) {
                final EsCustomDialog posDialog = EsCustomDialog.create(EsStrategyActivity.this);
                posDialog.setTitle(getString(R.string.es_view_trade_threekey_message_title))
                        .setCancelable(false)
                        .setContent(getString(R.string.es_strategy_position_num_insufficient))
                        .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                    @Override
                    public void onConfirm() {
                        insertStrategyOrderWithMessages(insert);
                        posDialog.dismiss();
                    }

                    @Override
                    public void onCancel() {
                        posDialog.dismiss();
                    }
                }).show();
            } else {
                insertStrategyOrderWithMessages(insert);
            }
        } else {
            if (EsStrategyData.getInstance().isOpenTrigger()) {
                insertAutoOrder(insert);
            } else {
                insertTimeConditionOrder(insert);
            }
        }
    }

    /**
     * 下自动单
     */
    private void insertAutoOrder(InsertOrder insert) {
        insertOrderAfterCheckPosion(insert);
    }

    /**
     * 下时间条件单
     */
    private void insertTimeConditionOrder(final InsertOrder insert) {
        //检查下单触发时间
        int timeRet = checkTimeCondition();
        if (timeRet == STRATEGY_TIME_TRIGGERED_ERROR_CODE) {
            final EsCustomDialog timeDialog = EsCustomDialog.create(this);
            timeDialog.setTitle(getString(R.string.es_view_trade_threekey_message_title))
                    .setCancelable(false)
                    .setContent(getString(R.string.es_strategy_error_datetime_expired))
                    .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                        @Override
                        public void onConfirm() {
                            //切换到已触发之后，需要同时更新UI操作。
                            mInputs.switchValidLong();
                            //检查持仓
                            insert.setValidType(EsDataConstant.S_VALIDTYPE_GTC);
                            insertOrderAfterCheckPosion(insert);
                            timeDialog.dismiss();
                        }

                        @Override
                        public void onCancel() {
                            timeDialog.dismiss();
                        }
                    }).show();
        } else if (timeRet == STRATEGY_NORMAL) {
            insertOrderAfterCheckPosion(insert);
        }
    }

    /**
     *  检查持仓之后进行后续下单工作
     * @param insert
     */
    public void insertOrderAfterCheckPosion (final InsertOrder insert) {
        int posRet = checkPosition(insert);
        if (posRet == STRATEGY_INSUFFICIENT_ERROR_CODE) {
            final EsCustomDialog posDialog = EsCustomDialog.create(EsStrategyActivity.this);
            posDialog.setTitle(getString(R.string.es_view_trade_threekey_message_title))
                    .setCancelable(false)
                    .setContent(getString(R.string.es_strategy_position_num_insufficient))
                    .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                        @Override
                        public void onConfirm() {
                            insertStrategyOrderWithMessages(insert);
                            posDialog.dismiss();
                        }

                        @Override
                        public void onCancel() {
                            posDialog.dismiss();
                        }
                    }).show();
        } else if (posRet == STRATEGY_NORMAL) {
            insertStrategyOrderWithMessages(insert);
        }
    }

    //判断条件是否合理  false : 会立即触发    true : 正确
    private boolean checkConditionPrice(char condition, double conditionPrice) {
        EsStrategyData data = EsStrategyData.getInstance();
        double price = data.getmLastPrice();//最新价
        if (condition == EsDataConstant.S_TC_GREATER && price > conditionPrice) {
            return false;
        } else if (condition == EsDataConstant.S_TC_GREATEREQUAL && price >= conditionPrice) {
            return false;
        } else if (condition == EsDataConstant.S_TC_LESS && price < conditionPrice) {
            return false;
        } else if (condition == EsDataConstant.S_TC_LESSEQUAL && price <= conditionPrice) {
            return false;
        }
        return true;
    }

    //基本下单信息检测
    private int inputStrategyCheck(char direct) {

        EsStrategyData data = EsStrategyData.getInstance();

        Contract contract = EsStrategyData.getInstance().getSelectedContract();
//        QuoteBetData quoteBetData = new QuoteBetData(contract);
//        if (!quoteBetData.isValid()) {
//            if (data.getConditionOrderPriceType() != EsDataConstant.S_PT_ABS) {
//                ToastHelper.show(this, R.string.es_baseapi_trade_quote_input_valid);
//                return STRATEGY_ERROR_CODE;
//            }
//        }

        if (!EsInsertOrderHelper.inputCheck(this, BigInteger.valueOf(Long.parseLong(mInputs.getQty())), EsLoginAccountData.getInstance().getCurrentAccount(), contract)) {
            return STRATEGY_ERROR_CODE;
        }
        //委托价格检查
        if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_ABS) {
            double price = strPriceToDouble(mInputs.getPriceStrOrder(), direct);
            if ((price <= 0 && !EsDataApi.isForeignContract(data.getSelectedContract().getCommodity())) || EsLoginAccountData.getInstance().isStockAccount()) {
                showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_orderprice_zero);
                return STRATEGY_ERROR_CODE;
            }
        }
        //触发价格条件检查
        return checkInputRange(direct);
    }

    private int checkTimeCondition() {
        EsStrategyData data = EsStrategyData.getInstance();
        String[] timeStrs = mInputs.getTimeCondition().split(":");
        if (timeStrs.length != 3) {
            return STRATEGY_ERROR_CODE;
        }
        long timeLong = Integer.parseInt(timeStrs[2]) * 1000 + Integer.parseInt(timeStrs[1]) * 100000 + Integer.parseInt(timeStrs[0]) * 10000000;
        Contract contract = data.getSelectedContract();
        ArrayList<HisQuoteTimeBucket> hisQuoteTimeBuckets = (ArrayList<HisQuoteTimeBucket>) EsDataApi.getBaseTimeBucketData(contract.getCommodity().getCommodityNo());
        boolean isDuringTradeTime = false;
        // 外盘合约取消限制，任何时间都可以下单
        if (contract.isForeignContract()) {
            isDuringTradeTime = true;
        } else {
            isDuringTradeTime = isDuringTime(timeLong, hisQuoteTimeBuckets);
        }

        if (!isDuringTradeTime) {
            showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_datetime_not_exist_tradetime);
            return STRATEGY_ERROR_CODE;
        }
        if (data.isToday()) {//当日检测
            int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
            int minute = Calendar.getInstance().get(Calendar.MINUTE);
            int second = Calendar.getInstance().get(Calendar.SECOND);
            long currentTimeLong = second * 1000 + minute * 100000 + hour * 10000000;
            long beginTimeLong = hisQuoteTimeBuckets.get(0).getBeginTime();
            if (!contract.isForeignContract()) {
                beginTimeLong = getBeginTime(beginTimeLong);
            }

            long setTime = timeLong - beginTimeLong;
            if (setTime < 0) {
                setTime += 240000000;
            }
            long nowTime = currentTimeLong - beginTimeLong;
            if (nowTime < 0) {
                nowTime += 240000000;
            }
            if (nowTime > setTime) {
                EsLoginAccountData.LoginAccount loginData = EsLoginAccountData.getInstance().getCurrentAccount();
                if (loginData != null) {
                    String tradeDate = "";
                    if (loginData.getTradeDate() != null && loginData.getTradeDate().length > 0) {
                        tradeDate = loginData.getTradeDate()[0];
                    }
                    if (EsDataApi.isEstarTradeApi(loginData.getTradeApi())) {
                        if (contract.isForeignContract()) {
                            if (loginData.getTradeDate() != null && loginData.getTradeDate().length > 1) {
                                tradeDate = loginData.getTradeDate()[1];
                            }
                        }
                    }

                    //如果设置时间在交易时间段内，并且瓶中开始时间交易时间在当前时间和设置时间中间，并且在同一个交易日内
                    if (beginTimeLong >= currentTimeLong && beginTimeLong <= timeLong && tradeDate.equals(getCurrentDate())) {
                        return STRATEGY_NORMAL;
                    }

                    if (tradeDate == null || tradeDate.equals("") || tradeDate.equals(getCurrentDate())) {
                        //并且自然日 与 交易日相等  不能下单
                        //showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_datetime_expired);
                        return STRATEGY_TIME_TRIGGERED_ERROR_CODE;
                    }
                }
            }
        }
        return STRATEGY_NORMAL;
    }

    private boolean isDuringTime(long timeLong, ArrayList<HisQuoteTimeBucket> hisQuoteTimeBuckets) {
        boolean isDuringTime = false;
        int size = hisQuoteTimeBuckets.size() - 1;
        for (int i = 0; i < size; i++) {
            if (hisQuoteTimeBuckets.get(i).getTradeState() == EsDataConstant.S_TRADESTATE_PAUSED) {
                continue;
            }
            long begin = hisQuoteTimeBuckets.get(i).getBeginTime();
            // 内盘合约集合竞价时间在开始交易时间提前5分钟
            if (i == 0) {
                begin = getBeginTime(begin);
            }

            long end = hisQuoteTimeBuckets.get(i + 1).getBeginTime();
            if (end < begin) {
                end += 240000000;
            }
            if (timeLong >= begin && timeLong <= end) {
                isDuringTime = true;//在交易时间段内
                break;
            } else if (timeLong < begin && (timeLong + 240000000) >= begin && (timeLong + 240000000) <= end) {
                // 选择时间跨天了
                isDuringTime = true;//在交易时间段内
                break;
            }
        }
        return isDuringTime;
    }

    private long getBeginTime(long begin) {
        long hour = begin / 10000000;
        long min = ((begin / 100000) - (begin / 10000000) * 100) - 5;
        long second = (begin / 1000) - (begin / 100000) * 100;
        if (min < 0) {
            min += 60;
            hour -= 1;
            hour = hour < 0 ? (hour + 24) : hour;
        }
        begin = hour * 10000000 + min * 100000 + second * 1000;
        return begin;
    }

    private int checkPosition(InsertOrder orderParent) {

        if (orderParent == null) {
            return STRATEGY_ERROR_CODE;
        }

        if (orderParent.getOffset() == EsDataConstant.S_OFFSET_COVER || orderParent.getOffset() == EsDataConstant.S_OFFSET_COVERT) {
            char posDirect;
            if (orderParent.getDirect() == EsDataConstant.S_DIRECT_BUY) {
                posDirect = EsDataConstant.S_DIRECT_SELL;
            } else {
                posDirect = EsDataConstant.S_DIRECT_BUY;
            }
            Contract contract = EsDataApi.getQuoteContract(orderParent.getContractNo());
            AvailableQty availableQty = EsDataApi.getAvailableQty(contract, posDirect, orderParent.getHedge(), orderParent.getCompanyNo(), orderParent.getUserNo(), orderParent.getAddressNo());
            long total = 0;
            if (availableQty != null) {
                total = availableQty.getAvailable().longValue();
            }
            if (total < orderParent.getOrderQty().longValue()) {
                //持仓不足
                return STRATEGY_INSUFFICIENT_ERROR_CODE;
            }
        }
        return STRATEGY_NORMAL;
    }


    //条件单暂时没有止损止盈
//    private int checkStopLPCondition(){
//        EsStrategyData data = EsStrategyData.getInstance();
//        if (data.getStrategyType() == EsStrategyData.mST.SpecifiedStopLP
//                || data.getStrategyType() == EsStrategyData.mST.StopLP
//                || data.getStrategyType() == EsStrategyData.mST.StopL
//                || data.getStrategyType() == EsStrategyData.mST.StopP) {
//            if (data.getStrategyType() != EsStrategyData.mST.StopP) {
//
//                if (data.getStrategyType() == EsStrategyData.mST.SpecifiedStopLP) {
//                    if (strPriceToDouble(mInputs.getPriceStrStopLoss()) <= 0) {
//                        showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_stoploss_price_zero);
//                        return STRATEGY_ERROR_CODE;
//                    }
//                } else {
//                    if (strPriceToDouble(mInputs.getPriceStrStopLoss()) <= 0) {
//                        showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_stoploss_diff_price_zero);
//                        return STRATEGY_ERROR_CODE;
//                    }
//                }
//
//                if (data.getConditionOrderPriceType() == StarApi_FINAL.S_PT_ABS) {
//                    double price = strPriceToDouble(mInputs.getPriceStrStopLossOrder());
//                    if (price <= 0) {
//                        showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_stoploss_abs_price_zero);
//                        return STRATEGY_ERROR_CODE;
//                    }
//                }
//            }
//            //止盈单
//            if (data.getStrategyType() != EsStrategyData.mST.StopL) {
//                if (data.getStrategyType() == EsStrategyData.mST.SpecifiedStopLP) {
//                    if (strPriceToDouble(mInputs.getPriceStrStopProfit()) <= 0) {
//                        showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_stopprofit_price_zero);
//                        return STRATEGY_ERROR_CODE;
//                    }
//                } else {
//                    if (strPriceToDouble(mInputs.getPriceStrStopProfit()) <= 0) {
//                        showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_stopprofit_diff_zero);
//                        return STRATEGY_ERROR_CODE;
//                    }
//                }
//
//                if (data.getConditionOrderPriceType() == StarApi_FINAL.S_PT_ABS) {
//                    double price = strPriceToDouble(mInputs.getPriceStrStopProfitOrder());
//                    if (price <= 0) {
//                        showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_stopprofit_abs_price_zero);
//                        return STRATEGY_ERROR_CODE;
//                    }
//                }
//            }
//        } else if (data.getStrategyType() == EsStrategyData.mST.Float) {//浮动回撤止损
//            if (strPriceToDouble(mInputs.getPriceStrStopLoss()) <= 0) {
//                showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_floatstoploss_float_price_zero);
//                return STRATEGY_ERROR_CODE;
//            }
//            if (data.getConditionOrderPriceType() == StarApi_FINAL.S_PT_ABS) {
//                double price = strPriceToDouble(mInputs.getPriceStrStopLossOrder());
//                if (price <= 0) {
//                    showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_stoploss_abs_price_zero);
//                    return STRATEGY_ERROR_CODE;
//                }
//            }
//        }
//        return STRATEGY_NORMAL;
//    }
    private int checkInputRange(char direct) {
        if (EsStrategyData.getInstance().getSelectedContract().isForeignContract()
                || EsStrategyData.getInstance().getSelectedContract().isOptionContract()) {
            return checkPriceCondition(direct);
        } else {
            double preSettlePrice = EsStrategyData.getInstance().getmPreSettlePrice();
            if (preSettlePrice == 0) {
                preSettlePrice = EsStrategyData.getInstance().getmPreClosingPrice();
            }
            double limitUpPrice = EsStrategyData.getInstance().getmLimitUpPrice();
            double limitDownPrice = EsStrategyData.getInstance().getmLimitDownPrice();
            if (limitUpPrice == 0 && limitDownPrice ==0 || preSettlePrice == 0){
                return checkPriceCondition(direct);
            }

            if (EsStrategyData.getInstance().isPrice()) { //价格条件单
                double checkTriggerPrice = Double.valueOf(mInputs.getPriceStrCondition());
                if (EsStrategyData.getInstance().isBonus()) { //附加价
                    double checkTrggierBonusPrice = Double.valueOf(mInputs.getPriceStrBonusCondition());
                    if (EsStrategyData.getInstance().isToday()) { //当日
                        if (checkTrggierBonusPrice > limitUpPrice || checkTrggierBonusPrice < limitDownPrice) {
                            ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_today_triggerPrice);
                            return STRATEGY_ERROR_CODE;
                        }
                    } else {
                        if (checkTrggierBonusPrice > preSettlePrice * EsDataConstant.FIVE_RISE || checkTrggierBonusPrice < preSettlePrice * EsDataConstant.FIVE_FALL) {
                            ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_longtime_triggerPrice);
                            return STRATEGY_ERROR_CODE;
                        }
                    }
                }

                if (EsStrategyData.getInstance().isToday()) {
                    if (checkTriggerPrice > limitUpPrice || checkTriggerPrice < limitDownPrice) {
                        ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_today_triggerPrice);
                        return STRATEGY_ERROR_CODE;
                    }
                } else {
                    if (checkTriggerPrice > preSettlePrice * EsDataConstant.FIVE_RISE || checkTriggerPrice < preSettlePrice * EsDataConstant.FIVE_FALL) {
                        ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_longtime_triggerPrice);
                        return STRATEGY_ERROR_CODE;
                    }
                }

                if (EsStrategyData.getInstance().getConditionOrderPriceType() == EsDataConstant.S_PT_ABS) {//指定价
                    double orderPrice = Double.valueOf(mInputs.getPriceStrOrder());
                    if (EsStrategyData.getInstance().isToday()) {
                        if (orderPrice > limitUpPrice || orderPrice < limitDownPrice) {
                            ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_today_orderPrice);
                            return STRATEGY_ERROR_CODE;
                        }
                    } else {
                        if (orderPrice > preSettlePrice * EsDataConstant.FIVE_RISE || orderPrice < preSettlePrice * EsDataConstant.FIVE_FALL) {
                            ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_longtime_orderPrice);
                            return STRATEGY_ERROR_CODE;
                        }
                    }
                }
            } else {//时间条件单
                if (EsStrategyData.getInstance().isBonus()) {
                    double checkTimeTrggierBonusPrice = Double.valueOf(mInputs.getPriceStrBonusCondition());
                    if (EsStrategyData.getInstance().isToday()) {//当日
                        if (checkTimeTrggierBonusPrice > limitUpPrice || checkTimeTrggierBonusPrice < limitDownPrice) {
                            ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_today_triggerPrice);
                            return STRATEGY_ERROR_CODE;
                        }
                    } else {
                        if (checkTimeTrggierBonusPrice > preSettlePrice * EsDataConstant.FIVE_RISE || checkTimeTrggierBonusPrice < preSettlePrice * EsDataConstant.FIVE_FALL) {
                            ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_longtime_triggerPrice);
                            return STRATEGY_ERROR_CODE;
                        }
                    }
                }

                if (EsStrategyData.getInstance().getConditionOrderPriceType() == EsDataConstant.S_PT_ABS) {//指定价
                    double timeOrderPrice = Double.valueOf(mInputs.getPriceStrOrder());
                    if (EsStrategyData.getInstance().isToday()) {
                        if (timeOrderPrice > limitUpPrice || timeOrderPrice < limitDownPrice) {
                            ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_today_orderPrice);
                            return STRATEGY_ERROR_CODE;
                        }
                    } else {
                        if (timeOrderPrice > preSettlePrice * EsDataConstant.FIVE_RISE || timeOrderPrice < preSettlePrice * EsDataConstant.FIVE_FALL) {
                            ToastHelper.show(this, R.string.es_position_stop_loss_insert_check_longtime_orderPrice);
                            return STRATEGY_ERROR_CODE;
                        }
                    }
                }
            }
            return checkPriceCondition(direct);
        }
    }

    //检查价格条件检查
    private int checkPriceCondition(char direct) {
        EsStrategyData data = EsStrategyData.getInstance();
        double conditionPrice = strPriceToDouble(mInputs.getPriceStrCondition(), direct);
        //价格条件
        if (data.isPrice()) {
            //价格条件检查
            if ((conditionPrice <= 0 && !EsDataApi.isForeignContract(data.getSelectedContract().getCommodity())) || EsLoginAccountData.getInstance().isStockAccount()) {
                showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_error_order_price_zero);
                return STRATEGY_ERROR_CODE;
            }
        }
        //附加条件检查
        if (data.isBonus() && !data.isOpenTrigger()) {
            double bonusPrice = strPriceToDouble(mInputs.getPriceStrBonusCondition(), direct);
            if ((bonusPrice <= 0 && !EsDataApi.isForeignContract(data.getSelectedContract().getCommodity())) || EsLoginAccountData.getInstance().isStockAccount()) {
                showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_erorr_addition_price_zero);
                return STRATEGY_ERROR_CODE;
            }
            //双价格条件情况下，不能同时满足
            if (data.isPrice()) {
                if (data.getTriggerMode() == data.getBonusTriggerMode() && !((conditionPrice < bonusPrice && (data.getTriggerCondition() == EsDataConstant.S_TC_GREATER || data.getTriggerCondition() == EsDataConstant.S_TC_GREATEREQUAL)
                        && (data.getBonusTriggerCondition() == EsDataConstant.S_TC_LESS || data.getBonusTriggerCondition() == EsDataConstant.S_TC_LESSEQUAL))
                        || (conditionPrice > bonusPrice && (data.getTriggerCondition() == EsDataConstant.S_TC_LESS || data.getTriggerCondition() == EsDataConstant.S_TC_LESSEQUAL) && (data.getBonusTriggerCondition() == EsDataConstant.S_TC_GREATER || data.getBonusTriggerCondition() == EsDataConstant.S_TC_GREATEREQUAL)) || (conditionPrice == bonusPrice && ((data.getTriggerCondition() == EsDataConstant.S_TC_LESSEQUAL && data.getBonusTriggerCondition() == EsDataConstant.S_TC_GREATEREQUAL) || (data.getTriggerCondition() == EsDataConstant.S_TC_GREATEREQUAL && data.getBonusTriggerCondition() == EsDataConstant.S_TC_LESSEQUAL))))) {
                    showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_erorr_prices_cannot_satified_at_the_same_time);
                    return STRATEGY_ERROR_CODE;
                } else if (data.getmLastPrice() == conditionPrice && (data.getTriggerCondition() == EsDataConstant.S_TC_GREATEREQUAL || data.getTriggerCondition() == EsDataConstant.S_TC_LESSEQUAL)) {
//                    ToastHelper.show(this, R.string.es_kline_draw_line_order_dialog_invalid_price_info_warnning);
                    return STRATEGY_PRICE_TRIGGERED_ERROR_CODE;
                } else if (data.getmLastPrice() == bonusPrice && (data.getBonusTriggerCondition() == EsDataConstant.S_TC_GREATEREQUAL || data.getBonusTriggerCondition() == EsDataConstant.S_TC_LESSEQUAL)) {
//                    ToastHelper.show(this, R.string.es_kline_draw_line_order_dialog_invalid_price_info_warnning);
                    return STRATEGY_PRICE_TRIGGERED_ERROR_CODE;
                } else if ((data.getmLastPrice() > conditionPrice && data.getmLastPrice() < bonusPrice) || (data.getmLastPrice() < conditionPrice && data.getmLastPrice() > bonusPrice)) {
//                    ToastHelper.show(this, R.string.es_kline_draw_line_order_dialog_invalid_price_info_warnning);
                    return STRATEGY_PRICE_TRIGGERED_ERROR_CODE;
                }
            }
        } else {
            if (data.isPrice()) {
                //检测条件是否立即触发
                if (!checkConditionPrice(data.getTriggerCondition(), conditionPrice)) {
//                    showErrorText(R.string.es_strategy_title_tips, R.string.es_strategy_erorr_condition_price_triggered);
//                    return STRATEGY_ERROR_CODE;
//                    ToastHelper.show(this, R.string.es_kline_draw_line_order_dialog_invalid_price_info_warnning);
                    return STRATEGY_PRICE_TRIGGERED_ERROR_CODE;
                }
            }
        }
        return STRATEGY_NORMAL;
    }


    private String getCurrentDate() {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");// HH:mm:ss
        Date date = new Date(System.currentTimeMillis());
        return simpleDateFormat.format(date);
    }


    //方向不明
    private InsertOrder getStrategyOrderInfo(char direct) {
        //获取账户
        EsLoginAccountData.LoginAccount login = EsLoginAccountData.getInstance().getCurrentAccount();
        if (login == null) {
            return null;
        }
        //获取合约
        EsStrategyData data = EsStrategyData.getInstance();
        if (data.getSelectedContract() == null) {
            return null;
        }
        InsertOrder orderParent = EsInsertOrderHelper.defaultOrder(this, login.getCompanyNo(), login.getUserNo(), login.getAddrTypeNo(), data.getSelectedContract().getContractNo());
        orderParent.setStrategyType(EsDataConstant.S_ST_CONDITION);
        orderParent.setDirect(direct);

        if (data.isPrice()) {
            //价格条件
            orderParent.setTriggerPrice(Double.parseDouble(EsDataApi.getDoubleStrFromFractionStr(mInputs.getPriceStrCondition(), data.getSelectedContract().getCommodity().getPriceDeno())));
            orderParent.setTriggerMode(data.getTriggerMode());
            orderParent.setTriggerCondition(data.getTriggerCondition());
        } else {
            //开盘触发
            if (data.isOpenTrigger()) {
                orderParent.setStrategyType(EsDataConstant.S_ST_AUTOORDER);
            } else {
                orderParent.setTimeCondition(mInputs.getTimeCondition());
            }
        }

        if (data.isBonus() && !data.isOpenTrigger()) {
            //附加条件
            orderParent.setTriggerPrice2(Double.parseDouble(EsDataApi.getDoubleStrFromFractionStr(mInputs.getPriceStrBonusCondition(), data.getSelectedContract().getCommodity().getPriceDeno())));
//            orderParent.setTriggerPrice2(strPriceToDouble(mInputs.getPriceStrBonusCondition()));
            orderParent.setTriggerMode2(data.getBonusTriggerMode());
            orderParent.setTriggerCondition2(data.getBonusTriggerCondition());
        }
        //获取数量
        orderParent.setOrderQty(BigInteger.valueOf(Long.parseLong(mInputs.getQty())));

        //设置开平
        if (data.getSelectedContract().isForeignContract()) {
            orderParent.setOffset(EsDataConstant.S_OFFSET_NONE);
        } else {
            if (data.isOpen()) {
                orderParent.setOffset(EsDataConstant.S_OFFSET_OPEN);
            } else if (EsDataApi.isCoverTContract(data.getSelectedContract().getCommodity()) && EsSPHelperProxy.getIsCloseT(getApplicationContext())) {
                orderParent.setOffset(EsDataConstant.S_OFFSET_COVERT);
            } else {
                orderParent.setOffset(EsDataConstant.S_OFFSET_COVER);
            }
        }

        //设置长期有效还是当日有效
        if (data.isOpenTrigger()) {
            // 自动单只能当日有效
            orderParent.setValidType(EsDataConstant.S_VALIDTYPE_GFD);//长期
        } else {
            if (data.isToday()) {
                orderParent.setValidType(EsDataConstant.S_VALIDTYPE_GFD);
            } else {
                orderParent.setValidType(EsDataConstant.S_VALIDTYPE_GTC);
            }
        }

        //设置价格类型（对手价、绝对价、市价，超价）
        orderParent.setOrderPriceType(data.getConditionOrderPriceType());
        if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_ABS) {
            orderParent.setOrderPrice(String.valueOf(strPriceToDouble(mInputs.getPriceStrOrder(), direct)));
        } else if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_MARKET) {
            Contract contract = data.getSelectedContract();
            if (!EsDataApi.isMarketPriceAvailable(contract) && !EsSPHelper.getMarketPriceSetting(getApplicationContext())) {
                // 非市价合约取市价时，根据涨跌停价格下单
                orderParent.setOrderPriceType(EsDataConstant.S_PT_ABS);
                QuoteBetData quoteBetData = new QuoteBetData(contract);
                if (direct == EsDataConstant.S_DIRECT_BUY) {
                    orderParent.setOrderPrice(quoteBetData.getLimitUpPriceString());
                } else {
                    orderParent.setOrderPrice(quoteBetData.getLimitDownPriceString());
                }
            } else {
                orderParent.setOrderPriceType(EsDataConstant.S_PT_MARKET);
            }
        } else {
            int flag = 1;
            if (!data.isOrderPlusAdd()) {
                flag = -1;
            }
            orderParent.setOrderPriceOver(Integer.parseInt(mInputs.getPointStrOrder()) * data.getSelectedContract().getCommodity().getTickPrice() * flag);
        }
        return orderParent;
    }

    private void insertStrategyOrderWithMessages(final InsertOrder orderParent) {
        EsStrategyData data = EsStrategyData.getInstance();
        //需要显示的信息
        //下单提示信息
        String contractNameStr = mInputs.getContractStr();

        String qtyStr = mInputs.getQty();
        String directStr = EstarTransformation.Direct2BuySellString(getBaseContext(), orderParent.getDirect());
        String offsetStr = EstarTransformation.Offset2String(getBaseContext(), orderParent.getOffset());
        String conditionStr;
        if (data.isPrice()) {
            conditionStr = getResources().getString(R.string.es_strategy_condition_type_price);
            conditionStr += ":";
            conditionStr = conditionStr + EstarTransformation.triggerModeType2Str(getBaseContext(), orderParent.getTriggerMode()) + EstarTransformation.conditionCompareType2Str(orderParent.getTriggerCondition()) + EsDataApi.formatPrice(orderParent.getContract().getCommodity(), orderParent.getTriggerPrice());
        } else {
            if (data.isOpenTrigger()) {
                conditionStr = getResources().getString(R.string.es_strategy_input_auto_order);
            } else {
                conditionStr = getResources().getString(R.string.es_strategy_condition_type_time);
                conditionStr += ":";
                conditionStr += mInputs.getTimeCondition();
            }
        }
        String formatStr = "%s %s%s %s" + getString(R.string.es_position_stop_loss_lots) + "\n%s";
        StringBuilder insertMessages = new StringBuilder(String.format(Locale.getDefault(), formatStr, contractNameStr, directStr, offsetStr, qtyStr, conditionStr));
        String bonusMessage = "";
        if (data.isBonus() && !data.isOpenTrigger()) {
            String conditionBonusStr = EstarTransformation.triggerModeType2Str(getBaseContext(), orderParent.getTriggerMode2()) + EstarTransformation.conditionCompareType2Str(orderParent.getTriggerCondition2()) + EsDataApi.formatPrice(orderParent.getContract().getCommodity(), orderParent.getTriggerPrice2());
            bonusMessage = String.format(Locale.getDefault(), "\n%s:%s", getResources().getString(R.string.es_activity_condition_order_bonus_condition), conditionBonusStr);
        }
        insertMessages.append(bonusMessage);


        String orderPriceMessage = getResources().getString(R.string.es_activity_condition_order_orderPrice) + ":";
        if (orderParent.getOrderPriceType() == EsDataConstant.S_PT_ABS) {
            //指定价
            orderPriceMessage += EsDataApi.formatPrice(orderParent.getContract().getCommodity(), Double.valueOf(orderParent.getOrderPrice()));
        } else if (orderParent.getOrderPriceType() == EsDataConstant.S_PT_MARKET) {
            //市价
            orderPriceMessage += EstarTransformation.apiPriceTypeToStr(getBaseContext(), orderParent.getOrderPriceType());
        } else {
            //最新价、排队价、对手价
            String plus;
            if (data.isOrderPlusAdd()) {
                plus = "+";
            } else {
                plus = "-";
            }
            orderPriceMessage += EstarTransformation.apiPriceTypeToStr(getBaseContext(), orderParent.getOrderPriceType());
            orderPriceMessage = orderPriceMessage + plus + mInputs.getPointStrOrder() + getString(R.string.es_strategy_condition_list_tick);
        }
        insertMessages.append("\n").append(orderPriceMessage);

        //修改提示：美玉米1812 买 1 手 \n 价格条件单：最新价>= 357.75 \n 委托价格：对手价 + 1点

        String stopLPMessage = "";

        if (data.getStrategyType() != EsStrategyData.mST.None && data.getStrategyType() != EsStrategyData.mST.Float) {
            if (data.getStrategyType() != EsStrategyData.mST.StopP) {//止损行
                stopLPMessage += "\n" + getString(R.string.es_activity_strategy_additional_stop_loss);
                if (data.getStrategyType() == EsStrategyData.mST.SpecifiedStopLP) {
                    stopLPMessage += getString(R.string.es_activity_strategy_price);
                } else {
                    stopLPMessage += getString(R.string.es_activity_strategy_price_difference);
                }
                stopLPMessage += mInputs.getPriceStrStopLoss();
                String orderLossPriceMessage = getString(R.string.es_activity_strategy_additional_delegate_price);
                if (data.getStopLossOrderPriceType() == EsDataConstant.S_PT_ABS) {
                    orderLossPriceMessage += mInputs.getPriceStrStopLossOrder();
                } else {
                    orderLossPriceMessage += mInputs.getPriceTypeStrStopLossOrder();
                    orderLossPriceMessage = orderLossPriceMessage + "+" + mInputs.getPointStrStopLossOrder();

                }
                stopLPMessage += orderLossPriceMessage;
            }

            if (data.getStrategyType() != EsStrategyData.mST.StopL) {//止盈行
                stopLPMessage += "\n" + getString(R.string.es_activity_strategy_additional_stop_profit);
                if (data.getStrategyType() == EsStrategyData.mST.SpecifiedStopLP) {
                    stopLPMessage += getString(R.string.es_activity_strategy_price);
                } else {
                    stopLPMessage += getString(R.string.es_activity_strategy_price_difference);
                }
                stopLPMessage += mInputs.getPriceStrStopProfit();
                String orderProfitPriceMessage = getString(R.string.es_activity_strategy_additional_delegate_price);
                if (data.getStopProfitOrderPriceType() == EsDataConstant.S_PT_ABS) {
                    orderProfitPriceMessage += mInputs.getPriceStrStopProfitOrder();
                } else {
                    orderProfitPriceMessage += mInputs.getPriceTypeStrStopProfitOrder();
                    orderProfitPriceMessage = orderProfitPriceMessage + "+" + mInputs.getPointStrStopProfitOrder();

                }
                stopLPMessage += orderProfitPriceMessage;
            }
        } else if (data.getStrategyType() == EsStrategyData.mST.Float) {
            stopLPMessage += "\n" + getString(R.string.es_activity_strategy_additional_float_stop_loss);
            stopLPMessage += mInputs.getPriceStrStopLoss();
            String orderLossPriceMessage = getString(R.string.es_activity_strategy_additional_delegate_price);
            if (data.getStopLossOrderPriceType() == EsDataConstant.S_PT_ABS) {
                orderLossPriceMessage += mInputs.getPriceStrStopLossOrder();
            } else {
                orderLossPriceMessage += mInputs.getPriceTypeStrStopLossOrder();
                orderLossPriceMessage = orderLossPriceMessage + "+" + mInputs.getPointStrStopLossOrder();

            }
            stopLPMessage += orderLossPriceMessage;
        }

        insertMessages.append(stopLPMessage);

        char offset = orderParent.getOffset();

        final boolean hasStopLoss = data.hasStopLoss();
        if (offset == EsDataConstant.S_OFFSET_COVERT || offset == EsDataConstant.S_OFFSET_COVER) {
            if (mInputs.isReverse()) {
                orderParent.setStrategyType(EsDataConstant.S_ST_BACKHAND);
                insertMessages.append("\n").append(getString(R.string.es_strategy_input_bonus));
                insertMessages.append(":");
                insertMessages.append(getString(R.string.es_activity_strategy_reverse));
            }
        } else if (hasStopLoss) {
            List<OpenOrder> list = data.getStopLossList();
            for (OpenOrder openOrder : list) {
                String text = "\n" + getString(R.string.es_strategy_input_bonus);
                char strategyType = openOrder.getStrategyType();
                double stopPrice = openOrder.getStopPrice();
                if (strategyType == EsDataConstant.S_ST_STOPLOSS) {
                    text += getString(R.string.es_stop_loss_open_dialog_condition_stop_loss);
                    text += ":";
                    text += getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_loss);
                } else if (strategyType == EsDataConstant.S_ST_STOPPROFIT) {
                    text += getString(R.string.es_stop_loss_open_dialog_condition_stop_profit);
                    text += ":";
                    text += getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_profit);
                }  else if (strategyType == EsDataConstant.S_ST_FLOATSTOPLOSS) {
                    text += getString(R.string.es_stop_loss_open_dialog_condition_stop_loss);
                    text += ":";
                    text += getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_loss_diff);
                } else if (strategyType == EsDataConstant.S_ST_BREAKEVEN) {
                    text += getString(R.string.es_stop_loss_open_dialog_condition_keep);
                    text += ":";
                    text += getString(R.string.es_stop_loss_open_dialog_strategy_type_stop_profit_diff);
                }

                text += String.valueOf(stopPrice);

                insertMessages.append(text);
            }
        }

        //以上显示大概如下：
        //CF801 3手买开 价格(时间)条件:最新价>19800
        // \n 附加条件:卖价<20000 委托价格:最新价超1点（或指定价格)
        // \n 附加停损方式:限价止损+限价止盈
        // \n 附加止损:价差100（或者止损价格19800如果是指定价止损）（委托同上）
        // \n 附加止盈:（同附加止损）

        //下条件单
        final EsCustomDialog dialog = EsCustomDialog.create(this);
        dialog.setTitle(getString(R.string.es_view_trade_threekey_message_title))
                .setCancelable(false)
                .setContent(insertMessages.toString())
                .setClickListener(new EsCustomDialog.EsDialogClickListener() {
            @Override
            public void onConfirm() {
                // 如果是条件单改单，那么需要先撤单，然后再下单，正常改单直接下单
                mIsRevoke = false;
                if (mIsModify) {
                    EsDataApi.deleteTradeOrder(mModifyOrderData);
                    mIsRevoke = true;
                }
                int ret;
                if (orderParent.getOffset() == EsDataConstant.S_OFFSET_OPEN || orderParent.getOffset() == EsDataConstant.S_OFFSET_NONE) {
                    if (hasStopLoss) {
                        ret = insertStopLPOrders(orderParent);
                    } else {
                        ret = EsDataApi.openTradeOrder(orderParent);
                    }
                } else if (orderParent.getOffset() == EsDataConstant.S_OFFSET_COVERT) {
                    ret = EsDataApi.coverTradeOrder(orderParent, true);
                } else {
                    ret = EsDataApi.coverTradeOrder(orderParent, false);
                }

                if (ret >= 0) {
                    // TODO 去掉该逻辑
//                    insertStopLPOrders(orderParent, ret);
                    finish();
                }
                dialog.dismiss();
            }

            @Override
            public void onCancel() {
                dialog.dismiss();
            }
        }).show();
    }

    private int insertStopLPOrders(InsertOrder orderParent)  {
        List<OpenOrder> list = EsStrategyData.getInstance().getStopLossList();
        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        InsertOrder order1 = null, order2 = null, order3 = null;
        char strategyDirect = orderParent.getDirect() == EsDataConstant.S_DIRECT_BUY ? EsDataConstant.S_DIRECT_SELL : EsDataConstant.S_DIRECT_BUY;
        for (OpenOrder order : list) {
            char type = order.getStrategyType();
            if (type == EsDataConstant.S_ST_STOPLOSS || type == EsDataConstant.S_ST_FLOATSTOPLOSS) {
                order1 = openOrderToInsertOrder(order, strategyDirect, orderParent.getOrderQty(), account, contract);
                if (type == EsDataConstant.S_ST_FLOATSTOPLOSS) {
                    // 浮动止损需要添加触发价setTriggerPrice
                    int flag = strategyDirect == EsDataConstant.S_DIRECT_BUY ? 1 : -1;
                    order1.setTriggerPrice(order1.getStopPrice() * flag);
                    order1.setStopPriceType(EsDataConstant.S_SPT_DIFF);
                }
            } else if (type == EsDataConstant.S_ST_STOPPROFIT) {
                order2 = openOrderToInsertOrder(order, strategyDirect, orderParent.getOrderQty(), account, contract);
            } else if (type ==  EsDataConstant.S_ST_BREAKEVEN) {
                order3 = openOrderToInsertOrder(order, strategyDirect, orderParent.getOrderQty(), account, contract);
            }
        }

        return EsDataApi.openWithStopLossOrder(orderParent, order1, order2, order3);
    }

    private InsertOrder openOrderToInsertOrder(OpenOrder openOrder, char direct, BigInteger orderQty, EsLoginAccountData.LoginAccount account, Contract contract) {

        InsertOrder insertOrder = EsInsertOrderHelper.defaultOrder(this, account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo(), contract.getContractNo());
        insertOrder.setStrategyType(openOrder.getStrategyType());
        insertOrder.setOffset(openOrder.getOffset());
        insertOrder.setOrderPriceType(openOrder.getOrderPriceType());
        insertOrder.setOrderPriceOver(openOrder.getOrderPriceOver());
        insertOrder.setOrderType(openOrder.getOrderType());
        insertOrder.setOrderPrice(String.valueOf(EsDataApi.formatOrderPrice(contract, String.valueOf(openOrder.getOrderPrice()), direct)));
        insertOrder.setValidType(openOrder.getValidType());
        insertOrder.setStopPrice(EsDataApi.formatOrderPrice(contract, String.valueOf(openOrder.getStopPrice()), direct));
        insertOrder.setStopPriceType(openOrder.getStopPriceType());
        insertOrder.setDirect(direct);
        insertOrder.setOrderQty(orderQty);
        // 因为保本单的stopPrice是价差，防止PTA这种最小变动价为2，但是止盈价差为1，会造成对价差取整为0，然后相加价格没有变动的情况
        if (openOrder.getStrategyType() == EsDataConstant.S_ST_OPEN_BREAKEVEN) {
            insertOrder.setStopPrice(openOrder.getStopPrice());
        }

        return insertOrder;
    }

    private void insertStopLPOrders(InsertOrder orderParent, int ret) {
        if (orderParent.getOffset() == EsDataConstant.S_OFFSET_COVER) {//注意：平仓条件单不附加止损止盈！！！！
            return;
        }
        EsStrategyData data = EsStrategyData.getInstance();
        //止损止盈，限价止损止盈，止损，止盈
        if (data.getStrategyType() == EsStrategyData.mST.SpecifiedStopLP || data.getStrategyType() == EsStrategyData.mST.StopLP || data.getStrategyType() == EsStrategyData.mST.StopL || data.getStrategyType() == EsStrategyData.mST.StopP) {
            //止损单
            if (data.getStrategyType() != EsStrategyData.mST.StopP) {
                InsertOrder stopOrder = defaultStopOrderFromParentConditionOrder(orderParent);
                stopOrder.setStrategyType(EsDataConstant.S_ST_STOPLOSS);
                if (data.getStrategyType() == EsStrategyData.mST.SpecifiedStopLP) {
                    stopOrder.setStopPriceType(EsDataConstant.S_SPT_PRICE);
                } else {
                    stopOrder.setStopPriceType(EsDataConstant.S_SPT_DIFF);
                }
                stopOrder.setStopPrice(strPriceToDouble(mInputs.getPriceStrStopLoss(), orderParent.getDirect()));

                stopOrder.setOrderPriceType(data.getStopLossOrderPriceType());
                if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_ABS) {
                    stopOrder.setOrderPrice(String.valueOf(strPriceToDouble(mInputs.getPriceStrStopLossOrder(), orderParent.getDirect())));
                } else if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_MARKET) {
                    //do nothing
                } else {
                    stopOrder.setOrderPriceOver(Integer.parseInt(mInputs.getPointStrStopLossOrder()) * data.getSelectedContract().getCommodity().getTickPrice());
                }
                //存止损单
                saveStopOrders(ret, stopOrder);
            }
            //止盈单
            if (data.getStrategyType() != EsStrategyData.mST.StopL) {
                InsertOrder stopOrder = defaultStopOrderFromParentConditionOrder(orderParent);
                stopOrder.setStrategyType(EsDataConstant.S_ST_STOPPROFIT);
                if (data.getStrategyType() == EsStrategyData.mST.SpecifiedStopLP) {
                    stopOrder.setStopPriceType(EsDataConstant.S_SPT_PRICE);
                } else {
                    stopOrder.setStopPriceType(EsDataConstant.S_SPT_DIFF);
                }
                stopOrder.setStopPrice(strPriceToDouble(mInputs.getPriceStrStopProfit(), orderParent.getDirect()));

                stopOrder.setOrderPriceType(data.getStopProfitOrderPriceType());
                if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_ABS) {
                    stopOrder.setOrderPrice(String.valueOf(strPriceToDouble(mInputs.getPriceStrStopProfitOrder(), orderParent.getDirect())));
                } else if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_MARKET) {
                    //do nothing
                } else {
                    stopOrder.setOrderPriceOver(Integer.parseInt(mInputs.getPointStrStopProfitOrder()) * data.getSelectedContract().getCommodity().getTickPrice());
                }
                //存止赢单
                saveStopOrders(ret, stopOrder);
            }
        } else if (data.getStrategyType() == EsStrategyData.mST.Float) {//浮动回撤止损
            InsertOrder stopOrder = defaultStopOrderFromParentConditionOrder(orderParent);
            stopOrder.setStrategyType(EsDataConstant.S_ST_FLOATSTOPLOSS);
            stopOrder.setStopPriceType(EsDataConstant.S_SPT_DIFF);
            stopOrder.setStopPrice(strPriceToDouble(mInputs.getPriceStrStopLoss(), orderParent.getDirect()));
            stopOrder.setOrderPriceType(data.getStopLossOrderPriceType());
            if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_ABS) {
                stopOrder.setOrderPrice(String.valueOf(strPriceToDouble(mInputs.getPriceStrStopLossOrder(), orderParent.getDirect())));
            } else if (data.getConditionOrderPriceType() == EsDataConstant.S_PT_MARKET) {
                //do nothing
            } else {
                stopOrder.setOrderPriceOver(Integer.parseInt(mInputs.getPointStrStopLossOrder()) * data.getSelectedContract().getCommodity().getTickPrice());
            }
            //存浮动止损单
            saveStopOrders(ret, stopOrder);
        }
    }

    private void showErrorText(@StringRes int titleID, @StringRes int contentID) {
        if (mTipsDialog == null) {
            mTipsDialog = new EsCustomTipsDialog(this, getString(titleID), getString(contentID));
            mTipsDialog.setCancelable(false);
        }
        if (!mTipsDialog.isShowing()) {
            mTipsDialog.show();
        }
        mTipsDialog.setTitle(getString(titleID));
        mTipsDialog.setContent(getString(contentID));
    }

    private void showNoticeText(final InsertOrder insert){
        EsCustomDialog dialog = EsCustomDialog.create(this);
        dialog.setTitle(this.getString(R.string.es_login_password_notice))
                .setContent(this.getString(R.string.es_kline_draw_line_order_dialog_invalid_price_info_warnning))
                .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                    @Override
                    public void onConfirm() {
                        inputStrategyNormal(insert);
                    }

                    @Override
                    public void onCancel() {

                    }
                }).show();
    }

    private double strPriceToDouble(String price, char direct) {
        String tempStr = EsDataApi.getDoubleStrFromFractionStr(price, EsStrategyData.getInstance().getSelectedContract().getCommodity().getPriceDeno());
        double priceDou = Double.parseDouble(tempStr);
        EsStrategyData data = EsStrategyData.getInstance();
        int quotient = (int) (priceDou / data.getSelectedContract().getCommodity().getPriceTick());
        double modQuotient = priceDou / data.getSelectedContract().getCommodity().getPriceTick();
        if (modQuotient - quotient != 0) {//不能整除
            if (direct == EsDataConstant.S_DIRECT_BUY) {
                priceDou = quotient * data.getSelectedContract().getCommodity().getPriceTick();//买向下取整
            } else {
                priceDou = (quotient + 1) * data.getSelectedContract().getCommodity().getPriceTick();//卖向上取整
            }
        }
        return priceDou;
    }

    /**
     * 由关联父单生成的子止损止盈单的默认字段填充
     *
     * @param parentConditionOrder 父单实例
     * @return new出来的子单
     */
    private InsertOrder defaultStopOrderFromParentConditionOrder(InsertOrder parentConditionOrder) {
        InsertOrder stopOrder = EsInsertOrderHelper.defaultOrder(this, parentConditionOrder.getCompanyNo(), parentConditionOrder.getUserNo(), parentConditionOrder.getAddressNo(), parentConditionOrder.getContractNo());
        stopOrder.setOrderQty(parentConditionOrder.getOrderQty());
        if (parentConditionOrder.getOffset() == EsDataConstant.S_OFFSET_NONE) {
            stopOrder.setOffset(EsDataConstant.S_OFFSET_NONE);
        } else {
            stopOrder.setOffset(EsDataConstant.S_OFFSET_COVER);
        }
        stopOrder.setValidType(parentConditionOrder.getValidType());
        return stopOrder;
    }

    private void saveStopOrders(long parentConditionOrderReqId, InsertOrder savedOrder) {
        savedOrder.setParentReqId(parentConditionOrderReqId);
        EsStrategyData.getInstance().saveStopOrders(savedOrder);
    }

    @Override
    public void OnSwitch(boolean isPrice) {
        //切换价格时间条件单
        mInputs.switchPriceAndTime(isPrice);
        EsStrategyData.getInstance().setPrice(isPrice);
//        if (EsStrategyData.getInstance().isBonus()) {
            // 去掉附加条件
            EsStrategyData.getInstance().setIsBonus(false);
            mInputs.showBonusLine(false);
//        }

        mInputs.showTimeConditionUI();
        mInputs.updateStopRl();
    }

    @Override
    public void onDataQuote() {
        EsStrategyData boardData = EsStrategyData.getInstance();
        if (boardData.getSelectedContract() == null) {
            return;
        }
        mPanel.setDataOnView(boardData.getmBuyPrice(), boardData.getmSellPrice(), boardData.getmLastPrice(), boardData.getmBuyQty(), boardData.getmSellQty(), boardData.getmLastQty(), boardData.getmPreSettlePrice());
        mPanel.setImpPriceQty(boardData.isImpBidPrice(), boardData.isImpAskPrice(), boardData.isImpBidQty(), boardData.isImpAskQty());
    }

    @Override
    public void onSetContract(Contract contract) {
        onDataQuote();
        // 只有非改单时需要将触发价格使用合约的最新价，改单则使用订单的触发价。
        if (!mIsModify) {
            mInputs.refreshPrices(EsStrategyData.getInstance().getmLastPrice());
        }
    }

    @Override
    public void refreshQty(boolean refresh) {
        if (refresh) {
            Contract contract = EsStrategyData.getInstance().getSelectedContract();
            if (contract != null && !contract.isForeignContract() && !EsStrategyData.getInstance().isOpen()) {
                EsLoginAccountData.LoginAccount login = EsLoginAccountData.getInstance().getCurrentAccount();
                String companyNo = login.getCompanyNo();
                String userNo = login.getUserNo();
                String addrNo = login.getAddrTypeNo();
                char hedge = EsSPHelperProxy.getIsHedge(this) ? EsDataConstant.S_HEDGE_HEDGE : EsDataConstant.S_HEDGE_SPECULATE;
                long buyQty = 0, sellQty = 0;
                AvailableQty availableBuyQty = EsDataApi.getAvailableQty(contract, EsDataConstant.S_DIRECT_SELL, hedge, companyNo, userNo, addrNo);
                AvailableQty availableSellQty = EsDataApi.getAvailableQty(contract, EsDataConstant.S_DIRECT_BUY, hedge, companyNo, userNo, addrNo);
                if (availableBuyQty != null) {
                    buyQty = availableBuyQty.getAvailable().longValue();
                }
                if (availableSellQty != null) {
                    sellQty = availableSellQty.getAvailable().longValue();
                }
                mOffsetBuy.setText(String.valueOf(buyQty));
                mOffsetSell.setText(String.valueOf(sellQty));
                mOffsetLL.setVisibility(View.VISIBLE);
            }
        } else {
            mOffsetLL.setVisibility(View.GONE);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage eventMessage) {
        int action = eventMessage.getAction();
        if (eventMessage.getSender() == EsEventConstant.E_STAR_MODULE_SEARCH) {
            if (action == EsEventConstant.E_STAR_ACTION_SELECT_OPTION) {
                try {
                    if (EsStrategyData.KEY_SEARCH_SOURCE.equals(eventMessage.getData())) {
                        mInputs.setContract(eventMessage.getContent());

                        Contract contract = EsDataApi.getQuoteContract(eventMessage.getContent());
                        EsFavoriteListData.getInstance().addFavoriteContract(contract, false);
                    }
                } catch (ClassCastException e) {
                    EsLog.e(TAG, "onNotification", e);
                }
            }
        }
        if (action == EsEventConstant.E_STAR_ACTION_NOTIFY_TRADE_LOGOUT) {
            EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
            if (account == null){
                finish();
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();
        String companyNo = event.getCompanyNo();
        String userNo = event.getUserNo();
        String addrNo = event.getAddressNo();

        if (action == EsDataConstant.S_SRVEVENT_TRADE_POSITION) {
            if (EsLoginAccountData.getInstance().isCurrentAccount(companyNo, userNo, addrNo)) {
                refreshQty(true);
            }
        } else if (action == EsDataConstant.S_SRVEVENT_TRADE_ORDER) {
            if (!EsLoginAccountData.getInstance().isCurrentAccount(companyNo, userNo, addrNo)) {
                return;
            }

            OrderData orderData = (OrderData) event.getData();
            if (orderData != null &&
                    (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_QUEUED
                            || orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_CANCELED
                            || orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTCANCELED)) {//排队、撤单状态触发持仓"可用"字段变化
                refreshQty(true);
            }
        } else if (action == EsDataConstant.S_SRVEVENT_CONNECT) {
            EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
            if (loginAccount != null) {
                refreshQty(true);
            } else {
                refreshQty(false);
            }
        } else if (action == EsDataConstant.S_SRVEVENT_DISCONNECT) {
            refreshQty(false);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}
