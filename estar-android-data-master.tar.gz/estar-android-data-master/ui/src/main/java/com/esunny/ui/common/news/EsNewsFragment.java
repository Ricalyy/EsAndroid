package com.esunny.ui.common.news;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsWebApi;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.bean.EsNewsData;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.util.EsLog;
import com.esunny.data.api.EsDataTrackApi;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseFragment;
import com.esunny.ui.common.setting.quote.login.EstarLoginActivity;
import com.esunny.ui.data.EsBadgeDataManger;
import com.esunny.ui.data.setting.EsMessageData;
import com.esunny.ui.dialog.EsCustomDialog;
import com.esunny.ui.util.ButtonUtils;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.util.imageuitl.ImageLoader;
import com.esunny.ui.util.imageuitl.ProgressLoadListener;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsDateSelectKeyboardDialog;
import com.esunny.ui.view.calendarPicker.CalendarUtil;
import com.github.chrisbanes.photoview.PhotoView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import butterknife.BindView;
import butterknife.OnClick;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

@Route(path = RoutingTable.ES_NEWS_FRAGMENT)
public class EsNewsFragment extends EsBaseFragment {

    private final static String TAG = "EsNewsFragment";

    private EsBaseToolBar mToolBar;

    final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    List<EsNewsData> mNewsDatas = new ArrayList<>();
    TreeSet<EsNewsData> mNewsDataSet;
    EsNewsAdapter mNewsAdapter;
    // 在Recyclerview中使用该Adapter
    EsNewsWrapperAdapter mNewsWrapperAdapter;
    Handler mHander = new Handler(Looper.getMainLooper());
    //    ListPopupWindow listPopupWindow;
    List<String> mNewsSearchContentList = new ArrayList<>();
    private List<String> mSearchRecord = new ArrayList<>(3);
    // NewsTagKey中每个字Tag对应的TagIndex的列表
    private Map<String, List<String>> tagListMap = new HashMap<>();
    // TagIndex对应TagName的映射表
    private Map<String, String> tagNameMap = new HashMap<>();
    // 搜索的内容对应的TagName
    private String mSelectTagName = "";
    // 是否清空数据
    private boolean isClean = false;
    // 上拉调用刷新全部最新数据,是否之前搜索过TagName
    private boolean mNeedClean = false;
    // 搜索咨询的日期
    private String selectTime = "";
    // 是否是点击获取tagname
    private boolean isNameAboutClick = false;
    // 搜索输入的内容
    private String mSearchText = "";

    @BindView(R2.id.es_news_rv_news)
    RecyclerView mRvNews;
    @BindView(R2.id.es_news_srl_container)
    SwipeRefreshLayout mSRLContainer;
    @BindView(R2.id.et_news_et_search)
    EditText mEtSearch;
    @BindView(R2.id.es_news_lv_search_tag)
    ListView mLvSearch;
    @BindView(R2.id.es_news_ll_search_tag)
    LinearLayout mLlSearch;
    @BindView(R2.id.es_news_rl_pic)
    RelativeLayout mRlPic;
    @BindView(R2.id.es_news_iv_pic)
    PhotoView mPvPic;
    @BindView(R2.id.es_activity_bill_query_tv_date)
    TextView mTvDate;
    @BindView(R2.id.search_record)
    LinearLayout mLlSearchRecord;
    @BindView(R2.id.search_record_one)
    TextView mRecordTv1;
    @BindView(R2.id.search_record_two)
    TextView mRecordTv2;
    @BindView(R2.id.search_record_three)
    TextView mRecordTv3;

    @Override
    protected int getLayoutId() {
        return R.layout.es_quote_fragment_news;
    }

    @Override
    protected void initWidget(View root) {
        super.initWidget(root);

        initTreeSet();
        initToolbar();
        initTime();
        initListView();
        initRecyclerView();
        initSwipeRefreshLayout();
        initSearchView();
        initPhotoView();
        initSearchRecord();
    }


    private void initTreeSet() {
        mNewsDataSet = new TreeSet<>(new Comparator<EsNewsData>() {
            @Override
            public int compare(EsNewsData esNewsData1, EsNewsData esNewsData2) {
                return esNewsData2.getNewsID() - esNewsData1.getNewsID();
            }
        });
    }

    private void initPhotoView() {
        mPvPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!ButtonUtils.isFastDoubleClick(v.getId())) {
                    mRlPic.setVisibility(View.GONE);
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        getNewsTag();
        getNews(0, true, selectTime);
    }

    @Override
    public void onPause() {
        super.onPause();
        saveRecord();
    }

    private void initTime() {
        String time = initDate();
        mTvDate.setText(time);
    }

    private void initListView() {
        mLvSearch.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String name = tagNameMap.get(mNewsSearchContentList.get(position));
                if (name != null) {
                    hideSoftInput();
                    hideSearchRecord();
                    dealAddRecord(name);
                    isClean = !mSelectTagName.equals(name);
                    mSelectTagName = name;
                    mNeedClean = true;
                    mEtSearch.setText(mSelectTagName);
                    mEtSearch.setSelection(mEtSearch.getText().toString().length());
                    recordSearch(mSearchText, mSelectTagName);
                    mLlSearch.setVisibility(View.GONE);
                    getNewsAboutName(0, isClean, true, selectTime);
                }
            }
        });
    }

    private void dealAddRecord(String s) {
        String string = mSearchRecord.toString();
        if (!string.contains(s)) {
            mSearchRecord.add(0, s);
            mSearchRecord.remove(mSearchRecord.size() - 1);
        }
    }

    private void initSearchRecord() {
        String str = EsSPHelper.getNewsSearchRecord(mContext);
        String[] strings = str.split("\\+");
        if (str.length() > 0) {
            mSearchRecord.addAll(Arrays.asList(strings));
            for (int i = strings.length; i < 3; i++) {
                mSearchRecord.add("");
            }

            showSearchRecord();
        } else {
            hideSearchRecord();
            for (int i = 0; i < 3; i++) {
                mSearchRecord.add("");
            }
        }
    }

    private void saveRecord() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < mSearchRecord.size(); i++) {
            if (mSearchRecord.get(i).isEmpty()) {
                continue;
            }
            stringBuilder.append(mSearchRecord.get(i));
            if (i < mSearchRecord.size()) {
                stringBuilder.append("+");
            }
        }
        String str = stringBuilder.toString();
        if (str.endsWith("+")) {
            str = str.substring(0, str.length() - 1);
        }

        EsSPHelper.setNewsSearchRecord(mContext, str);
    }

    private void initSearchView() {
        mEtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!isNameAboutClick) {
                    mNewsSearchContentList = getNewsTagIndexList(s.toString());
                    if (mEtSearch.getText().toString().trim().length() > 0) {
                        mSearchText = mEtSearch.getText().toString();
                        mLlSearchRecord.setVisibility(View.GONE);
                        if (mEtSearch.hasFocus()) {
                            mLvSearch.setAdapter(new ArrayAdapter<>(getContext(), R.layout.es_news_search_item, mNewsSearchContentList));
                            mLlSearch.setVisibility(View.VISIBLE);
                            mEtSearch.setFocusable(true);
                            mEtSearch.requestFocus();
                        }
                    } else {
                        mSelectTagName = "";
                        mLlSearch.setVisibility(View.GONE);
                        showSearchRecord();
                    }
                }
            }
        });
    }

    private void showSearchRecord() {
        mLlSearchRecord.setVisibility(View.VISIBLE);
        mRecordTv1.setText(mSearchRecord.get(0));
        mRecordTv2.setText(mSearchRecord.get(1));
        mRecordTv3.setText(mSearchRecord.get(2));
        ViewGroup.MarginLayoutParams params1 = (ViewGroup.MarginLayoutParams)mSRLContainer.getLayoutParams();
        params1.setMargins(0,(int) mContext.getResources().getDimension(R.dimen.x381),0,0);
        mSRLContainer.setLayoutParams(params1);
    }

    private void hideSearchRecord() {
        mLlSearchRecord.setVisibility(View.GONE);
        ViewGroup.MarginLayoutParams params1 = (ViewGroup.MarginLayoutParams)mSRLContainer.getLayoutParams();
        params1.setMargins(0,(int) mContext.getResources().getDimension(R.dimen.x281),0,0);
        mSRLContainer.setLayoutParams(params1);
    }

    private List<String> getNewsTagIndexList(String searchContent) {
        List<String> result = new ArrayList<>();
        if (searchContent == null || searchContent.isEmpty()) {
            result.add(getString(R.string.es_news_fragment_no_content));
            return result;
        }
        Set<String> key = tagListMap.keySet();
        Iterator<String> iterator = key.iterator();
        while (iterator.hasNext()) {
            String tagKey = iterator.next();
            if (tagKey.contains(searchContent.toUpperCase())) {
                result.addAll(tagListMap.get(tagKey));
            }
        }

        // 去重
        HashSet h = new HashSet(result);
        result.clear();
        result.addAll(h);

        if (result.size() == 0) {
            result.add(getString(R.string.es_news_fragment_no_content));
        }
        return result;
    }

    /**
     * 这个是获取搜索的对应标记字段的列表
     */
    private void getNewsTag() {
        EsWebApi.getNewsTag(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) {
                if (response.body() == null) {
                    return;
                }

                JSONArray jsonArray = new JSONArray();
                try {
                    jsonArray = JSONArray.parseArray(response.body().string());
                } catch (JSONException e) {
                    EsLog.d(TAG, "JSONArray.parseArray error", e);
                } catch (IOException e) {
                    EsLog.d(TAG, "getNewsTag IOException", e);
                }

                for (int i = 0; i < jsonArray.size(); i++) {
                    if (jsonArray.getJSONObject(i) == null) {
                        continue;
                    }
                    JSONArray jsonData = jsonArray.getJSONObject(i).getJSONArray("JsonRspData");
                    if (jsonData == null) {
                        continue;
                    }

                    for (int j = 0; j < jsonData.size(); j++) {
                        JSONObject object = jsonData.getJSONObject(j);
                        tagNameMap.put(object.getString("NewsTagIndex"), object.getString("NewsTagName"));

                        List<String> tagKeyList = getTagKeyList(object.getString("NewsTagKey"));
                        for (int k = 0; k < tagKeyList.size(); k++) {
                            String tagKey = tagKeyList.get(k);
                            List<String> singleTagKeyList = tagListMap.get(tagKey);
                            if (singleTagKeyList == null) {
                                singleTagKeyList = new ArrayList<>();
                            }
                            singleTagKeyList.add(object.getString("NewsTagIndex"));
                            tagListMap.put(tagKey, singleTagKeyList);
                        }
                    }
                }
            }
        });
    }

    private List<String> getTagKeyList(String newsTagKey) {
        List<String> result = new ArrayList<>();
        if (newsTagKey == null || newsTagKey.isEmpty()) {
            return result;
        }

        String[] strArray = newsTagKey.split("\\|");
        for (String str : strArray) {
            if (str == null || str.isEmpty()) {
                continue;
            }
            result.add(str);
        }
        return result;
    }

    private void initSwipeRefreshLayout() {
        mSRLContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Integer newsId = 0;
                if (mNewsDatas.size() > 0) {
                    newsId = mNewsDatas.get(0).getNewsID();
                }
                if (mSelectTagName.isEmpty()) {
                    if (mNeedClean) {
                        getNews(0, false, selectTime);
                    } else {
                        getNews(newsId, false, selectTime);
                    }
                } else {
                    getNewsAboutName(newsId, false, false, selectTime);
                }
            }
        });
    }

    private void initRecyclerView() {
        if (mRvNews == null) {
            return;
        }

        mNewsAdapter = new EsNewsAdapter(getActivity().getApplicationContext());
        mNewsWrapperAdapter = new EsNewsWrapperAdapter(mNewsAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity().getApplicationContext());

        mRvNews.setAdapter(mNewsWrapperAdapter);
        mRvNews.setLayoutManager(linearLayoutManager);
        mNewsAdapter.setOnItemClickListener(new EsNewsAdapter.ItemClickListener() {
            @Override
            public void onItemClick(int positon) {
                if (positon >= 0 && positon < mNewsDatas.size()) {
                    jumpToNewsDetail(positon);
                }
            }

            @Override
            public void onPicClick(String imgUrl) {
                ImageLoader.getInstance().loadImage(imgUrl, mPvPic, new ProgressLoadListener() {
                    @Override
                    public void update(Bitmap bitmap) {
                        mPvPic.setImageBitmap(bitmap);
                        mRlPic.setVisibility(View.VISIBLE);
                    }
                });
            }

            @Override
            public void onTagClick(String tagName) {
                if (tagName != null && !mSelectTagName.equals(tagName)) {
                    hideSoftInput();
                    hideSearchRecord();
                    dealAddRecord(tagName);
                    isClean = true;
                    mSelectTagName = tagName;
                    mNeedClean = true;
                    mEtSearch.setText(mSelectTagName);
                    mEtSearch.setSelection(mEtSearch.getText().toString().length());
                    mLlSearch.setVisibility(View.GONE);
                    recordSearch(mSelectTagName, mSelectTagName);
                    getNewsAboutName(0, isClean, true, selectTime);
                }
            }
        });

        mRvNews.addOnScrollListener(new EsNewsScrollChangeListener() {
            @Override
            public void loadMore() {
                mNewsWrapperAdapter.setLoadState(mNewsWrapperAdapter.LOADING);
                if (mSelectTagName.isEmpty()) {
                    getNews(mNewsDatas.get(mNewsDatas.size() - 1).getNewsID(), true, selectTime);
                } else {
                    getNewsAboutName(mNewsDatas.get(mNewsDatas.size() - 1).getNewsID(), false, true, selectTime);
                }
            }
        });
    }

    private void jumpToNewsDetail(int positon) {
        QuoteLoginInfo loginInfo = EsDataApi.quoteLoginInfo();
        if (loginInfo == null) {
            return;
        }
        String account = loginInfo.getLoginNo();
        EsNewsData newsData = mNewsDatas.get(positon);
        String newsTag = newsData.getNewsTag();

        if (!newsTag.contains("TC")) {
            Intent intent = new Intent(getActivity(), EsNewsDetailActivity.class);
            intent.putExtra("newsID", newsData.getNewsID());
            startActivity(intent);
        } else if (loginInfo.getErrorCode() == 0 && !account.isEmpty()) {
            // 已登录
            if (EsDataApi.hasTCPermission()) {
                Intent intent = new Intent(getActivity(), EsNewsDetailActivity.class);
                intent.putExtra("newsID", newsData.getNewsID());
                startActivity(intent);
            } else {
                EsCustomDialog dialog = EsCustomDialog.create(getContext());
                dialog.setTitle(getString(R.string.es_base_view_tips))
                        .setContent(getString(R.string.es_tc_news_unauthorized_tips))
                        .setConfirm(getString(R.string.es_quote_unauthorized_contract_purchase))
                        .setCancel(getString(R.string.es_base_view_cancel)).setCancelable(false)
                        .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                    @Override
                    public void onConfirm() {
                        if (EsDataApi.isMallLogin() && EsDataApi.isQuoteLogin()) {
                            EsUIApi.startEstarStoreActivity();
                        } else {
                            EsUIApi.startStarLoginActivity(getActivity());
                        }
                    }

                    @Override
                    public void onCancel() {
//                        finish();
                    }
                }).show();
            }
        } else {
            // 未登录
            Intent intent = new Intent(getActivity(), EstarLoginActivity.class);
            startActivity(intent);
        }
    }

    /**
     *
     * @param newsId 新闻ID
     * @param isOrder 是否是顺序添加新的数据
     */
    private void getNews(Integer newsId, final boolean isOrder, String date) {
        EsWebApi.getNews(10, date, newsId, isOrder, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) {
                if (response.body() == null) {
                    return;
                }

                JSONArray jsonArray = new JSONArray();
                try {
                    jsonArray = JSONArray.parseArray(response.body().string());
                } catch (JSONException e) {
                    EsLog.d(TAG, "JSONArray.parseArray error", e);
                } catch (IOException e) {
                    EsLog.d(TAG, "getNewsTag IOException", e);
                }

                List<EsNewsData> newsDataList = new ArrayList<>();
                JSONArray jsonData = jsonArray.getJSONObject(0).getJSONArray("JsonRspData");
                if (jsonData != null) {
                    for (int i = 0; i < jsonData.size(); i++) {
                        JSONObject innerJson = (JSONObject) jsonData.get(i);
                        newsDataList.add(JSON.parseObject(innerJson.toJSONString(), EsNewsData.class));
                        Log.d(TAG, "news title : " + innerJson.getString("NewsTitle"));
                    }
                }

                if (mNeedClean) {
                    mNeedClean = false;
                    mNewsDatas.clear();
                    mNewsDataSet.clear();
                }

                mNewsDataSet.addAll(newsDataList);
                mNewsDatas = new ArrayList<>(mNewsDataSet);

                mNewsAdapter.setListData(mNewsDatas);
                mNewsAdapter.notifyDataSetChanged();


                mHander.post(new Runnable() {
                    @Override
                    public void run() {
                        mNewsWrapperAdapter.setLoadState(mNewsWrapperAdapter.LOAD_END);

                        if (mSRLContainer != null && mSRLContainer.isRefreshing()) {
                            mSRLContainer.setRefreshing(false);
                        }
                    }
                });
            }
        });
    }

    /**
     * @param newsId 新闻ID
     * @param clean 是否需要将之前的资讯数据列表清空
     * @param isOrder 是否是顺序添加新的数据
     * @param qryDate 选择资讯数据的日期
     */
    private void getNewsAboutName(Integer newsId, final boolean clean, final boolean isOrder, String qryDate) {
        EsWebApi.getTagNews(10, mSelectTagName, newsId, qryDate, isOrder, new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) {
                if (response.body() == null) {
                    return;
                }

                JSONArray jsonArray = new JSONArray();
                try {
                    jsonArray = JSONArray.parseArray(response.body().string());
                } catch (JSONException e) {
                    EsLog.d(TAG, "JSONArray.parseArray error", e);
                } catch (IOException e) {
                    EsLog.d(TAG, "getNewsTag IOException", e);
                }
                List<EsNewsData> newsDataList = new ArrayList<>();
                JSONArray jsonData = jsonArray.getJSONObject(0).getJSONArray("JsonRspData");
                if (jsonData != null) {
                    int size = jsonData.size();
                    for (int i = 0; i < size; i++) {
                        JSONObject jsonObject = jsonData.getJSONObject(i);
                        newsDataList.add(JSON.parseObject(jsonObject.toJSONString(), EsNewsData.class));
                    }
                }

                if (clean) {
                    mNewsDatas.clear();
                    mNewsDataSet.clear();
                }

                mNewsDataSet.addAll(newsDataList);
                mNewsDatas = new ArrayList<>(mNewsDataSet);

                mNewsAdapter.setListData(mNewsDatas);
                mNewsAdapter.notifyDataSetChanged();

                mHander.post(new Runnable() {
                    @Override
                    public void run() {
                        mNewsWrapperAdapter.setLoadState(mNewsWrapperAdapter.LOAD_END);
                        if (mSRLContainer != null && mSRLContainer.isRefreshing()) {
                            mSRLContainer.setRefreshing(false);
                        }
                    }
                });
            }
        });
    }

    @OnClick(R2.id.itv_activity_search_clean_text)
    public void cleanEditText() {
        mSelectTagName = "";
        mEtSearch.setText(mSelectTagName);
        mNeedClean = true;
        if (isSearchRecordEmpty()) {
            hideSearchRecord();
        }
        getNews(0, true, selectTime);
    }

    private boolean isSearchRecordEmpty() {
        boolean isEmpty = true;
        for (String s : mSearchRecord) {
            if (!s.isEmpty()) {
                isEmpty = false;
                break;
            }
        }
        return isEmpty;
    }

    @OnClick(R2.id.es_activity_bill_query_rl_calendar)
    public void selectTime() {
        final String nowDate = initDate();
        EsDateSelectKeyboardDialog dialog = new EsDateSelectKeyboardDialog(getContext(), mTvDate, new EsDateSelectKeyboardDialog.onItemSelected() {
            @Override
            public void timeSelect(int year, int month, int day) {
                String chooseDateStr = year + "-" + CalendarUtil.dealMonthOrDay(month) + "-" + CalendarUtil.dealMonthOrDay(day);
                try {
                    if (CompareDate(chooseDateStr, nowDate)) {
                        selectTime = chooseDateStr;
                        mTvDate.setText(chooseDateStr);
                        if (mSelectTagName.isEmpty()) {
                            mNeedClean = true;
                            getNews(0, true, chooseDateStr);
                        } else {
                            getNewsAboutName(0, true, true, chooseDateStr);
                        }
                    } else {
                        ToastHelper.show(getContext(), R.string.es_activity_bill_query_error_date);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void cancel() {
                mTvDate.setText(initDate());
                selectTime = "";
                if (mSelectTagName.isEmpty()) {
                    mNeedClean = true;
                    getNews(0, true, "");
                } else {
                    getNewsAboutName(0, true, true, "");
                }
            }
        });
        dialog.setCancelTitle(getString(R.string.es_news_fragment_clear_filter));
        dialog.show();
    }

    @OnClick(R2.id.search_record_one)
    public void clickOne() {
        String s = mSearchRecord.get(0);
        if (!s.isEmpty()) {
            dealClickRecord(s);
        }
    }

    @OnClick(R2.id.search_record_two)
    public void clickTwo() {
        String s = mSearchRecord.get(1);
        if (!s.isEmpty()) {
            dealClickRecord(s);
        }
    }

    @OnClick(R2.id.search_record_three)
    public void clickThree() {
        String s = mSearchRecord.get(2);
        if (!s.isEmpty()) {
            dealClickRecord(s);
        }
    }

    @OnClick(R2.id.es_news_rl_pic)
    public void dealPhoto() {
        if (mRlPic.getVisibility() == View.VISIBLE) {
            mRlPic.setVisibility(View.GONE);
        }
    }

    @OnClick(R2.id.es_news_lv_search_tag_no_content)
    public void dealSearch() {
        if (mLlSearch.getVisibility() == View.VISIBLE) {
        }
    }

    private void dealClickRecord(String name) {
        isNameAboutClick = true;
        hideSearchRecord();
        isClean = !mSelectTagName.equals(name);
        mSelectTagName = name;
        mNeedClean = true;
        mEtSearch.setText(mSelectTagName);
        mEtSearch.setSelection(mEtSearch.getText().toString().length());
        isNameAboutClick = false;
        recordSearch(mSelectTagName, mSelectTagName);
        getNewsAboutName(0, isClean, false, selectTime);
    }

    private String initDate() {
        GregorianCalendar calendar = new GregorianCalendar();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        return year + "-" + CalendarUtil.dealMonthOrDay(month) + "-" + CalendarUtil.dealMonthOrDay(day);
    }

    private boolean CompareDate(String formerTime,String laterTime) {
        Date formerDate = null;
        Date laterDate = null;
        try {
            formerDate = format.parse(formerTime);
            laterDate = format.parse(laterTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        if (formerDate != null && laterDate != null) {
            return formerDate.getTime() - laterDate.getTime() < 0 || formerDate.getTime() - laterDate.getTime() == 0;
        } else {
            return false;
        }
    }

    private void initToolbar() {
        mToolBar = mRoot.findViewById(R.id.es_news_toolbar);
        mToolBar.setTitle(getString(R.string.es_news_title));
        mToolBar.setLeftIconVisible(false, false);
        mToolBar.setRightIcons(new int[]{R.string.es_icon_toolbar_setting});
        mToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_right_first) {
                    hideSoftInput();
                    EventBus.getDefault().post(new EsEventMessage(
                            EsEventConstant.E_STAR_MODULE_FAVORITE, EsEventConstant.E_STAR_ACTION_OPEN_RIGHT_DRAWER));
                }
            }
        });

    }

    private void hideSoftInput() {
        InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            // 通过获取原生控件windowsToken更容易，并且都是同一个token
            imm.hideSoftInputFromWindow(mToolBar.getWindowToken(), 0);
        }
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (!hidden) {
            updateBadgeView();
        }
    }

    private void updateBadgeView() {
        int type;
        if (EsMessageData.getInstance().getUnReadMessageCount(mContext) > 0
                || !EsSPHelper.getIsConnectNet(mContext) || EsSPHelper.getIsVersionLower(mContext)
                || EsBadgeDataManger.getInstance().isRightShow()) {
            mToolBar.setMessageBadgeView(View.VISIBLE);
            type = View.VISIBLE;
        } else {
            mToolBar.setMessageBadgeView(View.GONE);
            type = View.GONE;
        }

        if (EsSPHelper.getIsConnectNet(mContext)) {
            mToolBar.updateBadgeViewStrategyNum(View.VISIBLE, type);
        } else {
            mToolBar.updateBadgeViewStrategyNum(View.GONE, type);
        }
    }

    private void recordSearch(String searchText, String variety) {

        EsDataTrackApi.addNewsSearch(searchText, variety);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(EsEventMessage messageEvent) {
        int action = messageEvent.getAction();
        switch (action) {
            case EsEventConstant.E_STAR_ACTION_IS_VERSION_LOW :
            case EsEventConstant.E_STAR_ACTION_RECEIVE_UNREAD_MESSAGE :
            case EsEventConstant.E_STAR_ACTION_STRATEGY_NUM :
            case EsEventConstant.E_STAR_ACTION_LOGIN_INIT_COMPLETED :
            case EsEventConstant.E_STAR_ACTION_CHANGE_THEME :
            case EsEventConstant.E_STAR_ACTION_NOTIFY_TRADE_STATE :
                updateBadgeView();
                break;
            default:
                break;
        }
    }
}
