package com.esunny.ui.common.setting.trade;

import android.content.Intent;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsWebUrlData;
import com.esunny.ui.view.EsBaseToolBar;

import butterknife.BindView;
import butterknife.OnClick;


public class EsFingerPrinterWarningActivity extends EsBaseActivity{

    @BindView(R2.id.es_finger_printer_toolbar)
    EsBaseToolBar mToolbar;
    @BindView(R2.id.es_finger_printer_activity_content_tv)
    WebView mWebView;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_finger_printer_warning;
    }

    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindViewValue();
        initWebView();
    }

    private void bindViewValue() {
        mToolbar.setTitle(getString(R.string.es_finger_printer_warning_activity_title));
        mToolbar.setLeftIconVisible(false, false);
        mToolbar.setRightIconVisible(false, false, false);
    }

    private void initWebView() {
        mWebView.loadUrl(EsWebUrlData.getBiologicalRiskUrl(this));
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
    }

    @OnClick(R2.id.es_finger_printer_activity_cancel)
    public void dealCancel() {
        back("disagree");
    }

    @OnClick(R2.id.es_finger_printer_activity_confirm)
    public void dealConfirm() {
        back("agree");
    }

    private void back(String decision) {
        Intent intent = new Intent();
        intent.putExtra("FinalDecision", decision);
        this.setResult(RESULT_OK, intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (mWebView != null) {
            mWebView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            ((ViewGroup) mWebView.getParent()).removeView(mWebView);
            mWebView.destroy();
            mWebView = null;
        }
        super.onDestroy();
    }

}
