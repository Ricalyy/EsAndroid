package com.esunny.ui.common.setting.quote.kline;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.esunny.ui.R;

import java.util.List;


/**
 * Created by Peter on 2018/1/24.
 */

public class EsTechnicalIndexAdapter extends RecyclerView.Adapter<EsTechnicalIndexAdapter.ViewHolder> {
    Context mContext;
    List<String> mDataList;

    private int defItem = 0;
    private OnItemListener onItemListener;

    public EsTechnicalIndexAdapter(Context mContext, List<String> mDataList) {
        this.mContext = mContext;
        this.mDataList = mDataList;
    }

    public void setOnItemListener(OnItemListener onItemListener) {
        this.onItemListener = onItemListener;
    }

    public interface OnItemListener {
        void onClick(View v, int pos, String technicalIndex);
    }

    public void setDefSelect(int position) {
        this.defItem = position;
        notifyDataSetChanged();
    }

    int getDefItem() {
        return defItem;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_technical_index, parent, false);
        return new ViewHolder(view, true);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (position < getItemCount()) {
            final String technicalIndex = mDataList.get(position);
            if (technicalIndex != null) {
                holder.tv_technical_index_name.setText(technicalIndex);

                // 设置选中颜色
                if (defItem == position) {
                    holder.tv_technical_index_name.setBackgroundResource(R.color.es_selectedColor);
                    holder.ll_main.setBackgroundResource(R.color.es_selectedColor);
                } else {
                    holder.tv_technical_index_name.setBackgroundResource(R.color.es_technical_index_adapter_not_position);
                    holder.ll_main.setBackgroundResource(R.color.es_technical_index_adapter_not_position);
                }
            }
        }
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    public String getItem(int position) {
            position--;
        if (position < mDataList.size())
            return mDataList.get(position);
        else return null;
    }

    public void clear() {
        mDataList.clear();
        this.notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_technical_index_name;
        public LinearLayout ll_main;
        View mDivideLine;

        public ViewHolder(View itemView, boolean isItem) {
            super(itemView);
            if (isItem) {
                tv_technical_index_name = itemView.findViewById(R.id.es_item_technical_index_tv_technical_index);
                ll_main = itemView.findViewById(R.id.es_item_technical_index_ll_main);
                mDivideLine = itemView.findViewById(R.id.es_item_technical_index_view_divider_line);

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (onItemListener != null) {
                            onItemListener.onClick(view, getLayoutPosition(), mDataList.get(getLayoutPosition()));
                        }
                    }
                });
            }
        }
    }
}