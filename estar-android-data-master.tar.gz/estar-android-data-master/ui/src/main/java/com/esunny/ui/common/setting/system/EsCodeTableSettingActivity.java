package com.esunny.ui.common.setting.system;

import android.view.KeyEvent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.QuoteEvent;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.data.util.simplethread.SimpleRunnable;
import com.esunny.data.util.simplethread.TaskManager;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsCusSwitchButton;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;
import skin.support.content.res.SkinCompatResources;

public class EsCodeTableSettingActivity extends EsBaseActivity implements View.OnClickListener {

    private final String TAG = getClass().getSimpleName();

    @BindView(R2.id.es_activity_code_table_toolbar)
    EsBaseToolBar mToolbar;
    @BindView(R2.id.es_activity_code_table_is_save_data)
    RelativeLayout mRlSaveData;
    @BindView(R2.id.es_activity_code_table_mannual_update)
    RelativeLayout mRlMannualUpdate;
    @BindView(R2.id.es_activity_code_table_clear_data)
    RelativeLayout mRlClearData;
    @BindView(R2.id.es_activity_code_table_is_save_data_switch_button)
    EsCusSwitchButton mSwitchButtonIsSaveCodeTable;
    @BindView(R2.id.es_activity_code_table_rl_overlay)
    RelativeLayout mRlOverLay;
    @BindView(R2.id.es_activity_code_table_divide_view)
    View mDivideView;

    boolean mFinishMannualUpdate = true;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_code_table_setting;
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        initToolbar();
        bindOnClick();
        initSwitchButton();

        if (EsSPHelperProxy.getIsSaveCodeTable(this)) {
            mRlMannualUpdate.setVisibility(View.VISIBLE);
            mDivideView.setVisibility(View.VISIBLE);
        } else {
            mRlMannualUpdate.setVisibility(View.GONE);
            mDivideView.setVisibility(View.GONE);
        }
    }

    private void initSwitchButton() {
        mSwitchButtonIsSaveCodeTable.setChecked(EsSPHelperProxy.getIsSaveCodeTable(this));
        mSwitchButtonIsSaveCodeTable.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mSwitchButtonIsSaveCodeTable.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));
    }

    private void bindOnClick() {
        mRlSaveData.setOnClickListener(this);
        mRlMannualUpdate.setOnClickListener(this);
        mRlClearData.setOnClickListener(this);
        mRlOverLay.setOnClickListener(this);

        mSwitchButtonIsSaveCodeTable.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                EsSPHelperProxy.setIsSaveCodeTable(getBaseContext(), isChecked);
                if (isChecked) {
                    mRlMannualUpdate.setVisibility(View.VISIBLE);
                    mDivideView.setVisibility(View.VISIBLE);
                } else {
                    mRlMannualUpdate.setVisibility(View.GONE);
                    mDivideView.setVisibility(View.GONE);
                }
            }
        });
    }

    private void initToolbar() {
        mToolbar.setTitle(getString(R.string.es_activity_chart_setting_code_table));
        mToolbar.setLeftIcons(R.string.es_icon_toolbar_back);
        mToolbar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if(id == R.id.toolbar_left_first){
                    exitActivity();
                }
            }
        });
    }

    private void exitActivity() {
        if (mFinishMannualUpdate) {
            finish();
        } else {
            ToastHelper.show(getApplicationContext(), R.string.es_activity_chart_setting_code_table_update_is_running);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exitActivity();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.es_activity_code_table_mannual_update) {
            mannualUpdate();
        }else if (id == R.id.es_activity_code_table_clear_data) {
            clearData();
        }
    }

    private void mannualUpdate() {
        if (!mFinishMannualUpdate) {
            return;
        }
        mFinishMannualUpdate = false;

        mRlOverLay.setVisibility(View.VISIBLE);
        ToastHelper.show(this, R.string.es_activity_chart_setting_code_table_update_is_running);

        TaskManager.getInstance().execute(new SimpleRunnable() {
            @Override
            public void run() {
                EsDataApi.clearCodeTableData();
                EsDataApi.mannualUpdate();
            }
        });

    }

    private void clearData() {
        EsDataApi.clearCodeTableData();
        ToastHelper.show(this, R.string.es_activity_chart_setting_code_table_clear_data_is_running);
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
            EsLog.d(TAG, "Eventbus register ~");
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
            EsLog.d(TAG, "Eventbus unregister ~");
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void quoteEvent(QuoteEvent event) {
        int action = event.getAction();

        if (action == EsDataConstant.S_SRVEVENT_QINITCOMPLETED) {
            mFinishMannualUpdate = true;
            mRlOverLay.setVisibility(View.GONE);
            ToastHelper.show(this, R.string.es_activity_chart_setting_code_table_update_finish);
        }
    }
}
