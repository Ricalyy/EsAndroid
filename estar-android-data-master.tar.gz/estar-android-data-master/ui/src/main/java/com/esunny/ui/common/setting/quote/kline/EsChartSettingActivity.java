package com.esunny.ui.common.setting.quote.kline;

import android.content.Intent;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.esunny.data.api.util.EstarTransformation;
import com.esunny.data.bean.KLinePeriod;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.data.api.EsDataTrackApi;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.setting.quote.kline.QuoteTitle.EsQuoteTitleSettingActivity;
import com.esunny.ui.common.setting.system.EsCodeTableSettingActivity;
import com.esunny.ui.common.setting.system.EsSwitchTextSizeActivity;
import com.esunny.ui.data.EsBadgeDataManger;
import com.esunny.ui.data.quote.EsKLineData;
import com.esunny.ui.quote.kline.bean.KLineParam;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.data.util.simplethread.SimpleRunnable;
import com.esunny.data.util.simplethread.TaskManager;
import com.esunny.ui.view.EsBadgeTextView;
import com.esunny.ui.view.EsCusSwitchButton;
import com.esunny.ui.view.EsIconTextView;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import butterknife.OnClick;
import skin.support.content.res.SkinCompatResources;


@Route(path = RoutingTable.ES_CHART_SETTING_ACTIVITY)
public class EsChartSettingActivity extends EsBaseActivity implements View.OnClickListener{

    RelativeLayout mRlParameterChange, mRlPeriodSetting, mRlPriceCalculate, mRlSwitchTextSize, mRlChartDraw, mRlCodeTable, mRlQuoteSetting;
    RelativeLayout mRlQuoteTitle;
    EsCusSwitchButton mSwitchKLineColor, mSwitchPositionShow;
    EsIconTextView mItvBack;
    TextView mTvTextSize, mTvPriceType;

    @BindView(R2.id.es_activity_chart_setting_rl_parameter_configure)
    RelativeLayout mRlParamConfig;

    @BindView(R2.id.es_activity_chart_setting_btv_code_table)
    EsBadgeTextView mCodeTableBTV;
    @BindView(R2.id.es_activity_chart_setting_btv_plate_setting)
    EsBadgeTextView mPlateSettingBTV;

    @Override
    protected void initData() {
        super.initData();
        EsKLineData.getInstance().init(getApplicationContext());
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindOnClick();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mTvTextSize.setText(EstarTransformation.quoteTextSizeToStr(this, EsSPHelperProxy.getQuoteTextSize(this)));
        mTvPriceType.setText(EstarTransformation.priceCalculateTypeToStr(this, EsSPHelperProxy.getPriceCalculateMethod()));
    }

    private void bindView() {
        mRlParameterChange = findViewById(R.id.es_activity_chart_setting_rl_parameter_change);
        mRlPeriodSetting = findViewById(R.id.es_activity_chart_setting_rl_period_setting);
        mRlPriceCalculate = findViewById(R.id.es_activity_chart_setting_rl_price_calculate);
        mRlChartDraw = findViewById(R.id.es_activity_chart_setting_rl_char_draw_setting);
        mRlQuoteTitle = findViewById(R.id.es_activity_chart_setting_rl_single_double_title_setting);
        mRlCodeTable = findViewById(R.id.es_activity_chart_setting_rl_code_table);
        mItvBack = findViewById(R.id.es_activity_chart_setting_iv_back);
        mRlQuoteSetting = findViewById(R.id.es_activity_chart_setting_rl_quote_setting);
        mRlSwitchTextSize = findViewById(R.id.es_activity_chart_setting_rl_choose_text_size);
        mTvTextSize = findViewById(R.id.es_activity_chart_setting_tv_text_size);
        mTvPriceType = findViewById(R.id.es_activity_chart_setting_tv_price_calculate);

        mSwitchKLineColor = findViewById(R.id.es_activity_chart_setting_kline_color_switch_button);
        mSwitchKLineColor.setChecked(EsSPHelper.getIsKLineBuyRed(this));
        mSwitchKLineColor.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mSwitchKLineColor.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));

        mSwitchPositionShow = findViewById(R.id.es_activity_chart_setting_position_show_switch_button);
        mSwitchPositionShow.setChecked(EsSPHelper.getIsKLinePositionShow(this));
        mSwitchPositionShow.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mSwitchPositionShow.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));

        mCodeTableBTV.setKey(EsBadgeDataManger.NODE_KEY_QUOTE_SETTING_CODE_TABLE);
        mPlateSettingBTV.setKey(EsBadgeDataManger.NODE_KEY_QUOTE_SETTING_PLATE_SETTING);
    }

    private void bindOnClick() {
        mRlParameterChange.setOnClickListener(this);
        mRlPeriodSetting.setOnClickListener(this);
        mRlPriceCalculate.setOnClickListener(this);
        mRlChartDraw.setOnClickListener(this);
        mRlQuoteTitle.setOnClickListener(this);
        mRlCodeTable.setOnClickListener(this);
        mRlQuoteSetting.setOnClickListener(this);
        mRlSwitchTextSize.setOnClickListener(this);
        mItvBack.setOnClickListener(this);

        mSwitchKLineColor.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                EsSPHelper.setIsKLineBuyRed(getBaseContext(), isChecked);
            }
        });

        mSwitchPositionShow.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                EsSPHelper.setIsKLinePositionShow(getBaseContext(), isChecked);
            }
        });
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_chart_setting;
    }

    @Override
    public void onClick(View view) {
        int i = view.getId();
        if (i == mRlParameterChange.getId()) {
            setRlParameterChange();
        } else if (i == mRlPeriodSetting.getId()) {
            setRlPeriodSetting();
        } else if (i == mRlPriceCalculate.getId()) {
            setRlPriceCalculate();
        } else if (i == mItvBack.getId()) {
            back();
        } else if (i == mRlSwitchTextSize.getId()){
            switchTextSize();
        } else if (i == mRlChartDraw.getId()) {
            setRlChartDraw();
        } else if (i == mRlCodeTable.getId()) {
            mCodeTableBTV.removeBadge();
            setCodeTable();
        } else if (i == mRlQuoteTitle.getId()) {
            setQuoteTitle();
        } else if (i == R.id.es_activity_chart_setting_rl_quote_setting) {
            mPlateSettingBTV.removeBadge();
            quoteSetting();
        }
    }

    private void setQuoteTitle() {
        Intent intent = new Intent(this, EsQuoteTitleSettingActivity.class);
        startActivity(intent);
    }

    private void quoteSetting() {
        Intent intent = new Intent(this, EsQuoteSettingActivity.class);
        startActivity(intent);
    }

    private void setCodeTable() {
        Intent intent = new Intent(this, EsCodeTableSettingActivity.class);
        startActivity(intent);
    }

    private void setRlChartDraw() {
        Intent intent = new Intent(this, EsChartDrawSettingActivity.class);
        startActivity(intent);
    }

    private void setRlParameterChange() {
        Intent intent = new Intent(this, EsIndexParameterActivity.class);
        startActivity(intent);
    }

    private void setRlPeriodSetting() {
        Intent intent = new Intent(this, EsPeriodSettingActivity.class);
        startActivity(intent);
    }

    private void setRlPriceCalculate() {
        Intent intent = new Intent(this, EsPriceCalculateActivity.class);
        startActivity(intent);
    }

    private void switchTextSize() {
        Intent intent = new Intent(this, EsSwitchTextSizeActivity.class);
        startActivity(intent);
    }

    private void back() {
        finish();
    }

    @OnClick(R2.id.es_activity_chart_setting_rl_parameter_configure)
    public void configue() {
        Intent intent = new Intent(this, EsIndexConfigActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        JSONObject indexParameterObject = new JSONObject();
        HashMap<String, ArrayList<KLineParam>> mKLineParamsHashMap = EsKLineData.getInstance().getAllParams();
        if (mKLineParamsHashMap == null) {
            return;
        }

        Iterator<Map.Entry<String, ArrayList<KLineParam>>> entries = mKLineParamsHashMap.entrySet().iterator();
        while (entries.hasNext()) {
            Map.Entry<String, ArrayList<KLineParam>> entry = entries.next();
            String key = entry.getKey();
            JSONObject childIndexParameterObject = new JSONObject();
            ArrayList<KLineParam> list = entry.getValue();
            for (KLineParam param : list) {
                childIndexParameterObject.put(param.getName(), Double.parseDouble(param.getValue()));
            }
            indexParameterObject.put(key, childIndexParameterObject);
        }

        List<String> mKLineParamsKeyList = EsKLineData.getInstance().getAllParamsKey();
        String dataStr = EsSPHelper.getIndexConfig(this);
        JSONObject indexConfigurationObject = new JSONObject();

        org.json.JSONObject mJson = new org.json.JSONObject();
        if (dataStr == null || dataStr.isEmpty()) {
            mJson = new org.json.JSONObject();
        } else {
            try {
                mJson = new org.json.JSONObject(dataStr);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
//        mJson.has(key)
        List<String> morphologicalIndexList = Arrays.asList("MA", "EMA", "SAR", "BOLL", "PUBU", "SP", "BBI", "EMA2", "SMA", "CDP");
        List<String> turnoverIndexList = Arrays.asList("CJL");
        List<String> swingIndexList = Arrays.asList("MACD", "KD", "KDJ", "RSI", "SLOWKD", "WR", "BIAS", "DMI", "CCI", "PSY", "MTM", "DDI", "ARBR", "TRIX");
        JSONObject morphologicalObject = new JSONObject();
        JSONObject turnoverObject = new JSONObject();
        JSONObject swingObject = new JSONObject();

        for (String keyStr : mKLineParamsKeyList) {
            if (mJson.has(keyStr)) {
                try {
                    if (morphologicalIndexList.contains(keyStr)) {
                        morphologicalObject.put(keyStr, mJson.getBoolean(keyStr));
                    } else if (turnoverIndexList.contains(keyStr)) {
                        turnoverObject.put(keyStr, mJson.getBoolean(keyStr));
                    } else if (swingIndexList.contains(keyStr)) {
                        swingObject.put(keyStr, mJson.getBoolean(keyStr));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                if (morphologicalIndexList.contains(keyStr)) {
                    morphologicalObject.put(keyStr, true);
                } else if (turnoverIndexList.contains(keyStr)) {
                    turnoverObject.put(keyStr, true);
                } else if (swingIndexList.contains(keyStr)) {
                    swingObject.put(keyStr, true);
                }
            }
        }
        indexConfigurationObject.put("MorphologicalIndex", morphologicalObject);
        indexConfigurationObject.put("TurnoverIndex", turnoverObject);
        indexConfigurationObject.put("SwingIndex", swingObject);

        JSONArray periodSettingArray = new JSONArray();
        List<KLinePeriod> mDefaultList = EsKLineData.getInstance().getKLinePeriods();
        for (KLinePeriod period : mDefaultList) {
            JSONObject periodObject = new JSONObject();
            periodObject.put("Value", period.getKLineShowSlice());
            periodObject.put("Type", period.getKLineShowType());
            periodSettingArray.add(periodObject);
        }

        final JSONObject quoteDataObject = new JSONObject();
        quoteDataObject.put("IndexParameter", indexParameterObject);
        quoteDataObject.put("IndexConfiguration", indexConfigurationObject);
        quoteDataObject.put("PeriodSetting", periodSettingArray);
        quoteDataObject.put("PriceCalculateType", EsSPHelperProxy.getPriceCalculateMethod());
        quoteDataObject.put("TextSize", EsSPHelperProxy.getQuoteTextSize(this));
        quoteDataObject.put("IsPositionAverageLine", EsSPHelper.getIsShowPositionCost(this));
        quoteDataObject.put("IsLastPriceLine", EsSPHelper.getIsShowLastPrice(this));
        quoteDataObject.put("IsDrawLine", EsSPHelper.getIsShowDrawLine(this));
        quoteDataObject.put("IsQuoteSingle", EsSPHelper.getIsShowSingle(this));

        TaskManager.getInstance().execute(new SimpleRunnable() {
            @Override
            public void run() {
                EsDataTrackApi.saveQuoteSettingConfiguration(quoteDataObject);
            }
        });
    }
}
