package com.esunny.ui.common.news;

import android.app.Activity;
import android.content.Intent;
import android.webkit.JavascriptInterface;

import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.util.EsShareUtil;

/**
 * Created by chexiaopeng on 2018/7/5.
 */

public class EsNewsWebViewUtil {

    public static String KEY_INTENT_NEWS_SOURCE = "NewsSource";
    public static int KEY_INTENT_NEWS_SOURCE_DETAIL = 1;
    public static int KEY_INTENT_NEWS_SOURCE_SEARCH = 2;

    private Activity mActivity;

    public EsNewsWebViewUtil(Activity activity){
        mActivity = activity;
    }

    @JavascriptInterface
    public void share(String url, String title, String description){
        EsShareUtil.shareWeb(mActivity, url, title , description);
    }

    @JavascriptInterface
    public void showNewsDetail(String url){
        Intent intent = new Intent(mActivity, EsNewsDetailActivity.class);
        intent.putExtra(KEY_INTENT_NEWS_SOURCE, KEY_INTENT_NEWS_SOURCE_DETAIL);
        intent.putExtra(EsUIConstant.KEY_INTENT_NEWS_DETAILS_URL, url);
        mActivity.startActivity(intent);
    }

    @JavascriptInterface
    public void showNewsQryResult(String url){
        Intent intent = new Intent(mActivity, EsNewsDetailActivity.class);
        intent.putExtra(KEY_INTENT_NEWS_SOURCE, KEY_INTENT_NEWS_SOURCE_SEARCH);
        intent.putExtra(EsUIConstant.KEY_INTENT_NEWS_DETAILS_URL, url);
        mActivity.startActivity(intent);
    }

}