package com.esunny.ui.common;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.BasePresenter;
import com.esunny.ui.util.EsSPHelper;

import org.greenrobot.eventbus.EventBus;

import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Created by chexiaopeng on 2018/1/17.
 */

public abstract class EsBaseFragment extends Fragment {

    protected Context mContext;
    protected ViewGroup mViewGroup;
    protected View mRoot;
    protected LayoutInflater mInflater;
    private Unbinder unbinder;
    protected void initWidget(View root){}
    protected abstract int getLayoutId();
    protected void unRegister(){
        if(EventBus.getDefault().isRegistered(this)) {//加上判断
            EventBus.getDefault().unregister(this);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mViewGroup = container;
        if (mRoot != null) {
            ViewGroup parent = (ViewGroup)mRoot.getParent();
            if (parent!=null) {
                parent.removeView(mRoot);
            }
            unbinder = ButterKnife.bind(this, mRoot);
        } else {
            mRoot = inflater.inflate(getLayoutId(),container,false);
            mInflater = inflater;
            unbinder = ButterKnife.bind(this, mRoot);
            initWidget(mRoot);
        }
        return mRoot;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mContext = null;
    }


    @Override
    public void onResume() {
        super.onResume();

        if(!EventBus.getDefault().isRegistered(this) && !isHidden()) {//加上判断
            EventBus.getDefault().register(this);
        }

        if (EsSPHelperProxy.getIsKeepScreenOn(mContext)){
            getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }else {
            getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        unRegister();
        if (EsSPHelperProxy.getIsKeepScreenOn(mContext)){
            getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }else {
            getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        if (hidden) {
            if(EventBus.getDefault().isRegistered(this)) {//加上判断
                EventBus.getDefault().unregister(this);
            }
        } else {
            if(!EventBus.getDefault().isRegistered(this)) {//加上判断
                EventBus.getDefault().register(this);
            }
        }
    }
}
