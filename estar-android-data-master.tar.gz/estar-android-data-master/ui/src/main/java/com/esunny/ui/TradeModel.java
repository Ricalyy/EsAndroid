package com.esunny.ui;

import android.content.Context;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.api.event.NewsEvent;
import com.esunny.data.api.event.QuoteEvent;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.F10Content;
import com.esunny.data.bean.QuoteBetData;
import com.esunny.data.bean.MatchData;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.PositionData;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.trade.TradeCombination;
import com.esunny.ui.trade.TradeInstance;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class TradeModel implements TradeCombination.Mode {

    public void register() {
        EventBus.getDefault().register(this);
    }

    @Override
    public List<Contract> getFavoriteContractList() {
        return EsFavoriteListData.getInstance().getFavoriteContractArrayList();
    }

    @Override
    public void refreshPositionData(String companyNo, String userNo, String addrNo) {
        getPositionData(companyNo, userNo, addrNo);
    }

    @Override
    public void refreshParorderData(String companyNo, String userNo, String addrNo) {
        getParOrderData(companyNo, userNo, addrNo);
    }

    @Override
    public void refreshDelegateorderData(String companyNo, String userNo, String addrNo) {
        getDelegateOrderData(companyNo, userNo, addrNo);
    }

    @Override
    public void refreshMatchorderData(String companyNo, String userNo, String addrNo) {
        getMatchData(companyNo, userNo, addrNo);
    }

    @Override
    public void queryF10ByCommodity(Context context, String commodityNo) {
        EsDataApi.queryF10ByCommodity(commodityNo);
    }

    @Override
    public void refreshTradeFund(String companyNo, String userNo, String addrNo) {
        getTradeFundData(companyNo, userNo, addrNo);
    }

    @Override
    public void refreshTradeLock(String companyNo, String userNo, String addrNo) {
        tradeLockPosition(companyNo, userNo, addrNo);
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void newsEvent(NewsEvent event) {
        int action = event.getAction();

        if (action == EsDataConstant.S_SRVEVENT_NEWSFTENUPDATE) {
            F10Content info = (F10Content) event.getData();
            if (info != null) {
                EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_QUERY_F10_BY_COMMODITY)
                        .setData(info).buildEvent();
                EventBus.getDefault().post(message);
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void quoteEvent(QuoteEvent event) {
        int action = event.getAction();
        String contractNo = event.getContractNo();
        if (action == EsDataConstant.S_SRVEVENT_QUOTE) {
            getQuoteData(contractNo);
        }
    }

    private void getQuoteData(String contractNo) {
        EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_INSTANT_QUOTE)
                .setContent(contractNo).buildEvent();
        EventBus.getDefault().post(message);
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();
        Object data = event.getData();
        final String companyNo = event.getCompanyNo();
        final String userNo = event.getUserNo();
        final String addrNo = event.getAddressNo();
        int errorCode = event.getSrvErrorCode();

        switch (action) {
            // 交易资金变化
            case EsDataConstant.S_SRVEVENT_TRADE_FUND:
                getTradeFundData(companyNo, userNo, addrNo);
                break;
            // 交易持仓
            case  EsDataConstant.S_SRVEVENT_TRADE_POSITION:
                tradePosition(companyNo, userNo, addrNo, data, errorCode);
                break;
            // 挂单、委托
            case EsDataConstant.S_SRVEVENT_TRADE_ORDER:
                tradeOrder(companyNo, userNo, addrNo, data, errorCode);
                break;
            case EsDataConstant.S_SRVEVENT_TRADE_MATCH:
                // 成交
                tradeMatch(companyNo, userNo, addrNo, data, errorCode);
                break;
            case EsDataConstant.S_SRVEVENT_TRADE_LOCK_POSITION:
                tradeLockPosition(companyNo, userNo, addrNo);
                break;
            case EsDataConstant.S_SRVEVENT_ASX_PARAM:
                // 拿到澳交所的系统参数回调需要刷新持仓
                refreshFloatForSASX();
                break;
            case EsDataConstant.S_SRVEVENT_TRADESUMPROFITCHG:
                // 浮盈合计变化通知
                refreshFloatTB(companyNo, userNo, addrNo, data, errorCode);
            default:
                break;
        }
    }

    private void refreshFloatTB(String companyNo, String userNo, String addrNo, Object data, int errorCode) {
        int currentTabIndex = TradeInstance.getInstance().getCurrentTabIndex();
        if (errorCode == 0 && data instanceof PositionData && currentTabIndex == 0 && EsLoginAccountData.getInstance().isCurrentAccount(companyNo, userNo, addrNo)) {
            EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_USER_FLOAT_CHANGE).setData(data).buildEvent();
            EventBus.getDefault().post(message);
        }
    }

    private void tradePosition(String companyNo, String userNo, String addrNo, Object data, int errorCode) {
        int currentTabIndex = TradeInstance.getInstance().getCurrentTabIndex();
        if (errorCode == 0 && data instanceof PositionData && currentTabIndex == 0 && isCurrentAccount(companyNo, userNo, addrNo)) {
            getPositionData(companyNo, userNo, addrNo);
        }

    }

    private void tradeMatch(String companyNo, String userNo, String addrNo, Object data, int errorCode) {
        int currentTabIndex = TradeInstance.getInstance().getCurrentTabIndex();
        if (errorCode == 0 && data instanceof MatchData && currentTabIndex == 3 && isCurrentAccount(companyNo, userNo, addrNo)) {
            getMatchData(companyNo, userNo, addrNo);
        }
    }

    private void getMatchData(String companyNo, String userNo, String addrNo) {
        List<MatchData> matchDataList = EsDataApi.getMatchData(companyNo, userNo, addrNo, "", EsDataConstant.S_DIRECT_BOTH, -1, true);
        if (matchDataList == null) {
            matchDataList = new ArrayList<>();
        }

        EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_GET_MATCHORDER_DATA).setData(matchDataList).buildEvent();
        EventBus.getDefault().post(message);
    }

    private void tradeOrder(String companyNo, String userNo, String addrNo, Object data, int errorCode) {
        if (errorCode != 0 || !(data instanceof OrderData) || !isCurrentAccount(companyNo, userNo, addrNo)) {
            return;
        }

        int currentTabIndex = TradeInstance.getInstance().getCurrentTabIndex();
        if (currentTabIndex == 1) {
            getParOrderData(companyNo, userNo, addrNo);
        }else if (currentTabIndex == 2) {
            getDelegateOrderData(companyNo, userNo, addrNo);
        }

        //更新锁的数量
        tradeLock(userNo, companyNo, addrNo, (OrderData)data);
        // 更新持仓数量。存在当订单处于挂单状态时，无法收到持仓回调。但此时持仓的可用已减少。
        getPositionData(companyNo, userNo, addrNo);
    }

    private void getDelegateOrderData(String companyNo, String userNo, String addrNo) {
        List<OrderData> delegateOrderList = null;
        if (!companyNo.isEmpty() && !userNo.isEmpty() && !addrNo.isEmpty()) {
            delegateOrderList = EsDataApi.getOrderData(companyNo, userNo, addrNo, '\0', '\0', "", -1, true);
        }
        if (delegateOrderList == null) {
            delegateOrderList = new ArrayList<>();
        }

        EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_GET_DELEGATEORDER_DATA).setData(delegateOrderList).buildEvent();
        EventBus.getDefault().post(message);
    }

    private void getParOrderData(String companyNo, String userNo, String addrNo) {
        List<OrderData> parorderDataList = null;
        if (!companyNo.isEmpty() && !userNo.isEmpty() && !addrNo.isEmpty()) {
            parorderDataList = EsDataApi.getPutOrderData(companyNo, userNo, addrNo, '\0', "", -1, true);
        }
        if (parorderDataList == null) {
            parorderDataList = new ArrayList<>();
        }

        EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_GET_PARORDER_DATA).setData(parorderDataList).buildEvent();
        EventBus.getDefault().post(message);
    }

    private void getPositionData(String companyNo, String userNo, String addrNo) {
        List<PositionData> positionDataList = null;
        if (!companyNo.isEmpty() && !userNo.isEmpty() && !addrNo.isEmpty()) {
            positionDataList = EsDataApi.getSumPositionData(companyNo, userNo, addrNo, "", (char)0, true);
        }
        if (positionDataList == null) {
            positionDataList = new ArrayList<>();
        }

        EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_GET_POSITION_DATA).setData(positionDataList).buildEvent();
        EventBus.getDefault().post(message);
    }

    private void getTradeFundData(String companyNo, String userNo, String addrNo) {
        //是否当前用户的判断
        if (isCurrentAccount(companyNo, userNo, addrNo)) {
            EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
            List<MoneyData> datas = EsDataApi.getMoneyData(loginAccount.getCompanyNo(), loginAccount.getUserNo(), loginAccount.getAddrTypeNo());
            if (datas == null) {
                datas = new ArrayList<>();
            }

            EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_GET_MONEY_INFO_DATA).setData(datas).buildEvent();
            EventBus.getDefault().post(message);
        }

    }

    private void tradeLockPosition(String companyNo, String userNo, String addrNo) {
        BigInteger[] lockQty = new BigInteger[3];
        EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        if (loginAccount.getUserNo().equals(userNo) && loginAccount.getCompanyNo().equals(companyNo) && loginAccount.getAddrTypeNo().equals(addrNo)) {
            lockQty = EsDataApi.getLockQty(companyNo, userNo, addrNo, "SSE|T|FUNDS|510050");
            // M 通知P去更新
            EsEventMessage message = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_GET_TRADE_LOCK_POSITION).setData(lockQty).buildEvent();
            EventBus.getDefault().post(message);
        }
    }

    private void tradeLock(String userNo, String companyNo, String addrNo, OrderData orderData) {
        char orderType = orderData.getOrderType();
        if (orderType != EsDataConstant.S_ORDERTYPE_STOCK_LOCK && orderType != EsDataConstant.S_ORDERTYPE_STOCK_UNLOCK) {
            return;
        }
        tradeLockPosition(userNo, companyNo, addrNo);
    }

    private boolean isCurrentAccount(String companyNo, String userNo, String addrNo) {
        EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        return loginAccount != null
                && loginAccount.getUserNo().equals(userNo)
                && loginAccount.getCompanyNo().equals(companyNo)
                && loginAccount.getAddrTypeNo().equals(addrNo);
    }

    private void refreshFloatForSASX() {
        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
        if (account != null) {
            getPositionData(account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo());
        } else {
            getPositionData("", "", "");
        }
    }
}
