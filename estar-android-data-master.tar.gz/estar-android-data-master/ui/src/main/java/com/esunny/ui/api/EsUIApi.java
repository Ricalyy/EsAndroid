package com.esunny.ui.api;


import android.app.Activity;
import android.app.Application;
import android.content.Context;

import androidx.fragment.app.Fragment;

import com.esunny.data.bean.Contract;
import com.esunny.data.util.EsLog;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.data.quote.EsKLineData;
import com.esunny.ui.data.quote.EsOptionListData;
import com.esunny.ui.data.quote.EsQuoteListData;
import com.esunny.ui.data.setting.EsLoginAccountData;

import java.util.List;


public class EsUIApi {
    private static final String TAG = "EsUIApi";

    /**
     *  保存是否在前台运行
     */
    public static boolean IsBackground = false;

    public static final int SHOW_FAVORITE_FRAGMENT = 0;
    public static final int SHOW_QUOTE_FRAGMENT = 1;
    public static final int SHOW_OPTION_FRAGMENT = 2;
    public static final int SHOW_TRADE_FRAGMENT = 4;
    public static final int SHOW_NEW_FRAGMENT = 5;
    public static final int SHOW_SETTING_FRAGMENT = 6;
    public static final int SHOW_FUNDS_FRAGMENT = 7;


    /*     初始化       */

    public static void initUI(Application application) {
        EsUIBaseAPI.initUI(application);
    }

    /**
     * 初始化数据，如友盟插件及个推
     * @param context application
     */
    public static void initConfiguration(Context context) {
        EsUIBaseAPI.initConfiguration(context);
    }

    public static boolean isDebug(Context context) {
        return EsUIBaseAPI.isDebug(context);
    }

    public static String getVersion(Context application) {
        return EsUIBaseAPI.getVersion(application);
    }

    /**
     * 用于获取Manifest中定义的一些参数
     * @param context 应用上下文
     * @param key 参数名
     * @return 参数值
     */
    public static String getAppMetaStr(Context context, String key) {
        return EsUIBaseAPI.getAppMetaStr(context, key);
    }

    /**
     * 获取界面fragment
     * @param tag
     *     SHOW_FAVORITE_FRAGMENT 自选
     *     SHOW_QUOTE_FRAGMENT    行情
     *     SHOW_OPTION_FRAGMENT   期权
     *     SHOW_TRADE_FRAGMENT    交易
     *     SHOW_NEW_FRAGMENT      资讯
     *     SHOW_SETTING_FRAGMENT    登录
     * @return 对应的v4 fragment
     */
    public static Fragment getFragment(int tag) {
        EsLog.d(TAG, "getFragment tag = " + tag);
        return EsRouterManager.getFragment(tag);
    }

    /**
     * 极星自动登录
     * @param context 上下文
     */
    public static int initEstarLogin(Context context) {
        EsLog.d(TAG, "initEstarLogin");
        return EsUIBaseAPI.initEstarLogin(context);
    }

    private static List<Contract> getContractListData(int type) {
        if (type == EsUIConstant.S_CONTRACT_LIST_QUOTE) {
            return EsQuoteListData.getInstance().getAllContract();
        } else if (type == EsUIConstant.S_CONTRACT_LIST_FAVORITE_SORT) {
            return EsFavoriteListData.getInstance().getSortedFavoriteContractList();
        } else if (type == EsUIConstant.S_CONTRACT_LIST_FAVORITE) {
            return EsFavoriteListData.getInstance().getFavoriteContractArrayList();
        } else if (type == EsUIConstant.S_CALL_CONTRACT_LIST_OPTION) {
            return EsOptionListData.getInstance().getCallContractOfOption();
        } else if (type == EsUIConstant.S_PUT_CONTRACT_LIST_OPTION) {
            return EsOptionListData.getInstance().getPutContractOfOption();
        } else if (type == EsUIConstant.S_MAIN_CONTRACT_LIST_OPTION) {
            return EsQuoteListData.getInstance().getSortQuote();
        } else {
            return null;
        }
    }

    /*     跳转界面       */

    /**
     * 跳转启动界面
     */
    public static void startStartLoadingActivity() {
        EsRouterManager.startStartActivity();
    }

    /**
     * 跳转启动界面
     */
    public static void startStartLoadingActivity(String key, int value) {
        EsRouterManager.startStartActivity(key, value);
    }


    /**
     * 跳转升级界面
     */
    public static void startAPPUpdateActivity() {
        EsRouterManager.startUpdateActivity();
    }

    /**
     * 打开k线界面
     * @param contractNo 合约号
     */
    public static void startEsKLineActivity(String contractNo) {
        EsKLineData.getInstance().setContractList(null);
        EsRouterManager.startEsKLineActivity(contractNo);
    }

    public static void startEsKLineActivity(int position, List<Contract> list) {
        EsKLineData.getInstance().setContractList(list);
        EsRouterManager.startEsKLineActivity(position);
    }

    public static void startEsKLineActivity(int position, int source, List<Contract> list) {
        EsKLineData.getInstance().setContractList(list);
        EsRouterManager.startEsKLineActivity(position, source);
    }

    /**
     * 打开k线界面
     * @param type 合约列表的类型
     *             S_CONTRACT_LIST_QUOTE
     *             S_CONTRACT_LIST_FAVORITE
     *             S_CALL_CONTRACT_LIST_OPTION
     *             S_PUT_CONTRACT_LIST_OPTION
     * @param position 合约在列表中的位置
     * @deprecated
     */
    public static void startEsKLineActivity(int type, int position) {
        List<Contract> list = getContractListData(type);
        startEsKLineActivity(position, list);
    }

    /**
     * 打开k线界面
     * @param type 合约列表的类型
     *             S_CONTRACT_LIST_QUOTE
     *             S_CONTRACT_LIST_FAVORITE
     *             S_CALL_CONTRACT_LIST_OPTION
     *             S_PUT_CONTRACT_LIST_OPTION
     * @param position 合约在列表中的位置
     * @param source 跳转的activity源
     * @deprecated
     */
    public static void startEsKLineActivity(int type, int position, int source) {
        List<Contract> list = getContractListData(type);
        startEsKLineActivity(position, source, list);
    }

    /**
     * 跳转搜索界面
     */
    public static void startSearchActivity() {
        EsLog.d(TAG, "start startSearchActivity");
        EsRouterManager.startSearchActivity();
    }

    /**
     * 跳转自选编辑界面
     */
    public static void startFavoriteEditActivity(){
        EsLog.d(TAG, "start FavotiteEditActivity");
        EsRouterManager.startFavoriteEditActivity();
    }

    /**
     * 打开多账户选择界面
     */
    public static void startAccountSelectActivity() {
        EsLog.d(TAG, "start AccountSelectActivity");
        EsRouterManager.startAccountSelectActivity();
    }

    /**
     * 打开登录界面
     */
    public static void startLoginActivity() {
        startLoginActivity(-1);
    }

    /**
     * 打开登录界面
     */
    public static void startLoginActivity(int location){
        EsLog.d(TAG, "start LoginActivity");
        EsRouterManager.startLoginActivity(location);
    }

    /**
     * 打开极星登录界面
     */
    public static void startStarLoginActivity(Activity activity) {
        EsLog.d(TAG, "start StarLoginActivity");
//        EsRouterManager.startStarLoginActivity(activity);
        EsRouterManager.startStarLoginActivity();
    }

    public static void startEstarStoreActivity() {
        EsLog.d(TAG, "start EstarStoreActivity");
        EsRouterManager.startEstarStoreActivity();
    }

    public static void startStarLoginActivity() {
        EsLog.d(TAG, "start StarLoginActivity");
        EsRouterManager.startStarLoginActivity();
    }

    /**
     * 打开公司选择界面
     */
    public static void startCompanyListActivity(Activity cotext, int requsetCode){
        EsLog.d(TAG, "start CompanyListActivity");
        EsRouterManager.startCompanyListActivity(cotext, requsetCode);
    }


    /**
     * 打开新闻详情
     * @param newsID 新闻的id
     */
    public static void startNewsDetailActivity(Context context, String newsID) {
        EsLog.d(TAG, "start NewsDetailActivity with" + newsID);
        EsRouterManager.startNewsDetailActivity(context, newsID);
    }

    /**
     * 打开云条件单订单界面
     */
    public static void startConditionalOrderActivity() {
        EsLog.d(TAG, "start EsStopLPOrderActivity");
        EsRouterManager.startConditionalOrderActivity();
    }

    /**
     * 打开添加单止损止盈界面
     */
    public static void startEsStrategyStopActivity() {
        EsLog.d(TAG,  "start EsStrategyStopActivity");
        EsRouterManager.startEsStrategyStopActivity();
    }

    /**
     * 打开添加单止损止盈界面
     * @param parentNo 父单号
     * @param orderType 父单类型
     */
    public static void startEsStrategyStopActivity(String parentNo, char orderType) {
        EsLog.d(TAG,  "start EsStrategyStopActivity");
        EsRouterManager.startEsStrategyStopActivity(parentNo, orderType);
    }

    /**
     * 打开添加价格预警界面
     */
    public static void startEsPriceWarnActivity() {
        EsLog.d(TAG,  "start EsPriceWarnActivity");
        EsRouterManager.startEsPriceWarnActivity();
    }

    /**
     * 打开添加云条件单界面
     */
    public static void startEsStrategyActivity(String source, String contractNo) {
        EsLog.d(TAG,  "start EsPriceWarnActivity");
        EsRouterManager.startEsStrategyActivity(source, contractNo);
    }


    /**
     * 打开止损止盈列表界面
     * @param contractNo 合约号
     * @param direct 买卖方向
     * @param openPrice 开盘价
     * @param qty 持仓量
     */
    public static void startPositionStopLossPanelActivity(String contractNo, char hedge, char direct,double openPrice,long qty) {
        EsLog.d(TAG,"start PositionStopLossPanelActivity, contractNo = " + contractNo + ", direct = " + direct + ", openPrice = " + openPrice + ", qty = " + qty);
        EsRouterManager.startPositionStopLossPanelActivity(contractNo, hedge,  direct, openPrice, qty);
    }

    /**
     * 打开账单查询界面
     */
    public static void startBillQueryActivity() {
        EsLog.d(TAG, "start BillQueryActivity");
        EsRouterManager.startBillQueryActivity();
    }

    /**
     * 打开银行转账界面
     */
    public static void startBankTransferActivity() {
        EsLog.d(TAG, "start BankTransferActivity");
        EsRouterManager.startBankTransferActivity();
    }

    /**
     * 打开当前账户信息界面
     * @param loginAccount 当前账户信息
     */
//    public static void startAccountDetailActivity(EsLoginAccountData.LoginAccount loginAccount) {
//        EsLog.d(TAG, "start AccountDetailActivity");
//        if (loginAccount == null) {
//            EsLog.w(TAG, "startAccountDetailActivity loginAccount is null");
//            return;
//        }
//
//        EsRouterManager.startAccountDetailActivity(loginAccount);
//    }

    /**
     * 打开选择币种界面
     * @param loginAccount 当前登录的用户
     * @param activity 返回界面
     */
//    public static void startChooseCurrencyNoActivity(EsLoginAccountData.LoginAccount loginAccount, Activity activity) {
//        EsLog.d(TAG, "start ChooseCurrencyNoActivity");
//        if (loginAccount == null) {
//            EsLog.w(TAG, "startChooseCurrencyNoActivity loginAccount is null");
//            return;
//        }
//        EsRouterManager.startChooseCurrencyNoActivity(loginAccount, activity);
//    }

    /**
     * 打开交易记录界面
     */
    public static void startTradeLogActivity() {
        EsLog.d(TAG, "start TradeLogActivity");
        EsRouterManager.startTradeLogActivity();
    }

    /**
     * 打开交易设置界面
     */
    public static void startTradeSettingActivity() {
        EsLog.d(TAG,"start TradeSettingActivity");
        EsRouterManager.startTradeSettingActivity();
    }

    /**
     * 打开K线表格设置界面
     */
    public static void startChartSettingActivity() {
        EsLog.d(TAG ,"start ChartSettingActivity");
        EsRouterManager.startChartSettingActivity();
    }

    /**
     * 打开关于界面
     */
    public static void startAboutActivity() {
        EsLog.d(TAG ,"start AboutActivity");
        EsRouterManager.startAboutActivity();
    }

    /**
     * 打开系统配置界面
     */
    public static void startSystemSettingActivity() {
        EsLog.d(TAG ,"start SystemSettingActivity");
        EsRouterManager.startSystemSettingActivity();
    }

    /**
     * 打开修改密码界面
     */
    public static void startPasswordActivity() {
        EsLog.d(TAG ,"start PasswordActivity");
        EsRouterManager.startPasswordActivity();
    }

    /**
     * 打开搜索界面
     * @param source 源界面的class name
     */
    public static void startSearchActivity(String source) {
        EsLog.d(TAG ,"start SearchActivity with " + source);
        EsRouterManager.startSearchActivity(source);
    }

    /**
     * 打开消息界面
     */
    public static void startMessageActivity() {
        EsLog.d(TAG ,"start MessageActivity");
        EsRouterManager.startMessageActivity();
    }

    /**
     * 打开交易相关界面
     */
    public static void startTradeAboutActivity() {
        EsLog.d(TAG ,"start TradeAboutActivity");
        EsRouterManager.startTradeAboutActivity();
    }

    /**
     * 免责声明
     * @param activity 接收确认消息的界面
     */
    public static void startDisclaimerActivity(Activity activity) {
        EsLog.d(TAG ,"start startDisclaimerActivity");
        EsRouterManager.startDisclaimerActivity(activity);
    }

    /**
     *  跳转隐私声明
     */
    public static void startPrivacyActivity() {
        EsRouterManager.startPrivacyActivity();
    }

    /**
     *  跳转隐私声明
     */
    public static void startNoticeActivity() {
        EsRouterManager.startNoticeActivity();
    }

        /**
         * 账单确认
         */
    public static void startBillStateConfirmActivity(String content, Activity activity){
        EsLog.d(TAG ,"start StateConfirmActivity");
        EsRouterManager.startBillStateConfirmActivity(content, activity);
    }

    /**
     * 跳转到已触发条件单界面
     */
    public static void startEsTriggeredConditionalOrderActivity() {
        EsLog.d(TAG ,"start EsTriggeredConditionalOrderActivity");
        EsRouterManager.startEsTriggeredConditionalOrderActivity();
    }

    /**
     * 跳转到已触发止损止盈界面
     */
    public static void startEsTriggeredStopLossOrderActivity() {
        EsLog.d(TAG ,"start EsTriggeredStopLossOrderActivity");
        EsRouterManager.startEsTriggeredStopLossOrderActivity();
    }

    /**
     * 跳转到开仓止损界面
     */
    public static void startStopLossOPenActivity(String source, String data) {
        EsLog.d(TAG ,"start EsStopLossOPenActivity");
        EsRouterManager.startStopLossOpenActivity(source, data);
    }

    /**
     * 跳转到账户详情界面
     */
    public static void startEsAccountDetailActivity(EsLoginAccountData.LoginAccount loginAccount) {

        if (loginAccount == null) {
            EsLog.d(TAG, "startEsAccountDetailActivity loginAccount is null");
            return;
        }
        EsLog.d(TAG ,"start EsAccountDetailActivity");
        EsRouterManager.startEsAccountDetialActivity(loginAccount);
    }

    /**
     * 打开在线开户界面
     */
    public static void startOpenOnlineActivity(){
        EsRouterManager.startOpenOnlineActivity();
    }

    /*     工具       */
    public static String convertKLinePeriodType(Context context, char type) {
        return EsUIBaseAPI.convertKLinePeriodType(context, type);
    }

    /**
     * 打开选择币种界面
     * @param loginAccount 当前登录的用户
     * @param activity 返回界面
     */
    public static void startChooseCurrencyNoActivity(EsLoginAccountData.LoginAccount loginAccount, Activity activity) {
        EsLog.d(TAG, "start startChooseCurrencyNoActivity");
        if (loginAccount == null) {
            EsLog.w(TAG, "startChooseCurrencyNoActivity loginAccount is null");
            return;
        }

        EsRouterManager.startChooseCurrencyNoActivity(loginAccount, activity);
    }
}
