package com.esunny.ui.common.setting.condition.EsStrategyView;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import androidx.annotation.Nullable;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.util.EstarTransformation;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.QuoteBetData;
import com.esunny.data.bean.OpenOrder;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.common.bean.EsOpenCount;
import com.esunny.ui.common.setting.condition.EsStrategyData.EsStrategyData;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.dialog.EsMultiSelectKeyboardDialog;
import com.esunny.ui.dialog.EsTimeSelectKeyboardDialog;
import com.esunny.ui.dialog.EsTradeLotsKeyboard;
import com.esunny.ui.trade.view.EsTradePriceKeyboard;
import com.esunny.ui.trade.view.EsTradePriceKeyboardView;
import com.esunny.ui.util.EsCalculateUtil;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsCusSwitchButton;
import com.esunny.ui.view.EsCustomRelativeLayout;
import com.esunny.ui.view.EsFixEditText;
import com.esunny.ui.view.EsIconTextView;
import com.github.florent37.viewtooltip.ViewTooltip;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;


public class EsStrategyInputs extends LinearLayout implements View.OnTouchListener,
        EsTradePriceKeyboardView.TradePriceKeyboardListener,
        EsMultiSelectKeyboardDialog.OnEsMultiSelectKeyboardDialogListener,
        EsTimeSelectKeyboardDialog.EsTimeKeyboardDialogListener {

    private final static String TAG = "EsStrategyInputs";

    //Contract
    @BindView(R2.id.et_strategy_input_contract)
    EditText mEditContract;
    @BindView(R2.id.crl_strategy_input_contract)
    EsCustomRelativeLayout mCRLContract;

    //Qty
    @BindView(R2.id.et_strategy_input_qty)
    EditText mEditQty;
    @BindView(R2.id.crl_strategy_input_qty)
    EsCustomRelativeLayout mCRLQty;

    //PriceCondition&TimeCondition
    @BindView(R2.id.crl_strategy_conditions)
    EsCustomRelativeLayout mCRLPirceAndTime;
    @BindView(R2.id.ll_strategy_price_condition)
    LinearLayout mllPriceLimit;
    @BindView(R2.id.tv_strategy_price_trigger_mode)
    EditText mTvPriceTriggMode;
    @BindView(R2.id.tv_strategy_price_trigger_condition)
    EditText mTvPriceTriggCondition;
    @BindView(R2.id.et_strategy_price_trigger_price)
    EsFixEditText mTvConditionPrice;

    @BindView(R2.id.ll_strategy_time_condition)
    LinearLayout mllTimeLimit;
    @BindView(R2.id.tv_strategy_time_trigger_mode)
    EditText mTvTimeTriggMode;
    @BindView(R2.id.et_strategy_time_trigger_time)
    EditText mTvConditionTime;
    @BindView(R2.id.ll_strategy_bonus_condition_button)
    LinearLayout mllBonusButton;

    //PriceConditionBonus
    @BindView(R2.id.crl_strategy_bonus_condition)
    EsCustomRelativeLayout mCRLBonusCondition;
    @BindView(R2.id.tv_strategy_bonus_trigger_mode)
    EditText mTvBonusPriceTriggMode;
    @BindView(R2.id.tv_strategy_bonus_trigger_condition)
    EditText mTvBonusPriceTriggCondition;
    @BindView(R2.id.et_strategy_bonus_trigger_price)
    EsFixEditText mTvBonusConditionPrice;
    @BindView(R2.id.icon_strategy_close_bonus)
    EsIconTextView mIconCloseBonusButton;

    //Order
    @BindView(R2.id.crl_strategy_condition_order)
    EsCustomRelativeLayout mCRLConditionOrder;
    @BindView(R2.id.tv_strategy_condition_order_price_type)
    EditText mTvConditionOrderPriceType;
    @BindView(R2.id.et_strategy_condition_order_fixed_price)
    EsFixEditText mTvConditionOrderPrice;
    @BindView(R2.id.ll_strategy_condition_order_fixed_price)
    LinearLayout mLlConditionOrderPrice;
    @BindView(R2.id.tv_strategy_condition_order_plus_type)
    EditText mTvConditionOrderPlusType;
    @BindView(R2.id.et_strategy_condition_order_plus_point)
    EditText mTvConditionOrderPoint;
    @BindView(R2.id.ll_strategy_condition_order_plus_point)
    LinearLayout mLlConditionOrderPlusPoint;

    //keyboardFocusedText
    @BindView(R2.id.ll_strategy_modify_stop_loss)
    TextView mTvModifyStopLoss;

    //stop loss profit
    @BindView(R2.id.ll_strategy_stoploss_strategy_type)
    LinearLayout mllStopLossStrategyType;
    @BindView(R2.id.tv_strategy_stoploss_strategy_type)
    TextView mTvStopLossStrategyType;

    @BindView(R2.id.et_strategy_stoploss_price_difference)
    EditText mEditStopLossPriceDifference;
    @BindView(R2.id.crl_strategy_stoploss_price_difference)
    EsCustomRelativeLayout mCRLStopLossPriceDifference;
    @BindView(R2.id.tv_strategy_stoploss_order_price_type)
    EditText mTvStopLossOrderPriceType;
    @BindView(R2.id.et_strategy_stoploss_order_fixed_price)
    EditText mEditStopLossOrderPrice;
    @BindView(R2.id.et_strategy_stoploss_order_plus_point)
    EditText mEditStopLossOrderPoint;
    @BindView(R2.id.ll_strategy_stoploss_plus_point)
    LinearLayout mLlStoplossPlusPoint;
    @BindView(R2.id.crl_strategy_stoploss_order)
    EsCustomRelativeLayout mCRLStopLossOrder;
    @BindView(R2.id.ll_strategy_stoploss_row)
    LinearLayout mllStopLossRow;
    @BindView(R2.id.et_strategy_stopprofit_price_difference)
    EditText mEditStopProfitPriceDifference;
    @BindView(R2.id.crl_strategy_stopprofit_price_difference)
    EsCustomRelativeLayout mCRLStopProfitPriceDifference;
    @BindView(R2.id.tv_strategy_stopprofit_order_price_type)
    EditText mTvStopProfitOrderPriceType;
    @BindView(R2.id.et_strategy_stopprofit_order_fixed_price)
    EditText mEditStopProfitOrderPrice;
    @BindView(R2.id.et_strategy_stopprofit_order_plus_point)
    EditText mEditStopProfitOrderPoint;
    @BindView(R2.id.ll_strategy_stopprofit_plus_point)
    LinearLayout mLlStopProfitPlusPoint;
    @BindView(R2.id.crl_strategy_stopprofit_order)
    EsCustomRelativeLayout mCRLStopProfitOrder;
    @BindView(R2.id.ll_strategy_stopprofit_row)
    LinearLayout mllStopProfitRow;
    @BindView(R2.id.icon_strategy_open)
    EsIconTextView mIconOpen;
    @BindView(R2.id.ll_strategy_opencover_open)
    LinearLayout mLlOpen;
    @BindView(R2.id.icon_strategy_cover)
    EsIconTextView mIconCover;
    @BindView(R2.id.ll_strategy_opencover_cover)
    LinearLayout mLlCover;
    @BindView(R2.id.crl_strategy_offset)
    EsCustomRelativeLayout mCRLOffset;
    @BindView(R2.id.icon_strategy_today)
    EsIconTextView mIconToday;
    @BindView(R2.id.ll_strategy_validtype_today)
    LinearLayout mLlValidToday;
    @BindView(R2.id.icon_strategy_long)
    EsIconTextView mIconLong;
    @BindView(R2.id.ll_strategy_validtype_longterm)
    LinearLayout mLlValidLong;
    @BindView(R2.id.et_strategy_time_strategy_type_arrive)
    LinearLayout mLlTimeConditionArrive;
    @BindView(R2.id.et_strategy_time_strategy_type_auto_open_market)
    LinearLayout mLlTimeConditionAutoOpenMarket;
    @BindView(R2.id.tv_strategy_time_trigger_mode_auto_open_market)
    EditText mEtAutoOpenMarket;

    @BindView(R2.id.es_stop_loss_rl)
    RelativeLayout mStopLossRl;
    @BindView(R2.id.es_strategy_reverse_rl)
    RelativeLayout mReverseRl;
    @BindView(R2.id.es_stop_loss_title_tip)
    EsIconTextView mStopLossTips;
    @BindView(R2.id.es_strategy_reverse_tip)
    EsIconTextView mReverseTips;

    @BindView(R2.id.es_stop_loss_add)
    EsIconTextView mStopLossAdd;
    @BindView(R2.id.es_strategy_reverse_switch)
    EsCusSwitchButton mReverseSwitch;

    private Context mContext;

    //keyboards
    private EsMultiSelectKeyboardDialog mDialogKeyboardContract;
    private EsTradeLotsKeyboard mLotsKeyboard;
    private EsTradePriceKeyboard mPriceKeyboard;
    private EsMultiSelectKeyboardDialog mDialogKeyboardPriceType;
    private EsMultiSelectKeyboardDialog mDialogKeyboardCompareType;
    private EsMultiSelectKeyboardDialog mDialogKeyboardOrderPriceType;
    private EsMultiSelectKeyboardDialog mDialogKeyboardStopStrategyType;
    private EsTimeSelectKeyboardDialog mDialogKeyboardTime;

    private EsStrategyStopLossListDialog mStopLossListDialog;

    //keyboardFocusedText
    private TextView mKeyboardFocus;

    //lists for KeyBoard
    private ArrayList<String> listPriceType = new ArrayList<>();
    private ArrayList<String> listCompareType = new ArrayList<String>() {{
        add(">");
        add("<");
        add(">=");
        add("<=");
    }};
    private ArrayList<String> listOrderPriceType = new ArrayList<>();
    private ArrayList<String> listStrategyType = new ArrayList<>();

    Unbinder unbinder;

    private OffsetClickListener mCallBack = null;
    private boolean mClickCover = false;

    public EsStrategyInputs(Context context) {
        this(context, null);
    }

    public EsStrategyInputs(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public EsStrategyInputs(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        LayoutInflater.from(context).inflate(R.layout.es_linearlayout_es_strategy_inputs, this);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        unbinder = ButterKnife.bind(this);

        initArray();
        initWidget(mContext);
        initData();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (unbinder != null) {
            unbinder.unbind();
        }
    }

    private void initArray() {
        listPriceType.add(getResources().getString(R.string.es_util_activity_default_price_type_choosing_item_last_price));
        listPriceType.add(getResources().getString(R.string.es_strategy_panel_bid));
        listPriceType.add(getResources().getString(R.string.es_strategy_panel_ask));

        listOrderPriceType.add(getResources().getString(R.string.es_util_activity_default_price_type_choosing_item_point_price));
        listOrderPriceType.add(" ");
        listOrderPriceType.add(getResources().getString(R.string.es_util_activity_default_price_type_choosing_item_last_price));
        listOrderPriceType.add(getResources().getString(R.string.es_util_activity_default_price_type_choosing_item_queue_price));
        listOrderPriceType.add(getResources().getString(R.string.es_util_activity_default_price_type_choosing_item_counter_price));
        listOrderPriceType.add(getResources().getString(R.string.es_util_activity_default_price_type_choosing_item_market_price));

        listStrategyType.add(getResources().getString(R.string.es_strategy_panel_stop_type_point_stop_both));
        listStrategyType.add(getResources().getString(R.string.es_strategy_panel_stop_type_price_limit_stop_both));
        listStrategyType.add(getResources().getString(R.string.es_strategy_panel_stop_type_price_limit_stop_lose));
        listStrategyType.add(getResources().getString(R.string.es_strategy_panel_stop_type_price_limit_stop_surplus));
        listStrategyType.add(getResources().getString(R.string.es_strategy_panel_stop_type_dynamic_tracking));
        listStrategyType.add(" ");
        listStrategyType.add(getResources().getString(R.string.es_strategy_panel_stop_type_nothing));
    }

    private void initWidget(Context context) {
        //Contract

        mEditContract.setOnFocusChangeListener(mCRLContract);
        mEditContract.setInputType(InputType.TYPE_NULL);
        mEditContract.setOnTouchListener(this);
        //Qty
        mEditQty.setOnFocusChangeListener(mCRLQty);
        mEditQty.setInputType(InputType.TYPE_NULL);
        mEditQty.setOnTouchListener(this);
        //PriceCondition&TimeCondition

        setEtDefault(mTvPriceTriggMode, mCRLPirceAndTime);
        setEtDefault(mTvPriceTriggCondition, mCRLPirceAndTime);
        setEtDefault(mTvConditionPrice, mCRLPirceAndTime);
        setEtDefault(mTvTimeTriggMode, mCRLPirceAndTime);
        setEtDefault(mTvConditionTime, mCRLPirceAndTime);
        setEtDefault(mEtAutoOpenMarket, mCRLPirceAndTime);

        if (EsStrategyData.getInstance().isPrice()) {
            mllPriceLimit.setVisibility(VISIBLE);
            mllTimeLimit.setVisibility(GONE);
        } else {
            mllTimeLimit.setVisibility(VISIBLE);
            mllPriceLimit.setVisibility(GONE);
        }

        showTimeConditionUI();
        updateStopRl();

//        if (EsStrategyData.getInstance().isOpenTrigger()) {
//            mllBonusButton.setVisibility(GONE);
//        }

        setEtDefault(mTvBonusPriceTriggMode, mCRLBonusCondition);
        setEtDefault(mTvBonusPriceTriggCondition, mCRLBonusCondition);
        setEtDefault(mTvBonusConditionPrice, mCRLBonusCondition);

        showBonusLine(EsStrategyData.getInstance().isBonus());
        //Condition Order

        setEtDefault(mTvConditionOrderPriceType, mCRLConditionOrder);
        setEtDefault(mTvConditionOrderPrice, mCRLConditionOrder);
        setEtDefault(mTvConditionOrderPoint, mCRLConditionOrder);
        setEtDefault(mTvConditionOrderPlusType, mCRLConditionOrder);


        if (EsStrategyData.getInstance().isOrderPlusAdd()) {
            mTvConditionOrderPlusType.setText("+");
        } else {
            mTvConditionOrderPlusType.setText("-");
        }
        //StopLoss Profit

        setEtDefault(mEditStopLossPriceDifference, mCRLStopLossPriceDifference);

        setEtDefault(mTvStopLossOrderPriceType, mCRLStopLossOrder);
        setEtDefault(mEditStopLossOrderPrice, mCRLStopLossOrder);
        setEtDefault(mEditStopLossOrderPoint, mCRLStopLossOrder);


        setEtDefault(mEditStopProfitPriceDifference, mCRLStopProfitPriceDifference);


        setEtDefault(mTvStopProfitOrderPriceType, mCRLStopProfitOrder);
        setEtDefault(mEditStopProfitOrderPrice, mCRLStopProfitOrder);
        setEtDefault(mEditStopProfitOrderPoint, mCRLStopProfitOrder);


        //keyboards
        mLotsKeyboard = new EsTradeLotsKeyboard(context, mEditQty);
        mLotsKeyboard.setOutsideTouchable(true);
        mPriceKeyboard = new EsTradePriceKeyboard(context, mEditStopLossPriceDifference);
        mPriceKeyboard.setOutsideTouchable(true);
        mPriceKeyboard.setListener(this);


        mDialogKeyboardPriceType = new EsMultiSelectKeyboardDialog(context, listPriceType);
        mDialogKeyboardPriceType.setListener(this);
        mDialogKeyboardPriceType.hideSearch();

        mDialogKeyboardCompareType = new EsMultiSelectKeyboardDialog(context, listCompareType);
        mDialogKeyboardCompareType.setListener(this);

        mDialogKeyboardOrderPriceType = new EsMultiSelectKeyboardDialog(context, listOrderPriceType);
        mDialogKeyboardOrderPriceType.setListener(this);
        mDialogKeyboardOrderPriceType.hideSearch();

        mDialogKeyboardStopStrategyType = new EsMultiSelectKeyboardDialog(context, listStrategyType);
        mDialogKeyboardStopStrategyType.setListener(this);

        mDialogKeyboardTime = new EsTimeSelectKeyboardDialog(context, mTvConditionTime);
        mDialogKeyboardTime.setListener(this);

        mStopLossTips.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showTips(v);
            }
        });
        mReverseTips.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                showTips(v);
            }
        });

        mStopLossListDialog = new EsStrategyStopLossListDialog(mContext);

        mStopLossAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Contract contract = EsStrategyData.getInstance().getSelectedContract();
                if (contract == null) {
                    ToastHelper.show(mContext, R.string.es_view_trade_threekey_warning_chosecontract);
                    return;
                }

                mStopLossListDialog.show();
            }
        });

        mStopLossListDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                List<OpenOrder> list = EsStrategyData.getInstance().getStopLossList();
                if (list != null && list.size() > 0) {
                    mStopLossAdd.setText(mContext.getString(R.string.es_icon_arrow_down));
                } else {
                    mStopLossAdd.setText(mContext.getString(R.string.es_icon_condition_order_add));
                }
            }
        });
    }

    public interface OffsetClickListener {
        void refreshQty(boolean refresh);
    }

    public void setCallback(OffsetClickListener callback) {
        mCallBack = callback;
    }

    private void initData() {
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (contract != null) {
            mEditContract.setText(contract.getContractName());
            if (contract.isForeignContract()) {
                mCRLOffset.setVisibility(GONE);
            }
        }
        mEditQty.setText(String.valueOf(EsStrategyData.getInstance().getDefaultQty()));
        mTvConditionPrice.setText("0");
        mTvBonusConditionPrice.setText("0");
        mTvConditionOrderPrice.setText("0");
        mEditStopLossPriceDifference.setText("0");
        mEditStopProfitPriceDifference.setText("0");
        mEditStopLossOrderPrice.setText("0");
        mEditStopProfitOrderPrice.setText("0");

        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        Date curDate = new Date(System.currentTimeMillis());
        mTvConditionTime.setText(formatter.format(curDate));

        //根据数据类的数据来初始化界面
        setUIIsOpen(EsStrategyData.getInstance().isOpen());
        setUIIsToday(EsStrategyData.getInstance().isToday());
        if (EsStrategyData.getInstance().getTriggerConditionIndex() != -1) {
            mTvPriceTriggCondition.setText(listCompareType.get(EsStrategyData.getInstance().getTriggerConditionIndex()));
        } else {
            mTvPriceTriggCondition.setText(listCompareType.get(0));
        }
        if (EsStrategyData.getInstance().getBonusTriggerConditionIndex() != -1) {
            mTvBonusPriceTriggCondition.setText(listCompareType.get(EsStrategyData.getInstance().getBonusTriggerConditionIndex()));
        } else {
            mTvBonusPriceTriggCondition.setText(listCompareType.get(0));
        }

        if (EsStrategyData.getInstance().getTriggerModeIndex() != -1) {
            mTvPriceTriggMode.setText(listPriceType.get(EsStrategyData.getInstance().getTriggerModeIndex()));
        } else {
            mTvPriceTriggMode.setText(listPriceType.get(0));
        }
        if (EsStrategyData.getInstance().getBonusTriggerModeIndex() != -1) {
            mTvBonusPriceTriggMode.setText(listPriceType.get(EsStrategyData.getInstance().getBonusTriggerModeIndex()));
        } else {
            mTvBonusPriceTriggMode.setText(listPriceType.get(0));
        }

        EsStrategyData.mST st = EsStrategyData.getInstance().getStrategyType();
        int stIndex = st.ordinal();
        if (stIndex == 5) {
            stIndex++;
        }
        setStrategyType(stIndex);

        mKeyboardFocus = mTvConditionOrderPriceType;
        if (EsStrategyData.getInstance().getConditionOrderPriceTypeIndex() != -1) {
            setOrderPrice(EsStrategyData.getInstance().getConditionOrderPriceTypeIndex());
        } else {
            setOrderPrice(0);
        }

        mKeyboardFocus = mTvStopLossOrderPriceType;
        if (EsStrategyData.getInstance().getStopLossOrderPriceTypeIndex() != -1) {
            setOrderPrice(EsStrategyData.getInstance().getStopLossOrderPriceTypeIndex());
        } else {
            setOrderPrice(0);
        }

        mKeyboardFocus = mTvStopProfitOrderPriceType;
        if (EsStrategyData.getInstance().getStopProfitOrderPriceTypeIndex() != -1) {
            setOrderPrice(EsStrategyData.getInstance().getStopProfitOrderPriceTypeIndex());
        } else {
            setOrderPrice(0);
        }
    }

    private void setTvDefault(EditText editText, EsCustomRelativeLayout layout) {
        editText.setOnFocusChangeListener(layout);
        editText.setOnTouchListener(this);
        editText.setInputType(InputType.TYPE_NULL);
    }

    private void setEtDefault(EditText editText, EsCustomRelativeLayout layout) {
        editText.setOnFocusChangeListener(layout);
        editText.setOnTouchListener(this);
        editText.setInputType(InputType.TYPE_NULL);
    }

    @OnClick({R2.id.ll_strategy_bonus_condition_button, R2.id.icon_strategy_close_bonus, R2.id.ll_strategy_stoploss_strategy_type,
            R2.id.ll_strategy_opencover_open, R2.id.ll_strategy_opencover_cover, R2.id.ll_strategy_validtype_today, R2.id.ll_strategy_validtype_longterm})
    public void onClick(View v) {
        boolean isModifyConditionOrder = EsStrategyData.getInstance().getIsModifyConditionOrder();

        if (v.getId() == mllBonusButton.getId()) {
            EsStrategyData.getInstance().setIsBonus(true);
            showBonusLine(true);
        } else if (v.getId() == mIconCloseBonusButton.getId()) {
            EsStrategyData.getInstance().setIsBonus(false);
            if (mPriceKeyboard.isShowing()) {
                mPriceKeyboard.dismiss();
            }
            showBonusLine(false);
        } else if (v.getId() == mllStopLossStrategyType.getId()) {
            mllStopLossStrategyType.setSelected(true);
            showOtherKeyboard(mDialogKeyboardStopStrategyType);
        } else if (v.getId() == mLlOpen.getId()) {
            if (isModifyConditionOrder) {
                return;
            }
            mClickCover = false;

            EsStrategyData.getInstance().setOpen(true);
            if (mCallBack != null) {
                mCallBack.refreshQty(false);
            }
            switchCheck(mIconCover, mIconOpen);
            updateStopRl();
        } else if (v.getId() == mLlCover.getId()) {
            if (isModifyConditionOrder) {
                return;
            }

            mClickCover = true;
            EsStrategyData.getInstance().setOpen(false);
            if (mCallBack != null) {
                mCallBack.refreshQty(true);
            }
            switchCheck(mIconOpen, mIconCover);
            updateStopRl();
        } else if (v.getId() == mLlValidToday.getId()) {
            if (isModifyConditionOrder) {
                return;
            }

            EsStrategyData.getInstance().setToday(true);
            switchCheck(mIconLong, mIconToday);
        } else if (v.getId() == mLlValidLong.getId()) {
            if (isModifyConditionOrder) {
                return;
            }

            switchValidLong();
        }
    }

    //由于EditText接收OnClick消息需要先设置焦点OnFocus，所以使用OnTouch来截获点击消息
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            //合约
            if (v.getId() == mEditContract.getId()) {
                if (EsStrategyData.getInstance().getIsModifyConditionOrder()) {
                    return false;
                }

                if (EsStrategyData.getInstance().getIsFromKLine()) {
                    return false;
                }

                if (mLotsKeyboard.isShowing()) {
                    mLotsKeyboard.dismiss();
                }
                if (mPriceKeyboard.isShowing()) {
                    mPriceKeyboard.dismiss();
                }

                ArrayList<String> listContract = new ArrayList<>();
                for (Contract contract : EsFavoriteListData.getInstance().getFavoriteContractArrayList()) {
                    if (contract == null) {
                        continue;
                    }

                    if (contract.isArbitrageContract()) {
                        Contract tContract = EsDataApi.getQuoteContract(contract.getContractNo());
                        if (tContract != null) {
                            listContract.add(tContract.getContractName());
                            continue;
                        }
                    }

                    listContract.add(contract.getContractName());
                }
                mDialogKeyboardContract = new EsMultiSelectKeyboardDialog(mContext, listContract);
                mDialogKeyboardContract.setListener(this);
                mDialogKeyboardContract.show();
            }
            //手数和点数
            else if (v.getId() == mEditQty.getId()) {
                showOpenLots();
                showLotsKeyboard(mEditQty, false);
            } else if (v.getId() == mEditStopLossOrderPoint.getId()) {
                showLotsKeyboard(mEditStopLossOrderPoint, true);
            } else if (v.getId() == mEditStopProfitOrderPoint.getId()) {
                showLotsKeyboard(mEditStopProfitOrderPoint, true);
            }
            //价格和价差
            else if (v.getId() == mEditStopLossPriceDifference.getId()) {
                showPriceKeyboard(mEditStopLossPriceDifference);
            } else if (v.getId() == mEditStopLossOrderPrice.getId()) {
                showPriceKeyboard(mEditStopLossOrderPrice);
            } else if (v.getId() == mEditStopProfitPriceDifference.getId()) {
                showPriceKeyboard(mEditStopProfitPriceDifference);
            } else if (v.getId() == mEditStopProfitOrderPrice.getId()) {
                showPriceKeyboard(mEditStopProfitOrderPrice);
            } else if (v.getId() == mTvConditionOrderPriceType.getId()) {
                switchConditionOrderPriceType();
            } else if (v.getId() == mTvBonusPriceTriggCondition.getId()) {
                switchPriceTriggerCondition(mTvBonusPriceTriggCondition);
            }//时间条件
            else if (v.getId() == mTvConditionTime.getId()) {
                showOtherKeyboard(mDialogKeyboardTime);
                mKeyboardFocus = mTvConditionTime;
            } else if (v.getId() == mTvBonusConditionPrice.getId()) {
                showPriceKeyboard(mTvBonusConditionPrice);
            } else if (v.getId() == mTvConditionOrderPrice.getId()) {
                showPriceKeyboard(mTvConditionOrderPrice);
            } else if (v.getId() == mTvConditionOrderPoint.getId()) {
                showLotsKeyboard(mTvConditionOrderPoint, true);
            } else if (v.getId() == mTvConditionOrderPlusType.getId()) {// + - 符号变化
                if (mLotsKeyboard.isShowing()) {
                    mLotsKeyboard.dismiss();
                }
                if (mPriceKeyboard.isShowing()) {
                    mPriceKeyboard.dismiss();
                }

                EsStrategyData.getInstance().setIsOrderPlusAdd(!EsStrategyData.getInstance().isOrderPlusAdd());
                if (EsStrategyData.getInstance().isOrderPlusAdd()) {
                    mTvConditionOrderPlusType.setText("+");
                } else {
                    mTvConditionOrderPlusType.setText("-");
                }
            }//止损止盈
            else if (v.getId() == mTvStopLossOrderPriceType.getId()) {
                showOtherKeyboard(mDialogKeyboardOrderPriceType);
                mKeyboardFocus = mTvStopLossOrderPriceType;
            } else if (v.getId() == mTvStopProfitOrderPriceType.getId()) {
                showOtherKeyboard(mDialogKeyboardOrderPriceType);
                mKeyboardFocus = mTvStopProfitOrderPriceType;
            }//价格条件等
            else if (v.getId() == mTvConditionPrice.getId()) {
                showPriceKeyboard(mTvConditionPrice);
            } else if (v.getId() == mTvPriceTriggMode.getId()) {
                showOtherKeyboard(mDialogKeyboardPriceType);
                mKeyboardFocus = mTvPriceTriggMode;
//                switchPriceTriggerMode(mTvPriceTriggMode.getId());
            } else if (v.getId() == mTvPriceTriggCondition.getId()) {
                switchPriceTriggerCondition(mTvPriceTriggCondition);
            } else if (v.getId() == mTvBonusPriceTriggMode.getId()) {
//                switchPriceTriggerMode(mTvBonusPriceTriggMode.getId());
                showOtherKeyboard(mDialogKeyboardPriceType);
                mKeyboardFocus = mTvBonusPriceTriggMode;
            } else if (v.getId() == mTvTimeTriggMode.getId() || v.getId() == mEtAutoOpenMarket.getId()) {
                switchTimeConditionStrategyType();
            }
        }
        return false;
    }

    private void switchConditionOrderPriceType() {
        if (!EsStrategyData.getInstance().isOpenTrigger()) {
            showOtherKeyboard(mDialogKeyboardOrderPriceType);
            mKeyboardFocus = mTvConditionOrderPriceType;
        } else {
            ToastHelper.show(mContext, R.string.es_trade_strategy_opentrigger_can_only_be_absolute_price);
        }
    }

    private void switchTimeConditionStrategyType() {
        EsLoginAccountData.LoginAccount currentAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        if (currentAccount == null || EsDataApi.isDipperTradeStar(currentAccount)) {
            return;
        }

        boolean isAutoOrder = EsStrategyData.getInstance().isOpenTrigger();
        // 自动单只支持启明星后台
        if (!isAutoOrder && !EsDataApi.isVenusTradeStar(currentAccount)) {
            return;
        }
        EsStrategyData.getInstance().setIsOpenTrigger(!isAutoOrder);
        updateAutoOrderUI(!isAutoOrder);

        showTimeConditionUI();

        updateStopRl();
    }

    public void updateAutoOrderUI(boolean isAutoOrder) {
        if (isAutoOrder) {
            EsStrategyData.getInstance().setIsBonus(false);
            // 自動單只支持指定價和当日有效
            mKeyboardFocus = mTvConditionOrderPriceType;
            setOrderPrice(0);
            EsStrategyData.getInstance().setToday(true);
        }
    }


    /**
     * 根据是否自动单调节时间单UI
     */
    public void showTimeConditionUI() {
        boolean isAutoOrder = EsStrategyData.getInstance().isOpenTrigger();
        EsLoginAccountData.LoginAccount currentAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        // 暂时只支持启明星
        boolean isDayStar = EsDataApi.isVenusTradeStar(currentAccount);
        if (isAutoOrder && isDayStar) {
            mLlTimeConditionAutoOpenMarket.setVisibility(View.VISIBLE);
            mLlTimeConditionArrive.setVisibility(View.GONE);
            mllBonusButton.setVisibility(GONE);
            mCRLBonusCondition.setVisibility(GONE);
            switchCheck(mIconLong, mIconToday);
        } else {
            mLlTimeConditionAutoOpenMarket.setVisibility(View.GONE);
            mLlTimeConditionArrive.setVisibility(View.VISIBLE);
            mllBonusButton.setVisibility(VISIBLE);
        }
    }

    private void switchPriceTriggerCondition(EditText editText) {
        if (editText == null) {
            return;
        }

        if (mLotsKeyboard.isShowing()) {
            mLotsKeyboard.dismiss();
        }
        if (mPriceKeyboard.isShowing()) {
            mPriceKeyboard.dismiss();
        }

        int index = listCompareType.indexOf(editText.getText().toString());
        if (index == listCompareType.size() - 1) {
            index = 0;
        } else {
            index++;
        }
        mKeyboardFocus = editText;
        setPriceTriggerCondition(index);
    }

    public void switchPriceAndTime(boolean isPrice) {
        if (isPrice) {
            mllPriceLimit.setVisibility(VISIBLE);
            mllTimeLimit.setVisibility(GONE);
            //同时附加条件的大小需要改变
            ViewGroup.LayoutParams layoutParams = mllBonusButton.getLayoutParams();
            layoutParams.width = (int) mContext.getResources().getDimension(R.dimen.x262);
            mllBonusButton.setLayoutParams(layoutParams);
            showBonusLine(EsStrategyData.getInstance().isBonus());
            EsStrategyData.getInstance().setIsOpenTrigger(false);
        } else {
            mllTimeLimit.setVisibility(VISIBLE);
            mllPriceLimit.setVisibility(GONE);
            //同时附加条件的大小需要改变
            ViewGroup.LayoutParams layoutParams = mllBonusButton.getLayoutParams();
            layoutParams.width = (int) mContext.getResources().getDimension(R.dimen.x262);
            mllBonusButton.setLayoutParams(layoutParams);
            showBonusLine(EsStrategyData.getInstance().isBonus());
            if (EsStrategyData.getInstance().isOpenTrigger()) {//开盘触发无附加
                mllBonusButton.setVisibility(GONE);
                mCRLBonusCondition.setVisibility(GONE);
            }
        }
    }

    public void setOrderPriceType(char orderPriceType, String orderPrice, double orderPriceOver, double tickPrice) {
        // 时间条件单设置orderPriceType
        mKeyboardFocus = mTvConditionOrderPriceType;
        String orderPriceTypeStr;
        if (orderPriceType == EsDataConstant.S_PT_ABS) {
            orderPriceTypeStr = getResources().getString(R.string.es_util_activity_default_price_type_choosing_item_point_price);


            mTvConditionOrderPrice.setText(orderPrice);
        } else {
            orderPriceTypeStr = EstarTransformation.apiPriceTypeToStr(mContext, orderPriceType);
        }
        setOrderPrice(listOrderPriceType.indexOf(orderPriceTypeStr));

        boolean isAdd = orderPriceOver > 0;
        int flag = isAdd ? 1 : -1;
        EsStrategyData.getInstance().setIsOrderPlusAdd(isAdd);

        int point = (int) (orderPriceOver / (tickPrice * flag));

        if (isAdd) {
            mTvConditionOrderPlusType.setText("+");
        } else {
            mTvConditionOrderPlusType.setText("-");
        }
        mTvConditionOrderPoint.setText(String.valueOf(point));
    }

    public void switchValidLong() {
//        EsStrategyData.getInstance().setToday(false);
//        switchCheck(mIconToday, mIconLong);

        if (!EsStrategyData.getInstance().isOpenTrigger()) {
            EsStrategyData.getInstance().setToday(false);
            switchCheck(mIconToday, mIconLong);
        } else {
            ToastHelper.show(mContext, R.string.es_trade_strategy_opentrigger_can_only_be_valid_short);
        }
    }

    public void modifyCheckUI() {
        changeIconUI(mIconOpen);
        changeIconUI(mIconCover);
        changeIconUI(mIconToday);
        changeIconUI(mIconLong);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mEditContract.setTextColor(getResources().getColor(R.color.es_strategyStrokeColor, null));
        }
    }

    private void changeIconUI(EsIconTextView iconTextView) {
        if (getResources().getString(R.string.es_icon_keyboard_check).equals(iconTextView.getText().toString())) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                iconTextView.setTextColor(getResources().getColor(R.color.es_panelBidColor_transparent, null));
            }
        }
    }

    private void switchCheck(EsIconTextView from, EsIconTextView to) {
        from.setText(R.string.es_icon_keyboard_uncheck);
        to.setText(R.string.es_icon_keyboard_check);
    }

    private void showOpenLots() {

        if (mClickCover) {
            mLotsKeyboard.showOpenQty(false, 0);
            return;
        }

        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        char hedge = EsSPHelperProxy.getIsHedge(mContext) ? EsDataConstant.S_HEDGE_HEDGE : EsDataConstant.S_HEDGE_SPECULATE;
        EsStrategyData data = EsStrategyData.getInstance();
        char orderType = EsDataConstant.S_ORDERTYPE_LIMIT;
        char orderPriceType = data.getConditionOrderPriceType();
        String buyStr = "0", sellStr = "0";
        double buyPrice = 0;
        double sellPrice = 0;
        if (contract != null) {
            String price = getPriceStrOrder();
            if (orderPriceType != EsDataConstant.S_PT_ABS) {
                QuoteBetData quoteBetData = new QuoteBetData(contract);
                price = quoteBetData.getLastPriceString();
            }
            buyStr = sellStr = EsDataApi.getDoubleStrFromFractionStr(price, contract.getCommodity().getPriceDeno());
        }
        try {
            if (buyStr != null) {
                buyPrice = Double.parseDouble(buyStr);
            }

            if (sellStr != null) {
                sellPrice = Double.parseDouble(sellStr);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        if (orderPriceType == EsSPHelperProxy.S_PT_MARKET) {
            orderType = EsDataConstant.S_ORDERTYPE_MARKET;
        }

        EsOpenCount openCount = EsCalculateUtil.getOpenQty(contract, buyPrice, sellPrice, hedge, orderType);
        mLotsKeyboard.showOpenQty(openCount.getBuyCount(), openCount.getSellCount());

    }

    private void showLotsKeyboard(TextView edit, boolean show) {
        mLotsKeyboard.setEdit(edit);
        mLotsKeyboard.showAtLocation(getRootView(), Gravity.BOTTOM, 0, 0);
        mLotsKeyboard.setReInput(true);
        if (show) {
            mLotsKeyboard.showOpenQty(0, 0);
        }
        if (mPriceKeyboard.isShowing()) {
            mPriceKeyboard.dismiss();
        }
    }

    private void showPriceKeyboard(TextView edit) {
        mPriceKeyboard.setEdit(edit);
        mPriceKeyboard.showAtLocation(getRootView(), Gravity.BOTTOM, 0, 0);
        mPriceKeyboard.setReInput(true);
        if (mLotsKeyboard.isShowing()) {
            mLotsKeyboard.dismiss();
        }
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (contract != null) {
            mPriceKeyboard.EnableDecimalPoint(!(contract.getCommodity().getPriceDeno() > 1));
        }
    }

    private void showOtherKeyboard(Dialog dialog) {
        if (mLotsKeyboard.isShowing()) {
            mLotsKeyboard.dismiss();
        }
        if (mPriceKeyboard.isShowing()) {
            mPriceKeyboard.dismiss();
        }
        dialog.show();
    }

    /**
     * 价格键盘继承过来的四个回调，可要可不要
     */
    @Override
    public void customOnPriceKeyDown(EsTradePriceKeyboardView keyboardView, int keyId, boolean isSpecial) {
    }

    @Override
    public Contract onGetContract(EsTradePriceKeyboardView keyboardView) {
        return EsStrategyData.getInstance().getSelectedContract();
    }

    @Override
    public double onGetLastPrice(EsTradePriceKeyboardView keyboardView) {
        return 0;
    }

    @Override
    public void onChangeValidType(EsTradePriceKeyboardView keyboardView, char ValidType) {

    }

    @Override
    public void OnSelect(int index, EsMultiSelectKeyboardDialog dialog) {

        if (dialog == mDialogKeyboardCompareType) {
            setPriceTriggerCondition(index);
        } else if (dialog == mDialogKeyboardPriceType) {
            setPriceTriggerMode(index);
        } else if (dialog == mDialogKeyboardStopStrategyType) {
            setStrategyType(index);
        } else if (dialog == mDialogKeyboardOrderPriceType) {
            if (index >= 0) {
                setOrderPrice(index);
            }
        } else if (dialog == mDialogKeyboardContract) {
            if (index == -1) {
                EsStrategyData.getInstance().setToSearch(true);
                EsUIApi.startSearchActivity(EsStrategyData.KEY_SEARCH_SOURCE);
                return;
            }
            setContract(index);
        }
    }

    private void setContract(int index) {
        Contract contract = EsFavoriteListData.getInstance().getFavoriteContractArrayList().get(index);

        // 条件单不支持套利合约
        if (contract.isArbitrageContract()) {
            ToastHelper.show(mContext, R.string.es_trade_position_stoploss_cannot_is_spreadContract);
            return;
        }
        setContract(contract);
    }

    public void setContract(String ContractNo) {
        Contract contract = EsDataApi.getQuoteContract(ContractNo);
        setContract(contract);
    }

    private void setContract(Contract contract) {
        if (contract != null) {
            EsStrategyData.getInstance().setSelectedContract(mContext, contract.getContractNo());
            mEditContract.setText(contract.getContractName());
            mEditQty.setText(String.valueOf(EsStrategyData.getInstance().getDefaultQty()));
            if (contract.isForeignContract()) {
                mCRLOffset.setVisibility(GONE);
                if (mCallBack != null) {
                    mCallBack.refreshQty(false);
                }
            } else {
                mCRLOffset.setVisibility(VISIBLE);
                if (mCallBack != null) {
                    if (getContext().getString(R.string.es_icon_keyboard_check).equals(mIconCover.getText().toString())) {
                        mCallBack.refreshQty(true);
                    } else if (getContext().getString(R.string.es_icon_keyboard_uncheck).equals(mIconCover.getText().toString())) {
                        mCallBack.refreshQty(false);
                    }
                }
            }
            if (!EsDataApi.isMarketPriceAvailable(contract) && EsStrategyData.getInstance().getConditionOrderPriceType() == EsDataConstant.S_PT_MARKET) {//如果市价不可用
                if (EsSPHelper.getMarketPriceSetting(mContext) || (EsDataApi.isForeignContract(contract.getCommodity()))) {
                    // 配置市价可用的外盘合约依旧变更为市价不可用(由于外盘合约无涨跌停价)
                    ToastHelper.show(mContext, R.string.es_strategy_market_price_not_available);
                    mKeyboardFocus = mTvConditionOrderPriceType;
                    setOrderPrice(4);//则设置为对手价
                }
            }

            EsStrategyData.getInstance().setStopLossList(null);
            if (mStopLossAdd != null) {
                mStopLossAdd.setText(mContext.getString(R.string.es_icon_condition_order_add));
            }
            updateStopRl();
        }
    }

    public void updateStopRl() {
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (contract != null && contract.isForeignContract()) {
            mStopLossRl.setVisibility(GONE);
            mReverseRl.setVisibility(GONE);
            return;
        }

        if (EsStrategyData.getInstance().isOpenTrigger()) {
            mStopLossRl.setVisibility(GONE);
            mReverseRl.setVisibility(GONE);
            return;
        }

        if (EsStrategyData.getInstance().isOpen()) {
            mStopLossRl.setVisibility(VISIBLE);
            mReverseRl.setVisibility(GONE);
        } else {
            mStopLossRl.setVisibility(GONE);
            mReverseRl.setVisibility(VISIBLE);
        }
    }

    private void setPriceTriggerCondition(int index) {
        if (mKeyboardFocus == mTvPriceTriggCondition) {
            mTvPriceTriggCondition.setText(listCompareType.get(index));
            EsStrategyData.getInstance().setTriggerCondition(index);
        } else if (mKeyboardFocus == mTvBonusPriceTriggCondition) {
            mTvBonusPriceTriggCondition.setText(listCompareType.get(index));
            EsStrategyData.getInstance().setBonusTriggerCondition(index);
        }
    }

    private void setPriceTriggerMode(int index) {
        if (mKeyboardFocus == mTvPriceTriggMode) {
            mTvPriceTriggMode.setText(listPriceType.get(index));
            EsStrategyData.getInstance().setTriggerMode(index);
        } else if (mKeyboardFocus == mTvBonusPriceTriggMode) {
            mTvBonusPriceTriggMode.setText(listPriceType.get(index));
            EsStrategyData.getInstance().setBonusTriggerMode(index);
        }
    }

    private void switchPriceTriggerMode(int id) {
        if (id == mTvPriceTriggMode.getId()) {
            int indexRaw = (EsStrategyData.getInstance().getTriggerModeIndex() + 1) % 3;
            mTvPriceTriggMode.setText(listPriceType.get(indexRaw));
            EsStrategyData.getInstance().setTriggerMode(indexRaw);
        } else if (id == mTvBonusPriceTriggMode.getId()) {
            int indexRaw = (EsStrategyData.getInstance().getBonusTriggerModeIndex() + 1) % 3;
            mTvBonusPriceTriggMode.setText(listPriceType.get(indexRaw));
            EsStrategyData.getInstance().setBonusTriggerMode(indexRaw);
        }
    }

    private void setStrategyType(int index) {
        mTvStopLossStrategyType.setText(listStrategyType.get(index));
        if (index == 0) {//指定止损止盈
            EsStrategyData.getInstance().setStrategyType(EsStrategyData.mST.SpecifiedStopLP);
            mllStopLossRow.setVisibility(VISIBLE);
            mllStopProfitRow.setVisibility(VISIBLE);
            mCRLStopLossPriceDifference.setTitle("止损价");
            mCRLStopProfitPriceDifference.setTitle("止盈价");
        } else if (index == 1) {//限价止损+限价止盈
            EsStrategyData.getInstance().setStrategyType(EsStrategyData.mST.StopLP);
            mllStopLossRow.setVisibility(VISIBLE);
            mllStopProfitRow.setVisibility(VISIBLE);
            mCRLStopLossPriceDifference.setTitle("止损价差");
            mCRLStopProfitPriceDifference.setTitle("止盈价差");
        } else if (index == 2) {//限价止损
            EsStrategyData.getInstance().setStrategyType(EsStrategyData.mST.StopL);
            mllStopLossRow.setVisibility(VISIBLE);
            mCRLStopLossPriceDifference.setTitle("止损价差");
            mllStopProfitRow.setVisibility(GONE);
        } else if (index == 3) {//限价止盈
            EsStrategyData.getInstance().setStrategyType(EsStrategyData.mST.StopP);
            mllStopLossRow.setVisibility(GONE);
            mllStopProfitRow.setVisibility(VISIBLE);
            mCRLStopProfitPriceDifference.setTitle("止盈价差");
        } else if (index == 4) {//动态追踪 使用的还是止损行的内容
            EsStrategyData.getInstance().setStrategyType(EsStrategyData.mST.Float);
            mllStopLossRow.setVisibility(VISIBLE);
            mCRLStopLossPriceDifference.setTitle("浮动点数");
            mllStopProfitRow.setVisibility(GONE);
        } else if (index == 5) {//空行

        } else if (index == 6) {//无止损策略
            EsStrategyData.getInstance().setStrategyType(EsStrategyData.mST.None);
            mllStopLossRow.setVisibility(GONE);
            mllStopProfitRow.setVisibility(GONE);
        }
    }

    public String getStrategyTypeStr() {
        return mTvStopLossStrategyType.getText().toString();
    }

    private void setOrderPrice(int index) {
        if (mKeyboardFocus == mTvConditionOrderPriceType) {//委托价格变动
            boolean isConfigMarketPriceSetting = EsSPHelper.getMarketPriceSetting(mContext);
            Contract contract = EsStrategyData.getInstance().getSelectedContract();
            if (contract != null && index == 5) {
                if (!EsDataApi.isMarketPriceAvailable(contract) && (isConfigMarketPriceSetting || EsDataApi.isForeignContract(contract.getCommodity()))) {
                    ToastHelper.show(mContext, R.string.es_strategy_market_price_not_available);
                    return;
                } else if (!EsDataApi.isMarketPriceAvailable(contract) && !isConfigMarketPriceSetting){
                    ToastHelper.show(mContext, R.string.es_market_price_limit_up_and_down);
                }
            }
            mTvConditionOrderPriceType.setText(listOrderPriceType.get(index));
            EsStrategyData.getInstance().setConditionOrderPriceType(index);
            if (index == 0) {//指定价
                //指定价的话，需要refresh一下价格控件？
                mLlConditionOrderPlusPoint.setVisibility(GONE);
                mLlConditionOrderPrice.setVisibility(VISIBLE);
            } else if (index == 5) {//TODO切换市价改为点数消失
                mLlConditionOrderPlusPoint.setVisibility(GONE);
                mLlConditionOrderPrice.setVisibility(GONE);
            } else {
                mLlConditionOrderPlusPoint.setVisibility(VISIBLE);
                mLlConditionOrderPrice.setVisibility(GONE);
            }
        } else if (mKeyboardFocus == mTvStopLossOrderPriceType) {//委托价格变动
            mTvStopLossOrderPriceType.setText(listOrderPriceType.get(index));
            EsStrategyData.getInstance().setStopLossOrderPriceType(index);
            if (index == 0) {
                mLlStoplossPlusPoint.setVisibility(GONE);
                mEditStopLossOrderPrice.setVisibility(VISIBLE);
            } else {
                mLlStoplossPlusPoint.setVisibility(VISIBLE);
                mEditStopLossOrderPrice.setVisibility(GONE);
            }
        } else if (mKeyboardFocus == mTvStopProfitOrderPriceType) {//委托价格变动
            mTvStopProfitOrderPriceType.setText(listOrderPriceType.get(index));
            EsStrategyData.getInstance().setStopProfitOrderPriceType(index);
            if (index == 0) {
                mLlStopProfitPlusPoint.setVisibility(GONE);
                mEditStopProfitOrderPrice.setVisibility(VISIBLE);
            } else {
                mLlStopProfitPlusPoint.setVisibility(VISIBLE);
                mEditStopProfitOrderPrice.setVisibility(GONE);
            }
        }
    }

    public void showTips(View view) {
        ViewTooltip.on(view)
                .color(getResources().getColor(R.color.es_viewBkColor))
                .color(getResources().getColor(R.color.es_subTextColor))
                .autoHide(true, 1500)
                .corner(30)
                .position(ViewTooltip.Position.TOP)
                .text(getResources().getString(R.string.es_activity_strategy_additional_stop_loss_profit_tips))
                .show();
    }

    @Override
    public void OnDismiss(EsMultiSelectKeyboardDialog dialog) {
        if (dialog == mDialogKeyboardStopStrategyType) {
            mllStopLossStrategyType.setSelected(false);
        }
    }

    public String getContractStr() {
        return mEditContract.getText().toString();
    }

    public void setQty(BigInteger qty) {
        mEditQty.setText(qty.toString());
    }

    public String getQty() {
        return mEditQty.getText().toString();
    }

    public String getTimeCondition() {
        return mTvConditionTime.getText().toString();
    }

    public String getPriceStrCondition() {
        return mTvConditionPrice.getText().toString();
    }

    public String getPriceStrBonusCondition() {
        return mTvBonusConditionPrice.getText().toString();
    }

    public String getPriceStrOrder() {
        return mTvConditionOrderPrice.getText().toString();
    }

    public String getPointStrOrder() {
        return mTvConditionOrderPoint.getText().toString();
    }

    public String getPriceStrStopLoss() {
        return mEditStopLossPriceDifference.getText().toString();
    }

    public String getPriceTypeStrStopLossOrder() {
        return mTvStopLossOrderPriceType.getText().toString();
    }

    public String getPriceStrStopLossOrder() {
        return mEditStopLossOrderPrice.getText().toString();
    }

    public String getPointStrStopLossOrder() {
        return mEditStopLossOrderPoint.getText().toString();
    }

    public String getPriceTypeStrStopProfitOrder() {
        return mTvStopProfitOrderPriceType.getText().toString();
    }

    public String getPriceStrStopProfit() {
        return mEditStopProfitPriceDifference.getText().toString();
    }

    public String getPriceStrStopProfitOrder() {
        return mEditStopProfitOrderPrice.getText().toString();
    }

    public String getPointStrStopProfitOrder() {
        return mEditStopProfitOrderPoint.getText().toString();
    }

    public void refreshPrices(double lastPrice) {
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (contract == null) {
            return;
        }
        String lp = EsDataApi.formatPrice(contract.getCommodity(), lastPrice, false);
        if (mTvConditionPrice != null) {
            mTvConditionPrice.setText(lp);
            mTvBonusConditionPrice.setText(lp);
            mTvConditionOrderPrice.setText(lp);
            mEditStopLossOrderPrice.setText(lp);
            mEditStopProfitOrderPrice.setText(lp);
        }
    }

    public void setUIIsToday(boolean isToday) {
        if (isToday) {
            onClick(mLlValidToday);
        } else {
            onClick(mLlValidLong);
        }
    }

    public void setUIIsOpen(boolean isOpen) {
        if (isOpen) {
            onClick(mLlOpen);
        } else {
            onClick(mLlCover);
        }
    }

    public void setTriggerPrice(char triggerCondition1, char triggerCondition2, double triggerPrice1, double triggerPrice2) {
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (contract == null) {
            return;
        }

        int triggerConditionIndex1 = EsStrategyData.getInstance().getTriggerConditionIndex(triggerCondition1);

        if (triggerConditionIndex1 != -1) {
            mTvPriceTriggCondition.setText(listCompareType.get(triggerConditionIndex1));
            EsStrategyData.getInstance().setTriggerCondition(triggerConditionIndex1);
        } else {
            mTvPriceTriggCondition.setText(listCompareType.get(0));
            EsStrategyData.getInstance().setTriggerCondition(0);
        }

        String triggerPrice1Str = EsDataApi.formatPrice(contract.getCommodity(), triggerPrice1, false);
        if (mTvConditionPrice != null) {
            mTvConditionPrice.setText(triggerPrice1Str);
        }

        if (triggerCondition2 == 0) {
            showBonusLine(false);
            EsStrategyData.getInstance().setIsBonus(false);
        } else {
            EsStrategyData.getInstance().setIsBonus(true);
            showBonusLine(true);
            int triggerConditionIndex2 = EsStrategyData.getInstance().getTriggerConditionIndex(triggerCondition2);
            if (triggerConditionIndex2 != -1) {
                mTvBonusPriceTriggCondition.setText(listCompareType.get(triggerConditionIndex2));
                EsStrategyData.getInstance().setBonusTriggerCondition(triggerConditionIndex2);
            } else {
                mTvBonusPriceTriggCondition.setText(listCompareType.get(0));
                EsStrategyData.getInstance().setBonusTriggerCondition(0);
            }

            String triggerPrice2Str = EsDataApi.formatPrice(contract.getCommodity(), triggerPrice2, false);
            if (mTvBonusConditionPrice != null) {
                mTvBonusConditionPrice.setText(triggerPrice2Str);
            }
        }
    }

    public void setTriggerTime(String timeCondition, char triggerCondition2, double triggerPrice2) {
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (contract == null) {
            return;
        }

        mTvConditionTime.setText(timeCondition);

        if (triggerCondition2 == 0) {
            showBonusLine(false);
            EsStrategyData.getInstance().setIsBonus(false);
        } else {
            EsStrategyData.getInstance().setIsBonus(true);
            showBonusLine(true);
            int triggerConditionIndex2 = EsStrategyData.getInstance().getTriggerConditionIndex(triggerCondition2);
            if (triggerConditionIndex2 != -1) {
                mTvBonusPriceTriggCondition.setText(listCompareType.get(triggerConditionIndex2));
            } else {
                mTvBonusPriceTriggCondition.setText(listCompareType.get(0));
            }

            String triggerPrice2Str = EsDataApi.formatPrice(contract.getCommodity(), triggerPrice2, false);
            if (mTvBonusConditionPrice != null) {
                mTvBonusConditionPrice.setText(triggerPrice2Str);
            }
        }
    }

    @Override
    public void OnSetOpenTriggerTime(boolean isOpenTrigger, EsTimeSelectKeyboardDialog dialog) {
        EsStrategyData.getInstance().setIsOpenTrigger(isOpenTrigger);

        if (isOpenTrigger) {
            mTvTimeTriggMode.setText(R.string.es_strategy_input_auto_order);
            if (mPriceKeyboard.isShowing()) {
                mPriceKeyboard.dismiss();
            }
            mCRLBonusCondition.setVisibility(GONE);
            mllBonusButton.setVisibility(GONE);
            onClick(mLlValidLong);
        } else {
            mTvTimeTriggMode.setText(R.string.es_strategy_input_arrive);
            showBonusLine(EsStrategyData.getInstance().isBonus());
        }

    }

    public void showBonusLine(boolean show) {
        if (show) {
            mCRLBonusCondition.setVisibility(VISIBLE);
            mllBonusButton.setVisibility(GONE);
        } else {
            mCRLBonusCondition.setVisibility(GONE);
            mllBonusButton.setVisibility(VISIBLE);
        }
    }

    @Override
    public void OnDismiss(EsTimeSelectKeyboardDialog dialog) {
        //时间的
    }

    public boolean isReverse() {
        Contract contract = EsStrategyData.getInstance().getSelectedContract();
        if (contract != null && contract.isForeignContract()) {
            return false;
        }

        if (EsStrategyData.getInstance().isOpenTrigger()) {
            return false;
        }

        if (mReverseRl == null) {
            return false;
        }

        if (mReverseRl.getVisibility() == GONE) {
            return false;
        }

        if (mReverseSwitch.getVisibility() == GONE) {
            return false;
        }

        return mReverseSwitch.isChecked();
    }

    public void hideStopLoss() {
        mStopLossRl.setVisibility(View.GONE);
    }

    public void setReverseOrder() {
        mReverseRl.setVisibility(VISIBLE);
        mReverseSwitch.setChecked(true);
    }
}
