package com.esunny.ui.common;

public class EsConstant {

    //字符串分隔符
    public static final String SPLIT = "#";
    //保存自选合约
    public static final String FAVORITECONTRACT_KEY = "EstarFavoriteContract";
}
