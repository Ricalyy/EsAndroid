package com.esunny.ui.common.setting.condition;

import android.content.Intent;
import android.os.Build;
import android.os.Looper;
import android.os.MessageQueue;
import androidx.recyclerview.widget.RecyclerView;
import android.util.SparseArray;
import android.view.View;
import android.widget.PopupWindow;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.R;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.ui.common.setting.condition.adapter.EsConditionalOrderAdapter;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.dialog.EsCustomDialog;
import com.esunny.ui.util.EsInsertOrderHelper;
import com.esunny.ui.view.EsBaseToolBar;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import static com.esunny.data.api.EsDataConstant.S_OAT_CANCEL;
import static com.esunny.data.api.EsDataConstant.S_OAT_RESUME;
import static com.esunny.data.api.EsDataConstant.S_OAT_SUSPEND;
import static com.esunny.ui.api.EsEventConstant.E_STAR_ACTION_CONDITION_NUM;
import static com.esunny.ui.api.EsEventConstant.E_STAR_MODULE_TRADE;


@Route(path = RoutingTable.ES_CONDITIONAL_ORDER_ACTIVITY)
public class EsConditionalOrderActivity extends EsBaseConditionActivity {

    public static WeakReference<EsConditionalOrderActivity> weakReference = null;
    @Override
    protected void initWidget() {
        super.initWidget();

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                ((EsConditionalOrderAdapter) mAdapter).recoverList();
            }
        });

        weakReference = new WeakReference<>(EsConditionalOrderActivity.this);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_conditional_order;
    }

    @Override
    protected void initAdapter() {
        mAdapter = new EsConditionalOrderAdapter(this);
        ((EsConditionalOrderAdapter) mAdapter).setOrderData(mOrderDatas);
        ((EsConditionalOrderAdapter) mAdapter).setListType(EsConditionalOrderAdapter.ListTypeCondition);
        ((EsConditionalOrderAdapter) mAdapter).setOnItemClick(new EsConditionalOrderAdapter.OnItemClick() {
            @Override
            public void itemClick(char action, OrderData data) {
                //判断用户是否在线
                if (EsInsertOrderHelper.checkCanTrade(EsConditionalOrderActivity.this)) {
                    int ret = -1;
                    if (action == S_OAT_SUSPEND) {
                        ret = EsDataApi.suspendTradeOrder(data);
//                        data.setOrderState(EsDataConstant.S_ORDERSTATE_SUSPENDED);
                    } else if (action == S_OAT_RESUME) {
                        ret = EsDataApi.resumeTradeOrder(data);
//                        data.setOrderState(EsDataConstant.S_ORDERSTATE_TRIGGERING);
                    } else if (action == S_OAT_CANCEL) {
                        ret = EsDataApi.deleteTradeOrder(data);
//                        data.setOrderState(EsDataConstant.S_ORDERSTATE_CANCELED);
                    }
                    ((EsConditionalOrderAdapter) mAdapter).resetPopupWindow();
                }
            }

            @Override
            public void toKLine(String contractNo) {
                Contract contract = EsDataApi.getQuoteContract(contractNo);
                if (contract != null) {
                    EsFavoriteListData.getInstance().addFavoriteContract(contract,false);
                    EsUIApi.startEsKLineActivity(EsUIConstant.S_CONTRACT_LIST_FAVORITE,
                            EsFavoriteListData.getInstance().getFavoriteIndex(contractNo), EsUIConstant.TO_KLINE_FROM_CONDITIONAL);
                }
            }

            @Override
            public void modifyConditionOrder(OrderData orderData) {
                if (EsInsertOrderHelper.checkCanTrade(EsConditionalOrderActivity.this)) {
                    if (orderData.getStrategyType() == EsDataConstant.S_ST_CONDITION_PARENT) {
                        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
                        if (account == null) {
                            return;
                        }

                        EsUIApi.startEsStrategyStopActivity(orderData.getOrderNo(), 'C');
                    } else {
                        Intent intent = new Intent(EsConditionalOrderActivity.this, EsStrategyActivity.class);
                        intent.putExtra("modifyCondition", true);
                        intent.putExtra("orderData", orderData);
                        startActivity(intent);
                    }
                }
            }

            @Override
            public void deleteAllOrder(final List<OrderData> orderDataList, final PopupWindow popupWindow, final SparseArray<PopupWindow> popupWindowHashMap) {
                EsCustomDialog dialog = EsCustomDialog.create(EsConditionalOrderActivity.this);
                dialog.setTitle(getApplicationContext().getString(R.string.es_trade_option_dialog_cancel_all))
                        .setContent(getApplicationContext().getString(R.string.es_trade_option_dialog_cancel_all_message))
                        .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                            @Override
                            public void onConfirm() {
                                for (OrderData orderData : orderDataList) {
                                    int ret = EsDataApi.deleteTradeOrder(orderData);
                                }
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    Looper.getMainLooper().getQueue().addIdleHandler(new MessageQueue.IdleHandler() {
                                        @Override
                                        public boolean queueIdle() {
                                            if (popupWindow != null && popupWindow.isShowing()) {
                                                popupWindow.dismiss();
                                            }
                                            int size = popupWindowHashMap.size();
                                            for (int i = 0; i < size;i++) {
                                                PopupWindow popupWindow = popupWindowHashMap.get(i);
                                                if (popupWindow != null && popupWindow.isShowing()) {
                                                    popupWindow.dismiss();
                                                }
                                            }
                                            return false;
                                        }
                                    });
                                }
                            }

                            @Override
                            public void onCancel() {

                            }
                        }).show();
            }
        });
    }

    @Override
    protected void getOrderData() {
        if (mOrderDatas == null) {
            mOrderDatas = new ArrayList<>();
        }
        mOrderDatas.clear();
        EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        if (loginAccount == null) {
            return;
        }
        List<OrderData> orderData = getCurrentAccountOrderData(loginAccount.getUserNo(), loginAccount.getCompanyNo(), loginAccount.getAddrTypeNo());
        for (OrderData data : orderData) {
            //显示条件单
            if (data == null) {
                continue;
            }

            char strategyType = data.getStrategyType();
            char orderState = data.getOrderState();

            if ((strategyType == EsDataConstant.S_ST_CONDITION
                    || strategyType == EsDataConstant.S_ST_CONDITION_PARENT
                    || strategyType == EsDataConstant.S_ST_BACKHAND
                    || strategyType == EsDataConstant.S_ST_AUTOORDER)
                    && orderState != EsDataConstant.S_ORDERSTATE_FILLTRIGGERED
                    && orderState != EsDataConstant.S_ORDERSTATE_TRIGGERFAILED
                    && orderState != EsDataConstant.S_ORDERSTATE_FAIL
                    && orderState != EsDataConstant.S_ORDERSTATE_CANCELED
                    && orderState != EsDataConstant.S_ORDERSTATE_INVALID
                    && orderState != '\u0000') {
                mOrderDatas.add(data);
            }
        }

        EsEventMessage message = new EsEventMessage.Builder(E_STAR_ACTION_CONDITION_NUM).setSender(E_STAR_MODULE_TRADE).setData(mOrderDatas.size()).buildEvent();
        EventBus.getDefault().post(message);
    }

    private List<OrderData> getCurrentAccountOrderData(String userNo, String companyNo, String addrNo) {
        return EsDataApi.getOrderData(companyNo, userNo, addrNo, EsDataConstant.S_ST_CONDITION, '\0', "", -1, true);
    }

    @Override
    protected void initViewValue() {
        mBaseToolBar.setTitle(getString(R.string.es_activity_conditional_order_basetoolbar));
        mBaseToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
        mBaseToolBar.setRightIcons(new int[]{R.string.es_icon_condition_order_add, R.string.es_icon_condition_order_filltriggered_new});
    }

    @Override
    protected void bindOnClick() {
        mBaseToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_left_first) {
                    finish();
                } else if (id == R.id.toolbar_right_first) {
                    startActivity(new Intent(EsConditionalOrderActivity.this, EsStrategyActivity.class));
                } else if (id == R.id.toolbar_right_second) {
                    startActivity(new Intent(EsConditionalOrderActivity.this, EsTriggeredConditionalOrderActivity.class));
                }
            }
        });
    }

    @Override
    public void onScrollChange(int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
    }


    private void updateLists() {
        getOrderData();
        ((EsConditionalOrderAdapter) mAdapter).resetPopupWindow();
        mAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

//        ((EsConditionalOrderAdapter) mAdapter).reSetOpenedIndex();
        updateLists();
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage messageEvent) {
        int action = messageEvent.getAction();

        if (action == EsEventConstant.E_STAR_ACTION_NOTIFY_TRADE_LOGOUT) {
            EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
            if (account == null) {
                finish();
            } else {
                updateLists();
            }
        } else if (action == EsEventConstant.E_STAR_ACTION_STRATEGY_NUM) {
            getOrderData();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();

        if (action == EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER) {
            OrderData data = (OrderData)event.getData();
            if (data == null) {
                return;
            }

            char strategyType = data.getStrategyType();
            if (strategyType == EsDataConstant.S_ST_CONDITION
                    || strategyType == EsDataConstant.S_ST_CONDITION_PARENT
                    || strategyType == EsDataConstant.S_ST_BACKHAND
                    || strategyType == EsDataConstant.S_ST_AUTOORDER) {
                updateLists();
            }
        }
    }

    public static void finishActivity() {
        if (weakReference != null && weakReference.get() != null) {
            weakReference.get().finish();
        }
    }
}
