package com.esunny.ui.common.setting.quote.login;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alipay.sdk.app.H5PayCallback;
import com.alipay.sdk.app.PayTask;
import com.alipay.sdk.util.H5PayResultModel;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsWebApi;
import com.esunny.data.util.EsLog;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.dialog.EsCustomTipsDialog;

import butterknife.BindView;

@Route(path = RoutingTable.ES_STAR_STORE_ACTIVITY)
public class EsStarStoreActivity extends EsBaseActivity {
    private static final String TAG = "EsStarStoreActivity";

    @BindView(R2.id.es_activity_store_webview)
    WebView webView;
    @BindView(R2.id.es_store_activity_process)
    ProgressBar progressBar;
    String mUrl;
    @Override
    protected int getContentView() {
        return R.layout.es_activity_star_store;
    }

    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        webView.getSettings().setTextZoom(100);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setBackgroundColor(Color.TRANSPARENT);
//        webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);//测试阶段不适用缓存，方便调试
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.addJavascriptInterface(new EsWebAppApi(), "EstarWebApi");

        webView.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(final WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (!(url.startsWith("http") || url.startsWith("https"))) {
                    return true;
                }

                /*
                 * 推荐采用的新的二合一接口(payInterceptorWithUrl),只需调用一次
                 */
                final PayTask task = new PayTask(EsStarStoreActivity.this);
                boolean isIntercepted = task.payInterceptorWithUrl(url, true, new H5PayCallback() {
                    @Override
                    public void onPayResult(final H5PayResultModel result) {
                        // 支付结果返回
                        final String url = result.getReturnUrl();
                        if (!TextUtils.isEmpty(url)) {
                            EsStarStoreActivity.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    view.loadUrl(url);
                                }
                            });
                        }
                    }
                });

                /*
                 * 判断是否成功拦截
                 * 若成功拦截，则无需继续加载该URL；否则继续加载
                 */
                if (!isIntercepted) {
                    view.loadUrl(url);
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (progressBar != null) {
                    progressBar.setVisibility(View.VISIBLE);
                }
                super.onPageStarted(view, url, favicon);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                String js = "window.initUserInfo();";
                webView.evaluateJavascript(js, null);

                if (progressBar != null) {
                    progressBar.setVisibility(View.GONE);
                }
                super.onPageFinished(view, url);
            }
        });

        webView.loadUrl(EsWebApi.GET_MALL_URL);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadDataWithBaseURL(null, "", "text/html", "utf-8", null);
            webView.clearHistory();

            ((ViewGroup) webView.getParent()).removeView(webView);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private void showMsg(String content) {
        EsCustomTipsDialog dialog = EsCustomTipsDialog.create(this,
                getString(R.string.es_base_view_tips),
                content);
        dialog.setCancelListener(new EsCustomTipsDialog.EsCustomTipsDialogListener() {
            @Override
            public void onCancel() {
                finish();
            }
        });
        dialog.show();
    }

    class EsWebAppApi {
        final static int MSG_FINISH_ACTIVITY = -1;
        final static int MSG_DO_NOT_LOGIN = -2;

        @JavascriptInterface
        public void sendMsgToApp(int msg){
            switch (msg){
                case MSG_FINISH_ACTIVITY:
                    finish();
                    break;
                case MSG_DO_NOT_LOGIN:
                    showMsg(getString(R.string.es_store_activity_session_error));
                    break;
                default:
                    EsLog.d(TAG, "EsWebApi sendMsgToApp msg = " + msg);
                    break;
            }
        }
    }
}
