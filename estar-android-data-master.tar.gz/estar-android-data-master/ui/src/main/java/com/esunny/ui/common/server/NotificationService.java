package com.esunny.ui.common.server;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.IBinder;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.esunny.ui.R;
import com.esunny.ui.util.EsAppManager;

public class NotificationService extends Service {

    public static final String CHANNEL_ID_STRING = "com.esunny.ui.common.server.NotificationService";

    public NotificationService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();

        showNotification();
    }

    private void showNotification() {
        //创建通道
        NotificationChannel channel = null;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            channel = new NotificationChannel(CHANNEL_ID_STRING,"esunny", NotificationManager.IMPORTANCE_LOW);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Activity topActivity = EsAppManager.getAppManager().getTopActivity();
        Intent intent = new Intent(this, topActivity.getClass());
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi  = PendingIntent.getActivity(this,0,intent,0);
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID_STRING)
                .setContentTitle(getString(R.string.es_main_notice_title))
                .setContentText(getString(R.string.es_main_notice_content))
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.mipmap.ic_launcher)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher))
                .setContentIntent(pi)
                .build();
        startForeground(1,notification);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stopForeground(true);
    }
}
