package com.esunny.ui.common.setting.quote.kline;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.quote.EsKLineData;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.view.EsBaseToolBar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

public class EsIndexConfigActivity extends EsBaseActivity {

    @BindView(R2.id.activity_es_about_toolbar)
    EsBaseToolBar mToolbar;
    @BindView(R2.id.es_activity_chart_setting_rv_morphological_index)
    RecyclerView mRvMorphological;
    @BindView(R2.id.es_activity_chart_setting_rv_position_index)
    RecyclerView mRvPosition;
    @BindView(R2.id.es_activity_chart_setting_rv_swing_index)
    RecyclerView mRvSwing;

    EsIndexConfigAdapter mMorphologicalAdapter;
    EsIndexConfigAdapter mPositionAdapter;
    EsIndexConfigAdapter mSwingAdapter;

    List<String> mKLineParamsKeyList;

    List<String> mMorphologicalParamsKeyList = new ArrayList<>();
    List<String> mPositionParamsKeyList = new ArrayList<>();
    List<String> mSwingParamsKeyList = new ArrayList<>();

    JSONObject mJson = null;

    private final static String CJL = "CJL";

    @Override
    protected int getContentView() {
        return R.layout.es_activity_index_config;
    }

    @Override
    protected void initData() {
        // 先更新数据源，因为数据源可能被污染
        EsKLineData.getInstance().init(getApplicationContext());

        mKLineParamsKeyList = EsKLineData.getInstance().getAllParamsKey();
        int CJDIndex = mKLineParamsKeyList.indexOf(CJL);
        // 形态指标
        mMorphologicalParamsKeyList.addAll(mKLineParamsKeyList.subList(0, CJDIndex - 1));
        // 量仓指标
        mPositionParamsKeyList.add(mKLineParamsKeyList.get(CJDIndex));
        // 摆动指标
        mSwingParamsKeyList.addAll(mKLineParamsKeyList.subList(CJDIndex + 1, mKLineParamsKeyList.size()));
        formatList(mMorphologicalParamsKeyList);
        formatList(mPositionParamsKeyList);
        formatList(mSwingParamsKeyList);


        String dataStr = EsSPHelper.getIndexConfig(this);

        if (dataStr == null || dataStr.isEmpty()) {
            mJson = new JSONObject();
        }else {
            try {
                mJson = new JSONObject(dataStr);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        mMorphologicalAdapter = new EsIndexConfigAdapter(this, mMorphologicalParamsKeyList);
        mMorphologicalAdapter.setJsonData(mJson);
        mPositionAdapter = new EsIndexConfigAdapter(this, mPositionParamsKeyList);
        mPositionAdapter.setJsonData(mJson);
        mSwingAdapter = new EsIndexConfigAdapter(this, mSwingParamsKeyList);
        mSwingAdapter.setJsonData(mJson);
    }

    @Override
    protected void initWidget() {
        mToolbar.setSimpleBack(getString(R.string.es_activity_chart_setting_parameter_configure));
        GridLayoutManager layoutManager_parameter = new GridLayoutManager(this, 3);
        mRvMorphological.setLayoutManager(layoutManager_parameter);
        mRvMorphological.setAdapter(mMorphologicalAdapter);

        GridLayoutManager layoutManager_position = new GridLayoutManager(this, 3);
        mRvPosition.setLayoutManager(layoutManager_position);
        mRvPosition.setAdapter(mPositionAdapter);

        GridLayoutManager layoutManager_swing = new GridLayoutManager(this, 3);
        mRvSwing.setLayoutManager(layoutManager_swing);
        mRvSwing.setAdapter(mSwingAdapter);
    }

    private void formatList(List<String> list) {
        if (list.size() % 3 == 0) {
            return;
        }

        int size = list.size();

        for (int i =0; i < 3 - (size % 3); i ++) {
            list.add("");
        }
    }

    @Override
    protected void onDestroy() {
        EsSPHelper.setIndexConfig(this, mJson.toString());
        super.onDestroy();
    }
}
