package com.esunny.ui.common.setting.quote.login;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Handler;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.QuoteEvent;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.api.EsDataTrackApi;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.dialog.EsCustomTipsDialog;
import com.esunny.ui.login.EsLoginActivity;
import com.esunny.ui.util.AESCrypt;
import com.esunny.ui.util.EsDoubleClickExitHelper;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsCustomRelativeLayout;
import com.esunny.ui.view.EsCustomerToast;
import com.esunny.ui.view.EsIconTextView;
import com.esunny.ui.view.EsSafeKeyboardDialog;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.ref.WeakReference;

import butterknife.BindView;
import butterknife.OnClick;


@Route(path = RoutingTable.ES_STAR_LOGIN_ACTIVITY)
public class EstarLoginActivity extends EsBaseActivity {

    private static final String TAG = "EstarLoginActivity";
    private static final int DELAYTIMER = 10 * 1000;

    @BindView(R2.id.activity_estar_login_toolbar)
    EsBaseToolBar mToolBar;
    @BindView(R2.id.es_login_activity_login_crl_company)
    EsCustomRelativeLayout mCrlCompany;
    @BindView(R2.id.view_margin_top)
    View mViewMarginTop;
    @BindView(R2.id.et_login_userno)
    EditText mEtUserNo;
    @BindView(R2.id.ed_login_activity_rl_clear_input_login_userno)
    RelativeLayout mRlClearInputAccount;
    @BindView(R2.id.es_login_activity_login_rl_switch_account)
    RelativeLayout mRLSwitchAccount;
    @BindView(R2.id.es_login_activity_login_crl_user)
    EsCustomRelativeLayout mCrlUser;
    @BindView(R2.id.et_login_pwd)
    EditText mEtPwd;
    @BindView(R2.id.ed_login_activity_rl_clear_input_login_password)
    RelativeLayout mRlClearPsd;
    @BindView(R2.id.es_login_activity_login_crl_password)
    EsCustomRelativeLayout mCrlPsd;
    @BindView(R2.id.es_login_activity_login_itv_save_account)
    EsIconTextView mITVSaveAccount;
    @BindView(R2.id.es_login_activity_login_tv_save_account)
    TextView mTvAccount;
    @BindView(R2.id.es_login_activity_login_etv_save_pwd)
    EsIconTextView mITVSavePassword;
    @BindView(R2.id.es_login_activity_login_tv_save_pwd)
    TextView mTVPassword;
    @BindView(R2.id.tv_login_submit)
    TextView mTvLogin;
    @BindView(R2.id.activity_estar_login_tv_forget_password)
    TextView mTvForgetPsd;
    @BindView(R2.id.activity_estar_login_tv_register)
    TextView mTvRegister;

    private EsCustomerToast mCustomerToast;
    private Handler mTimerHandler;
    private Runnable mTimerRunnable;

    String mUserNo, mPassword;

    boolean mIsJumpFromInit;

    private EsDoubleClickExitHelper mEsDoubleClickExitHelper;//双击后退键，退出程序

    @Override
    protected void initData() {
        super.initData();

        int source = getIntent().getIntExtra("Source", 0);
        mIsJumpFromInit = source == EsUIConstant.S_STATE_QUOTE_LOGIN_CODE;
        if (mIsJumpFromInit) {
            mEsDoubleClickExitHelper = new EsDoubleClickExitHelper(this);
            mEsDoubleClickExitHelper.setBackListener(new EsDoubleClickExitHelper.onKeyDown() {
                @Override
                public void back() {
                    setResult(EsUIConstant.S_STATE_QUOTE_LOGIN_APP_EXIT_CODE);
                    finish();
                }
            });
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindViewValue();
        bindViewVisible();
        bindOnFocus();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void bindOnFocus() {
        mEtUserNo.setOnFocusChangeListener(mCrlUser);
        mEtPwd.setOnFocusChangeListener(mCrlPsd);

//        mEtPwd.setInputType(InputType.TYPE_NULL);
//        mEtPwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
        mEtPwd.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.hideSoftInputFromWindow(mEtUserNo.getWindowToken(),0);
                }
                if ((event.getAction() & MotionEvent.ACTION_MASK) == MotionEvent.ACTION_DOWN) {
                    EsSafeKeyboardDialog dialog = new EsSafeKeyboardDialog(EstarLoginActivity.this, mEtPwd);
                    dialog.showAtLocation(mEtPwd, Gravity.BOTTOM, 0, 0);
                }
                return false;
            }
        });
    }


    private void bindViewVisible() {
        mCrlCompany.setVisibility(View.GONE);
        mRLSwitchAccount.setVisibility(View.INVISIBLE);
        mViewMarginTop.setVisibility(View.VISIBLE);
    }

    private void bindViewValue() {
        mToolBar.setTitle(getString(R.string.es_activity_estar_login_title));
        mToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
        mToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if(id == R.id.toolbar_left_first){
//                    if (isLoginQuoteAccount()) {
                        finish();
//                    } else {
//                        EsCustomDialog.create(EstarLoginActivity.this)
//                                .setTitle(getString(R.string.es_activity_system_setting_notice))
//                                .setCancelable(false)
//                                .setContent(getString(R.string.es_activity_estar_login_app_exit))
//                                .setClickListener(new EsCustomDialog.EsDialogClickListener() {
//                                    @Override
//                                    public void onConfirm() {
//                                        setResult(EsUIConstant.S_STATE_QUOTE_LOGIN_APP_EXIT_CODE);
//                                        finish();
//                                    }
//                                    @Override
//                                    public void onCancel() {}
//                                }).show();
//                    }
                }
            }
        });

        mCrlUser.setTitle(getString(R.string.es_login_activity_quote_account));
        mTvAccount.setText(getString(R.string.es_activity_login_save_pasword));
        mTVPassword.setText(getString(R.string.es_activity_login_auto_login));

        try {
            initAccountPsdUIValue();
        } catch (Exception e) {
            e.printStackTrace();
        }

        mCustomerToast = EsCustomerToast.create(this)
                .setStyle(EsCustomerToast.Style.TOAST_LOADING)
                .setAutoDismiss(false).setClickDismiss(false)
                .setClickBackKeyDismiss(false)
                .setTip(this.getString(R.string.es_login_start_loading_qbegin));

        mTimerHandler = new Handler();
        mTimerRunnable = new Runnable() {
            @Override
            public void run() {
                if(mCustomerToast.isShowing()){
                    mCustomerToast.cancel();
                    ToastHelper.show(EstarLoginActivity.this, R.string.es_activity_login_timeout);
                }
            }
        };
    }

    private boolean isLoginQuoteAccount(){
        QuoteLoginInfo loginInfo = EsDataApi.quoteLoginInfo();
        if (loginInfo.getErrorCode() == 0 && !loginInfo.getLoginNo().isEmpty()) {
            return true;
        }else {
            return false;
        }
    }

    private void initAccountPsdUIValue() throws Exception {
        SharedPreferences sp = EsSPHelper.getSP(this);

        QuoteLoginInfo loginInfo = EsDataApi.quoteLoginInfo();
        if (loginInfo == null) {
            return;
        }
        String account = loginInfo.getLoginNo();
        String password = loginInfo.getPassWord();
        AESCrypt aesCrypt = new AESCrypt(this);
        if (loginInfo.getErrorCode() == 0) {
            if (account.isEmpty()) {
                account = sp.getString(EsUIConstant.ESTAR_LOGIN_ACCOUNT_NEW, "");
                if (TextUtils.isEmpty(account)) {
                    account = sp.getString(EsUIConstant.ESTAR_LOGIN_ACCOUNT, "");
                } else {
                    account = aesCrypt.decrypt(account);
                }

                password = sp.getString(EsUIConstant.ESTAR_LOGIN_PASSWORD_NEW, "");
                if (TextUtils.isEmpty(password)) {
                    password = sp.getString(EsUIConstant.ESTAR_LOGIN_PASSWORD, "");
                } else {
                    password = aesCrypt.decrypt(password);
                }

                mTvLogin.setText(getString(R.string.es_activity_login_btn_login));
            } else {
                mTvLogin.setText(getString(R.string.es_login_item_list_account_choose_logout));
            }
        } else {
            mTvLogin.setText(getString(R.string.es_activity_login_btn_login));
        }


        if (sp.getBoolean(EsUIConstant.ESTAR_LOGIN_KEEP_PASSWORD, true)) {
            mITVSaveAccount.setText(getString(R.string.es_icon_keyboard_check));
        } else {
            mITVSaveAccount.setText(getString(R.string.es_icon_keyboard_uncheck));
        }

        if (sp.getBoolean(EsUIConstant.ESTAR_LOGIN_AUTO_LOGIN, true)) {
            mITVSavePassword.setText(getString(R.string.es_icon_keyboard_check));
        } else {
            mITVSavePassword.setText(getString(R.string.es_icon_keyboard_uncheck));
        }

        mEtUserNo.setText(account);
        mEtPwd.setText(password);
        if (mTvLogin.getText().equals(getString(R.string.es_activity_login_btn_login))) {
            enableEdit(true);
        } else {
            enableEdit(false);
        }
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_estar_login;
    }

//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
////        if (keyCode == KeyEvent.KEYCODE_BACK) {
////            if (mIsJumpFromInit && mEsDoubleClickExitHelper != null) {
////                return mEsDoubleClickExitHelper.onKeyDown(keyCode, event);
////            }
////        }
////        return super.onKeyDown(keyCode, event);
//        if (isLoginQuoteAccount()){
//            return super.onKeyDown(keyCode, event);
//        } else {
//            return true;
//        }
//    }

    @OnClick(R2.id.tv_login_submit)
    public void submitLoginRequest() {
        if (getString(R.string.es_activity_login_btn_login).equals(mTvLogin.getText().toString())) {
            login();
        } else {
            logout();
        }
    }

    @OnClick(R2.id.ed_login_activity_rl_clear_input_login_userno)
    public void cleanAccount() {
        mEtUserNo.setText(null);
        mEtPwd.setText(null);
    }

    @OnClick(R2.id.ed_login_activity_rl_clear_input_login_password)
    public void cleanPassword() {
        mEtPwd.setText(null);
    }

    @OnClick(R2.id.es_login_activity_login_itv_save_account)
    public void clickRemberAccount() {
        if (mITVSaveAccount.getText().toString().equals(this.getString(R.string.es_icon_keyboard_uncheck))) {
            mITVSaveAccount.setText(getString(R.string.es_icon_keyboard_check));
        } else {
            mITVSaveAccount.setText(getString(R.string.es_icon_keyboard_uncheck));
            mITVSavePassword.setText(getString(R.string.es_icon_keyboard_uncheck));
        }
    }

    @OnClick(R2.id.es_login_activity_login_etv_save_pwd)
    public void clickRemberPassword() {
        if (mITVSavePassword.getText().toString().equals(this.getString(R.string.es_icon_keyboard_uncheck))) {
            mITVSavePassword.setText(getString(R.string.es_icon_keyboard_check));
            mITVSaveAccount.setText(getString(R.string.es_icon_keyboard_check));
        } else {
            mITVSavePassword.setText(getString(R.string.es_icon_keyboard_uncheck));
        }
        //实时生效写文件
        saveAutoLogin();
    }

    @OnClick(R2.id.activity_estar_login_tv_register)
    public void registerActivity(){
        Intent intent = new Intent(this, EsForgetPasswordActivity.class);
        intent.putExtra(EsForgetPasswordActivity.ACTIVITY_TYPE_KEY, EsForgetPasswordActivity.ACTIVITY_TYPE_VALUE_REGISTER);
        startActivity(intent);
    }

    @OnClick(R2.id.activity_estar_login_tv_forget_password)
    public void forgetPassword() {
        Intent intent = new Intent(this, EsForgetPasswordActivity.class);
        intent.putExtra(EsForgetPasswordActivity.ACTIVITY_TYPE_KEY, EsForgetPasswordActivity.ACTIVITY_TYPE_VALUE_FORGETPASSWORD);
        startActivity(intent);
    }


    private void logout() {
        int ret = EsDataApi.quoteLogout();
        if (ret == 0) {
            mUserNo = "";
            mPassword = "";
            mCustomerToast.cancel();
            mTimerHandler.removeCallbacks(mTimerRunnable);
            ToastHelper.show(this, R.string.es_activity_estar_login_logout_success);
            enableEdit(true);
            mTvLogin.setText(getString(R.string.es_activity_login_btn_login));
        }
    }

    private void login() {
        if (loginInfoCheck()) {
            mUserNo = mEtUserNo.getText().toString();
            mPassword = mEtPwd.getText().toString();
            //后台进行登录函数
            new LoginTask(this).execute();
            progressUpdate(EstarLoginActivity.this.getString(R.string.es_login_start_loading_qbegin));
            mTimerHandler.postDelayed(mTimerRunnable, DELAYTIMER);
        }
    }

    private void keepLoginInfo(String userNo, String password) {
        saveAutoLogin();

        savePassword(userNo, password);
    }

    private void saveAutoLogin() {
        boolean isAutoLogin = (getString(R.string.es_icon_keyboard_check).equals(mITVSavePassword.getText().toString()));
        SharedPreferences sp = EsSPHelper.getSP(this);
        SharedPreferences.Editor editor = sp.edit();

        if (isAutoLogin) {
            editor.putBoolean(EsUIConstant.ESTAR_LOGIN_AUTO_LOGIN, true);
        } else {
            editor.putBoolean(EsUIConstant.ESTAR_LOGIN_AUTO_LOGIN, false);
        }
        editor.apply();
    }

    private void savePassword(String userNo, String password) {
        String encryptUserNo = "", encryptPassword = "";
        try {
            AESCrypt aesCrypt = new AESCrypt(this);
            encryptUserNo = aesCrypt.encrypt(userNo);
            encryptPassword = aesCrypt.encrypt(password);
        } catch (Exception e) {
            e.printStackTrace();
        }

        boolean isKeepPassword = (getString(R.string.es_icon_keyboard_check).equals(mITVSaveAccount.getText().toString()));
        SharedPreferences sp = EsSPHelper.getSP(this);
        SharedPreferences.Editor editor = sp.edit();

        if (isKeepPassword) {
            editor.putBoolean(EsUIConstant.ESTAR_LOGIN_KEEP_PASSWORD, true);
            editor.putString(EsUIConstant.ESTAR_LOGIN_ACCOUNT_NEW, encryptUserNo);
            editor.putString(EsUIConstant.ESTAR_LOGIN_PASSWORD_NEW, encryptPassword);
        } else {
            editor.putBoolean(EsUIConstant.ESTAR_LOGIN_KEEP_PASSWORD, false);
            editor.putString(EsUIConstant.ESTAR_LOGIN_ACCOUNT_NEW, encryptUserNo);
            editor.putString(EsUIConstant.ESTAR_LOGIN_PASSWORD_NEW, "");
        }
        editor.apply();
    }

    private boolean loginInfoCheck() {
        if (mEtUserNo.getText().toString().trim().isEmpty()) {
            ToastHelper.show(this, R.string.es_activity_login_please_enter_account);
            return false;
        } else if (mEtPwd.getText().toString().trim().isEmpty()) {
            ToastHelper.show(this, R.string.es_activity_login_please_enter_password);
            return false;
        }
        return true;
    }

    private void progressUpdate(String label) {
        mCustomerToast.setTip(label);
        mCustomerToast.show();
        if (label.equals(getString(R.string.es_login_start_loading_qsuccess))) {
            mCustomerToast.cancel();
            mTimerHandler.removeCallbacks(mTimerRunnable);
        } else if (label.equals(getString(R.string.es_activity_es_registter_logout_successful))) {
            mCustomerToast.cancel();
            mTimerHandler.removeCallbacks(mTimerRunnable);
        }
    }

    private void showErrorText(String errorText) {
        EsCustomTipsDialog dialog = EsCustomTipsDialog.create(this, getString(R.string.es_login_callabck_info), errorText);
        dialog.show();
        mTimerHandler.removeCallbacks(mTimerRunnable);
    }

    private void enableEdit(boolean enable) {
        mEtUserNo.setEnabled(enable);
        mEtPwd.setEnabled(enable);
        if (enable) {
            mRlClearInputAccount.setVisibility(View.VISIBLE);
            mRlClearPsd.setVisibility(View.VISIBLE);
        } else {
            mRlClearInputAccount.setVisibility(View.GONE);
            mRlClearPsd.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        EventBus.getDefault().unregister(this);
    }

    private static class LoginTask extends AsyncTask<String, Void, Integer> {

        private WeakReference<EstarLoginActivity> weakReference;

        LoginTask(EstarLoginActivity activity) {
            weakReference = new WeakReference<>(activity);
        }

        @Override
        protected Integer doInBackground(String... params) {

            EstarLoginActivity activity = weakReference.get();

            if (activity == null) {
                return -5;
            }

            return EsDataApi.quoteLogin(activity.mUserNo, activity.mPassword);
        }

        @Override
        protected void onPostExecute(Integer result) {
            super.onPostExecute(result);

            EstarLoginActivity activity = weakReference.get();

            if (activity == null) {
                return;
            }
            EsDataTrackApi.addPolestarLogin(false);

            if (result == -1) {
                ToastHelper.show(activity, R.string.es_activity_estar_login_account_loged);
                activity.mCustomerToast.cancel();
                activity.mTimerHandler.removeCallbacks(activity.mTimerRunnable);
            } else if (result == -2 || result == -3) {
                ToastHelper.show(activity, R.string.es_activity_login_error);
                activity.mCustomerToast.cancel();
                activity.mTimerHandler.removeCallbacks(activity.mTimerRunnable);
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void quoteEvent(QuoteEvent event) {
        int action = event.getAction();

        if (action == EsDataConstant.S_SRVEVENT_REGLOGIN) {
            String userNo = event.getUserNo();

            int errorCode = event.getSrvErrorCode();
            if (errorCode != 0) {
                mCustomerToast.cancel();
                showErrorText(getString(R.string.es_activity_es_registter_login_error,
                        String.valueOf(errorCode), event.getSrvErrorText()));
            } else if (!TextUtils.isEmpty(userNo)) {
                //认证成功
                keepLoginInfo(mUserNo, mPassword);
                progressUpdate(getString(R.string.es_login_start_loading_qsuccess));
                finish();
            }
        }
    }
}
