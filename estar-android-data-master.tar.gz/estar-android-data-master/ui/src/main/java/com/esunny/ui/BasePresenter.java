package com.esunny.ui;

import androidx.annotation.NonNull;

import org.greenrobot.eventbus.EventBus;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

public abstract class BasePresenter<T> {
    protected Reference<T> mViewRef;

    @NonNull
    protected T mView;

    public void attactView(@NonNull T view){
        this.mViewRef = new WeakReference<T>(view);
        mView = mViewRef.get();
    }

    public void detachView(){
        if (mViewRef != null){
            mViewRef.clear();
            this.mViewRef = null;
        }
    }

    protected void register(){};
    protected void unRegister(){};
//    void register();
//    void unRegister();
}
