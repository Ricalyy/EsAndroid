package com.esunny.ui.common.setting.trade;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.BillData;
import com.esunny.data.bean.BillDetail;
import com.esunny.ui.BasePresenter;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.chartview.BarChartData;
import com.esunny.ui.view.chartview.DataEntry;
import com.esunny.ui.view.chartview.LineChartData;
import com.esunny.ui.view.chartview.LineDataSet;
import com.esunny.ui.view.chartview.PieEntry;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class EsBenefitPresenter extends BasePresenter<EsBenefitCombination.View> implements EsBenefitCombination.Presenter{

    private Context mContext;

    private EsBenefitCombination.Mode mModel;

    private int mPastBillDate = 1;
    private int mAllDays = 1;

    public EsBenefitPresenter(Context context) {
        this.mContext = context;
        mModel = new BenefitModelImpl();
    }

    @Override
    public LineChartData getLineChartData() {
        List<DataEntry> entries = mModel.getLineChartData();

        LineDataSet lineDataSet = new LineDataSet(entries);
        return new LineChartData(lineDataSet);
    }

    @Override
    public LineChartData gerResetChartData() {
        List<DataEntry> entries = new ArrayList<>();

        LineDataSet lineDataSet = new LineDataSet(entries);
        return new LineChartData(lineDataSet);
    }

    @Override
    public BarChartData getBarChartData() {
        List<DataEntry> entries = mModel.getBarChartData();

        LineDataSet lineDataSet = new LineDataSet(entries);
        BarChartData barChartData = new BarChartData(lineDataSet);
        barChartData.calcBarAbsMinMax();
        return barChartData;
    }

    @Override
    public BarChartData gerResetBarChartData() {
        List<DataEntry> entries = new ArrayList<>();

        LineDataSet lineDataSet = new LineDataSet(entries);
        return new BarChartData(lineDataSet);
    }

    @Override
    public List<PieEntry> getPieChartData() {
        return mModel.getPieChartData();
    }

    @Override
    public void startQueryBillData(int days) {
        mPastBillDate = days;
        mAllDays = days;
        lastDate = new Date();

        mModel.clearAllBillData();
        mModel.clearAllBillCommodityData();
        queryBillDataForDay(mPastBillDate);
    }

    Date lastDate;
    @Override
    public void startCusQueryBillData(int days, String endDateStr) {
        mPastBillDate = days + 1;
        mAllDays = days + 1;

        EsLoginAccountData.LoginAccount account = mModel.getCurrentAccount();
        if (account == null){
            return;
        }

        // 因为当天也是要查询的 所以需要输入后一天
        try {
            lastDate = new SimpleDateFormat("yyyy-MM-dd").parse(getTomorrow(endDateStr));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String pastDay = getPastData(mPastBillDate);

        mModel.clearAllBillData();
        mModel.clearAllBillCommodityData();

        EsDataApi.queryBill(account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo(), pastDay);
    }

    private void endQueryBillData() {
        // 查询结束，计算账单数据
        mModel.calBillValue();

        mView.updateBenefitDataStatisticUI(String.valueOf(mModel.getBfBanlance()), String.valueOf(mModel.getCfBanlance()), String.valueOf(mModel.getRealizedPL()),
                String.valueOf(mModel.getMTMPL()), String.valueOf(mModel.getCommission()), String.valueOf(mModel.getInitialMargin())
                 , String.valueOf(mModel.getDepositWithdrawal()));
        mView.updateChart();
        if (! mModel.isEnoughValidData()){
            mView.noEnoughBillData();
        }
    }

    private String getTomorrow(String dateStr){
        Calendar c = Calendar.getInstance();
        Date date = null;
        try {
            date = new SimpleDateFormat("yy-MM-dd").parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        c.setTime(date);
        int day1 = c.get(Calendar.DATE);
        c.set(Calendar.DATE, day1 + 1);

        return new SimpleDateFormat("yyyy-MM-dd").format(c.getTime());
    }

    @Override
    public void registerBillCallback() {
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    public void unRegisterBillCallback() {
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    private String getPastData(int past){
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(lastDate);
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - past);
        return new SimpleDateFormat("yyyy-MM-dd").format(calendar.getTime());
    }

    private void queryBillDataForDay(int day){
        EsLoginAccountData.LoginAccount account = mModel.getCurrentAccount();
        if (account == null){
            return;
        }
        // 賬單查詢需分開，無法一次性查詢。
        String pastDay = getPastData(day);
        EsDataApi.queryBill(account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo(), pastDay);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event){
        int action = event.getAction();
        Object data = event.getData();

        switch (action){
            case  EsDataConstant.S_SRVEVENT_QRY_BILL:
                if (data instanceof BillData) {
                    getBill((BillData) data);
                }
                break;
            default:
                break;
        }
    }

    private void getBill(BillData srvData) {
        String billContent = srvData.getContent();
        // decoide the bill data.
        mModel.addBillData(getPastData(mPastBillDate), billContent);

        mPastBillDate--;
        if (mPastBillDate > 0) {
            queryBillDataForDay(mPastBillDate);
        }else {
            // 账单查询结束,
            endQueryBillData();
        }

        mView.simulateProgressBar(100 * (mAllDays - mPastBillDate) / mAllDays );
    }
}
