package com.esunny.ui.common.news;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.esunny.ui.R;

public class EsNewsWrapperAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private RecyclerView.Adapter mAdapter;

    private final int TYPE_ITEM = 1;
    private final int TYPE_FOOT = 2;

    public final int LOADING = 1;
    // 加载完成
    public final int LOAD_COMPLETED = 2;
    //加载到底
    public final int LOAD_END = 3;

    private int mLoadState = LOAD_COMPLETED;

    public EsNewsWrapperAdapter(RecyclerView.Adapter mAdapter) {
        this.mAdapter = mAdapter;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == getItemCount() - 1) {
            return TYPE_FOOT;
        } else {
            return TYPE_ITEM;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_FOOT) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_news_item_foot, parent, false);
            return new FootViewHolder(view);
        } else {
            return mAdapter.onCreateViewHolder(parent, viewType);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof FootViewHolder) {
            FootViewHolder footViewHolder = (FootViewHolder) holder;
            switch (mLoadState) {
                case LOADING:
                    footViewHolder.tvLoading.setVisibility(View.VISIBLE);
                    break;
                case LOAD_COMPLETED:
                    footViewHolder.tvLoading.setVisibility(View.INVISIBLE);
                    break;
                case LOAD_END:
                    footViewHolder.tvLoading.setVisibility(View.GONE);
                    break;
                default:
                    break;
            }
        } else {
            mAdapter.onBindViewHolder(holder, position);
        }
    }

    @Override
    public int getItemCount() {
        return mAdapter.getItemCount() + 1;
    }

    public void setLoadState(int loadState) {
        this.mLoadState = loadState;
        notifyDataSetChanged();
    }

    private class FootViewHolder extends RecyclerView.ViewHolder {

        TextView tvLoading;

        FootViewHolder(View itemView) {
            super(itemView);
            tvLoading = itemView.findViewById(R.id.es_news_item_foot_tv_loading);
        }
    }
}
