package com.esunny.ui.common.bean;

public class EsOpConOperate {

    private int      mTacticOperate;     //操作类型
    private double   mStrikePrice;       //执行价
    private double   mMoney;             //权利金
    private String   mContractNo;        //合约号
    private String   mErrorText;         //错误信息，用于界面绘制

    public int getTacticOperate() {
        return mTacticOperate;
    }

    public void setTacticOperate(int tacticOperate) {
        mTacticOperate = tacticOperate;
    }

    public double getStrikePrice() {
        return mStrikePrice;
    }

    public void setStrikePrice(double strikePrice) {
        mStrikePrice = strikePrice;
    }

    public double getMoney() {
        return mMoney;
    }

    public void setMoney(double money) {
        mMoney = money;
    }

    public String getContractNo() {
        return mContractNo;
    }

    public void setContractNo(String contractNo) {
        mContractNo = contractNo;
    }

    public String getErrorText() {
        return mErrorText;
    }

    public void setErrorText(String errorText) {
        mErrorText = errorText;
    }
}

