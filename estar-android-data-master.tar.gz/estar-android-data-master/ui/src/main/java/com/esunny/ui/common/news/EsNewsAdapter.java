package com.esunny.ui.common.news;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.esunny.data.bean.EsNewsData;
import com.esunny.ui.R;
import com.esunny.ui.util.imageuitl.ImageLoader;
import com.esunny.ui.util.imageuitl.ProgressLoadListener;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;

import skin.support.content.res.SkinCompatResources;

public class EsNewsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final String TAG = getClass().getSimpleName();

    private Context mContext;
    private List<EsNewsData> mDatas = new ArrayList<>();
    private ItemClickListener mListener;

    interface ItemClickListener {
        void onItemClick(int positon);

        void onPicClick(String imgUrl);

        void onTagClick(String tagName);
    }

    public EsNewsAdapter(Context context) {
        this.mContext = context;
    }

    public void setListData(List<EsNewsData> mDatas) {
        this.mDatas = mDatas;
    }

    public void setOnItemClickListener(ItemClickListener listener) {
        this.mListener = listener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_news_item, parent, false);
        return new NewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (position < 0 || position >= mDatas.size()) {
            return;
        }
        EsNewsAdapter.NewsViewHolder newsViewHolder = (EsNewsAdapter.NewsViewHolder) holder;

        EsNewsData newsData = mDatas.get(position);
        // 设置文本内容
        setTextContent(newsData.getNewsTitle(), newsData.getNewsSummary().trim(), newsData.getNewsPublishTime(), newsViewHolder);
        // 设置字体颜色
        setTextColor(newsData.getNewsColor(), newsViewHolder);
        // 加载图片
        loadPicture(newsData.getNewsPic(), newsViewHolder);
        // 设置新闻Tag
        addNewsTag(newsData.getNewsTag(), newsViewHolder);
    }

    private void addNewsTag(String newsTag, NewsViewHolder newsViewHolder) {
        String[] tagArray = newsTag.split("\\|");
        newsViewHolder.mLlTagContainer.removeAllViews();
        for (int index = 0; index < tagArray.length; index++) {
            final String tag = tagArray[index];
            if (tag != null && !tag.isEmpty()) {
                TextView tvTag = new TextView(mContext);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                layoutParams.rightMargin = mContext.getResources().getDimensionPixelSize(R.dimen.x22);
                tvTag.setLayoutParams(layoutParams);
                tvTag.setText(tag);
                tvTag.setTextSize(TypedValue.COMPLEX_UNIT_PX, mContext.getResources().getDimension(R.dimen.x20));
                tvTag.setTextColor(getTagColor(index));
                tvTag.setPadding(mContext.getResources().getDimensionPixelSize(R.dimen.x10), mContext.getResources().getDimensionPixelSize(R.dimen.x3), mContext.getResources().getDimensionPixelSize(R.dimen.x10), mContext.getResources().getDimensionPixelSize(R.dimen.x3));
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setShape(GradientDrawable.RECTANGLE);
                gradientDrawable.setStroke(mContext.getResources().getDimensionPixelSize(R.dimen.x2), getTagColor(index));
                gradientDrawable.setCornerRadius(mContext.getResources().getDimensionPixelSize(R.dimen.x50));
                tvTag.setBackground(gradientDrawable);
                newsViewHolder.mLlTagContainer.addView(tvTag);
                tvTag.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mListener.onTagClick(tag);
                    }
                });
            }
        }
    }

    private void setTextColor(String newsColor, NewsViewHolder newsViewHolder) {
        if ("red".equals(newsColor)) {
            newsViewHolder.mTvTitle.setTextColor(mContext.getResources().getColor(R.color.es_imageErrorNotificationTextColor));
            newsViewHolder.mTvContent.setTextColor(mContext.getResources().getColor(R.color.es_bg_position_stop_loss_button_pressed));
        } else {
            newsViewHolder.mTvTitle.setTextColor(SkinCompatResources.getColor(mContext, R.color.es_mainTextColor));
            newsViewHolder.mTvContent.setTextColor(mContext.getResources().getColor(R.color.es_text_color_position_stop_loss_title));
        }
    }

    private void setTextContent(String newsTitle, String newsSummary, String newsPublishTime, NewsViewHolder newsViewHolder) {
        newsViewHolder.mTvTitle.setText(newsTitle);
        newsViewHolder.mTvContent.setText(newsSummary);
        newsViewHolder.mTvDate.setText(newsPublishTime);
    }

    private void loadPicture(String pirUrl, final NewsViewHolder newsViewHolder) {
        // 加载图片
        if (pirUrl != null && !pirUrl.isEmpty()) {
            newsViewHolder.mLlPicContainer.removeAllViews();

            Matcher matcher = Patterns.WEB_URL.matcher(pirUrl);
            while (matcher.find()){
                final String realUrl = matcher.group();

                final ImageView ivPic = new ImageView(mContext);
                ivPic.setScaleType(ImageView.ScaleType.FIT_XY);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(mContext.getResources().getDimensionPixelSize(R.dimen.x250),
                        mContext.getResources().getDimensionPixelSize(R.dimen.y100));
                layoutParams.rightMargin = mContext.getResources().getDimensionPixelSize(R.dimen.x22);
                ivPic.setLayoutParams(layoutParams);

                ImageLoader.getInstance().loadImage(realUrl, ivPic, new ProgressLoadListener() {
                    @Override
                    public void update(Bitmap bitmap) {
                        ivPic.setImageBitmap(bitmap);
                        newsViewHolder.mLlPicContainer.addView(ivPic);
                    }
                });

                ivPic.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mListener.onPicClick(realUrl);
                    }
                });
            }

            newsViewHolder.mLlPicContainer.setVisibility(View.VISIBLE);
        } else {
            newsViewHolder.mLlPicContainer.setVisibility(View.GONE);
        }
    }

    /**
     * @param index tag在列表中位置
     * @return 标签颜色，按蓝绿橙循环。
     */
    public int getTagColor(int index) {
        int color = mContext.getResources().getColor(R.color.es_activity_tactic_sell_strike_price_text_color);
        if (index % 3 == 1) {
            color = mContext.getResources().getColor(R.color.es_activity_tactic_buy_strike_price_text_color);
        } else if (index % 3 == 2) {
            color = mContext.getResources().getColor(R.color.es_activity_tactic_sell_strike_price_text_color);
        } else if (index % 3 == 0) {
            color = mContext.getResources().getColor(R.color.es_activity_tatic_order_strategy_profit_way_value_green);
        }
        return color;
    }

    @Override
    public int getItemCount() {
        return mDatas.size();
    }

    class NewsViewHolder extends RecyclerView.ViewHolder {
        TextView mTvTitle;
        TextView mTvContent;
        TextView mTvDate;
        //        ImageView mPvPic;
        LinearLayout mLlMain;
        LinearLayout mLlTagContainer;
        LinearLayout mLlPicContainer;

        NewsViewHolder(View itemView) {
            super(itemView);
            mTvTitle = itemView.findViewById(R.id.es_news_item_tv_title);
            mTvContent = itemView.findViewById(R.id.es_news_item_tv_content);
            mTvDate = itemView.findViewById(R.id.es_news_item_tv_date);
//            mPvPic = itemView.findViewById(R.id.es_news_item_iv_pic);
            mLlMain = itemView.findViewById(R.id.es_news_item_ll_main);
            mLlTagContainer = itemView.findViewById(R.id.es_news_item_ll_tagcontainer);
            mLlPicContainer = itemView.findViewById(R.id.es_news_item_ll_pic_container);

            mLlMain.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.onItemClick(getAdapterPosition());
                }
            });
        }
    }
}
