package com.esunny.ui.common.setting.trade;

import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;

import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.setting.trade.adapter.EsSigningBankAdapter;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.EsIconTextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;

public class EsBankChoosingActivity extends EsBaseActivity implements View.OnClickListener{

    @BindView(R2.id.es_activity_bank_choose_itv_back)
    EsIconTextView itv_back;
    @BindView(R2.id.es_activity_bank_choose_rv_bank_list)
    RecyclerView rv_bank_list;

    private String mCompanyNo, mUserNo;

    private EsSigningBankAdapter mAdapter;
    private List<String> mSigningBankNameList = new ArrayList<>();
    private List<String> mSigningBankCurrencyList = new ArrayList<>();
    private int mChooseIndex = 0;

    @Override
    protected void initData() {
        super.initData();
        if (EsLoginAccountData.getInstance().getCurrentAccount() != null) {
            mCompanyNo = EsLoginAccountData.getInstance().getCurrentAccount().getCompanyNo();
            mUserNo = EsLoginAccountData.getInstance().getCurrentAccount().getUserNo();
        }

        Bundle bundle = getIntent().getExtras();
        ArrayList signgingBankNoList = getIntent().getStringArrayListExtra("signingBankNoList");
        mSigningBankCurrencyList = getIntent().getStringArrayListExtra("singingBankCurrencyNoList");

        mChooseIndex = getIntent().getIntExtra("chooseSigningBankIndex", 0);

        List<HashMap<String, String>> signingBankHashMap = (List<HashMap<String, String>>) bundle.getSerializable("signingBankHashMap");
        for (int i = 0 ; i < signingBankHashMap.size(); i ++){
            if (i < signingBankHashMap.size() && i < signgingBankNoList.size()) {
                mSigningBankNameList.add(signingBankHashMap.get(i).get(signgingBankNoList.get(i)));
            }
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindOnClick();
        initRecyclerview();
    }

    private void initRecyclerview() {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mAdapter = new EsSigningBankAdapter(this, mSigningBankNameList, mSigningBankCurrencyList);
        mAdapter.setOnItemListener(new EsSigningBankAdapter.OnItemListener() {
            @Override
            public void onClick(View v, int pos, String signName) {
                mAdapter.setDefSelect(pos);
                mChooseIndex = pos;
                back();
            }
        });

        rv_bank_list.setLayoutManager(layoutManager);
        rv_bank_list.setAdapter(mAdapter);
        ViewGroup.LayoutParams params = rv_bank_list.getLayoutParams();
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height =((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                50 * mAdapter.getItemCount(), getResources().getDisplayMetrics()));
        rv_bank_list.setLayoutParams(params);
        mAdapter.setDefSelect(mChooseIndex);

        rv_bank_list.setBackgroundResource(R.color.es_activity_bank_transfer_detail_bg);
    }

    private void bindOnClick() {
        itv_back.setOnClickListener(this);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0){
            back();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_bank_choosing;
    }

    @Override
    public void onClick(View view) {
        int i = view.getId();
        if (i == R.id.es_activity_bank_choose_itv_back) {
            back();
        }
    }

    public void back(){
        Intent intent = new Intent();
        intent.putExtra("chooseSigningBankIndex", mChooseIndex);
        setResult(RESULT_OK, intent);
        finish();
    }
}
