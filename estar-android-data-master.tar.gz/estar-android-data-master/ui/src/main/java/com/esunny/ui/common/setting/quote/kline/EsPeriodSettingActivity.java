package com.esunny.ui.common.setting.quote.kline;

import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.esunny.data.bean.KLinePeriod;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.quote.EsKLineData;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsIconTextView;
import com.yydcdut.sdlv.Menu;
import com.yydcdut.sdlv.SlideAndDragListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;

public class EsPeriodSettingActivity extends EsBaseActivity implements SlideAndDragListView.OnDragDropListener {

    @BindView(R2.id.es_activity_period_setting_iv_back)
    EsIconTextView itv_back;
    @BindView(R2.id.es_activity_period_setting_tv_reset)
    TextView tv_reset;
    @BindView(R2.id.es_activity_period_setting_sadl_period)
    SlideAndDragListView sadl_period;
    @BindView(R2.id.es_activity_period_setting_tv_add)
    TextView tv_add;
    @BindView(R2.id.es_activity_period_setting_tv_cancel)
    TextView tv_cancel;
    @BindView(R2.id.es_activity_period_setting_tv_delete)
    TextView tv_delete;
    @BindView(R2.id.es_activity_period_setting_ll_delete)
    LinearLayout ll_delete;

    String strTime;
    List<String> mData = new ArrayList<>();
    List<KLinePeriod> mDefaultList = new ArrayList<>();
    private ArrayList<Character> mTypes = new ArrayList<>();
    private HashMap<Integer, EsIconTextView> cbHashMap = new HashMap<>();
    private List<String> mSelectedPeriod = new ArrayList<>();

    @Override
    protected void initWidget() {
        super.initWidget();
        initListView();

    }

    @Override
    protected void initData() {
        super.initData();
        initLinkOptionsPickerData();
    }

    private void initLinkOptionsPickerData() {
        updatePeriodData();
    }

    private void updatePeriodData() {
        mDefaultList = EsKLineData.getInstance().getKLinePeriods();
        for (int i = 1; i < mDefaultList.size(); i++) {
            KLinePeriod period = mDefaultList.get(i);
            if (period != null) {
                int key = period.getPeriodName();
                if (key == 2) {
                    mData.add(period.getKLineShowSlice() + EsUIApi.convertKLinePeriodType(this, period.getKLineShowType()));
                } else if (key == 3) {
                    if (period.getKLineShowSlice() != 1) {
                        mData.add(period.getKLineShowSlice() + EsUIApi.convertKLinePeriodType(this, period.getKLineShowType()));
                    } else {
                        mData.add(EsUIApi.convertKLinePeriodType(this, period.getKLineShowType()));
                    }
                }
            }
        }

        mTypes = getDefaultType();
    }

    private void initListView() {
        sadl_period.setMenu(new Menu(false));
        sadl_period.setAdapter(mAdapter);
        sadl_period.setOnDragDropListener(this);
    }

    @OnClick(R2.id.es_activity_period_setting_tv_reset)
    public void reSet() {
        mData.clear();
        mDefaultList.clear();
        mSelectedPeriod.clear();

        EsKLineData.getInstance().resetPeriod(this);
        updatePeriodData();

        updateBottomBarUIStatus();
        mAdapter.notifyDataSetChanged();
    }

    @OnClick(R2.id.es_activity_period_setting_tv_add)
    public void add() {
        EsPeriodSelectKeyboardDialog periodSelectKeyboardDialog = new EsPeriodSelectKeyboardDialog(this, mTypes, new EsPeriodSelectKeyboardDialog.onItemSelected() {
            @Override
            public void periodSelect(int number, char type) {
                KLinePeriod period = new KLinePeriod(type, number);

                if (mDefaultList.contains(period) || (number == 1 && type == 'D')) {
                    ToastHelper.show(getApplicationContext(), R.string.es_activity_period_setting_notice_add_again);
                } else {
                    EsKLineData.getInstance().savePeriod(EsPeriodSettingActivity.this, period);

                    mData.add(period.getKLineShowSlice() + EsUIApi.convertKLinePeriodType(EsPeriodSettingActivity.this, period.getKLineShowType()));
                    mAdapter.notifyDataSetChanged();
                }
            }
        });
        periodSelectKeyboardDialog.show();
    }

    @OnClick(R2.id.es_activity_period_setting_tv_cancel)
    public void cancel() {
        for (int i = 0; i < mSelectedPeriod.size(); i++) {
            EsIconTextView checkBox = cbHashMap.get(mData.indexOf(mSelectedPeriod.get(i)));
            if (checkBox != null) {
                checkBox.setText(getBaseContext().getString(R.string.es_icon_keyboard_uncheck));
            }
        }
        //更新完UI之后清除已选择列表
        mSelectedPeriod.clear();

        ll_delete.setVisibility(View.GONE);
        tv_add.setVisibility(View.VISIBLE);
    }

    @OnClick(R2.id.es_activity_period_setting_tv_delete)
    public void delete() {
        for (int i = 0; i < mSelectedPeriod.size(); i++) {
            EsKLineData.getInstance().removePeriod(this, 1 + mData.indexOf(mSelectedPeriod.get(i)));
            mData.remove(mSelectedPeriod.get(i));
        }

        mSelectedPeriod.clear();
        mAdapter.notifyDataSetChanged();
        ll_delete.setVisibility(View.GONE);
        tv_add.setVisibility(View.VISIBLE);
    }

    @OnClick(R2.id.es_activity_period_setting_iv_back)
    public void back() {
        finish();
    }

    private void updateBottomBarUIStatus() {
        if (mSelectedPeriod.size() > 0) {
            ll_delete.setVisibility(View.VISIBLE);
            tv_add.setVisibility(View.GONE);
        } else {
            ll_delete.setVisibility(View.GONE);
            tv_add.setVisibility(View.VISIBLE);
        }
    }

    private BaseAdapter mAdapter = new BaseAdapter() {

        @Override
        public int getCount() {
            return mData.size();
        }

        @Override
        public Object getItem(int i) {
            return mData.get(i);
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(final int position, View contentView, ViewGroup parent) {
            final ViewHolder viewHolder;
            if (contentView == null) {
                viewHolder = new ViewHolder();
                contentView = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_list_period, null);
                viewHolder.cb_select = contentView.findViewById(R.id.es_item_list_period_cb_select);
                viewHolder.tv_period = contentView.findViewById(R.id.es_item_list_period_tv_period);
                viewHolder.iv_drag = contentView.findViewById(R.id.es_item_list_period_iv_drag);
                viewHolder.ll_content_main = contentView.findViewById(R.id.es_item_list_period_ll_content_main);
                viewHolder.ll_main = contentView.findViewById(R.id.es_item_list_period_ll_main);

                contentView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) contentView.getTag();
            }

            if (!cbHashMap.containsKey(position)) {
                cbHashMap.put(position, viewHolder.cb_select);
            }

            String periodStr = mData.get(position);
            viewHolder.tv_period.setText(periodStr);
            viewHolder.cb_select.setTag(position);
            if (mSelectedPeriod.contains(periodStr)) {
                viewHolder.cb_select.setText(getBaseContext().getString(R.string.es_icon_keyboard_check));
            } else {
                viewHolder.cb_select.setText(getBaseContext().getString(R.string.es_icon_keyboard_uncheck));
            }
            viewHolder.iv_drag.setTag(position);

            viewHolder.iv_drag.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    Object object = view.getTag();
                    if (object != null && object instanceof Integer) {
                        sadl_period.startDrag(((Integer) object).intValue());
                    }
                    return false;
                }
            });
            final EsIconTextView cb_select = viewHolder.cb_select;
            final LinearLayout ll_main = viewHolder.ll_main;

            cb_select.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    EsIconTextView check = (EsIconTextView) view;
                    Object o = check.getTag();
                    if (o instanceof Integer) {
                        itemClick(cb_select, ll_main, position);
                    }
                }
            });

            viewHolder.ll_content_main.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    itemClick(cb_select, ll_main, position);
                }
            });

            return contentView;
        }

        void itemClick(EsIconTextView checkbox, LinearLayout linearLayout, int position) {
            // update UI.
            if (checkbox.getText().equals(getBaseContext().getString(R.string.es_icon_keyboard_check))) {
                checkbox.setText(getBaseContext().getString(R.string.es_icon_keyboard_uncheck));
                linearLayout.setBackgroundColor(ContextCompat.getColor(getBaseContext(), R.color.es_viewBkColor));
                mSelectedPeriod.remove(mData.get((int) checkbox.getTag()));
            } else {
                checkbox.setText(getBaseContext().getString(R.string.es_icon_keyboard_check));
                linearLayout.setBackgroundColor(ContextCompat.getColor(getBaseContext(), R.color.es_selectedColor));
                mSelectedPeriod.add(mData.get((int) checkbox.getTag()));
            }

            updateBottomBarUIStatus();
        }

        class ViewHolder {
            EsIconTextView cb_select;
            TextView tv_period;
            EsIconTextView iv_drag;
            LinearLayout ll_content_main;
            LinearLayout ll_main;
        }
    };

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_period_setting;
    }

    @Override
    public void onDragViewStart(int beginPosition) {
        strTime = mData.get(beginPosition);
    }

    @Override
    public void onDragDropViewMoved(int fromPosition, int toPosition) {
        EsKLineData.getInstance().movePeriod(this, 1 + fromPosition, 1 + toPosition);
        String tempStr = mData.remove(toPosition);
        mData.add(fromPosition, tempStr);
    }

    @Override
    public void onDragViewDown(int finalPosition) {
        mData.set(finalPosition, strTime);
    }

    private ArrayList<Character> getDefaultType() {
        ArrayList<Character> list = new ArrayList<>();
        list.add(KLinePeriod.S_KLINE_MINUTE);
        list.add(KLinePeriod.S_KLINE_HOUR);
        list.add(KLinePeriod.S_KLINE_DAY);
        list.add(KLinePeriod.S_KLINE_WEEK);
        list.add(KLinePeriod.S_KLINE_MONTH);
        return list;
    }
}
