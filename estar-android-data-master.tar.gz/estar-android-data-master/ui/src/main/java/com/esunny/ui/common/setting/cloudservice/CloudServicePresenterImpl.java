package com.esunny.ui.common.setting.cloudservice;

import android.content.Context;
import androidx.annotation.NonNull;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.EsWebApi;
import com.esunny.data.api.event.NewsEvent;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.KLinePeriod;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.BasePresenter;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.data.quote.EsKLineData;
import com.esunny.ui.quote.kline.bean.KLineParam;
import com.esunny.ui.util.EsSPHelper;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author xiaosa
 */
public class CloudServicePresenterImpl extends BasePresenter<CloudServiceView> implements CloudServicePresenter {

    private CloudServiceModelImpl mModel;

    private Context mContext;

    public CloudServicePresenterImpl(@NonNull CloudServiceView cloudServiceView) {
        attactView(cloudServiceView);
        mContext = (Context) cloudServiceView;
        mModel = new CloudServiceModelImpl();
    }

    // 调用从服务器接口是否用于同步，因为初始化界面也调用该接口但不同步
    private boolean mIsSyncPhoneContract = false;
    private boolean mIsSyncPhoneSetting = false;

    @Override
    public void register() {
        EventBus.getDefault().register(this);
    }

    @Override
    public void unRegister() {
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void modifyPassword(String oldPassword, String newPassword) {
//        int res = EsWebApi.modifyPassword(oldPassword, newPassword);
//        if (res < 0) {
//            mView.syncFail();
//        }
        //TODO 修改为网页
    }

    @Override
    public void clearData() {
        int res = EsWebApi.clearConfigData();
        if (res < 0) {
            mView.syncFail();
        }
    }

    @Override
    public void logout() {
        EsDataApi.quoteLogout();
    }

    @Override
    public void syncFavoriteContractToCloud() {
        List<Contract> contractList = EsFavoriteListData.getInstance().getFavoriteContractArrayList();
        int res = mModel.sendFavoriteContract(contractList);
        if (res < 0) {
            mView.syncFail();
        }
    }

    /**
     *
     * @param isSync 是否同步，因为初始化界面也调用这个接口获取备份天数但不需要同步
     */
    @Override
    public void syncFavoriteContractFromCloud(boolean isSync) {
        mIsSyncPhoneContract = isSync;
        int res = EsWebApi.getConfigData(1,1);
        if (res < 0) {
            mView.syncFail();
        }
    }

    @Override
    public void syncPCContractFromCloud() {
        int res = EsWebApi.getConfigData(2,1);
        if (res < 0) {
            mView.syncFail();
        }
    }

    @Override
    public void syncSettingToCloud() {
        JSONObject settingConfigJson = getSettingConfig();
        int res = EsWebApi.sendSetting(settingConfigJson);
        if (res < 0) {
            mView.syncFail();
        }
    }

    @Override
    public void syncSettingFromCloud(boolean isSync) {
        mIsSyncPhoneSetting = isSync;
        int res = EsWebApi.getConfigData(1,2);
        if (res < 0) {
            mView.syncFail();
        }
    }

    private void syncServerFavoriteContract(JSONObject jsonObject) {
        JSONObject JsonRspData = jsonObject.getJSONObject("JsonRspData");
        if (JsonRspData == null) return;
        JSONArray array = JsonRspData.getJSONArray("ContractList");
        if (array == null) return;
        List<String> contractStrList = array.toJavaList(String.class);
        List<Contract> contracts = new ArrayList<>();
        for (String temp : contractStrList) {
            Contract contract = EsDataApi.getContract(temp);
            if (contract == null) {
                continue;
            }
            contracts.add(contract);
        }

        List<Contract> favoriteContractList = EsFavoriteListData.getInstance().getFavoriteContractArrayList();
        for (Contract contract : contracts) {
            if (!favoriteContractList.contains(contract)) {
                EsFavoriteListData.getInstance().addFavoriteContract(contract);
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void newsEvent(NewsEvent event) {
        int action = event.getAction();
        Object object = event.getData();

        if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_FAVORITE_FROM_SERVER
                || action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PC_FAVORITE_FROM_SERVER) {
            // 从服务器查询到了自选合约
            if (mIsSyncPhoneContract) {
                syncServerFavoriteContract((JSONObject) object);
                mView.syncFavoriteContractFromServer(true);
            } else {
                int days = getBackUpDays((JSONObject) object);
                if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_FAVORITE_FROM_SERVER) {
                    mView.updateBackupDays(0, days);
                }
            }
        } else if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_FAVORITE_FROM_SERVER_FAIL
                || action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PC_FAVORITE_FROM_SERVER_FAIL) {
            mView.syncFavoriteContractFromServer(false);
        } else if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SEND_FAVORITE_TO_SERVER) {
            mView.syncFavoriteToServer(true);
        } else if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SEND_FAVORITE_TO_SERVER_FAIL) {
            mView.syncFavoriteToServer(false);
        } else if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_CLEAR_DATA) {
            mView.clearConfigData();
        } else if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_FROM_SERVER) {
            if (mIsSyncPhoneSetting) {
                syncServerSetting((JSONObject) object);
                mView.syncSettingFromServer(true);
            } else {
                int days = getSettingBackUpDays((JSONObject) object);
                mView.updateBackupDays(1, days);
            }
        } else if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_FROM_SERVER_FAIL) {
            mView.syncSettingFromServer(false);
        } else if (action == EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_TO_SERVER_FAIL) {
            mView.syncSettingToServer(false);
        } else if (action == EsDataConstant.S_DATA_EVENT_MODIFY_MALL_PASSWORD) {
            JSONObject jsonObject = (JSONObject) object;
            JSONObject dataObject = jsonObject.getJSONObject("JsonRspHead");
            int errorCode = dataObject.getIntValue("ErrorCode");
            if (errorCode == 0) {
                mView.modifyPassword(true, "");
            } else {
                mView.modifyPassword(false, dataObject.getString("ErrorText"));
            }
        }
    }

    private void syncServerSetting(JSONObject jsonObject) {
        JSONObject jsonRspData = jsonObject.getJSONObject("JsonRspData");
        if (jsonRspData == null) return;
        JSONObject settingConfig = jsonRspData.getJSONObject("SettingsConfig");
        boolean isReverseConfirm = settingConfig.getBoolean("IsReverseConfirm");
        EsSPHelperProxy.setIsShowReversePrompt(mContext, isReverseConfirm);
        int textSize = settingConfig.getIntValue("TextSize");
        EsSPHelperProxy.setQuoteTextSize(mContext, textSize);
        int defaultPriceType = settingConfig.getIntValue("DefaultPriceType");
        EsSPHelperProxy.setDefaultPriceType(mContext, defaultPriceType);
        JSONArray periodSettingArray = settingConfig.getJSONArray("PeriodSetting");
        EsKLineData.getInstance().syncKlinePeriods(mContext, periodSettingArray);
        int IsHedge = settingConfig.getIntValue("IsHedge");
        // 0 代表 false
        EsSPHelperProxy.setIsHedge(mContext, IsHedge != 0);
        int PriceCalculateType = settingConfig.getIntValue("PriceCalculateType");
        EsSPHelperProxy.setPriceCalculateMethod(mContext, PriceCalculateType);
        boolean IsOrderConfirm = settingConfig.getBoolean("IsOrderConfirm");
        EsSPHelperProxy.setIsShowChangeOrderPrompt(mContext, IsOrderConfirm);
//        boolean IsDeepQuoteProportionBar = settingConfig.getBoolean("IsDeepQuoteProportionBar");

        boolean IsFingerPrinterConfirm = settingConfig.getBoolean("IsFingerPrinterConfirm");
        EsSPHelperProxy.setIsFingerPrinter(mContext, IsFingerPrinterConfirm);
        JSONObject indexConfigObject = settingConfig.getJSONObject("IndexConfiguration");
        JSONObject swingIndexObject = indexConfigObject.getJSONObject("SwingIndex");
        JSONObject morIndexObject = indexConfigObject.getJSONObject("MorphologicalIndex");
        JSONObject TurnoverndexObject = indexConfigObject.getJSONObject("TurnoverIndex");
        JSONObject result = new JSONObject();
        for (String temp : swingIndexObject.keySet()) {
            result.put(temp, swingIndexObject.getBooleanValue(temp));
        }
        for (String temp : morIndexObject.keySet()) {
            result.put(temp, morIndexObject.getBooleanValue(temp));
        }
        for (String temp : TurnoverndexObject.keySet()) {
            result.put(temp, TurnoverndexObject.getBooleanValue(temp));
        }
        EsSPHelper.setIndexConfig(mContext,  result.toJSONString());
        boolean IsPositionAverageLine = settingConfig.getBoolean("IsPositionAverageLine");
        EsSPHelper.setIsShowPositionCost(mContext, IsPositionAverageLine);
        JSONObject indexParameterObject = settingConfig.getJSONObject("IndexParameter");
        EsKLineData.getInstance().syncIndexParameter(mContext, indexParameterObject);
        boolean SingleShow = settingConfig.getBoolean("IsQuoteSingle");
        EsSPHelper.setIsShowSingle(mContext, SingleShow);
        int DrawOrderPriceType = settingConfig.getIntValue("DrawOrderPriceType");
        EsSPHelperProxy.setDrawLinePriceType(mContext, DrawOrderPriceType);
        boolean IsKeepScreenOn = settingConfig.getBoolean("IsKeepScreenOn");
        EsSPHelperProxy.setIsKeepScreenOn(mContext, IsKeepScreenOn);
        int Language = settingConfig.getIntValue("Language");
        EsSPHelperProxy.saveFavoriteLanguage(mContext, Language);
        boolean IsCacheCodeTable = settingConfig.getBoolean("IsCacheCodeTable");
        EsSPHelperProxy.setIsSaveCodeTable(mContext, IsCacheCodeTable);
        boolean IsMessageShake = settingConfig.getBoolean("IsMessageShake");
        EsSPHelperProxy.setIsShake(mContext, IsMessageShake);
        boolean IsLastPriceLine = settingConfig.getBoolean("IsLastPriceLine");
        EsSPHelper.setIsShowLastPrice(mContext, IsLastPriceLine);
        boolean IsFirstCoverToday = settingConfig.getBoolean("IsFirstCoverToday");
        EsSPHelperProxy.setIsCloseT(mContext, IsFirstCoverToday);
        boolean DeepQuoteGreenRedColor = settingConfig.getBoolean("DeepQuoteGreenRedColor");
        EsSPHelper.setIsKLineBuyRed(mContext, DeepQuoteGreenRedColor);
        boolean IsDisconnectSound = settingConfig.getBoolean("IsDisconnectSound");
        EsSPHelperProxy.setIsUseRington(mContext, IsDisconnectSound);
        boolean IsTradeSound = settingConfig.getBoolean("IsTradeSound");
        EsSPHelperProxy.setIsUseTradeRington(mContext, IsTradeSound);
        boolean IsClickPriceConfirm = settingConfig.getBoolean("IsClickPriceConfirm");
        EsSPHelperProxy.setIsShowClickPrompt(mContext, IsClickPriceConfirm);
        boolean IsDrawLine = settingConfig.getBoolean("IsDrawLine");
        EsSPHelper.setIsShowDrawLine(mContext, IsDrawLine);
        boolean IsTradeLinkage = settingConfig.getBoolean("IsTradeLinkage");
        EsSPHelperProxy.setIsLinkage(mContext, IsTradeLinkage);
        boolean IsMessageSound = settingConfig.getBoolean("IsMessageSound");
        EsSPHelperProxy.setIsUseMessageRington(mContext, IsMessageSound);
        int ReversePriceType = settingConfig.getIntValue("ReversePriceType");
        EsSPHelperProxy.setReversePriceType(mContext, ReversePriceType);
    }

    private JSONObject getSettingConfig() {
        EsKLineData.getInstance().init(mContext);
        JSONObject settingConfig = new JSONObject();

        settingConfig.put("IsReverseConfirm", EsSPHelperProxy.isShowReversePrompt(mContext));

        settingConfig.put("TextSize", EsSPHelperProxy.getQuoteTextSize(mContext));
        settingConfig.put("DefaultPriceType", EsSPHelperProxy.getDefaultPriceType(mContext));

        JSONArray periodSettingArray = new JSONArray();
        List<KLinePeriod> mDefaultList = EsKLineData.getInstance().getKLinePeriods();
        Set<KLinePeriod> tempList = new HashSet<>(mDefaultList);
        for (KLinePeriod period : tempList) {
            JSONObject periodObject = new JSONObject();
            periodObject.put("Value", period.getKLineShowSlice());
            periodObject.put("Type", period.getKLineShowType());
            periodSettingArray.add(periodObject);
        }
        settingConfig.put("PeriodSetting", periodSettingArray);

        settingConfig.put("IsHedge", EsSPHelperProxy.getIsHedge(mContext) ? 1 : 0);

        settingConfig.put("PriceCalculateType", EsSPHelperProxy.getPriceCalculateMethod());
        settingConfig.put("IsOrderConfirm", EsSPHelperProxy.isShowChangeOrderPrompt(mContext));
//        settingConfig.put("IsDeepQuoteProportionBar",  );
        settingConfig.put("IsFingerPrinterConfirm", EsSPHelperProxy.getIsFingerPrinter(mContext));

        List<String> morphologicalIndexList = Arrays.asList("MA", "EMA", "SAR", "BOLL", "PUBU", "SP", "BBI", "EMA2", "SMA", "CDP");
        List<String> turnoverIndexList = Arrays.asList("CJL");
        List<String> swingIndexList = Arrays.asList("MACD", "KD", "KDJ", "RSI", "SLOWKD", "WR", "BIAS", "DMI", "CCI", "PSY", "MTM", "DDI", "ARBR", "TRIX");
        JSONObject morphologicalObject = new JSONObject();
        JSONObject turnoverObject = new JSONObject();
        JSONObject swingObject = new JSONObject();

        List<String> mKLineParamsKeyList = EsKLineData.getInstance().getAllParamsKey();
        JSONObject indexConfigurationObject = new JSONObject();
        String dataStr = EsSPHelper.getIndexConfig(mContext);

        org.json.JSONObject mJson = new org.json.JSONObject();
        if (dataStr == null || dataStr.isEmpty()) {
            mJson = new org.json.JSONObject();
        } else {
            try {
                mJson = new org.json.JSONObject(dataStr);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        for (String keyStr : mKLineParamsKeyList) {
            if (mJson.has(keyStr)) {
                try {
                    if (morphologicalIndexList.contains(keyStr)) {
                        morphologicalObject.put(keyStr, mJson.getBoolean(keyStr));
                    } else if (turnoverIndexList.contains(keyStr)) {
                        turnoverObject.put(keyStr, mJson.getBoolean(keyStr));
                    } else if (swingIndexList.contains(keyStr)) {
                        swingObject.put(keyStr, mJson.getBoolean(keyStr));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                if (morphologicalIndexList.contains(keyStr)) {
                    morphologicalObject.put(keyStr, true);
                } else if (turnoverIndexList.contains(keyStr)) {
                    turnoverObject.put(keyStr, true);
                } else if (swingIndexList.contains(keyStr)) {
                    swingObject.put(keyStr, true);
                }
            }
        }
        indexConfigurationObject.put("MorphologicalIndex", morphologicalObject);
        indexConfigurationObject.put("TurnoverIndex", turnoverObject);
        indexConfigurationObject.put("SwingIndex", swingObject);
        settingConfig.put("IndexConfiguration", indexConfigurationObject);

        settingConfig.put("IsPositionAverageLine", EsSPHelper.getIsShowPositionCost(mContext));

        JSONObject indexParameterObject = new JSONObject();
        HashMap<String, ArrayList<KLineParam>> mKLineParamsHashMap = EsKLineData.getInstance().getAllParams();
        if (mKLineParamsHashMap != null) {
            Iterator<Map.Entry<String, ArrayList<KLineParam>>> entries = mKLineParamsHashMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry<String, ArrayList<KLineParam>> entry = entries.next();
                String key = entry.getKey();
                JSONObject childIndexParameterObject = new JSONObject();
                ArrayList<KLineParam> list = entry.getValue();
                for (KLineParam param : list) {
                    childIndexParameterObject.put(param.getName(), Double.parseDouble(param.getValue()));
                }
                indexParameterObject.put(key, childIndexParameterObject);
            }
        }
        settingConfig.put("IndexParameter", indexParameterObject);

        settingConfig.put("IsQuoteSingle", EsSPHelper.getIsShowSingle(mContext));
        settingConfig.put("DrawOrderPriceType", EsSPHelperProxy.getDrawLinePriceType(mContext));
        settingConfig.put("IsKeepScreenOn", EsSPHelperProxy.getIsKeepScreenOn(mContext));
        settingConfig.put("Language", EsSPHelperProxy.getFavoriteLanguage(mContext));
        settingConfig.put("IsCacheCodeTable", EsSPHelperProxy.getIsSaveCodeTable(mContext));
        settingConfig.put("IsMessageShake", EsSPHelperProxy.getIsShake(mContext));
        settingConfig.put("IsLastPriceLine", EsSPHelper.getIsShowLastPrice(mContext));
        settingConfig.put("IsFirstCoverToday", EsSPHelperProxy.getIsCloseT(mContext));
        settingConfig.put("DeepQuoteGreenRedColor", EsSPHelper.getIsKLineBuyRed(mContext));
        settingConfig.put("IsDisconnectSound", EsSPHelperProxy.getIsUseRington(mContext));
        settingConfig.put("IsTradeSound", EsSPHelperProxy.getIsUseTradeRington(mContext));
        settingConfig.put("IsClickPriceConfirm", EsSPHelperProxy.isShowClickPrompt(mContext));
        settingConfig.put("IsDrawLine", EsSPHelper.getIsShowDrawLine(mContext));
        settingConfig.put("IsTradeLinkage", EsSPHelperProxy.getIsLinkage(mContext));
        settingConfig.put("IsMessageSound", EsSPHelperProxy.getIsUseMessageRington(mContext));
        settingConfig.put("ReversePriceType", EsSPHelperProxy.getReversePriceType(mContext));
        return settingConfig;
    }

    private int getBackUpDays(JSONObject jsonObject) {
        JSONObject JsonRspData = jsonObject.getJSONObject("JsonRspData");
        if (JsonRspData == null || JsonRspData.getInteger("CLTimeDelay") == null) {
            return -1;
        }
        return JsonRspData.getInteger("CLTimeDelay");
    }

    private int getSettingBackUpDays(JSONObject jsonObject) {
        JSONObject JsonRspData = jsonObject.getJSONObject("JsonRspData");
        if (JsonRspData == null || JsonRspData.getInteger("SCTimeDelay") == null) {
            return -1;
        }
        return JsonRspData.getInteger("SCTimeDelay");
    }
}
