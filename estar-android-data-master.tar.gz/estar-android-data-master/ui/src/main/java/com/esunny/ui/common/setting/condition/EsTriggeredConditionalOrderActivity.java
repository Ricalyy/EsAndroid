package com.esunny.ui.common.setting.condition;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.R;
import com.esunny.ui.common.setting.condition.adapter.EsTriggeredConditionalOrderAdapter;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.EsBaseToolBar;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;


public class EsTriggeredConditionalOrderActivity extends EsBaseConditionActivity{


    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_triggered_conditional_order;
    }


    @Override
    protected void initViewValue() {
        mBaseToolBar.setTitle(getString(R.string.es_activity_triggered_conditional_order_basetoolbar));
        mBaseToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
    }

    @Override
    protected void bindOnClick() {
        mBaseToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if(id == R.id.toolbar_left_first) {
                    finish();
                }
            }
        });
    }

    @Override
    protected void initAdapter() {
        mAdapter = new EsTriggeredConditionalOrderAdapter(this);
        ((EsTriggeredConditionalOrderAdapter)mAdapter).setOrderData(mOrderDatas);
    }

    @Override
    protected void getOrderData() {
        if(mOrderDatas == null){
            mOrderDatas = new ArrayList<>();
        }
        mOrderDatas.clear();
        EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        if (loginAccount == null) {
            return;
        }
        List<OrderData> orderData = getCurrentAccountOrderData(loginAccount.getUserNo(), loginAccount.getCompanyNo(), loginAccount.getAddrTypeNo());
        for (int i = 0; i < orderData.size(); i++) {
            OrderData data = orderData.get(i);
            if(data == null){
                continue;
            }
            char type = data.getStrategyType();
            char status = data.getOrderState();
            if((type == EsDataConstant.S_ST_AUTOORDER || type == EsDataConstant.S_ST_CONDITION
                    || type == EsDataConstant.S_ST_CONDITION_PARENT || type == EsDataConstant.S_ST_BACKHAND) &&
                    (status == EsDataConstant.S_ORDERSTATE_FILLTRIGGERED || status == EsDataConstant.S_ORDERSTATE_TRIGGERFAILED
                            || status == EsDataConstant.S_ORDERSTATE_FAIL || status == EsDataConstant.S_ORDERSTATE_CANCELED
                            || status== EsDataConstant.S_ORDERSTATE_INVALID|| status == '\u0000')) {
                mOrderDatas.add(data);
            }
        }
    }

    private List<OrderData> getCurrentAccountOrderData(String userNo, String companyNo, String addrNo) {
        return EsDataApi.getOrderData(companyNo, userNo, addrNo, EsDataConstant.S_ST_CONDITION,'\0',"", -1, true);
    }

    private void updateLists(){
        getOrderData();
        mAdapter.notifyDataSetChanged();
    }

    @Override
    public void onScrollChange(int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();

        if (action == EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER) {
            OrderData data = (OrderData)event.getData();
            if (data == null) {
                return;
            }

            char type = data.getStrategyType();
            if(type == EsDataConstant.S_ST_CONDITION || type == EsDataConstant.S_ST_CONDITION_PARENT
                    || type == EsDataConstant.S_ST_AUTOORDER || type == EsDataConstant.S_ST_BACKHAND) {
                updateLists();
            }
        }
    }
}
