package com.esunny.ui.common.setting.trade;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esunny.ui.R;

public class EsBenefitDataStatistic extends RelativeLayout {
    private TextView mTvDayFirstBenefit; //期初权益
    private TextView mTvDayLastBenefit; //期末权益
    private TextView mTvInOutBenefit; // 出入金
    private TextView mTvServiceCharge; // 手续费
    private TextView mTvRealizedPL; // 平盈
    private TextView mTvMTMPL; //  浮盈
    private TextView mTvInitizeMargin; // 保证金

    private final String DEFAULT_VALUE = "----";

    public EsBenefitDataStatistic(Context context) {
        this(context, null);
    }

    public EsBenefitDataStatistic(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public EsBenefitDataStatistic(Context context, AttributeSet attrs, int defStyleAttr) {
        this(context, attrs, defStyleAttr, 0);
    }

    public EsBenefitDataStatistic(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    private void init(Context context) {
        initView(context);
    }

    private void initView(Context context) {
        LayoutInflater.from(context).inflate(R.layout.es_benefit_data_statistic, this);
        bindView();
        bindViewValue();
    }

    private void bindView() {
        mTvDayFirstBenefit = findViewById(R.id.es_benefit_day_first_benefit);
        mTvDayLastBenefit = findViewById(R.id.es_benefit_day_last_benefit);
        mTvInOutBenefit = findViewById(R.id.es_benefit_day_tv_inout_benefit);
        mTvServiceCharge = findViewById(R.id.es_benefit_day_tv_service_charge);
        mTvRealizedPL = findViewById(R.id.es_benefit_day_tv_profit);
        mTvMTMPL = findViewById(R.id.es_benefit_day_tv_profit_service);
        mTvInitizeMargin = findViewById(R.id.es_benefit_day_tv_initialMargin);
    }

    private void bindViewValue(){

    }

    public void updatePannelValue(String bfBalance, String cfBalance, String realizedPL, String MTMPL, String commission, String initialMargin, String depositWithdrawal){
        mTvDayFirstBenefit.setText(bfBalance);
        mTvDayLastBenefit.setText(cfBalance);
        mTvRealizedPL.setText(realizedPL);
        mTvMTMPL.setText(MTMPL);
        mTvServiceCharge.setText(commission);
        mTvInitizeMargin.setText(initialMargin);
        mTvInOutBenefit.setText(depositWithdrawal);
    }

    public void resetView() {
        mTvDayFirstBenefit.setText(DEFAULT_VALUE);
        mTvDayLastBenefit.setText(DEFAULT_VALUE);
        mTvRealizedPL.setText(DEFAULT_VALUE);
        mTvMTMPL.setText(DEFAULT_VALUE);
        mTvServiceCharge.setText(DEFAULT_VALUE);
        mTvInitizeMargin.setText(DEFAULT_VALUE);
        mTvInOutBenefit.setText(DEFAULT_VALUE);
    }
}
