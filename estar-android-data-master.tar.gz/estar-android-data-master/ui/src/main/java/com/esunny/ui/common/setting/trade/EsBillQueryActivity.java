package com.esunny.ui.common.setting.trade;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.BillData;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.util.EsShareUtil;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsCustomerToast;
import com.esunny.ui.view.EsDateSelectKeyboardDialog;
import com.esunny.ui.view.EsIconTextView;
import com.esunny.ui.view.calendarPicker.CalendarUtil;

import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import butterknife.BindView;
import skin.support.content.res.SkinCompatResources;

public class EsBillQueryActivity extends EsBaseActivity implements View.OnClickListener {

    @BindView(R2.id.es_activity_bill_query_rl_calendar)
    RelativeLayout rl_calendar;
    @BindView(R2.id.es_activity_bill_query_etv_query)
    EsIconTextView etv_query;
    @BindView(R2.id.es_activity_bill_query_tv_date)
    TextView tv_date;
    @BindView(R2.id.es_activity_bill_query_tv_content)
    TextView tv_content;
    @BindView(R2.id.es_activity_bill_query_iv_back)
    EsIconTextView itv_back;
    @BindView(R2.id.es_activity_bill_query_hsv_bill_content)
    HorizontalScrollView hsv_bill_content;
    @BindView(R2.id.es_activity_bill_query_toolbar)
    EsBaseToolBar mToolbar;

    private Calendar mCalendar;
    private int mYear, mMonth, mDay;
    private String mNowDate, mCompanyNo, mUserNo, mAddrNo;

    private String mBillContent;
    private String mBillDate = "";

    EsCustomerToast mEsCustomerToast;
    final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    private static final String TAG = "EsBillQueryActivity";
    private final static String ROOT_DIR = Environment.getExternalStorageDirectory().getPath();
    private final static String BILL_LOG_DIR = ROOT_DIR + "/Estar/TradeLog/";
    private final static String FILE_SUFFIX_NAME = ".txt";

    @Override
    protected void initData() {
        super.initData();
        initDate();

        if (EsLoginAccountData.getInstance().getCurrentAccount() != null) {
            mCompanyNo = EsLoginAccountData.getInstance().getCurrentAccount().getCompanyNo();
            mUserNo = EsLoginAccountData.getInstance().getCurrentAccount().getUserNo();
            mAddrNo = EsLoginAccountData.getInstance().getCurrentAccount().getAddrTypeNo();
        }
    }

    private void initDate() {
        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
        if (account != null){
            mCalendar = Calendar.getInstance();
            String[] date = account.getTradeDate();
            Date tradeDate = new Date();
            String dealDay;
            if (date[0] != null && !date[0].trim().isEmpty()){
                dealDay = date[0];
            }else if (date[1] != null && !date[1].trim().isEmpty()){
                dealDay = date[1];
            }else {
                mYear = mCalendar.get(Calendar.YEAR);
                mMonth = mCalendar.get(Calendar.MONTH) + 1;
                mDay = mCalendar.get(Calendar.DAY_OF_MONTH);
                dealDay = mYear + "-" + CalendarUtil.dealMonthOrDay(mMonth) + "-" + CalendarUtil.dealMonthOrDay(mDay);
            }

            try {
                tradeDate = new SimpleDateFormat("yyyy-MM-dd").parse(dealDay);
                mCalendar.setTime(tradeDate);
                int day = mCalendar.get(Calendar.DATE);
                mCalendar.set(Calendar.DATE, day -1);
                mNowDate = new SimpleDateFormat("yyyy-MM-dd").format(mCalendar.getTime());
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

//        mCalendar = Calendar.getInstance();

    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindOnClick();
        initToolbar();
        initCusViewNightBg();
        tv_date.setText(mNowDate);

        queryBill();
    }

    private void initToolbar() {
        mToolbar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if(id == R.id.toolbar_left_first){
                    finish();
                }else if (id == R.id.toolbar_right_first){
                    if (mBillContent != null && ! mBillContent.isEmpty()) {
                        shareBill();
                    }else {
                        ToastHelper.show(EsBillQueryActivity.this, R.string.es_activity_bill_query_no_bill_content);
                    }
                }
            }
        });
    }

    private void shareBill() {
        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
        if (account != null) {
            String fileName = BILL_LOG_DIR + mBillDate + account.getCompanyName() + "_" + account.getUserNo() + "_" + "billlog_Android" + FILE_SUFFIX_NAME;
            File file = createFile(fileName);
            EsShareUtil.shareTxt(EsBillQueryActivity.this, file);
        }
    }

    private File createFile(String fileName) {
        File fileFolder = new File(BILL_LOG_DIR);
        if (!fileFolder.exists()) {
            fileFolder.mkdirs();
        }

        File file = new File(fileName);
        if(!file.exists()){
            try {
                PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(file)));
                pw.println(mBillContent);
                pw.println();
                pw.close();
            } catch (IOException e) {
                Log.e(TAG,"写文件错误！！", e);
            }
        }
        return file;
    }

    private void initCusViewNightBg() {
        hsv_bill_content.setBackground(SkinCompatResources.getDrawable(this, R.drawable.es_login_bill_confirm_bg_bill));
    }

    private void bindView() {
        mEsCustomerToast = EsCustomerToast.create(this)
                .setTip(getString(R.string.es_activity_login_bill_confirm_loading))
                .setStyle(EsCustomerToast.Style.TOAST_LOADING)
                .setAutoDismiss(true)
                .setDurationTime(10000)
                .setDimAmount(0.5f);
    }

    private void bindOnClick() {
        itv_back.setOnClickListener(this);
        rl_calendar.setOnClickListener(this);
        etv_query.setOnClickListener(this);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_bill_query;
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.es_activity_bill_query_rl_calendar) {
            EsDateSelectKeyboardDialog esDateSelectKeyboardDialog = new EsDateSelectKeyboardDialog(this, tv_date, new EsDateSelectKeyboardDialog.onItemSelected() {
                @Override
                public void timeSelect(int year, int month, int day) {
                    String chooseDateStr = year + "-" + CalendarUtil.dealMonthOrDay(month) + "-" + CalendarUtil.dealMonthOrDay(day);

                    try {
                        if (CompareDate(chooseDateStr, mNowDate)) {
                            tv_date.setText(chooseDateStr);
                            queryBill();
                        }else {
                            ToastHelper.show(getApplicationContext(), R.string.es_activity_bill_query_error_date);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void cancel() {

                }
            });
            esDateSelectKeyboardDialog.show();
        } else if (i == R.id.es_activity_bill_query_etv_query) {
            queryBill();
        } else if (i == R.id.es_activity_bill_query_iv_back) {
            finish();
        }
    }

    public boolean CompareDate(String formerTime,String laterTime) {
        Date formerDate = null;
        Date laterDate = null;
        try {
            formerDate = format.parse(formerTime);
            laterDate = format.parse(laterTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        //  || formerDate.getTime()-laterDate.getTime() ==0
        return formerDate.getTime()-laterDate.getTime() < 0 || formerDate.getTime()-laterDate.getTime() == 0;
    }


    public void queryBill() {
        if (mCompanyNo == null || mUserNo == null || mAddrNo == null) {
            ToastHelper.show(this, R.string.es_activity_bill_query_error_query);
            return;
        }

        etv_query.setClickable(false);
        if (mUserNo == null || mCompanyNo == null || mAddrNo == null) {
            return;
        }

        EsDataApi.queryBill(mCompanyNo, mUserNo, mAddrNo, tv_date.getText().toString());
        // Update the UI
        //progressBar.setVisibility(View.VISIBLE);
        hsv_bill_content.setVisibility(View.GONE);

        mEsCustomerToast.show();
        // 查詢之前清空數據
        tv_content.setText("");
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event){
        int action = event.getAction();
        Object data = event.getData();

        switch (action){
            case  EsDataConstant.S_SRVEVENT_QRY_BILL:
                if (data instanceof BillData) {
                    getBill((BillData) data);
                }
                break;
            default:
                break;
        }
    }

    private void getBill(BillData srvData) {
        // Judge callback whether is bill.
        mBillContent = "";
        if (srvData != null) {
            if (srvData.getContent().equals("")) {
                ToastHelper.show(EsBillQueryActivity.this, R.string.es_activity_bill_query_no_bill_content);
            } else {
                mBillDate = srvData.getBillDate();
                mBillContent = srvData.getContent();
                tv_content.setText(srvData.getContent());
            }
        } else {
            ToastHelper.show(EsBillQueryActivity.this, R.string.es_activity_bill_query_no_bill_content);
        }
        etv_query.setClickable(true);
        // Update the UI
        //progressBar.setVisibility(View.GONE);
        if (mEsCustomerToast.isShowing()) {
            mEsCustomerToast.cancel();
        }
        hsv_bill_content.setVisibility(View.VISIBLE);
    }
}
