package com.esunny.ui.common.setting.system;

import androidx.core.content.ContextCompat;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsCusSwitchButton;
import com.esunny.ui.view.EsIconTextView;


@Route(path = RoutingTable.ES_CHOOSE_RINGTONG_ACTIVITY)
public class EsChooseRingtongActivity extends EsBaseActivity implements View.OnClickListener {
    EsBaseToolBar mToolbar;

    RelativeLayout mRlChooseBuzz;
    EsIconTextView mEtvBuzz;
    EsCusSwitchButton mSwitchIsUseRington;

    TextView mTvBuzz;

    @Override
    protected void initWidget() {
        super.initWidget();

        bindView();
        bindViewValue();
        bindOnClick();
        initViewNightColor();
    }

    private void initViewNightColor() {
        if (EsSPHelper.getTheme(this)){
//            mSwitchIsUseRington.setThumbDrawableRes(R.drawable.es_bg_custom_switch_thumb_drawable);
//            mSwitchIsUseRington.setBackDrawableRes(R.drawable.es_bg_custom_switch_back_drawable);
        }else {
//            mSwitchIsUseRington.setThumbDrawableRes(R.drawable.es_bg_custom_switch_thumb_drawable_night);
//            mSwitchIsUseRington.setBackDrawableRes(R.drawable.es_bg_custom_switch_back_drawable_night);
        }
    }

    private void bindView() {
        mToolbar = findViewById(R.id.es_activity_choose_ringtong_toolbar);
        mRlChooseBuzz = findViewById(R.id.es_activity_rl_choose_buzz);
        mEtvBuzz = findViewById(R.id.es_activity_etv_choose_buzz);
        mSwitchIsUseRington = findViewById(R.id.es_activity_system_setting_switch_is_use_rington);
        mTvBuzz = findViewById(R.id.activity_es_choose_tv_default_ringtong);
    }

    private void bindViewValue() {
        mToolbar.setSimpleBack(getString(R.string.es_activity_system_setting_choose_ringtong));

        mSwitchIsUseRington.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                EsSPHelperProxy.setIsUseRington(getApplicationContext(),isChecked);
                if (EsSPHelper.getTheme(getBaseContext())) {
                    if (isChecked) {
                        mTvBuzz.setTextColor(ContextCompat.getColor(getBaseContext(), R.color.es_mainTextColor));
                    } else {
                        mTvBuzz.setTextColor(ContextCompat.getColor(getBaseContext(), R.color.es_bg_no_message_hint));
                    }
                }else {
                    if (isChecked) {
//                        mTvBuzz.setTextColor(ContextCompat.getColor(getBaseContext(), R.color.es_mainTextColor_night));
                    } else {
//                        mTvBuzz.setTextColor(ContextCompat.getColor(getBaseContext(), R.color.es_bg_no_message_hint_night));
                    }
                }
            }
        });

        if (EsSPHelper.getTheme(getBaseContext())) {
            if (EsSPHelperProxy.getIsUseRington(getApplicationContext())) {
                mTvBuzz.setTextColor(ContextCompat.getColor(getBaseContext(), R.color.es_mainTextColor));
            } else {
                mTvBuzz.setTextColor(ContextCompat.getColor(getBaseContext(), R.color.es_bg_no_message_hint));
            }
        }else {
            if (EsSPHelperProxy.getIsUseRington(getApplicationContext())) {
//                mTvBuzz.setTextColor(ContextCompat.getColor(getBaseContext(), R.color.es_mainTextColor_night));
            } else {
//                mTvBuzz.setTextColor(ContextCompat.getColor(getBaseContext(), R.color.es_bg_no_message_hint_night));
            }
        }

        switch (EsSPHelperProxy.getRingTongType(getApplicationContext())){
            case EsSPHelperProxy.RINGTONG_DEFAULT:
                updateRingTongUI(mEtvBuzz);
                break;
            default:
                break;
        }
    }

    private void bindOnClick() {
        mRlChooseBuzz.setOnClickListener(this);
    }

    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_choose_ringtong;
    }

    @Override
    public void onClick(View v) {
        if (!EsSPHelperProxy.getIsUseRington(getApplicationContext())){
            return;
        }

        int id = v.getId();
        if (id == R.id.es_activity_rl_choose_buzz){
            chooseRingtong(mEtvBuzz);
        }
    }

    private void chooseRingtong(View view) {
        if (isSwitchRingtong(view)) {
            if (view == mEtvBuzz) {
                setRingtong(EsSPHelperProxy.RINGTONG_DEFAULT);
            }

            updateRingTongUI(view);
        }
    }

    private void updateRingTongUI(View view) {
        mEtvBuzz.setVisibility(View.GONE);

        view.setVisibility(View.VISIBLE);
    }

    private void setRingtong(int type) {
        switch (type) {
            case EsSPHelperProxy.RINGTONG_DEFAULT:
                EsSPHelperProxy.setRingTongType(getApplicationContext(),EsSPHelperProxy.RINGTONG_DEFAULT);
                break;
            default:
                EsSPHelperProxy.setRingTongType(getApplicationContext(),EsSPHelperProxy.RINGTONG_DEFAULT);
                break;
        }
    }

    private boolean isSwitchRingtong(View view) {
        if(view.getVisibility() == View.VISIBLE){
            return false;
        }
        return true;
    }

    @Override
    protected void onStart() {
        mSwitchIsUseRington.setChecked(EsSPHelperProxy.getIsUseRington(getApplicationContext()));
        super.onStart();
    }
}
