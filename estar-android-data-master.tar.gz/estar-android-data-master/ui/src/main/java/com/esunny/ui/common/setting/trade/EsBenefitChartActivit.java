package com.esunny.ui.common.setting.trade;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsMVPActivity;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.util.EsShareUtil;
import com.esunny.ui.util.OnTextCenter;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.ArcProgress;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.calendarPicker.CalendarUtil;
import com.esunny.ui.view.calendarPicker.DatePopupWindow;
import com.esunny.ui.view.chartview.BarChart;
import com.esunny.ui.view.chartview.BarChartCommodityView;
import com.esunny.ui.view.chartview.BarChartData;
import com.esunny.ui.view.chartview.BarDataSet;
import com.esunny.ui.view.chartview.BenefitAccountView;
import com.esunny.ui.view.chartview.BenefitChartSelector;
import com.esunny.ui.view.chartview.DataEntry;
import com.esunny.ui.view.chartview.EsBenefitDaySelector;
import com.esunny.ui.view.chartview.LineChart;
import com.esunny.ui.view.chartview.PieChart;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import butterknife.BindView;

public class EsBenefitChartActivit extends EsMVPActivity<EsBenefitPresenter> implements EsBenefitCombination.View, PieChart.OnItemClickListener{

    @BindView(R2.id.activity_es_benefit_chart_toolbar)
    EsBaseToolBar mToolbar;
    @BindView(R2.id.lineChart)
    LineChart myChart;
    @BindView(R2.id.es_activity_benefit_chart_benefitDataStatistic)
    EsBenefitDataStatistic mBenefitDataStatistic;
    @BindView(R2.id.es_activity_benefit_chart_rl_overlay)
    RelativeLayout mRlOverLay;
    @BindView(R2.id.es_activity_benefit_chart_account_view)
    BenefitAccountView benefitAccountView;
    @BindView(R2.id.es_activity_benefit_chart_day_selector)
    EsBenefitDaySelector daySelector;
    @BindView(R2.id.es_activity_benefit_chart_selector)
    BenefitChartSelector mBenefitChartSelector;
    @BindView(R2.id.es_activity_benefit_progress_bar)
    ArcProgress mProgressBar;
    @BindView(R2.id.es_benefit_barchart)
    BarChart barChart;
    @BindView(R2.id.es_benefit_piechart)
    PieChart pieChart;
    @BindView(R2.id.es_benefit_piechart_commodity_view)
    BarChartCommodityView commodityView;

    private int startGroup = -1;
    private int endGroup = -1;
    private int startChild = -1;
    private int endChild = -1;

    private final int timeout = 30 * 1000;

    private Handler mHandler;

    private Runnable mOverRunnable;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_benefit_chart;
    }

    @Override
    protected void initData() {
        super.initData();
        mHandler = new Handler(Looper.getMainLooper());

        mPresenter.registerBillCallback();

        mPresenter.startQueryBillData(7);

        mOverRunnable = new Runnable() {
            @Override
            public void run() {
                mRlOverLay.setVisibility(View.GONE);
                ToastHelper.show(getApplicationContext(), R.string.es_bill_benefit_query_timeout);
            }
        };
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        initToolbar();

        initMyLineChart();

        bindViewValue();

        bindViewEvent();
    }

    private void bindViewEvent() {
        daySelector.setChoosePeriod(new EsBenefitDaySelector.IChoosePeriod() {
            @Override
            public void choosePeriod(int days) {
                resetLineChart();
                mProgressBar.setProgress(0);
//                mRlOverLay.setVisibility(View.VISIBLE);
                startOverLay();
                mPresenter.startQueryBillData(days);
            }
        });

        daySelector.mTvCustom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createCustomDatePicker(v);
            }
        });

        mBenefitChartSelector.mTvCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = capture(EsBenefitChartActivit.this);
                EsShareUtil.sharePicture(EsBenefitChartActivit.this, bitmap);
            }
        });
    }

    private Bitmap capture(Activity activity) {
        View dView = getWindow().getDecorView();
        dView.setDrawingCacheEnabled(true);
        dView.buildDrawingCache();
        Bitmap bmp = dView.getDrawingCache();
        return bmp;
    }

    private void createCustomDatePicker(View view) {
        new DatePopupWindow
                .Builder(EsBenefitChartActivit.this, Calendar.getInstance().getTime(), view)
                .setInitSelect(startGroup, startChild, endGroup, endChild)
                .setInitDay(true)
                .setDateOnClickListener(new DatePopupWindow.DateOnClickListener() {
                    @Override
                    public void getDate(String startDate, String endDate, int startGroupPosition, int startChildPosition, int endGroupPosition, int endChildPosition) {
                        startGroup = startGroupPosition;
                        startChild = startChildPosition;
                        endGroup = endGroupPosition;
                        endChild = endChildPosition;
                        String mStartTime = CalendarUtil.FormatBillDateYMD(startDate);
                        String mEndTime = CalendarUtil.FormatBillDateYMD(endDate);
                        int days = CalendarUtil.daysBetween(mStartTime, mEndTime);
                        if (days < 2) {
                            ToastHelper.show(getApplicationContext(), R.string.es_bill_benefit_profit_chart_warning_at_least_three_days);
                        }else if (days > 13){
                            ToastHelper.show(getApplicationContext(), R.string.es_bill_benefit_profit_chart_warning_at_most_thirteen_days);
                        }else {
                            daySelector.setSelectedDay(daySelector.mTvCustom);
                            mProgressBar.setProgress(0);
                            resetLineChart();
//                            mRlOverLay.setVisibility(View.VISIBLE);
                            startOverLay();
                            mPresenter.startCusQueryBillData(days, mEndTime);
                        }
                    }
                }).builder();
    }

    private void bindViewValue() {
        int textColor = getResources().getColor(R.color.es_klineMaMid);
        int textSize = (int) getResources().getDimension(R.dimen.x48);
        mProgressBar.setOnCenterDraw(new OnTextCenter(textColor, textSize));

//        mRlOverLay.setVisibility(View.VISIBLE);
        startOverLay();
        EsLoginAccountData.LoginAccount account = EsLoginAccountData.getInstance().getCurrentAccount();
        if (account != null){
            benefitAccountView.updateTitle(account.getUserNo());
        }
    }

    private void initMyLineChart() {
        pieChart.setRadius(getResources().getDimension(R.dimen.x180));
    }

    private void initToolbar() {
        mToolbar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_left_first) {
                    finish();
                }
            }
        });
    }

    private void resetLineChart(){
        myChart.setData(mPresenter.gerResetChartData());
        mBenefitDataStatistic.resetView();
        barChart.setData(mPresenter.gerResetBarChartData());
        pieChart.resetView();
        commodityView.resetView();
    }

    @Override
    protected EsBenefitPresenter createPresenter() {
        return new EsBenefitPresenter(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mPresenter.unRegisterBillCallback();
    }

    @Override
    public void updateBenefitDataStatisticUI(String bfBalance, String cfBalance, String realizedPL, String MTMPL, String commission, String initialMargin, String depositWithdrawal) {
//        mRlOverLay.setVisibility(View.GONE);
        endOverLay();
        mBenefitDataStatistic.updatePannelValue(bfBalance, cfBalance, realizedPL, MTMPL, commission, initialMargin, depositWithdrawal);
    }

    @Override
    public void updateChart() {
        myChart.setData(mPresenter.getLineChartData());
        barChart.setData(mPresenter.getBarChartData());
        pieChart.setPieEntries(mPresenter.getPieChartData());
        commodityView.setPieEntries(mPresenter.getPieChartData());
    }

    @Override
    public void simulateProgressBar(int progress) {
        mProgressBar.setProgress(progress);
    }

    @Override
    public void noEnoughBillData() {
        ToastHelper.show(getApplicationContext(), R.string.es_bill_benefit_no_enough_bill_data);
    }

    @Override
    public void onItemClick(int position) {

    }

    private void startOverLay(){
        mRlOverLay.setVisibility(View.VISIBLE);
        mHandler.postDelayed(mOverRunnable, timeout);
    }

    private void endOverLay(){
        mRlOverLay.setVisibility(View.GONE);
        mHandler.removeCallbacks(mOverRunnable);
    }
}
