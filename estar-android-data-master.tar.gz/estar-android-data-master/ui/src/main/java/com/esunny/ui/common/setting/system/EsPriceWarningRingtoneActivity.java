package com.esunny.ui.common.setting.system;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.CompoundButton;

import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsCusSwitchButton;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.OnCheckedChanged;

public class EsPriceWarningRingtoneActivity extends EsBaseActivity implements EsRingtonAdapter.OnItemSelected{

    @BindView(R2.id.es_activity_price_warning_rv)
    RecyclerView mRv;
    @BindView(R2.id.es_activity_price_warning_toolbar)
    EsBaseToolBar mToolbar;
    @BindView(R2.id.es_activity_price_warning_switch_is_use_rington)
    EsCusSwitchButton mSwitch;

    EsRingtonAdapter mAdapter = new EsRingtonAdapter();
    List<String > mList = new ArrayList<>();

    @Override
    protected int getContentView() {
        return R.layout.es_activity_price_warning;
    }

    @Override
    protected void initData() {
        super.initData();

        mList.add("Ding");
        mList.add("MidlyAlarming");
        mList.add("Nassau");
        mList.add("pixiedust");
        mList.add("pizzicato");
        mList.add("Ring_Classic_02");
        mList.add("Ring_Digital_02");
        mList.add("Ring_Synnth_02");
        mList.add("Ring_synth_04");
        mList.add("TaDa");
        mList.add("Tinkerbell");
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        mToolbar.setSimpleBack(getString(R.string.es_activity_price_warning_title));
        mSwitch.setChecked(EsSPHelperProxy.getIsUsePriceWarningRington(this));

        initRecyclerView();
    }

    private void initRecyclerView() {
        mAdapter.setmCheckedPosition(EsSPHelperProxy.getPriceWarningRingtonType(this));
        mAdapter.setmDataList(mList);
        mAdapter.setmLister(this);
        mRv.setAdapter(mAdapter);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        mRv.setLayoutManager(linearLayoutManager);
    }

    @OnCheckedChanged(R2.id.es_activity_price_warning_switch_is_use_rington)
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        EsSPHelperProxy.setIsUsePriceWarningRington(this, isChecked);
    }

    @Override
    public void onItemSelected(int position) {
        EsSPHelperProxy.setPriceWarningRingtonType(this, position);
    }
}
