package com.esunny.ui.common.setting.trade;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.setting.trade.adapter.EsTradePriceChooseListAdapter;
import com.esunny.ui.trade.data.EsTradePriceTypeInfo;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.EstarFieldTransformation;
import com.esunny.ui.view.EsBaseToolBar;

import java.util.ArrayList;
import java.util.List;

public class EsPriceTypeActivity extends EsBaseActivity {
    private static final String TAG = "EsPriceTypeActivity";

    static final String ACTIVITY_TYPE_KEY = "type";
    static final int ACTIVITY_TYPE_VALUE_DEFAULT = 0;
    static final int ACTIVITY_TYPE_VALUE_REVERSE = 1;
    static final int ACTIVITY_TYPE_VALUE_DRAWLINE = 2;

    EsBaseToolBar tb_toolbar;
    RecyclerView rv_price_choose;

    private int mPriceType;

    private int mCheckedPosition;

    private List<EsTradePriceTypeInfo> mData = new ArrayList<>();
    private List<String> mPriceTypeStringList = new ArrayList<>();

    private EsTradePriceChooseListAdapter mAdapter;

    @Override
    protected void initData() {
        super.initData();
        mPriceType = getIntent().getIntExtra(ACTIVITY_TYPE_KEY, 0);
        int priceType = 0;
        if (mPriceType == ACTIVITY_TYPE_VALUE_DEFAULT) {
            priceType = EsSPHelperProxy.getDefaultPriceType(this);
        } else if (mPriceType == ACTIVITY_TYPE_VALUE_REVERSE) {
            priceType = EsSPHelperProxy.getReversePriceType(this);
        } else if (mPriceType == ACTIVITY_TYPE_VALUE_DRAWLINE) {
            priceType = EsSPHelperProxy.getDrawLinePriceType(this);
        }

        String defaultPrice = EstarFieldTransformation.priceTypeToStr(this, priceType);

        // Four choose price type.

        // 華夏下單有超價
        if (mPriceType == ACTIVITY_TYPE_VALUE_DRAWLINE) {
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_latest_drawline));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_queue));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_market));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_counter));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_exceed));
        } else if (mPriceType == ACTIVITY_TYPE_VALUE_DEFAULT) {
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_latest));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_queue));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_market));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_counter));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_latest_exceed));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_queue_exceed));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_counter_exceed));
        } else {
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_latest));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_queue));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_market));
            mPriceTypeStringList.add(getString(R.string.es_price_keyboard_counter));
        }

        // Load the data of the list.
        for (String priceTypeName : mPriceTypeStringList) {
            if (priceTypeName.equals(defaultPrice)) {
                mCheckedPosition = mPriceTypeStringList.indexOf(priceTypeName);
            }

            EsTradePriceTypeInfo tradePriceTypeInfo = new EsTradePriceTypeInfo();
            tradePriceTypeInfo.setPriceTypeName(priceTypeName);
            mData.add(tradePriceTypeInfo);
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        initBaseToolbar();
    }

    private void initBaseToolbar() {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mAdapter = new EsTradePriceChooseListAdapter(this, mData, mCheckedPosition);
        mAdapter.setOnItemSelected(new EsTradePriceChooseListAdapter.OnItemSelected() {
            @Override
            public void onItemSelected() {
                back();
            }
        });


        rv_price_choose.setLayoutManager(layoutManager);
        rv_price_choose.setAdapter(mAdapter);
        tb_toolbar.setSimpleBack(getString(R.string.es_activity_trade_setting_default_price_type));

        tb_toolbar.setLeftIcons(R.string.es_icon_toolbar_back);
        if (mPriceType == ACTIVITY_TYPE_VALUE_DEFAULT) {
            tb_toolbar.setTitle(getString(R.string.es_util_activity_default_price_type_choosing_title));
        } else if (mPriceType == ACTIVITY_TYPE_VALUE_REVERSE) {
            tb_toolbar.setTitle(getString(R.string.es_util_activity_reverse_price_type_choosing_title));
        } else if (mPriceType == ACTIVITY_TYPE_VALUE_DRAWLINE) {
            tb_toolbar.setTitle(getString(R.string.es_util_activity_drawline_price_type_choosing_title));
        }
        tb_toolbar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                back();
            }
        });
    }

    private void bindView() {
        tb_toolbar = findViewById(R.id.es_activity_default_price_type_toolbar);
        rv_price_choose = findViewById(R.id.es_activity_default_price_type_choosing_rv_price_choose);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_default_price_type_choosing;
    }

    public void back() {
        saveSetting();

        finish();
    }

    private void saveSetting() {
        String defaultPriceTypeStr = mPriceTypeStringList.get(mAdapter.getCheckedPosition());

        int priceType = EstarFieldTransformation.priceStrToType(this, defaultPriceTypeStr);

        if (mPriceType == ACTIVITY_TYPE_VALUE_DEFAULT) {
            EsSPHelperProxy.setDefaultPriceType(this, priceType);
        } else if (mPriceType == ACTIVITY_TYPE_VALUE_REVERSE) {
            EsSPHelperProxy.setReversePriceType(this, priceType);
        } else if (mPriceType == ACTIVITY_TYPE_VALUE_DRAWLINE) {
            EsSPHelperProxy.setDrawLinePriceType(this, priceType);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveSetting();
    }
}
