package com.esunny.ui.common.server;

import android.app.Service;
import android.content.Intent;
import android.location.Location;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.api.event.HisQuoteEvent;
import com.esunny.data.api.event.QuoteEvent;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.MessageData;
import com.esunny.data.bean.CloudTradeCompany;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.TradeLoginRsp;
import com.esunny.data.bean.TrdSecondCheckCodeRsp;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsNetHelper;
import com.esunny.data.api.EsDataTrackApi;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.data.setting.EsMessageData;
import com.esunny.ui.data.setting.EsNetStateNotification;
import com.esunny.ui.util.EsGetLocation;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import static com.esunny.ui.api.EsEventConstant.E_STAR_ACTION_STRATEGY_NUM;
import static com.esunny.ui.api.EsEventConstant.E_STAR_MODULE_TRADE;

public class NetEventService extends Service {

    private final static String TAG = "NetEventService";

    public static final String CHANNEL_ID_STRING = "com.esunny.ui.common.server";

    private final static int MSG_QUOTE_CONNECT = 0;
    private final static int MSG_QUOTE_DISCONNECT = 1;

    private final static int MSG_HIS_QUOTE_CONNECT = 10;
    private final static int MSG_HIS_QUOTE_DISCONNECT = 11;

    private final static int MSG_TRADE_CONNECT = 20;
    private final static int MSG_TRADE_DISCONNECT = 21;
    private final static int MSG_TRADE_LOGOUT = 22;
    private final static int MSG_TRADE_DATE_CHANGE = 23;
    private final static int MSG_TRADE_SMS_AUTH_NOTIFY = 24;
    private final static int MSG_TRADE_SMS_AUTH_NOTIFY_RSP = 25;
    private final static int MSG_TRADE_LOGIN = 26;
    private final static int MSG_TRADE_LOGGED= 27;

    private Handler mHandle;

    private List<CloudTradeCompany> mCloudTradeCompanies = null;

    @Nullable
    @Override
    public IBinder onBind(@NonNull Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        EsLog.d(TAG, "onCreate()");

        mHandle = new Handler(getMainLooper(), new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                switch (msg.what) {
                    case MSG_QUOTE_CONNECT:
                        EsNetStateNotification.getInstance().quoteLoginEvent(EsNetStateNotification.EVENT_LOGIN);
                        break;
                    case MSG_QUOTE_DISCONNECT:
                        EsNetStateNotification.getInstance().quoteLoginEvent(EsNetStateNotification.EVENT_DISCONNECT);
                        break;
                    case MSG_HIS_QUOTE_CONNECT:
                        EsNetStateNotification.getInstance().hisQuoteLoginEvent(EsNetStateNotification.EVENT_LOGIN);
                        break;
                    case MSG_HIS_QUOTE_DISCONNECT:
                        EsNetStateNotification.getInstance().hisQuoteLoginEvent(EsNetStateNotification.EVENT_DISCONNECT);
                        break;
                    case MSG_TRADE_CONNECT:
                    {
                        TradeEvent event = (TradeEvent) msg.obj;
                        String companyNo = event.getCompanyNo();
                        String userNo = event.getUserNo();
                        String addrNo = event.getAddressNo();
                        int code = event.getSrvErrorCode();
                        EsNetStateNotification.getInstance().tradeLoginEvent(EsNetStateNotification.EVENT_CONNECT,
                                companyNo, userNo, addrNo, code);
                    }
                        break;
                    case MSG_TRADE_DISCONNECT:
                    {
                        TradeEvent event = (TradeEvent) msg.obj;
                        String companyNo = event.getCompanyNo();
                        String userNo = event.getUserNo();
                        String addrNo = event.getAddressNo();
                        int code = event.getSrvErrorCode();
                        EsNetStateNotification.getInstance().tradeLoginEvent(EsNetStateNotification.EVENT_DISCONNECT,
                                companyNo, userNo, addrNo, code);
                    }
                        break;
                    case MSG_TRADE_LOGOUT:
                    {
                        TradeEvent event = (TradeEvent) msg.obj;
                        String companyNo = event.getCompanyNo();
                        String userNo = event.getUserNo();
                        String addrNo = event.getAddressNo();
                        int code = event.getSrvErrorCode();
                        EsNetStateNotification.getInstance().tradeLoginEvent(EsNetStateNotification.EVENT_LOGOUT,
                                companyNo, userNo, addrNo, code);
                    }
                        break;
                    case MSG_TRADE_DATE_CHANGE:
                        EsNetStateNotification.getInstance().onTradeDateChg();
                        break;
                    case MSG_TRADE_SMS_AUTH_NOTIFY:
                    {
                        TradeEvent event = (TradeEvent) msg.obj;
                        String companyNo = event.getCompanyNo();
                        String userNo = event.getUserNo();
                        String addrNo = event.getAddressNo();
                        int code = event.getSrvErrorCode();
                        EsNetStateNotification.getInstance().onSmsAuthNotify(companyNo, userNo, addrNo, code);
                    }
                        break;
                    case MSG_TRADE_SMS_AUTH_NOTIFY_RSP:
                    {
                        TrdSecondCheckCodeRsp response = (TrdSecondCheckCodeRsp) msg.obj;
                        String serialId = response.getSecondSerialID();
                        double stillTime = response.getEffectiveTime();
                        EsNetStateNotification.getInstance().updateSmsAuthDialogUITime(serialId, stillTime);
                        break;
                    }
                    case MSG_TRADE_LOGIN:
                    {
                        TradeEvent event = (TradeEvent) msg.obj;
                        // 二次认证跳入
                        TradeLoginRsp tradeLoginRsp = (TradeLoginRsp) event.getData();
                        if (tradeLoginRsp != null) {
                            EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
                            if (loginAccount != null && loginAccount.getCompanyNo().equals(tradeLoginRsp.getCompanyNo())
                                    && loginAccount.getUserNo().equals(tradeLoginRsp.getUserNo())
                                    && loginAccount.getAddrTypeNo().equals(tradeLoginRsp.getAddrTypeNo())) {
                                if (tradeLoginRsp.getErrorCode() == 10003) {
                                    EsNetStateNotification.getInstance().onReLoginSmsAuth(tradeLoginRsp.getCompanyNo(), tradeLoginRsp.getUserNo(), tradeLoginRsp.getAddrTypeNo());
                                    break;
                                }
                            }
                        }

                        String companyNo = event.getCompanyNo();
                        String userNo = event.getUserNo();
                        String addrNo = event.getAddressNo();
                        int code = event.getSrvErrorCode();
                        EsNetStateNotification.getInstance().tradeLoginEvent(EsNetStateNotification.EVENT_LOGIN,
                                companyNo, userNo, addrNo, code);
                        if (mCloudTradeCompanies == null) {
                            mCloudTradeCompanies = EsDataApi.getCloudTradeCompanyData("", "");
                        }
                        CloudTradeCompany cloudTradeCompany = findCloudTradeCompany(companyNo);
                        if (cloudTradeCompany != null) {
                            dealTradeInfo(companyNo, cloudTradeCompany.getCompanyName(), userNo, addrNo, cloudTradeCompany.getAddrTypeName(),
                                    "LoginIn", cloudTradeCompany.getTradeApi());
                        }
                    }
                    break;
                    case MSG_TRADE_LOGGED:
                    {

                        break;
                    }
                    default:
                        break;
                }
                return false;
            }
        });

        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        EsMessageData.getInstance().initMessageData(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        EsLog.d(TAG, "onStartCommand()");
        return super.onStartCommand(intent, flags, startId);
    }

    private void updateBadgeViewNum(String companyNo, String userNo, String addrNo) {
        EsLoginAccountData.LoginAccount currentAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        if (currentAccount != null) {
            if (currentAccount.getCompanyNo().equals(companyNo) && currentAccount.getUserNo().equals(userNo) && currentAccount.getAddrTypeNo().equals(addrNo)) {
                EsEventMessage.Builder builder = new EsEventMessage.Builder(E_STAR_ACTION_STRATEGY_NUM);
                builder.setSender(E_STAR_MODULE_TRADE);
                EventBus.getDefault().post(builder.buildEvent());
            }
        }
    }

    private void dealTradeInfo(String companyNo, String companyName, String userNo, String addressNo, String addressName,String loginType, String tradeApi) {
        Location location = EsGetLocation.getLongitudeAndLatitude(getApplicationContext());
        String mac = EsNetHelper.getMac(getApplicationContext());
        String ip = EsNetHelper.getIpAddress(getApplicationContext());
        String gps = "";
        if (location != null) {
            gps = location.getLongitude() + ", " + location.getLatitude();
        }
        AddrInfo tradeServiceAddressInfo = EsDataApi.getAddrInfo(EsUIConstant.S_SRVSRC_TRADE, companyNo, userNo, addressNo);
        String serverIp = "";
        int serverPort = 0;
        if (tradeServiceAddressInfo != null) {
            serverIp = tradeServiceAddressInfo.getIp();
            serverPort = tradeServiceAddressInfo.getPort();
        }
        EsDataTrackApi.addTradeLogin(companyNo, companyName, userNo, addressNo, addressName, loginType, tradeApi, ip, mac, gps, serverIp, serverPort);
    }

    private CloudTradeCompany findCloudTradeCompany(String companyNo) {
        if (mCloudTradeCompanies == null) {
            return null;
        }
        CloudTradeCompany company = null;
        for (int i = 0; i < mCloudTradeCompanies.size(); i++) {
            if (companyNo.equals(mCloudTradeCompanies.get(i).getCompanyNo())) {
                company = mCloudTradeCompanies.get(i);
                break;
            }
        }
        return company;
    }

    @Override
    public void onDestroy() {
        EsLog.d(TAG, "stop NetEventService");

        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }

        if (mHandle != null) {
            mHandle.removeCallbacksAndMessages(null);
        }

        super.onDestroy();
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();
        String companyNo = event.getCompanyNo();
        String userNo = event.getUserNo();
        String addrNo = event.getAddressNo();

        switch (action) {
            case EsDataConstant.S_SRVEVENT_CONNECT:
                if (mHandle != null) {
                    Message message = mHandle.obtainMessage(MSG_TRADE_CONNECT);
                    message.obj = event;
                    mHandle.sendMessage(message);
                }
                break;
            case EsDataConstant.S_SRVEVENT_DISCONNECT:
                if (mHandle != null) {
                    Message message = mHandle.obtainMessage(MSG_TRADE_DISCONNECT);
                    message.obj = event;
                    mHandle.sendMessage(message);
                }
                break;
            case EsDataConstant.S_SRVEVENT_TRADELOGOUT:
                if (mHandle != null) {
                    Message message = mHandle.obtainMessage(MSG_TRADE_LOGOUT);
                    message.obj = event;
                    mHandle.sendMessage(message);
                }
                break;
            case EsDataConstant.S_SRVEVENT_TRADE_ORDER:
            case EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER:
            {
                //写日志文件
                OrderData order = (OrderData)event.getData();

                if (order == null) {
                    EsLog.w(TAG, "tradeCallBack: order is null");
                    break;
                }

                if (event.getSrvErrorCode() == 0) {
                    updateBadgeViewNum(companyNo, userNo, addrNo);
                }
            }
                break;
            case EsDataConstant.S_SRVEVENT_TRADE_MESSAGE:
            {
                MessageData smessageData = (MessageData) event.getData();
                boolean isEnd = event.getSrvChain();

                if (smessageData == null) {
                    if (isEnd) {
                        EsMessageData.getInstance().setIsEndMessage(companyNo, userNo, addrNo);
                    }
                    EsLog.w(TAG, "tradeCallBack: message Data is null");
                    break;
                }

                EsMessageData.getInstance().setMessageData(smessageData, isEnd);
                break;
            }
            case EsDataConstant.S_SRVEVENT_TRADEDATECHG:
            {
                if (mHandle != null) {
                    mHandle.sendEmptyMessage(MSG_TRADE_DATE_CHANGE);
                }
                break;
            }
            case EsDataConstant.S_SRVEVENT_SMSAUTH_NOTIFY:
            {
                if (mHandle != null) {
                    mHandle.sendMessage(mHandle.obtainMessage(MSG_TRADE_SMS_AUTH_NOTIFY, event));
                }
                break;
            }
            case EsDataConstant.S_SRVEVENT_SMSAUTHINFO_RSP:
            {
                // 获取验证码和有效时间 更新 同时读秒
                TrdSecondCheckCodeRsp rsp = (TrdSecondCheckCodeRsp) event.getData();

                if (mHandle != null) {
                    mHandle.sendMessage(mHandle.obtainMessage(MSG_TRADE_SMS_AUTH_NOTIFY_RSP, rsp));
                }
                break;
            }
            case EsDataConstant.S_SRVEVENT_TRADELOGIN:
            {
                if (mHandle == null) {
                    return;
                }

                mHandle.sendMessage(mHandle.obtainMessage(MSG_TRADE_LOGIN, event));
                break;
            }
            case EsDataConstant.S_SRVEVENT_TRADELOGINED:
            {

                if (EsLoginAccountData.getInstance().isLogin(companyNo, userNo, addrNo)
                        && !EsLoginAccountData.getInstance().isCurrentAccount(companyNo, userNo, addrNo)) {
                    return;
                }

                EsLog.d(TAG, "serviceTradeLogined send msg, " + userNo);
                EsEventMessage.Builder builder = new EsEventMessage.Builder( EsEventConstant.E_STAR_ACTION_LOADING_LOGIN_INIT);
                builder.setSender(EsEventConstant.E_STAR_MODULE_LOGIN);
                builder.setContent(companyNo + userNo + addrNo);

                //增加loading提示“数据同步中”
                EventBus.getDefault().postSticky(builder.buildEvent());
                break;
            }
            case EsDataConstant.S_SRVEVENT_TINITCOMPLETED: {
                EsEventMessage.Builder builder = new EsEventMessage.Builder(EsEventConstant.E_STAR_ACTION_LOADING_LOGIN_INIT);
                builder.setSender(EsEventConstant.E_STAR_MODULE_LOGIN);
                builder.setContent(companyNo + userNo + addrNo);
                EventBus.getDefault().removeStickyEvent(builder.buildEvent());

                if (!EsLoginAccountData.getInstance().isCurrentAccount(companyNo, userNo, addrNo)) {
                    EsLog.d(TAG, "loginInitCompleted error send msg, " + userNo);
                    return;
                }

                EsLog.d(TAG, "loginInitCompleted send msg, " + userNo);
                //取消loading提示“数据同步中”
                builder.setAction(EsEventConstant.E_STAR_ACTION_LOGIN_INIT_COMPLETED);
                EventBus.getDefault().postSticky(builder.buildEvent());
                break;
            }
            case EsDataConstant.S_SRVEVENT_TRADE_MATCH: {
                if (event.getSrvErrorCode() == 0) {
                    updateBadgeViewNum(companyNo, userNo, addrNo);
                }
                break;
            }
            default:
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void quoteEvent(QuoteEvent event) {
        int action = event.getAction();

        switch (action) {
            case EsDataConstant.S_SRVEVENT_QUOTELOGIN:
                if (mHandle != null) {
                    mHandle.sendEmptyMessage(MSG_QUOTE_CONNECT);
                }
                break;
            case EsDataConstant.S_SRVEVENT_DISCONNECT:
                if (mHandle != null) {
                    mHandle.sendEmptyMessage(MSG_QUOTE_DISCONNECT);
                }
                break;
            default:
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void hisQuoteEvent(HisQuoteEvent event) {
        int action = event.getAction();

        switch (action) {
            case EsDataConstant.S_SRVEVENT_HISLOGIN:
                if (mHandle != null) {
                    mHandle.sendEmptyMessage(MSG_HIS_QUOTE_CONNECT);
                }
                break;
            case EsDataConstant.S_SRVEVENT_DISCONNECT:
                if (mHandle != null) {
                    mHandle.sendEmptyMessage(MSG_HIS_QUOTE_DISCONNECT);
                }
                break;
            default:
                break;
        }
    }
}
