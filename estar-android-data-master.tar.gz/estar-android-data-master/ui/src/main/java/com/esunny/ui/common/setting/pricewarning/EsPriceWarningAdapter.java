package com.esunny.ui.common.setting.pricewarning;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.ui.R;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.data.quote.EsFavoriteListData;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;


public class EsPriceWarningAdapter extends RecyclerView.Adapter {

    private Context             mContext;
    private int                 mOpenedIndex = -1;
    private OnItemClick         mOnItemClick;
    private List<MonitorOrder> mMonitorData = new ArrayList<>();
    private PopupWindow mOldPopwindow;
    private HashMap<Integer, PopupWindow> mPopupWindowHashMap = new HashMap<>();
    private boolean isDestroy = false;

    public void setMonitorData(List<MonitorOrder> data){
        if(data != null) {
            sortMonitorData(data);
        }
    }

    public void setIsDestroy(boolean destroy) {
        isDestroy = destroy;
    }

    public OnItemClick getOnItemClick() {
        return mOnItemClick;
    }

    public void setOnItemClick(OnItemClick onItemClick) {
        mOnItemClick = onItemClick;
    }

    public interface OnItemClick{
        void itemClick(char action, MonitorOrder data);
        void toKLine(String contractNo);
    }

    public void reSetOpenedIndex(){
        mOpenedIndex = -1;
        notifyDataSetChanged();
    }


    public EsPriceWarningAdapter(Context context){
        this.mContext = context;
    }

    private void sortMonitorData(List<MonitorOrder> data) {
        mMonitorData.clear();
        for (MonitorOrder monitorOrder : data) {
            if (monitorOrder != null && monitorOrder.getOrderState() != EsDataConstant.S_ORDERSTATE_CANCELED &&
                    monitorOrder.getOrderState() != EsDataConstant.S_ORDERSTATE_FILLTRIGGERED) {
                if (monitorOrder.getPriceMax1() != EsDataConstant.S_PRICE_NOT_MONITOR || monitorOrder.getPriceMin1() != EsDataConstant.S_PRICE_NOT_MONITOR
                        || monitorOrder.getGrowthWidthMax() != EsDataConstant.S_PRICE_NOT_MONITOR || monitorOrder.getGrowthWidthMin() != EsDataConstant.S_PRICE_NOT_MONITOR) {
                    mMonitorData.add(monitorOrder);
                }
            }
        }

        Collections.sort(mMonitorData, new Comparator<MonitorOrder>() {
            @Override
            public int compare(MonitorOrder o1, MonitorOrder o2) {
                if (o1 == null || o2 == null) {
                    return 0;
                }

                String time1 = o1.getInsertDateTime();
                String time2 = o2.getInsertDateTime();

                if (time1 == null || time2 == null) {
                    return 0;
                }

                time1 = time1.replace(":", "").replace(" ", "").replace("-", "");
                time2 = time2.replace(":", "").replace(" ", "").replace("-", "");

                BigInteger time1L = new BigInteger(time1);
                BigInteger time2L = new BigInteger(time2);

                return time2L.compareTo(time1L);
            }
        });
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        if (position < getItemCount()) {
            ((ViewHolder) holder).setDataOnView(mMonitorData.get(position));
            final MonitorOrder monitorOrder = mMonitorData.get(position);
            String text = "";
            ((ViewHolder) holder).mTvChange.setVisibility(View.GONE);
            if (monitorOrder.getOrderState() == EsDataConstant.S_ORDERSTATE_TRIGGERING || monitorOrder.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTTRIGGERED) {
                text = mContext.getString(R.string.es_strategy_condition_list_suspend);
                ((ViewHolder) holder).mTvSuspendOrResume.setVisibility(View.VISIBLE);
            } else if (monitorOrder.getOrderState() == EsDataConstant.S_ORDERSTATE_SUSPENDED) {
                text = mContext.getString(R.string.es_strategy_condition_list_resume);
                ((ViewHolder) holder).mTvSuspendOrResume.setVisibility(View.VISIBLE);
            } else {
                //其他状态应该隐藏  挂起、激活按钮
                ((ViewHolder) holder).mTvSuspendOrResume.setVisibility(View.INVISIBLE);
            }
            ((ViewHolder) holder).mTvSuspendOrResume.setText(text);
            ((ViewHolder) holder).mTvRevoke.setText(R.string.es_activity_price_warn_delete_order);
            ((ViewHolder) holder).mTvRevoke.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mOnItemClick != null) {
                        mOnItemClick.itemClick(EsDataConstant.S_OAT_CANCEL, monitorOrder);
                    }
                    reSetOpenedIndex();
                }
            });

            ((ViewHolder) holder).mTvSuspendOrResume.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (monitorOrder.getOrderState() == EsDataConstant.S_ORDERSTATE_TRIGGERING || monitorOrder.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTTRIGGERED) {
                        if (mOnItemClick != null) {
                            mOnItemClick.itemClick(EsDataConstant.S_OAT_SUSPEND, monitorOrder);
                        }
                    } else if (monitorOrder.getOrderState() == EsDataConstant.S_ORDERSTATE_SUSPENDED) {
                        if (mOnItemClick != null) {
                            mOnItemClick.itemClick(EsDataConstant.S_OAT_RESUME, monitorOrder);
                        }
                    }
                    reSetOpenedIndex();
                }
            });

            ((ViewHolder)holder).mTvKLine.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mOnItemClick.toKLine(monitorOrder.getContractNo());
                }
            });

            if (mPopupWindowHashMap.get(position) != null) {
                mPopupWindowHashMap.get(position).dismiss();
            }
            mPopupWindowHashMap.put(position, ((ViewHolder) holder).mPopupWindow);
            bind(((ViewHolder) holder), position);

            if (((ViewHolder) holder).mLlOrderMain != null) {
                ((ViewHolder) holder).mLlOrderMain.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOpenedIndex == position) {
                            mOpenedIndex = -1;
                            notifyItemChanged(position);
                        } else {
                            if (mPopupWindowHashMap.get(mOpenedIndex) != null) {
                                mOldPopwindow = mPopupWindowHashMap.get(mOpenedIndex);
                                if(mOldPopwindow!=null) {
                                    mOldPopwindow.dismiss();
                                }
                            }
                            notifyItemChanged(mOpenedIndex);
                            mOpenedIndex = position;
                            notifyItemChanged(position);
                        }
                    }
                });
            }
        }
    }

    @Override
    public int getItemCount() {
        return mMonitorData == null ? 0 : mMonitorData.size();
    }


    private void bind(ViewHolder holder, int pos) {
        PopupWindow popupWindow = mPopupWindowHashMap.get(pos);
        if (pos == mOpenedIndex && pos > -1 &&  mMonitorData.get(pos).getOrderState() != EsDataConstant.S_ORDERSTATE_CANCELED) {
            holder.mLlRevoke.setVisibility(View.VISIBLE);
            showBelowView(popupWindow, holder.mLlTitleMain, pos);
            holder.mLlTitleMain.setBackgroundResource(R.color.es_bg_ll_condition_order_main_content);
            holder.mLlRevoke.setBackgroundResource(R.color.es_bg_ll_condition_order_main_content);
        } else {
            holder.mLlRevoke.setVisibility(View.GONE);
            popupWindow.dismiss();
            holder.mLlTitleMain.setBackgroundResource(R.color.es_bg_item_condition_order);
        }
    }

    private void showBelowView(final PopupWindow popupWindow, final View parent, final int position) {
        if (parent != null &&parent.getVisibility() == View.GONE) {
            popupWindow.showAtLocation(parent, 0, 0, 0);
        } else if (parent != null){
            final int[] location = new int[2];
            parent.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!isDestroy) {
                        parent.getLocationOnScreen(location);
                        popupWindow.showAtLocation(parent, 0, 0, location[1] +
                                mContext.getResources().getDimensionPixelOffset(R.dimen.y144));
                    }
                }
            }, 300);
        }
    }

    public void recoverList(){
        for (int i = 0; i < mPopupWindowHashMap.size(); i++){
            if (mPopupWindowHashMap.get(i).isShowing()){
                mOpenedIndex = -1;
                notifyDataSetChanged();
                break;
            }
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int type){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_activity_price_warn_order,parent,false);
        return new EsPriceWarningAdapter.ViewHolder(view);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView mTvContractName;
        TextView mTvPriceHighest;
        TextView mTvPriceLowest;
        TextView mTvPriceLimitUp;
        TextView mTvPriceLimitDown;
        TextView mTvInserttime;
        LinearLayout mLlOrderMain, mLlTitleMain, mLlRevoke;
        TextView mTvRevoke;
        TextView mTvKLine;
        TextView mTvSuspendOrResume;
        TextView mTvChange;

        PopupWindow mPopupWindow;

        ViewHolder(View itemView) {
            super(itemView);
            mTvContractName = itemView.findViewById(R.id.es_item_price_warn_contract_name);
            mTvPriceHighest = itemView.findViewById(R.id.es_item_price_warn_price_highest);
            mTvPriceLowest = itemView.findViewById(R.id.es_item_price_warn_price_lowest);
            mTvPriceLimitUp = itemView.findViewById(R.id.es_item_price_warn_price_limitup);
            mTvPriceLimitDown = itemView.findViewById(R.id.es_item_price_warn_price_limitdown);
            mTvInserttime = itemView.findViewById(R.id.es_item_price_warn_price_insertTime);
            mLlOrderMain = itemView.findViewById(R.id.es_item_price_warn_order_ll_main);
            mLlTitleMain = itemView.findViewById(R.id.es_item_price_warn_title_ll_main);
            mLlRevoke = itemView.findViewById(R.id.es_item_price_warn_order_rl_revoke);

            View view = LayoutInflater.from(mContext).inflate(R.layout.es_strategy_conditional_order_popupwindow, null);
            mPopupWindow = new PopupWindow(view, mContext.getResources().getDimensionPixelSize(R.dimen.x1080)
                    , mContext.getResources().getDimensionPixelSize(R.dimen.y140));
            mPopupWindow.setFocusable(false);
            mPopupWindow.setOutsideTouchable(false);
            mPopupWindow.update();

            mTvChange = mPopupWindow.getContentView().findViewById(R.id.es_item_cloud_conditional_order_tv_modify);
            mTvSuspendOrResume = mPopupWindow.getContentView().findViewById(R.id.es_item_cloud_conditional_order_tv_suspend);
            mTvRevoke = mPopupWindow.getContentView().findViewById(R.id.es_item_cloud_conditional_order_tv_revoke);
            mTvKLine = mPopupWindow.getContentView().findViewById(R.id.es_item_cloud_conditional_order_tv_kline);
        }

        public void setDataOnView(MonitorOrder data){
            if (data == null){
                return;
            }

            Contract contract = EsDataApi.getTradeContract(data.getContractNo());
            if (contract != null) {
                mTvContractName.setText(contract.getContractName());
            } else {
                mTvContractName.setText(data.getContractNo());
            }

            if (data.getPriceMax1() == EsDataConstant.S_PRICE_NOT_MONITOR) {
                mTvPriceHighest.setText("--");
            } else {
                if (contract != null) {
                    mTvPriceHighest.setText(EsDataApi.formatPrice(contract.getCommodity(), data.getPriceMax1()));
                } else {
                    mTvPriceHighest.setText(String.valueOf(data.getPriceMax1()));
                }
            }

            if (data.getPriceMin1() == EsDataConstant.S_PRICE_NOT_MONITOR) {
                mTvPriceLowest.setText("--");
            } else {
                if (contract != null) {
                    mTvPriceLowest.setText(EsDataApi.formatPrice(contract.getCommodity(), data.getPriceMin1()));
                } else {
                    mTvPriceLowest.setText(String.valueOf(data.getPriceMin1()));
                }
            }

            if (data.getGrowthWidthMax() == EsDataConstant.S_PRICE_NOT_MONITOR) {
                mTvPriceLimitUp.setText("--");
            } else {
                mTvPriceLimitUp.setText(String.format(Locale.getDefault(), "%.2f%%", data.getGrowthWidthMax()));
            }

            if (data.getGrowthWidthMin() == EsDataConstant.S_PRICE_NOT_MONITOR) {
                mTvPriceLimitDown.setText("--");
            } else {
                mTvPriceLimitDown.setText(String.format(Locale.getDefault(), "%.2f%%", data.getGrowthWidthMin()));
            }

            mTvInserttime.setText(data.getInsertDateTime());
        }
    }
}
