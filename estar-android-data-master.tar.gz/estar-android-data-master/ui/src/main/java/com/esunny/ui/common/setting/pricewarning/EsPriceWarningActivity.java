package com.esunny.ui.common.setting.pricewarning;

import android.content.Intent;
import android.os.Message;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.RelativeLayout;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.MonitorEvent;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.data.bean.MonitorOrderAction;
import com.esunny.ui.R;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsHorizontalScrollView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import android.os.Handler;


@Route(path = RoutingTable.ES_PRICE_WARN_ACTIVITY)
public class EsPriceWarningActivity extends EsBaseActivity {

    private EsBaseToolBar mBaseToolBar;
    private RelativeLayout mOverLay;
    private RecyclerView mRecyclerView;
    private EsHorizontalScrollView mScrollView;
    private EsPriceWarningAdapter mAdapter;
    private List<MonitorOrder> mMonitorData = new ArrayList<>();
    private int mNum = 1;
    private Handler mTimer;
    private static final int LOGIN_TIME_OUT = 0;
    private static WeakReference<EsPriceWarningActivity> weakReference;

    @Override
    protected void initWidget() {
        super.initWidget();
        initView();
        initViewValue();
        bindOnClick();
    }

    @Override
    protected void initData() {
        super.initData();
    }

    public static void finishActivity() {
        if (weakReference != null && weakReference.get() != null) {
            weakReference.get().finish();
        }
    }

    private void dealPriceConnect(int num) {
        mTimer.removeMessages(LOGIN_TIME_OUT);
        mNum = num;
        mOverLay.setVisibility(View.GONE);
    }

    private void updateDataList() {
        mMonitorData = EsDataApi.getMonitorOrder();
        mAdapter.setMonitorData(mMonitorData);
        mAdapter.notifyDataSetChanged();
    }

    private void initView(){
        mBaseToolBar = findViewById(R.id.es_activity_price_warn_toolbar);
        mOverLay = findViewById(R.id.es_activity_price_warn_rl_overlay);
        mRecyclerView = findViewById(R.id.es_activity_price_warn_rv);
        mScrollView = findViewById(R.id.es_activity_price_warn_scrollerView);

        mAdapter = new EsPriceWarningAdapter(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                (mAdapter).recoverList();
            }
        });
        mAdapter.setMonitorData(mMonitorData);

        mAdapter.setOnItemClick(new EsPriceWarningAdapter.OnItemClick() {
            @Override
            public void itemClick(char action, MonitorOrder data) {
                if (data == null) {
                    return;
                }
                MonitorOrderAction orderAction = new MonitorOrderAction();
                orderAction.setContractNo(data.getContractNo());
                orderAction.setOrderNo(data.getOrderNo());
                orderAction.setOrderActionType(action);
                EsDataApi.actionMonitorOrder(orderAction);
            }

            @Override
            public void toKLine(String contractNo) {
                Contract contract = EsDataApi.getQuoteContract(contractNo);
                if (contract != null) {
                    EsFavoriteListData.getInstance().addFavoriteContract(contract,false);
                    EsUIApi.startEsKLineActivity(EsUIConstant.S_CONTRACT_LIST_FAVORITE,
                            EsFavoriteListData.getInstance().getFavoriteIndex(contractNo), EsUIConstant.TO_KLINE_FROM_PRICEWARN);
                }
            }
        });
    }

    private void initViewValue() {
        mBaseToolBar.setTitle(getString(R.string.es_activity_price_warn_base_toolbar));
        mBaseToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
        mBaseToolBar.setRightIcons(new int[]{R.string.es_icon_condition_order_add, R.string.es_icon_condition_order_filltriggered_new});

        mTimer = new LoginHandler(this);
        mTimer.sendMessageDelayed(mTimer.obtainMessage(LOGIN_TIME_OUT), 10*1000);
        mOverLay.setVisibility(View.VISIBLE);

        weakReference = new WeakReference<>(EsPriceWarningActivity.this);
    }

    private void bindOnClick() {
        mBaseToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_left_first) {
                    finish();
                } else if (id == R.id.toolbar_right_first) {
                    if (mOverLay.getVisibility() == View.GONE) {
                        Intent intent = new Intent();
                        intent.setClass(EsPriceWarningActivity.this, EsPriceWarnEditActivity.class);
                        intent.putExtra("connectNum", mNum);
                        startActivity(intent);
                    }
                } else if (id == R.id.toolbar_right_second) {
                    if (mOverLay.getVisibility() == View.GONE) {
                        startActivity(new Intent(EsPriceWarningActivity.this, EsTriggeredPriceWarningActivity.class));
                    }
                }
            }
        });
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_price_warn;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mAdapter != null) {
            mAdapter.setIsDestroy(false);
        }

        EventBus.getDefault().register(this);

        int ret = EsDataApi.priceLogin();
        if (ret > 0) {
            dealPriceConnect(EsDataConstant.PRICE_SERVER_CONNECT_SUCCESS);
            updateDataList();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mAdapter != null) {
            mAdapter.setIsDestroy(true);
        }

        EventBus.getDefault().unregister(this);

        if (mTimer != null) {
            mTimer.removeCallbacksAndMessages(null);
        }
    }

    static class LoginHandler extends Handler {
        private WeakReference<EsPriceWarningActivity> mOuter;

        LoginHandler(EsPriceWarningActivity activity) {
            mOuter = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(Message msg) {
            if (mOuter == null) {
                return;
            }

            EsPriceWarningActivity activity = mOuter.get();

            if (msg.what == LOGIN_TIME_OUT) {
                activity.mOverLay.setVisibility(View.GONE);
                ToastHelper.show(activity, R.string.es_kline_activity_price_warn_disconnect_server);
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(MonitorEvent event) {
        int action = event.getAction();

        switch (action) {
            case EsDataConstant.S_SRVEVENT_CONNECT:
                updateDataList();
                dealPriceConnect(EsDataConstant.PRICE_SERVER_CONNECT_SUCCESS);//成功发送0
                break;
            case EsDataConstant.S_SRVEVENT_DISCONNECT:
                dealPriceConnect(EsDataConstant.PRICE_SERVER_CALLBACK_DISCONNECT);
                ToastHelper.show(EsPriceWarningActivity.this, R.string.es_kline_activity_price_warn_connect_fail);
                break;
            case EsDataConstant.S_SRVEVENT_CONNECTFAIL:
                dealPriceConnect(EsDataConstant.PRICE_SERVER_CONNECT_FAIL);//失败发送1
                ToastHelper.show(EsPriceWarningActivity.this, R.string.es_kline_activity_price_warn_disconnect_server);
                break;
            case EsDataConstant.S_SRVEVENT_MONITOR_QRY:
            case EsDataConstant.S_SRVEVENT_MONITOR_RTN:
            case EsDataConstant.S_SRVEVENT_MONITOR_ACTION:
            case EsDataConstant.S_SRVEVENT_MONITOR_DELETE:
                updateDataList();
                break;
            default:
                break;
        }
    }
}
