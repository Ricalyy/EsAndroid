package com.esunny.ui.common.setting;

import android.content.Intent;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.common.EsMvpFragment;
import com.esunny.ui.common.setting.about.EsFeedbackActivity;
import com.esunny.ui.common.setting.cloudservice.EsCloudServiceActivity;
import com.esunny.ui.common.setting.quote.login.EsStarStoreActivity;
import com.esunny.ui.data.EsBadgeDataManger;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.data.setting.EsMessageData;
import com.esunny.ui.data.setting.EsNetStateNotification;
import com.esunny.ui.event.MessageEvent;
import com.esunny.ui.util.ButtonUtils;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.view.EsBadgeTextView;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;
import butterknife.OnClick;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static com.esunny.ui.api.EsEventConstant.E_STAR_ACTION_NOTIFY_TRADE_STATE;

public class EsSettingFragment extends EsMvpFragment<SettingPresenterImpl> implements SettingCombination.View {

    @BindView(R2.id.es_fragment_login_rl_account_num)
    LinearLayout mLlAccountNum;
    @BindView(R2.id.es_textView_loginDetail)
    TextView mTextViewDetail;
    @BindView(R2.id.es_fragment_login_ll_accouont_detail)
    LinearLayout mLlAccountDetail;
    @BindView(R2.id.es_fragment_login_tv_login)
    Button mTvLogin;
    @BindView(R2.id.es_fragment_login_tv_network_state)
    TextView mTvNetWorkState;
    @BindView(R2.id.es_fragment_login_rl_trade_login)
    RelativeLayout mRlTradeLogin;
    @BindView(R2.id.es_fragment_login_rl_char_setting)
    RelativeLayout mCharSetting;
    @BindView(R2.id.es_fragment_login_rl_trade_setting)
    RelativeLayout mRlTradeSetting;
    @BindView(R2.id.es_fragment_login_rl_condition_order)
    RelativeLayout mRlConditionOrder;
    @BindView(R2.id.es_fragment_login_rl_stop_trade)
    RelativeLayout mRlStopTrade;
    @BindView(R2.id.es_fragment_login_rl_price_warn)
    RelativeLayout mRlPriceWarn;
    @BindView(R2.id.es_fragment_login_rl_stop_open)
    RelativeLayout mRlStopLossOpen;
    @BindView(R2.id.es_fragment_login_rl_about_trade)
    RelativeLayout mRlTradeAbout;
    @BindView(R2.id.es_fragment_login_rl_message)
    RelativeLayout mRlMessage;
    @BindView(R2.id.es_fragment_login_rl_estar)
    RelativeLayout mRlEstarLogin;
    @BindView(R2.id.es_fragment_login_rl_cloud)
    RelativeLayout mRlCloudService;
    @BindView(R2.id.es_fragment_login_rl_sdk)
    RelativeLayout mRlOpenAccount;
    @BindView(R2.id.es_fragment_login_rl_feedback)
    RelativeLayout mRlOFeedback;
    @BindView(R2.id.es_fragment_login_rl_setting)
    RelativeLayout mRlSetting;
    @BindView(R2.id.es_fragment_login_rl_about)
    RelativeLayout mRlAbout;
    @BindView(R2.id.es_fragment_login_rl_change_skin)
    RelativeLayout mRlChangeSkin;
    @BindView(R2.id.es_fragment_login_view_below_message_underline)
    View mUnderLineBelowMessage;
    @BindView(R2.id.es_view_loginDetail)
    View mUnderLine;
    @BindView(R2.id.es_login_has_login_num_txt)
    TextView mTvAccountNum;
    @BindView(R2.id.es_fragment_login_etv_condition_order)
    TextView mTvCondition;
    @BindView(R2.id.es_fragment_login_etv_stop_trade)
    TextView mTvStoplp;
    @BindView(R2.id.es_fragment_login_ll_container)
    LinearLayout mLlContainer;
    @BindView(R2.id.es_fragment_login_sv_container)
    ScrollView mSvContainer;
    @BindView(R2.id.es_fragment_login_rl_store)
    RelativeLayout mRlStore;

    @BindView(R2.id.es_fragment_login_btv_char_setting)
    EsBadgeTextView mQuoteSettingBTV;
    @BindView(R2.id.es_fragment_login_btv_trade_setting)
    EsBadgeTextView mTradeSettingBTV;
    @BindView(R2.id.es_fragment_login_btv_condition_order)
    EsBadgeTextView mConditionOrderBTV;
    @BindView(R2.id.es_fragment_login_btv_stop_trade)
    EsBadgeTextView mStopTradeBTV;
    @BindView(R2.id.es_fragment_login_btv_stop_open)
    EsBadgeTextView mStopOpenBTV;
    @BindView(R2.id.es_fragment_login_btv_price_warn)
    EsBadgeTextView mPriceWarnBTV;
    @BindView(R2.id.es_fragment_login_btv_about_trade)
    EsBadgeTextView mAboutTradeBTV;
    @BindView(R2.id.es_fragment_login_btv_message)
    EsBadgeTextView mMessageBTV;
    @BindView(R2.id.es_fragment_login_btv_quote_login)
    EsBadgeTextView mQuoteLoginBTV;
    @BindView(R2.id.es_fragment_login_btv_cloud_service)
    EsBadgeTextView mCloudServiceBTV;
    @BindView(R2.id.es_fragment_login_btv_open_account)
    EsBadgeTextView mOpenAccountBTV;
    @BindView(R2.id.es_fragment_login_btv_store)
    EsBadgeTextView mStoreBTV;
    @BindView(R2.id.es_fragment_login_btv_change_skin)
    EsBadgeTextView mChangeSkinBTV;
    @BindView(R2.id.es_fragment_login_btv_setting)
    EsBadgeTextView mSettingBTV;
    @BindView(R2.id.es_fragment_login_btv_about)
    EsBadgeTextView mAboutBTV;

    @Override
    protected int getLayoutId() {
        return R.layout.es_setting_fragment;
    }

    @Override
    protected SettingPresenterImpl createPresenter() {
        return new SettingPresenterImpl(mContext);
    }

    @Override
    protected void initWidget(View root) {
        super.initWidget(root);

        initBadgeView();

        mLlAccountNum.setVisibility(GONE);
        mLlAccountDetail.setVisibility(View.INVISIBLE);
        mTvLogin.setVisibility(VISIBLE);
        mTvNetWorkState.setVisibility(GONE);
        mRlTradeLogin.setVisibility(GONE);
        mRlConditionOrder.setVisibility(GONE);
        mRlStopTrade.setVisibility(GONE);
        mRlTradeAbout.setVisibility(GONE);
        mRlMessage.setVisibility(GONE);
        
        if (EsDataApi.isQuoteLogin()) {
            String url = EsDataApi.getFeedbackUrl();
            if(url == null || url.isEmpty()) {
                mRlOFeedback.setVisibility(GONE);
            }
            if (!EsDataApi.isMallLogin()) {
                mRlStore.setVisibility(GONE);
            }
        } else {
            mRlOFeedback.setVisibility(GONE);
            mRlPriceWarn.setVisibility(GONE);
            mRlStore.setVisibility(GONE);
        }

        mTvLogin.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        mTextViewDetail.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        mTvAccountNum.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
    }

    private void initBadgeView() {
        mQuoteSettingBTV.setKey(EsBadgeDataManger.NODE_KEY_QUOTE_SETTING);
        mTradeSettingBTV.setKey(EsBadgeDataManger.NODE_KEY_TRADE_SETTING);
        mConditionOrderBTV.setKey(EsBadgeDataManger.NODE_KEY_CONDITION_ORDER);
        mStopTradeBTV.setKey(EsBadgeDataManger.NODE_KEY_STOP_LOSS);
        mStopOpenBTV.setKey(EsBadgeDataManger.NODE_KEY_STOP_OPEN);
        mPriceWarnBTV.setKey(EsBadgeDataManger.NODE_KEY_PRICE_WARN);
        mAboutTradeBTV.setKey(EsBadgeDataManger.NODE_KEY_ABOUT_TRADE);
        mMessageBTV.setKey(EsBadgeDataManger.NODE_KEY_MESSAGE);
        mQuoteLoginBTV.setKey(EsBadgeDataManger.NODE_KEY_QUOTE_LOGIN);
        mCloudServiceBTV.setKey(EsBadgeDataManger.NODE_KEY_CLOUD_SERVICE);
        mOpenAccountBTV.setKey(EsBadgeDataManger.NODE_KEY_OPEN_ACCOUNT);
        mStoreBTV.setKey(EsBadgeDataManger.NODE_KEY_STORE);
        mChangeSkinBTV.setKey(EsBadgeDataManger.NODE_KEY_CHANGE_SKIN);
        mSettingBTV.setKey(EsBadgeDataManger.NODE_KEY_SETTING);
        mAboutBTV.setKey(EsBadgeDataManger.NODE_KEY_ABOUT);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage messageEvent) {
        if (messageEvent.getAction() == E_STAR_ACTION_NOTIFY_TRADE_STATE) {
            int tradeQuoteState = EsNetStateNotification.getInstance().getTradeQuoteState();
            if (EsNetStateNotification.getInstance().isAccountCanTrade(EsLoginAccountData.getInstance().getCurrentAccount())) {
                showTradeQuoteState(tradeQuoteState | EsNetStateNotification.C_TRADE_CONNECTED);
            } else {
                showTradeQuoteState(tradeQuoteState);
            }

            if (EsSPHelper.getIsConnectNet(mContext)) {
                mPresenter.queryStrategy();
            } else {
                mConditionOrderBTV.setNum(0);
                mStopOpenBTV.setNum(0);
            }
        } else if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_IS_VERSION_LOW) {
            mAboutBTV.setBadgeFlag(EsSPHelper.getIsVersionLower(mContext));
        } else if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_CONDITION_NUM) {
            if (messageEvent.getData() != null) {
                updateBadgeViewConditionNum((Integer) messageEvent.getData());
            }
        } else if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_STOPLP_NUM) {
            if (messageEvent.getData() != null) {
                updateBadgeViewStoplpNum((Integer) messageEvent.getData());
            }
        } else if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_STRATEGY_NUM) {
            mPresenter.queryStrategy();
        } else if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_LOGIN_INIT_COMPLETED) {
            mPresenter.queryStrategy();
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void MessageEvent(MessageEvent messageEvent) {
        if (messageEvent.getAction() == EsEventConstant.E_STAR_ACTION_RECEIVE_MESSAGE){
            if (mContext != null) {
                // mContext可能为空 有消息的时候去切换语言再进来
                mMessageBTV.setBadgeFlag(EsMessageData.getInstance().getUnReadMessageCount(mContext) > 0);
            }
        }
    }

    private void showTradeQuoteState(int state){
        switch (state){
            case 0:
            case 1:
            case 2://no quote trade
//                badgeDisdconnect.setVisibility(View.VISIBLE);
                mTvNetWorkState.setVisibility(VISIBLE);
                mTvNetWorkState.setText(getString(R.string.es_nethelper_trade_quote_disconnect));
                break;
            case 3://no trade
//                badgeDisdconnect.setVisibility(View.VISIBLE);
                mTvNetWorkState.setVisibility(VISIBLE);
                mTvNetWorkState.setText(getString(R.string.es_nethelper_trade_disconect));
                break;
            case 4:
            case 6://no quote
//                badgeDisdconnect.setVisibility(View.VISIBLE);
                mTvNetWorkState.setVisibility(VISIBLE);
                mTvNetWorkState.setText(getString(R.string.es_nethelper_quote_disconnect));
                break;
            case 5://no hisquote
//                badgeDisdconnect.setVisibility(View.VISIBLE);
                mTvNetWorkState.setVisibility(VISIBLE);
                mTvNetWorkState.setText(getString(R.string.es_nethelper_hisquote_disconnect));
                break;
            default://gone
//                badgeDisdconnect.setVisibility(View.GONE);
                mTvNetWorkState.setVisibility(GONE);
                break;
        }
        if (mPresenter != null) {
            mPresenter.refreshAccountDataDetail();
        }
    }

    @OnClick(R2.id.es_fragment_login_rl_change_skin)
    public void changeSkin() {
        mPresenter.changeSkin(mContext);
    }

    @OnClick(R2.id.es_fragment_login_tv_login)
    public void jumpLoginPage() {
        if (! ButtonUtils.isFastDoubleClick(mTvLogin.getId())) {
            mPresenter.login();
        }
    }

    @OnClick(R2.id.es_fragment_login_rl_trade_login)
    public void LoginMultiAccount() {
        mPresenter.login();
    }

    @OnClick(R2.id.es_fragment_login_rl_char_setting)
    public void charSetting() {
        mPresenter.charSetting();
    }

    @OnClick(R2.id.es_fragment_login_rl_cloud)
    public void cloudService() {
        mCloudServiceBTV.removeBadge();
        startActivity(new Intent(getActivity(), EsCloudServiceActivity.class));
    }

    @OnClick({R2.id.es_fragment_login_rl_trade_setting, R2.id.es_fragment_login_rl_condition_order, R2.id.es_fragment_login_rl_stop_trade,
            R2.id.es_fragment_login_rl_about_trade, R2.id.es_fragment_login_rl_message, R2.id.es_fragment_login_rl_estar, R2.id.es_fragment_login_rl_store,
            R2.id.es_fragment_login_rl_sdk, R2.id.es_fragment_login_rl_feedback, R2.id.es_fragment_login_rl_setting, R2.id.es_fragment_login_rl_about, R2.id.es_textView_loginDetail,
            R2.id.es_login_rl_header, R2.id.es_fragment_login_rl_account_num, R2.id.es_fragment_login_rl_price_warn, R2.id.es_fragment_login_rl_stop_open})
    public void onViewClicked(View view) {
        int i = view.getId();
        if (i == R.id.es_fragment_login_rl_trade_setting) {
            mPresenter.tradeSetting();
        } else if (i == R.id.es_fragment_login_rl_condition_order) {
            mPresenter.cloundConditionOrder();
        } else if (i == R.id.es_fragment_login_rl_stop_trade) {
            mPresenter.stopLossAndStopProfit();
        } else if (i == R.id.es_fragment_login_rl_about_trade) {
            mPresenter.aboutTrade();
        } else if (i == R.id.es_fragment_login_rl_message) {
            mPresenter.message();
        } else if (i == R.id.es_fragment_login_rl_estar) {
            mPresenter.quoteLogin(getActivity());
        } else if (i == R.id.es_fragment_login_rl_sdk) {
            mPresenter.openAccount();
        } else if (i == R.id.es_fragment_login_rl_setting) {
            mPresenter.setting();
        } else if (i == R.id.es_fragment_login_rl_about) {
            mPresenter.about();
        } else if (i == R.id.es_textView_loginDetail){
            mPresenter.accountDetail();
        }else if (i == R.id.es_fragment_login_rl_account_num){
            mPresenter.selectAccount();
        } else if (i == R.id.es_fragment_login_rl_feedback) {
            startActivity(new Intent(getActivity(), EsFeedbackActivity.class));
        } else if (i == R.id.es_fragment_login_rl_price_warn) {
            decideJumpPrice();
        } else if (i == R.id.es_fragment_login_rl_stop_open) {
            mPresenter.turnToStopLossOpen();
        } else if (i == R.id.es_fragment_login_rl_store) {
            goToStore();
        }
    }

    private void goToStore() {
        Intent intent = new Intent(getActivity(), EsStarStoreActivity.class);
        startActivity(intent);
    }

    @OnClick(R2.id.es_fragment_login_ll_container)
    public void container() {

    }

    @OnClick(R2.id.es_fragment_login_sv_container)
    public void svContainer() {

    }

    private void decideJumpPrice() {
        QuoteLoginInfo loginInfo = EsDataApi.quoteLoginInfo();
        if (loginInfo == null || loginInfo.getErrorCode() != 0 || loginInfo.getLoginNo().isEmpty()) {
            EsUIApi.startStarLoginActivity(getActivity());
        } else {
            mPresenter.priceWarn();
        }
    }

    @Override
    public void showIsConnectUI(boolean isConnect) {
        if (isConnect){
            mTvNetWorkState.setVisibility(GONE);
        }else {
            mTvNetWorkState.setVisibility(VISIBLE);
        }
    }

    @Override
    public void showMoneyDetail() {
        mLlAccountNum.setVisibility(GONE);
        mLlAccountDetail.setVisibility(VISIBLE);
        mTvLogin.setVisibility(GONE);
        mTvNetWorkState.setVisibility(GONE);
    }

    @Override
    public void showAccountCount() {
        mLlAccountNum.setVisibility(VISIBLE);
        mLlAccountDetail.setVisibility(View.INVISIBLE);
        mTvLogin.setVisibility(GONE);
        mTvNetWorkState.setVisibility(GONE);
    }

    @Override
    public void showLoginUI() {
        mLlAccountNum.setVisibility(GONE);
        mLlAccountDetail.setVisibility(View.INVISIBLE);
        mTvLogin.setVisibility(VISIBLE);
        mTvNetWorkState.setVisibility(GONE);
    }

    @Override
    public void refreshTitleByAccountCount(int accountCount, String user) {
        if (accountCount == 0){
            mLlAccountDetail.setVisibility(View.INVISIBLE);
            mLlAccountNum.setVisibility(GONE);

            updateLoginUI(false);
        }else if (accountCount == 1){
            mLlAccountDetail.setVisibility(VISIBLE);
            mLlAccountNum.setVisibility(GONE);
            updateLoginUI(true);

            mTextViewDetail.setText(user);
        }else {
            mLlAccountDetail.setVisibility(View.INVISIBLE);
            mLlAccountNum.setVisibility(VISIBLE);
            updateLoginUI(true);

            mTvAccountNum.setText(user);
        }
    }

    @Override
    public void updateBadgeViewByMessage(boolean isHadUnreadMessage) {
        mMessageBTV.setBadgeFlag(isHadUnreadMessage);
    }

    @Override
    public void updateBadgeViewNum(int condition, int stoplp) {
        updateBadgeViewConditionNum(condition);
        updateBadgeViewStoplpNum(stoplp);
    }

    private void updateBadgeViewConditionNum(int condition) {
        mConditionOrderBTV.setNum(condition);
    }

    private void updateBadgeViewStoplpNum(int stoplp) {
        mStopOpenBTV.setNum(stoplp);
    }

    private void updateLoginUI(boolean isLogin){
        if (EsDataApi.isContainTrade()){
            mRlTradeLogin.setVisibility(isLogin && EsDataApi.isTradeMutLogin() ? VISIBLE : GONE);
            mRlConditionOrder.setVisibility(isLogin ? VISIBLE : GONE);
            mRlStopTrade.setVisibility(isLogin ? VISIBLE : GONE);
            mRlTradeAbout.setVisibility(isLogin ? VISIBLE : GONE);
            mRlMessage.setVisibility(isLogin ? VISIBLE : GONE);
            mTvLogin.setVisibility(isLogin ? GONE : VISIBLE);
            mUnderLine.setVisibility(isLogin ? VISIBLE : GONE);
            mMessageBTV.setBadgeFlag(EsMessageData.getInstance().getUnReadMessageCount(mContext) > 0 );
            mAboutBTV.setBadgeFlag(EsSPHelper.getIsVersionLower(mContext));
            if (EsDataApi.getOpenCompany().size() == 0) {
                mRlOpenAccount.setVisibility(GONE);
            }
            if (isLogin) {
                mPresenter.queryStrategy();
            }

            if (isLogin) {
                EsLoginAccountData.LoginAccount currentAccount = EsLoginAccountData.getInstance().getCurrentAccount();
                if (currentAccount != null && !EsDataApi.isDipperTradeStar(currentAccount)) {
                    mRlStopLossOpen.setVisibility(VISIBLE);
                } else {
                    mRlStopLossOpen.setVisibility(GONE);
                }
            } else {
                mRlStopLossOpen.setVisibility(GONE);
            }
        }else {
            mTvLogin.setVisibility(GONE);                                          //交易登陆
            mRlTradeSetting.setVisibility(GONE);                                   //交易设置
            mRlAbout.setVisibility(GONE);                                          //关于
            mRlSetting.setVisibility(GONE);                                        //设置
            mRlOpenAccount.setVisibility(GONE);                                   //在线开户
            mUnderLine.setVisibility(GONE);                                        //分割线1
            mRlStopLossOpen.setVisibility(GONE);                                   // 止损开仓
        }

        if (EsDataApi.isQuoteLogin()) {
            mRlPriceWarn.setVisibility(VISIBLE);
            String url = EsDataApi.getFeedbackUrl();
            if(url != null && !url.isEmpty()) {
                mRlOFeedback.setVisibility(VISIBLE);
            } else {
                mRlOFeedback.setVisibility(GONE);
            }

            if (EsDataApi.isMallLogin()) {
                mRlStore.setVisibility(VISIBLE);
            } else {
                mRlStore.setVisibility(GONE);
            }
            mRlEstarLogin.setVisibility(GONE);
            mRlCloudService.setVisibility(VISIBLE);
        } else {
            mRlOFeedback.setVisibility(GONE);
            mRlPriceWarn.setVisibility(GONE);
            mRlStore.setVisibility(GONE);

            mRlEstarLogin.setVisibility(VISIBLE);
            mRlCloudService.setVisibility(GONE);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mPresenter.register();

        mPresenter.queryMessage();
        mPresenter.queryStrategy();
        //显示网络状态
//        showTradeQuoteState(EsNetStateNotification.getInstance().getTradeQuoteState());
        int tradeQuoteState = EsNetStateNotification.getInstance().getTradeQuoteState();
        if (EsNetStateNotification.getInstance().isAccountCanTrade(EsLoginAccountData.getInstance().getCurrentAccount())) {
            showTradeQuoteState(tradeQuoteState | EsNetStateNotification.C_TRADE_CONNECTED);
        } else {
            showTradeQuoteState(tradeQuoteState);
        }
        //mPresenter.refreshAccountDataDetail();
    }

    @Override
    public void onPause() {
        super.onPause();
        mPresenter.unRegister();
    }
}
