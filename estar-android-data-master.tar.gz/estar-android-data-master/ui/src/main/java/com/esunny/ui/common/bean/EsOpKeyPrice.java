package com.esunny.ui.common.bean;

import java.math.BigDecimal;
import java.util.ArrayList;

public class EsOpKeyPrice {

    private int mZeroCount = 0;
    private ArrayList<BigDecimal> mZeroPrices = new ArrayList<>(16);      //关键价位
    private ArrayList<Float>    mZeroPosition = new ArrayList<>(16);    //每个价格对应的横坐标位置

    public void addZeroPrice(BigDecimal zeroPrice){
        mZeroPrices.add(zeroPrice);
    }

    public void clearZeroPrice(){
        mZeroPrices.clear();
        mZeroCount = 0;
    }

    public void addZeroPosition(float xPos){
        mZeroPosition.add(xPos);
    }

    public void clearZeroPosition(){
        mZeroPosition.clear();
    }

    public void addZeroCount(){
        mZeroCount++;
    }

    public ArrayList<BigDecimal> getZeroPrices() {
        return mZeroPrices;
    }

    public void setZeroPrices(ArrayList<BigDecimal> zeroPrices) {
        mZeroPrices = zeroPrices;
    }

    public ArrayList<Float> getZeroPosition() {
        return mZeroPosition;
    }

    public void setZeroPosition(ArrayList<Float> zeroPosition) {
        mZeroPosition = zeroPosition;
    }

    public int getZeroCount() {
        return mZeroCount;
    }

    public void setZeroCount(int zeroCount) {
        mZeroCount = zeroCount;
    }
}
