package com.esunny.ui.common.setting.condition.EsStrategyView;

import android.content.Context;
import androidx.annotation.ColorInt;
import androidx.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.bean.Contract;
import com.esunny.ui.R;
import com.esunny.ui.common.setting.condition.EsStrategyData.EsStrategyData;
import com.esunny.ui.util.EsQuoteUtil;
import com.esunny.ui.view.EsFixTextView;

import java.math.BigInteger;


public class EsStrategyPanel extends LinearLayout {
    @ColorInt
    private int mColorPrice;
    private Context mContext;
    private EsFixTextView mLastP, mBidP, mAskP;
    private TextView mTotalQty, mBidQty, mAskQty;

    public EsStrategyPanel(Context context) {
        super(context);
        initWidget(context);
    }

    public EsStrategyPanel(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initWidget(context);
    }

    public EsStrategyPanel(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initWidget(context);
    }

    private void initWidget(Context context) {
        mContext = context;
        LayoutInflater.from(context).inflate(R.layout.es_linearlayout_es_strategy_panel, this);
        mLastP = findViewById(R.id.trade_strategy_simple_panel_lastP);
        mBidP = findViewById(R.id.trade_strategy_simple_panel_bidP);
        mAskP = findViewById(R.id.trade_strategy_simple_panel_askP);
        mTotalQty = findViewById(R.id.trade_strategy_simple_panel_totalQ);
        mBidQty = findViewById(R.id.trade_strategy_simple_panel_bidQ);
        mAskQty = findViewById(R.id.trade_strategy_simple_panel_askQ);

    }

    public void setDataOnView(double bidPrice, double askPrice, double lastPrice, BigInteger bidQty, BigInteger askQty, BigInteger totalQty, double preSettlePrice) {

        Contract contract = EsStrategyData.getInstance().getSelectedContract();

        mBidP.setText(EsDataApi.formatPrice(contract.getCommodity(), bidPrice));
        mBidQty.setText(EsQuoteUtil.dealLargeQty(mContext, bidQty));
        mAskP.setText(EsDataApi.formatPrice(contract.getCommodity(), askPrice));
        mAskQty.setText(EsQuoteUtil.dealLargeQty(mContext, askQty));
        mLastP.setText(EsDataApi.formatPrice(contract.getCommodity(), lastPrice));
        mTotalQty.setText(EsQuoteUtil.dealLargeQty(mContext, totalQty));

        setPriceColors(lastPrice, preSettlePrice);
    }

    public void setPriceColors(double lastPrice, double preSettlePrice) {
        if (preSettlePrice > 0 && lastPrice > 0 && preSettlePrice < lastPrice) {
            mBidP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_bigger_preSettle);
            mLastP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_bigger_preSettle);
            mAskP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_bigger_preSettle);
        } else if (preSettlePrice > 0 && lastPrice > 0 && lastPrice < preSettlePrice) {
            mBidP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_smaller_preSettle);
            mLastP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_smaller_preSettle);
            mAskP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_smaller_preSettle);
        } else {
            mBidP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_equal_preSettle);
            mLastP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_equal_preSettle);
            mAskP.setTextAppearance(mContext, R.style.es_strategy_panel_price_last_equal_preSettle);
        }
    }

    public void setImpPriceQty(boolean isBidPriceImp, boolean isAskPriceImp, boolean isBidQtyImp, boolean isAskQtyImp) {
        if (isBidPriceImp) {
            String text = "*" + mBidP.getText();
            mBidP.setText(text);
        }
        if (isAskPriceImp) {
            String text = "*" + mAskP.getText();
            mAskP.setText(text);
        }
        if (isBidQtyImp) {
            String text = "*" + mBidQty.getText();
            mBidQty.setText(text);
        }
        if (isAskQtyImp) {
            String text = "*" + mAskQty.getText();
            mAskQty.setText(text);
        }
    }
}
