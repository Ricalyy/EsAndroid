package com.esunny.ui.common.setting.trade;

import android.view.View;
import android.widget.RelativeLayout;

import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsIconTextView;

public class EsCoverAllSettingActivity extends EsBaseActivity implements View.OnClickListener{
    EsBaseToolBar mToolBar;
    RelativeLayout mRlCoverFuture;
    RelativeLayout mRlCoverOption;
    EsIconTextView mTvCheckFuture;
    EsIconTextView mTvCheckOption;

    private boolean mIsCoverFuture;
    private boolean mIsCoverOption;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_cover_all_setting;
    }

    @Override
    protected void initData() {
        super.initData();
        mIsCoverFuture = EsSPHelperProxy.getIsCoverAllFuture(this);
        mIsCoverOption = EsSPHelperProxy.getIsCoverAllOption(this);
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        initView();
        initViewValue();
        bindOnClick();
    }

    private void initView() {
        mToolBar = findViewById(R.id.es_activity_trade_setting_cover_all_toolbar);
        mRlCoverFuture = findViewById(R.id.es_cover_all_setting_rl_future);
        mRlCoverOption = findViewById(R.id.es_cover_all_setting_rl_option);
        mTvCheckFuture = findViewById(R.id.es_item_choose_cover_future_tv_check);
        mTvCheckOption = findViewById(R.id.es_item_choose_cover_option_tv_check);
    }

    private void initViewValue() {
        mToolBar.setSimpleBack(this.getString(R.string.es_activity_cover_all_setting));
        if (!mIsCoverFuture) {
            mTvCheckFuture.setVisibility(View.GONE);
        }

        if (!mIsCoverOption) {
            mTvCheckOption.setVisibility(View.GONE);
        }
    }

    private void bindOnClick() {
        mRlCoverFuture.setOnClickListener(this);
        mRlCoverOption.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == mRlCoverFuture.getId()) {
            dealClickRlFuture();
        } else {
            dealClickRlOption();
        }
    }

    private void dealClickRlFuture() {
        if (!mIsCoverOption && mIsCoverFuture) {
            ToastHelper.show(this, R.string.es_activity_cover_all_setting_no_choose);
            return;
        }

        mIsCoverFuture = mIsCoverFuture ? false :  true;
        EsSPHelperProxy.setIsCoverAllFuture(this, mIsCoverFuture);
        mTvCheckFuture.setVisibility(mIsCoverFuture ? View.VISIBLE : View.GONE);
    }

    private void dealClickRlOption() {
        if (!mIsCoverFuture && mIsCoverOption) {
            ToastHelper.show(this, R.string.es_activity_cover_all_setting_no_choose);
            return;
        }

        mIsCoverOption = mIsCoverOption ? false : true;
        EsSPHelperProxy.setIsCoverAllOption(this, mIsCoverOption);
        mTvCheckOption.setVisibility(mIsCoverOption ? View.VISIBLE : View.GONE);
    }
}
