package com.esunny.ui.common.bean;

public class EsOpTacticType {

    //策略类型
    public static final int TACTIC_TYPE_SINGLE = 0;            //单式组合策略
    public static final int TACTIC_TYPE_COMBINE = 1;           //复试组合策略
    public static final int TACTIC_TYPE_FREE = 2;              //自由组合策略

    //策略ID
    public static final int TACTIC_ID_NONE = -1;
    public static final int TACTIC_ID_BUY_CALL = 0;            //大涨--买入看涨
    public static final int TACTIC_ID_SELL_PUT = 1;            //不跌--卖出看跌
    public static final int TACTIC_ID_BULL_CALL_SPREAD = 2;    //盘涨Call(牛市看涨期权垂直价差)--买入低行权价的看涨期权和卖出高行权价的看涨期权
    public static final int TACTIC_ID_BULL_PUT_SPREAD = 3;     //盘涨Put(牛市看跌期权垂直价差)--买入低行权价的看跌期权和卖出高行权价的看跌期权
    public static final int TACTIC_ID_BUY_PUT = 4;             //大跌--买入看跌
    public static final int TACTIC_ID_SELL_CALL = 5;           //不涨--卖出看涨
    public static final int TACTIC_ID_BEAR_CALL_SPREAD = 6;    //盘跌Call（熊市看涨期权垂直价差）--买入高行权价的看涨期权和卖出低行权价的看涨期权
    public static final int TACTIC_ID_BEAR_PUT_SPREAD = 7;     //盘跌Put（熊市看跌期权垂直价差）--买入高行权价的看跌期权和卖出低行权价的看跌期权
    public static final int TACTIC_ID_SELL_STRADDLE = 8;       //原点盘整--卖出跨式--同时卖出行权价相同的看涨和看跌期权
    public static final int TACTIC_ID_SELL_STRANGLE = 9;       //区间盘整--卖出宽跨式--同时卖出高行权价格看涨期权和低行权价的看跌期权
    public static final int TACTIC_ID_BUY_STRADDLE = 10;       //原点突破--买入跨式--同时买入行权价相同的看涨和看跌期权
    public static final int TACTIC_ID_BUY_STRANGLE = 11;       //区间突破--买入宽跨式--同时买入高行权价看涨期权和低行权价的看跌期权
    public static final int TACTIC_ID_FREE_STYLE = 12;         //自由组合

    //操作类型
    public static final int TACTIC_OPERATE_NONE = 0;
    public static final int TACTIC_OPERATE_BUY_FUTURE = 1;     //买入期货
    public static final int TACTIC_OPERATE_SELL_FUTURE = 2;    //卖出期货
    public static final int TACTIC_OPERATE_BUY_CALL = 3;       //买入看涨期权    成本：权利金  收益：标的价格-行权价格+权利金
    public static final int TACTIC_OPERATE_SELL_CALL = 4;      //卖出看涨期权    成本：标的价格-行权价格+权利金    收益：权利金
    public static final int TACTIC_OPERATE_BUY_PUT = 5;        //买入看跌期权    成本：权利金  收益：标的价格-行权价格+权利金
    public static final int TACTIC_OPERATE_SELL_PUT = 6;       //卖出看跌期权    成本：标的价格-行权价格+权利金    收益：权利金

    //条件
    public static final int TACTIC_CONDITION_NONE = 0;
    public static final int TACTIC_CONDITION_LESS = 1;         //第一个行权价 < 第二个行权价
    public static final int TACTIC_CONDITION_EQUAL = 2;        //第一个行权价 = 第二个行权价
    public static final int TACTIC_CONDITION_LARGE = 3;        //第一个行权价 > 第二个行权价

    //获利损失类型
    public static final int TACTIC_PROFIT_LOSS_TYPE_PUNLIMIT = 0;       //获利无限
    public static final int TACTIC_PROFIT_LOSS_TYPE_LUNLIMIT = 1;       //损失无限
    public static final int TACTIC_PROFIT_LOSS_TYPE_PLLIMIT = 2;        //获利和损失都有限
    public static final int TACTIC_PROFIT_LOSS_TYPE_PLUNLIMIT = 3;      //获利和损失都无限

}
