package com.esunny.ui.common.bean;

public class EsOpenCount {
    private long buyCount;
    private long sellCount;

    public void setBuyCount(long buyCount) {
        this.buyCount = buyCount;
    }

    public long getBuyCount() {
        return buyCount;
    }

    public void setSellCount(long sellCount) {
        this.sellCount = sellCount;
    }

    public long getSellCount() {
        return sellCount;
    }
}
