package com.esunny.ui.common.setting;

import android.content.Context;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.MoneyField;
import com.esunny.ui.data.setting.EsMessageData;
import com.esunny.ui.data.setting.EsLoginAccountData;

import java.util.List;

public class SettingModelImpl implements SettingCombination.Model{
    private EsLoginAccountData.LoginAccount mLastUserInfo = null;

    @Override
    public String getAccountMoneyDetail() {
        String benefit;
        EsLoginAccountData loginAccountData = getLoginAccountData();
        if (loginAccountData == null){
            return "";
        }

        MoneyField[] sMoneyFields = getMoneyFieldFromAccount(loginAccountData.getCurrentAccount());
        if (sMoneyFields != null && sMoneyFields.length > 50) {
            benefit = String.valueOf(new java.text.DecimalFormat("#0.00").format(sMoneyFields[EsDataConstant.S_EQUITY].getValue()));
        }else {
            benefit = "---";
        }
        return benefit;
    }

    @Override
    public MoneyField[] getMoneyFieldFromAccount(EsLoginAccountData.LoginAccount account) {
        int mCurrencyDefaultChooseIndex = 0;

        List<MoneyData> mMoneyData = EsDataApi.getMoneyData(account.getCompanyNo(), account.getUserNo(), account.getAddrTypeNo());

        String groupNo = account.getCurrencyGroupNo();
        String currentNo = account.getCurrencyNo();
        for (int i = 0;  i < mMoneyData.size(); i++){
            if (mMoneyData.get(i) == null)
                continue;
            if(mMoneyData.get(i).getCurrencyGroupNo().equals(groupNo) && mMoneyData.get(i).getCurrencyNo().equals(currentNo)){
                mCurrencyDefaultChooseIndex = i;
                break;
            }
        }

        if (mMoneyData.size() > 0) {
            MoneyData moneyData = mMoneyData.get(mCurrencyDefaultChooseIndex);
            if(moneyData != null)
                return moneyData.getDataEx();
            else
                return null;
        }else {
            return null;
        }
    }

    @Override
    public EsLoginAccountData getLoginAccountData() {
        return EsLoginAccountData.getInstance();
    }

    @Override
    public void setLastUserInfo(EsLoginAccountData.LoginAccount account) {
        this.mLastUserInfo = account;
    }

    @Override
    public boolean isSameUser() {
        EsLoginAccountData.LoginAccount loginAccount = getLoginAccountData().getCurrentAccount();
        if (loginAccount != null){
            return loginAccount == mLastUserInfo;
        }else {
            return false;
        }
    }

    @Override
    public boolean isHasUnreadMessage(Context context) {
        return EsMessageData.getInstance().getUnReadMessageCount(context) > 0;
    }
}
