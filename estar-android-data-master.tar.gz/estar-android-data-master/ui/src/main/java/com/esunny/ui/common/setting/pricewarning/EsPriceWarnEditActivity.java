package com.esunny.ui.common.setting.pricewarning;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.EsEventMessage;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.MonitorOrderInsert;
import com.esunny.data.bean.QuoteBetData;
import com.esunny.data.util.EsLog;
import com.esunny.ui.R;
import com.esunny.ui.api.EsEventConstant;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.quote.EsFavoriteListData;
import com.esunny.ui.dialog.EsCustomDialog;
import com.esunny.ui.dialog.EsMultiSelectKeyboardDialog;
import com.esunny.ui.trade.view.EsTradePriceKeyboard;
import com.esunny.ui.trade.view.EsTradePriceKeyboardView;
import com.esunny.ui.util.EsInsertOrderHelper;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsCustomRelativeLayout;
import com.esunny.ui.view.EsIconTextView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public class EsPriceWarnEditActivity extends EsBaseActivity
        implements View.OnTouchListener, EsMultiSelectKeyboardDialog.OnEsMultiSelectKeyboardDialogListener {

    private static final String TAG = "EsPriceWarnEditActivity";

    private EsBaseToolBar mBaseToolBar;
    private TextView mConfirm, mContractName;
    private EsCustomRelativeLayout mRlContract, mRlPriceHigh, mRlPriceLow, mRlIncreaseUp, mRlIncreaseDown;
    private TextView mEtPriceHigh, mEtPriceLow, mEtIncreaseUp, mEtIncreaseDown;
    private EsIconTextView mDelPriceHigh, mDelPriceLow, mDelIncreaseUp, mDelIncreaseDown;
    private LinearLayout mLlAll;
    private Contract mSelectContract, mReturnContract;
    private EsMultiSelectKeyboardDialog mDialogKeyboardContract;
    private final static String KEY_SEARCH_SOURCE = "EsPriceWarn";
    private boolean mConnect = false;// 连接失败
    private EsTradePriceKeyboard mPriceKeyboard;
    private double mLastPrice = 0;
    private String mReturnPrice = "";
    private String mRangeStr = "0";
    private EsCustomRelativeLayout mOldRl;

    @Override
    protected void initData() {
        super.initData();
        Intent intent = getIntent();
        int num = intent.getIntExtra("connectNum", 1);
        if (num == EsDataConstant.PRICE_SERVER_CONNECT_SUCCESS) {
            mConnect = true;
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        initView();
        initViewValue();
        bindOnClick();
        bindOnFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        if (mSelectContract != null) {
            EsDataApi.unSubQuote(mSelectContract.getContractNo());
        }
    }

    private void initView() {
        mLlAll = findViewById(R.id.es_activity_price_warn_AllRl);

        mBaseToolBar = findViewById(R.id.es_activity_price_warn_edit_toolbar);

        mConfirm = findViewById(R.id.es_activity_price_warn_edit_confirm);
        mContractName = findViewById(R.id.es_activity_price_warn_edit_text_contract);

        mRlContract = findViewById(R.id.es_activity_price_warn_edit_contract);
        mRlPriceHigh = findViewById(R.id.es_activity_price_warn_edit_price_highest);
        mRlPriceLow = findViewById(R.id.es_activity_price_warn_edit_price_lowest);
        mRlIncreaseUp = findViewById(R.id.es_activity_price_warn_edit_price_increase_up);
        mRlIncreaseDown = findViewById(R.id.es_activity_price_warn_edit_price_increase_down);

        mEtPriceHigh = findViewById(R.id.es_activity_price_warn_edit_price_highest_edit);
        mEtPriceLow = findViewById(R.id.es_activity_price_warn_edit_price_lowest_edit);
        mEtIncreaseUp = findViewById(R.id.es_activity_price_warn_edit_price_increase_up_edit);
        mEtIncreaseDown = findViewById(R.id.es_activity_price_warn_edit_price_increase_down_edit);

        mDelPriceHigh = findViewById(R.id.es_activity_price_warn_edit_price_highest_cancel_tv);
        mDelPriceLow = findViewById(R.id.es_activity_price_warn_edit_price_lowest_cancel_tv);
        mDelIncreaseUp = findViewById(R.id.es_activity_price_warn_edit_price_increase_up_cancel_tv);
        mDelIncreaseDown = findViewById(R.id.es_activity_price_warn_edit_price_increase_down_cancel_tv);

        mPriceKeyboard = new EsTradePriceKeyboard(EsPriceWarnEditActivity.this, mEtPriceHigh);
        mPriceKeyboard.setOutsideTouchable(true);
        mPriceKeyboard.setIsOptionCombination(true);
        mPriceKeyboard.EnablePriceWarn(true);
        mPriceKeyboard.enableGTC(false);
        mPriceKeyboard.setListener(new EsTradePriceKeyboardView.TradePriceKeyboardListener() {
            @Override
            public void customOnPriceKeyDown(EsTradePriceKeyboardView keyboardView, int keyId, boolean isSpecial) {

            }

            @Override
            public Contract onGetContract(EsTradePriceKeyboardView keyboardView) {
                return mReturnContract;
            }

            @Override
            public double onGetLastPrice(EsTradePriceKeyboardView keyboardView) {
                if (mSelectContract == null) {
                    return 0;
                }

                double price;
                int deno = mSelectContract.getCommodity().getPriceDeno();
                if (deno > 1 && mReturnPrice != null && mReturnPrice.length() > 0
                        && Character.isDigit(mReturnPrice.charAt(0)) && !mReturnPrice.contains(".")) {
                    String num = mReturnPrice;
                    if (mReturnPrice.contains("/")) {
                        num = mReturnPrice.split("/")[0];
                    }

                    String integerStr;
                    String numeratorStr;

                    if (num.contains("+")) {
                        integerStr = num.split("\\+")[0];
                        numeratorStr = num.split("\\+")[1];
                    } else {
                        integerStr = "0";
                        numeratorStr = num;
                    }

                    try {
                        price = Double.parseDouble(integerStr) + Double.parseDouble(numeratorStr) / deno;
                    } catch (NumberFormatException | NullPointerException e) {
                        price = 0;
                    }
                } else {
                    try {
                        price = Double.parseDouble(mReturnPrice);
                    } catch (NumberFormatException | NullPointerException e) {
                        price = 0;
                    }
                }

                return price;
            }

            @Override
            public void onChangeValidType(EsTradePriceKeyboardView keyboardView, char ValidType) {

            }
        });
    }

    private void initViewValue() {
        mBaseToolBar.setTitle(getString(R.string.es_setting_fragment_price_warn));
        mBaseToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
        mOldRl = mRlContract;
    }

    private void bindOnFocus() {
        mEtPriceHigh.setOnFocusChangeListener(mRlPriceHigh);
        mEtPriceLow.setOnFocusChangeListener(mRlPriceLow);
        mEtIncreaseUp.setOnFocusChangeListener(mRlIncreaseUp);
        mEtIncreaseDown.setOnFocusChangeListener(mRlIncreaseDown);
        mContractName.setOnFocusChangeListener(mRlContract);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void bindOnClick() {

        mConfirm.setOnTouchListener(this);
        mContractName.setOnTouchListener(this);

        mEtPriceHigh.setOnTouchListener(this);
        mEtPriceLow.setOnTouchListener(this);
        mEtIncreaseUp.setOnTouchListener(this);
        mEtIncreaseDown.setOnTouchListener(this);

        mDelPriceHigh.setOnTouchListener(this);
        mDelPriceLow.setOnTouchListener(this);
        mDelIncreaseUp.setOnTouchListener(this);
        mDelIncreaseDown.setOnTouchListener(this);

        mBaseToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_left_first) {
                    finish();
                }
            }
        });
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_price_warn_edit;
    }

    private void selectContract() {

        ArrayList<String> favouriteContract = new ArrayList<>();
        for (Contract contract : EsFavoriteListData.getInstance().getFavoriteContractArrayList()) {
            if (contract == null) {
                continue;
            }
            if (contract.isArbitrageContract()) {
                Contract tContract = EsDataApi.getTradeContract(contract.getContractNo());
                if (tContract != null) {
                    favouriteContract.add(tContract.getContractName());
                    continue;
                }
            }

            favouriteContract.add(contract.getContractName());
        }

        mDialogKeyboardContract = new EsMultiSelectKeyboardDialog(EsPriceWarnEditActivity.this, favouriteContract);
        mDialogKeyboardContract.setListener(this);
        mDialogKeyboardContract.show();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (v.getId() == mConfirm.getId()) {
                insertMonitor();
            } else if (v.getId() == mContractName.getId()) {
                selectContract();
                showOnFocus(mRlContract);
            } else if (v.getId() == mEtPriceHigh.getId()) {
                refreshQuote();
                showOnFocus(mRlPriceHigh);
                showPriceKeyboard(mEtPriceHigh, 1);
            } else if (v.getId() == mEtPriceLow.getId()) {
                refreshQuote();
                showOnFocus(mRlPriceLow);
                showPriceKeyboard(mEtPriceLow, 1);
            } else if (v.getId() == mEtIncreaseUp.getId()) {
                refreshQuote();
                showOnFocus(mRlIncreaseUp);
                showPriceKeyboard(mEtIncreaseUp, 2);
            } else if (v.getId() == mEtIncreaseDown.getId()) {
                refreshQuote();
                showOnFocus(mRlIncreaseDown);
                showPriceKeyboard(mEtIncreaseDown, 2);
            } else if (v.getId() == mDelPriceHigh.getId()) {
                mEtPriceHigh.setText("");
            } else if (v.getId() == mDelPriceLow.getId()) {
                mEtPriceLow.setText("");
            } else if (v.getId() == mDelIncreaseUp.getId()) {
                mEtIncreaseUp.setText("");
            } else if (v.getId() == mDelIncreaseDown.getId()) {
                mEtIncreaseDown.setText("");
            }
        }
        return false;
    }

    private void showOnFocus(EsCustomRelativeLayout focusView) {
        mOldRl.setBorderColor(false);
        focusView.setBorderColor(true);
        mOldRl = focusView;
    }

    private void showPriceKeyboard(TextView edit, int showType) {
        mPriceKeyboard.setEdit(edit);
        if (showType == 1) {
            mReturnContract = mSelectContract;
            mPriceKeyboard.setReturnRange(false);
        } else {
            mPriceKeyboard.setReturnRange(true);
            mReturnPrice = mRangeStr;
            if (mSelectContract != null && mSelectContract.getCommodity().getPriceDeno() > 1) {
                mReturnContract = null;
            }
        }
        edit.setText(mReturnPrice);
        mPriceKeyboard.showAtLocation(mLlAll.getRootView(), Gravity.BOTTOM, 0, 0);
        mPriceKeyboard.setReInput(true);
    }

    private void insertMonitor() {
        if (mConnect) {
            if (mSelectContract == null) {
                ToastHelper.show(this, R.string.es_activity_price_warn_edit_insert_no_contract);
            } else {
                if (mSelectContract.isArbitrageContract()) {
                    ToastHelper.show(EsPriceWarnEditActivity.this, R.string.es_price_warn_insert_is_arbitrage_contract);
                } else {
                    String priceHighest =  mEtPriceHigh.getText().toString();
                    String priceLowest = mEtPriceLow.getText().toString();
                    String increaseUp = mEtIncreaseUp.getText().toString();
                    String increaseDown = mEtIncreaseDown.getText().toString();
                    if (EsInsertOrderHelper.checkInPut(this, mSelectContract, mLastPrice, mRangeStr, priceHighest, priceLowest, increaseUp, increaseDown)) {
                        final MonitorOrderInsert orderInsert = EsInsertOrderHelper.getPriceMonitorOrderInsert(mSelectContract, priceHighest, priceLowest, increaseUp, increaseDown);
                        String insertMessages = EsInsertOrderHelper.getPriceMonitorOrderMessage(this, orderInsert);
                        EsCustomDialog dialog = EsCustomDialog.create(this);
                        dialog.setTitle(this.getString(R.string.es_setting_fragment_price_warn))
                                .setContent(insertMessages)
                                .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                                    @Override
                                    public void onConfirm() {
                                        int ret = EsDataApi.insertMonitorOrder(orderInsert);
                                        if (ret >= 0) {
                                            finish();
                                        }
                                    }

                                    @Override
                                    public void onCancel() {
                                    }
                                }).show();
                    }
                }
            }
        } else {
            ToastHelper.show(EsPriceWarnEditActivity.this, R.string.es_kline_activity_price_warn_disconnect_server);
        }
    }

    @Override
    public void OnSelect(int index, EsMultiSelectKeyboardDialog dialog) {
        if (dialog == mDialogKeyboardContract) {
            if (index == -1) {
                EsUIApi.startSearchActivity(KEY_SEARCH_SOURCE);
                return;
            }
            setContract(index);

        }
    }

    @Override
    public void OnDismiss(EsMultiSelectKeyboardDialog dialog) {

    }

    private void setContract(int index) {
        Contract contract = EsFavoriteListData.getInstance().getFavoriteContractArrayList().get(index);
        setSelectContract(contract);
    }

    private void setSelectContract(Contract contract) {
        if (contract != null) {
            if (mSelectContract != null && !mSelectContract.getContractNo().equals(contract.getContractNo())) {
                EsDataApi.unSubQuote(mSelectContract.getContractNo());
            }
            EsDataApi.subQuote(contract.getContractNo());
            mReturnContract = mSelectContract = contract;
            mContractName.setText(mSelectContract.getContractName());
            refreshQuote();
        }
    }

    private void refreshQuote() {
        if (mSelectContract == null) {
            return;
        }
        QuoteBetData snap = new QuoteBetData(mSelectContract);
        mLastPrice = snap.getLastPrice();
        mReturnPrice = snap.getLastPriceString();

        try {
            mRangeStr = NumberFormat.getInstance().parse(snap.getPriceChangePercentageString()).toString();
        } catch (ParseException e) {
            mRangeStr = "0";
            EsLog.e(TAG, "refreshQuote", e);
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(EsEventMessage eventMessage) {
        int action = eventMessage.getAction();
        if (eventMessage.getSender() == EsEventConstant.E_STAR_MODULE_SEARCH) {
            if (action == EsEventConstant.E_STAR_ACTION_SELECT_OPTION) {
                try {
                    if (KEY_SEARCH_SOURCE.equals(eventMessage.getData())) {
                        Contract contract = EsDataApi.getQuoteContract(eventMessage.getContent());
                        setSelectContract(contract);
                        EsFavoriteListData.getInstance().addFavoriteContract(contract, false);
                    }
                } catch (ClassCastException e) {
                    EsLog.e(TAG, "Event", e);
                }
            }
        }
    }
}
