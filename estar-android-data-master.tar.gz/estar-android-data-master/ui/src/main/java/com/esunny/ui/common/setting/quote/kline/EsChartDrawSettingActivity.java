package com.esunny.ui.common.setting.quote.kline;

import android.widget.CompoundButton;
import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsCusSwitchButton;

import skin.support.content.res.SkinCompatResources;


public class EsChartDrawSettingActivity extends EsBaseActivity {

    EsBaseToolBar mToolbar;
    EsCusSwitchButton mSwitchPositionButton, mSwitchLastPriceButton, mSwitchDrawLineButton;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_chart_draw_setting;
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindViewValue();
        bindOnClick();
    }

    private void bindView() {
        mToolbar = findViewById(R.id.es_activity_price_calculate_toolbar);
        mSwitchPositionButton = findViewById(R.id.es_activity_chart_setting_position_cost_switch_button);
        mSwitchPositionButton.setChecked(EsSPHelper.getIsShowPositionCost(this));
        mSwitchPositionButton.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mSwitchPositionButton.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));

        mSwitchLastPriceButton = findViewById(R.id.es_activity_chart_setting_last_price_switch_button);
        mSwitchLastPriceButton.setChecked(EsSPHelper.getIsShowLastPrice(this));
        mSwitchLastPriceButton.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mSwitchLastPriceButton.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));

        mSwitchDrawLineButton = findViewById(R.id.es_activity_chart_setting_draw_line_switch_button);
        mSwitchDrawLineButton.setChecked(EsSPHelper.getIsShowDrawLine(this));
        mSwitchDrawLineButton.setThumbDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_thumb_drawable));
        mSwitchDrawLineButton.setBackDrawableRes(SkinCompatResources.getDrawable(this, R.drawable.es_bg_custom_switch_back_drawable));
    }

    private void bindViewValue() {
        mToolbar.setSimpleBack(getString(R.string.es_activity_chart_setting_chart_draw_setting));
    }

    private void bindOnClick() {
        mSwitchPositionButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                EsSPHelper.setIsShowPositionCost(getBaseContext(), isChecked);
            }
        });

        mSwitchLastPriceButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                EsSPHelper.setIsShowLastPrice(getBaseContext(), isChecked);
            }
        });

        mSwitchDrawLineButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                EsSPHelper.setIsShowDrawLine(getBaseContext(), isChecked);
            }
        });
    }
}
