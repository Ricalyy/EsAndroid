package com.esunny.ui.common.setting.about;

import android.content.ActivityNotFoundException;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import androidx.core.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.android.arouter.facade.Postcard;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.util.EsNetHelper;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.activity.EsPrivacyActivity;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.dialog.EsCusTurnWeixinDialog;
import com.esunny.ui.util.EsAppUpdate;
import com.esunny.ui.util.EsLanguageHelper;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBadgeView;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsIconTextView;

import butterknife.BindInt;
import butterknife.BindView;
import butterknife.OnClick;


@Route(path = RoutingTable.ES_ABOUT_ACTIVITY)
public class EsAboutActivity extends EsBaseActivity{

    private final static String TEL_NUMBER = "4006156869";
    private final static String HISTORY_VERSION_WEB = "http://www.epolestar.xyz/updateHistoryEstar.html?language=%d&theme=%d&type=1";

    private final static String ESTAR_WEBSITE = "www.epolestar.xyz";

    @BindView(R2.id.activity_es_about_toolbar)
    EsBaseToolBar tb_toolbar;
    @BindView(R2.id.activity_es_about_iv_logo)
    ImageView iv_logo;
    @BindView(R2.id.activity_es_about_ftv_app_name)
    TextView ftv_app_name;
    @BindView(R2.id.activity_es_about_tv_package_no_value)
    TextView tv_package_no;
    @BindView(R2.id.activity_es_about_tv_quote_address_value)
    TextView tv_quote_address;
    @BindView(R2.id.activity_es_about_tv_his_quote_address_value)
    TextView tv_his_quote_address;
    @BindView(R2.id.activity_es_about_tv_trade_address_value)
    TextView tv_trade_address;
    @BindView(R2.id.activity_es_about_rl_trade_address)
    RelativeLayout rl_trade_address;
    @BindView(R2.id.activity_es_about_tv_cloud_address_value)
    TextView mTvCloudAddr;
    @BindView(R2.id.activity_es_about_rl_cloud_address)
    RelativeLayout mRlCloudAddr;
    @BindView(R2.id.activity_es_about_tv_website)
    TextView tv_website;
    @BindView(R2.id.activity_es_about_website_ntext)
    EsIconTextView itv_website_next;
    @BindView(R2.id.activity_es_about_rl_website)
    RelativeLayout rl_website;
    @BindView(R2.id.activity_es_about_tv_qq_value)
    TextView tv_qq;
    @BindView(R2.id.activity_es_about_qq_ntext)
    EsIconTextView itv_qq_next;
    @BindView(R2.id.activity_es_about_rl_qq)
    RelativeLayout rl_qq;
    @BindView(R2.id.activity_es_about_tv_version)
    TextView mTvVersionName;
    @BindView(R2.id.activity_es_about_tv_version_value)
    TextView mTvVersion;
    @BindView(R2.id.activity_es_about_rl_version)
    RelativeLayout mRlVersion;
    @BindView(R2.id.activity_es_about_tv_company_name)
    TextView tv_company_name;
    @BindView(R2.id.activity_es_about_tv_mac_value)
    TextView mTvIdentifier;
    @BindView(R2.id.activity_es_about_rl_privacy)
    RelativeLayout mRlPrivacy;

    EsBadgeView badgeViewVersion;

    String mVersionCode;
    String mAppName;
    String mUrl;

    AddrInfo mQuoteServiceAddressInfo;
    AddrInfo mHisQuoteServiceAddressInfo;
    AddrInfo mTradeServiceAddressInfo;
    AddrInfo mCloudServiceAddressInfo;

    @Override
    protected void initData() {
        super.initData();

        initAddress();

        Postcard postcard = new Postcard();
        postcard.setGroup("estarDataTradeApi");
        postcard.setPath("");
    }

    private void initAddress() {
        PackageManager manager = this.getPackageManager();
        PackageInfo info = null;
        try {
            info = manager.getPackageInfo(this.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        if (info != null) {
            mVersionCode = info.versionName;
            ApplicationInfo applicationInfo = info.applicationInfo;
            mAppName = (String)applicationInfo.loadLabel(manager);
        }

        mUrl = EsDataApi.getCompanyUrl();

        EsLoginAccountData.LoginAccount loginAccount = null;
        String companyNo = "";
        String userNo = "";
        String addrNo = "";
        if (EsLoginAccountData.getInstance() != null) {
            loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
        }

        if (loginAccount != null) {
            companyNo = loginAccount.getCompanyNo();
            userNo = loginAccount.getUserNo();
            addrNo = loginAccount.getAddrTypeNo();
        }

        mQuoteServiceAddressInfo = EsDataApi.getAddrInfo(EsUIConstant.S_SRVSRC_QUOTE, companyNo, userNo, addrNo);
        mHisQuoteServiceAddressInfo = EsDataApi.getAddrInfo(EsUIConstant.S_SRVSRC_HISQUOTE, companyNo, userNo, addrNo);
        mTradeServiceAddressInfo = EsDataApi.getAddrInfo(EsUIConstant.S_SRVSRC_TRADE, companyNo, userNo, addrNo);
        mCloudServiceAddressInfo = EsDataApi.getAddrInfo(EsUIConstant.S_SRVSRC_CLOUD, companyNo, userNo, addrNo);
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindViewValue();
    }


    private void bindViewValue() {

        ftv_app_name.setText(mAppName);
        tv_qq.setText(TEL_NUMBER);

        if (mQuoteServiceAddressInfo != null) {
            String quoteIP = mQuoteServiceAddressInfo.getIp() == null ? "---" : mQuoteServiceAddressInfo.getIp();
            String quotePort = mQuoteServiceAddressInfo.getPort() == 0 ? "---" : mQuoteServiceAddressInfo.getPort() + "";
            tv_quote_address.setText(quoteIP + " :  " + quotePort);
        } else {
            tv_quote_address.setVisibility(View.GONE);
        }
        if (mHisQuoteServiceAddressInfo != null) {
            String hisQuoteIP = mHisQuoteServiceAddressInfo.getIp() == null ? "---" : mHisQuoteServiceAddressInfo.getIp();
            String hisQuotePort = mHisQuoteServiceAddressInfo.getPort() == 0 ? "---" : mHisQuoteServiceAddressInfo.getPort() + "";
            tv_his_quote_address.setText(hisQuoteIP + " :  " + hisQuotePort);
        } else {
            tv_his_quote_address.setVisibility(View.GONE);
        }

        if (mTradeServiceAddressInfo != null) {
            String tradeIP = mTradeServiceAddressInfo.getIp();
            int tradePort = mTradeServiceAddressInfo.getPort();
            if (tradeIP == null || tradePort == 0) {
                rl_trade_address.setVisibility(View.GONE);
            } else {
                tv_trade_address.setText(tradeIP + " :  " + tradePort);
            }
        } else {
            rl_trade_address.setVisibility(View.GONE);
        }
        if (mCloudServiceAddressInfo != null) {
            String cloudIP = mCloudServiceAddressInfo.getIp();
            int cloudPort = mCloudServiceAddressInfo.getPort();
            if (cloudIP == null || cloudPort == 0) {
                mRlCloudAddr.setVisibility(View.GONE);
            } else {
                mTvCloudAddr.setText(cloudIP + " : " + cloudPort);
            }
        } else {
            mRlCloudAddr.setVisibility(View.GONE);
        }

        tv_package_no.setText(EsDataApi.getPackageNo());

        String url = ESTAR_WEBSITE;
        if (mUrl != null && mUrl.startsWith("http://")) {
            String[] aar = mUrl.split("://");
            if (aar.length > 1) {
                url = aar[1].replace("/", "");
            }
        }

        tv_website.setText(url);
        tb_toolbar.setSimpleBack(getString(R.string.es_activity_about_estart));
        mTvVersion.setText(String.format(mTvVersion.getText().toString(), mVersionCode));
        mTvIdentifier.setText(EsNetHelper.getMac(this));

        updateVersionBadgeUI();
    }

    private void updateVersionBadgeUI() {
        int spec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        mTvVersionName.measure(spec, spec);
        int versionMeasuredWidth = mTvVersionName.getMeasuredWidth();
        int versionMeasuredHeight = mTvVersionName.getMeasuredHeight();
        mTvVersionName.setWidth(versionMeasuredWidth + 40);
        mTvVersionName.setHeight(versionMeasuredHeight + 50);
        badgeViewVersion = new EsBadgeView(this);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(20, 20, Gravity.END | Gravity.TOP);
        badgeViewVersion.setTargetView(mTvVersionName);
        badgeViewVersion.setLayoutParams(layoutParams);
        badgeViewVersion.setHideOnNull(false);
        badgeViewVersion.setBadgeMargin(5);
        badgeViewVersion.setBackground(10, ContextCompat.getColor(this,R.color.es_about_activity_badge_view));
        badgeViewVersion.setVisibility(EsSPHelper.getIsVersionLower(this) ? View.VISIBLE : View.GONE);
        mTvVersionName.setGravity(Gravity.CENTER_VERTICAL);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_about;
    }

    @OnClick({R2.id.activity_es_about_rl_website, R2.id.activity_es_about_tv_website, R2.id.activity_es_about_website_ntext, R2.id.activity_es_about_rl_qq,
    R2.id.activity_es_about_qq_ntext, R2.id.activity_es_about_tv_qq_value, R2.id.activity_es_about_rl_version, R2.id.activity_es_about_rl_privacy,
    R2.id.activity_es_about_rl_weixin, R2.id.activity_es_about_tv_weixin, R2.id.activity_es_about_weixin_ntext})
    public void onClick(View view) {
        if (view.getId() == R.id.activity_es_about_rl_website ||
                view.getId() == R.id.activity_es_about_tv_website ||
                view.getId() == R.id.activity_es_about_website_ntext) {
            goToWebsite();
        } else if (view.getId() == R.id.activity_es_about_rl_qq ||
                view.getId() == R.id.activity_es_about_qq_ntext ||
                view.getId() == R.id.activity_es_about_tv_qq_value) {
            goToTelephone();
        } else if (view.getId() == R.id.activity_es_about_rl_version) {
            if (EsSPHelper.getIsVersionLower(EsAboutActivity.this)) {
                updateVersion();
            } else {
                goToHisVersion();
            }
        } else if (view.getId() == R.id.activity_es_about_rl_weixin ||
                view.getId() == R.id.activity_es_about_tv_weixin ||
                view.getId() == R.id.activity_es_about_weixin_ntext) {
            goToWeixin();
        } else if (view.getId() == R.id.activity_es_about_rl_privacy) {
            goPrivacy();
        }
    }

    private void goPrivacy() {
        Intent intent = new Intent(EsAboutActivity.this, EsPrivacyActivity.class);
        intent.putExtra(EsUIConstant.KEY_PRIVACY_CONTENT, "Privacy");
        startActivity(intent);
    }

    private void goToHisVersion() {
        int language = getLanguage(EsLanguageHelper.getFavoriteLanguage(this));
        int theme;
        if (EsSPHelper.getTheme(this)) {
            theme = 1;
        } else {
            theme = 0;
        }

        Uri uri = Uri.parse(String.format(HISTORY_VERSION_WEB, language, theme));
        startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }

    private void updateVersion() {
        //更新服务
        EsAppUpdate update = new EsAppUpdate(this);
        update.startUpdate();
    }

    private int getLanguage(int languageType) {
        int language = 0;
        switch (languageType) {
            case EsLanguageHelper.LOCALE_ENGLISH:
                language = 2;
                break;
            case EsLanguageHelper.LOCALE_CHINA:
                language = 0;
                break;
            case EsLanguageHelper.LOCALE_HONGKONG:
                language = 1;
                break;
            case EsLanguageHelper.LOCALE_DEFAULT:
                language = getLanguage(EsLanguageHelper.getDefaultLanguage());
                break;
        }
        return language;
    }

    public void goToWebsite() {
        Uri uri = Uri.parse(mUrl);
        startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }

    private void goToTelephone() {
        Intent dialIntent =  new Intent(Intent.ACTION_DIAL,Uri.parse("tel:" + TEL_NUMBER));
        startActivity(dialIntent);
    }

    private void goToWeixin() {
        EsCusTurnWeixinDialog dialog = new EsCusTurnWeixinDialog(this, new EsCusTurnWeixinDialog.turnToWeixinDialogListener() {
            @Override
            public void turnToWeixin() {
                try {
                    ClipboardManager tvCopy = (ClipboardManager) EsAboutActivity.this.getSystemService(Context.CLIPBOARD_SERVICE);
                    tvCopy.setText(getResources().getString(R.string.es_activity_about_weixin_account));
                    Intent intent = new Intent(Intent.ACTION_MAIN);
                    ComponentName cmp = new ComponentName("com.tencent.mm","com.tencent.mm.ui.LauncherUI");
                    intent.addCategory(Intent.CATEGORY_LAUNCHER);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.setComponent(cmp);
                    startActivity(intent);
                } catch (ActivityNotFoundException e) {
                    ToastHelper.show(EsAboutActivity.this, R.string.es_activity_about_tip_no_weixin);
                }
            }
        });
        dialog.show();
    }
//    private void goToQQContract() {
//        //400开头的公众号需要替换成对应的web协议的uin（4006156869替换成938026171）
//        if (isQQClientAvailable(this.getBaseContext())) {
//            String url = "mqqwpa://im/chat?chat_type=crm&uin=938026171&version=1&src_type=web&web_src=http:://wpa.b.qq.com";
//            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
//        } else {
//            Toast.makeText(EsAboutActivity.this, R.string.es_activity_about_tip_no_QQ, Toast.LENGTH_LONG).show();
//        }
//    }
//
//    private boolean isQQClientAvailable(Context context) {
//        // 目前不支持QQ轻聊版，若支持，需要添加则包名检测为com.tencent.qqlite
//        final PackageManager packageManager = context.getPackageManager();
//        List<PackageInfo> pInfo = packageManager.getInstalledPackages(0);
//        if (pInfo != null) {
//            for (int index = 0; index < pInfo.size(); index++) {
//                String pn = pInfo.get(index).packageName;
//                if (pn.equals("com.tencent.mobileqq") || pn.equals("com.tencent.tim")) {
//                    return true;
//                }
//            }
//        }
//        return false;
//    }
}
