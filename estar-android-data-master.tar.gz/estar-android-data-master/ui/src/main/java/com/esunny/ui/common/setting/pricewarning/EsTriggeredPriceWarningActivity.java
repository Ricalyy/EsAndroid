package com.esunny.ui.common.setting.pricewarning;

import android.content.Context;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.MonitorEvent;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.ui.R;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.dialog.EsCustomDialog;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsHorizontalScrollView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.List;


public class EsTriggeredPriceWarningActivity extends EsBaseActivity  implements EsHorizontalScrollView.OnScrollChangeListener{

    private EsBaseToolBar mBaseToolBar;
    private RecyclerView mRecyclerView;
    private EsHorizontalScrollView mScrollView;
    private EsTriggeredPriceWarnAdapter mAdapter;
    private List<MonitorOrder> mMonitorData = new ArrayList<>();

    private int mLoginStatus;

    @Override
    protected void onResume() {
        super.onResume();

        EventBus.getDefault().register(this);

        mLoginStatus = EsDataApi.priceLogin();

        if (mLoginStatus == 1) {
            updateDataList();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_price_warn_triggered;
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        initView();
        initViewValue();
        bindOnClick();
        initAdapter();
    }

    private void updateDataList() {
        mMonitorData = EsDataApi.getMonitorOrder();
        mAdapter.setMonitorData(mMonitorData);
        mAdapter.notifyDataSetChanged();
    }

    private void initView(){
        mBaseToolBar = findViewById(R.id.es_activity_price_warn_triggered_toolbar);
        mRecyclerView = findViewById(R.id.es_activity_price_warn_triggered_rv);
        mScrollView = findViewById(R.id.es_activity_price_warn_triggered_scrollerView);
        mScrollView.setOnScrollChangeListener(this);

        mAdapter = new EsTriggeredPriceWarnAdapter(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setMonitorData(mMonitorData);
    }

    private void initViewValue() {
        mBaseToolBar.setTitle(getString(R.string.es_activity_price_warn_triggered_basetoolbar));
        mBaseToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
        mBaseToolBar.setRightIcons(new int[]{R.string.es_icon_dustbin});
    }

    private void bindOnClick() {
        mBaseToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_left_first) {
                    finish();
                } else if (id == R.id.toolbar_right_first) {
                    deleteMonitorOrder();
                }
            }
        });
    }

    protected void initAdapter() {

    }

    private void deleteMonitorOrder() {
        QuoteLoginInfo loginInfo = EsDataApi.quoteLoginInfo();
        if (loginInfo != null && loginInfo.getErrorCode() == 0 && !loginInfo.getLoginNo().isEmpty()) {
            final EsCustomDialog dialog = EsCustomDialog.create(this);
            dialog.setTitle(getString(R.string.es_base_view_tips))
                    .setCancelable(false)
                    .setContent(getString(R.string.es_activity_price_warn_triggered_delete_all_confirm))
                    .setClickListener(new EsCustomDialog.EsDialogClickListener() {
                        @Override
                        public void onConfirm() {
                            EsDataApi.deleteMonitorOrder();
                        }

                        @Override
                        public void onCancel() {
                            dialog.dismiss();
                        }
                    }).show();
        } else {
            EsUIApi.startStarLoginActivity(this);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    public void onScrollChange(int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(MonitorEvent event) {
        int action = event.getAction();

        switch (action) {
            case EsDataConstant.S_SRVEVENT_MONITOR_QRY:
            case EsDataConstant.S_SRVEVENT_MONITOR_RTN:
            case EsDataConstant.S_SRVEVENT_MONITOR_ACTION:
            case EsDataConstant.S_SRVEVENT_MONITOR_DELETE:
                updateDataList();
                break;
            default:
                break;
        }
    }
}
