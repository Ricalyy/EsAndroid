package com.esunny.ui.common.setting.quote.kline;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.esunny.data.bean.Plate;
import com.esunny.ui.R;
import com.esunny.ui.view.EsFixTextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

public class EsQuoteSettingAdapter extends RecyclerView.Adapter<EsQuoteSettingAdapter.ViewHolder>{

    private final static List<String> CHECKED_PLATE = Arrays.asList("MAIN", "ZCE");

    private List<Plate> mData;

    JSONObject mJson = null;

    public void setJsonData(JSONObject jsonData) {
        this.mJson = jsonData;
    }

    public void setDataList(List<Plate> data) {
        this.mData = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_quote_settting_item_plate, parent, false);
        return new EsQuoteSettingAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Plate plate = mData.get(position);
        if(position > -1 && position < mData.size() &&  plate != null){
            holder.mTvPlate.setText(plate.getPlateName());

            String plateNo = plate.getPlateNo();
            if (plateNo != null && mJson.has(plateNo)) {
                try {
                    boolean isSelected = mJson.getBoolean(plateNo);
                    holder.mTvPlate.setSelected(isSelected);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                holder.mTvPlate.setSelected(true);
            }

            if (CHECKED_PLATE.contains(plate.getPlateNo())) {
                holder.mTvPlate.setSelected(true);
            }

        }
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        EsFixTextView mTvPlate;

        ViewHolder(View itemView) {
            super(itemView);

            mTvPlate = itemView.findViewById(R.id.es_quote_setting_item_plate);
            mTvPlate.setSelected(true);

            mTvPlate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Plate plate = mData.get(getAdapterPosition());
                    if (CHECKED_PLATE.contains(plate.getPlateNo())) {
                        return;
                    }

                    mTvPlate.setSelected(!mTvPlate.isSelected());

                    try {
                        mJson.put(plate.getPlateNo(), mTvPlate.isSelected());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }
}
