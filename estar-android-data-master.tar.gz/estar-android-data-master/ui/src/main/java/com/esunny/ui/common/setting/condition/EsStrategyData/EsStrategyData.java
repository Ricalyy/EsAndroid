package com.esunny.ui.common.setting.condition.EsStrategyData;


import android.content.Context;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.QuoteEvent;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.QuoteBetData;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.OpenOrder;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.util.EsSPHelper;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;


import static com.esunny.ui.common.setting.condition.EsStrategyData.EsStrategyData.mST.None;


public class EsStrategyData {
    public final static String KEY_SEARCH_SOURCE = "EsStrategyActivity";

    private boolean mIsBuyPriceImplied = false;//是否隐含报价
    private boolean mIsSellPriceImplied = false;
    private boolean mIsBuyQtyImplied = false;
    private boolean mIsSellQtyImplied = false;
    private double mLastPrice = 0;
    private double mBuyPrice = 0;
    private double mSellPrice = 0;
    private double mLimitUpPrice = 0;
    private double mLimitDownPrice = 0;
    private double mPreSettlePrice = 0;
    private double mPreClosingPrice = 0;
    private BigInteger mLastQty = BigInteger.ZERO;
    private BigInteger mBuyQty = BigInteger.ZERO;
    private BigInteger mSellQty = BigInteger.ZERO;
    private Contract mSelectedContract = null;
    private boolean mIsPrice = true;
    private boolean mIsOpen = true;
    private boolean mIsToday = false;
    private boolean mIsBonus = false;
    private boolean mIsOpenTrigger = false;
    private boolean mIsOrderPlusAdd = true;
    private boolean mdidSubscribeQuoteReady = false;
    // 云条件单中是否为改单。 True为改单，false为正常下云条件单
    private boolean mIsModifyConditionOrder = false;
    // 时间条件单中类型，根据时间到达触发的到达单，还是自动单
    private boolean mIsAutoOrder = false;
    private boolean mIsFromKLine = false;
    private char mTriggerCondition = EsDataConstant.S_TC_GREATER;
    private char mBonusTriggerCondition = EsDataConstant.S_TC_GREATER;
    private char mTriggerMode = EsDataConstant.S_TM_LATEST;
    private char mBonusTriggerMode = EsDataConstant.S_TM_LATEST;

    private char mConditionOrderPriceType = EsDataConstant.S_PT_LSAT;
    private char mStopLossOrderPriceType = EsDataConstant.S_PT_LSAT;
    private char mStopProfitOrderPriceType = EsDataConstant.S_PT_LSAT;
    private mST mStrategyType = None;

    private boolean mIsToSearch;
    private long mDefaultQty = 0;
    private List<OpenOrder> mStopLossList;


    private static char[] mTC = {EsDataConstant.S_TC_GREATER,EsDataConstant.S_TC_LESS,EsDataConstant.S_TC_GREATEREQUAL,EsDataConstant.S_TC_LESSEQUAL};
    private static char[] mTM = {EsDataConstant.S_TM_LATEST,EsDataConstant.S_TM_BID,EsDataConstant.S_TM_ASK};
    private static char[] mPT = {EsDataConstant.S_PT_ABS,0,EsDataConstant.S_PT_LSAT,EsDataConstant.S_PT_QUEUE,EsDataConstant.S_PT_MATCH,EsDataConstant.S_PT_MARKET};//零是为了和界面的空行保持一致，需要再优化

    public enum mST{SpecifiedStopLP,StopLP,StopL,StopP,Float,None}
    private StrategyDataListener mCallback = null;
    private static EsStrategyData instance;

    public static EsStrategyData getInstance(){
        if(instance==null){
            instance = new EsStrategyData();
        }
//        register();
        return instance;
    }

    private EsStrategyData(){
    }

    public void setCallback(StrategyDataListener callback){
        mCallback = callback;
    }

    public void removeCallback() {
        mCallback = null;
    }

    public interface StrategyDataListener {
        void onDataQuote();//回调行情

        /**
         *
         * @param sContract: null if cant find contract
         */
        void onSetContract(Contract sContract);//设置合约回调
    }

    private ArrayList<InsertOrder> mListSavedOrders  = new ArrayList<>();
    public void saveStopOrders(InsertOrder sInsertOrder){
        mListSavedOrders.add(sInsertOrder);
    }

    public void register(){
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        if(mSelectedContract!=null){
            EsDataApi.subQuote(mSelectedContract.getContractNo());
            mdidSubscribeQuoteReady = false;
        }
    }

    public void unRegister(){
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }

        if(mSelectedContract!=null){
            EsDataApi.unSubQuote(mSelectedContract.getContractNo());
            mdidSubscribeQuoteReady = false;
        }
    }



    public double getmLastPrice() {
        return mLastPrice;
    }

    public double getmPreClosingPrice(){
        return mPreClosingPrice;
    }

    public double getmPreSettlePrice(){
        return mPreSettlePrice;
    }
    public double getmBuyPrice() {
        return mBuyPrice;
    }

    public double getmSellPrice() {
        return mSellPrice;
    }

    public double getmLimitUpPrice() {
        return mLimitUpPrice;
    }

    public double getmLimitDownPrice() {
        return mLimitDownPrice;
    }

    public BigInteger getmLastQty() {
        return mLastQty;
    }

    public BigInteger getmBuyQty() {
        return mBuyQty;
    }

    public BigInteger getmSellQty() {
        return mSellQty;
    }

    public boolean isImpBidPrice() {
        return mIsBuyPriceImplied;
    }

    public boolean isImpAskPrice() {
        return mIsSellPriceImplied;
    }

    public boolean isImpBidQty() {
        return mIsBuyQtyImplied;
    }

    public boolean isImpAskQty() {
        return mIsSellQtyImplied;
    }

    private void refreshQuoteInfo(){
        if(mSelectedContract!=null){
            QuoteBetData snapShot = new QuoteBetData(mSelectedContract);
            if(snapShot!= null){
                mLastPrice = snapShot.getLastPrice();
                mIsBuyPriceImplied = snapShot.isBuyPriceImplied();
                mBuyPrice = snapShot.getBuyPrice();
                mIsSellPriceImplied = snapShot.isSellPriceImplied();
                mSellPrice = snapShot.getSellPrice();
                mIsSellQtyImplied = snapShot.isSellQtyImplied();
                mSellQty = snapShot.getSellQty();
                mIsBuyQtyImplied = snapShot.isBuyQtyImplied();
                mBuyQty = snapShot.getBuyQty();
                mLastQty = snapShot.getLastQty();
                mLimitUpPrice = snapShot.getLimitUpPrice();
                mLimitDownPrice = snapShot.getLimitDownPrice();
                mPreSettlePrice = snapShot.getPreSettlePrice();
                mPreClosingPrice = snapShot.getPreClosingPrice();
            }
        }
    }

    public void setSelectedContract(Context context, String selectedContractNo){
        if(selectedContractNo.equals("")){
            return;
        }
        Contract contract = EsDataApi.getTradeContract(selectedContractNo);
        if(contract == null){
            contract = EsDataApi.getQuoteContract(selectedContractNo);
        }
        if(contract == null) {//过期或不存在
            if(mCallback!=null){
                mCallback.onSetContract(null);
                return;
            }
        }
        if(mSelectedContract != null){
            EsDataApi.unSubQuote(mSelectedContract.getContractNo());
        }
        mSelectedContract = contract;

        if (contract != null) {
            String commodityNo = contract.getCommodity().getCommodityNo();
            if (commodityNo.contains("|Z|")) {
                commodityNo = commodityNo.replace("|Z|", "|F|");
            }
            mDefaultQty = EsSPHelper.getCommodityNumByNo(context, commodityNo);
        }

        EsDataApi.subQuote(mSelectedContract.getContractNo());
        mdidSubscribeQuoteReady = false;
//        if(ret == 1){
//            //新订阅的合约，需要等回调通知界面刷新
//            mdidSubscribeQuoteReady = false;
//        }else{
//            mdidSubscribeQuoteReady = true;
//        }
        refreshQuoteInfo();
        if(mCallback!=null){
            mCallback.onSetContract(mSelectedContract);
        }
    }
    public Contract getSelectedContract(){
        return mSelectedContract;
    }

    public long getDefaultQty() {
        return mDefaultQty;
    }

    public boolean isPrice(){
        return mIsPrice;
    }
    public void setPrice(boolean isPrice){
        mIsPrice = isPrice;
    }

    public boolean isToday() {
        return mIsToday;
    }

    public void setToday(boolean mIsToday) {
        this.mIsToday = mIsToday;
    }

    public boolean isOpen() {
        return mIsOpen;
    }

    public void setOpen(boolean mIsOpen) {
        this.mIsOpen = mIsOpen;
    }

    public boolean isBonus() {
        return mIsBonus;
    }

    public void setIsBonus(boolean mIsBonus) {
        this.mIsBonus = mIsBonus;
    }
    public boolean isOpenTrigger() {
        return mIsOpenTrigger;
    }
    public void setIsOpenTrigger(boolean mIsOpenTrigger) {
        this.mIsOpenTrigger = mIsOpenTrigger;
    }

    public boolean isOrderPlusAdd() {
        return mIsOrderPlusAdd;
    }

    public void setIsOrderPlusAdd(boolean mIsOrderPlusAdd) {
        this.mIsOrderPlusAdd = mIsOrderPlusAdd;
    }

    public void setIsModifyConditionOrder(boolean isModifyConditionOrder) {
        this.mIsModifyConditionOrder = isModifyConditionOrder;
    }

    public boolean getIsModifyConditionOrder() {
        return mIsModifyConditionOrder;
    }

    public void setIsFromKLine(boolean isFromKLine) {
        this.mIsFromKLine = isFromKLine;
    }

    public boolean getIsFromKLine() {
        return mIsFromKLine;
    }

    public char getTriggerCondition(){
        return mTriggerCondition;
    }
    public int getTriggerConditionIndex() {
        for (int i = 0; i < mTC.length; i++) {
            if(mTriggerCondition == mTC[i]){
                return i;
            }
        }
        return -1;
    }

    public int getTriggerConditionIndex(char triggerCondition) {
        for (int i = 0; i < mTC.length; i++) {
            if(triggerCondition == mTC[i]){
                return i;
            }
        }
        return -1;
    }

    /**
     * index of following:
     * EsDataConstant.S_TC_GREATER,EsDataConstant.S_TC_LESS,EsDataConstant.S_TC_GREATEREQUAL,EsDataConstant.S_TC_LESSEQUAL
     * @param index
     */
    public void setTriggerCondition(int index) {
        if(index >= 0 && index < mTC.length) {
            this.mTriggerCondition = mTC[index];
        }
    }

    public char getBonusTriggerCondition(){
        return mBonusTriggerCondition;
    }
    public int getBonusTriggerConditionIndex() {
        for (int i = 0; i < mTC.length; i++) {
            if(mBonusTriggerCondition == mTC[i]){
                return i;
            }
        }
        return -1;
    }
    /**
     * index of following:
     * EsDataConstant.S_TC_GREATER,EsDataConstant.S_TC_LESS,EsDataConstant.S_TC_GREATEREQUAL,EsDataConstant.S_TC_LESSEQUAL
     * @param index
     */
    public void setBonusTriggerCondition(int index) {
        if(index >= 0 && index < mTC.length) {
            this.mBonusTriggerCondition = mTC[index];
        }
    }
    public int getTriggerModeIndex() {
        for (int i = 0; i < mTM.length; i++) {
            if(mTriggerMode == mTM[i]){
                return i;
            }
        }
        return -1;
    }
    public char getTriggerMode(){
        return mTriggerMode;
    }
    /**
     * index of following:
     * EsDataConstant.S_TM_LATEST,EsDataConstant.S_TM_BID,EsDataConstant.S_TM_ASK
     * @param index
     */
    public void setTriggerMode(int index) {
        if(index >= 0 && index < mTM.length) {
            this.mTriggerMode = mTM[index];
        }
    }

    public char getBonusTriggerMode(){
        return mBonusTriggerMode;
    }
    public int getBonusTriggerModeIndex() {
        for (int i = 0; i < mTM.length; i++) {
            if(mBonusTriggerMode == mTM[i]){
                return i;
            }
        }
        return -1;
    }
    /**
     * index of following:
     * EsDataConstant.S_TM_LATEST,EsDataConstant.S_TM_BID,EsDataConstant.S_TM_ASK
     * @param index
     */
    public void setBonusTriggerMode(int index) {
        if(index >= 0 && index < mTM.length) {
            this.mBonusTriggerMode = mTM[index];
        }
    }

    public char getConditionOrderPriceType(){
        return mConditionOrderPriceType;
    }
    public int getConditionOrderPriceTypeIndex() {
        for (int i = 0; i < mPT.length; i++) {
            if(mConditionOrderPriceType == mPT[i]){
                return i;
            }
        }
        return -1;
    }

    public void setConditionOrderPriceType(int index) {
        if(index >= 0 && index < mPT.length) {
            this.mConditionOrderPriceType = mPT[index];
        }
    }
    public char getStopLossOrderPriceType(){
        return mStopLossOrderPriceType;
    }
    public int getStopLossOrderPriceTypeIndex() {
        for (int i = 0; i < mPT.length; i++) {
            if(mStopLossOrderPriceType == mPT[i]){
                return i;
            }
        }
        return -1;
    }

    public void setStopLossOrderPriceType(int index) {
        if(index >= 0 && index < mPT.length) {
            this.mStopLossOrderPriceType = mPT[index];
        }
    }

    public char getStopProfitOrderPriceType(){
        return mStopProfitOrderPriceType;
    }
    public int getStopProfitOrderPriceTypeIndex() {
        for (int i = 0; i < mPT.length; i++) {
            if(mStopProfitOrderPriceType == mPT[i]){
                return i;
            }
        }
        return -1;
    }

    public void setStopProfitOrderPriceType(int index) {
        if(index >= 0 && index < mPT.length) {
            this.mStopProfitOrderPriceType = mPT[index];
        }
    }


    public mST getStrategyType() {
        return mStrategyType;
    }

    public void setStrategyType(mST mStrategyType) {
        this.mStrategyType = mStrategyType;
    }

    public void setToSearch(boolean isTo) {
        mIsToSearch = isTo;
    }

    public boolean isToSearch() {
        return mIsToSearch;
    }

    public void setStopLossList(List<OpenOrder> list) {
        if (mStopLossList == null) {
            mStopLossList = new ArrayList<>(3);
        } else {
            mStopLossList.clear();
        }

        if (list != null) {
            mStopLossList.addAll(list);
        }
    }

    public List<OpenOrder> getStopLossList() {
        if (mStopLossList == null) {
            mStopLossList = new ArrayList<>(3);
        }
        return mStopLossList;
    }

    public boolean hasStopLoss() {
        if (mSelectedContract == null || mSelectedContract.isForeignContract()) {
            return false;
        }

        if (mIsOpenTrigger) {
            return false;
        }

        return mStopLossList != null && mStopLossList.size() > 0;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void tradeEvent(TradeEvent event) {
        int action = event.getAction();
        String companyNo = event.getCompanyNo();
        String userNo = event.getUserNo();
        String addrNo = event.getAddressNo();
        if (!EsLoginAccountData.getInstance().isCurrentAccount(companyNo, userNo, addrNo)) {
            return;
        }

        if (action == EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER) {
            OrderData data = (OrderData)event.getData();
            if (data == null) {
                return;
            }

            char strategyType = data.getStrategyType();
            char orderState = data.getOrderState();
            long orderReqId = data.getOrderReqId();
            String orderNo = data.getOrderNo();

            if ((strategyType == EsDataConstant.S_ST_CONDITION
                    || strategyType == EsDataConstant.S_ST_CONDITION_PARENT
                    || strategyType == EsDataConstant.S_ST_BACKHAND)
                    && orderState == EsDataConstant.S_ORDERSTATE_TRIGGERING) {
                ArrayList<Integer> triggeredArray = new ArrayList<>();
                for (int i = 0; i < mListSavedOrders.size(); i++) {
                    InsertOrder orderInsert = mListSavedOrders.get(i);
                    if(orderInsert.getParentReqId() == orderReqId && orderNo != null){
                        orderInsert.setParentNo(orderNo);
                        EsDataApi.openTradeOrder(orderInsert);//下止损单

                        triggeredArray.add(i);
                    }
                }
                for (int i = 0; i < triggeredArray.size(); i++) {
                    mListSavedOrders.remove(triggeredArray.get(i).intValue());//删掉保存的单
                }
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void quoteEvent(QuoteEvent event) {
        int action = event.getAction();

        if (action == EsDataConstant.S_SRVEVENT_QUOTELOGIN) {
            if(mSelectedContract != null){
                EsDataApi.subQuote(mSelectedContract.getContractNo());
            }
        } else if (action == EsDataConstant.S_SRVEVENT_QUOTE) {
            String contractNo = event.getContractNo();
            if(mSelectedContract != null){
                if (contractNo.equals(mSelectedContract.getContractNo())) {
                    refreshQuoteInfo();
                    if(mCallback != null){
                        mCallback.onDataQuote();
                        if(!mdidSubscribeQuoteReady){
                            mCallback.onSetContract(mSelectedContract);
                            mdidSubscribeQuoteReady = true;
                        }
                    }
                }
            }
        }
    }
}
