package com.esunny.ui.common.setting.trade;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.bean.Plate;
import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.setting.trade.adapter.EsCommodityInfoAdapter;
import com.esunny.ui.common.setting.trade.adapter.EsExceedPointAdapter;
import com.esunny.ui.common.setting.trade.adapter.EsPlateInfoAdapter;
import com.esunny.ui.view.EsBaseToolBar;

import java.util.ArrayList;
import java.util.List;

public class EsDefaultQtyActivity extends EsBaseActivity implements View.OnClickListener {

    private final static String FILTER_SUM_PLATE_NO = "SUM";
    private final static String FILTER_NIGHT_PLATE_NO = "NIGHT";
    private final static String FILTER_MAIN_PLATE_NO = "MAIN";
    private final static String FILTER_FOREX_PLATE_NO = "FOREX";

    private final static String FILTER_CHN_PARENT_PLATE_NO = "CHN";
    private final static String FILTER_FOR_PARENT_PLATE_NO = "FOR";

    static final String ACTIVITY_TYPE_KEY = "type";
    static final int ACTIVITY_TYPE_VALUE_QTY = 0;
    static final int ACTIVITY_TYPE_VALUE_EXCEED = 1;

    RecyclerView rv_exchange, rv_commodity;
    EsBaseToolBar tb_toolbar;
    TextView mTitlePrice, mTitlePoint;

    EsPlateInfoAdapter mPlateInfoAdapter;
    EsCommodityInfoAdapter mCommodityInfoAdapter;
    EsExceedPointAdapter mExceedPointAdapter;

    RecyclerView.LayoutManager commodityLayoutManage;

    private List<Plate> mDataInSPlateList;

    private Plate mCurrentPlate;
    private int mType;

    @Override
    protected void initData() {
        super.initData();
        mType = getIntent().getIntExtra(ACTIVITY_TYPE_KEY, 0);

        initPlateData();
    }

    private void initPlateData() {
        List<Plate> groupPlate = EsDataApi.getPlate();
        mDataInSPlateList = new ArrayList<>();

        ArrayList<Plate> cnPlate = new ArrayList<>();
        ArrayList<Plate> frPlate = new ArrayList<>();
        ArrayList<Plate> otPlate = new ArrayList<>();

        for (int i = 0; i < groupPlate.size(); i++) {
            Plate sPlate = groupPlate.get(i);
            if (sPlate.getParentPlateNo().trim().isEmpty()) {
                continue;
            }
            if (FILTER_SUM_PLATE_NO.equals(sPlate.getPlateNo()) || FILTER_NIGHT_PLATE_NO.equals(sPlate.getPlateNo()) ||
                    FILTER_FOREX_PLATE_NO.equals(sPlate.getPlateNo())) {
                continue;
            }

            if (FILTER_MAIN_PLATE_NO.equals(sPlate.getPlateNo())) {
                mDataInSPlateList.add(sPlate);
            } else if (FILTER_CHN_PARENT_PLATE_NO.equals(sPlate.getParentPlateNo())) {
                cnPlate.add(sPlate);
            } else if (FILTER_FOR_PARENT_PLATE_NO.equals(sPlate.getParentPlateNo())) {
                frPlate.add(sPlate);
            } else {
                otPlate.add(sPlate);
            }
        }

        mDataInSPlateList.addAll(cnPlate);
        mDataInSPlateList.addAll(frPlate);
        mDataInSPlateList.addAll(otPlate);

        if (mDataInSPlateList.size() > 0) {
            mCurrentPlate = mDataInSPlateList.get(0);
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();

        initPlateRecyclerView();
        initCommodityRecyclerView();
        if (mType == ACTIVITY_TYPE_VALUE_QTY) {
            tb_toolbar.setSimpleBack(getString(R.string.es_activity_default_hand_amount_title));

            mTitlePrice.setVisibility(View.INVISIBLE);

            mTitlePoint.setText(R.string.es_activity_default_hand_amount_title);
        } else if (mType == ACTIVITY_TYPE_VALUE_EXCEED) {
            tb_toolbar.setSimpleBack(getString(R.string.es_activity_exceed_point_title));

            mTitlePrice.setVisibility(View.VISIBLE);

            mTitlePoint.setText(R.string.es_activity_exceed_point_point);
        }
    }

    private void bindView() {
        rv_exchange = findViewById(R.id.es_activity_default_hand_amount_rv_exchange);
        rv_commodity = findViewById(R.id.es_activity_default_hand_amount_rv_variety);
        tb_toolbar = findViewById(R.id.es_activity_default_hand_amount_toolbar);

        mTitlePrice = findViewById(R.id.es_activity_point_title_tv_point_price);
        mTitlePoint = findViewById(R.id.es_activity_point_title_tv_point);
    }


    private void initPlateRecyclerView() {
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        mPlateInfoAdapter = new EsPlateInfoAdapter(this, mDataInSPlateList);
        mPlateInfoAdapter.setOnItemListener(new EsPlateInfoAdapter.OnItemListener() {
            @Override
            public void onClick(View v, int pos) {

                mPlateInfoAdapter.setDefSelect(pos);

                mCurrentPlate = mDataInSPlateList.get(pos);

                if (mType == ACTIVITY_TYPE_VALUE_QTY) {
                    mCommodityInfoAdapter.update(mCurrentPlate);
                } else if (mType == ACTIVITY_TYPE_VALUE_EXCEED) {
                    mExceedPointAdapter.update(mCurrentPlate);
                }

                commodityLayoutManage.scrollToPosition(0);
            }
        });

        rv_exchange.setLayoutManager(layoutManager);
        rv_exchange.setAdapter(mPlateInfoAdapter);
    }

    private void initCommodityRecyclerView() {
        commodityLayoutManage = new LinearLayoutManager(this);
        rv_commodity.setLayoutManager(commodityLayoutManage);

        if (mType == ACTIVITY_TYPE_VALUE_QTY) {
            mCommodityInfoAdapter = new EsCommodityInfoAdapter(this, mCurrentPlate);
            rv_commodity.setAdapter(mCommodityInfoAdapter);
        } else if (mType == ACTIVITY_TYPE_VALUE_EXCEED) {
            mExceedPointAdapter = new EsExceedPointAdapter(this, mCurrentPlate);
            rv_commodity.setAdapter(mExceedPointAdapter);
        }

        tb_toolbar.setSimpleBack(getString(R.string.es_activity_default_hand_amount_title));
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_default_hand_amount;
    }

    @Override
    public void onClick(View v) {

    }
}
