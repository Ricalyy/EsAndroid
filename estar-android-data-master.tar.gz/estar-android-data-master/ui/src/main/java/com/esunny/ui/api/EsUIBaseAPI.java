package com.esunny.ui.api;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;

import com.alibaba.android.arouter.launcher.ARouter;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.bean.KLinePeriod;
import com.esunny.data.util.EsLog;
import com.esunny.data.api.EsDataTrackApi;
import com.esunny.ui.R;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.util.AESCrypt;
import com.esunny.ui.util.EsLanguageHelper;
import com.esunny.ui.util.EsSPHelper;
import com.github.promeg.pinyinhelper.Pinyin;
import com.github.promeg.pinyinhelper.PinyinMapDict;
import com.umeng.commonsdk.UMConfigure;
import com.umeng.socialize.PlatformConfig;

import java.util.HashMap;
import java.util.Map;

import skin.support.SkinCompatManager;
import skin.support.app.SkinCardViewInflater;
import skin.support.constraint.app.SkinConstraintViewInflater;
import skin.support.design.app.SkinMaterialViewInflater;


public class EsUIBaseAPI {

    private static final String TAG = "EsUIBaseAPI";

    static void initUI(Application application) {

        //利用换肤框架初始化颜色数据
        SkinCompatManager.withoutActivity(application)                         // 基础控件换肤初始化
                .addInflater(new SkinMaterialViewInflater())            // material design 控件换肤初始化[可选]
                .addInflater(new SkinConstraintViewInflater())          // ConstraintLayout 控件换肤初始化[可选]
                .addInflater(new SkinCardViewInflater())                // CardView v7 控件换肤初始化[可选]
                .setSkinStatusBarColorEnable(true)                     // 关闭状态栏换肤，默认打开[可选]
                .setSkinWindowBackgroundEnable(false)                   // 关闭windowBackground换肤，默认打开[可选]
                .loadSkin();

        if (!isDebug(application)) {
//            EsDataApi.setLogLevel(Log.WARN);
        }
        if (EsDataApi.getLogLevel() < Log.INFO) {           // 这两行必须写在init之前，否则这些配置在init过程中将无效
            ARouter.openLog();     // 打印日志
            ARouter.openDebug();   // 开启调试模式(如果在InstantRun模式下运行，必须开启调试模式！线上版本需要关闭,否则有安全风险)
        }
        ARouter.init(application); // 尽可能早，推荐在Application中初始化

        //自定义汉字转拼音字库
        Pinyin.init(Pinyin.newConfig()
                .with(new PinyinMapDict() {
                    @Override
                    public Map<String, String[]> mapping() {
                        HashMap<String, String[]> map = new HashMap<>();
                        map.put("长城",  new String[]{"CHANG", "CHENG"});
                        map.put("长江",  new String[]{"CHANG", "JIANG"});
                        map.put("长安",  new String[]{"CHANG", "AN"});
                        map.put("长期",  new String[]{"CHANG", "QI"});
                        return map;
                    }
                }));

        EsLoginAccountData.getInstance().init(application);
    }

    static void initConfiguration(Context context) {
        UMConfigure.init(context, UMConfigure.DEVICE_TYPE_PHONE, null);
        PlatformConfig.setQQZone("1106900757", "YZPR4MLezM7SKkmC");
        PlatformConfig.setWeixin(getAppMetaStr(context, "shareWeiXinAppID"), getAppMetaStr(context, "shareWeiXinAppSecret"));
    }

    /**
     * 判断当前应用是否是debug状态
     */
    static boolean isDebug(Context context) {
        try {
            ApplicationInfo info = context.getApplicationInfo();
            return (info.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        } catch (Exception e) {
            return false;
        }
    }

    static String getVersion(Context application) {
        try {
            PackageManager manager = application.getPackageManager();
            PackageInfo info = manager.getPackageInfo(application.getPackageName(), 0);
            return info.versionName;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    static String getAppMetaStr(Context context, String key){
        ApplicationInfo appInfo;
        try {
            appInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            EsLog.d(TAG, "getAppMetaStr", e);
            return "";
        }

        if (appInfo == null || appInfo.metaData == null) {
            return "";
        }

        String str = appInfo.metaData.getString(key);
        return str == null ? "" : str;
    }


    static String convertKLinePeriodType(Context context, char type) {
        String name = "";
        switch (type) {
            case KLinePeriod.S_KLINE_MINUTE:
                name = context.getString(R.string.es_kline_period_minute);
                break;
            case KLinePeriod.S_KLINE_HOUR:
                name = context.getString(R.string.es_kline_period_hour);
                break;
            case KLinePeriod.S_KLINE_DAY:
                name = context.getString(R.string.es_kline_period_day);
                break;
            case KLinePeriod.S_KLINE_WEEK:
                name = context.getString(R.string.es_kline_period_week);
                break;
            case KLinePeriod.S_KLINE_MONTH:
                name = context.getString(R.string.es_kline_period_month);
                break;
            default:
                break;
        }
        return name;
    }

    static int initEstarLogin(Context context) {
        SharedPreferences sp = EsSPHelper.getSP(context);
        boolean isAutoLogin = sp.getBoolean(EsUIConstant.ESTAR_LOGIN_AUTO_LOGIN, true);
        if (isAutoLogin){
            AESCrypt aesCrypt = null;
            try {
                aesCrypt = new AESCrypt(context);
            } catch (Exception e) {
                e.printStackTrace();
            }

            String userNo = sp.getString(EsUIConstant.ESTAR_LOGIN_ACCOUNT_NEW, "");
            if (userNo.isEmpty()) {
                userNo = sp.getString(EsUIConstant.ESTAR_LOGIN_ACCOUNT, "");
            } else {
                try {
                    if (aesCrypt != null) {
                        userNo = aesCrypt.decrypt(userNo);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            String password = sp.getString(EsUIConstant.ESTAR_LOGIN_PASSWORD_NEW, "");
            if (password.isEmpty()) {
                password = sp.getString(EsUIConstant.ESTAR_LOGIN_PASSWORD, "");
            } else {
                try {
                    if (aesCrypt != null) {
                        password = aesCrypt.decrypt(password);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            int ret = EsDataApi.quoteLogin(userNo, password);
            EsDataTrackApi.addPolestarLogin(true);
            EsLog.d(TAG, "initEstarLogin ret = " + ret);
            return ret;
        }

        return 3;
    }

    public static String getLaguageStrByType(Context context, int languageType){
        String languageStr = "";
        switch (languageType){
            case EsLanguageHelper.LOCALE_ENGLISH:
                languageStr = context.getString(R.string.es_language_english);
                break;
            case EsLanguageHelper.LOCALE_CHINA:
                languageStr = context.getString(R.string.es_language_china);
                break;
            case EsLanguageHelper.LOCALE_HONGKONG:
                languageStr = context.getString(R.string.es_language_hk);
                break;
            case EsLanguageHelper.LOCALE_DEFAULT:
                languageStr = context.getString(R.string.es_language_default);
                break;
        }
        return languageStr;
    }
}
