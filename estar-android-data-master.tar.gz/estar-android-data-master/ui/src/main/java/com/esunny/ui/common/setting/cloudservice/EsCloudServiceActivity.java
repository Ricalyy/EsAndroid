package com.esunny.ui.common.setting.cloudservice;

import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.EsMVPActivity;
import com.esunny.ui.dialog.EsModifyPasswordDialog;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsBaseToolBar;

import butterknife.BindView;
import butterknife.OnClick;

/**
 * @author Peter
 */
public class EsCloudServiceActivity extends EsMVPActivity<CloudServicePresenterImpl> implements CloudServiceView{

    @BindView(R2.id.es_activity_cloud_service_toolbar)
    EsBaseToolBar mToolbar;
    @BindView(R2.id.es_activity_cloud_tv_contract_backup_days)
    TextView mTvContractBackUp;
    @BindView(R2.id.es_activity_cloud_tv_account)
    TextView mTvAccount;
    @BindView(R2.id.es_activity_cloud_tv_setting_backup_days)
    TextView mTvBackUpDays;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_cloud_service;
    }

    @Override
    protected void initData() {
        super.initData();

        mPresenter.syncFavoriteContractFromCloud(false);
        mPresenter.syncSettingFromCloud(false);
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        initToolbar();
        initValue();
    }

    private void initValue() {
        mTvAccount.setText(EsSPHelperProxy.getEstarAccount(getApplicationContext()));
    }

    private void initToolbar() {
        mToolbar.setSimpleBack(getString(R.string.es_activity_cloud_service_title));
    }

    @OnClick(R2.id.es_activity_cloud_tv_modify_password)
    public void modifyPassword() {
        EsModifyPasswordDialog dialog = new EsModifyPasswordDialog(this, new EsModifyPasswordDialog.ClickListener() {
            @Override
            public void modifyPassword(String oldPassword, String newPassword) {
                mPresenter.modifyPassword(oldPassword, newPassword);
            }
        });
        dialog.show();
    }

    @OnClick(R2.id.es_activity_cloud_tv_clear_data)
    public void clearData() {
        mPresenter.clearData();
    }

    @OnClick(R2.id.es_activity_cloud_tv_log_out)
    public void logout() {
        mPresenter.logout();
        finish();
    }

    @OnClick(R2.id.es_activity_cloud_rl_sync_favorite_to_cloud)
    public void syncFavoriteContractToCloud() {
        mPresenter.syncFavoriteContractToCloud();
    }

    @OnClick(R2.id.es_activity_cloud_rl_sync_favorite_from_cloud)
    public void syncFavoriteContractFromCloud() {
        mPresenter.syncFavoriteContractFromCloud(true);
    }

    @OnClick(R2.id.es_activity_cloud_rl_sync_pc_from_cloud)
    public void syncPCContractFromCloud() {
        mPresenter.syncPCContractFromCloud();
    }

    @OnClick(R2.id.es_activity_cloud_rl_sync_setting_to_cloud)
    public void syncSettingToCloud() {
        mPresenter.syncSettingToCloud();
    }

    @OnClick(R2.id.es_activity_cloud_rl_sync_setting_from_cloud)
    public void syncSettingFromCloud() {
        mPresenter.syncSettingFromCloud(true);
    }

    @Override
    protected CloudServicePresenterImpl createPresenter() {
        return new CloudServicePresenterImpl(this);
    }

    @Override
    protected void onResume() {
        super.onResume();

        mPresenter.register();
    }

    @Override
    protected void onPause() {
        super.onPause();

        mPresenter.unRegister();
    }

    @Override
    public void clearConfigData() {
        ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_system_setting_clear_successfully));
    }

    @Override
    public void syncFavoriteToServer(boolean isSuccess) {
        if (isSuccess) {
            ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_cloud_persional_sync_to_cloud_success));
        } else {
            ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_cloud_persional_sync_to_cloud_fail));
        }
    }

    @Override
    public void syncFavoriteContractFromServer(boolean isSuccess) {
        if (isSuccess) {
            ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_cloud_persional_sync_from_cloud_success));
        } else {
            ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_cloud_persional_sync_from_cloud_success));
        }
    }

    @Override
    public void syncSettingFromServer(boolean isSuccess) {
        if (isSuccess) {
            ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_cloud_persional_sync_setting_from_cloud_success));
        } else {
            ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_cloud_persional_sync_setting_from_cloud_fail));
        }
    }

    @Override
    public void syncSettingToServer(boolean isSuccess) {
        if (isSuccess) {
            ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_cloud_persional_sync_setting_to_cloud_success));
        } else {
            ToastHelper.show(getApplicationContext(), getString(R.string.es_activity_cloud_persional_sync_setting_to_cloud_success_fail));
        }
    }

    @Override
    public void updateBackupDays(int type, int days) {
        if (type == 0) {
            // 更新合约
            if (days >=0 ) {
                mTvContractBackUp.setText(String.format(getString(R.string.es_activity_cloud_service_syn_favorite_contract_days), days));
            } else {
                mTvContractBackUp.setText(getString(R.string.es_activity_cloud_service_syn_favorite_contract_none));
            }
        } else if (type == 1) {
            if (days >=0 ) {
                mTvBackUpDays.setText(String.format(getString(R.string.es_activity_cloud_service_syn_favorite_contract_days), days));
            } else {
                mTvBackUpDays.setText(getString(R.string.es_activity_cloud_service_syn_favorite_contract_none));
            }
        }
    }

    @Override
    public void modifyPassword(boolean isSuccess, String text) {
        if (isSuccess) {
            ToastHelper.show(this, getString(R.string.es_login_password_warning_succeed));
        } else {
            ToastHelper.show(this, getString(R.string.es_login_password_warning_failed) + ", " + text);
        }
    }

    @Override
    public void syncFail() {
        ToastHelper.show(this, getString(R.string.es_activity_cloud_persional_sync_fail));
    }
}