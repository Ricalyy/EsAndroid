package com.esunny.ui.common.setting.quote.kline;

import android.view.View;
import android.widget.RelativeLayout;

import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.view.EsBaseToolBar;
import com.esunny.ui.view.EsIconTextView;


public class EsPriceCalculateActivity extends EsBaseActivity implements View.OnClickListener{


    EsBaseToolBar mToolbar;
    RelativeLayout mRlPreSettlePrice, mRlPreClosingPrice, mRlOpenPrice;
    EsIconTextView mEtvTextSettle, mEtvTextClosing, mEtvTextOpen;

    @Override
    protected int getContentView() {
        return R.layout.es_activity_price_calculate;
    }

    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
        bindViewValue();
        bindOnClick();
    }


    private void bindViewValue() {
        mToolbar.setSimpleBack(getString(R.string.es_activity_chart_setting_price_calculate));

        switch (EsSPHelperProxy.getPriceCalculateMethod()) {
            case EsSPHelperProxy.PRE_SETTLE_PRICE:
                updateTextSizeCheckUI(mEtvTextSettle);
                break;
            case EsSPHelperProxy.PRE_CLOSING_PRICE:
                updateTextSizeCheckUI(mEtvTextClosing);
                break;
            case EsSPHelperProxy.TODAY_OPEN_PRICE:
                updateTextSizeCheckUI(mEtvTextOpen);
                break;
        }
    }

    private void bindOnClick() {
        mRlPreSettlePrice.setOnClickListener(this);
        mRlPreClosingPrice.setOnClickListener(this);
        mRlOpenPrice.setOnClickListener(this);
    }

    private void bindView() {
        mToolbar = findViewById(R.id.es_activity_price_calculate_toolbar);
        mRlPreSettlePrice = findViewById(R.id.es_activity_price_calculate_settle);
        mRlPreClosingPrice = findViewById(R.id.es_activity_price_calculate_closing);
        mRlOpenPrice = findViewById(R.id.es_activity_price_calculate_open);
        mEtvTextSettle = findViewById(R.id.es_activity_etv_price_calculate_pre_settle_price);
        mEtvTextClosing = findViewById(R.id.es_activity_etv_price_calculate_pre_closing_price);
        mEtvTextOpen = findViewById(R.id.es_activity_etv_price_calculate_open_price);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.es_activity_price_calculate_settle) {
            clickToSwitch(mEtvTextSettle);
        } else if (v.getId() == R.id.es_activity_price_calculate_closing) {
            clickToSwitch(mEtvTextClosing);
        } else if (v.getId() == R.id.es_activity_price_calculate_open) {
            clickToSwitch(mEtvTextOpen);
        }
    }

    private void clickToSwitch(View view) {
            if (view == mEtvTextSettle) {
                savePriceCalculateMethod(EsSPHelperProxy.PRE_SETTLE_PRICE);
            } else if (view == mEtvTextClosing) {
                savePriceCalculateMethod(EsSPHelperProxy.PRE_CLOSING_PRICE);
            } else if (view == mEtvTextOpen) {
                savePriceCalculateMethod(EsSPHelperProxy.TODAY_OPEN_PRICE);
            }

            updateTextSizeCheckUI(view);
    }

    private void updateTextSizeCheckUI(View view) {
        mEtvTextSettle.setVisibility(View.GONE);
        mEtvTextClosing.setVisibility(View.GONE);
        mEtvTextOpen.setVisibility(View.GONE);

        view.setVisibility(View.VISIBLE);
    }

    private void savePriceCalculateMethod(int type) {
        switch (type) {
            case EsSPHelperProxy.PRE_SETTLE_PRICE:
                EsSPHelperProxy.setPriceCalculateMethod(this, EsSPHelperProxy.PRE_SETTLE_PRICE);
                break;
            case EsSPHelperProxy.PRE_CLOSING_PRICE:
                EsSPHelperProxy.setPriceCalculateMethod(this, EsSPHelperProxy.PRE_CLOSING_PRICE);
                break;
            case EsSPHelperProxy.TODAY_OPEN_PRICE:
                EsSPHelperProxy.setPriceCalculateMethod(this, EsSPHelperProxy.TODAY_OPEN_PRICE);
                break;
        }
    }
}
