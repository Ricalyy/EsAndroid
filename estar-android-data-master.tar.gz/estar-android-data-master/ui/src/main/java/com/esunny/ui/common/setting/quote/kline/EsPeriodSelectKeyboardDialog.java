package com.esunny.ui.common.setting.quote.kline;

import java.util.ArrayList;
import java.util.List;

import com.esunny.ui.R;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.view.EsCustomNumberPicker;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import androidx.annotation.NonNull;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;


public class EsPeriodSelectKeyboardDialog extends Dialog implements View.OnClickListener, DialogInterface.OnShowListener{
    private EsCustomNumberPicker mNumPicker, mTypePicker;
    private onItemSelected mOnItemSelected;
    private List<Character> mData = new ArrayList<>();

    private static int NUM_OF_MINUTE = 120;
    private static int NUM_OF_HOUR = 4;
    private static int NUM_OF_DAY = 30;
    private static int NUM_OF_WEEK = 4;
    private static int NUM_OF_MONTH = 1;

    TextView tv_cancel, tv_confirm;
    public interface onItemSelected{
        void periodSelect(int number, char type);
    }

    public EsPeriodSelectKeyboardDialog(@NonNull Context context, List<Character> list, onItemSelected onItemSelected) {
        this(context, R.style.EsTimeDialog, list, onItemSelected);
    }

    public EsPeriodSelectKeyboardDialog(@NonNull Context context, int themeResId, List<Character> list, onItemSelected onItemSelected) {
        super(context, themeResId);
        initWidget(context);
        this.mOnItemSelected = onItemSelected;
        this.mData = list;
    }

    void initWidget(Context context){
        ViewGroup ContentView = (ViewGroup) LayoutInflater.from(context).inflate(R.layout.es_period_keyboard_dialog_linearlayout,null);
        setContentView(ContentView);

        bindView();
        bindViewClick();
        initDialogParams(context);
        initPickListener();
    }

    private void bindViewClick() {
        tv_cancel.setOnClickListener(this);
        tv_confirm.setOnClickListener(this);
    }

    private void initDialogParams(Context context) {
        Window window = this.getWindow();
        WindowManager.LayoutParams wl = window.getAttributes();
        wl.height = (int)context.getResources().getDimension(R.dimen.y889);
        wl.width = context.getResources().getDisplayMetrics().widthPixels;
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        window.setAttributes(wl);
        //设置点击外围消散
        this.setCanceledOnTouchOutside(true);
        this.setCancelable(true);
        this.setOnShowListener(this);
    }

    private void initPickListener() {
        mTypePicker.setListener(new EsCustomNumberPicker.OnEsValueChangeListener() {
            @Override
            public void onValueChanged(int position, Object Value) {
                switch (position) {
                    case 0:
                        // 分
                        mNumPicker.setMaxValue(NUM_OF_MINUTE);
                        break;
                    case 1:
                        // 时
                        mNumPicker.setMaxValue(NUM_OF_HOUR);
                        break;
                    case 2:
                        // 日
                        mNumPicker.setMaxValue(NUM_OF_DAY);
                        break;
                    case 3:
                        // 周
                        mNumPicker.setMaxValue(NUM_OF_WEEK);
                        break;
                    case 4:
                        // 月
                        mNumPicker.setMaxValue(NUM_OF_MONTH);
                        break;
                    default:
                        break;
                }
                mNumPicker.setValue(1);
            }
        });
    }

    private void bindView() {
        tv_cancel = findViewById(R.id.es_period_picker_tv_cancel);
        tv_confirm = findViewById(R.id.tv_es_period_keyboard_confirm);
        mNumPicker = findViewById(R.id.numpicker_es_period_keyboard_num);
        mTypePicker = findViewById(R.id.numpicker_es_period_keyboard_type);
    }

    @Override
    public void onShow(DialogInterface dialog) {
        initPickerData();
    }

    private void initPickerData() {
        Object[] selector = new Object[mData.size()];
        for (int i = 0; i < mData.size(); i++){
            selector[i] = EsUIApi.convertKLinePeriodType(getContext(), mData.get(i));
        }
        mTypePicker.setSelector(selector);
        mNumPicker.setMaxValue(NUM_OF_MINUTE);
        mTypePicker.setRawValue(mData.get(0));
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == tv_cancel.getId()){

        }else if (v.getId() == tv_confirm.getId()){
            mOnItemSelected.periodSelect(mNumPicker.getValue(), mData.get(mTypePicker.getPosition()));
        }
        this.dismiss();
    }
}
