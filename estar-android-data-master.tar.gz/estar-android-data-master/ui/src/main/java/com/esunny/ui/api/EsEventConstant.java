package com.esunny.ui.api;

public class EsEventConstant {

    //定义发送方
    public final static int E_STAR_MODULE_QUOTE = 0;
    public final static int E_STAR_MODULE_FAVORITE = 1;
    public final static int E_STAR_MODULE_KLINE = 2;
    public final static int E_STAR_MODULE_OPTION = 3;
    public final static int E_STAR_MODULE_TRADE = 4;
    public final static int E_STAR_MODULE_LOGIN = 5;
    public final static int E_STAR_MODULE_SETTING_ACCOUNT_DETAIL = 11;
    public final static int E_STAR_MODULE_EVENT_SERVICE = 12;
    public final static int E_STAR_MODULE_MUST_TRADE = 13;

    //定义动作类型 action
    //更换出题
    public final static int E_STAR_ACTION_CHANGE_THEME = 0;
    // 打开板块左抽屉
    public final static int E_STAR_ACTION_OPEN_LEFT_DRAWER = 1;
    // 打开登录面板右抽屉
    public final static int E_STAR_ACTION_OPEN_RIGHT_DRAWER = 2;
    // 跳转交易
    public final static int E_STAR_ACTION_TO_TRADE = 3;
    // 搜索合约
    public final static int E_STAR_MODULE_SEARCH = 6;
    // 跳转页面
    public final static int E_STAR_ACTION_JUMP_PAGE = 8;
    // 选择合约
    public final static int E_STAR_ACTION_SELECT_OPTION = 10;
    // 关闭左抽屉
    public final static int E_STAR_ACTION_CLOSE_LEFT_DRAWER = 11;
    // 关闭右抽屉
    public final static int E_STAR_ACTION_CLOSE_RIGHT_DRAWER = 12;
    // 点击顶部Toolbar标题
    public final static int E_STAR_ACTION_CLICK_TITLE = 13;
    // 交易界面选择自选合约
    public final static int E_STAR_ACTION_CHOOSE_CONTRACT = 14;
    // K线界面单行标题
    public final static int E_STAR_ACTION_KLINE_TITLE_SINGLE = 15;
    // k线界面双行标题
    public final static int E_STAR_ACTION_KLINE_TITLE_DOUBLE = 16;
    // k线界面下一个合约
    public final static int E_STAR_ACTION_KLINE_NEXT_CONTRACT = 17;
    // k线界面上一个合约
    public final static int E_STAR_ACTION_KLINE_PREVIOUS_CONTRACT = 18;
    // k线界面下一个Tab
    public final static int E_STAR_ACTION_KLINE_NEXT_TAB = 1901;
    // k线界面上一个Tab
    public final static int E_STAR_ACTION_KLINE_PREVIOUS_TAB = 1902;
    // 更新行情列表
    public final static int E_STAR_ACTION_UPDATE_QUOTE_LIST = 20;
    //更新行情某一项
    public final static int E_STAR_ACTION_UPDATE_QUOTE_ITEM = 21;
    // 订阅行情
    public final static int E_STAR_ACTION_SUBSCRIBE_QUOTE = 22;
    // 跳转期权
    public final static int E_STAR_ACTION_TO_OPTION = 23;
    // 跳转行情
    public final static int E_STAR_ACTION_TO_QUOTE = 24;
    // 收取到未读消息
    public final static int E_STAR_ACTION_RECEIVE_UNREAD_MESSAGE = 25;
    // 收取到消息(无论已读未读)
    public final static int E_STAR_ACTION_RECEIVE_MESSAGE = 26;
    // 跳转资金
    public final static int E_STAR_ACTION_TO_FUNDS = 27;

    //finish 活动
    public final static int E_STAR_ACTION_FINISH_ACTIVITY = 11;
    //收取到低版本消息
    public final static int E_STAR_ACTION_IS_VERSION_LOW = 27;
    // 期权策略图刷新
    public final static int E_STAR_ACTION_REFRESH_OPTION_TACTIC = 28;
    // 工具栏状态栏颜色更新
    public final static int E_STAR_ACTION_KLINE_UPDATE_TOOLBAR = 29;
    // 跳转自选
    public final static int E_STAR_ACTION_TO_FAVORITE = 30;
    // 云条件单的待触发单数
    public final static int E_STAR_ACTION_CONDITION_NUM = 31;
    // 止损止盈单的待触发单数
    public final static int E_STAR_ACTION_STOPLP_NUM = 32;
    // 待触发策略单单数
    public final static int E_STAR_ACTION_STRATEGY_NUM = 33;
    // 正在进行交易数据初始化
    public final static int E_STAR_ACTION_LOADING_LOGIN_INIT = 34;
    // 交易数据初始化完成
    public final static int E_STAR_ACTION_LOGIN_INIT_COMPLETED = 35;
    // 证券账户切换
    public final static int E_STAR_ACTION_SWITCH_ACCOUNT = 36;
    // 备兑单开关状态切换
    public final static int E_STAR_ACTION_SWITCH_COVER = 37;
    // 价格预警服务器连接与否
    public final static int E_STAR_ACTION_PRICE_MONITOR_CONNECT = 38;
    // 已获取资金信息数据
    public final static int E_STAR_ACTION_GET_MONEY_INFO_DATA = 39;


    // 定义交易重构后的action
    public final static int E_STAR_ACTION_INSTANT_QUOTE = 40;
    // 已获取持仓数据
    public final static int E_STAR_ACTION_GET_POSITION_DATA = 41;
    // 已获取挂单数据
    public final static int E_STAR_ACTION_GET_PARORDER_DATA = 42;
    // 已获取委托数据
    public final static int E_STAR_ACTION_GET_DELEGATEORDER_DATA = 43;
    // 已获取成交数据
    public final static int E_STAR_ACTION_GET_MATCHORDER_DATA = 44;
    // 获取交易冻结值变化数据
    public final static int E_STAR_ACTION_GET_TRADE_LOCK_POSITION = 45;
    // F10数据
    public final static int E_STAR_ACTION_QUERY_F10_BY_COMMODITY = 46;
    // 将非交易界面的数据传递给交易面板
    public final static int E_STAR_ACTION_SEND_CONTRACT_TO_TRADE = 47;
    // 用户主动登出
    public final static int E_STAR_ACTION_USER_WANT_TO_LOGOUT = 48;
    // 浮盈合计变化通知
    public final static int E_STAR_ACTION_USER_FLOAT_CHANGE = 49;
    // 待触发条件单到K线然后跳转交易
    public final static int E_STAR_ACTION_TO_TRADE_AND_CLOSE_STRATEGY = 50;
    // 登出账号必须要进行判断是否从交易跳出
    public final static int E_STAR_ACTION_TO_SWITCH_FRAGMENT = 51;
    // 由于行情配置更新刷新板块
    public final static int E_STAR_ACTION_REFRESH_QUOTE_SETTING = 52;
    // 期权数据已就绪
    public final static int E_STAR_ACTION_OPTION_DATA_COMPLETED= 53;

    //k线模块动作
    public final static int E_STAR_ACTION_K_LINE_UPDATE_CONTRACT = 2000;
    public final static int E_STAR_ACTION_K_LINE_UPDATE_QUOTE = 2001;
    public final static int E_STAR_ACTION_K_LINE_UPDATE_HIS_QUOTE = 2002;
    public final static int E_STAR_ACTION_K_LINE_UPDATE_HIS_MIN = 2003;
    public final static int E_STAR_ACTION_K_LINE_UPDATE_TC_DATA = 2004;

    public final static int E_STAR_ACTION_K_LINE_CHANGE_SCREEN = 2100;
    public final static int E_STAR_ACTION_K_LINE_SCREEN_CHANGED = 2101;
    public final static int E_STAR_ACTION_K_LINE_SHOW_HIS_MIN_TICK= 2102;
    public final static int E_STAR_ACTION_K_LINE_CHANGE_PERIOD = 2103;
    public final static int E_STAR_ACTION_K_LINE_SHOW_PROGRESS = 2104;
    public final static int E_STAR_ACTION_K_LINE_HIDE_PROGRESS = 2105;
    public final static int E_STAR_ACTION_K_LINE_SHOW_DRAW_MODEL = 2106;
    public final static int E_STAR_ACTION_K_LINE_CHANGE_DRAW_LINE = 2107;
    public final static int E_STAR_ACTION_K_LINE_CHANGE_DRAW_LINE_LOTS = 2108;
    public final static int E_STAR_ACTION_K_LINE_CHANGE_DRAW_LINE_ORDER = 2109;
    public final static int E_STAR_ACTION_K_LINE_UPDATE_ORDER = 2110;
    public final static int E_STAR_ACTION_K_LINE_UPDATE_TIME_OUT = 2111;
    public final static int E_STAR_ACTION_K_LINE_UPDATE_POSITION_PRICE = 2112;
    // 音量键调节画线下单价格
    public final static int E_STAR_ACTION_K_LINE_UPDATE_DRAWLINE_PRICE = 2113;
    // 音量键调节十字光标位置
    public final static int E_STAR_ACTION_K_LINE_UPDATE_DRAW_CROSS_POSITION = 2114;

    public final static int E_STAR_ACTION_UPDATE_CLICK_ORDER_QUOTE = 1000;
    public final static int E_STAR_ACTION_UPDATE_CLICK_ORDER_ORDER = 1001;

    public final static int E_STAR_ACTION_NOTIFY_TRADE_STATE = 8000;

    public final static int E_STAR_ACTION_NOTIFY_TRADE_LOGOUT = 9000;
}
