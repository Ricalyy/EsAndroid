package com.esunny.ui.common.setting.condition.EsStrategyView;

import android.content.Context;
import androidx.annotation.Nullable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.esunny.ui.R;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.common.setting.condition.EsStrategyData.EsStrategyData;
import com.esunny.ui.util.ToastHelper;
import com.esunny.ui.view.EsIconTextView;


public class EsStrategyToolBar extends LinearLayout implements View.OnClickListener{

    public interface OnToolbarListener{
        void OnSwitch(boolean isPrice);
    }

    private Context mContext;
    private EsIconTextView mBack;
    private TextView mPriceStrategy;
    private TextView mTimeStrategy;
    private View mSlide;
    private View mSlide2;
    private LinearLayout mLlMain, mLlSub;
    private View mSubView;
    private TextView mTvPriceModify, mTvTimeModify;
    private OnToolbarListener mListener;
    private boolean mIsPrice;

    public void setOnSwitchListener(OnToolbarListener listener){
        mListener = listener;
    }

    public EsStrategyToolBar(Context context) {
        super(context);
        initWidget(context);
    }

    public EsStrategyToolBar(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        initWidget(context);
    }

    public EsStrategyToolBar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initWidget(context);
    }

    private void initWidget(Context context){
        mContext = context;
        LayoutInflater.from(context).inflate(R.layout.es_linearlayout_es_strategy_toolbar, this);
        mBack = findViewById(R.id.trade_strategy_toolbar_back_icon);
        mPriceStrategy = findViewById(R.id.trade_strategy_toolbar_price);
        mTimeStrategy = findViewById(R.id.trade_strategy_toolbar_time);
        mSlide = findViewById(R.id.trade_strategy_toolbar_slide);
        mSlide2 = findViewById(R.id.trade_strategy_toolbar_slide2);
        mLlMain = findViewById(R.id.es_strategy_toolbar_ll_main);
        mLlSub = findViewById(R.id.es_strategy_toolbar_ll_sub);
        mSubView = findViewById(R.id.es_strategy_toolbar_view_sub);
        mTvPriceModify = findViewById(R.id.trade_strategy_toolbar_price_modify);
        mTvTimeModify = findViewById(R.id.trade_strategy_toolbar_time_modify);

        mBack.setOnClickListener(this);
        mPriceStrategy.setOnClickListener(this);
        mPriceStrategy.setSelected(true);
        mIsPrice = EsStrategyData.getInstance().isPrice();
        slide(mIsPrice);
        mTimeStrategy.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.trade_strategy_toolbar_back_icon){
            ((EsBaseActivity)mContext).finish();
            //back
        }else if(v.getId() == R.id.trade_strategy_toolbar_price){
            if (EsStrategyData.getInstance().getIsModifyConditionOrder()) {
                return;
            }

            if(!mIsPrice){
                slide(true);
                mIsPrice = true;
            }

        }else if(v.getId() == R.id.trade_strategy_toolbar_time){
            if (EsStrategyData.getInstance().getIsModifyConditionOrder()) {
                return;
            }

            if(mIsPrice){
                slide(false);
                mIsPrice = false;
            }

        }
    }

    public void slide(boolean isPrice){
        mPriceStrategy.setSelected(isPrice);
        mTimeStrategy.setSelected(!isPrice);
        if(mListener!=null){
            mListener.OnSwitch(isPrice);
        }
        if(isPrice){
            mSlide.setVisibility(View.VISIBLE);
            mSlide2.setVisibility(View.INVISIBLE);
        }else {
            mSlide2.setVisibility(View.VISIBLE);
            mSlide.setVisibility(View.INVISIBLE);
        }

    }

    public void updateModifyUI(boolean isPrice) {
        mLlMain.setVisibility(View.GONE);
        mLlSub.setVisibility(View.VISIBLE);
        mSubView.setVisibility(View.VISIBLE);

        if (isPrice) {
            mTvPriceModify.setVisibility(View.VISIBLE);
            mTvPriceModify.setSelected(true);
            mTvTimeModify.setVisibility(View.GONE);
            mTvTimeModify.setSelected(false);
        } else {
            mTvPriceModify.setVisibility(GONE);
            mTvPriceModify.setSelected(false);
            mTvTimeModify.setVisibility(View.VISIBLE);
            mTvTimeModify.setSelected(true);
        }
    }
}
