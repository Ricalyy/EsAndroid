package com.esunny.ui.common.setting.trade;

import android.content.Intent;
import android.view.View;
import android.widget.RelativeLayout;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.EsBaseToolBar;

import butterknife.BindView;
import butterknife.OnClick;

@Route(path = RoutingTable.ES_TRADE_ABOUT_ACTIVITY)
public class EsTradeAboutActivity extends EsBaseActivity{

    @BindView(R2.id.activity_es_trade_about_toolbar)
    EsBaseToolBar tb_toolbar;
    @BindView(R2.id.activity_es_trade_about_rl_benefit)
    RelativeLayout mRlBenefit;

    @OnClick(R2.id.activity_es_trade_about_rl_trade_log)
    public void tradeLog() {
        startActivity(new Intent(this, EsTradeLogActivity.class));
    }
    @OnClick(R2.id.activity_es_trade_about_rl_bill_query)
    public void billQuery() {
        startActivity(new Intent(this, EsBillQueryActivity.class));
    }
    @OnClick(R2.id.activity_es_trade_about_rl_bank_transfer)
    public void bankTransfer() {
        startActivity(new Intent(this, EsBankTransferActivity.class));
    }
    @OnClick(R2.id.activity_es_trade_about_rl_update_password)
    public void updatePassword() {
        startActivity(new Intent(this, EsPasswordActivity.class));
    }
    @OnClick(R2.id.activity_es_trade_about_rl_turn_to_monitoring_center)
    public void toMonitorCenter() {
        startActivity(new Intent(this, EsMonitorCenterActivity.class));
    }

    @Override
    protected void initData() {
        super.initData();
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindViewValue();
    }

    private void bindViewValue() {
        tb_toolbar.setSimpleBack(getString(R.string.es_setting_about_trade));

        if(EsLoginAccountData.getInstance().getCurrentAccount() != null && EsLoginAccountData.getInstance().getCurrentAccount().getTradeApi().contains("Ctp")){
            mRlBenefit.setVisibility(View.VISIBLE);
        }else {
            mRlBenefit.setVisibility(View.GONE);
        }
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_trade_about;
    }

    @OnClick(R2.id.activity_es_trade_about_rl_benefit)
    public void benefit(){
        startActivity(new Intent(this, EsBenefitChartActivit.class));
    }
}
