package com.esunny.ui.common.setting.quote.kline;

import android.content.Context;
import android.view.View;

import com.esunny.ui.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import skin.support.content.res.SkinCompatResources;

public class EsIndexConfigAdapter extends EsTechnicalIndexAdapter {
    JSONObject mJson;

    public EsIndexConfigAdapter(Context mContext, List<String> mDataList) {
        super(mContext, mDataList);
    }

    public void setJsonData(JSONObject jsonData) {
        this.mJson = jsonData;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        if (position < getItemCount()) {
            holder.mDivideLine.setVisibility(View.VISIBLE);
            final String key = mDataList.get(position);
            holder.tv_technical_index_name.setText(mDataList.get(position));
            holder.tv_technical_index_name.setBackgroundColor(SkinCompatResources.getColor(mContext, R.color.es_activitty_index_config_bg_item));
            if (key == null || key.isEmpty()) {
                return;
            }
            if (mJson.has(key)) {
                try {
                    boolean isSelected = mJson.getBoolean(key);
                    if (isSelected) {
                        holder.tv_technical_index_name.setTextColor(mContext.getResources().getColor(R.color.es_activitty_index_config_text_color_selected));
                    } else {
                        holder.tv_technical_index_name.setTextColor(SkinCompatResources.getColor(mContext, R.color.es_app_update_activity_content));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                holder.tv_technical_index_name.setTextColor(mContext.getResources().getColor(R.color.es_activitty_index_config_text_color_selected));
            }

            holder.ll_main.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        if (mJson.has(key)) {
                            // 有值根据值来判断
                            boolean isSelected = mJson.getBoolean(key);
                            mJson.put(key, !isSelected);
                            if (!isSelected) {
                                holder.tv_technical_index_name.setTextColor(mContext.getResources().getColor(R.color.es_activitty_index_config_text_color_selected));
                            } else {
                                holder.tv_technical_index_name.setTextColor(SkinCompatResources.getColor(mContext, R.color.es_app_update_activity_content));
                            }
                        } else {
                            // 没值使用默认true
                            mJson.put(key, false);
                            holder.tv_technical_index_name.setTextColor(SkinCompatResources.getColor(mContext, R.color.es_app_update_activity_content));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }
}
