package com.esunny.ui.common.setting.quote.kline;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.text.InputType;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.esunny.data.bean.Contract;
import com.esunny.ui.R;
import com.esunny.ui.quote.kline.bean.KLineParam;
import com.esunny.ui.trade.view.EsTradePriceKeyboard;
import com.esunny.ui.trade.view.EsTradePriceKeyboardView;

import java.util.List;

public class EsIndexParameterAdapter extends RecyclerView.Adapter<EsIndexParameterAdapter.ViewHolder> {
    private static final String INDEX_PARAM_BOLL_SECOND = "P";
    private Context mContext;
    private List<KLineParam> mKLineParamDataList;
    private EsTradePriceKeyboard mParamKeyboard;
    public EditText mCurrentEditText;
    private String mMainKey;

    public EsIndexParameterAdapter(Context context, List<KLineParam> mKLineParamDataList) {
        this.mContext = context;
        this.mKLineParamDataList = mKLineParamDataList;
        initParamKeyboard();
    }

    private void initParamKeyboard() {
        mParamKeyboard = new EsTradePriceKeyboard(mContext, new EditText(mContext));
        mParamKeyboard.setOutsideTouchable(true);
        mParamKeyboard.setListener(new EsTradePriceKeyboardView.TradePriceKeyboardListener() {
            @Override
            public void customOnPriceKeyDown(EsTradePriceKeyboardView keyboardView, int keyId, boolean isSpecial) {

            }

            @Override
            public Contract onGetContract(EsTradePriceKeyboardView keyboardView) {
                return null;
            }

            @Override
            public double onGetLastPrice(EsTradePriceKeyboardView keyboardView) {
                return 0;
            }

            @Override
            public void onChangeValidType(EsTradePriceKeyboardView keyboardView, char ValidType) {

            }
        });
    }

    void setMainKey(String key) {
        mMainKey = key;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_index_parameter, parent, false);
        return new ViewHolder(view, true);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        if (position < getItemCount()) {
            final KLineParam currentKLineParams = mKLineParamDataList.get(position);
            if (currentKLineParams != null) {
                holder.et_value.setTag(position);
                holder.tv_key.setText(currentKLineParams.getName());
                holder.et_value.setText(currentKLineParams.getValue());
                holder.et_value.setInputType(InputType.TYPE_NULL);

                holder.et_value.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        paramKeyboardShow(v, currentKLineParams);
                    }
                });

                holder.et_value.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        mParamKeyboard.setEdit(holder.et_value);
                        mCurrentEditText = holder.et_value;
                        if (!hasFocus) {
                            if (holder.et_value.getTag().equals(position)) {
                                resetDefaultValue();
                                currentKLineParams.setValue(holder.et_value.getText().toString());
                            }
                        } else {
                            paramKeyboardShow(v, currentKLineParams);
                        }
                    }

                    private void resetDefaultValue() {
                        if (isResetDefaultValue(holder.et_value.getText().toString())) {
                            holder.et_value.setText(String.valueOf(1));
                            if (mMainKey.equals("BOLL") && currentKLineParams.getName().equals(INDEX_PARAM_BOLL_SECOND)) {
                                holder.et_value.setText(String.valueOf(1.0));
                            }
                        }
                    }
                });
            }
        }
    }

    @Override
    public int getItemCount() {
        return mKLineParamDataList.size();
    }

    private void paramKeyboardShow(View v, KLineParam currentKLineParams) {
        mParamKeyboard.setIsParam(true,mMainKey.equals("BOLL") && currentKLineParams.getName().equals(INDEX_PARAM_BOLL_SECOND));
        mParamKeyboard.EnableDecimalPoint(mMainKey.equals("BOLL") && currentKLineParams.getName().equals(INDEX_PARAM_BOLL_SECOND));
        mParamKeyboard.showAtLocation(v.getRootView(), Gravity.BOTTOM, 0, 0);
    }


    private boolean isResetDefaultValue(String string) {
        return (Double.parseDouble(string) == 0) && !(mMainKey.equals("MA") || mMainKey.equals("EMA") || mMainKey.equals("SMA") || mMainKey.equals("PUBU"));
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tv_key;
        EditText et_value;

        public ViewHolder(View itemView, boolean isItem) {
            super(itemView);
            if (isItem){
                tv_key = itemView.findViewById(R.id.es_item_index_parameter_tv_key);
                et_value = itemView.findViewById(R.id.es_item_index_parameter_et_value);
            }
        }
    }
}
