package com.esunny.ui.common;

import android.content.Context;

import com.esunny.ui.BasePresenter;
import com.esunny.ui.common.EsBaseFragment;

public abstract class EsMvpFragment<T extends BasePresenter> extends EsBaseFragment {
    protected T mPresenter;
    protected abstract T createPresenter();

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mPresenter = createPresenter();
        if (mPresenter != null) {
            mPresenter.attactView(this);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mPresenter != null) {
            mPresenter.detachView();
        }
    }
}
