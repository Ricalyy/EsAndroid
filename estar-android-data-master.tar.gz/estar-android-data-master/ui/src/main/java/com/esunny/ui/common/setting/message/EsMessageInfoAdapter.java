package com.esunny.ui.common.setting.message;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.esunny.data.bean.MessageData;
import com.esunny.ui.R;
import com.esunny.ui.util.EsSPHelper;
import java.util.List;


/**
 * Created by Peter on 2018/1/25.
 */

public class EsMessageInfoAdapter extends RecyclerView.Adapter<EsMessageInfoAdapter.ViewHolder> {
    private Context mContext;
    private List<MessageData> mMessageData;

    public EsMessageInfoAdapter(Context context, List<MessageData> messageData) {
        this.mContext = context;
        this.mMessageData = messageData;
    }

    private MessageData getItem(int position) {
        if (position < mMessageData.size())
            return mMessageData.get(position);
        else return null;
    }

    public void clear(){
        mMessageData.clear();
        this.notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_message_info, parent, false);
        return new ViewHolder(view, true);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (position < getItemCount()) {
            final MessageData messageData = getItem(position);
            if (messageData != null){
                holder.tv_title.setText(messageData.getTitle());
                holder.tv_content.setText(messageData.getContent());
                holder.tv_date.setText(messageData.getSendDateTime());

                // Show the UnRead Icon according to the status of meeage.
                if (EsSPHelper.getMessageHasBeenRead(mContext, messageData.getMsgId())){
                    holder.tv_message_status.setVisibility(View.GONE);
                }else {
                    holder.tv_message_status.setVisibility(View.VISIBLE);
                }

                holder.rl_main.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // Record the status of message.
                        EsSPHelper.setMessageHasBeenRead(mContext, messageData.getMsgId(), true);

                        // Jump to the meesage detailed content.
                        Intent intent = new Intent(mContext, EsMessageDetailActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("messageData", messageData);
                        intent.putExtras(bundle);
                        mContext.startActivity(intent);
                    }
                });
            }
        }
    }

    @Override
    public int getItemCount() {
        return mMessageData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_title;
        public TextView tv_content;
        public TextView tv_date;
        public LinearLayout rl_main;
        public TextView tv_message_status;

        public ViewHolder(View itemView, boolean isItem) {
            super(itemView);
            if (isItem){
                tv_title = itemView.findViewById(R.id.es_item_message_info_tv_title);
                tv_content = itemView.findViewById(R.id.es_item_message_info_tv_content);
                tv_date = itemView.findViewById(R.id.es_item_message_info_tv_date);
                rl_main = itemView.findViewById(R.id.es_item_message_info_rl_main);
                tv_message_status = itemView.findViewById(R.id.es_item_message_info_tv_message_status);
            }
        }
    }
}
