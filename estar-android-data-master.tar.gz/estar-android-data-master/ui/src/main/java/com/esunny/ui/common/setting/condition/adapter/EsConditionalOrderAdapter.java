package com.esunny.ui.common.setting.condition.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.util.EstarTransformation;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.OrderData;
import com.esunny.ui.R;
import com.esunny.ui.util.ButtonUtils;
import com.esunny.ui.util.EsCommonUtil;
import com.esunny.ui.util.EstarFieldTransformation;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class EsConditionalOrderAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int TYPE_ITEM = 1;
    private final int TYPE_FOOT = 2;

    public static final int ListTypeCondition = 0;
    public static final int ListTypeStopLossProfit = 1;

    private Context mContext;
    private int mOpenedIndex = -1;
    private int mListType = ListTypeStopLossProfit;
    private OnItemClick mOnItemClick;
    private List<OrderData> mOrderData = new ArrayList<>();
    private SparseArray<PopupWindow> mPopupWindowHashMap = new SparseArray<>();

    public void setOrderData(List<OrderData> data) {
        if (data != null) {
            mOrderData = data;
        }
    }

    public OnItemClick getOnItemClick() {
        return mOnItemClick;
    }

    public void setOnItemClick(OnItemClick onItemClick) {
        mOnItemClick = onItemClick;
    }

    public interface OnItemClick {
        /**
         * @param action S_OAT_CANCEL S_OAT_SUSPEND S_OAT_RESUME
         * @param data   操作数据
         */
        void itemClick(char action, OrderData data);

        void toKLine(String contractNo);

        void modifyConditionOrder(OrderData orderData);

        void deleteAllOrder(List<OrderData> orderDataList, PopupWindow popupWindow, SparseArray<PopupWindow> popupWindowHashMap);
    }

    /**
     * @param listType 0 condition  1 stopLossProfit
     */
    public void setListType(int listType) {
        mListType = listType;
    }

    public void reSetOpenedIndex() {
        mOpenedIndex = -1;
        notifyDataSetChanged();
    }

    public void resetPopupWindow() {
        mOpenedIndex = -1;

        int count = mPopupWindowHashMap.size();
        for (int i = 0; i < count; i++) {
            PopupWindow popupWindow = mPopupWindowHashMap.get(i);
            if (popupWindow != null && popupWindow.isShowing()) {
                popupWindow.dismiss();
            }
        }

        if (mOrderData.size() <= 1 && mFootPopupWindow != null) {
            mFootPopupWindow.dismiss();
        }
    }

    public EsConditionalOrderAdapter(Context context) {
        this.mContext = context;
    }

    @Override
    public int getItemViewType(int position) {
        if (mListType == ListTypeCondition && mOrderData.size() > 1 && position == getItemCount() - 1) {
            return TYPE_FOOT;
        } else {
            return TYPE_ITEM;
        }
//        return super.getItemViewType(position);
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        if (mListType == ListTypeCondition) {
            if (viewType == TYPE_FOOT) {
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_trade_item_condition_foot, parent, false);
                return new FootViewHolder(view);
            }
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_cloud_conditional_order, parent, false);
            return new ViewHolder(view, true);
        } else {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.es_item_cloud_stop_loss_profit_order, parent, false);
            return new ViewHolder(view, true);
        }
    }

    View footPopupWindowParent;
    PopupWindow mFootPopupWindow;

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, final int position) {
        if (viewHolder instanceof  FootViewHolder) {
            final FootViewHolder footViewHolder = (FootViewHolder)viewHolder;
            footViewHolder.mTvPlaceHolder.setVisibility(View.GONE);

//            showBelowView(footViewHolder.mFootPopupWindow, footViewHolder.mRlMain, 0);
            footPopupWindowParent = footViewHolder.mRlMain;
            mFootPopupWindow = footViewHolder.mFootPopupWindow;
            showFootPopupWindow();

            footViewHolder.mTvDeleteAll.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // 实现不优雅，等想到更优雅的方式就替换掉
                    mOnItemClick.deleteAllOrder(mOrderData, mFootPopupWindow, mPopupWindowHashMap);
                }
            });
        } else {
            if (position < getItemCount()) {
                ViewHolder holder = (ViewHolder) viewHolder;
                final OrderData orderData = getItem(position);
                if (orderData != null) {
                    final String contractNo = orderData.getContractNo();
                    final Contract contract = EsDataApi.getQuoteContract(orderData.getContractNo());
                    String contractName;
                    if (contract != null) {
                        contractName = contract.getContractName();
                    } else {
                        contractName = EsDataApi.getContractName(orderData.getContractNo());
                        if (contractName == null) {
                            contractName = contractNo;
                        }
                    }
                    String status = EstarTransformation.OrderState2String(mContext, orderData.getOrderState(), orderData.getOrderType());
                    String type;
                    String condition;
                    String bonusCondition;
                    char strategyType = orderData.getStrategyType();
                    if (strategyType == EsDataConstant.S_ST_AUTOORDER) {
                        // 自动单
                        condition = mContext.getString(R.string.es_strategy_time_keyboard_opentrigger);
                        type = mContext.getString(R.string.es_strategy_input_auto_order);
                    } else if (strategyType == EsDataConstant.S_ST_CONDITION
                            || strategyType == EsDataConstant.S_ST_CONDITION_PARENT
                            || strategyType == EsDataConstant.S_ST_BACKHAND) {//条件单条件
                        if (orderData.getTimeCondition().length() == 0 && orderData.getTriggerCondition() != 0) {
                            double price = orderData.getTriggerPrice();
                            String priceStr;
                            if (contract != null) {
                                priceStr = EsDataApi.formatPrice(contract.getCommodity(), price);
                            } else {
                                priceStr = Double.toString(price);
                            }
                            condition = String.format(Locale.getDefault(), "%s%s%s", EstarTransformation.triggerModeType2Str(mContext, orderData.getTriggerMode()), EstarTransformation.conditionCompareType2Str(orderData.getTriggerCondition()), priceStr);
                            type = mContext.getString(R.string.es_strategy_condition_type_price);
                        } else {
                            condition = orderData.getTimeCondition();
                            type = mContext.getString(R.string.es_strategy_condition_type_time);
                        }
                        if (strategyType == EsDataConstant.S_ST_BACKHAND) {
                            type += "\n-" + mContext.getString(R.string.es_reverse_postion_order_name);
                        } else if (strategyType == EsDataConstant.S_ST_CONDITION_PARENT) {
                            type += "\n-" + mContext.getString(R.string.es_setting_stop_trade);
                        }
                    } else {//止损单条件
                        type = EstarTransformation.StrategyType2String(mContext, strategyType);
                        if (contract != null) {
                            condition = String.format(Locale.getDefault(), "%s %s", EstarTransformation.stopPriceType2Str(mContext, orderData.getStopPriceType()), EsDataApi.formatPrice(contract.getCommodity(), orderData.getStopPrice()));
                        } else {
                            condition = String.format(Locale.getDefault(), "%s %s", EstarTransformation.stopPriceType2Str(mContext, orderData.getStopPriceType()), Double.toString(orderData.getStopPrice()));
                        }
                    }

                    if (orderData.getTriggerCondition2() != 0 && (strategyType == EsDataConstant.S_ST_CONDITION || strategyType == EsDataConstant.S_ST_CONDITION_PARENT
                            || strategyType == EsDataConstant.S_ST_BACKHAND)) {//附加条件
                        double price = orderData.getTriggerPrice2();
                        String priceStr;
                        if (contract != null) {
                            priceStr = EsDataApi.formatPrice(contract.getCommodity(), price);
                        } else {
                            priceStr = Double.toString(price);
                        }
                        bonusCondition = String.format(Locale.getDefault(), "%s%s%s", EstarTransformation.triggerModeType2Str(mContext, orderData.getTriggerMode2()), EstarTransformation.conditionCompareType2Str(orderData.getTriggerCondition2()), priceStr);
                    } else {
                        bonusCondition = mContext.getString(R.string.es_strategy_bonus_condition_null);
                    }

                    String direct = EstarTransformation.Direct2BuySellString(mContext, orderData.getDirect()) + EstarTransformation.Offset2String(mContext, orderData.getOffset());
                    String qty = orderData.getOrderQty().toString();
                    String avTime = EstarTransformation.conditionValidType2Str(mContext, orderData.getValidType());
                    String insertTime = orderData.getInsertDateTime();
                    String orderPrice;

                    if (orderData.getOrderPriceType() == EsDataConstant.S_PT_ABS) {
                        if (contract != null) {
                            orderPrice = EsDataApi.formatPrice(contract.getCommodity(), orderData.getOrderPrice());
                        } else {
                            orderPrice = EsCommonUtil.formatDouble(orderData.getOrderPrice());
                        }
                    } else {
                        orderPrice = EstarTransformation.apiPriceTypeToStr(mContext, orderData.getOrderPriceType());
                        if (orderData.getOrderPriceOver() != 0 && contract != null) {
                            if (orderData.getOrderPriceOver() < 0) {
                                orderPrice = orderPrice + (int) (orderData.getOrderPriceOver() / contract.getCommodity().getTickPrice()) + mContext.getString(R.string.es_strategy_condition_list_tick);
                            } else {
                                orderPrice = orderPrice + "+" + (int) (orderData.getOrderPriceOver() / contract.getCommodity().getTickPrice()) + mContext.getString(R.string.es_strategy_condition_list_tick);
                            }
                        }
                    }
                    holder.mTvContractNo.setText(contractName);
                    holder.mTvStatus.setText(status);
                    holder.mTvStatus.setTextColor(EstarFieldTransformation.getOrderStateColor(mContext, orderData.getOrderState()));
                    holder.mTvType.setText(type);
                    holder.mTvCondition.setText(condition);
                    holder.mTvDirect.setText(direct);
                    holder.mTvQty.setText(qty);
                    holder.mTvAvTime.setText(avTime);
                    holder.mTvOrderPrice.setText(orderPrice);
                    holder.mTvInsertTime.setText(insertTime);
                    if (mListType == ListTypeCondition) {
                        holder.mTvBoundCondition.setText(bonusCondition);
                        holder.mTvDelegateType.setText(EstarTransformation.delegateWayToStr(mContext, orderData.getOrderWay()));
                    }
                    if (orderData.getErrorText() != null) {
                        holder.mTvFeedback.setText(orderData.getErrorText());
                    } else {
                        holder.mTvFeedback.setText("");
                    }

                    String hedgeString = EstarTransformation.Hedge2String(mContext, orderData.getHedge(), contractNo) ;
                    holder.mTvHedge.setText(hedgeString);

                    if (holder.mTvModify != null) {
                        holder.mTvModify.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mOnItemClick.modifyConditionOrder(orderData);
                            }
                        });
                        if (strategyType ==  EsDataConstant.S_ST_CONDITION_PARENT) {
                            holder.mTvModify.setText(mContext.getString(R.string.es_trade_item_trade_parorder_button_suborder));
                        } else {
                            holder.mTvModify.setText(mContext.getString(R.string.es_trade_item_trade_parorder_button_change));
                        }
                    }

                    if (holder.mTvKLine != null) {
                        if (orderData.getOrderWay() == EsDataConstant.S_ORDERWAY_DRAWLINE
                                || orderData.getOrderWay() == EsDataConstant.S_ORDERWAY_PROXY_DRAWLINE) {
                            // 对于所有画线下单类型需额外显示为划线下单
                            holder.mTvType.setText(R.string.es_kline_bottom_draw_line);
                        }
                        holder.mTvKLine.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
//                                EstarApi.startEsKLineActivity(contractNo);
                                mOnItemClick.toKLine(contractNo);
                            }
                        });
                    }

                    String text = "";
                    if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_TRIGGERING || orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTTRIGGERED) {
                        text = mContext.getString(R.string.es_strategy_condition_list_suspend);
                        holder.mTvSuspendOrResume.setVisibility(View.VISIBLE);
                    } else if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_SUSPENDED) {
                        text = mContext.getString(R.string.es_strategy_condition_list_resume);
                        holder.mTvSuspendOrResume.setVisibility(View.VISIBLE);
                    } else {
                        //其他状态应该隐藏  挂起、激活按钮
                        holder.mTvSuspendOrResume.setVisibility(View.GONE);
                    }
                    holder.mTvSuspendOrResume.setText(text);
                    holder.mTvRevoke.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (mOnItemClick != null) {
                                mOnItemClick.itemClick(EsDataConstant.S_OAT_CANCEL, orderData);
                            }
                            reSetOpenedIndex();
                        }
                    });

                    holder.mTvSuspendOrResume.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_TRIGGERING || orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTTRIGGERED) {
                                if (mOnItemClick != null) {
                                    mOnItemClick.itemClick(EsDataConstant.S_OAT_SUSPEND, orderData);
                                }
                            } else if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_SUSPENDED) {
                                if (mOnItemClick != null) {
                                    mOnItemClick.itemClick(EsDataConstant.S_OAT_RESUME, orderData);
                                }
                            }
                            reSetOpenedIndex();
                        }
                    });

                    if (mPopupWindowHashMap.get(position) != null) {
                        mPopupWindowHashMap.get(position).dismiss();
                    }
                    mPopupWindowHashMap.put(position, holder.mPopupWindow);
                    bind(holder, position);

                    if (holder.mLlAllMain != null) {
                        holder.mLlAllMain.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (!ButtonUtils.isFastDoubleClick(v.getId())) {
                                    if (mOpenedIndex == position) {
                                        reSetOpenedIndex();
                                    } else {
                                        reSetOpenedIndex();
                                        mOpenedIndex = position;
                                        notifyItemChanged(position);
                                    }
                                }
                            }
                        });
                    }
                }
            }
        }
    }

    private void showFootPopupWindow() {
        if (footPopupWindowParent == null || mFootPopupWindow == null) return;
        mFootPopupWindow.dismiss();

        final int[] location = new int[2];
        footPopupWindowParent.postDelayed(new Runnable() {
            @Override
            public void run() {
                footPopupWindowParent.getLocationOnScreen(location);
                if (mOrderData.size() <= 1) return;
                mFootPopupWindow.showAtLocation(footPopupWindowParent, 0, 0, location[1]);
            }
        }, 50);
    }

//    @Override
//    public void onBindViewHolder(final ViewHolder holder, final int position) {
//        if (position < getItemCount()) {
//            final OrderData orderData = getItem(position);
//            if (orderData != null) {
//                final String contractNo = orderData.getContractNo();
//                final Contract contract = EsDataApi.getQuoteContract(orderData.getContractNo());
//                String contractName;
//                if (contract != null) {
//                    contractName = contract.getContractName();
//                } else {
//                    contractName = EsDataApi.getContractName(orderData.getContractNo());
//                    if (contractName == null) {
//                        contractName = contractNo;
//                    }
//                }
//                String status = EstarTransformation.OrderState2String(mContext, orderData.getOrderState(), orderData.getOrderType());
//                String type;
//                String condition;
//                String bonusCondition;
//                if (orderData.getStrategyType() == EsDataConstant.S_ST_AUTOORDER) {
//                    // 自动单
//                    condition = mContext.getString(R.string.es_strategy_time_keyboard_opentrigger);
//                    type = mContext.getString(R.string.es_strategy_condition_type_time);
//                } else if (orderData.getStrategyType() == EsDataConstant.S_ST_CONDITION) {//条件单条件
//                    if (orderData.getTimeCondition().length() == 0 && orderData.getTriggerCondition() != 0) {
//                        double price = orderData.getTriggerPrice();
//                        String priceStr;
//                        if (contract != null) {
//                            priceStr = EsDataApi.formatPrice(contract.getCommodity(), price);
//                        } else {
//                            priceStr = Double.toString(price);
//                        }
//                        condition = String.format(Locale.getDefault(), "%s%s%s", EstarTransformation.triggerModeType2Str(mContext, orderData.getTriggerMode()), EstarTransformation.conditionCompareType2Str(orderData.getTriggerCondition()), priceStr);
//                        type = mContext.getString(R.string.es_strategy_condition_type_price);
//                    } else {
//                        condition = orderData.getTimeCondition();
//                        type = mContext.getString(R.string.es_strategy_condition_type_time);
//                    }
//                } else {//止损单条件
//                    type = EstarTransformation.StrategyType2String(mContext, orderData.getStrategyType());
//                    if (contract != null) {
//                        condition = String.format(Locale.getDefault(), "%s %s", EstarTransformation.stopPriceType2Str(mContext, orderData.getStopPriceType()), EsDataApi.formatPrice(contract.getCommodity(), orderData.getStopPrice()));
//                    } else {
//                        condition = String.format(Locale.getDefault(), "%s %s", EstarTransformation.stopPriceType2Str(mContext, orderData.getStopPriceType()), Double.toString(orderData.getStopPrice()));
//                    }
//                }
//
//                if (orderData.getTriggerCondition2() != 0 && orderData.getStrategyType() == EsDataConstant.S_ST_CONDITION) {//附加条件
//                    double price = orderData.getTriggerPrice2();
//                    String priceStr;
//                    if (contract != null) {
//                        priceStr = EsDataApi.formatPrice(contract.getCommodity(), price);
//                    } else {
//                        priceStr = Double.toString(price);
//                    }
//                    bonusCondition = String.format(Locale.getDefault(), "%s%s%s", EstarTransformation.triggerModeType2Str(mContext, orderData.getTriggerMode2()), EstarTransformation.conditionCompareType2Str(orderData.getTriggerCondition2()), priceStr);
//                } else {
//                    bonusCondition = mContext.getString(R.string.es_strategy_bonus_condition_null);
//                }
//
//                String direct = EstarTransformation.Direct2BuySellString(mContext, orderData.getDirect()) + EstarTransformation.Offset2String(mContext, orderData.getOffset());
//                String qty = orderData.getOrderQty().toString();
//                String avTime = EstarTransformation.conditionValidType2Str(mContext, orderData.getValidType());
//                String insertTime = orderData.getInsertDateTime();
//                String orderPrice;
//
//                if (orderData.getOrderPriceType() == EsDataConstant.S_PT_ABS) {
//                    if (contract != null) {
//                        orderPrice = EsDataApi.formatPrice(contract.getCommodity(), orderData.getOrderPrice());
//                    } else {
//                        orderPrice = EsCommonUtil.formatDouble(orderData.getOrderPrice());
//                    }
//                } else {
//                    orderPrice = EstarTransformation.apiPriceTypeToStr(mContext, orderData.getOrderPriceType());
//                    if (orderData.getOrderPriceOver() != 0 && contract != null) {
//                        if (orderData.getOrderPriceOver() < 0) {
//                            orderPrice = orderPrice + (int) (orderData.getOrderPriceOver() / contract.getCommodity().getTickPrice()) + mContext.getString(R.string.es_strategy_condition_list_tick);
//                        } else {
//                            orderPrice = orderPrice + "+" + (int) (orderData.getOrderPriceOver() / contract.getCommodity().getTickPrice()) + mContext.getString(R.string.es_strategy_condition_list_tick);
//                        }
//                    }
//                }
//                holder.mTvContractNo.setText(contractName);
//                holder.mTvStatus.setText(status);
//                holder.mTvStatus.setTextColor(EstarFieldTransformation.getOrderStateColor(mContext, orderData.getOrderState()));
//                holder.mTvType.setText(type);
//                holder.mTvCondition.setText(condition);
//                holder.mTvDirect.setText(direct);
//                holder.mTvQty.setText(qty);
//                holder.mTvAvTime.setText(avTime);
//                holder.mTvOrderPrice.setText(orderPrice);
//                holder.mTvInsertTime.setText(insertTime);
//                if (mListType == ListTypeCondition) {
//                    holder.mTvBoundCondition.setText(bonusCondition);
//                    holder.mTvDelegateType.setText(EstarTransformation.delegateWayToStr(mContext, orderData.getOrderWay()));
//                }
//                if (orderData.getErrorText() != null) {
//                    holder.mTvFeedback.setText(orderData.getErrorText());
//                } else {
//                    holder.mTvFeedback.setText("");
//                }
//
//                if (holder.mTvModify != null) {
//                    holder.mTvModify.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            mOnItemClick.modifyConditionOrder(orderData);
//                        }
//                    });
//                }
//
//                if (holder.mTvKLine != null) {
//                    if (orderData.getOrderWay() == EsDataConstant.S_ORDERWAY_DRAWLINE
//                            || orderData.getOrderWay() == EsDataConstant.S_ORDERWAY_PROXY_DRAWLINE) {
//                        // 对于所有画线下单类型需额外显示为划线下单
//                        holder.mTvType.setText(R.string.es_kline_bottom_draw_line);
//                    }
//                    holder.mTvKLine.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
////                                EstarApi.startEsKLineActivity(contractNo);
//                            mOnItemClick.toKLine(contractNo);
//                        }
//                    });
//                }
//
//                String text = "";
//                if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_TRIGGERING || orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTTRIGGERED) {
//                    text = mContext.getString(R.string.es_strategy_condition_list_suspend);
//                    holder.mTvSuspendOrResume.setVisibility(View.VISIBLE);
//                } else if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_SUSPENDED) {
//                    text = mContext.getString(R.string.es_strategy_condition_list_resume);
//                    holder.mTvSuspendOrResume.setVisibility(View.VISIBLE);
//                } else {
//                    //其他状态应该隐藏  挂起、激活按钮
//                    holder.mTvSuspendOrResume.setVisibility(View.GONE);
//                }
//                holder.mTvSuspendOrResume.setText(text);
//                holder.mTvRevoke.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        if (mOnItemClick != null) {
//                            mOnItemClick.itemClick(EsDataConstant.S_OAT_CANCEL, orderData);
//                        }
//                        reSetOpenedIndex();
//                    }
//                });
//
//                holder.mTvSuspendOrResume.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_TRIGGERING || orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTTRIGGERED) {
//                            if (mOnItemClick != null) {
//                                mOnItemClick.itemClick(EsDataConstant.S_OAT_SUSPEND, orderData);
//                            }
//                        } else if (orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_SUSPENDED) {
//                            if (mOnItemClick != null) {
//                                mOnItemClick.itemClick(EsDataConstant.S_OAT_RESUME, orderData);
//                            }
//                        }
//                        reSetOpenedIndex();
//                    }
//                });
//
//                if (mPopupWindowHashMap.get(position) != null) {
//                    mPopupWindowHashMap.get(position).dismiss();
//                }
//                mPopupWindowHashMap.put(position, holder.mPopupWindow);
//                bind(holder, position);
//
//                if (holder.mLlAllMain != null) {
//                    holder.mLlAllMain.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View v) {
//                            if (!ButtonUtils.isFastDoubleClick(v.getId())) {
//                                if (mOpenedIndex == position) {
//                                    reSetOpenedIndex();
//                                } else {
//                                    reSetOpenedIndex();
//                                    mOpenedIndex = position;
//                                    notifyItemChanged(position);
//                                }
//                            }
//                        }
//                    });
//                }
//            }
//        }
//    }

    public void recoverList() {
        if (mOpenedIndex != -1) {
            mOpenedIndex = -1;
            notifyDataSetChanged();
        }
    }

    private void bind(ViewHolder holder, int pos) {
        showFootPopupWindow();
        PopupWindow popupWindow = mPopupWindowHashMap.get(pos);
        if (popupWindow == null) {
            return;
        }
        if (pos == mOpenedIndex && pos > -1 && mOrderData.get(pos).getOrderState() != EsDataConstant.S_ORDERSTATE_CANCELED && !popupWindow.isShowing()) {
            holder.mLlRevoke.setVisibility(View.VISIBLE);
            showBelowView(popupWindow, holder.mLlMain, pos);
            holder.mLlMain.setBackgroundResource(R.color.es_bg_ll_condition_order_main_content);
            holder.mLlRevoke.setBackgroundResource(R.color.es_bg_ll_condition_order_main_content);
        } else {
            holder.mLlRevoke.setVisibility(View.GONE);
            popupWindow.dismiss();
            holder.mLlMain.setBackgroundResource(R.color.es_bg_item_condition_order);
        }
    }

    private void showBelowView(final PopupWindow popupWindow, final View parent, final int position) {
        if (parent != null && parent.getVisibility() == View.GONE) {
            popupWindow.showAtLocation(parent, 0, 0, 0);
        } else if (parent != null) {
            final int[] location = new int[2];
            parent.postDelayed(new Runnable() {
                @Override
                public void run() {
                    parent.getLocationOnScreen(location);
                    popupWindow.showAtLocation(parent, 0, 0, location[1] + mContext.getResources().getDimensionPixelOffset(R.dimen.y144));
                }
            }, 50);
        }
    }

    @Override
    public int getItemCount() {
        if (mListType == ListTypeCondition && mOrderData != null && mOrderData.size() > 1) {
            return mOrderData.size() + 1;
        } else {
            return mOrderData == null ? 0 : mOrderData.size();
        }
    }

    private OrderData getItem(int position) {
        if (position < mOrderData.size()) {
            return mOrderData.get(position);
        } else {
            return null;
        }
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView mTvContractNo;
        TextView mTvStatus;
        TextView mTvType;
        TextView mTvCondition;
        TextView mTvBoundCondition;
        TextView mTvDirect;
        TextView mTvQty;
        TextView mTvOrderPrice;
        TextView mTvAvTime;
        TextView mTvInsertTime;
        LinearLayout mLlRevoke;
        TextView mTvRevoke;
        TextView mTvKLine;
        TextView mTvModify;
        TextView mTvSuspendOrResume;
        LinearLayout mLlMain;
        View mButtonMarginEnd;
        PopupWindow mPopupWindow;
        private LinearLayout mLlAllMain;
        TextView mTvFeedback;
        TextView mTvHedge;
        // 委托来源
        TextView mTvDelegateType;

        // 实例化
        //该adapter是由云条件单列表和止损止盈单列表复用
        //当某个列表添加新的控件时，而另一个列表不需要该空间
        //就会导致该空间在获取时为NULL，调用之后出现NPE
        //因此，新增控件请根据需要做好空指针判断
        ViewHolder(View itemView, boolean isItem) {
            super(itemView);
            if (isItem) {
                mTvContractNo = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_contract_no);
                mTvStatus = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_status);
                mTvType = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_type);
                mTvCondition = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_condition);
                mTvDirect = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_direct);
                mTvQty = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_qty);
                mTvOrderPrice = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_orderPrice);
                mTvAvTime = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_validType);
                mTvInsertTime = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_insertTime);
                mLlRevoke = itemView.findViewById(R.id.es_item_cloud_conditional_order_rl_revoke);
                mButtonMarginEnd = itemView.findViewById(R.id.es_item_cloud_conditional_order_paddingEnd);
                mLlMain = itemView.findViewById(R.id.es_item_conditional_order_ll_main);
                mLlAllMain = itemView.findViewById(R.id.es_item_cloud_conditional_order_ll_main);
                mTvFeedback = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_feedback);
                mTvHedge = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_hedge);

                View view = LayoutInflater.from(mContext).inflate(R.layout.es_strategy_conditional_order_popupwindow, null);
                mPopupWindow = new PopupWindow(view, mContext.getResources().getDimensionPixelSize(R.dimen.x1080), mContext.getResources().getDimensionPixelSize(R.dimen.y140));
                mPopupWindow.setFocusable(false);
                mPopupWindow.setOutsideTouchable(false);
                mPopupWindow.update();

                mTvSuspendOrResume = mPopupWindow.getContentView().findViewById(R.id.es_item_cloud_conditional_order_tv_suspend);
                mTvKLine = mPopupWindow.getContentView().findViewById(R.id.es_item_cloud_conditional_order_tv_kline);
                mTvModify = mPopupWindow.getContentView().findViewById(R.id.es_item_cloud_conditional_order_tv_modify);
                mTvRevoke = mPopupWindow.getContentView().findViewById(R.id.es_item_cloud_conditional_order_tv_revoke);

                if (mListType == ListTypeCondition) {
                    mTvBoundCondition = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_bonus);
                    mTvDelegateType = itemView.findViewById(R.id.es_item_cloud_conditional_order_tv_delegate_type);
                    mTvKLine.setVisibility(View.VISIBLE);
                    mTvModify.setVisibility(View.VISIBLE);
                } else {
                    mTvKLine.setVisibility(View.INVISIBLE);
                    mTvModify.setVisibility(View.INVISIBLE);
                }
            }
        }

    }

    private class FootViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout mRlMain;
        TextView mTvPlaceHolder;
        TextView mTvDeleteAll;
        PopupWindow mFootPopupWindow;

        FootViewHolder(View itemView) {
            super(itemView);
            mRlMain = itemView.findViewById(R.id.es_trade_item_condition_rl_main);
            mTvPlaceHolder = itemView.findViewById(R.id.es_trade_item_condition_delete_all);
            mTvPlaceHolder.setVisibility(View.GONE);

            View view = LayoutInflater.from(mContext).inflate(R.layout.es_trade_item_condition_foot, null);
            mFootPopupWindow = new PopupWindow(view, mContext.getResources().getDimensionPixelSize(R.dimen.x1080), mContext.getResources().getDimensionPixelSize(R.dimen.y140));
            mFootPopupWindow.setFocusable(false);
            mFootPopupWindow.setOutsideTouchable(false);
            mFootPopupWindow.update();

            mTvDeleteAll = mFootPopupWindow.getContentView().findViewById(R.id.es_trade_item_condition_delete_all);
        }
    }
}
