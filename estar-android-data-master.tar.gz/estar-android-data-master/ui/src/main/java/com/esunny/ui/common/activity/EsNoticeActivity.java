package com.esunny.ui.common.activity;

import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.bean.NotifyInfo;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.util.EsSPHelper;

import butterknife.BindView;
import butterknife.OnClick;

@Route(path = RoutingTable.ES_NOTICE_ACTIVITY)
public class EsNoticeActivity extends EsBaseActivity {

    private NotifyInfo mNotifyInfo;
    private String mUrl;

    @BindView(R2.id.es_notice_webView)
    WebView mWebView;
    @BindView(R2.id.es_activity_notice_tv_confirm)
    TextView mTvConfirm;

    @Override
    protected void initData() {
        super.initData();

        mNotifyInfo = EsDataApi.getNotifyInfo();
        if (mNotifyInfo != null) {
            mUrl = mNotifyInfo.getMsgNotifyData();
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();

        mWebView.loadUrl(mUrl);
        mWebView.setFocusable(true);
        mWebView.getSettings().setTextZoom(100);
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);//测试阶段不适用缓存，方便调试
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.setBackgroundColor(0);
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });
        //设置不用系统浏览器打开,直接显示在当前Webview
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                mWebView.loadUrl(url);
                return true;
            }
        });
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_notice;
    }

    @OnClick(R2.id.es_activity_notice_tv_confirm)
    public void confirm(){
        EsSPHelper.setNoticeId(this, mNotifyInfo.getMsgNotifyID());
        EsUIApi.startStartLoadingActivity(this.getClass().getSimpleName(), EsUIConstant.S_NOTICE_RESULT_CODE_CONFIRM);
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK)
            return true;

        return super.onKeyDown(keyCode, event);
    }
}
