package com.esunny.ui.common.setting.trade;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.ui.R;
import com.esunny.ui.R2;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.dialog.EsCustomTipsDialog;
import com.esunny.ui.data.setting.EsLoginAccountData;
import com.esunny.ui.view.EsCustomRelativeLayout;
import com.esunny.ui.view.EsCustomerToast;
import com.esunny.ui.view.EsIconTextView;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import butterknife.BindView;

public class EsPasswordActivity extends EsBaseActivity implements View.OnClickListener, TextWatcher {

    @BindView(R2.id.es_activity_password_etv_back)
    EsIconTextView etv_back;
    @BindView(R2.id.es_activity_password_tv_trade_password)
    TextView tv_trade_password;
    @BindView(R2.id.es_activity_password_tv_money_password)
    TextView tv_money_password;
    @BindView(R2.id.es_activity_password_view_trade_password_underline)
    View view_trade_password_underline;
    @BindView(R2.id.es_activity_password_view_money_password_underline)
    View view_money_password_underline;
    @BindView(R2.id.es_activity_password_rl_trade_password)
    RelativeLayout rl_trade;
    @BindView(R2.id.es_activity_password_rl_money_password)
    RelativeLayout rl_money;
    @BindView(R2.id.es_activity_password_crl_old_password)
    EsCustomRelativeLayout crl_old_password;
    @BindView(R2.id.es_activity_password_crl_new_password)
    EsCustomRelativeLayout crl_new_password;
    @BindView(R2.id.es_activity_password_crl_new_password_again)
    EsCustomRelativeLayout crl_new_password_again;
    @BindView(R2.id.es_activity_password_et_old_password)
    EditText et_old_password;
    @BindView(R2.id.es_activity_password_et_new_password)
    EditText et_new_password;
    @BindView(R2.id.es_activity_password_et_new_password_again)
    EditText et_new_password_again;
    @BindView(R2.id.es_activity_password_tv_confirm)
    TextView tv_confirm;
    @BindView(R2.id.es_activity_password_etv_clear_old_password)
    EsIconTextView etv_clear_old_password;
    @BindView(R2.id.es_activity_password_etv_clear_new_password)
    EsIconTextView etv_clear_new_password;
    @BindView(R2.id.es_activity_password_etv_clear_new_password_again)
    EsIconTextView etv_clear_new_password_agagin;

    int mCurrentTabIndex = 0;
    String mCompanyNo, mUserNo, mAddrNo;
    EsCustomerToast mLoadingToast;

    @Override
    protected void onStart() {
        super.onStart();

        EventBus.getDefault().register(this);
    }

    @Override
    protected void onStop() {
        super.onStop();

        EventBus.getDefault().unregister(this);
    }

    @Override
    protected void initData() {
        super.initData();

        if (EsLoginAccountData.getInstance().getCurrentAccount() != null) {
            mCompanyNo = EsLoginAccountData.getInstance().getCurrentAccount().getCompanyNo();
            mUserNo = EsLoginAccountData.getInstance().getCurrentAccount().getUserNo();
            mAddrNo = EsLoginAccountData.getInstance().getCurrentAccount().getAddrTypeNo();
        }
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindOnClick();
        bindFocus();
        changeTab(mCurrentTabIndex);
    }

    private void bindOnClick() {
        etv_back.setOnClickListener(this);
        rl_trade.setOnClickListener(this);
        rl_money.setOnClickListener(this);
        tv_confirm.setOnClickListener(this);
        etv_clear_old_password.setOnClickListener(this);
        etv_clear_new_password.setOnClickListener(this);
        etv_clear_new_password_agagin.setOnClickListener(this);
    }

    private void bindFocus() {
        et_old_password.setOnFocusChangeListener(crl_old_password);
        et_new_password.setOnFocusChangeListener(crl_new_password);
        et_new_password_again.setOnFocusChangeListener(crl_new_password_again);

        et_old_password.addTextChangedListener(this);
        et_new_password.addTextChangedListener(this);
        et_new_password_again.addTextChangedListener(this);
    }

    @Override
    protected int getContentView() {
        return R.layout.es_activity_es_password_modify;
    }

    @Override
    public void onClick(View v) {
        int resId = v.getId();
        if (resId == R.id.es_activity_password_etv_back) {
            finish();
        } else if (resId == R.id.es_activity_password_rl_trade_password) {
            changeTab(0);
        } else if (resId == R.id.es_activity_password_rl_money_password) {
            changeTab(1);
        } else if (resId == R.id.es_activity_password_tv_confirm) {
            modifyPassword();
        } else if (resId == R.id.es_activity_password_etv_clear_old_password) {
            clearOldPasswordInEditText();
        } else if (resId == R.id.es_activity_password_etv_clear_new_password) {
            clearNewPasswordInEditText();
        } else if (resId == R.id.es_activity_password_etv_clear_new_password_again) {
            clearNewPasswordAgainInEditText();
        }
    }

    private void clearNewPasswordAgainInEditText() {
        et_new_password_again.setText("");
    }

    private void clearNewPasswordInEditText() {
        et_new_password.setText("");
    }

    private void clearOldPasswordInEditText() {
        et_old_password.setText("");
    }

    private void showLoadingToast() {
        mLoadingToast = EsCustomerToast.create(this)
                .setStyle(EsCustomerToast.Style.TOAST_LOADING)
                .setDetailTips(getString(R.string.es_activity_password_loading))
                .setDurationTime(1000 * 10);
        mLoadingToast.show();
    }

    /**
     * @param position 0代表交易密码界面，1代码资金密码界面。
     */
    private void changeTab(int position) {
        mCurrentTabIndex = position;
        // 之所以都用if不用switch是为了防止Android Lib出现问题。
        if (position == 0) {
            tv_trade_password.setSelected(true);
            view_trade_password_underline.setVisibility(View.VISIBLE);

            tv_money_password.setSelected(false);
            view_money_password_underline.setVisibility(View.GONE);
        } else if (position == 1) {
            tv_money_password.setSelected(true);
            view_money_password_underline.setVisibility(View.VISIBLE);

            tv_trade_password.setSelected(false);
            view_trade_password_underline.setVisibility(View.GONE);
        }
    }

    private void modifyPassword() {
        if ("".equals(et_old_password.getText().toString().trim())
                && "".equals(et_new_password.getText().toString().trim())
                && "".equals(et_new_password_again.getText().toString().trim())) {
            return;
        }

        if (mCurrentTabIndex == 0) {
            modifyTradePassword();
        } else if (mCurrentTabIndex == 1) {
            modifyMoneyPassword();
        }
    }

    /**
     * 修改交易密码
     */
    private void modifyTradePassword() {
        if (isLegalInput() && isCurrentUserExit()) {
            int result = EsDataApi.modifyTradePassword(mCompanyNo, mUserNo, mAddrNo, et_old_password.getText().toString(), et_new_password.getText().toString());
            showLoadingToast();
        }
    }

    /**
     * 修改資金密碼
     */
    private void modifyMoneyPassword() {
        // 修改资金密码需要针对币种进行，针对币种则是针对签约银行进行。。。
        if (isLegalInput() && isCurrentUserExit()) {
            int result = EsDataApi.modifyMoneyPassword(mCompanyNo, mUserNo, mAddrNo,"CNY", et_old_password.getText().toString().trim(), et_new_password.getText().toString().trim());
            showLoadingToast();
        }
    }

    /**
     * 检查用户输入格式是否合法以及检验原密码是否正确.
     * 合法且密码正常返回True，反之为False.
     */
    private boolean isLegalInput() {

        if (et_old_password.getText().toString().trim().equals("")) {
            return false;
        }
        if (et_new_password.getText().toString().trim().equals("")) {
            return false;
        }
        if (et_new_password_again.getText().toString().trim().equals("")) {
            return false;
        }
        if (et_new_password.getText().toString().trim().equals(et_old_password.getText().toString().trim())) {
            EsCustomTipsDialog dialog = EsCustomTipsDialog.create(this, getString(R.string.es_login_password_notice), getString(R.string.es_activity_password_warning_equal_old));
            dialog.setCancelable(false);
            dialog.show();
            return false;
        }
        if (!et_new_password.getText().toString().trim().equals(et_new_password_again.getText().toString().trim())) {
            EsCustomTipsDialog dialog = EsCustomTipsDialog.create(this, getString(R.string.es_login_password_notice), getString(R.string.es_activity_password_warning_not_equal));
            dialog.setCancelable(false);
            dialog.show();
            return false;
        }

        return true;
    }

    /**
     * @return True代表用户已登录，有当前用户。False代表用户未登录。
     */
    private boolean isCurrentUserExit() {
        // 為了防止之後可能有不同的提示語，所以分開寫
        if (mUserNo == null || mUserNo.equals("")) {
            EsCustomTipsDialog.create(this,
                    getString(R.string.es_activity_password_error_notice),
                    getString(R.string.es_activity_password_no_user))
                    .show();
            return false;
        }

        if (mCompanyNo == null || mCompanyNo.equals("")) {
            EsCustomTipsDialog.create(this,
                    getString(R.string.es_activity_password_error_notice),
                    getString(R.string.es_activity_password_no_user))
                    .show();
            return false;
        }
        return true;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }

    @Override
    public void afterTextChanged(Editable s) {
        judgeBtnUIAccordingStatus();
    }

    private void judgeBtnUIAccordingStatus() {
        if ("".equals(et_old_password.getText().toString().trim())
                || "".equals(et_new_password.getText().toString().trim())
                || "".equals(et_new_password_again.getText().toString().trim())) {
            tv_confirm.setBackgroundResource(R.drawable.es_bg_color_btn_modify_password_no_content);
            tv_confirm.setEnabled(false);
        } else {
            tv_confirm.setBackgroundResource(R.drawable.es_bg_color_btn_modify_password);
            tv_confirm.setEnabled(true);
        }
    }

    private void dealMessage(String srvText, int errorCode) {
        if (mLoadingToast.isShowing()) {
            mLoadingToast.cancel();
        }
        if (srvText == null) {
            EsCustomTipsDialog dialog = EsCustomTipsDialog.create(this, getString(R.string.es_login_password_notice), getString(R.string.es_activity_password_warning_failed));
            dialog.setCancelable(false);
            dialog.show();
        } else {
            String text = srvText;

            if (errorCode == 0) {
                final EsCustomTipsDialog dialog = EsCustomTipsDialog.create(EsPasswordActivity.this, getString(R.string.es_login_password_notice), getString(R.string.es_activity_password_warning_succeed));
                dialog.setCancelable(false);
                dialog.setCancelListener(new EsCustomTipsDialog.EsCustomTipsDialogListener() {
                    @Override
                    public void onCancel() {
                        EsLoginAccountData.LoginAccount loginAccount = EsLoginAccountData.getInstance().getCurrentAccount();
                        int logout = EsDataApi.tradeLogout(loginAccount.getAddrTypeNo(), loginAccount.getCompanyNo(), loginAccount.getUserNo());
                        if (logout == 0) {
                            //移除原来的账号信息，可能还有问题
                            EsLoginAccountData.getInstance().removeAccount(loginAccount);

                            dialog.dismiss();
                            finish();
                            loginAccount.setPassword("&");
                            EsLoginAccountData.getInstance().setDoSavePassword(getBaseContext(), false);
                            EsLoginAccountData.getInstance().addNewSavedAccount(loginAccount);
                            EsUIApi.startLoginActivity();
                        }
                    }
                });
                dialog.show();
            } else {
                if (text.equals("")) {
                    text = getString(R.string.es_password_warning_errorCode, errorCode);
                }
                EsCustomTipsDialog dialog = EsCustomTipsDialog.create(EsPasswordActivity.this, getString(R.string.es_login_password_notice), text);
                dialog.show();
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void Event(TradeEvent event) {
        int action = event.getAction();
        String companyNo = event.getCompanyNo();
        String userNo = event.getUserNo();
        String addrNo = event.getAddressNo();

        if (!EsLoginAccountData.getInstance().isCurrentAccount(companyNo, userNo, addrNo)) {
            return;
        }

        if (action == EsDataConstant.S_SRVEVENT_CHG_TRD_PWD ||
                action == EsDataConstant.S_SRVEVENT_CHG_FUND_PWD) {
            dealMessage(event.getSrvErrorText(), event.getSrvErrorCode());
        }
    }
}