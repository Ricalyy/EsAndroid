package com.esunny.ui.common.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.ui.R;
import com.esunny.ui.api.EsUIApi;
import com.esunny.ui.api.EsUIConstant;
import com.esunny.ui.api.RoutingTable;
import com.esunny.ui.common.EsBaseActivity;
import com.esunny.ui.dialog.EsCustomTipsDialog;
import com.esunny.ui.util.EsSPHelper;
import com.esunny.ui.util.EsWebUrlData;
import com.esunny.ui.view.EsBaseToolBar;


@Route(path = RoutingTable.ES_DISCLAIMER_ACTIVITY)
public class EsDisclaimerActivity extends EsBaseActivity {

    private EsBaseToolBar mToolBar;
//    private TextView mTvConfirm;
//    private TextView mTvCancel;
//    private LinearLayout mLlCheck;

    private WebView  mWebView;
//    private boolean  mWebStateConfirm = false;

//    private String mLocalVersion;
//
//    private boolean mIsCheckStateConfirm;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setNeedInit(false);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void initData() {
        super.initData();

//        mIsCheckStateConfirm = getIntent().getBooleanExtra(EsUIConstant.KEY_IS_CHECK_STATE_CONFIRM, false);
    }

    @Override
    protected void initWidget() {
        super.initWidget();
        bindView();
//        bindClick();
        initToolbar();
        initWebView();
//        initConfirmButton();

        mWebView.setVisibility(View.VISIBLE);
//        mWebStateConfirm = false;
//        mWebView.addJavascriptInterface(new EsWebViewUtil(), "EsWebViewUtil");

        String fileDir;
        if (EsSPHelper.getTheme(this)) {
            fileDir = "file:///android_asset/html/disclaimer_white.html";
        } else {
            fileDir = "file:///android_asset/html/disclaimer_black.html";
        }

        mWebView.loadUrl(fileDir);
//        mLocalVersion = EsUIApi.getVersion(getApplication());
    }


    @Override
    protected int getContentView() {
        return R.layout.es_login_activity_state_confirm;
    }

    private void bindView(){
//        mTvConfirm = findViewById(R.id.es_login_state_confirm_activity_confirm);
//        mTvCancel = findViewById(R.id.es_login_state_confirm_activity_cancel);
//        mLlCheck = findViewById(R.id.es_login_state_confirm_activity_ll_choose);

        mToolBar = findViewById(R.id.es_login_state_confirm_activity_title);
    }

    private void initToolbar() {
        mToolBar.setTitle(getString(R.string.es_activity_disclaimer_confirm_title));
//        if (mIsCheckStateConfirm) {
            mToolBar.setLeftIcons(R.string.es_icon_toolbar_back);
//        } else {
//            mToolBar.setRightIcons(new int[]{R.string.es_icon_fresh});
//        }
        mToolBar.setToolbarClickListener(new EsBaseToolBar.ToolbarClickListener() {
            @Override
            public void onClick(int id) {
                if (id == R.id.toolbar_right_first) {
                    if (mWebView != null) {
                        mWebView.reload();
                    }
                } else if (id == R.id.toolbar_left_first) {
                    finish();
                }
            }
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initWebView(){
        mWebView = findViewById(R.id.es_login_state_confirm_webview);
        mWebView.setFocusable(true);
        mWebView.getSettings().setTextZoom(100);
        mWebView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);//测试阶段不适用缓存，方便调试
//        mWebView.getSettings().setJavaScriptEnabled(true);
//        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.setBackgroundColor(0);
        mWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        mWebView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });
        //设置不用系统浏览器打开,直接显示在当前Webview
        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                mWebView.loadUrl(url);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
//                if (mIsCheckStateConfirm) {
//                    mWebView.loadUrl("javascript:hideCheckList()");
//                }
            }
        });
    }

//    private void initConfirmButton() {
//        if (mIsCheckStateConfirm) {
//            mLlCheck.setVisibility(View.GONE);
//        } else {
//            mLlCheck.setVisibility(View.VISIBLE);
//        }
//    }

//    private void bindClick(){
//        mTvConfirm.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(mWebStateConfirm){
//                    EsSPHelper.setStateConfirm(EsDisclaimerActivity.this, mLocalVersion);
//                    Intent intent = new Intent(EsDisclaimerActivity.this, EsPrivacyActivity.class);
//                    intent.putExtra(EsUIConstant.KEY_CONFIRM_LOCALVERSION, mLocalVersion);
//                    startActivity(intent);
//                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
//                }else {
//                    EsCustomTipsDialog dialog = new EsCustomTipsDialog(EsDisclaimerActivity.this, getString(R.string.es_base_view_tips), getString(R.string.es_login_activity_state_confirm_check_tips));
//                    dialog.show();
//                }
//            }
//        });
//
//        mTvCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                EsSPHelper.setStateConfirm(EsDisclaimerActivity.this, "");
//                setResult(EsUIConstant.S_STATE_CONFIRM_RESULT_CODE_CANCEL);
//                finish();
//            }
//        });
//    }
//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        if (!mIsCheckStateConfirm) {
//            if (keyCode == KeyEvent.KEYCODE_BACK)
//                return true;
//        }
//        return super.onKeyDown(keyCode, event);
//    }


//    class EsWebViewUtil {
//        @JavascriptInterface
//        public void stateConfirm(boolean state){
//            mWebStateConfirm = state;
//        }
//    }
}
