package com.esunny.data.error;

import android.content.Context;
import android.content.res.Resources;

import com.esunny.data.R;

class DaystarAndDipperErrorCode {

    static String getErrorMessage(Context context, int errorCode) {

        switch (errorCode) {
            case 0 :
                return context.getResources().getString(R.string.daystarDipper_0);
            case -1 :
                return context.getResources().getString(R.string.daystarDipper_n1);
            case -2 :
                return context.getResources().getString(R.string.daystarDipper_n2);
            case -3 :
                return context.getResources().getString(R.string.daystarDipper_n3);
            case -4 :
                return context.getResources().getString(R.string.daystarDipper_n4);
            case -5 :
                return context.getResources().getString(R.string.daystarDipper_n5);
            case -6 :
                return context.getResources().getString(R.string.daystarDipper_n6);
            case -7 :
                return context.getResources().getString(R.string.daystarDipper_n7);
            case -8 :
                return context.getResources().getString(R.string.daystarDipper_n8);
            case -9 :
                return context.getResources().getString(R.string.daystarDipper_n9);
            case -10 :
                return context.getResources().getString(R.string.daystarDipper_n10);
            case -11 :
                return context.getResources().getString(R.string.daystarDipper_n11);
            case -12 :
                return context.getResources().getString(R.string.daystarDipper_n12);
            case -13 :
                return context.getResources().getString(R.string.daystarDipper_n13);
            case -14 :
                return context.getResources().getString(R.string.daystarDipper_n14);
            case -15 :
                return context.getResources().getString(R.string.daystarDipper_n15);
            case -16 :
                return context.getResources().getString(R.string.daystarDipper_n16);
            case -17 :
                return context.getResources().getString(R.string.daystarDipper_n17);
            case -18 :
                return context.getResources().getString(R.string.daystarDipper_n18);
            case -19 :
                return context.getResources().getString(R.string.daystarDipper_n19);
            case -20 :
                return context.getResources().getString(R.string.daystarDipper_n20);
            case -21 :
                return context.getResources().getString(R.string.daystarDipper_n21);
            case -22 :
                return context.getResources().getString(R.string.daystarDipper_n22);
            case -23 :
                return context.getResources().getString(R.string.daystarDipper_n23);
            case -24 :
                return context.getResources().getString(R.string.daystarDipper_n24);
            case -25 :
                return context.getResources().getString(R.string.daystarDipper_n25);
            case -26 :
                return context.getResources().getString(R.string.daystarDipper_n26);
            case -27 :
                return context.getResources().getString(R.string.daystarDipper_n27);
            case -28 :
                return context.getResources().getString(R.string.daystarDipper_n28);
            case -29 :
                return context.getResources().getString(R.string.daystarDipper_n29);
            case -30 :
                return context.getResources().getString(R.string.daystarDipper_n30);
            case -31 :
                return context.getResources().getString(R.string.daystarDipper_n31);
            case -32 :
                return context.getResources().getString(R.string.daystarDipper_n32);
            case -33 :
                return context.getResources().getString(R.string.daystarDipper_n33);
            case -34 :
                return context.getResources().getString(R.string.daystarDipper_n34);
            case -35 :
                return context.getResources().getString(R.string.daystarDipper_n35);
            case -36 :
                return context.getResources().getString(R.string.daystarDipper_n36);
            case -37 :
                return context.getResources().getString(R.string.daystarDipper_n37);
            case -10000 :
                return context.getResources().getString(R.string.daystarDipper_n10000);
            case -10001 :
                return context.getResources().getString(R.string.daystarDipper_n10001);
            case -10002 :
                return context.getResources().getString(R.string.daystarDipper_n10002);
            case -10003 :
                return context.getResources().getString(R.string.daystarDipper_n10003);
            case -10004 :
                return context.getResources().getString(R.string.daystarDipper_n10004);
            case -10005 :
                return context.getResources().getString(R.string.daystarDipper_n10005);
            case -10006 :
                return context.getResources().getString(R.string.daystarDipper_n10006);
            case -12001 :
                return context.getResources().getString(R.string.daystarDipper_n12001);
            case -12003 :
                return context.getResources().getString(R.string.daystarDipper_n12003);
            case -12004 :
                return context.getResources().getString(R.string.daystarDipper_n12004);
            case -12005 :
                return context.getResources().getString(R.string.daystarDipper_n12005);
            case -12006 :
                return context.getResources().getString(R.string.daystarDipper_n12006);
            case -12007 :
                return context.getResources().getString(R.string.daystarDipper_n12007);
            case -12008 :
                return context.getResources().getString(R.string.daystarDipper_n12008);
            case -12009 :
                return context.getResources().getString(R.string.daystarDipper_n12009);
            case -12010 :
                return context.getResources().getString(R.string.daystarDipper_n12010);
            case -12011 :
                return context.getResources().getString(R.string.daystarDipper_n12011);
            case -12012 :
                return context.getResources().getString(R.string.daystarDipper_n12012);
            case -12013 :
                return context.getResources().getString(R.string.daystarDipper_n12013);
            case -12014 :
                return context.getResources().getString(R.string.daystarDipper_n12014);
            case -12015 :
                return context.getResources().getString(R.string.daystarDipper_n12015);
            case -12016 :
                return context.getResources().getString(R.string.daystarDipper_n12016);
            case -12017 :
                return context.getResources().getString(R.string.daystarDipper_n12017);
            case -12021 :
                return context.getResources().getString(R.string.daystarDipper_n12021);
            case -12022 :
                return context.getResources().getString(R.string.daystarDipper_n12022);
            case -12023 :
                return context.getResources().getString(R.string.daystarDipper_n12023);
            case -12024 :
                return context.getResources().getString(R.string.daystarDipper_n12024);
            case -12025 :
                return context.getResources().getString(R.string.daystarDipper_n12025);
            case -12035 :
                return context.getResources().getString(R.string.daystarDipper_n12035);
            case -12036 :
                return context.getResources().getString(R.string.daystarDipper_n12036);
            case -12041 :
                return context.getResources().getString(R.string.daystarDipper_n12041);
            case -12042 :
                return context.getResources().getString(R.string.daystarDipper_n12042);
            case -12043 :
                return context.getResources().getString(R.string.daystarDipper_n12043);
            case -12044 :
                return context.getResources().getString(R.string.daystarDipper_n12044);
            case -12045 :
                return context.getResources().getString(R.string.daystarDipper_n12045);
            case -12046 :
                return context.getResources().getString(R.string.daystarDipper_n12046);
            case -12047 :
                return context.getResources().getString(R.string.daystarDipper_n12047);
            case -12048 :
                return context.getResources().getString(R.string.daystarDipper_n12048);
            case -12049 :
                return context.getResources().getString(R.string.daystarDipper_n12049);
            case -12050 :
                return context.getResources().getString(R.string.daystarDipper_n12050);
            case -12051 :
                return context.getResources().getString(R.string.daystarDipper_n12051);
            case 1 :
                return context.getResources().getString(R.string.daystarDipper_1);
            case 2 :
                return context.getResources().getString(R.string.daystarDipper_2);
            case 3 :
                return context.getResources().getString(R.string.daystarDipper_3);
            case 4 :
                return context.getResources().getString(R.string.daystarDipper_4);
            case 5 :
                return context.getResources().getString(R.string.daystarDipper_5);
            case 6 :
                return context.getResources().getString(R.string.daystarDipper_6);
            case 7 :
                return context.getResources().getString(R.string.daystarDipper_7);
            case 8 :
                return context.getResources().getString(R.string.daystarDipper_8);
            case 9 :
                return context.getResources().getString(R.string.daystarDipper_9);
            case 10 :
                return context.getResources().getString(R.string.daystarDipper_10);
            case 11 :
                return context.getResources().getString(R.string.daystarDipper_11);
            case 12 :
                return context.getResources().getString(R.string.daystarDipper_12);
            case 13 :
                return context.getResources().getString(R.string.daystarDipper_13);
            case 14 :
                return context.getResources().getString(R.string.daystarDipper_14);
            case 15 :
                return context.getResources().getString(R.string.daystarDipper_15);
            case 10001 :
                return context.getResources().getString(R.string.daystarDipper_10001);
            case 10002 :
                return context.getResources().getString(R.string.daystarDipper_10002);
            case 10003 :
                return context.getResources().getString(R.string.daystarDipper_10003);
            case 10004 :
                return context.getResources().getString(R.string.daystarDipper_10004);
            case 10005 :
                return context.getResources().getString(R.string.daystarDipper_10005);
            case 10006 :
                return context.getResources().getString(R.string.daystarDipper_10006);
            case 10007 :
                return context.getResources().getString(R.string.daystarDipper_10007);
            case 10008 :
                return context.getResources().getString(R.string.daystarDipper_10008);
            case 10009 :
                return context.getResources().getString(R.string.daystarDipper_10009);
            case 10010 :
                return context.getResources().getString(R.string.daystarDipper_10010);
            case 10011 :
                return context.getResources().getString(R.string.daystarDipper_10011);
            case 10012 :
                return context.getResources().getString(R.string.daystarDipper_10012);
            case 10013 :
                return context.getResources().getString(R.string.daystarDipper_10013);
            case 10014 :
                return context.getResources().getString(R.string.daystarDipper_10014);
            case 10015 :
                return context.getResources().getString(R.string.daystarDipper_10015);
            case 10016 :
                return context.getResources().getString(R.string.daystarDipper_10016);
            case 10017 :
                return context.getResources().getString(R.string.daystarDipper_10017);
            case 10018 :
                return context.getResources().getString(R.string.daystarDipper_10018);
            case 10019 :
                return context.getResources().getString(R.string.daystarDipper_10019);
            case 10020 :
                return context.getResources().getString(R.string.daystarDipper_10020);
            case 10021 :
                return context.getResources().getString(R.string.daystarDipper_10021);
            case 10050 :
                return context.getResources().getString(R.string.daystarDipper_10050);
            case 10052 :
                return context.getResources().getString(R.string.daystarDipper_10052);
            case 10053 :
                return context.getResources().getString(R.string.daystarDipper_10053);
            case 10054 :
                return context.getResources().getString(R.string.daystarDipper_10054);
            case 10055 :
                return context.getResources().getString(R.string.daystarDipper_10055);
            case 10056 :
                return context.getResources().getString(R.string.daystarDipper_10056);
            case 10057 :
                return context.getResources().getString(R.string.daystarDipper_10057);
            case 10058 :
                return context.getResources().getString(R.string.daystarDipper_10058);
            case 10059 :
                return context.getResources().getString(R.string.daystarDipper_10059);
            case 10060 :
                return context.getResources().getString(R.string.daystarDipper_10060);
            case 10061 :
                return context.getResources().getString(R.string.daystarDipper_10061);
            case 10062 :
                return context.getResources().getString(R.string.daystarDipper_10062);
            case 10066 :
                return context.getResources().getString(R.string.daystarDipper_10066);
            case 10067 :
                return context.getResources().getString(R.string.daystarDipper_10067);
            case 10068 :
                return context.getResources().getString(R.string.daystarDipper_10068);
            case 10069 :
                return context.getResources().getString(R.string.daystarDipper_10069);
            case 10070 :
                return context.getResources().getString(R.string.daystarDipper_10070);
            case 10071 :
                return context.getResources().getString(R.string.daystarDipper_10071);
            case 10101 :
                return context.getResources().getString(R.string.daystarDipper_10101);
            case 11001 :
                return context.getResources().getString(R.string.daystarDipper_11001);
            case 11501 :
                return context.getResources().getString(R.string.daystarDipper_11501);
            case 11701 :
                return context.getResources().getString(R.string.daystarDipper_11701);
            case 11702 :
                return context.getResources().getString(R.string.daystarDipper_11702);
            case 11703 :
                return context.getResources().getString(R.string.daystarDipper_11703);
            case 11704 :
                return context.getResources().getString(R.string.daystarDipper_11704);
            case 12001 :
                return context.getResources().getString(R.string.daystarDipper_12001);
            case 12002 :
                return context.getResources().getString(R.string.daystarDipper_12002);
            case 12003 :
                return context.getResources().getString(R.string.daystarDipper_12003);
            case 14001 :
                return context.getResources().getString(R.string.daystarDipper_14001);
            case 14002 :
                return context.getResources().getString(R.string.daystarDipper_14002);
            case 14003 :
                return context.getResources().getString(R.string.daystarDipper_14003);
            case 14004 :
                return context.getResources().getString(R.string.daystarDipper_14004);
            case 20201 :
                return context.getResources().getString(R.string.daystarDipper_20201);
            case 20701 :
                return context.getResources().getString(R.string.daystarDipper_20701);
            case 22801 :
                return context.getResources().getString(R.string.daystarDipper_22801);
            case 22901 :
                return context.getResources().getString(R.string.daystarDipper_22901);
            case 28901 :
                return context.getResources().getString(R.string.daystarDipper_28901);
            case 29591 :
                return context.getResources().getString(R.string.daystarDipper_29591);
            case 29592 :
                return context.getResources().getString(R.string.daystarDipper_29592);
            case 29593 :
                return context.getResources().getString(R.string.daystarDipper_29593);
            case 29594 :
                return context.getResources().getString(R.string.daystarDipper_29594);
            case 60001 :
                return context.getResources().getString(R.string.daystarDipper_60001);
            case 60002 :
                return context.getResources().getString(R.string.daystarDipper_60002);
            case 60003 :
                return context.getResources().getString(R.string.daystarDipper_60003);
            case 60004 :
                return context.getResources().getString(R.string.daystarDipper_60004);
            case 60005 :
                return context.getResources().getString(R.string.daystarDipper_60005);
            case 60006 :
                return context.getResources().getString(R.string.daystarDipper_60006);
            case 60007 :
                return context.getResources().getString(R.string.daystarDipper_60007);
            case 60011 :
                return context.getResources().getString(R.string.daystarDipper_60011);
            case 60021 :
                return context.getResources().getString(R.string.daystarDipper_60021);
            case 60022 :
                return context.getResources().getString(R.string.daystarDipper_60022);
            case 60023 :
                return context.getResources().getString(R.string.daystarDipper_60023);
            case 60024 :
                return context.getResources().getString(R.string.daystarDipper_60024);
            case 60031 :
                return context.getResources().getString(R.string.daystarDipper_60031);
            case 60032 :
                return context.getResources().getString(R.string.daystarDipper_60032);
            case 60033 :
                return context.getResources().getString(R.string.daystarDipper_60033);
            case 60034 :
                return context.getResources().getString(R.string.daystarDipper_60034);
            case 60035 :
                return context.getResources().getString(R.string.daystarDipper_60035);
            case 60036 :
                return context.getResources().getString(R.string.daystarDipper_60036);
            case 60037 :
                return context.getResources().getString(R.string.daystarDipper_60037);
            case 60038 :
                return context.getResources().getString(R.string.daystarDipper_60038);
            case 60039 :
                return context.getResources().getString(R.string.daystarDipper_60039);
            case 60040 :
                return context.getResources().getString(R.string.daystarDipper_60040);
            case 60051 :
                return context.getResources().getString(R.string.daystarDipper_60051);
            case 60052 :
                return context.getResources().getString(R.string.daystarDipper_60052);
            case 60053 :
                return context.getResources().getString(R.string.daystarDipper_60053);
            case 60061 :
                return context.getResources().getString(R.string.daystarDipper_60061);
            case 60062 :
                return context.getResources().getString(R.string.daystarDipper_60062);
            case 60063 :
                return context.getResources().getString(R.string.daystarDipper_60063);
            case 60071 :
                return context.getResources().getString(R.string.daystarDipper_60071);
            case 60072 :
                return context.getResources().getString(R.string.daystarDipper_60072);
            case 60081 :
                return context.getResources().getString(R.string.daystarDipper_60081);
            case 60082 :
                return context.getResources().getString(R.string.daystarDipper_60082);
            case 60091 :
                return context.getResources().getString(R.string.daystarDipper_60091);
            case 60092 :
                return context.getResources().getString(R.string.daystarDipper_60092);
            case 60100 :
                return context.getResources().getString(R.string.daystarDipper_60100);
            case 60101 :
                return context.getResources().getString(R.string.daystarDipper_60101);
            case 60102 :
                return context.getResources().getString(R.string.daystarDipper_60102);
            case 60103 :
                return context.getResources().getString(R.string.daystarDipper_60103);
            case 60104 :
                return context.getResources().getString(R.string.daystarDipper_60104);
            case 60105 :
                return context.getResources().getString(R.string.daystarDipper_60105);
            case 60106 :
                return context.getResources().getString(R.string.daystarDipper_60106);
            case 60107 :
                return context.getResources().getString(R.string.daystarDipper_60107);
            case 60108 :
                return context.getResources().getString(R.string.daystarDipper_60108);
            case 60109 :
                return context.getResources().getString(R.string.daystarDipper_60109);
            case 60110 :
                return context.getResources().getString(R.string.daystarDipper_60110);
            case 60111 :
                return context.getResources().getString(R.string.daystarDipper_60111);
            case 60112 :
                return context.getResources().getString(R.string.daystarDipper_60112);
            case 60113 :
                return context.getResources().getString(R.string.daystarDipper_60113);
            case 60114 :
                return context.getResources().getString(R.string.daystarDipper_60114);
            case 60115 :
                return context.getResources().getString(R.string.daystarDipper_60115);
            case 60116 :
                return context.getResources().getString(R.string.daystarDipper_60116);
            case 60117 :
                return context.getResources().getString(R.string.daystarDipper_60117);
            case 60118 :
                return context.getResources().getString(R.string.daystarDipper_60118);
            case 60119 :
                return context.getResources().getString(R.string.daystarDipper_60119);
            case 60120 :
                return context.getResources().getString(R.string.daystarDipper_60120);
            case 60121 :
                return context.getResources().getString(R.string.daystarDipper_60120);
            case 60122 :
                return context.getResources().getString(R.string.daystarDipper_60120);
            case 60123 :
                return context.getResources().getString(R.string.daystarDipper_60120);
            case 60503 :
                return context.getResources().getString(R.string.daystarDipper_60503);
            case 60504 :
                return context.getResources().getString(R.string.daystarDipper_60504);
            case 60505 :
                return context.getResources().getString(R.string.daystarDipper_60505);
            case 60506 :
                return context.getResources().getString(R.string.daystarDipper_60506);
            case 60511 :
                return context.getResources().getString(R.string.daystarDipper_60511);
            case 60512 :
                return context.getResources().getString(R.string.daystarDipper_60512);
            case 60513 :
                return context.getResources().getString(R.string.daystarDipper_60513);
            case 60514 :
                return context.getResources().getString(R.string.daystarDipper_60514);
            case 60515 :
                return context.getResources().getString(R.string.daystarDipper_60515);
            case 60516 :
                return context.getResources().getString(R.string.daystarDipper_60515);
            case 60517 :
                return context.getResources().getString(R.string.daystarDipper_60515);
            case 60518 :
                return context.getResources().getString(R.string.daystarDipper_60515);
            case 60519 :
                return context.getResources().getString(R.string.daystarDipper_60515);
            case 60520 :
                return context.getResources().getString(R.string.daystarDipper_60515);
            case 60521 :
                return context.getResources().getString(R.string.daystarDipper_60521);
            case 60522 :
                return context.getResources().getString(R.string.daystarDipper_60522);
            case 60523 :
                return context.getResources().getString(R.string.daystarDipper_60523);
            case 60524 :
                return context.getResources().getString(R.string.daystarDipper_60524);
            case 60525 :
                return context.getResources().getString(R.string.daystarDipper_60525);
            case 60526 :
                return context.getResources().getString(R.string.daystarDipper_60526);
            case 60527 :
                return context.getResources().getString(R.string.daystarDipper_60527);
            case 60528 :
                return context.getResources().getString(R.string.daystarDipper_60528);
            case 60529 :
                return context.getResources().getString(R.string.daystarDipper_60529);
            case 60530 :
                return context.getResources().getString(R.string.daystarDipper_60530);
            case 60531 :
                return context.getResources().getString(R.string.daystarDipper_60531);
            case 60532 :
                return context.getResources().getString(R.string.daystarDipper_60532);
            case 60533 :
                return context.getResources().getString(R.string.daystarDipper_60533);
            case 60534 :
                return context.getResources().getString(R.string.daystarDipper_60534);
            case 60535 :
                return context.getResources().getString(R.string.daystarDipper_60535);
            case 60536 :
                return context.getResources().getString(R.string.daystarDipper_60535);
            case 60537 :
                return context.getResources().getString(R.string.daystarDipper_60535);
            case 60538 :
                return context.getResources().getString(R.string.daystarDipper_60535);
            case 60539 :
                return context.getResources().getString(R.string.daystarDipper_60535);
            case 60540 :
                return context.getResources().getString(R.string.daystarDipper_60535);
            case 60541 :
                return context.getResources().getString(R.string.daystarDipper_60541);
            case 60542 :
                return context.getResources().getString(R.string.daystarDipper_60542);
            case 60543 :
                return context.getResources().getString(R.string.daystarDipper_60541);
            case 60544 :
                return context.getResources().getString(R.string.daystarDipper_60541);
            case 60545 :
                return context.getResources().getString(R.string.daystarDipper_60541);
            case 60551 :
                return context.getResources().getString(R.string.daystarDipper_60551);
            case 60552 :
                return context.getResources().getString(R.string.daystarDipper_60552);
            case 60553 :
                return context.getResources().getString(R.string.daystarDipper_60553);
            case 60554 :
                return context.getResources().getString(R.string.daystarDipper_60554);
            case 60555 :
                return context.getResources().getString(R.string.daystarDipper_60555);
            case 60556 :
                return context.getResources().getString(R.string.daystarDipper_60556);
            case 60557 :
                return context.getResources().getString(R.string.daystarDipper_60557);
            case 60558 :
                return context.getResources().getString(R.string.daystarDipper_60558);
            case 60559 :
                return context.getResources().getString(R.string.daystarDipper_60558);
            case 60560 :
                return context.getResources().getString(R.string.daystarDipper_60558);
            case 60561 :
                return context.getResources().getString(R.string.daystarDipper_60561);
            case 60562 :
                return context.getResources().getString(R.string.daystarDipper_60562);
            case 60563 :
                return context.getResources().getString(R.string.daystarDipper_60563);
            case 60564 :
                return context.getResources().getString(R.string.daystarDipper_60563);
            case 60571 :
                return context.getResources().getString(R.string.daystarDipper_60571);
            case 60572 :
                return context.getResources().getString(R.string.daystarDipper_60572);
            case 60573 :
                return context.getResources().getString(R.string.daystarDipper_60573);
            case 60574 :
                return context.getResources().getString(R.string.daystarDipper_60574);
            case 60575 :
                return context.getResources().getString(R.string.daystarDipper_60575);
            case 60581 :
                return context.getResources().getString(R.string.daystarDipper_60581);
            case 60591 :
                return context.getResources().getString(R.string.daystarDipper_60591);
            case 60601 :
                return context.getResources().getString(R.string.daystarDipper_60601);
            case 60611 :
                return context.getResources().getString(R.string.daystarDipper_60611);
            case 60612 :
                return context.getResources().getString(R.string.daystarDipper_60612);
            case 60621 :
                return context.getResources().getString(R.string.daystarDipper_60621);
            case 60622 :
                return context.getResources().getString(R.string.daystarDipper_60622);
            case 60623 :
                return context.getResources().getString(R.string.daystarDipper_60623);
            case 60631 :
                return context.getResources().getString(R.string.daystarDipper_60631);
            case 60632 :
                return context.getResources().getString(R.string.daystarDipper_60632);
            case 60641 :
                return context.getResources().getString(R.string.daystarDipper_60641);
            case 60642 :
                return context.getResources().getString(R.string.daystarDipper_60642);
            case 60643 :
                return context.getResources().getString(R.string.daystarDipper_60643);
            case 60644 :
                return context.getResources().getString(R.string.daystarDipper_60644);
            case 60645 :
                return context.getResources().getString(R.string.daystarDipper_60645);
            case 60651 :
                return context.getResources().getString(R.string.daystarDipper_60651);
            case 60652 :
                return context.getResources().getString(R.string.daystarDipper_60652);
            case 60661 :
                return context.getResources().getString(R.string.daystarDipper_60661);
            case 60662 :
                return context.getResources().getString(R.string.daystarDipper_60662);
            case 60663 :
                return context.getResources().getString(R.string.daystarDipper_60663);
            case 60664 :
                return context.getResources().getString(R.string.daystarDipper_60664);
            case 60665 :
                return context.getResources().getString(R.string.daystarDipper_60665);
            case 60666 :
                return context.getResources().getString(R.string.daystarDipper_60666);
            case 60671 :
                return context.getResources().getString(R.string.daystarDipper_60671);
            case 60672 :
                return context.getResources().getString(R.string.daystarDipper_60672);
            case 60673 :
                return context.getResources().getString(R.string.daystarDipper_60673);
            case 60674 :
                return context.getResources().getString(R.string.daystarDipper_60674);
            case 60675 :
                return context.getResources().getString(R.string.daystarDipper_60675);
            case 60676 :
                return context.getResources().getString(R.string.daystarDipper_60676);
            case 60677 :
                return context.getResources().getString(R.string.daystarDipper_60677);
            case 60681 :
                return context.getResources().getString(R.string.daystarDipper_60681);
            case 60682 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60691 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60692 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60693 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60694 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60695 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60696 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60701 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60702 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60703 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60704 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 60711 :
                return context.getResources().getString(R.string.daystarDipper_60682);
            case 61001 :
                return context.getResources().getString(R.string.daystarDipper_61001);
//            case 112001 :
//                return context.getResources().getString(R.string.daystarDipper_112001);
            case 61002 :
                return context.getResources().getString(R.string.daystarDipper_61002);
            case 990001 :
                return context.getResources().getString(R.string.daystarDipper_990001);
            case 990002 :
                return context.getResources().getString(R.string.daystarDipper_990002);
            case 990003 :
                return context.getResources().getString(R.string.daystarDipper_990003);
            case 990004 :
                return context.getResources().getString(R.string.daystarDipper_990004);
            case 990005 :
                return context.getResources().getString(R.string.daystarDipper_990005);
            case 990006 :
                return context.getResources().getString(R.string.daystarDipper_990006);
            case 990007 :
                return context.getResources().getString(R.string.daystarDipper_990007);
            case 990008 :
                return context.getResources().getString(R.string.daystarDipper_990008);
            case 990009 :
                return context.getResources().getString(R.string.daystarDipper_990009);
            case 990010 :
                return context.getResources().getString(R.string.daystarDipper_990010);
            case 990011 :
                return context.getResources().getString(R.string.daystarDipper_990011);
            case 990012 :
                return context.getResources().getString(R.string.daystarDipper_990012);
            case 990013 :
                return context.getResources().getString(R.string.daystarDipper_990013);
            case 990101 :
                return context.getResources().getString(R.string.daystarDipper_990101);
            case 990102 :
                return context.getResources().getString(R.string.daystarDipper_990102);
            case 990103 :
                return context.getResources().getString(R.string.daystarDipper_990103);
            case 990104 :
                return context.getResources().getString(R.string.daystarDipper_990104);
            case 990105 :
                return context.getResources().getString(R.string.daystarDipper_990105);
            case 990106 :
                return context.getResources().getString(R.string.daystarDipper_990106);
            case 990107 :
                return context.getResources().getString(R.string.daystarDipper_990107);
            case 990108 :
                return context.getResources().getString(R.string.daystarDipper_990108);
            case 990109 :
                return context.getResources().getString(R.string.daystarDipper_990109);
            case 990110 :
                return context.getResources().getString(R.string.daystarDipper_990110);
            case 990201 :
                return context.getResources().getString(R.string.daystarDipper_990201);
            case 990202 :
                return context.getResources().getString(R.string.daystarDipper_990202);
            case 990203 :
                return context.getResources().getString(R.string.daystarDipper_990203);
            case 990204 :
                return context.getResources().getString(R.string.daystarDipper_990204);
            case 990205 :
                return context.getResources().getString(R.string.daystarDipper_990205);
            case 990206 :
                return context.getResources().getString(R.string.daystarDipper_990206);
            case 990207 :
                return context.getResources().getString(R.string.daystarDipper_990207);
            case 990208 :
                return context.getResources().getString(R.string.daystarDipper_990208);
            case 990301 :
                return context.getResources().getString(R.string.daystarDipper_990301);
            case 990302 :
                return context.getResources().getString(R.string.daystarDipper_990302);
            case 990303 :
                return context.getResources().getString(R.string.daystarDipper_990303);
            case 990304 :
                return context.getResources().getString(R.string.daystarDipper_990304);
            case 990305 :
                return context.getResources().getString(R.string.daystarDipper_990305);
            case 990306 :
                return context.getResources().getString(R.string.daystarDipper_990306);
            case 990307 :
                return context.getResources().getString(R.string.daystarDipper_990307);
            case 990308 :
                return context.getResources().getString(R.string.daystarDipper_990308);
            case 990309 :
                return context.getResources().getString(R.string.daystarDipper_990309);
            case 990310 :
                return context.getResources().getString(R.string.daystarDipper_990310);
            case 990311 :
                return context.getResources().getString(R.string.daystarDipper_990311);
            case 990312 :
                return context.getResources().getString(R.string.daystarDipper_990312);
            case 990313 :
                return context.getResources().getString(R.string.daystarDipper_990313);
            case 990314 :
                return context.getResources().getString(R.string.daystarDipper_990314);
            case 990701 :
                return context.getResources().getString(R.string.daystarDipper_990701);
            case 990702 :
                return context.getResources().getString(R.string.daystarDipper_990702);
            case 990703 :
                return context.getResources().getString(R.string.daystarDipper_990703);
            default:
                String name;
                if (errorCode >= 0) {
                    name = String.format("daystarDipper_%d", errorCode);
                } else {
                    name = String.format("daystarDipper_n%d", Math.abs(errorCode));
                }
                int resid = getResId(context, name);
                if (resid != 0) {
                    return context.getResources().getString(resid);
                } else {
                    return "";
                }
        }
    }

    public static int getResId(Context context, String name) {
        Resources resources = context.getResources();
        return resources.getIdentifier(name, "string", context.getPackageName());
    }
}
