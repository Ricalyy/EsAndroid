package com.esunny.data.bean;

/**
 * @author huang
 */
public class ContractSortData {
    private double                     value;
    private String                     contractNo;

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }
}
