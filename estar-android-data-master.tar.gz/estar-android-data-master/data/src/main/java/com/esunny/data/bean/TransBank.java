package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */
public class TransBank {
    private String companyNo;          //经纪公司编号
    private String bankNo;             //银行代码
    private String bankBrchNo;         //银行分中心代码
    private String bankName;           //银行名称

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getBankNo() {
        return bankNo;
    }

    public void setBankNo(String bankNo) {
        this.bankNo = bankNo;
    }

    public String getBankBrchNo() {
        return bankBrchNo;
    }

    public void setBankBrchNo(String bankBrchNo) {
        this.bankBrchNo = bankBrchNo;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }
}