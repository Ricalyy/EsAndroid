package com.esunny.data.api;

import android.util.SparseArray;

import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.bean.Address;
import com.esunny.data.util.EsLog;
import com.esunny.mobile.JNICallBack;
import com.esunny.mobile.SByteObject;
import com.esunny.mobile.UnixJNI;
import com.esunny.mobile.bean.CspSessionHead;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class EsStarApi implements JNICallBack {

    private static final String TAG = "EsStarApiNotify";

    // 认证服务器的key
    private int accessKey;

    SparseArray<CallbackDispatcher> mDispatcher;
    CallbackDispatcher mDefault;

    public int init(String str) {
        int ret = UnixJNI.S_Init(str);
        if (ret == 0) {
            UnixJNI.S_RegEvent(this);
            mDispatcher = new SparseArray<>();

            mDefault = new EsDataDispatcher();
        }
        return ret;
    }

    public String getPackageNo() {
        return UnixJNI.S_GetPackageNo();
    }

    public int connect(String ip, int port, CallbackDispatcher dispatcher) {
        EsLog.d(TAG, "Connect Ip : %s, pord : %d", ip, port);
        int key = UnixJNI.S_Connect(ip, port);
        if (key > 0) {
            mDispatcher.put(key, dispatcher);
        }
        if (dispatcher != null) {
           dispatcher.setClient(key);
        } else {
            accessKey = key;
            mDefault.setClient(key);
        }
        return key;
    }

    public int disconnect(int key) {
        int ret = UnixJNI.S_Disconnect(key);
        mDispatcher.remove(key);
        return ret;
    }

    public int sendMsg(int key, char type, CspSessionHead head, byte[] data) {
        int len = data == null ? 0 : data.length;
        len += CspSessionHead.STRUCT_LENGTH;

        ByteBuffer buffer = ByteBuffer.allocate(len);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        buffer.put(head.beanToByte());
        if (data != null) {
            buffer.put(data);
        }

        return UnixJNI.S_SendMessage(key, type, len, buffer.array());
    }

    public int getAccessKey() {
        return accessKey;
    }

    @Override
    public int Invoke(SByteObject object) {
        if (object == null) {
            EsLog.w(TAG, "object is null");
            return -1;
        }

        if (mDispatcher == null) {
            EsLog.w(TAG, "dispatcher is null");
            return -2;
        }

        int key = object.getKey();
        if (mDispatcher.indexOfKey(key) < 0) {
            EsLog.w(TAG, "key is non-existent");
            return -3;
        }

        CallbackDispatcher dispatcher = mDispatcher.get(key);

        if (dispatcher != null) {
            return dispatcher.dispatch(object.getEvent(), object.getData());
        }

        return mDefault.dispatch(object.getEvent(), object.getData());
    }
}
