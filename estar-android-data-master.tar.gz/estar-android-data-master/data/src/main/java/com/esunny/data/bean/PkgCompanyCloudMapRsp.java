package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/11/2
 */
public class PkgCompanyCloudMapRsp {
    private String CompanyNo;
    private String CloudTradeAddrNo;
    private String TradeAddrNo;

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getCloudTradeAddrNo() {
        return CloudTradeAddrNo;
    }

    public void setCloudTradeAddrNo(String cloudTradeAddrNo) {
        CloudTradeAddrNo = cloudTradeAddrNo;
    }

    public String getTradeAddrNo() {
        return TradeAddrNo;
    }

    public void setTradeAddrNo(String tradeAddrNo) {
        TradeAddrNo = tradeAddrNo;
    }
}
