package com.esunny.data.database.table;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;

import java.util.Date;
import org.greenrobot.greendao.annotation.Generated;

/**
 * @author Peter Fu
 * @date 2020/10/14
 */
@Entity(nameInDb = "TUpdateManager")
public class TUpdateManager {
    @Id(autoincrement = true)
    private Long id;
    @Property(nameInDb = "FTableName")
    private String TableName;          // 更新的表名
    @Property(nameInDb = "FLanguage")
    private int Language;
    @Property(nameInDb = "FDateTime")
    private String DateTime;              // 更新的时间
    @Property(nameInDb = "FResult")
    private boolean Result;                // 更新的结果

    @Generated(hash = 873784056)
    public TUpdateManager(Long id, String TableName, int Language, String DateTime,
            boolean Result) {
        this.id = id;
        this.TableName = TableName;
        this.Language = Language;
        this.DateTime = DateTime;
        this.Result = Result;
    }

    @Generated(hash = 1760323665)
    public TUpdateManager() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTableName() {
        return TableName;
    }

    public void setTableName(String tableName) {
        TableName = tableName;
    }

    public int getLanguage() {
        return Language;
    }

    public void setLanguage(int language) {
        Language = language;
    }

    public String getDateTime() {
        return DateTime;
    }

    public void setDateTime(String dateTime) {
        DateTime = dateTime;
    }

    public boolean isResult() {
        return Result;
    }

    public void setResult(boolean result) {
        Result = result;
    }

    public boolean getResult() {
        return this.Result;
    }
}
