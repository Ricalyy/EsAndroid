package com.esunny.data.api;

/**
 * @author Peter Fu
 * @date 2020/9/15
 */
public class EsDataConstant {

    public static final int S_ANDROID_ENU = 0x0409; //英文
    public static final int S_ANDROID_CHT = 0x0404;//繁体
    public static final int S_ANDROID_CHS = 0x0804;//简体

    public static final String EN_STR = "en";      //英文
    public static final String CN_HK_STR = "zh-HK";//香港繁体
    public static final String CN_TW_STR = "zh-TW";//台湾繁体

    public static final long S_PRICE_NOT_MONITOR = 4294967295L;//不监控

    //策略单的价格判断
    public final static double ONE_RISE = 1.04;
    public final static double ONE_FALL = 0.96;
    public final static double FIVE_RISE = 1.22;
    public final static double FIVE_FALL = 0.81;

    //k线类型
    public static final char KLINE_TICK = 'T';    //分笔 RawKLineSliceType 为0
    public static final char KLINE_MINUTE = 'M';    //分钟线
    public static final char KLINE_DAY = 'D';    //日线

    //价格预警的连接判断
    public final static int PRICE_SERVER_CONNECT_SUCCESS = 0;
    public final static int PRICE_SERVER_CONNECT_FAIL = 1;
    public final static int PRICE_SERVER_CALLBACK_DISCONNECT = 2;
    public final static int PRICE_SERVER_CONNECT_ORIGINAL = 4;

    public final static int TIME_TYPE_YEAR = 0;
    public final static int TIME_TYPE_MONTH = 1;
    public final static int TIME_TYPE_DATE = 2;
    public final static int TIME_TYPE_HOUR = 3;
    public final static int TIME_TYPE_MIN = 4;
    public final static int TIME_TYPE_SEC = 5;

    public final static int TIME_TYPE_HOUR_MIN = 10;
    public final static int TIME_TYPE_MIN_SEC = 11;

    public final static int TIME_TYPE_YEAR_MONTH_DATA = 20;
    public final static int TIME_TYPE_HOUR_MIN_SEC = 21;
    public final static int TIME_TYPE_YEAR_MONTH_DATA_SLASH = 22;
    public final static int TIME_TYPE_MONTH_DATA_SLASH = 23;

    public static final int MAX_QUOTE_FIELD_DEPTH = 10;


    //错误码
    public final static int TRADE_ORDER_USER_INFO_ERROR = -1;
    public final static int TRADE_ORDER_REQUEST_ERROR = -2;


    public final static int NOT_TRADE_MODULE = -1000;
    public final static int TRADE_ORDER_INPUT_ERROR = -1001;

    public final static int TRADE_COVER_ORDER_AVAIlABLE_POSITION_NOT_ENOUGH = -1010;
    public final static int TRADE_COVER_ORDER_AVAIlABLE_POSITION_T_NOT_ENOUGH = -1011;
    public final static int TRADE_COVER_ORDER_AVAIlABLE_POSITION_Y_NOT_ENOUGH = -1012;

    public final static int TRADE_MODIFY_ORDER_NOT_CHANGE = -1020;
    public final static int TRADE_MODIFY_ORDER_AVAILABLE_POSITION_NOT_ENOUGH = -1021;

    public final static int TRADE_ORDER_CANNOT_DELETE = -1030;
    //错误码
    public final static int OPEN_DATA_FROM_ORDER_DATA = 1;
    public final static int OPEN_DATA_FROM_INSERT_ORDER = 0;

    //交易数据类型
    //资金变化字段定义
    public static final short                       S_PREAVAILABLE                      = 0; //昨可用
    public static final short                       S_PREBALANCE		                = 1; //昨账面
    public static final short                       S_PREEQUITY		                    = 2; //昨权益
    public static final short                       S_PREMARKETEQUITY	                = 3; //昨市值权益
    public static final short                       S_PREUNEXPPROFIT	                = 4; //昨未结平盈
    public static final short                       S_PRELMEFLOATPROFIT                 = 5; //昨LME浮盈
    public static final short                       S_ADJUST                            = 6; //资金调整
    public static final short                       S_CASHIN                            = 7; //入金
    public static final short                       S_CASHOUT                           = 8; //出金
    public static final short                       S_FROZENFEE                         = 9; //冻结手续费20
    public static final short                       S_FROZENDEPOSIT                     = 10; //冻结保证金19
    public static final short                       S_FEE                               = 11; //手续费(包含交割手续费)
    public static final short                       S_COVERPROFIT                       = 17; //盯市平盈
    public static final short                       S_COVERPROFITTBT                    = 18; //逐笔平盈 TRADE BY TRADE
    public static final short                       S_UNEXPPROFIT                       = 20; //未结平盈
    public static final short                       S_DELIVERYPROFIT                    = 21; //交割盈亏
    public static final short                       S_FLOATPROFIT                       = 22; //盯市浮赢(不含LME盯市浮赢)
    public static final short                       S_FLOATPROFITTBT                    = 24; //逐笔浮赢 TRADE BY TRADE
    public static final short                       S_DEPOSIT                           = 27; //保证金
    public static final short                       S_KEEPDEPOSIT                       = 28; //维持保证金
    public static final short                       S_EQUITY                            = 33; //今权益
    public static final short                       S_AVAILABLE                         = 34; //今可用
    public static final short                       S_CANCASHOUT                        = 35; //今可提
    public static final short                       S_PREFUNDPLEDGEDIN                  = 38; //昨货币质入
    public static final short                       S_PREFUNDPLEDGEDOUT                 = 39; //昨货币质出
    public static final short                       S_FUNDPLEDGEDIN                     = 40; //今货币质入
    public static final short                       S_FUNDPLEDGEDOUT                    = 41; //今货币质出
    public static final short                       S_FUNDCASHPLEDGED                   = 42; //货币质押余额
    public static final short                       S_PLEDGEDABLEFUND                   = 43; //可质押货币
    public static final short                       S_SPECDEPOSIT                       = 45; //特殊产品保证金
    public static final short                       S_SPECFROZENDEPOSIT                 = 46; //特殊产品冻结保证金
    public static final short                       S_SPECFEE                           = 47; //特殊产品手续费
    public static final short                       S_SPECFROZENFEE                     = 48; //特殊产品冻结手续费
    public static final short                       S_SPECFLOATPROFIT                   = 49; //特殊产品浮盈
    public static final short                       S_SPECCOVERPROFIT                   = 50; //特殊产品平盈
    public static final short                       S_RISKRATE                          = 51; //风险率
    public static final short                       S_NETPROFIT                         = 53; //净盈利
    public static final short                       S_PROFITRATE                        = 54; //盈利率
    public static final short                       S_CashPledged                       = 55; //质押资金

    //转账方向
    public static final char                        S_TD_ToFutures                      = 'I'; //银行->期货(转入)
    public static final char                        S_TD_ToBank                         = 'O'; //期货->银行(转出)

    //转账状态
    public static final char                        S_TS_Send                           = 'R'; //已发出
    public static final char                        S_TS_Transing                       = 'T'; //转账中
    public static final char                        S_TS_Transed                        = 'S'; //转账成功
    public static final char                        S_TS_TransFail                      = 'F'; //转账失败
    public static final char                        S_TS_Reversing                      = 'r'; //冲正中
    public static final char                        S_TS_Reversed                       = 's'; //冲正成功
    public static final char                        S_TS_ReversFail                     = 'f'; //冲正失败,此状态多余


    //买卖
    public static final char                        S_DIRECT_BUY                        = 'B'; //买入
    public static final char                        S_DIRECT_SELL                       = 'S'; //卖出
    public static final char                        S_DIRECT_BOTH                       = 'A'; //双边

    //开平
    public static final char                        S_OFFSET_NONE                       =  0; //无
    public static final char                        S_OFFSET_OPEN                       = 'O'; //开仓
    public static final char                        S_OFFSET_COVER                      = 'C'; //平仓
    public static final char                        S_OFFSET_COVERT                     = 'T'; //平今
    public static final char                        S_OFFSET_OPENCOVER                  = '1'; //开平，应价时有效
    public static final char                        S_OFFSET_COVEROPEN                  = '2'; //平开，应价时有效S_CONFIGVALUE_TURNOFF

    //投保
    public static final char                        S_HEDGE_NONE                        = 0; //无
    public static final char                        S_HEDGE_SPECULATE                   = 'T'; //投机
    public static final char                        S_HEDGE_HEDGE                       = 'B'; //套保
    public static final char                        S_HEDGE_SPREAD                      = 'S'; //套利
    public static final char                        S_HEDGE_MARKET                      = 'M'; //做市
    public static final char                        S_HEDGE_COVER                       = 'C'; //备兑

    //报单状态
    public static final char                        S_ORDERSTATE_SENDED                 = '0'; //已发送
    public static final char                        S_ORDERSTATE_ACCEPT                 = '1'; //已受理
    public static final char                        S_ORDERSTATE_TRIGGERING             = '2'; //待触发
    public static final char                        S_ORDERSTATE_ACTIVE                 = '3'; //已生效
    public static final char                        S_ORDERSTATE_QUEUED                 = '4'; //已排队
    public static final char                        S_ORDERSTATE_PARTFILLED             = '5'; //部分成交
    public static final char                        S_ORDERSTATE_FILLED                 = '6'; //完全成交
    public static final char                        S_ORDERSTATE_CANCELING              = '7'; //待撤
    public static final char                        S_ORDERSTATE_MODIFYING              = '8'; //待改
    public static final char                        S_ORDERSTATE_CANCELED               = '9'; //已撤单
    public static final char                        S_ORDERSTATE_PARTCANCELED           = 'A'; //已撤余单
    public static final char                        S_ORDERSTATE_FAIL                   = 'B'; //指令失败
    public static final char                        S_ORDERSTATE_CHECKING               = 'C'; //待审核
    public static final char                        S_ORDERSTATE_SUSPENDED              = 'D'; //已挂起
    public static final char                        S_ORDERSTATE_APPLY                  = 'E'; //已申请
    public static final char                        S_ORDERSTATE_INVALID                = 'F'; //无效单
    public static final char                        S_ORDERSTATE_PARTTRIGGERED          = 'G'; //部分触发
    public static final char                        S_ORDERSTATE_FILLTRIGGERED          = 'H'; //完全触发
    public static final char                        S_ORDERSTATE_TRIGGERFAILED          = 'M'; //触发失败
    public static final char                        S_ORDERSTATE_PARTFAILED             = 'I'; //余单失败
    public static final char                        S_ORDERSTATE_PAIRED                 = 'J'; //已配对;   //本地套利定单状态
    public static final char                        S_ORDERSTATE_PAIRING                = 'K'; //配对中;
    public static final char                        S_ORDERSTATE_UNPAIRED               = 'L'; //有瘸腿;
    public static final char                        S_ORDERSTATE_STOPLOSS               = 'N'; //开仓止损策略单不监控;
    public static final char                        S_ORDERSTATE_OPENSTOPLOSS           = 'S'; //开仓止损策略单不监控;

    //条件单类型
    public static final char                        S_ST_PREORDER                       = 'p'; //预备单(埋单)
    public static final char                        S_ST_AUTOORDER                      = 'A'; //自动单
    public static final char                        S_ST_CONDITION                      = 'C'; //条件单
    public static final char                        S_ST_CONDITION_PARENT               = 'D'; //父条件单
    public static final char                        S_ST_BACKHAND                       = 'E'; //条件单反手
    public static final char                        S_ST_STOPLOSS                       = 'L'; //止损单
    public static final char                        S_ST_STOPPROFIT                     = 'P'; //止盈单
    public static final char                        S_ST_FLOATSTOPLOSS                  = 'F'; //浮动止损单
    public static final char                        S_ST_BREAKEVEN                      = 'B'; //保本止损单
    public static final char                        S_ST_OPEN_STOPLOSS                  = 'O'; //开仓止损
    public static final char                        S_ST_OPEN_STOPPROFIT                = 'S'; //开仓止盈
    public static final char                        S_ST_OPEN_STOP_LOSS_SFLOAT          = 'U'; //浮动止损
    public static final char                        S_ST_OPEN_BREAKEVEN                 = 'T'; //开仓保本

    //消息级别
    public static final char                        S_ML_Info                           = 'I'; //提示
    public static final char                        S_ML_Warning                        = 'W'; //警告
    public static final char                        S_ML_Error                          = 'E'; //错误
    public static final char                        S_ML_Vital                          = 'V'; //重要
    public static final char                        S_ML_Urgent                         = 'U'; //紧急

    //定单类型
    //====================================StarApi_CLOUD===============================================
    //云端交易类型
    //定单类型
    public static final char                        S_ORDERTYPE_MARKET                  = '1'; //市价单
    public static final char                        S_ORDERTYPE_LIMIT                   = '2'; //限价单
    public static final char                        S_ORDERTYPE_MARKETSTOP              = '3'; //市价止损
    public static final char                        S_ORDERTYPE_LIMITSTOP               = '4'; //限价止损
    public static final char                        S_ORDERTYPE_EXECUTE                 = '5'; //行权
    public static final char                        S_ORDERTYPE_ABANDON                 = '6'; //弃权
    public static final char                        S_ORDERTYPE_ENQUIRY                 = '7'; //询价
    public static final char                        S_ORDERTYPE_OFFER                   = '8'; //应价
    public static final char                        S_ORDERTYPE_ICEBERG                 = '9'; //冰山单
    public static final char                        S_ORDERTYPE_GHOST                   = 'A'; //影子单
    public static final char                        S_ORDERTYPE_SWAP                    = 'B'; //互换
    public static final char                        S_ORDERTYPE_SPREADAPPLY             = 'C'; //套利申请
    public static final char                        S_ORDERTYPE_HEDGEAPPLY              = 'D'; //套保申请
    public static final char                        S_ORDERTYPE_OPTIONAUTOCLOSE         = 'E'; //期权自对冲
    public static final char                        S_ORDERTYPE_FUTUREAUTOCLOSE         = 'F'; //履约期货自对冲
    public static final char                        S_ORDERTYPE_STOCK_LOCK                 = 'L'; //证券仓位锁定单
    public static final char                        S_ORDERTYPE_STOCK_UNLOCK             = 'U'; //证券仓位解锁单

    //是否是下一个
    public static final byte                      S_NEXT_NO                     = 0;        //从当前开始
    public static final byte                      S_NEXT_YES                    = 1;        //从下一个开始

    //委托价类型
    public static final char                        S_PT_ABS                            = 'A'; //绝对价(指定价)
    public static final char                        S_PT_LSAT                           = 'L'; //最新价
    public static final char                        S_PT_QUEUE                          = 'Q'; //排队价
    public static final char                        S_PT_MATCH                          = 'M'; //对手价
    public static final char                        S_PT_MARKET                         = 'm'; //市价

    //委托来源
    public static final char                        S_ORDERWAY_DRAWLINE                 = 'd'; //画线下单
    public static final char                        S_ORDERWAY_PROXY_DRAWLINE           = 'w'; //PC画线下单
    public static final char                        S_ORDERWAY_ETRADE                   = 'E'; //E-Trade
    public static final char                        S_ORDERWAY_PROXYETRADE              = 'P'; //代理单
    public static final char                        S_ORDERWAY_CARRY                    = 'C'; //Carry单
    public static final char                        S_ORDERWAY_EXECUTE                  = 'e'; //行权
    public static final char                        S_ORDERWAY_ABANDON                  = 'a'; //弃权

    //订单操作
    public static final char                        S_OAT_CANCEL                        = 'C'; //撤单
    public static final char                        S_OAT_SUSPEND                       = 'S'; //挂起
    public static final char                        S_OAT_RESUME                        = 'R'; //激活

    //有效类型
    public static final char                        S_VALIDTYPE_FOK                     = '1'; //即时全部
    public static final char                        S_VALIDTYPE_IOC                     = '2'; //即时部分
    public static final char                        S_VALIDTYPE_GFD                     = '4'; //当日有效
    public static final char                        S_VALIDTYPE_GTC                     = '5'; //长期有效
    //触发模式
    public static final char                        S_TM_LATEST                         = 'L'; //最新价
    public static final char                        S_TM_BID                            = 'B'; //买价
    public static final char                        S_TM_ASK                            = 'A'; //卖价

    //触发条件
    public static final char                        S_TC_GREATER                        = 'g'; //大于
    public static final char                        S_TC_GREATEREQUAL                   = 'G'; //大于等于
    public static final char                        S_TC_LESS                           = 'l'; //小于
    public static final char                        S_TC_LESSEQUAL                      = 'L'; //小于等于

    //交易时段状态 交易时段仅用'3','4','5'，行情交易状态用所有
    public static final char            S_TRADESTATE_PAUSED       = '4';    //暂停

    //停损价类型
    public static final char                        S_SPT_PRICE                         = 'P'; //价格
    public static final char                        S_SPT_DIFF                          = 'D'; //价差

    //TC资讯查询方向
    public static final char                        SNEWS_DAY                   = 'D';       //每天
    public static final char                        SNEWS_SHORT_TERM            = 'S';       //短期
    public static final char                        SNEWS_MIDDLE_TERM           = 'M';       //中期
    public static final char                        SNEWS_FIFTEEN_MINUTE        = 'F';       //15分钟

    //行情字段含义
    public static final short                       S_FID_MEAN_COUNT          = 128;    //字段总数量

    //平仓方式
    public static final char                      S_COVER_NONE                  = 'N';    //不区分开平仓
    public static final char                      S_COVER_UNFINISH              = 'U';    //平仓未了结
    public static final char                      S_COVER_TODAY                 = 'T';    //开仓/平仓/平今

    //错误码
    public static final int                         S_LOGIN_TCPEXIST                    = -1;  //重复登录
    public static final int                         S_LOGIN_INITFAIL                    = -2;  //内部初始化错误
    public static final int                         S_LOGIN_SERVERVCLOSE                = -3;  //云服务器已关闭
    public static final int                         S_LOGIN_ADDRNOTEXIST                = -4;  //云服务器暂不支持该期货公司地址
    public static final int                         S_INIT_ACCESSFAIL                   =-5; //获取接入服务数据失败；
    public static final int                         S_INIT_QUOTEINITFAIL                =-6; //行情初始化失败；
    public static final int                         S_INIT_LICENSEWRONG                 =-7; //证书不合法
    public static final int                         S_INIT_ACCOUNTEXIST                 =-8; //账号已登录过其他地址

    //账单格式类型
    public static final char                        S_BFT_Text                          = 'T'; //纯文本
    public static final char                        S_BFT_Html                          = 'H'; //网页
    public static final char                        S_BFT_Pdf                           = 'P'; //Pdf
    public static final char                        S_BFT_Csv                           = 'C'; //Csv
    public static final char                        S_BFT_Link                          = 'L'; //链接

    //二次认证发送类型
    public static final char                        S_SENDTYPE_MAIL                     = 'M';//邮件
    public static final char                        S_SENDTYPE_SMS                      = 'S';//短信
    public static final char                        S_SENDTYPE_WEIXIN                   = 'W';//微信
    public static final char                        S_SENDTYPE_NULL                     = 'N';//不发送

    // 二次认证设备类型
    public static final char                        S_LOGINTYPE_NORMAL = 'N';                 //信任设备
    public static final char                        S_LOGINTYPE_TEMPORARY = 'T';              //临时设备
    public static final char                        S_LOGINTYPE_RESET = 'R';              // 重置密码


    //排序行情指标
    public static final char                        S_CONTRACT_SORT_TOTAL_QTY                = '0';  //成交量
    public static final char                        S_CONTRACT_SORT_TURNOVER                 = '1';  //成交金额
    public static final char                        S_CONTRACT_SORT_POSITION_QTY            = '2';  //持仓量
    public static final char                        S_CONTRACT_SORT_POSITION_RISE_QTY      = '3';  //日增仓
    public static final char                        S_CONTRACT_SORT_POSITION_RISE_PERCENT  = '4';  //日增仓比
    public static final char                        S_CONTRACT_SORT_RISE                      = '5';  //涨跌
    public static final char                        S_CONTRACT_SORT_RISE_PERCENT             = '6';  //涨跌幅

    //当前订单的报警原因
    public static final char                        S_PRICE_MONITOR_PRICE_MAX1                 = '0'; //价格上限1触发
    public static final char                        S_PRICE_MONITOR_PRICE_MAX2                 = '1';  //价格上限2触发
    public static final char                        S_PRICE_MONITOR_PRICE_MIN1                 = '2';  //价格下限1
    public static final char                        S_PRICE_MONITOR_PRICE_MIN2                 = '3';  //价格下限2
    public static final char                        S_PRICE_MONITOR_PRICE_GROWTH_WIDTH_MAX     = '4';  //涨幅上限
    public static final char                        S_PRICE_MONITOR_PRICE_GROWTH_WIDTH_MIN     = '5';  //涨幅下限
    public static final char                        S_PRICE_MONITOR_PRICE_GROWTH_SPEED_MAX     = '6';  //涨速上限
    public static final char                        S_PRICE_MONITOR_PRICE_GROWTH_SPEED_MIN     = '7';  //涨速下限
    public static final char                        S_PRICE_MONITOR_PRICE_LAST_VOL             = '8';   //现手
    public static final char                        S_PRICE_MONITOR_PRICE_VOLUME               = '9';  //成交量
    public static final char                        S_PRICE_MONITOR_PRICE_POSITION_MAX         = 'A';  //持仓量上限
    public static final char                        S_PRICE_MONITOR_PRICE_POSITION_MIN         = 'B';  //持仓量下限
    public static final char                        S_PRICE_MONITOR_PRICE_LIMIT_UP             = 'C';  //涨停价
    public static final char                        S_PRICE_MONITOR_PRICE_LIMIT_DOWN           = 'D';   //跌停价

    //服务事件类型 来自底层回报
    public static final short                     S_SRVEVENT_CONNECT            = 0x01; //连接
    public static final short                     S_SRVEVENT_DISCONNECT         = 0x02; //断开
    public static final short                      S_SRVEVENT_CONNECTFAIL      = 0x03;   //接入服务器失败
    public static final short                      S_SRVEVENT_INITFAIL          = 0x04;   //初始化失败
    public static final short                     S_SRVEVENT_QUOTE              = 0x20; //即时行情
    public static final short                     S_SRVEVENT_QUOTELOGIN         = 0x21; //登录行情前置
    public static final short                     S_SRVEVENT_QINITCOMPLETED     = 0x22; //行情初始化完成
    public static final short					  S_SRVEVENT_OPTIONCOMPLETED    = 0x23;	//期权数据初始化完成

    public static final short                     S_SRVEVENT_HISQUOTE           = 0x40; //历史行情
    public static final short                     S_SRVEVENT_HISLOGIN           = 0x41; //登录历史行情
    public static final short                     S_SRVEVENT_HINITCOMPLETED     = 0x42; //历史初始化完成
    public static final short                     S_SRVEVENT_TRADELOGOUT        = 0x51;  //登出交易
    public static final short                     S_SRVEVENT_TRADELOGINED        = 0x52;  //交易登录完成
    public static final short                      S_SRVEVENT_TRADE_LOG          = 0x53;   //交易日志
    public static final short                      S_SRVEVENT_RESET_PWD      = 0x57;  //允许重置密码
    public static final short                      S_SRVEVENT_RESET_VER_CER  = 0x58;  //身份验证
    public static final short                      S_SRVEVENT_RESET_SEC_CER  = 0x59;  //验证码验证
    public static final short                     S_SRVEVENT_TRADE              = 0x60; //交易
    public static final short                     S_SRVEVENT_TRADELOGIN         = 0x61; //登录交易前置
    public static final short                     S_SRVEVENT_TINITCOMPLETED     = 0x62; //交易初始化完成
    public static final short                     S_SRVEVENT_TRADE_ORDER        = 0x63; //交易委托变化
    public static final short                     S_SRVEVENT_TRADE_MATCH        = 0x64; //交易成交变化
    public static final short                     S_SRVEVENT_TRADE_POSITION     = 0x65; //交易持仓变化
    public static final short                     S_SRVEVENT_TRADE_FUND         = 0x66; //交易资金变化
    public static final short                     S_SRVEVENT_CHG_TRD_PWD        = 0x67; //修改交易密码
    public static final short                     S_SRVEVENT_CHG_FUND_PWD       = 0x68; //修改资金密码
    public static final short                     S_SRVEVENT_QRY_TRANSBANK      = 0x69; //转账银行查询
    public static final short                     S_SRVEVENT_QRY_SIGNBANK       = 0x6A; //签约银行查询
    public static final short                     S_SRVEVENT_QRY_BALANCE        = 0x6B; //账户余额查询
    public static final short                     S_SRVEVENT_BANKTRANSFER       = 0x6C; //银期转账
    public static final short                     S_SRVEVENT_QRY_TRANSFER       = 0x6D; //银期转账流水
    public static final short                     S_SRVEVENT_QRY_BILL           = 0x6E; //结算单查询
    public static final short                     S_SRVEVENT_TRADE_MESSAGE      = 0x6F; //消息变化
    public static final short                     S_SRVEVENT_TRADEDATECHG       =  0x70;//交易日切换
    public static final short                     S_SRVEVENT_TRADESUMPROFITCHG      = 0x71;   //浮盈合计变化通知
    public static final short                     S_SRVEVENT_TRADEPROFITCHG         = 0x72;   //浮盈明细变化通知
    public static final short                     S_SRVEVENT_TRADE_STRATEGY_ORDER   = 0x73;   //策略单
    public static final short                     S_SRVEVENT_SMSAUTH_NOTIFY         = 0x74;   //短消息
    public static final short                      S_SRVEVENT_BILLCONFIRMNOTICE     = 0x75;   //结算单确认通知
    public static final short                      S_SRVEVENT_BILLCONFIRM           = 0x76;   //结算单确认应答
    public static final short                      S_SRVEVENT_NEWSUPDATE            = 0x77;   //新闻更新
    public static final short                      S_SRVEVENT_HISQUOTEMINUTE        = 0x78;   //历史分时行情
    public static final short                      S_SRVEVENT_NEWSTAGUPDATE         = 0x79;   //新闻检索
    public static final short                      S_SRVEVENT_REGLOGIN              = 0x7A;   //登录认证服务器
    public static final short                      S_SRVEVENT_SMSAUTHINFO_RSP       = 0x7B;    //获取认证码 请求应答信息
    public static final short                      S_SRVEVENT_NEWSFTENUPDATE        = 0x7C;   //F10新闻检索
    public static final short                      S_SRVEVENT_NEWSTCREPORT          = 0x7D;   //tc资讯
    public static final short                     S_SRVEVENT_CONTRACTSORT         = 0x7E;   //行情排序
    public static final short                     S_SRVEVENT_TRADE_LOCK_POSITION         = 0x7F;   //交易冻结值变化

    public static final short                      S_SRVEVENT_MONITOR_QRY  = 0x80;   //价格预警查询
    public static final short                      S_SRVEVENT_MONITOR_RTN  = 0x81;   //价格预警回报
    public static final short                      S_SRVEVENT_MONITOR_ACTION = 0x82;   //价格预警下单回报
    public static final short                      S_SRVEVENT_MONITOR_DELETE = 0x83;   //价格预警下单回报

    public static final short                      S_SRVEVENT_ASX_PARAM            = 0x84;   //澳交所系统参数

    public static final int                        S_DATA_EVENT_LOGIN_MALL = 0X0100;
    public static final int                        S_DATA_EVENT_MODIFY_MALL_PASSWORD = 0X0101;
    public static final int                        S_DATA_EVENT_SEARCH_DATA = 0x0110;
    public static final int                        S_DATA_EVENT_CONFIG_DATA = 0x0111;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SEND_FAVORITE_TO_SERVER = 0x01110;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_FAVORITE_FROM_SERVER = 0x01111;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PC_FAVORITE_FROM_SERVER = 0x01112;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_FROM_SERVER = 0x01113;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_TO_SERVER = 0x01114;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_CLEAR_DATA = 0x01115;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_FAVORITE_FROM_SERVER_FAIL = 0x01116;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PC_FAVORITE_FROM_SERVER_FAIL = 0x01117;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_FROM_SERVER_FAIL = 0x01118;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SEND_FAVORITE_TO_SERVER_FAIL = 0x01119;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_TO_SERVER_FAIL = 0x01120;

    // 当前合约的类型
    public static final char	   QTE_COMM_TYPE_SPOT               = 'P';   //现货
    public static final char	   QTE_COMM_TYPE_SPOT_T             = 'Y';   //现货,T+1
    public static final char	   QTE_COMM_TYPE_FUTURES			= 'F';   //期货
    public static final char	   QTE_COMM_TYPE_OPTION			    = 'O';   //期权
    public static final char	   QTE_COMM_TYPE_SPREADS		    = 'S';   //跨期套利
    public static final char	   QTE_COMM_TYPE_SPREADM            = 'M';   //跨品种套利
    public static final char	   QTE_COMM_TYPE_INDEX			    = 'Z';   //指数
    public static final char	   QTE_COMM_TYPE_STOCK			    = 'T';   //股票
    public static final char	   QTE_COMM_TYPE_OTCOPTION		    = 'Q';   //场外期权
    public static final char	   QTE_COMM_TYPE_EFP    		    = 'A';   //期转现

    // 证件类型
    public static final char                   S_CT_ID                   = '1';    //内地身份证
    public static final char                   S_CT_Passport             = '6';    //中国护照，内地港澳通行证
    public static final char                   S_CT_BusinessLicense      = '9';    //营业执照
    public static final char                   S_CT_OtherID              = 'B';    //证件类型B 其他身份证
    public static final char                   S_CT_BusinessRegistration = 'R';    //证件类型X 商业登记证

    // 密码类型
    public static final char S_PT_Trader                     = 'T';           //交易
    public static final char S_PT_Reset                      = 'R';           //重置密码

    public final static long S_MAX_SESSION_ID = 0xffffffff;      //最大回话号
}
