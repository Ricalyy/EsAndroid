package com.esunny.data.bean;

import androidx.annotation.Nullable;

import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.inter.ApiStruct;

import java.math.BigInteger;

/**
 * @author huang
 */
public class Commodity {
    private String                                      CommodityNo;
    private String                                      CommodityName;

    private double                                      PriceNume;
    private int                                         PriceDeno;
    private double                                      PriceTick;
    private short                                       PricePrec;
    private float                                       PriceMultiple;
    private double                                      TradeDot;
    private double                                      ExerciseDot;
    private char                                        CoverMode;
    private char                                        SpreadDirect;
    private char                                        OptionExercise;
    private char                                        OptionProperty;

    private java.math.BigInteger                        MaxSingleOrderQty;
    private java.math.BigInteger                        MaxPositionQty;

    private Currency                                   Currency;
    private Exchange                                   Exchange;
//    private Commodity                                  TargetCommodity1;
    private String                                   TargetCommodity1;
//    private Contract                                   TargetContract1;
    private String                                   TargetContract1;
//    private Commodity                                  TargetCommodity2;
    private String                                  TargetCommodity2;

    public String getCommodityNo() {
        return CommodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        CommodityNo = commodityNo;
    }

    public String getCommodityName() {
        return CommodityName;
    }

    public void setCommodityName(String commodityName) {
        CommodityName = commodityName;
    }

    public double getPriceNume() {
        return PriceNume;
    }

    public void setPriceNume(double priceNume) {
        PriceNume = priceNume;
    }

    public int getPriceDeno() {
        return PriceDeno;
    }

    public void setPriceDeno(int priceDeno) {
        PriceDeno = priceDeno;
    }

    public double getPriceTick() {
        return PriceTick;
    }

    public void setPriceTick(double priceTick) {
        PriceTick = priceTick;
    }

    public short getPricePrec() {
        return PricePrec;
    }

    public void setPricePrec(short pricePrec) {
        PricePrec = pricePrec;
    }

    public float getPriceMultiple() {
        return PriceMultiple;
    }

    public void setPriceMultiple(float priceMultiple) {
        PriceMultiple = priceMultiple;
    }

    public double getTradeDot() {
        return TradeDot;
    }

    public void setTradeDot(double tradeDot) {
        TradeDot = tradeDot;
    }

    public double getExerciseDot() {
        return ExerciseDot;
    }

    public void setExerciseDot(double exerciseDot) {
        ExerciseDot = exerciseDot;
    }

    public char getCoverMode() {
        return CoverMode;
    }

    public void setCoverMode(char coverMode) {
        CoverMode = coverMode;
    }

    public char getSpreadDirect() {
        return SpreadDirect;
    }

    public void setSpreadDirect(char spreadDirect) {
        SpreadDirect = spreadDirect;
    }

    public char getOptionExercise() {
        return OptionExercise;
    }

    public void setOptionExercise(char optionExercise) {
        OptionExercise = optionExercise;
    }

    public char getOptionProperty() {
        return OptionProperty;
    }

    public void setOptionProperty(char optionProperty) {
        OptionProperty = optionProperty;
    }

    public BigInteger getMaxSingleOrderQty() {
        return MaxSingleOrderQty;
    }

    public void setMaxSingleOrderQty(BigInteger maxSingleOrderQty) {
        MaxSingleOrderQty = maxSingleOrderQty;
    }

    public BigInteger getMaxPositionQty() {
        return MaxPositionQty;
    }

    public void setMaxPositionQty(BigInteger maxPositionQty) {
        MaxPositionQty = maxPositionQty;
    }

    public String getTargetCommodity1() {
        return TargetCommodity1;
    }

    public void setTargetCommodity1(String targetCommodity1) {
        TargetCommodity1 = targetCommodity1;
    }

    public String  getTargetContract1() {
        return TargetContract1;
    }

    public void setTargetContract1(String targetContract1) {
        TargetContract1 = targetContract1;
    }

    public String getTargetCommodity2() {
        return TargetCommodity2;
    }

    public void setTargetCommodity2(String  targetCommodity2) {
        TargetCommodity2 = targetCommodity2;
    }

    public Currency getCurrency() {
        return Currency;
    }

    public void setCurrency(Currency currency) {
        Currency = currency;
    }

    public  Exchange getExchange() {
        return Exchange;
    }

    public void setExchange(Exchange exchange) {
        Exchange = exchange;
    }

    public double getTickPrice() {
        if (getPriceDeno() == 0) {
            return 1.0;
        } else if (getPriceDeno() == 1) {
            return getPriceNume();
        } else {
            return getPriceTick();
        }
    }

    public boolean isCoverT() {
        return getCoverMode() == EsDataConstant.S_COVER_TODAY;
    }

    @Override
    public String toString() {
        return getCommodityName();
    }

    @Override
    public int hashCode() {
        return CommodityNo.hashCode();
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        return obj instanceof Commodity && CommodityNo.equals(((Commodity) obj).CommodityNo);
    }
}
