package com.esunny.data.bean;

public class AddrInfo {

    private String ip;
    private int port;

    public AddrInfo() {
    }

    public AddrInfo(String ip, int port) {
        this.ip = ip;
        this.port = port;
    }

    public void setIp(String value)
    {
        ip=value;
    }

    public String getIp()
    {
        return ip;
    }

    public void setPort(int value)
    {
        port=value;
    }

    public int getPort()
    {
        return port;
    }

}
