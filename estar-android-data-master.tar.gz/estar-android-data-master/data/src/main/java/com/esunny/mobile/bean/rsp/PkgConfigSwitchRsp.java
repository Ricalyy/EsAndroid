package com.esunny.mobile.bean.rsp;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/9/18
 */
public class PkgConfigSwitchRsp extends ApiStruct {

    public final static short STRUCT_LENGTH = 53;

    public String ConfigSwitchNo;
    public short ConfigSwitchValue;

    private PkgConfigSwitchRsp(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);

        ConfigSwitchNo = parseUtil.getString(51);
        ConfigSwitchValue = (short) parseUtil.getUnsignedShort();
    }

    public String getConfigSwitchNo() {
        return ConfigSwitchNo;
    }

    public void setConfigSwitchNo(String configSwitchNo) {
        ConfigSwitchNo = configSwitchNo;
    }

    public short getConfigSwitchValue() {
        return ConfigSwitchValue;
    }

    public void setConfigSwitchValue(int configSwitchValue) {
        ConfigSwitchValue = (short) configSwitchValue;
    }

    public static PkgConfigSwitchRsp toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new PkgConfigSwitchRsp(data);
        } else {
            return null;
        }
    }
}
