package com.esunny.data.api.server;

import com.alibaba.android.arouter.facade.template.IProvider;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.data.bean.MonitorOrderAction;

import java.util.List;

/**
 * @author Peter Fu
 * @date 2020/11/23
 */
public interface EsMonitorApi extends IProvider {

    CallbackDispatcher getDispatcher();

    void setClientKey(int ret);

    int getClientKey();

    List<MonitorOrder> getMonitorOrder();

    int actionMonitorOrder(MonitorOrderAction order);
}
