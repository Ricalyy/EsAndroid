package com.esunny.data.database.table;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 * @author Peter Fu
 * @date 2020/11/18
 */
@Entity(nameInDb = "log_data")
public class LogData {
    @Id(autoincrement = true)
    private Long id;
    @Property(nameInDb = "SessionId")
    private Long SessionId;
    @Property(nameInDb = "OrderNo")
    private String OrderNo;
    @Property(nameInDb = "CompanyNo")
    private String CompanyNo;
    @Property(nameInDb = "UserNo")
    private String UserNo;
    @Property(nameInDb = "InsertDate")
    private String InsertDate;
    @Property(nameInDb = "UpdateDate")
    private String UpdateDate;
    @Property(nameInDb = "OrderState")
    private String OrderState;
    @Property(nameInDb = "OrderType")
    private String OrderType;
    @Property(nameInDb = "CreateDate")
    private String CreateDate;
    @Property(nameInDb = "CreateTime")
    private String CreateTime;
    @Property(nameInDb = "Content")
    private String Content;

    @Generated(hash = 330316043)
    public LogData(Long id, Long SessionId, String OrderNo, String CompanyNo,
            String UserNo, String InsertDate, String UpdateDate, String OrderState,
            String OrderType, String CreateDate, String CreateTime,
            String Content) {
        this.id = id;
        this.SessionId = SessionId;
        this.OrderNo = OrderNo;
        this.CompanyNo = CompanyNo;
        this.UserNo = UserNo;
        this.InsertDate = InsertDate;
        this.UpdateDate = UpdateDate;
        this.OrderState = OrderState;
        this.OrderType = OrderType;
        this.CreateDate = CreateDate;
        this.CreateTime = CreateTime;
        this.Content = Content;
    }

    @Generated(hash = 1020246481)
    public LogData() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSessionId() {
        return SessionId;
    }

    public void setSessionId(Long sessionId) {
        SessionId = sessionId;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getInsertDate() {
        return InsertDate;
    }

    public void setInsertDate(String insertDate) {
        InsertDate = insertDate;
    }

    public String getUpdateDate() {
        return UpdateDate;
    }

    public void setUpdateDate(String updateDate) {
        UpdateDate = updateDate;
    }

    public String getOrderState() {
        return OrderState;
    }

    public void setOrderState(String orderState) {
        OrderState = orderState;
    }

    public String getOrderType() {
        return OrderType;
    }

    public void setOrderType(String orderType) {
        OrderType = orderType;
    }

    public String getCreateDate() {
        return CreateDate;
    }

    public void setCreateDate(String createDate) {
        CreateDate = createDate;
    }

    public String getCreateTime() {
        return CreateTime;
    }

    public void setCreateTime(String createTime) {
        CreateTime = createTime;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }
}
