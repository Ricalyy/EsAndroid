package com.esunny.data.bean;

import java.math.BigInteger;

public class MonitorOrder extends MonitorOrderInsert{

    private BigInteger LastVol;        //现手
    private BigInteger						                      Volume;         //成交量
    private BigInteger 					                          PositionMax;	//持仓量上限
    private BigInteger						                      PositionMin;	//持仓量下限

    private boolean                                             LimitUp;	//涨停价
    private boolean                                             LimitDown;	//跌停价

    private String                                   MonitorRemark;  //监控备注

    private String                                   OrderNo;        //订单号
    private String                                   InsertDateTime; //下单时间
    private String						              UpdateDateTime;	//最后一次更新时间
    private char                                     OrderState;     //订单状态

    private int                                      ErrorCode;
    private String                                   ErrorText;
    private MonitorStateData[]                     Data;

    public BigInteger getLastVol() {
        return LastVol;
    }

    public void setLastVol(BigInteger lastVol) {
        LastVol = lastVol;
    }

    public BigInteger getVolume() {
        return Volume;
    }

    public void setVolume(BigInteger volume) {
        Volume = volume;
    }

    public BigInteger getPositionMax() {
        return PositionMax;
    }

    public void setPositionMax(BigInteger positionMax) {
        PositionMax = positionMax;
    }

    public BigInteger getPositionMin() {
        return PositionMin;
    }

    public void setPositionMin(BigInteger positionMin) {
        PositionMin = positionMin;
    }

    public boolean isLimitUp() {
        return LimitUp;
    }

    public void setLimitUp(boolean limitUp) {
        LimitUp = limitUp;
    }

    public boolean isLimitDown() {
        return LimitDown;
    }

    public void setLimitDown(boolean limitDown) {
        LimitDown = limitDown;
    }

    public String getMonitorRemark() {
        return MonitorRemark;
    }

    public void setMonitorRemark(String monitorRemark) {
        MonitorRemark = monitorRemark;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getInsertDateTime() {
        return InsertDateTime;
    }

    public void setInsertDateTime(String insertDateTime) {
        InsertDateTime = insertDateTime;
    }

    public String getUpdateDateTime() {
        return UpdateDateTime;
    }

    public void setUpdateDateTime(String updateDateTime) {
        UpdateDateTime = updateDateTime;
    }

    public char getOrderState() {
        return OrderState;
    }

    public void setOrderState(char orderState) {
        OrderState = orderState;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }

    public MonitorStateData[] getData() {
        return Data;
    }

    public void setData(MonitorStateData[] data) {
        Data = data;
    }
}
