package com.esunny.data.error;

import android.content.Context;

import com.esunny.data.R;

class CtpetfErrorCode {

    static String getErrorMessage(Context context, int errorCode) {

        switch (errorCode) {

            case -1 :
                return context.getResources().getString(R.string.ctpetf_n1);
            case -2 :
                return context.getResources().getString(R.string.ctpetf_n2);
            case 0 :
                return context.getResources().getString(R.string.ctpetf_0);
            case 1 :
                return context.getResources().getString(R.string.ctpetf_1);
            case 2 :
                return context.getResources().getString(R.string.ctpetf_2);
            case 3 :
                return context.getResources().getString(R.string.ctpetf_3);
            case 4 :
                return context.getResources().getString(R.string.ctpetf_4);
            case 5 :
                return context.getResources().getString(R.string.ctpetf_5);
            case 6 :
                return context.getResources().getString(R.string.ctpetf_6);
            case 7 :
                return context.getResources().getString(R.string.ctpetf_7);
            case 8 :
                return context.getResources().getString(R.string.ctpetf_8);
            case 9 :
                return context.getResources().getString(R.string.ctpetf_9);
            case 10 :
                return context.getResources().getString(R.string.ctpetf_10);
            case 11 :
                return context.getResources().getString(R.string.ctpetf_11);
            case 12 :
                return context.getResources().getString(R.string.ctpetf_12);
            case 13 :
                return context.getResources().getString(R.string.ctpetf_13);
            case 14 :
                return context.getResources().getString(R.string.ctpetf_14);
            case 15 :
                return context.getResources().getString(R.string.ctpetf_15);
            case 16 :
                return context.getResources().getString(R.string.ctpetf_16);
            case 17 :
                return context.getResources().getString(R.string.ctpetf_17);
            case 18 :
                return context.getResources().getString(R.string.ctpetf_18);
            case 19 :
                return context.getResources().getString(R.string.ctpetf_19);
            case 20 :
                return context.getResources().getString(R.string.ctpetf_20);
            case 21 :
                return context.getResources().getString(R.string.ctpetf_21);
            case 22 :
                return context.getResources().getString(R.string.ctpetf_22);
            case 23 :
                return context.getResources().getString(R.string.ctpetf_23);
            case 24 :
                return context.getResources().getString(R.string.ctpetf_24);
            case 25 :
                return context.getResources().getString(R.string.ctpetf_25);
            case 26 :
                return context.getResources().getString(R.string.ctpetf_26);
            case 27 :
                return context.getResources().getString(R.string.ctpetf_27);
            case 28 :
                return context.getResources().getString(R.string.ctpetf_28);
            case 29 :
                return context.getResources().getString(R.string.ctpetf_29);
            case 30 :
                return context.getResources().getString(R.string.ctpetf_30);
            case 31 :
                return context.getResources().getString(R.string.ctpetf_31);
            case 32 :
                return context.getResources().getString(R.string.ctpetf_32);
            case 33 :
                return context.getResources().getString(R.string.ctpetf_33);
            case 34 :
                return context.getResources().getString(R.string.ctpetf_34);
            case 35 :
                return context.getResources().getString(R.string.ctpetf_35);
            case 36 :
                return context.getResources().getString(R.string.ctpetf_36);
            case 37 :
                return context.getResources().getString(R.string.ctpetf_37);
            case 38 :
                return context.getResources().getString(R.string.ctpetf_38);
            case 39 :
                return context.getResources().getString(R.string.ctpetf_39);
            case 40 :
                return context.getResources().getString(R.string.ctpetf_40);
            case 41 :
                return context.getResources().getString(R.string.ctpetf_41);
            case 42 :
                return context.getResources().getString(R.string.ctpetf_42);
            case 43 :
                return context.getResources().getString(R.string.ctpetf_43);
            case 44 :
                return context.getResources().getString(R.string.ctpetf_44);
            case 45 :
                return context.getResources().getString(R.string.ctpetf_45);
            case 46 :
                return context.getResources().getString(R.string.ctpetf_46);
            case 47 :
                return context.getResources().getString(R.string.ctpetf_47);
            case 48 :
                return context.getResources().getString(R.string.ctpetf_48);
            case 49 :
                return context.getResources().getString(R.string.ctpetf_49);
            case 50 :
                return context.getResources().getString(R.string.ctpetf_50);
            case 51 :
                return context.getResources().getString(R.string.ctpetf_51);
            case 52 :
                return context.getResources().getString(R.string.ctpetf_52);
            case 53 :
                return context.getResources().getString(R.string.ctpetf_53);
            case 54 :
                return context.getResources().getString(R.string.ctpetf_54);
            case 55 :
                return context.getResources().getString(R.string.ctpetf_55);
            case 56 :
                return context.getResources().getString(R.string.ctpetf_56);
            case 57 :
                return context.getResources().getString(R.string.ctpetf_57);
            case 58 :
                return context.getResources().getString(R.string.ctpetf_58);
            case 59 :
                return context.getResources().getString(R.string.ctpetf_59);
            case 60 :
                return context.getResources().getString(R.string.ctpetf_60);
            case 61 :
                return context.getResources().getString(R.string.ctpetf_61);
            case 62 :
                return context.getResources().getString(R.string.ctpetf_62);
            case 63 :
                return context.getResources().getString(R.string.ctpetf_63);
            case 64 :
                return context.getResources().getString(R.string.ctpetf_64);
            case 65 :
                return context.getResources().getString(R.string.ctpetf_65);
            case 66 :
                return context.getResources().getString(R.string.ctpetf_66);
            case 67 :
                return context.getResources().getString(R.string.ctpetf_67);
            case 68 :
                return context.getResources().getString(R.string.ctpetf_68);
            case 69 :
                return context.getResources().getString(R.string.ctpetf_69);
            case 70 :
                return context.getResources().getString(R.string.ctpetf_70);
            case 71 :
                return context.getResources().getString(R.string.ctpetf_71);
            case 72 :
                return context.getResources().getString(R.string.ctpetf_72);
            case 73 :
                return context.getResources().getString(R.string.ctpetf_73);
            case 74 :
                return context.getResources().getString(R.string.ctpetf_74);
            case 75 :
                return context.getResources().getString(R.string.ctpetf_75);
            case 76 :
                return context.getResources().getString(R.string.ctpetf_76);
            case 77 :
                return context.getResources().getString(R.string.ctpetf_77);
            case 78 :
                return context.getResources().getString(R.string.ctpetf_78);
            case 79 :
                return context.getResources().getString(R.string.ctpetf_79);
            case 80 :
                return context.getResources().getString(R.string.ctpetf_80);
            case 81 :
                return context.getResources().getString(R.string.ctpetf_81);
            case 82 :
                return context.getResources().getString(R.string.ctpetf_82);
            case 83 :
                return context.getResources().getString(R.string.ctpetf_83);
            case 84 :
                return context.getResources().getString(R.string.ctpetf_84);
            case 85 :
                return context.getResources().getString(R.string.ctpetf_85);
            case 86 :
                return context.getResources().getString(R.string.ctpetf_86);
            case 87 :
                return context.getResources().getString(R.string.ctpetf_87);
            case 88 :
                return context.getResources().getString(R.string.ctpetf_88);
            case 89 :
                return context.getResources().getString(R.string.ctpetf_89);
            case 90 :
                return context.getResources().getString(R.string.ctpetf_90);
            case 91 :
                return context.getResources().getString(R.string.ctpetf_91);
            case 92 :
                return context.getResources().getString(R.string.ctpetf_92);
            case 93 :
                return context.getResources().getString(R.string.ctpetf_93);
            case 94 :
                return context.getResources().getString(R.string.ctpetf_94);
            case 95 :
                return context.getResources().getString(R.string.ctpetf_95);
            case 96 :
                return context.getResources().getString(R.string.ctpetf_96);
            case 97 :
                return context.getResources().getString(R.string.ctpetf_97);
            case 98 :
                return context.getResources().getString(R.string.ctpetf_98);
            case 99 :
                return context.getResources().getString(R.string.ctpetf_99);
            case 100 :
                return context.getResources().getString(R.string.ctpetf_100);
            case 101 :
                return context.getResources().getString(R.string.ctpetf_101);
            case 102 :
                return context.getResources().getString(R.string.ctpetf_102);
            case 103 :
                return context.getResources().getString(R.string.ctpetf_103);
            case 104 :
                return context.getResources().getString(R.string.ctpetf_104);
            case 105 :
                return context.getResources().getString(R.string.ctpetf_105);
            case 106 :
                return context.getResources().getString(R.string.ctpetf_106);
            case 107 :
                return context.getResources().getString(R.string.ctpetf_107);
            case 108 :
                return context.getResources().getString(R.string.ctpetf_108);
            case 109 :
                return context.getResources().getString(R.string.ctpetf_109);
            case 110 :
                return context.getResources().getString(R.string.ctpetf_110);
            case 111 :
                return context.getResources().getString(R.string.ctpetf_111);
            case 112 :
                return context.getResources().getString(R.string.ctpetf_112);
            case 113 :
                return context.getResources().getString(R.string.ctpetf_113);
            case 114 :
                return context.getResources().getString(R.string.ctpetf_114);
            case 115 :
                return context.getResources().getString(R.string.ctpetf_115);
            case 116 :
                return context.getResources().getString(R.string.ctpetf_116);
            case 117 :
                return context.getResources().getString(R.string.ctpetf_117);
            case 118 :
                return context.getResources().getString(R.string.ctpetf_118);
            case 119 :
                return context.getResources().getString(R.string.ctpetf_119);
            case 120 :
                return context.getResources().getString(R.string.ctpetf_120);
            case 121 :
                return context.getResources().getString(R.string.ctpetf_121);
            case 122 :
                return context.getResources().getString(R.string.ctpetf_122);
            case 123 :
                return context.getResources().getString(R.string.ctpetf_123);
            case 124 :
                return context.getResources().getString(R.string.ctpetf_124);
            case 125 :
                return context.getResources().getString(R.string.ctpetf_125);
            case 126 :
                return context.getResources().getString(R.string.ctpetf_126);
            case 127 :
                return context.getResources().getString(R.string.ctpetf_127);
            case 128 :
                return context.getResources().getString(R.string.ctpetf_128);
            case 129 :
                return context.getResources().getString(R.string.ctpetf_129);
            case 1000 :
                return context.getResources().getString(R.string.ctpetf_1000);
            case 1001 :
                return context.getResources().getString(R.string.ctpetf_1001);
            case 1002 :
                return context.getResources().getString(R.string.ctpetf_1002);
            case 1003 :
                return context.getResources().getString(R.string.ctpetf_1003);
            case 1004 :
                return context.getResources().getString(R.string.ctpetf_1004);
            case 1005 :
                return context.getResources().getString(R.string.ctpetf_1005);
            case 1006 :
                return context.getResources().getString(R.string.ctpetf_1006);
            case 1007 :
                return context.getResources().getString(R.string.ctpetf_1007);
            case 1008 :
                return context.getResources().getString(R.string.ctpetf_1008);
            case 1009 :
                return context.getResources().getString(R.string.ctpetf_1009);
            case 1010 :
                return context.getResources().getString(R.string.ctpetf_1010);
            case 1011 :
                return context.getResources().getString(R.string.ctpetf_1011);
            case 1012 :
                return context.getResources().getString(R.string.ctpetf_1012);
            case 1013 :
                return context.getResources().getString(R.string.ctpetf_1013);
            case 1014 :
                return context.getResources().getString(R.string.ctpetf_1014);
            case 1015 :
                return context.getResources().getString(R.string.ctpetf_1015);
            case 1016 :
                return context.getResources().getString(R.string.ctpetf_1016);
            case 1017 :
                return context.getResources().getString(R.string.ctpetf_1017);
            case 1018 :
                return context.getResources().getString(R.string.ctpetf_1018);
            case 1019 :
                return context.getResources().getString(R.string.ctpetf_1019);
            case 1020 :
                return context.getResources().getString(R.string.ctpetf_1020);
            case 1021 :
                return context.getResources().getString(R.string.ctpetf_1021);
            case 1022 :
                return context.getResources().getString(R.string.ctpetf_1022);
            case 1023 :
                return context.getResources().getString(R.string.ctpetf_1023);
            case 1024 :
                return context.getResources().getString(R.string.ctpetf_1024);
            case 1025 :
                return context.getResources().getString(R.string.ctpetf_1025);
            case 1026 :
                return context.getResources().getString(R.string.ctpetf_1026);
            case 1027 :
                return context.getResources().getString(R.string.ctpetf_1027);
            case 1028 :
                return context.getResources().getString(R.string.ctpetf_1028);
            case 1029 :
                return context.getResources().getString(R.string.ctpetf_1029);
            case 1030 :
                return context.getResources().getString(R.string.ctpetf_1030);
            case 1031 :
                return context.getResources().getString(R.string.ctpetf_1031);
            case 1032 :
                return context.getResources().getString(R.string.ctpetf_1032);
            case 1033 :
                return context.getResources().getString(R.string.ctpetf_1033);
            case 1034 :
                return context.getResources().getString(R.string.ctpetf_1034);
            case 1035 :
                return context.getResources().getString(R.string.ctpetf_1035);
            case 1036 :
                return context.getResources().getString(R.string.ctpetf_1036);
            case 1037 :
                return context.getResources().getString(R.string.ctpetf_1037);
            case 1038 :
                return context.getResources().getString(R.string.ctpetf_1038);
            case 1039 :
                return context.getResources().getString(R.string.ctpetf_1039);
            case 1040 :
                return context.getResources().getString(R.string.ctpetf_1040);
            case 1041 :
                return context.getResources().getString(R.string.ctpetf_1041);
            case 2000 :
                return context.getResources().getString(R.string.ctpetf_2000);
            case 2001 :
                return context.getResources().getString(R.string.ctpetf_2001);
            case 2004 :
                return context.getResources().getString(R.string.ctpetf_2004);
            case 2005 :
                return context.getResources().getString(R.string.ctpetf_2005);
            case 2006 :
                return context.getResources().getString(R.string.ctpetf_2006);
            case 2007 :
                return context.getResources().getString(R.string.ctpetf_2007);
            case 2008 :
                return context.getResources().getString(R.string.ctpetf_2008);
            case 2009 :
                return context.getResources().getString(R.string.ctpetf_2009);
            case 2011 :
                return context.getResources().getString(R.string.ctpetf_2011);
            case 2012 :
                return context.getResources().getString(R.string.ctpetf_2012);
            case 2013 :
                return context.getResources().getString(R.string.ctpetf_2013);
            case 2014 :
                return context.getResources().getString(R.string.ctpetf_2014);
            case 2015 :
                return context.getResources().getString(R.string.ctpetf_2015);
            case 999999 :
                return context.getResources().getString(R.string.ctpetf_999999);
            case 3001 :
                return context.getResources().getString(R.string.ctpetf_3001);
            case 3002 :
                return context.getResources().getString(R.string.ctpetf_3002);
            case 3005 :
                return context.getResources().getString(R.string.ctpetf_3005);
            case 3006 :
                return context.getResources().getString(R.string.ctpetf_3006);
            case 3007 :
                return context.getResources().getString(R.string.ctpetf_3007);
            case 3009 :
                return context.getResources().getString(R.string.ctpetf_3009);
            case 3010 :
                return context.getResources().getString(R.string.ctpetf_3010);
            case 3011 :
                return context.getResources().getString(R.string.ctpetf_3011);
            case 3017 :
                return context.getResources().getString(R.string.ctpetf_3017);
            case 3019 :
                return context.getResources().getString(R.string.ctpetf_3019);
            case 3020 :
                return context.getResources().getString(R.string.ctpetf_3020);
            case 3021 :
                return context.getResources().getString(R.string.ctpetf_3021);
            case 3022 :
                return context.getResources().getString(R.string.ctpetf_3022);
            case 3023 :
                return context.getResources().getString(R.string.ctpetf_3023);
            case 3026 :
                return context.getResources().getString(R.string.ctpetf_3026);
            case 3030 :
                return context.getResources().getString(R.string.ctpetf_3030);
            case 3035 :
                return context.getResources().getString(R.string.ctpetf_3035);
            case 3036 :
                return context.getResources().getString(R.string.ctpetf_3036);
            case 3037 :
                return context.getResources().getString(R.string.ctpetf_3037);
            case 3038 :
                return context.getResources().getString(R.string.ctpetf_3038);
            case 4096 :
                return context.getResources().getString(R.string.ctpetf_4096);
            case 4097 :
                return context.getResources().getString(R.string.ctpetf_4097);
            case 4098 :
                return context.getResources().getString(R.string.ctpetf_4098);
            case 8193 :
                return context.getResources().getString(R.string.ctpetf_8193);
            case 8194 :
                return context.getResources().getString(R.string.ctpetf_8194);
            case 8195 :
                return context.getResources().getString(R.string.ctpetf_8195);
            case 990001 :
                return context.getResources().getString(R.string.ctpetf_990001);
            case 990002 :
                return context.getResources().getString(R.string.ctpetf_990002);
            case 990003 :
                return context.getResources().getString(R.string.ctpetf_990003);
            case 990004 :
                return context.getResources().getString(R.string.ctpetf_990004);
            case 990005 :
                return context.getResources().getString(R.string.ctpetf_990005);
            case 990006 :
                return context.getResources().getString(R.string.ctpetf_990006);
            case 990007 :
                return context.getResources().getString(R.string.ctpetf_990007);
            case 990008 :
                return context.getResources().getString(R.string.ctpetf_990008);
            case 990009 :
                return context.getResources().getString(R.string.ctpetf_990009);
            case 990010 :
                return context.getResources().getString(R.string.ctpetf_990010);
            case 990011 :
                return context.getResources().getString(R.string.ctpetf_990011);
            case 990012 :
                return context.getResources().getString(R.string.ctpetf_990012);
            case 990013 :
                return context.getResources().getString(R.string.ctpetf_990013);
            case 990101 :
                return context.getResources().getString(R.string.ctpetf_990101);
            case 990102 :
                return context.getResources().getString(R.string.ctpetf_990102);
            case 990103 :
                return context.getResources().getString(R.string.ctpetf_990103);
            case 990104 :
                return context.getResources().getString(R.string.ctpetf_990104);
            case 990105 :
                return context.getResources().getString(R.string.ctpetf_990105);
            case 990106 :
                return context.getResources().getString(R.string.ctpetf_990106);
            case 990107 :
                return context.getResources().getString(R.string.ctpetf_990107);
            case 990108 :
                return context.getResources().getString(R.string.ctpetf_990108);
            case 990109 :
                return context.getResources().getString(R.string.ctpetf_990109);
            case 990110 :
                return context.getResources().getString(R.string.ctpetf_990110);
            case 990201 :
                return context.getResources().getString(R.string.ctpetf_990201);
            case 990202 :
                return context.getResources().getString(R.string.ctpetf_990202);
            case 990203 :
                return context.getResources().getString(R.string.ctpetf_990203);
            case 990204 :
                return context.getResources().getString(R.string.ctpetf_990204);
            case 990205 :
                return context.getResources().getString(R.string.ctpetf_990205);
            case 990206 :
                return context.getResources().getString(R.string.ctpetf_990206);
            case 990207 :
                return context.getResources().getString(R.string.ctpetf_990207);
            case 990208 :
                return context.getResources().getString(R.string.ctpetf_990208);
            case 990209 :
                return context.getResources().getString(R.string.ctpetf_990209);
            case 990210 :
                return context.getResources().getString(R.string.ctpetf_990210);
            case 990301 :
                return context.getResources().getString(R.string.ctpetf_990301);
            case 990302 :
                return context.getResources().getString(R.string.ctpetf_990302);
            case 990303 :
                return context.getResources().getString(R.string.ctpetf_990303);
            case 990304 :
                return context.getResources().getString(R.string.ctpetf_990304);
            case 990305 :
                return context.getResources().getString(R.string.ctpetf_990305);
            case 990306 :
                return context.getResources().getString(R.string.ctpetf_990306);
            case 990307 :
                return context.getResources().getString(R.string.ctpetf_990307);
            case 990308 :
                return context.getResources().getString(R.string.ctpetf_990308);
            case 990309 :
                return context.getResources().getString(R.string.ctpetf_990309);
            case 990310 :
                return context.getResources().getString(R.string.ctpetf_990310);
            case 990311 :
                return context.getResources().getString(R.string.ctpetf_990311);
            case 990312 :
                return context.getResources().getString(R.string.ctpetf_990312);
            case 990313 :
                return context.getResources().getString(R.string.ctpetf_990313);
            case 990314 :
                return context.getResources().getString(R.string.ctpetf_990314);
            default:
                return "";
        }
    }
}
