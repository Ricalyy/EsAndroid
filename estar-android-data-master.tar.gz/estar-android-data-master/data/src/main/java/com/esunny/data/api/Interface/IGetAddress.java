package com.esunny.data.api.Interface;

import com.esunny.data.bean.Address;

/**
 * @author Peter Fu
 * @date 2020/12/3
 */
public interface IGetAddress {
    void getAddress(Address[] addresses);
}
