package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class VerifyIdentityReq {
    private String userNo;
    private char certificateType;        //证件类型
    private String certificateNo;          //证件号
    private String email;                  //邮箱号
    private String phoneNumber;            //手机号

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public char getCertificateType() {
        return certificateType;
    }

    public void setCertificateType(char certificateType) {
        this.certificateType = certificateType;
    }

    public String getCertificateNo() {
        return certificateNo;
    }

    public void setCertificateNo(String certificateNo) {
        this.certificateNo = certificateNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
