package com.esunny.data.database;

/**
 * @author Peter Fu
 * @date 2020/10/13
 */
public class ServerDatabaseHelper {
    private static final String TAG = "ServerSettingDatabaseHe";

    public static final int DATABASE_VERSION = 1;

    public static final String ESUNNY_DATABASE_NAME = "esunny.db";

}
