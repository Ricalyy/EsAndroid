package com.esunny.data.api;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

import android.text.TextUtils;
import android.webkit.CookieManager;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.esunny.data.api.event.NewsEvent;
import com.esunny.data.api.server.EsQuoteApi;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.F10Content;
import com.esunny.data.bean.NewsTCContract;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsSPHelperProxy;

import org.greenrobot.eventbus.EventBus;

import java.io.IOException;
import java.security.PublicKey;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class EsWebApi {
    private static final String TAG = EsWebApi.class.getSimpleName();

    private final static String CONTENT_TYPE = "application/json; charset=utf-8";

//    private final static String GET_NEWS_URL = "http://news.epolestar.xyz/newsH5/CHS/getClass.cgi";
//    private final static String GET_NEWS_TAG_URL = "http://news.epolestar.xyz/newsH5/CHS/getTags.cgi";
//    private final static String GET_TAG_NEWS_URL = "http://news.epolestar.xyz/newsH5/CHS/getTagNews.cgi";
//    private final static String GET_NEWS_DETAIL_URL = "http://news.epolestar.xyz/PC/CHS/client/getContent.cgi";

    private final static String GET_NEWS_BASE_URL = "http://news.epolestar.xyz/flask/";
    private final static String GET_NEWS_URL = GET_NEWS_BASE_URL + "news/index.cgi";
    private final static String GET_NEWS_TAG_URL = GET_NEWS_URL;
    private final static String GET_TAG_NEWS_URL = GET_NEWS_URL;
    private final static String GET_NEWS_DETAIL_URL = GET_NEWS_URL;
    private final static String GET_NEWS_F10_URL = GET_NEWS_BASE_URL + "news/F10/";
    private final static String GET_NEWS_TC_REPORT_CONTRACT_URL = GET_NEWS_BASE_URL + "news/tc/report/contract/";
    private final static String GET_NEWS_TC_REPORT_URL = GET_NEWS_BASE_URL + "news/tc/report/";
    private final static String GET_SEARCH_INFO_URL = GET_NEWS_BASE_URL + "terminal/search/";
    private final static String GET_SERVER_INFO_URL = GET_NEWS_BASE_URL + "terminal/server/";
    private final static String GET_UPLOAD_CONTRACT_INFO_URL = GET_NEWS_BASE_URL + "terminal/server/contract/";
    private final static String GET_UPLOAD_SETTING_INFO_URL = GET_NEWS_BASE_URL + "terminal/server/setting/";
    private final static String GET_SERVER_INFO_CLEAR_URL = GET_NEWS_BASE_URL + "terminal/server/clear/";

    private final static String GET_MALL_BASE_URL = "http://pay.epolestar.xyz/";
    public final static String GET_MALL_URL = GET_MALL_BASE_URL + "phone/";
//    public final static String GET_MALL_URL = "http://192.168.18.155:8080/";
//    private final static String GET_MALL_SERVER_URL = GET_MALL_BASE_URL + "flask/index.wsgi";


    /**
     * @param count    查询数量
     * @param qryDate
     * @param newsId   新闻的ID，新闻数据按id从大到小排序，0为默认。
     * @param isOrder  是否正序，正序为从大到小查询   例如id为34156, direction为85则数据从34155,34154逐减10个数据。若direction为68，则向上查询最新count个数据
     *                 85是UP的U的ASCII码，68是DOWN中D的ASCII码....
     * @param callback
     */

    public static void getNews(int count, String qryDate, Integer newsId, boolean isOrder, Callback callback) {
        MediaType mediaType = MediaType.parse(CONTENT_TYPE);//数据类型为json格式，
        JSONObject requetJson = new JSONObject();
        JSONObject jsonReqHead = new JSONObject();
        JSONObject jsonReqData = new JSONObject();

        jsonReqHead.put("SubSystem", 8);
        jsonReqHead.put("FieldSize", 1);
        jsonReqHead.put("AuthCode", "");
        jsonReqHead.put("ProtocolCode", 20496);

        jsonReqData.put("NewsClassID", 0);
        jsonReqData.put("NewsID", newsId);
        jsonReqData.put("Count", count);
        jsonReqData.put("Direction", isOrder ? 85 : 68);
        jsonReqData.put("QryDate", qryDate);
        jsonReqData.put("PackageNo", EsDataApi.getPackageNo());

        requetJson.put("JsonReqHead", jsonReqHead);
        requetJson.put("JsonReqData", jsonReqData);
        RequestBody body = RequestBody.create(mediaType, requetJson.toJSONString());

        Request request = new Request.Builder()
                .url(GET_NEWS_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(callback);
    }

    /**
     * <p>查询资讯搜索模糊匹配的映射表</p>
     *
     * @param callback
     */
    public static void getNewsTag(Callback callback) {
        MediaType mediaType = MediaType.parse(CONTENT_TYPE);//数据类型为json格式，
        JSONObject requetJson = new JSONObject();
        JSONObject jsonReqHead = new JSONObject();
        JSONObject jsonReqData = new JSONObject();

        jsonReqHead.put("SubSystem", 8);
        jsonReqHead.put("FieldSize", 1);
        jsonReqHead.put("AuthCode", "");
        jsonReqHead.put("ProtocolCode", 20528);

        jsonReqData.put("Lang", "");

        requetJson.put("JsonReqHead", jsonReqHead);
        requetJson.put("JsonReqData", jsonReqData);
        RequestBody body = RequestBody.create(mediaType, requetJson.toJSONString());

        Request request = new Request.Builder()
                .url(GET_NEWS_TAG_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(callback);
    }

    /**
     * 根据筛选内容及日期来过滤资讯
     *
     * @param newsTag  过滤筛选的内容
     * @param qryDate  筛选查询日期
     * @param callback
     */
    public static void getTagNews(int count, String newsTag, Integer newsId, String qryDate, boolean isOrder, Callback callback) {
        MediaType mediaType = MediaType.parse(CONTENT_TYPE);//数据类型为json格式，
        JSONObject requetJson = new JSONObject();
        JSONObject jsonReqHead = new JSONObject();
        JSONObject jsonReqData = new JSONObject();

        jsonReqHead.put("SubSystem", 8);
        jsonReqHead.put("FieldSize", 1);
        jsonReqHead.put("AuthCode", "");
        jsonReqHead.put("ProtocolCode", 20560);

        jsonReqData.put("NewsTag", newsTag);
        jsonReqData.put("NewsID", newsId);
        jsonReqData.put("Count", count);
        jsonReqData.put("Direction", isOrder ? 85 : 68);
        jsonReqData.put("QryDate", qryDate);
        jsonReqData.put("PackageNo", EsDataApi.getPackageNo());

        requetJson.put("JsonReqHead", jsonReqHead);
        requetJson.put("JsonReqData", jsonReqData);
        RequestBody body = RequestBody.create(mediaType, requetJson.toJSONString());

        Request request = new Request.Builder()
                .url(GET_TAG_NEWS_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(callback);
    }

    /**
     * 获取新闻的详细内容
     *
     * @param newsId   新闻id
     * @param callback
     */
    public static void getNewsDetail(int newsId, Callback callback) {
        MediaType mediaType = MediaType.parse(CONTENT_TYPE);//数据类型为json格式，
        JSONObject requetJson = new JSONObject();
        JSONObject jsonReqHead = new JSONObject();
        JSONObject jsonReqData = new JSONObject();

        jsonReqHead.put("SubSystem", 8);
        jsonReqHead.put("FieldSize", 1);
        jsonReqHead.put("AuthCode", "");
        jsonReqHead.put("ProtocolCode", 20512);

        jsonReqData.put("NewsID", newsId);

        requetJson.put("JsonReqHead", jsonReqHead);
        requetJson.put("JsonReqData", jsonReqData);
        RequestBody body = RequestBody.create(mediaType, requetJson.toJSONString());

        Request request = new Request.Builder()
                .url(GET_NEWS_DETAIL_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(callback);
    }

    private static void sendEventMessage(int msgId, Object jsonObject) {
        NewsEvent.Builder builder = new NewsEvent.Builder(msgId);
        builder.setData(jsonObject);
        EventBus.getDefault().post(builder.buildEvent());
    }

    public static void sendUserInfo(JSONObject userDataJson, Callback callback) {
        MediaType mediaType = MediaType.parse(CONTENT_TYPE);//数据类型为json格式，

        RequestBody body = RequestBody.create(mediaType, userDataJson.toJSONString());

        Request request = new Request.Builder()
                .url("http://118.25.173.30:5000/index.wsgi")
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(callback);
    }

    public static void getSearchData(String key) {
        MediaType mediaType = MediaType.parse(CONTENT_TYPE);//数据类型为json格式，

        JSONObject data = new JSONObject();
        data.put("searchKey", key);
        data.put("searchType", "M");
        data.put("count", 100);

        RequestBody body = RequestBody.create(mediaType, data.toJSONString());

        final Request request = new Request.Builder()
                .url(GET_SEARCH_INFO_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                EsLog.d(TAG, "onFailure getSearchData error", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                JSONObject jsonObject = null;
                try {
                    jsonObject = JSONObject.parseObject(response.body().string());
                } catch (JSONException | IOException e) {
                    EsLog.d(TAG, "onResponse getSearchData error", e);
                }

                if (jsonObject == null) {
                    return;
                }

                sendEventMessage(EsDataConstant.S_DATA_EVENT_SEARCH_DATA, jsonObject);
            }
        });
    }

    public static int sendFavoriteContract(List<Contract> contractList) {
        QuoteLoginInfo info = EsDataApi.quoteLoginInfo();
        if (info == null) {
            return -1;
        }

        String userNo =  info.getLoginNo();
        if (TextUtils.isEmpty(userNo)) {
            return -2;
        }

        JSONArray jsonArray = new JSONArray();
        for (Contract contract : contractList) {
            if (contract == null || TextUtils.isEmpty(contract.getContractNo())) {
                continue;
            }
            jsonArray.add(contract.getContractNo());
        }

        JSONObject reqData = new JSONObject();
        reqData.put("userNo", userNo);
        reqData.put("source", 1);
        reqData.put("contractList", jsonArray);

        MediaType mediaType = MediaType.parse(CONTENT_TYPE);
        RequestBody body = RequestBody.create(mediaType, reqData.toJSONString());

        EsLog.d(TAG, "send contract data : " + reqData.toJSONString());
        final Request request = new Request.Builder()
                .url(GET_UPLOAD_CONTRACT_INFO_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                EsLog.d(TAG, "onFailure sendFavoriteContract error", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                JSONObject jsonObject = null;
                try {
                    jsonObject = JSONObject.parseObject(response.body().string());
                } catch (JSONException | IOException e) {
                    EsLog.d(TAG, "onResponse sendFavoriteContract error", e);
                }

                if (jsonObject == null) {
                    return;
                }

                sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SEND_FAVORITE_TO_SERVER, jsonObject);
            }
        });

        return 0;
    }

    public static int sendSetting(JSONObject settingConfiJson) {
        QuoteLoginInfo info = EsDataApi.quoteLoginInfo();
        if (info == null) {
            return -1;
        }

        String userNo = info.getLoginNo();
        if (TextUtils.isEmpty(userNo)) {
            return -2;
        }

        JSONObject reqData = new JSONObject();
        reqData.put("userNo", userNo);
        reqData.put("source", 1);
        reqData.put("settingsConfig", settingConfiJson);

        MediaType mediaType = MediaType.parse(CONTENT_TYPE);
        RequestBody body = RequestBody.create(mediaType, reqData.toJSONString());

        EsLog.d(TAG, "sendSetting data : " + reqData.toJSONString());
        final Request request = new Request.Builder()
                .url(GET_UPLOAD_SETTING_INFO_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                EsLog.d(TAG, "onFailure sendFavoriteContract error", e);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                JSONObject jsonObject = null;
                try {
                    jsonObject = JSONObject.parseObject(response.body().string());
                } catch (JSONException | IOException e) {
                    EsLog.d(TAG, "onResponse sendFavoriteContract error", e);
                }

                if (jsonObject == null) {
                    return;
                }

                sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_TO_SERVER, jsonObject);
            }
        });

        return 0;
    }
    /**
     * 获取云端自选合约数据
     * @param source 数据源，1为移动端，2为pc端
     * @param dataType 数据类型，1为自选合约，2为设置
     * @return 请求发送的结果
     */
    public static int getConfigData(final int source, final int dataType) {
        QuoteLoginInfo info = EsDataApi.quoteLoginInfo();
        if (info == null) {
            return -1;
        }

        String userNo = info.getLoginNo();
        if (TextUtils.isEmpty(userNo)) {
            return -2;
        }

        JSONObject reqData = new JSONObject();
        reqData.put("userNo", userNo);
        reqData.put("source", source);
        reqData.put("dataType", dataType);

        MediaType mediaType = MediaType.parse(CONTENT_TYPE);
        RequestBody body = RequestBody.create(mediaType, reqData.toJSONString());

        final Request request = new Request.Builder()
                .url(GET_SERVER_INFO_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                EsLog.d(TAG, "onFailure getConfigData error", e);
                if (source == 1 && dataType == 1) {
                    sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_FAVORITE_FROM_SERVER_FAIL, null);
                } else if (source == 1 && dataType == 2) {
                    sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PC_FAVORITE_FROM_SERVER_FAIL, null);
                } else if (source == 2){
                    sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_FROM_SERVER_FAIL, null);
                }
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                JSONObject jsonObject = null;
                try {
                    jsonObject = JSONObject.parseObject(response.body().string());
                } catch (JSONException | IOException e) {
                    EsLog.d(TAG, "onResponse getConfigData error", e);
                }

                if (jsonObject == null) {
                    return;
                }

                if (source == 1 && dataType == 1) {
                    sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_FAVORITE_FROM_SERVER, jsonObject);
                } else if (source == 1 && dataType == 2) {
                    sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_FROM_SERVER, jsonObject);
                } else if (source == 2){
                    sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_SYNC_PC_FAVORITE_FROM_SERVER, jsonObject);
                }
            }
        });

        return 0;
    }

    public static int clearConfigData() {
        QuoteLoginInfo info = EsDataApi.quoteLoginInfo();
        if (info == null) {
            return -1;
        }

        String userNo = info.getLoginNo();
        if (TextUtils.isEmpty(userNo)) {
            return -2;
        }

        JSONObject result = new JSONObject();
        result.put("userNo", userNo);

        MediaType mediaType = MediaType.parse(CONTENT_TYPE);
        RequestBody body = RequestBody.create(mediaType, result.toJSONString());

        final Request request = new Request.Builder()
                .url(GET_SERVER_INFO_CLEAR_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                EsLog.d(TAG, "onFailure clearConfigData error", e);
            }

            @Override
            public void onResponse(Call call, Response response) {
                JSONObject jsonObject = null;
                try {
                    jsonObject = JSONObject.parseObject(response.body().string());
                } catch (JSONException | IOException e) {
                    EsLog.d(TAG, "onResponse clearConfigData error", e);
                }

                if (jsonObject == null) {
                    return;
                }

                sendEventMessage(EsDataConstant.S_DATA_EVENT_CONFIG_DATA_CLEAR_DATA, jsonObject);
            }
        });

        return 0;
    }

    public static int qryFTenInfo(int lang, String scom) {
        JSONObject req = new JSONObject();
        req.put("Commodity", scom);
        req.put("Language", lang);

        MediaType mediaType = MediaType.parse(CONTENT_TYPE);
        RequestBody body = RequestBody.create(mediaType, req.toJSONString());


        final Request request = new Request.Builder()
                .url(GET_NEWS_F10_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) {
                JSONObject jsonObject = null;
                try {
                    jsonObject = JSONObject.parseObject(response.body().string());
                } catch (JSONException | IOException e) {
                    EsLog.d(TAG, "onResponse qryFTenInfo error", e);
                }

                if (jsonObject == null) {
                    sendEventMessage(EsDataConstant.S_SRVEVENT_NEWSFTENUPDATE, null);
                    return;
                }

                int errorCode = jsonObject.getInteger("ErrorCode");
                if (errorCode != 0) {
                    sendEventMessage(EsDataConstant.S_SRVEVENT_NEWSFTENUPDATE, null);
                    return;
                }

                String object = jsonObject.getString("Data");
                if (object == null) {
                    sendEventMessage(EsDataConstant.S_SRVEVENT_NEWSFTENUPDATE, null);
                    return;
                }

                F10Content f10Content = JSON.parseObject(object, F10Content.class);
                sendEventMessage(EsDataConstant.S_SRVEVENT_NEWSFTENUPDATE, f10Content);
            }
        });

        return 0;
    }

//    public static int qryTCContract() {
//
//        final Request request = new Request.Builder()
//                .url(GET_NEWS_TC_REPORT_CONTRACT_URL)
//                .get()
//                .build();
//        OkHttpClient okHttpClient = new OkHttpClient();
//        okHttpClient.newCall(request).enqueue(new Callback() {
//            @Override
//            public void onFailure(Call call, IOException e) {
//
//            }
//
//            @Override
//            public void onResponse(Call call, Response response) {
//                JSONObject jsonObject = null;
//                try {
//                    jsonObject = JSONObject.parseObject(response.body().string());
//                } catch (JSONException | IOException e) {
//                    EsLog.d(TAG, "onResponse qryTCReport error", e);
//                }
//
//                if (jsonObject == null) {
//                    return;
//                }
//
//                int errorCode = jsonObject.getInteger("ErrorCode");
//                if (errorCode != 0) {
//                    return;
//                }
//
//                String object = jsonObject.getString("Data");
//                if (object == null) {
//                    return;
//
//                }
//                List list = JSONObject.parseObject(object, List.class);
//                EsBaseApi.getInstance().setTcContractList(list);
//            }
//        });
//        return 0;
//    }

    public static int qryTCReport(String contractNo, char timeType) {
        JSONObject req = new JSONObject();
        req.put("ContractNo", contractNo);
        req.put("TimeType", timeType);

        MediaType mediaType = MediaType.parse(CONTENT_TYPE);
        RequestBody body = RequestBody.create(mediaType, req.toJSONString());


        final Request request = new Request.Builder()
                .url(GET_NEWS_TC_REPORT_URL)
                .post(body)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) {
                JSONObject jsonObject = null;
                try {
                    jsonObject = JSONObject.parseObject(response.body().string());
                } catch (JSONException | IOException e) {
                    EsLog.d(TAG, "onResponse qryTCReport error", e);
                }

                if (jsonObject == null) {
                    sendEventMessage(EsDataConstant.S_SRVEVENT_NEWSTCREPORT, null);
                    return;
                }

                int errorCode = jsonObject.getInteger("ErrorCode");
                if (errorCode != 0) {
                    sendEventMessage(EsDataConstant.S_SRVEVENT_NEWSTCREPORT, null);
                    return;
                }

                String object = jsonObject.getString("Data");
                if (object == null) {
                    sendEventMessage(EsDataConstant.S_SRVEVENT_NEWSTCREPORT, null);
                    return;
                }

                NewsTCContract report = JSON.parseObject(object, NewsTCContract.class);
                sendEventMessage(EsDataConstant.S_SRVEVENT_NEWSTCREPORT, report);
            }
        });

        return 0;
    }
}

