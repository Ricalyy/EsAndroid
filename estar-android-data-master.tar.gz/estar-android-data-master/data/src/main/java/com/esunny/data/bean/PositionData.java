package com.esunny.data.bean;

import java.math.BigInteger;

public class PositionData {
    private String                                              companyNo;          //经纪公司编号
    private String                                              positionNo;         //持仓号

    private String                                              userNo;             //资金账号
    private String                                              addressNo;          //地址号
    private String                                              contractNo;         //合约编号
    private char                                                direct;             //买卖
    private char                                                hedge;              //投保
    private double                                              positionPrice;      //持仓价
    private java.math.BigInteger                                positionQty;        //持仓量
    private java.math.BigInteger                                prePositionQty;     //昨持仓量

    private String                                              matchNo;            //成交关键字
    private String                                              matchDateTime;      //成交时间

    private double                                              profitCalcPrice;    //浮盈计算价
    private double                                              floatProfit;        //浮盈
    private double                                              floatProfitTBT;     //逐笔浮赢 trade by trade

    private double                                              depositCalcPrice;   //老仓保证金计算价（昨结算），新仓为成交价
    private double                                              deposit;            //客户初始保证金
    private double                                              keepDeposit;        //客户维持保证金
    private double                                              marketValue;        //期权市值 = 最新价 * 持仓量 * 乘数

    private java.math.BigInteger  						                            CanCoverQty;		//可平数量
    private java.math.BigInteger  						                            FrozenQty;          //锁定数量

    private long                                                streamId;           //流号

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getPositionNo() {
        return positionNo;
    }

    public void setPositionNo(String positionNo) {
        this.positionNo = positionNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getAddressNo() {
        return addressNo;
    }

    public void setAddressNo(String addressNo) {
        this.addressNo = addressNo;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public char getDirect() {
        return direct;
    }

    public void setDirect(char direct) {
        this.direct = direct;
    }

    public char getHedge() {
        return hedge;
    }

    public void setHedge(char hedge) {
        this.hedge = hedge;
    }

    public double getPositionPrice() {
        return positionPrice;
    }

    public void setPositionPrice(double positionPrice) {
        this.positionPrice = positionPrice;
    }

    public BigInteger getPositionQty() {
        return positionQty;
    }

    public void setPositionQty(BigInteger positionQty) {
        this.positionQty = positionQty;
    }

    public BigInteger getPrePositionQty() {
        return prePositionQty;
    }

    public void setPrePositionQty(BigInteger prePositionQty) {
        this.prePositionQty = prePositionQty;
    }

    public String getMatchNo() {
        return matchNo;
    }

    public void setMatchNo(String matchNo) {
        this.matchNo = matchNo;
    }

    public String getMatchDateTime() {
        return matchDateTime;
    }

    public void setMatchDateTime(String matchDateTime) {
        this.matchDateTime = matchDateTime;
    }

    public double getProfitCalcPrice() {
        return profitCalcPrice;
    }

    public void setProfitCalcPrice(double profitCalcPrice) {
        this.profitCalcPrice = profitCalcPrice;
    }

    public double getFloatProfit() {
        return floatProfit;
    }

    public void setFloatProfit(double floatProfit) {
        this.floatProfit = floatProfit;
    }

    public double getFloatProfitTBT() {
        return floatProfitTBT;
    }

    public void setFloatProfitTBT(double floatProfitTBT) {
        this.floatProfitTBT = floatProfitTBT;
    }

    public double getDepositCalcPrice() {
        return depositCalcPrice;
    }

    public void setDepositCalcPrice(double depositCalcPrice) {
        this.depositCalcPrice = depositCalcPrice;
    }

    public double getDeposit() {
        return deposit;
    }

    public void setDeposit(double deposit) {
        this.deposit = deposit;
    }

    public double getKeepDeposit() {
        return keepDeposit;
    }

    public void setKeepDeposit(double keepDeposit) {
        this.keepDeposit = keepDeposit;
    }

    public double getMarketValue() {
        return marketValue;
    }

    public void setMarketValue(double marketValue) {
        this.marketValue = marketValue;
    }

    public BigInteger getCanCoverQty() {
        return CanCoverQty;
    }

    public void setCanCoverQty(BigInteger canCoverQty) {
        CanCoverQty = canCoverQty;
    }

    public BigInteger getFrozenQty() {
        return FrozenQty;
    }

    public void setFrozenQty(BigInteger frozenQty) {
        FrozenQty = frozenQty;
    }

    public long getStreamId() {
        return streamId;
    }

    public void setStreamId(long streamId) {
        this.streamId = streamId;
    }
}
