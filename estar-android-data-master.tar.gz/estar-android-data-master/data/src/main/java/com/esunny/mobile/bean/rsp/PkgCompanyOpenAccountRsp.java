package com.esunny.mobile.bean.rsp;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/9/18
 */
public class PkgCompanyOpenAccountRsp extends ApiStruct {

    public final static short STRUCT_LENGTH = 53;

    private String OpenCode;
    private String CompanyName;
    private String OpenUrl;

    private PkgCompanyOpenAccountRsp(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);

        OpenCode = parseUtil.getString(11);
        CompanyName = parseUtil.getString(51);
        OpenUrl = parseUtil.getString(101);
    }

    public String getOpenCode() {
        return OpenCode;
    }

    public void setOpenCode(String openCode) {
        OpenCode = openCode;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public void setCompanyName(String companyName) {
        CompanyName = companyName;
    }

    public String getOpenUrl() {
        return OpenUrl;
    }

    public void setOpenUrl(String openUrl) {
        OpenUrl = openUrl;
    }

    public static PkgCompanyOpenAccountRsp toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new PkgCompanyOpenAccountRsp(data);
        } else {
            return null;
        }
    }
}
