package com.esunny.data.api.server;

import android.content.Context;

import com.alibaba.android.arouter.facade.template.IProvider;
import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.HisQuoteData;
import com.esunny.data.bean.HisQuoteTimeBucket;
import com.esunny.data.bean.Currency;
import com.esunny.data.bean.KLinePeriod;
import com.esunny.data.bean.OptionContractPair;
import com.esunny.data.bean.OptionSeries;
import com.esunny.data.bean.Plate;
import com.esunny.data.bean.QuoteField;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.bean.SQuoteSnapShot;

import java.util.List;
import java.util.Map;

public interface EsQuoteApi extends IProvider {
    void setQuoteClientKey(int key);

    void setQuoteAddress(AddrInfo address);

    void setHisQuoteAddress(AddrInfo addrInfo);

    void setHisQuoteClientKey(int key);

    CallbackDispatcher getDispatcher();

    Map<String, Commodity> getCommodityMap();

    Map<String, Contract> getContractMap();

    List<Commodity> getCommodityOfPlate(Plate plate);

    List<Commodity> getOptionCommodity();

    List<OptionSeries> getOptionSeriesOfCommodity(Commodity commodity);

    List<OptionContractPair> getOptionContractPair(OptionSeries series);

    Commodity getCommodityData(String companyNo, String userNo, String addrNo, String commodityNo);

    Commodity getCommodity(String commodityNo);

    boolean checkChargeCommodity(Contract contract);

    int qryContractSort(char type, String[] contractNoList);

    Contract getContract(String contractNo);

    List<Contract> getContractOfPlate(Plate plate);

    int subQuote(String contractNo);

    int unSubQuote(String contractNo);

    int subHisQuote(String contractNo);

    int unSubHisQuote(String contractNo);

    int subMinQuote(String contractNo, long day);

    SQuoteSnapShot getSnapShot(String contractNo);

    Contract getQuoteContract(String contractNo);

    Contract getTradeContract(String contractNo);

    Contract getRealContract(String contractNo);

    int getQuoteCodeUpdate();

    void mannualUpdate();

    void initCodeTable(Context mContext);


    List<HisQuoteTimeBucket> getBaseTimeBucketData(String commodityNo, long date);

    List<HisQuoteTimeBucket> getCalTimeBucketData(String commodityNo, long date);

    QuoteField[][] getQuoteField(Contract contract);

    List<HisQuoteData> getMinData(Contract contract);

    List<HisQuoteData> getKLineData(Contract contract, KLinePeriod period, int end, int size);

    String getContractName(String contractNo);

    AddrInfo getAddrInfo(char system, String companyNo, String userNo, String addrNo);

    int quoteLogin(String userNo, String password);

    int quoteLogout();

    QuoteLoginInfo quoteLoginInfo();

    boolean isQuoteLogin();

    int unSubAllQuote();

    boolean isCoverTContract(Commodity commodity);

    boolean hasExchangePermission(String exchangeNo);

    boolean hasContractPermission(Contract contract);

    boolean isMainContract(String contractNo);

    String getMainContractNo(String realContractNo);

    boolean hasTCPermission();

    String optionToTarget(String contractNo);

    boolean isPlusOneExchange(String exChangeNo);
}