package com.esunny.data.api.inter;

import java.nio.charset.Charset;

public abstract class ApiStruct {

    // 此字段需重写
    public final static int STRUCT_LENGTH = 0;

    public ApiStruct() {
    }

    public ApiStruct(byte[] buf) {
        byteToBean(buf);
    }

    public abstract byte[] beanToByte();
    protected abstract void byteToBean(byte[] buf);

    protected byte[] stringToByte(String content, int len) {
        byte[] result = new byte[len];
        if (content == null) {
            return result;
        }
        byte[] bytes = content.getBytes(Charset.defaultCharset());

        for (int i = 0; i < len; i++) {
            if (i < bytes.length) {
                result[i] = bytes[i];
            } else {
                result[i] = 0;
            }
        }
        return result;
    }

    protected byte charToByte(char c) {
        return (byte) (c & 0xFF);
    }

    protected short unsignedCharToShort(char c) {
        return (short) (c & 0xff);
    }

    protected int unsignedShortToInt(short s) {
        return s & 0xffff;
    }

    protected long unsignedIntToLong(int i) {
        return i & 0xffffffffL;
    }
}
