package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class VersionInfo {

    private String                             CurVersion;         //当前版本
    private String                          UpdateInfo;         //更新内容
    private String                             UpdateDate;         //更新时间

    private String                             BaseVersion;     //必须升级的最高版本

    public String getCurVersion() {
        return CurVersion;
    }

    public void setCurVersion(String curVersion) {
        CurVersion = curVersion;
    }

    public String getUpdateInfo() {
        return UpdateInfo;
    }

    public void setUpdateInfo(String updateInfo) {
        UpdateInfo = updateInfo;
    }

    public String getUpdateDate() {
        return UpdateDate;
    }

    public void setUpdateDate(String updateDate) {
        UpdateDate = updateDate;
    }

    public String getBaseVersion() {
        return BaseVersion;
    }

    public void setBaseVersion(String baseVersion) {
        BaseVersion = baseVersion;
    }
}
