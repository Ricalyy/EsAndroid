package com.esunny.data.api.server;

import com.alibaba.android.arouter.facade.template.IProvider;
import com.esunny.data.api.Interface.IGetAddress;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.BillConfirmReq;
import com.esunny.data.bean.CloudTradeCompany;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.MatchData;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.PositionData;
import com.esunny.data.bean.PushClientInfo;
import com.esunny.data.bean.TradeLogin;

import java.math.BigInteger;
import java.util.List;

public interface EsTradeApi extends IProvider {
    void setClientKey(String companyNo, String userNo, int key, CallbackDispatcher dispatcher);

    CallbackDispatcher getDispatcher();

    int tradeLogin(TradeLogin tradeLogin, String password, IGetAddress callback);

    List<CloudTradeCompany> getCloudTradeCompanyData(String companyNo, String addrNo);

    int tradeLogout(String companyNo, String userNo, String addrTypeNo);

    String[] getTradeDate(String companyNo, String userNo);

    Commodity getCommodityData(String companyNo, String userNo, String addrNo, String commodityNo);

    int openTradeOrder(InsertOrder order);

    AddrInfo getAddrInfo(char system, String companyNo, String userNo, String addrNo);

    List<PositionData> getSumPositionData(String companyNo, String userNo, String addrNo, String startNo, char direct, boolean isNow);

    List<OrderData> getPutOrderData(String companyNo, String userNo, String addrNo, char type, String beginOrderNo, int len, boolean isNow);

    List<MatchData> getMatchData(String companyNo, String userNo, String addrNo, String startNo, char direct, int len, boolean isNow);

    List<OrderData> getOrderData(String companyNo, String userNo, String addrNo, char strategyType, char orderState, String orderNo, int len, boolean isNow);

    int deleteTradeOrder(OrderData order);

    int suspendTradeOrder(OrderData order);

    int resumeTradeOrder(OrderData order);

    int modifyTradeOrder(OrderData data, double price, BigInteger qty, BigInteger maxQty);

    int queryBill(String companyNo, String userNo, String addrNo, String billDate);

    int billConfirm(BillConfirmReq billConfirmReq);

    int registPushInfo(PushClientInfo info);

    int qryMessage(String companyno, String userno, String addrno);

    List<MoneyData> getMoneyData(String companyNo, String userNo, String addrNo);

    boolean isDipperTradeStar(TradeLogin tradeLogin);

    boolean isVenusTradeStar(TradeLogin tradeLogin);

    int modifyTradePassword(String companyNo, String userNo, String addrNo, String oldPassword, String newPassword);
}
