package com.esunny.data.database.table;

import android.text.TextUtils;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 * @author Peter Fu
 * @date 2020/10/13
 */
@Entity(nameInDb = "TExchange")
public class TExchange {

        @Id()
        @Property(nameInDb = "FExchangeNo")
        private String ExchangeNo;
        @Property(nameInDb = "FCHSName")
        private String CHSName = "";            //简体中文名称
        @Property(nameInDb = "FCHTName")
        private String CHTName = "";            //繁体中文名称
        @Property(nameInDb = "FENUName")
        private String ENUName = "";            //英文名称
        @Property(nameInDb = "FUpdateId")
        private Long UpdateId = 0L;                // 更新的编号
        @Generated(hash = 1810645614)
        public TExchange(String ExchangeNo, String CHSName, String CHTName,
                String ENUName, Long UpdateId) {
            this.ExchangeNo = ExchangeNo;
            this.CHSName = CHSName;
            this.CHTName = CHTName;
            this.ENUName = ENUName;
            this.UpdateId = UpdateId;
        }
        @Generated(hash = 600781815)
        public TExchange() {
        }
        public String getExchangeNo() {
            return this.ExchangeNo;
        }
        public void setExchangeNo(String ExchangeNo) {
            this.ExchangeNo = ExchangeNo;
        }
        public String getCHSName() {
            return this.CHSName;
        }
        public void setCHSName(String CHSName) {
            this.CHSName = CHSName;
        }
        public String getCHTName() {
            return this.CHTName;
        }
        public void setCHTName(String CHTName) {
            this.CHTName = CHTName;
        }
        public String getENUName() {
            return this.ENUName;
        }
        public void setENUName(String ENUName) {
            this.ENUName = ENUName;
        }
        public Long getUpdateId() {
            return this.UpdateId;
        }
        public void setUpdateId(Long UpdateId) {
            this.UpdateId = UpdateId;
        }

    public String getExchangeName() {
        String name = CHSName;
        if (TextUtils.isEmpty(name)) {
            name = CHTName;
        }
        if (TextUtils.isEmpty(name)) {
            name = ENUName;
        }

        return name;
    }
}
