package com.esunny.data.api.event;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class MonitorEvent extends AbstractAPIEvent {

    public String getUserNo() {
        return ((MonitorEvent.Builder)Builder).userNo;
    }

    private MonitorEvent(AbstractAPIEventBuilder builder) {
        super(builder);
    }

    public static class Builder extends AbstractAPIEventBuilder<MonitorEvent> {
        String userNo;

        public Builder(int action) {
            setAction(action);
        }

        @Override
        public Builder setSender(int sender) {
            this.mSender = sender;
            return this;
        }

        @Override
        public Builder setAction(int action) {
            this.mAction = action;
            return this;
        }

        @Override
        public Builder setData(Object data) {
            this.mData = data;
            return this;
        }

        @Override
        public Builder setSrvChain(boolean srvChain) {
            this.srvChain = srvChain;
            return this;
        }

        @Override
        public Builder setSrvErrorCode(int srvErrorCode) {
            this.srvErrorCode = srvErrorCode;
            return this;
        }

        @Override
        public Builder setSrvErrorText(String srvErrorText) {
            this.srvErrorText = srvErrorText;
            return this;
        }

        public Builder setUserNo(String userNo) {
            this.userNo = userNo;
            return this;
        }

        @Override
        public MonitorEvent buildEvent() {
            return new MonitorEvent(this);
        }
    }
}

