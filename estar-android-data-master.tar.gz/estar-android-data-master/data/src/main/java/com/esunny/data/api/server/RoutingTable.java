package com.esunny.data.api.server;

public class RoutingTable {

    public final static String ES_CT_SYSTEM_INFO_API = "/estarCTApi/systemInfo";
    public final static String ES_CT_API = "/estarCTApi/api";

    public final static String ES_QUOTE_API = "/estarDataQuoteApi/api";
    public final static String ES_QUOTE_MSG_DISPATCH = "/estarDataQuoteApi/dispatch";

    public final static String ES_TRADE_API = "/estarDataTradeApi/api";

    public final static String ES_MONITOR_API = "/estarDataMonitorApi/api";
}
