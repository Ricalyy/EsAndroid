package com.esunny.data.util.simplethread;

import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;

public class NormalExecutor {
    private final static ExecutorParams NORMAL_EXECUTOR_PARAMS = new ExecutorParams();

    static {
        NORMAL_EXECUTOR_PARAMS.corePoolSize = ThreadPoolConstant.NORMAL_CORE_POOL_SIZE;
        NORMAL_EXECUTOR_PARAMS.maximumPoolSize = ThreadPoolConstant.NORMAL_MAXIMUM_POOL_SIZE;
        NORMAL_EXECUTOR_PARAMS.keepAliveTime = ThreadPoolConstant.NORMAL_KEEP_ALIVE_TIME;
        NORMAL_EXECUTOR_PARAMS.unit = ThreadPoolConstant.EXECUTOR_TIME_UNIT;
        NORMAL_EXECUTOR_PARAMS.workQueue = new SynchronousQueue<>();
        NORMAL_EXECUTOR_PARAMS.handler = new ThreadPoolExecutor.DiscardOldestPolicy();
    }

    static ThreadPoolExecutor getNormalExecutor(ExecutorParams params) {
        return new ThreadPoolExecutor(params.corePoolSize,
                params.maximumPoolSize,
                params.keepAliveTime,
                params.unit,
                params.workQueue);
    }

    static ThreadPoolExecutor getDefaultNormalExecutor() {
        return getNormalExecutor(NORMAL_EXECUTOR_PARAMS);
    }
}
