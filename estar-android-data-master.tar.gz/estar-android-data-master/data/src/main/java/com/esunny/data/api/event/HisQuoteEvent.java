package com.esunny.data.api.event;

public class HisQuoteEvent extends AbstractAPIEvent {
    private HisQuoteEvent(AbstractAPIEventBuilder builder) {
        super(builder);
    }

    public String getContractNo() {
        return ((HisQuoteEvent.Builder) Builder).contractNo;
    }

    public String getUserNo() {
        return ((HisQuoteEvent.Builder) Builder).userNo;
    }

    public char getKLineType() {
        return ((HisQuoteEvent.Builder) Builder).kLineType;
    }

    public String getSessionId(){
        return ((HisQuoteEvent.Builder) Builder).sessionId;
    }

    public static class Builder extends AbstractAPIEventBuilder<HisQuoteEvent> {

        String contractNo;
        String userNo;
        char kLineType;
        String sessionId;

        public Builder(int action) {
            setAction(action);
        }

        @Override
        public Builder setSender(int sender) {
            this.mSender = sender;
            return this;
        }

        @Override
        public Builder setAction(int action) {
            this.mAction = action;
            return this;
        }

        @Override
        public Builder setData(Object data) {
            this.mData = data;
            return this;
        }

        @Override
        public Builder setSrvChain(boolean srvChain) {
            this.srvChain = srvChain;
            return this;
        }

        @Override
        public Builder setSrvErrorCode(int srvErrorCode) {
            this.srvErrorCode = srvErrorCode;
            return this;
        }

        @Override
        public Builder setSrvErrorText(String srvErrorText) {
            this.srvErrorText = srvErrorText;
            return this;
        }

        public Builder setContractNo(String contractNo) {
            this.contractNo = contractNo;
            return this;
        }

        public Builder setUserNo(String userNo) {
            this.userNo = userNo;
            return this;
        }

        public Builder setKLineType(char kLineType) {
            this.kLineType = kLineType;
            return this;
        }

        public Builder setSessionId(String sessionId) {
            this.sessionId = sessionId;
            return this;
        }

        @Override
        public HisQuoteEvent buildEvent() {
            return new HisQuoteEvent(this);
        }
    }
}