package com.esunny.data.bean;

public class NotifyInfo {
    private long          MsgNotifyID;            // 通知id
    private char        MsgNotifyType;          // 通知类型
    private String            MsgNotifyStartDate;     // 通知的起始时间
    private String             MsgNotifyEndDate;       // 通知到结束时间
    private String        MsgNotifyData;          // 通知

    public NotifyInfo() {
    }

    public long getMsgNotifyID() {
        return MsgNotifyID;
    }

    public void setMsgNotifyID(long msgNotifyID) {
        MsgNotifyID = msgNotifyID;
    }

    public char getMsgNotifyType() {
        return MsgNotifyType;
    }

    public void setMsgNotifyType(char msgNotifyType) {
        MsgNotifyType = msgNotifyType;
    }

    public String getMsgNotifyStartDate() {
        return MsgNotifyStartDate;
    }

    public void setMsgNotifyStartDate(String msgNotifyStartDate) {
        MsgNotifyStartDate = msgNotifyStartDate;
    }

    public String getMsgNotifyEndDate() {
        return MsgNotifyEndDate;
    }

    public void setMsgNotifyEndDate(String msgNotifyEndDate) {
        MsgNotifyEndDate = msgNotifyEndDate;
    }

    public String getMsgNotifyData() {
        return MsgNotifyData;
    }

    public void setMsgNotifyData(String msgNotifyData) {
        MsgNotifyData = msgNotifyData;
    }
}
