package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class OpenCompanyInfo {
    private String                               OpenCode;
    private String                          OpenCompanyName;

    private boolean  isInner;

    public String getOpenCode() {
        return OpenCode;
    }

    public void setOpenCode(String openCode) {
        OpenCode = openCode;
    }

    public String getOpenCompanyName() {
        return OpenCompanyName;
    }

    public void setOpenCompanyName(String openCompanyName) {
        OpenCompanyName = openCompanyName;
    }

    public boolean isInner() {
        return isInner;
    }

    public void setInner(boolean inner) {
        isInner = inner;
    }
}

