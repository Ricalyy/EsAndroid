package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

import android.content.Context;
import android.text.TextUtils;

import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.EsDataApi;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Locale;

public class FundsBetData {

    private Contract Contract;
//    private SQuoteSnapShot Snap;

    private String ExchangeNo;
    private String CommodityNo;

    private double TotalTurnOver;
    private BigInteger TotalQty;
    private double LastPrice;
    private double PreClosingPrice;
    private BigInteger Position;
    private BigInteger PrePositionQty;

    public boolean setContractData(Contract contract) {
        if (contract == null) {
            return false;
        }
//
//        Contract = contract;
//
//        TotalTurnOver = 0;
//        LastPrice = 0;
//        PreClosingPrice = 0;
//        TotalQty = BigInteger.ZERO;
//        Position = BigInteger.ZERO;
//        PrePositionQty = BigInteger.ZERO;
//
//        Snap = StarApiAndroid.S_GetSnapShot(contract.getContractNo());
//        if (Snap == null) {
//            return false;
//        }
//
//        SQuoteField field = Snap.getData()[StarApi_FINAL.S_FID_TOTALTURNOVER];
//        if (field != null) {
//            TotalTurnOver = field.getPrice();
//        }
//
//        field = Snap.getData()[StarApi_FINAL.S_FID_PRECLOSINGPRICE];
//        if (field != null) {
//            PreClosingPrice = field.getPrice();
//        }
//
//        field = Snap.getData()[StarApi_FINAL.S_FID_LASTPRICE];
//        if (field != null) {
//            LastPrice = field.getPrice();
//        }
//
//        //持仓量
//        field = Snap.getData()[StarApi_FINAL.S_FID_POSITIONQTY];
//        if (field != null) {
//            Position = field.getQty();
//        }
//        //昨持仓量
//        field = Snap.getData()[StarApi_FINAL.S_FID_PREPOSITIONQTY];
//        if (field != null) {
//            PrePositionQty = field.getQty();
//        }
//
//        field = Snap.getData()[StarApi_FINAL.S_FID_TOTALQTY];
//        if (field != null) {
//            TotalQty = field.getQty();
//        }
//
//        field = Snap.getData()[StarApi_FINAL.S_FID_CODE];
//        if (field != null) {
//            CommodityNo = field.getStr();
//        }
//
//        field = Snap.getData()[StarApi_FINAL.S_FID_NAME];
//        if (field != null) {
//            ExchangeNo = field.getStr();
//        }

        return true;
    }

    public BigInteger getTotalQty() {
        return TotalQty;
    }

    public BigInteger getPosition() {
        return Position;
    }

    public BigInteger getPrePositionQty() {
        return PrePositionQty;
    }

    public String price2String(double price) {
//        if (TextUtils.isEmpty(CommodityNo) || TextUtils.isEmpty(ExchangeNo)) {
//            return null;
//        }
//        String commodityNo = CommodityNo;
//        int index = CommodityNo.indexOf("|");
//        if (index > 0) {
//            commodityNo = CommodityNo.substring(0, index);
//        }
//
//        commodityNo = ExchangeNo + "|F|" + commodityNo;
//        Commodity commodity = EsBaseApi.getCommodityByNo(commodityNo);
//        if (commodity != null) {
//            return EsDataApi.formatPrice(commodity, price, false);
//        }
//
//        return EsDataApi.formatPrice(Contract.getCommodity(), price, false);
        return "0.0";
    }

    public String getLastPriceString() {
        return price2String(LastPrice);
    }
//
    public String getPreSettlePriceString() {
        return price2String(PreClosingPrice);
    }

    public double getTotalTurnOver() {
        return TotalTurnOver;
    }

    public String getTotalTurnOverString() {
        Context context = EsBaseApi.getInstance().getContext();
        return dealLargeQty(context, BigDecimal.valueOf(TotalTurnOver), 2);
    }

    public double getLastPrice() {
        return LastPrice;
    }

    public double getPreClosingPrice() {
        return PreClosingPrice;
    }

//    public String getContractName() {
//        if (Contract != null) {
//            return Contract.getContractName();
//        }
//
//        return null;
//    }

//    public String getExchangeName() {
//        if (TextUtils.isEmpty(ExchangeNo)) {
//            return null;
//        }
//        Exchange exchange = EsBaseApi.getExchangeByNo(ExchangeNo);
//        if (exchange != null) {
//            return exchange.getExchangeName();
//        }
//
//        return null;
//    }

    public String getCommodityNo(char type) {
        if (TextUtils.isEmpty(CommodityNo) || TextUtils.isEmpty(ExchangeNo)) {
            return "";
        }
        String commodityNo = CommodityNo;
        int index = CommodityNo.indexOf("|");
        if (index > 0) {
            commodityNo = CommodityNo.substring(0, index);
        }

        return ExchangeNo + "|"+ type + "|" + commodityNo;
    }

    public String getCommodityName() {
        String commodityNo = getCommodityNo('F');
//        Commodity commodity = EsDataApi.getCommodityData(commodityNo);
//        if (commodity != null) {
//            return commodity.getCommodityName();
//        }

        return null;
    }

    public String getMainContractNo() {
        String contractNo = Contract.getContractNo();
        if (!contractNo.endsWith("1")) {
            int len = contractNo.length();
            return contractNo.substring(0, len - 1) + "1";
        } else {
            if (TextUtils.isEmpty(CommodityNo) || TextUtils.isEmpty(ExchangeNo)) {
                return null;
            }

            return ExchangeNo + "|F|" + CommodityNo;
        }
    }

    private String dealLargeQty(Context context, BigDecimal qtyDecimal, int scale){
        // "en" is English.
        Locale locale = context.getResources().getConfiguration().locale;
        String localeStr = locale.getLanguage();
        String strQty = "+";

        if (qtyDecimal.compareTo(BigDecimal.ZERO) < 0) {
            strQty = "-";
            qtyDecimal = qtyDecimal.abs();
        }

        BigDecimal one = new BigDecimal("1");
        if(localeStr.endsWith("zh")) {
            BigDecimal wan = new BigDecimal("10000");
            BigDecimal normal = new BigDecimal("100000");
            BigDecimal yi = new BigDecimal("100000000");
            if (qtyDecimal.compareTo(normal) <= 0) {
                strQty += qtyDecimal.divide(one, scale, BigDecimal.ROUND_HALF_UP).toString();
            } else if (qtyDecimal.compareTo(yi) < 0) {
                strQty += qtyDecimal.divide(wan, scale, BigDecimal.ROUND_HALF_UP).toString();
                if (locale.getCountry().equals("CN")) {
                    strQty += "万";
                }else {
                    strQty += "萬";
                }
            } else {
                strQty += qtyDecimal.divide(yi, scale, BigDecimal.ROUND_HALF_UP).toString();
                if (locale.getCountry().equals("CN")) {
                    strQty += "亿";
                }else {
                    strQty += "億";
                }
            }
        } else {
            BigDecimal normal = new BigDecimal("1000000.0");
            BigDecimal yi = new BigDecimal("100000000.0");
            BigDecimal billion = new BigDecimal("1000000000.0");
            if (qtyDecimal.compareTo(normal) <= 0) {
                strQty += qtyDecimal.divide(one, scale, BigDecimal.ROUND_HALF_UP).toString();
            } else if (qtyDecimal.compareTo(yi) < 0) {
                strQty += qtyDecimal.divide(normal, scale, BigDecimal.ROUND_HALF_UP).toString() + "M";
            } else {
                strQty += qtyDecimal.divide(billion, scale, BigDecimal.ROUND_HALF_UP).toString() + "B";
            }
        }
        return strQty;
    }
}
