package com.esunny.mobile.util;

import java.math.BigInteger;

public class ParseUtil {

    private byte[] mData;
    private int mPoint;

    public static ParseUtil wrap(byte[] data) {
        return new ParseUtil(data);
    }

    private ParseUtil(byte[] data) {
        mData = data;
        mPoint = 0;
    }

    public void clearWrap(byte[] data) {
        mData = data;
        mPoint = 0;
    }

    public boolean isEnd() {
        return mPoint >= mData.length;
    }

    public void moveStep(int len) {
        mPoint += len;
    }

    public char getChar(){
        if (mData != null && mPoint < mData.length) {
            char c = (char) mData[mPoint];
            mPoint++;
            return c;
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public short getUnsignedChar(){
        if (mData != null && mPoint < mData.length) {
            short s = (short) (mData[mPoint] & 0xff);
            mPoint++;
            return s;
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public byte getByte() {
        if (mData != null && mPoint < mData.length) {
            char c = (char) mData[mPoint];
            mPoint++;
            return (byte) c;
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public boolean getBool() {
        char c = getChar();
        return c == 1 || c == 'Y';
    }

    public short getShort() {
        if (mData != null && mPoint + 1 < mData.length) {
            short s = (short) (mData[mPoint + 1] << 8 | mData[mPoint] & 0xff);
            mPoint += 2;
            return s;
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public int getUnsignedShort() {
        if (mData != null && mPoint + 1 < mData.length) {
            int i = mData[mPoint] & 0xFF |
                    (mData[mPoint + 1] & 0xFF) << 8 |
                    (0) << 16 |
                    (0) << 24;
            mPoint += 2;
            return i;
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public String getString(int len) {
        if (mData != null && mPoint + len - 1 < mData.length) {

            int count = 0;
            for (int i = 0; i < len; i++) {
                byte b = mData[i + mPoint];
                if (b == 0) {
                    break;
                }
                count++;
            }

            if (count == 0) {
                mPoint += len;
                return "";
            }

            byte[] bytes = new byte[count];
            System.arraycopy(mData, mPoint, bytes, 0, count);
            mPoint += len;
            String str = new String(bytes).trim();
            return str.intern();
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public int getInt() {
        if (mData != null && mPoint + 3 < mData.length) {
            int i = (mData[mPoint + 3] & 0xFF) << 24|
                    (mData[mPoint + 2] & 0xFF) << 16 |
                    (mData[mPoint + 1] & 0xFF) << 8 |
                    (mData[mPoint] & 0xFF) ;
            mPoint += 4;
            return i;
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public long getUnsignedInt() {
        if (mData != null && mPoint + 3 < mData.length) {
            long i = (mData[mPoint + 3] & 0xFFL) << 24 |
                    (mData[mPoint + 2] & 0xFFL) << 16 |
                    (mData[mPoint + 1] & 0xFFL) << 8 |
                    (mData[mPoint] & 0xFFL) |
                    (0L) << 32 |
                    (0L) << 40 |
                    (0L) << 38 |
                    (0L) << 56 ;
            mPoint += 4;
            return i;
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public long getLong() {
        if (mData != null && mPoint + 7 < mData.length) {
            long num = (mData[mPoint + 7] & 0xFFL) << 56 |
                    (mData[mPoint + 6] & 0xFFL) << 48 |
                    (mData[mPoint + 5] & 0xFFL) << 40 |
                    (mData[mPoint + 4] & 0xFFL) << 32 |
                    (mData[mPoint + 3] & 0xFFL) << 24 |
                    (mData[mPoint + 2] & 0xFFL) << 16 |
                    (mData[mPoint + 1] & 0xFFL) << 8 |
                    (mData[mPoint] & 0xFFL);

            mPoint += 8;
            return num;
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public BigInteger getLongLong() {
        if (mData != null && mPoint + 7 < mData.length) {
            byte[] bytes = new byte[8];

            for (int i = 0; i < 8; i++) {
                bytes[i] = mData[mPoint + 7 - i];
            }

            mPoint += 8;
            return new BigInteger(bytes);
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public float getFloat() {
        if (mData != null && mPoint + 3 < mData.length) {
            int i = (mData[mPoint + 3] & 0xFF) << 24 |
                    (mData[mPoint + 2] & 0xFF) << 16 |
                    (mData[mPoint + 1] & 0xFF) << 8 |
                    (mData[mPoint] & 0xFF);

            mPoint += 4;
            return Float.intBitsToFloat(i);
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public double getDouble() {
        if (mData != null && mPoint + 7 < mData.length) {
            long m;
            m = mData[mPoint];
            m &= 0xff;
            m |= ((long) mData[mPoint + 1] << 8);
            m &= 0xffff;
            m |= ((long) mData[mPoint + 2] << 16);
            m &= 0xffffff;
            m |= ((long) mData[mPoint + 3] << 24);
            m &= 0xffffffffL;
            m |= ((long) mData[mPoint + 4] << 32);
            m &= 0xffffffffffL;
            m |= ((long) mData[mPoint + 5] << 40);
            m &= 0xffffffffffffL;
            m |= ((long) mData[mPoint + 6] << 48);
            m &= 0xffffffffffffffL;
            m |= ((long) mData[mPoint + 7] << 56);

            mPoint += 8;
            return Double.longBitsToDouble(m);
        }
        throw new IndexOutOfBoundsException("pos = " + mPoint);
    }

    public byte[] getBytes(int len) {
        byte[] bytes = new byte[len];
        System.arraycopy(mData, mPoint, bytes, 0, len);
        mPoint += len;
        return bytes;
    }

    public int getPoint() {
        return mPoint;
    }
}
