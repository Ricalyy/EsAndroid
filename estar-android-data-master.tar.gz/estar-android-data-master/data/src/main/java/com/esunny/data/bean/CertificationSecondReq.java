package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class CertificationSecondReq {
    private char passwordType;
    private String vertificateCode;
    private char loginType;

    public char getPasswordType() {
        return passwordType;
    }

    public void setPasswordType(char passwordType) {
        this.passwordType = passwordType;
    }

    public String getVertificateCode() {
        return vertificateCode;
    }

    public void setVertificateCode(String vertificateCode) {
        this.vertificateCode = vertificateCode;
    }

    public char getLoginType() {
        return loginType;
    }

    public void setLoginType(char loginType) {
        this.loginType = loginType;
    }
}
