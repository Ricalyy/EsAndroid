package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class MonitorOrderAction {
    private String                                            OrderNo;
    private String                                          ContractNo; //合约编号
    private char                                    OrderActionType; //定单操作类型

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getOrderActionType() {
        return OrderActionType;
    }

    public void setOrderActionType(char orderActionType) {
        OrderActionType = orderActionType;
    }
}
