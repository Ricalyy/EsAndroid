package com.esunny.mobile;

/**
 * typedef struct SServiceInfo
 */
public class SByteObject {

    // 对应Src
    private int Key;
    // 对应 action
    private char Event;
    private int Len;
    private byte[] Data;

    public int getKey() {
        return Key;
    }

    public void setKey(int key) {
        Key = key;
    }

    public char getEvent() {
        return Event;
    }

    public void setEvent(char event) {
        Event = event;
    }

    public int getLen() {
        return Len;
    }

    public void setLen(int len) {
        Len = len;
    }

    public byte[] getData() {
        return Data;
    }

    public void setData(byte[] data) {
        this.Data = data;
    }
}
