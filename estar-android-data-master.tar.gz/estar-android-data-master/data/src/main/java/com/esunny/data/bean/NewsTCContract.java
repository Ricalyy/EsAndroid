package com.esunny.data.bean;

public class NewsTCContract {
    private String NewsContractNo;
    private char NewsTimeRange;
    private double NewsResistance3;
    private double NewsResistance2;
    private double NewsResistance1;
    private double NewsLast;
    private double NewsPivot;
    private double NewsSupport1;
    private double NewsSupport2;
    private double NewsSupport3;
    private String NewsTcReport;
    private String NewsTcTime;

    public String getNewsContractNo() {
        return NewsContractNo;
    }

    public void setNewsContractNo(String newsContractNo) {
        NewsContractNo = newsContractNo;
    }

    public char getNewsTimeRange() {
        return NewsTimeRange;
    }

    public void setNewsTimeRange(char newsTimeRange) {
        NewsTimeRange = newsTimeRange;
    }

    public double getNewsResistance3() {
        return NewsResistance3;
    }

    public void setNewsResistance3(double newsResistance3) {
        NewsResistance3 = newsResistance3;
    }

    public double getNewsResistance2() {
        return NewsResistance2;
    }

    public void setNewsResistance2(double newsResistance2) {
        NewsResistance2 = newsResistance2;
    }

    public double getNewsResistance1() {
        return NewsResistance1;
    }

    public void setNewsResistance1(double newsResistance1) {
        NewsResistance1 = newsResistance1;
    }

    public double getNewsLast() {
        return NewsLast;
    }

    public void setNewsLast(double newsLast) {
        NewsLast = newsLast;
    }

    public double getNewsPivot() {
        return NewsPivot;
    }

    public void setNewsPivot(double newsPivot) {
        NewsPivot = newsPivot;
    }

    public double getNewsSupport1() {
        return NewsSupport1;
    }

    public void setNewsSupport1(double newsSupport1) {
        NewsSupport1 = newsSupport1;
    }

    public double getNewsSupport2() {
        return NewsSupport2;
    }

    public void setNewsSupport2(double newsSupport2) {
        NewsSupport2 = newsSupport2;
    }

    public double getNewsSupport3() {
        return NewsSupport3;
    }

    public void setNewsSupport3(double newsSupport3) {
        NewsSupport3 = newsSupport3;
    }

    public String getNewsTcReport() {
        return NewsTcReport;
    }

    public void setNewsTcReport(String newsTcReport) {
        NewsTcReport = newsTcReport;
    }

    public String getNewsTcTime() {
        return NewsTcTime;
    }

    public void setNewsTcTime(String newsTcTime) {
        NewsTcTime = newsTcTime;
    }

    @Override
    public String toString() {
        return "Contract No : " + getNewsContractNo() + ", NewsSupport 1 : " + getNewsSupport1() + ", NewsResistance1 : " + getNewsResistance1();
    }
}
