package com.esunny.mobile.bean.rsp;


import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

public class PkgCompanyAddrRsp extends ApiStruct {

    private String CompanyNo;
    private String CompanyName;
    private String TradeAddrNo;
    private String TradeAddrName;
    private String TradeApi;
    private char   AddrType;

    private PkgCompanyAddrRsp(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);
        CompanyNo = parseUtil.getString(11);
        CompanyName = parseUtil.getString(51);
        TradeAddrNo = parseUtil.getString(21);
        TradeAddrName = parseUtil.getString(51);
        TradeApi = parseUtil.getString(21);
        AddrType = parseUtil.getChar();
    }

    public static PkgCompanyAddrRsp toParse(byte[] data) {
        return new PkgCompanyAddrRsp(data);
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public String getTradeAddrNo() {
        return TradeAddrNo;
    }

    public String getTradeAddrName() {
        return TradeAddrName;
    }

    public String getTradeApi() {
        return TradeApi;
    }

    public char getAddrType() {
        return AddrType;
    }

    public String getKey() {
        return CompanyNo + "_" + TradeAddrNo;
    }
}
