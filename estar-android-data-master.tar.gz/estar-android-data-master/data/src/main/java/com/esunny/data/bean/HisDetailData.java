package com.esunny.data.bean;

import java.math.BigInteger;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class HisDetailData {
    private long                                    TradeDate;                      //交易日|tick无效，min可能和时间戳不同，day和时间戳相同
    private java.math.BigInteger                    DateTimeStamp;                  //时间戳|不同数据类型，精度不同

    private double                                  LastPrice;                     //最新价（收盘价）
    private long                                    LastQty;                       //明细现手      tick
    private int                                     PositionChg;                   //持仓量变化 tick
    private double                                  BuyPrice;                      //买价            tick
    private double                                  SellPrice;                     //卖价            tick
    private java.math.BigInteger                    BuyQty;                        //买量            tick
    private java.math.BigInteger                    SellQty;                       //卖量            tick

    private BigInteger Position;

    public long getTradeDate() {
        return TradeDate;
    }

    public void setTradeDate(long tradeDate) {
        TradeDate = tradeDate;
    }

    public BigInteger getDateTimeStamp() {
        return DateTimeStamp;
    }

    public void setDateTimeStamp(BigInteger dateTimeStamp) {
        DateTimeStamp = dateTimeStamp;
    }

    public void setLastPrice(double value) {
        LastPrice=value;
    }

    public double getLastPrice() {
        return LastPrice;
    }

    public long getLastQty() {
        return LastQty;
    }

    public void setLastQty(long lastQty) {
        LastQty = lastQty;
    }

    public int getPositionChg() {
        return PositionChg;
    }

    public void setPositionChg(int positionChg) {
        PositionChg = positionChg;
    }

    public double getBuyPrice() {
        return BuyPrice;
    }

    public void setBuyPrice(double buyPrice) {
        BuyPrice = buyPrice;
    }

    public double getSellPrice() {
        return SellPrice;
    }

    public void setSellPrice(double sellPrice) {
        SellPrice = sellPrice;
    }

    public BigInteger getBuyQty() {
        return BuyQty;
    }

    public void setBuyQty(BigInteger buyQty) {
        BuyQty = buyQty;
    }

    public BigInteger getSellQty() {
        return SellQty;
    }

    public void setSellQty(BigInteger sellQty) {
        SellQty = sellQty;
    }

    public BigInteger getPosition() {
        return Position;
    }

    public void setPosition(BigInteger position) {
        Position = position;
    }
}
