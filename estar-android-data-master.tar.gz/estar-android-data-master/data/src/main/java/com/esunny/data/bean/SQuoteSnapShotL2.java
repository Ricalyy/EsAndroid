package com.esunny.data.bean;

import android.util.SparseArray;

import com.esunny.data.bean.SQuoteFieldL2;
import com.esunny.mobile.EsNativeProtocol;

/**
 * @author Peter Fu
 * @date 2020/10/10
 */
public class SQuoteSnapShotL2 {

//    private SQuoteFieldL2[] Data = new SQuoteFieldL2[EsNativeProtocol.MAX_L2_DEPTH];
    private SparseArray<SQuoteFieldL2> Data = new SparseArray<>();

    public SparseArray<SQuoteFieldL2> getData() {
        if (Data == null) {
            return new SparseArray<>();
        }
        return Data;
    }

    public void setData(SparseArray<SQuoteFieldL2> data) {
        Data = data;
    }

    public int getDataLength() {
        return Data.size();
//        int count = 0;
//        for (SQuoteFieldL2 item : Data) {
//            if (item != null) {
//                count++;
//            }
//        }
//        return count;
    }
}
