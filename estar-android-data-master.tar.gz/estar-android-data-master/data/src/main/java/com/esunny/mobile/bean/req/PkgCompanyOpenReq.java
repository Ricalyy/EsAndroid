package com.esunny.mobile.bean.req;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class PkgCompanyOpenReq extends ApiStruct {

    //1+2+11+21+1+1
    public final static int STRUCT_LENGTH = 37;

    private char TerminalOSType;
    private short LangType;
    private String PackageNo;
    private String LicenseNo;
    private char      ProtocolVer;
    private char      OpenCompanyType;


    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(charToByte(TerminalOSType));
        buffer.putShort(LangType);
        buffer.put(stringToByte(PackageNo, 11));
        buffer.put(stringToByte(LicenseNo, 21));
        buffer.put(charToByte(ProtocolVer));
        buffer.put(charToByte(OpenCompanyType));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
    }

    public void setTerminalOSType(char terminalOSType) {
        TerminalOSType = terminalOSType;
    }

    public void setLangType(int langType) {
        LangType = (short) langType;
    }

    public void setPackageNo(String packageNo) {
        PackageNo = packageNo;
    }

    public void setLicenseNo(String licenseNo) {
        LicenseNo = licenseNo;
    }

    public void setProtocolVer(char protocolVer) {
        ProtocolVer = protocolVer;
    }

    public void setOpenCompanyType(char openCompanyType) {
        OpenCompanyType = openCompanyType;
    }
}
