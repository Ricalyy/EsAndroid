package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */
public class SigningBank {
    private String CompanyNo;          //经纪公司编号
    private String UserNo;             //期货资金账号
    private String AddressNo;          //地址号
    private String BankNo;             //银行标志
    private String BankAccount;        //银行卡号
    private String CurrencyNo;         //币种编号
    private String BankName;           //银行名称
    private byte                                              SwapState;          //转账换汇状态
    private char                                              TransState;         //转账状态

    public SigningBank(){

    }

    public void setCompanyNo(String value){
        CompanyNo=value;
    }

    public String getCompanyNo(){
        return CompanyNo;
    }

    public void setUserNo(String value){
        UserNo=value;
    }

    public String getUserNo(){
        return UserNo;
    }

    public void setAddressNo(String value){
        AddressNo=value;
    }

    public String getAddressNo(){
        return AddressNo;
    }

    public void setBankNo(String value){
        BankNo=value;
    }

    public String getBankNo(){
        return BankNo;
    }

    public void setBankAccount(String value){
        BankAccount=value;
    }

    public String getBankAccount(){
        return BankAccount;
    }

    public void setCurrencyNo(String value){
        CurrencyNo=value;
    }

    public String getCurrencyNo(){
        return CurrencyNo;
    }

    public void setBankName(String value){
        BankName=value;
    }

    public String getBankName(){
        return BankName;
    }

    public void setSwapState(byte value)
    {
        SwapState=value;
    }

    public byte getSwapState(){
        return SwapState;
    }

    public void setTransState(char value)
    {
        TransState=value;
    }

    public char getTransState(){
        return TransState;
    }
}
