package com.esunny.data.api;

import android.app.Application;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;

import com.alibaba.android.arouter.launcher.ARouter;
import com.esunny.data.api.Interface.IGetAddress;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.api.server.EsCtApi;
import com.esunny.data.api.server.EsMonitorApi;
import com.esunny.data.api.server.EsQuoteApi;
import com.esunny.data.api.server.EsSystemInfo;
import com.esunny.data.api.server.EsTradeApi;
import com.esunny.data.api.server.RoutingTable;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.BillConfirmReq;
import com.esunny.data.bean.CloudTradeCompany;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.HisQuoteData;
import com.esunny.data.bean.HisQuoteTimeBucket;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.KLinePeriod;
import com.esunny.data.bean.MatchData;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.data.bean.MonitorOrderAction;
import com.esunny.data.bean.OptionContractPair;
import com.esunny.data.bean.OptionSeries;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.Plate;
import com.esunny.data.bean.PositionData;
import com.esunny.data.bean.PushClientInfo;
import com.esunny.data.bean.QuoteField;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.bean.SQuoteSnapShot;
import com.esunny.data.bean.SQuoteUserInfo;
import com.esunny.data.bean.TradeLogin;
import com.esunny.data.bean.UssUserBehaviorInfo;
import com.esunny.data.error.EsErrorCode;
import com.esunny.data.util.AndroidSysInfoUtils;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsNetHelper;
import com.esunny.data.util.SocketHelper;
import com.esunny.data.bean.Address;
import com.esunny.mobile.EsApiData;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.UnixJNI;
import com.esunny.mobile.bean.CspSessionHead;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;

public class EsBaseApi {
    private static final String TAG = "EsBaseApi";

    private static final int MSG_ACCESS_START_UP_TIME_OUT = 0;
    private static final int MSG_QUOTE_START_UP_TIME_OUT = 1;
    private static final int MSG_HIS_QUOTE_START_UP_TIME_OUT = 2;

    private static final int DELAY_TIME_OUT = 15000;

    private static final SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private volatile boolean IsInit = false, mIsStartUp = false;

    private Context mContext;
    private Application mApp;
    private String mPackageNo;
    private EsStarApi mStarApi;
    private volatile long mSessionId;
    private Handler mHandle;

    private EsQuoteApi mQuoteApi;
    private EsTradeApi mTradeApi;
    private EsCtApi mCtApi;
    private EsMonitorApi mMonitorApi;

    private EsBaseApi() {
        mHandle = new Handler(Looper.getMainLooper(), new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message msg) {
                switch (msg.what) {
                    case MSG_ACCESS_START_UP_TIME_OUT:
                        mHandle.removeMessages(MSG_ACCESS_START_UP_TIME_OUT);
                        break;
                    case MSG_QUOTE_START_UP_TIME_OUT:
                        mHandle.removeMessages(msg.what);
                        break;
                    case MSG_HIS_QUOTE_START_UP_TIME_OUT:
                    default:
                        break;
                }
                return false;
            }
        });
    }

    public int actionMonitorOrder(MonitorOrderAction order) {
        return mMonitorApi.actionMonitorOrder(order);
    }

    public List<Commodity> getOptionCommodity() {
        return mQuoteApi.getOptionCommodity();
    }

    public List<OptionContractPair> getOptionContractPair(OptionSeries series) {
        return mQuoteApi.getOptionContractPair(series);
    }

    public int getQuoteCodeUpdate() {
        return mQuoteApi.getQuoteCodeUpdate();
    }

    public void mannualUpdate() {
        mQuoteApi.mannualUpdate();
    }

    public int tradeLogin(final TradeLogin tradeLogin, String password) {
        return mTradeApi.tradeLogin(tradeLogin, password, new IGetAddress() {
            @Override
            public void getAddress(Address[] addresses) {
                final CallbackDispatcher callbackDispatcher = mTradeApi.getDispatcher();
                SocketHelper helper = new SocketHelper();
                helper.selectAddress(addresses, new SocketHelper.SocketCallback(){
                    @Override
                    public void onSelectAddr(String ip, int port) {
                        int ret = mStarApi.connect(ip, port, callbackDispatcher);
                        if (ret > 0) {
                            mTradeApi.setClientKey(tradeLogin.getCompanyNo(), tradeLogin.getUserNo(), ret, callbackDispatcher);
                        } else {
                            Log.d(TAG, " tradeLogin connect  ret : " + ret);
                        }
                        tradeLog(tradeLogin, mStarApi.getAccessKey(), ip, port);
                    }

                    @Override
                    public void onSelectFail(int error) {
                        mHandle.sendEmptyMessageDelayed(MSG_QUOTE_START_UP_TIME_OUT, DELAY_TIME_OUT);
                    }
                });

                mHandle.sendEmptyMessageDelayed(MSG_QUOTE_START_UP_TIME_OUT, DELAY_TIME_OUT);
            }
        });
    }

    private void tradeLog(TradeLogin tradeLogin, int accessKey, String ip, int port) {
        UssUserBehaviorInfo req = new UssUserBehaviorInfo();
        req.setLocalTime(sf.format(new Date()));
        req.setPackageNo(UnixJNI.S_GetPackageNo());
        req.setProductInfo("Yi Star");
        req.setProductVersion(getVersion(mApp));
        req.setMACAddr(EsNetHelper.getMac(mContext));
        req.setOsInfo(AndroidSysInfoUtils.getOsName() + "." + AndroidSysInfoUtils.getOsVersion());
        req.setHostName(AndroidSysInfoUtils.getHost());
        req.setUserNo(tradeLogin.getUserNo());
        req.setLoginApi("AndroidTrade");
        req.setCompanyName(tradeLogin.getCompanyName());
        req.setCompanyNo(tradeLogin.getCompanyNo());
        req.setAddrName(tradeLogin.getAddrTypeName());
        req.setAddrNo(tradeLogin.getAddrTypeNo());
        req.setServerIP(ip);
        req.setServerPort((short) port);

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.CMD_USS_USERBEHAVIOR_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_USERSTATS, UssUserBehaviorInfo.STRUCT_LENGTH);
        EsBaseApi.getInstance().sendMsg(accessKey, EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());
    }

    public String getVersion(Context application) {
        try {
            PackageManager manager = application.getPackageManager();
            PackageInfo info = manager.getPackageInfo(application.getPackageName(), 0);
            return info.versionName;
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public List<CloudTradeCompany> getCloudTradeCompanyData(String companyNo, String addrNo) {
        return mTradeApi.getCloudTradeCompanyData(companyNo, addrNo);
    }

    public int getSystemInfo(String api, EsSystemInfo.SystemInfoCallback callback) {
        return mCtApi.getSystemInfo(api, callback);
    }

    public int tradeLogout(String addrTypeNo, String companyNo, String userNo) {
        return mTradeApi.tradeLogout(companyNo, userNo, addrTypeNo);
    }

    public String[] getTradeDate(String companyNo, String userNo) {
        return mTradeApi.getTradeDate(companyNo, userNo);
    }

    public Commodity getCommodityData(String companyNo, String userNo, String addrNo, String commodityNo) {
        return mTradeApi.getCommodityData(companyNo, userNo, addrNo, commodityNo);
    }

    public Commodity getCommodity(String companyNo) {
        return mQuoteApi.getCommodity(companyNo);
    }

    public String getDoubleStrFromFractionStr(String price, int deno) {
        //判断分数报价，去掉特殊价和小数报价
        if (deno > 1 && price != null && price.length() > 0 && Character.isDigit(price.charAt(0)) && !price.contains(".")) {
            String num = price;
            if (price.contains("/")) {
                num = price.split("/")[0];
            }

            String integerStr;
            String numeratorStr;
            if (num.contains("+")) {
                integerStr = num.split("\\+")[0];
                numeratorStr = num.split("\\+")[1];
            } else {
                integerStr = "0";
                numeratorStr = num;
            }

            return String.valueOf(Double.parseDouble(integerStr) +
                    Double.valueOf(numeratorStr) / deno);
        }

        return price;
    }

    public boolean isForeignContract(Commodity commodity) {
        return commodity.getCoverMode() == EsDataConstant.S_COVER_NONE|| commodity.getCoverMode() == EsDataConstant.S_COVER_UNFINISH;
    }

    public String getContractName(String contractNo) {
        return mQuoteApi.getContractName(contractNo);
    }

    public double formatOrderPrice(Contract contract, String priceStr, char direct) {
        if (contract == null || priceStr == null) {
            return 0;
        }

        Commodity commodity = contract.getCommodity();

        double tick = commodity.getPriceTick();
        int deno = commodity.getPriceDeno();

        double price;
        boolean hasDeno = false;

        //分数报价合约处理
        //分数报价合约显示的几种情况
        //14+20/32,20/32,14+0/32,14+20,14+0,20
        if (deno > 1 && priceStr.length() > 0 && Character.isDigit(priceStr.charAt(0)) && !priceStr.contains(".")) {
            String num = priceStr;
            if (priceStr.contains("/")) {
                num = priceStr.split("/")[0];
                hasDeno = true;
            }

            String integerStr;
            String numeratorStr;

            if (num.contains("+")) {
                integerStr = num.split("\\+")[0];
                numeratorStr = num.split("\\+")[1];
            } else {
                integerStr = "0";
                numeratorStr = num;
            }

            try {
                price = Double.parseDouble(integerStr) + Double.parseDouble(numeratorStr) / deno;
            } catch (NumberFormatException | NullPointerException e) {
                price = 0;
            }
        } else {
            try {
                price = Double.parseDouble(priceStr);
            } catch (NumberFormatException | NullPointerException e) {
                price = 0;
            }
        }

        //将价格变为邻近的最小变动价，向上取整-
        int quotient = (int)(price/tick);

        double minPrice, maxPrice;

        if (price > 0) {
            minPrice = tick * quotient;
            maxPrice = tick * (quotient + 1);
        } else if (price < 0) {
            minPrice = tick * (quotient - 1);
            maxPrice = tick * quotient;
        } else {
            return 0;
        }

        //通过转换后的字符串比较大小
        String mixPriceStr = EsDataApi.formatPrice(commodity, minPrice, hasDeno);
        String maxPriceStr = EsDataApi.formatPrice(commodity, maxPrice, hasDeno);
//        String priceTemp = EsDataApi.formatPrice(commodity, price);

        if (!priceStr.contains("+") && !priceStr.contains("/") && !mixPriceStr.contains("+") && !mixPriceStr.contains("/")) {
            // double类型的价格不能通过字符串equals
            if (Double.parseDouble(priceStr) == Double.parseDouble(mixPriceStr)) {
                return minPrice;
            } else if (Double.parseDouble(priceStr) == Double.parseDouble(maxPriceStr)) {
                return maxPrice;
            }
        } else if (priceStr.equals(mixPriceStr) || String.valueOf(minPrice).equals(priceStr)) {
            return minPrice;
        } else if (priceStr.equals(maxPriceStr) || String.valueOf(maxPrice).equals(priceStr)) {
            return maxPrice;
        }
        if (direct == EsDataConstant.S_DIRECT_BUY) {
            return minPrice;
        } else {
            return maxPrice;
        }
    }

    public int openTradeOrder(InsertOrder order) {
        return mTradeApi.openTradeOrder(order);
    }

    public AddrInfo getAddrInfo(char system, String companyNo, String userNo, String addrNo) {
        if (system == EsNativeProtocol.S_SRVSRC_QUOTE || system == EsNativeProtocol.S_SRVSRC_HISQUOTE) {
            return mQuoteApi.getAddrInfo(system, companyNo, userNo, addrNo);
        } else if (system == EsNativeProtocol.S_SRVSRC_TRADE) {
            return mTradeApi.getAddrInfo(system, companyNo, userNo, addrNo);
        }

        return null;
    }

    public String getErrorMessage(String api, int code, String text) {
        return EsErrorCode.getErrorMessage(api, code, text);
    }

    public List<PositionData> getSumPositionData(String companyNo, String userNo, String addrNo, String startNo, char direct, boolean isNow) {
        return mTradeApi.getSumPositionData(companyNo, userNo, addrNo, startNo, direct, isNow);
    }

    public List<OrderData> getPutOrderData(String companyNo, String userNo, String addrNo, char type, String beginOrderNo, int len, boolean isNow) {
        return mTradeApi.getPutOrderData(companyNo, userNo, addrNo, type, beginOrderNo, len, isNow);
    }

    public List<MatchData> getMatchData(String companyNo, String userNo, String addrNo, String startNo, char direct, int len, boolean isNow) {
        return mTradeApi.getMatchData(companyNo, userNo, addrNo, startNo, direct, len, isNow);
    }

    public List<OrderData> getOrderData(String companyNo, String userNo, String addrNo, char strategyType, char orderState, String orderNo, int len, boolean isNow) {
        return mTradeApi.getOrderData(companyNo, userNo, addrNo, strategyType, orderState, orderNo, len, isNow);
    }

    public int quoteLogin(String userNo, String password) {
        return mQuoteApi.quoteLogin(userNo, password);
    }

    public int quoteLogout() {
        return mQuoteApi.quoteLogout();
    }

    public QuoteLoginInfo quoteLoginInfo() {
        return mQuoteApi.quoteLoginInfo();
    }

    public boolean isQuoteLogin() {
        return mQuoteApi.isQuoteLogin();
    }

    public int unSubAllQuote() {
        return mQuoteApi.unSubAllQuote();
    }

    public int deleteTradeOrder(OrderData order) {
        return mTradeApi.deleteTradeOrder(order);
    }

    public int suspendTradeOrder(OrderData order) {
        return mTradeApi.suspendTradeOrder(order);
    }

    public int resumeTradeOrder(OrderData order) {
        return mTradeApi.resumeTradeOrder(order);
    }

    public int modifyTradeOrder(OrderData data, double price, BigInteger qty, BigInteger maxQty) {
        return mTradeApi.modifyTradeOrder(data, price, qty, maxQty);
    }

    public int queryBill(String companyNo, String userNo, String addrNo, String billDate) {
        return mTradeApi.queryBill(companyNo, userNo, addrNo, billDate);
    }

    public int billConfirm(BillConfirmReq billConfirmReq) {
        return mTradeApi.billConfirm(billConfirmReq);
    }

    public boolean isCoverTContract(Commodity commodity) {
        return mQuoteApi.isCoverTContract(commodity);
    }

    public int registPushInfo(PushClientInfo info) {
        return mTradeApi.registPushInfo(info);
    }

    public int qryMessage(String companyno, String userno, String addrno) {
        return mTradeApi.qryMessage(companyno, userno, addrno);
    }

    public List<MoneyData> getMoneyData(String companyNo, String userNo, String addrNo) {
        return mTradeApi.getMoneyData(companyNo, userNo, addrNo);
    }

    public boolean hasExchangePermission(String exchangeNo) {
        return mQuoteApi.hasExchangePermission(exchangeNo);
    }

    public boolean hasContractPermission(Contract contract) {
        return mQuoteApi.hasContractPermission(contract);
    }

    public boolean isMainContract(String contractNo) {
        return mQuoteApi.isMainContract(contractNo);
    }

    public String getMainContractNo(String realContractNo) {
        return mQuoteApi.getMainContractNo(realContractNo);
    }

    public int queryNewsByTag(String tag, int startId, boolean isLatest, int count) {
        return 0;
    }

    public int queryF10ByCommodity(String commodityNo) {
        //判断系统语言
        int languageType = getLanguageType();
        if (languageType == EsDataConstant.S_ANDROID_CHS)
            languageType = EsDataConstant.S_ANDROID_CHS;
        else if (languageType == EsDataConstant.S_ANDROID_CHT)
            languageType = EsDataConstant.S_ANDROID_CHT;
        else if (languageType ==EsDataConstant. S_ANDROID_ENU)
            languageType = EsDataConstant.S_ANDROID_ENU;

        //主连合约添加F10
        if (commodityNo.contains("|Z|")) {
            commodityNo = commodityNo.replace("|Z|", "|F|");
        }
        //期权合约添加F10
//        if (commodityNo.contains("|O|")) {
//            commodityNo = commodityNo.replace("|O|", "|F|");
//        }
//        return StarApiAndroid.S_QryFTenInfo(languageType, commodityNo, new JNILongPoint(0));
        return EsWebApi.qryFTenInfo(languageType, commodityNo);
    }

    public boolean hasTCPermission() {
        return mQuoteApi.hasTCPermission();
    }

    public String optionToTarget(String contractNo) {
        return mQuoteApi.optionToTarget(contractNo);
    }

    public boolean isDipperTradeStar(TradeLogin tradeLogin) {
        return mTradeApi.isDipperTradeStar(tradeLogin);
    }

    public boolean isVenusTradeStar(TradeLogin tradeLogin) {
        return mTradeApi.isVenusTradeStar(tradeLogin);
    }

    public boolean isPlusOneExchange(String exChangeNo) {
        return mQuoteApi.isPlusOneExchange(exChangeNo);
    }

    public int modifyTradePassword(String companyNo, String userNo, String addrNo, String oldPassword, String newPassword) {
        return mTradeApi.modifyTradePassword(companyNo, userNo, addrNo, oldPassword, newPassword);
    }

    public int priceLogin() {
        if (mMonitorApi.getClientKey() != 0) {
            return 1;
        }

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        if (TextUtils.isEmpty(userInfo.getLoginNo())) {
            return -1;
        }

        String ip = "58.246.206.146";
//    String ip = "172.81.252.132";
//    String ip = "129.211.83.40";
        int port = 23555;

        CallbackDispatcher callbackDispatcher = mMonitorApi.getDispatcher();
        int ret = mStarApi.connect(ip, port, callbackDispatcher);
        if (ret > 0) {
            mMonitorApi.setClientKey(ret);
        } else {
            Log.d(TAG, " priceLogin connect  ret : " + ret);
        }

        return 0;
    }

    public List<MonitorOrder> getMonitorOrder() {
        return mMonitorApi.getMonitorOrder();
    }

    private static class SingletonClassInstance {
        private static final EsBaseApi INSTANCE = new EsBaseApi();
    }

    public static EsBaseApi getInstance() {
        return EsBaseApi.SingletonClassInstance.INSTANCE;
    }

    public int init(Application app, String packageNoStr) {
        if (IsInit) {
            Log.w(TAG, "You have been inited !");
            return -1;
        }

        if (app == null || TextUtils.isEmpty(packageNoStr)) {
            return -2;
        }

        this.mApp = app;
        mContext = app.getApplicationContext();
        mStarApi = new EsStarApi();
        mQuoteApi = (EsQuoteApi) ARouter.getInstance().build(RoutingTable.ES_QUOTE_API).navigation();
        mTradeApi = (EsTradeApi) ARouter.getInstance().build(RoutingTable.ES_TRADE_API).navigation();
        mCtApi = (EsCtApi) ARouter.getInstance().build(RoutingTable.ES_CT_API).navigation();
        mMonitorApi = (EsMonitorApi) ARouter.getInstance().build(RoutingTable.ES_MONITOR_API).navigation();

        int ret = mStarApi.init(packageNoStr);
        if (ret < 0) {
            return -3;
        }
        mPackageNo = mStarApi.getPackageNo();
        if (TextUtils.isEmpty(mPackageNo)) {
            return -4;
        }

        IsInit = true;
        return 0;
    }

    public void startUp() {
        if (!IsInit) {
            throw new RuntimeException("You must call init() before you start up !");
        }
        if (mIsStartUp) {
            Log.w(TAG, "You have been started up !");
            return;
        }

        Address[] addresses = EsApiData.getInstance().getAccessAddresses();
        connectTcp(addresses, null);
        mIsStartUp = true;
    }

    public int startUpQuote() {
        if (mQuoteApi == null) {
            return -10;
        }

        mQuoteApi.initCodeTable(mContext);
        Address[] addresses = EsApiData.getInstance().getQuoteAddress();
        final CallbackDispatcher dispatcher = mQuoteApi.getDispatcher();
        SocketHelper helper = new SocketHelper();
        helper.selectAddress(addresses, new SocketHelper.SocketCallback(){
            @Override
            public void onSelectAddr(String ip, int port) {
                int ret = mStarApi.connect(ip, port, dispatcher);
                if (ret > 0) {
                    mQuoteApi.setQuoteClientKey(ret);
                    mQuoteApi.setQuoteAddress(new AddrInfo(ip, port));
                }
            }

            @Override
            public void onSelectFail(int error) {
                mHandle.sendEmptyMessageDelayed(MSG_QUOTE_START_UP_TIME_OUT, DELAY_TIME_OUT);
            }
        });

        mHandle.sendEmptyMessageDelayed(MSG_QUOTE_START_UP_TIME_OUT, DELAY_TIME_OUT);
        return 0;
    }

    public int startUpHisQuote() {
        if (mQuoteApi == null) {
            return -10;
        }

        Address[] addresses = EsApiData.getInstance().getHisQuoteAddress();
        final CallbackDispatcher dispatcher = mQuoteApi.getDispatcher();

        SocketHelper helper = new SocketHelper();
        helper.selectAddress(addresses, new SocketHelper.SocketCallback(){
            @Override
            public void onSelectAddr(String ip, int port) {
                int ret = mStarApi.connect(ip, port, dispatcher);
                if (ret > 0) {
                    mQuoteApi.setHisQuoteClientKey(ret);
                    mQuoteApi.setHisQuoteAddress(new AddrInfo(ip, port));
                }
            }

            @Override
            public void onSelectFail(int error) {
                mHandle.sendEmptyMessage(MSG_HIS_QUOTE_START_UP_TIME_OUT);
            }
        });

        mHandle.sendEmptyMessageDelayed(MSG_HIS_QUOTE_START_UP_TIME_OUT, DELAY_TIME_OUT);
        return 0;
    }

    public boolean isInit() {
        return IsInit;
    }

    public String getPackageNo() {
        return mPackageNo;
    }

    public Context getContext() {
        return mContext;
    }

    public EsQuoteApi getQuoteApi() {
        return mQuoteApi;
    }

    public EsTradeApi getTradeApi() {
        return mTradeApi;
    }

    public int getLanguageType(){
        Locale locale;
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.N){
            locale = mApp.getResources().getConfiguration().getLocales().get(0);
        }else{
            locale = mApp.getResources().getConfiguration().locale;
        }
        String languageName = locale.getLanguage() + "-" + locale.getCountry();
        int languageType;
        if (languageName.contains(EsDataConstant.EN_STR)) {
            languageType = EsDataConstant.S_ANDROID_ENU;
        } else if(languageName.equals(EsDataConstant.CN_HK_STR) || languageName.equals(EsDataConstant.CN_TW_STR)) {
            languageType = EsDataConstant.S_ANDROID_CHT;
        } else {
            languageType = EsDataConstant.S_ANDROID_CHS;
        }
        return languageType;
    }

    public int getSystemWidth() {
        DisplayMetrics displayMetrics = mContext.getResources().getDisplayMetrics();
        return displayMetrics.widthPixels;
    }

    public int getSystemHeight() {
        DisplayMetrics displayMetrics = mContext.getResources().getDisplayMetrics();
        return displayMetrics.heightPixels;
    }

    public long getmSessionId() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HHmmss", Locale.getDefault());
        Date date = new Date(System.currentTimeMillis());
        long sessionId = Integer.parseInt(simpleDateFormat.format(date)) * 100;
        synchronized (this) {
            if (sessionId < mSessionId) {
                mSessionId++;
            } else {
                mSessionId = sessionId;
            }
        }
        return mSessionId;
    }

    public int sendMsg(int key, char type, CspSessionHead head, byte[] data) {
        if (mStarApi != null) {
            return mStarApi.sendMsg(key, type, head, data);
        }
        return -100;
    }



    private int connectTcp(Address[] addresses, final CallbackDispatcher dispatcher) {
        if (addresses == null || addresses.length == 0) {
            return -1;
        }

        SocketHelper helper = new SocketHelper();
        helper.selectAddress(addresses, new SocketHelper.SocketCallback(){
            @Override
            public void onSelectAddr(String ip, int port) {
                int ret = mStarApi.connect(ip, port, dispatcher);
//                if (addr != null && mV1Address == null) {
//                    mHandle.removeMessages(MSG_V1_START_UP_TIME_OUT);
//                    mStartUpStatus++;
//                    EsLog.d(TAG, "starUpV1Access onSelectAddr: addr = " + addr.toString() + ", status = " + mStartUpStatus);


//                    mV1Address = addr;
//                    int flag = checkCodeTableUpdateInfo();
//                    StarApiAndroid.S_Startup(mLanguageType, flag, addr.getIp(), addr.getPort());
//
//                    selectQuoteAddress();
//                    selectHisQuoteAddress();
//                }
            }

            @Override
            public void onSelectFail(int error) {
//                for (Address address : addresses) {
//                    if (address != null) {
//                        mAddressHelper.updateAddress(address.getIp(), address.getPort(),
//                                AddressDatabaseHelper.ADDRESS_TYPE_ACCESS_V1, address.getRemark(), false);
//                    }
//                }
//                if (error == 1) {
//                    mHandle.removeCallbacksAndMessages(null);
//                    mHandle.sendEmptyMessage(MSG_V1_START_UP_TIME_OUT);
//                }
//                EsLog.d(TAG, "starUpV1Access onSelectAddr: error = " + error + ", status = " + mStartUpStatus);
            }
        });

//        mHandle.sendEmptyMessageDelayed(MSG_V1_START_UP_TIME_OUT, DELAY_TIME_OUT);
        return 0;
    }

    List<Plate> getPlates(){
        return EsApiData.getInstance().getPlates();
    }

    List<Commodity> getCommodityOfPlate(Plate plate) {
        return mQuoteApi.getCommodityOfPlate(plate);
    }

    public List<OptionSeries> getOptionSeriesOfCommodity(Commodity commodity) {
        return mQuoteApi.getOptionSeriesOfCommodity(commodity);
    }

    public List<Plate> getChildPlate(Plate plate) {
        if (plate == null || !plate.isFirstPlate()) {
            return null;
        }

        String plateNo = plate.getPlateNo();
        List<Plate> plateArrayList = new ArrayList<>();

        List<Plate> plates = getPlates();
        for (Plate plateChild : plates) {
            if (plateChild != null && plateNo.equals(plateChild.getParentPlateNo())) {
                plateArrayList.add(plateChild);
            }
        }
        return plateArrayList;
    }

    public List<Contract> getContractOfPlate(Plate plate) {
        return mQuoteApi.getContractOfPlate(plate);
    }

    public String getContractCode(String contractNo) {
        if (contractNo == null) {
            return "";
        }
        String[] strArray = contractNo.split("\\|");
        if (strArray[1].charAt(0) == 'T') {
            return "";
        }

        if (strArray.length <= 3) {
            return strArray[strArray.length - 1];
        }

        if (strArray[3].charAt(0) < '0' || strArray[3].charAt(0) > '9') {
            return strArray[2] + "_" + strArray[3];
        } else {
            return strArray[2] + strArray[3];
        }
    }

    public int subQuote(String contractNo) {
        return mQuoteApi.subQuote(contractNo);
    }

    public int unSubQuote(String contractNo) {
        return mQuoteApi.unSubQuote(contractNo);
    }

    public int subHisQuote(String contractNo){
        return mQuoteApi.subHisQuote(contractNo);
    }

    public int unSubHisQuote(String contractNo){
        return mQuoteApi.subHisQuote(contractNo);
    }

    public int subMinQuote(String contractNo, long day){
        return mQuoteApi.subMinQuote(contractNo,day);
    }

    public SQuoteSnapShot getSnapShot(String contractNo) {
        return mQuoteApi.getSnapShot(contractNo);
    }

    public String formatPrice(Commodity commodity, double price, boolean showDeno) {
        if (commodity == null) {
            return "————";
        }

        byte show = showDeno ? EsDataConstant.S_NEXT_YES : EsDataConstant.S_NEXT_NO;

        String text = String.valueOf(price);
//        String text =  UnixJNI.S_FormatPrice(price, commodity.getPricePrec(), commodity.getPriceDeno(), show);
//
//        if (text == null) {
//            return "————";
//        }

        return text;
    }

    public String formatTime(String time, int type) {
        if (time.length() < 17) {
            try {
                time = String.format(Locale.getDefault(), "%0" + 17 + "d", Long.parseLong(time));
            } catch (NumberFormatException e) {
                EsLog.e(TAG, "formatTime error", e);
                return "";
            }
        }

        // 根据新的需求，年份只显示后两位
        String year = time.substring(2, 4);
        String month = time.substring(4, 6);
        String date = time.substring(6, 8);
        String hour = time.substring(8, 10);
        String min = time.substring(10, 12);
        String sec = time.substring(12, 14);

        switch (type) {
            case EsDataConstant.TIME_TYPE_YEAR:
                return year;
            case EsDataConstant.TIME_TYPE_MONTH:
                return month;
            case EsDataConstant.TIME_TYPE_DATE:
                return date;
            case EsDataConstant.TIME_TYPE_HOUR:
                return hour;
            case EsDataConstant.TIME_TYPE_MIN:
                return min;
            case EsDataConstant.TIME_TYPE_SEC:
                return sec;
            case EsDataConstant.TIME_TYPE_HOUR_MIN:
                return hour + ":" + min;
            case EsDataConstant.TIME_TYPE_MIN_SEC:
                return min + ":" + sec;
            case EsDataConstant.TIME_TYPE_YEAR_MONTH_DATA:
                return year + month + date;
            case EsDataConstant.TIME_TYPE_HOUR_MIN_SEC:
                return hour + ":" + min + ":" + sec;
            case EsDataConstant.TIME_TYPE_YEAR_MONTH_DATA_SLASH:
                if ("00".equals(date)) {
                    return  year + "/" + month;
                }
                return year + "/" + month + "/" + date;
            case EsDataConstant.TIME_TYPE_MONTH_DATA_SLASH:
                return month + "/" + date;
            default:
                return "";
        }
    }

    public Contract getContract(String contractNo) {
        return mQuoteApi.getContract(contractNo);
    }

    public Contract getTradeContract(String contractNo) {
        return mQuoteApi.getTradeContract(contractNo);
    }

    public Contract getQuoteContract(String contractNo) {
        return mQuoteApi.getQuoteContract(contractNo);
    }


    public Contract getRealContract(String contractNo) {
        return mQuoteApi.getRealContract(contractNo);
    }

    public List<HisQuoteTimeBucket> getBaseTimeBucketData(String commodityNo, long date) {
        return mQuoteApi.getBaseTimeBucketData(commodityNo, date);
    }

    public List<HisQuoteTimeBucket> getCalTimeBucketData(String commodityNo, long date) {
        return mQuoteApi.getCalTimeBucketData(commodityNo, date);
    }

    public QuoteField[][] getQuoteField(Contract contract) {
        return mQuoteApi.getQuoteField(contract);
    }

    public List<HisQuoteData> getMinData(Contract contract) {
        return mQuoteApi.getMinData(contract);
    }
    public List<HisQuoteData> getKLineData(Contract contract, KLinePeriod period, int end, int size) {
        return mQuoteApi.getKLineData(contract, period, end, size);
    }
}
