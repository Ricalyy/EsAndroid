package com.esunny.mobile.bean.rsp;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

public class PkgPhoneStartRsp extends ApiStruct {

    //判定是否更新
    private String          CurVersion;             //当前版本
    private String       UpdateInfo;             //更新内容
    private String             UpdateTime;             //更新时间


    //启动加载图片
    private String           ImgUrl;                 //启动图片加载网址
    private String             ImgStartDate;           //加载起始日期
    private String             ImgEndDate;             //加载结束日期
    private String             ImgUpdateTime;

    private String          BasicVersion;          //必须升级版本
    private String           FeedbackUrl;            //反馈Url
    private String           CompanyUrl;            //公司Url

    private long          MsgNotifyID;            // 通知id
    private char        MsgNotifyType;          // 通知类型
    private String             MsgNotifyStartDate;     // 通知的起始时间
    private String             MsgNotifyEndDate;       // 通知到结束时间

    private String        MsgNotifyData;          // 通知

    public PkgPhoneStartRsp(byte[] buf) {
        super(buf);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);

        CurVersion = parseUtil.getString(21);
        UpdateInfo = parseUtil.getString(301);
        UpdateTime = parseUtil.getString(21);

        ImgUrl = parseUtil.getString(101);
        ImgStartDate = parseUtil.getString(11);
        ImgEndDate = parseUtil.getString(11);
        ImgUpdateTime = parseUtil.getString(21);

        MsgNotifyID = parseUtil.getLong();
        MsgNotifyType = parseUtil.getChar();
        MsgNotifyStartDate = parseUtil.getString(11);
        MsgNotifyEndDate = parseUtil.getString(11);
        MsgNotifyData = parseUtil.getString(301);
    }

    public String getCurVersion() {
        return CurVersion;
    }

    public String getUpdateInfo() {
        return UpdateInfo;
    }

    public String getUpdateTime() {
        return UpdateTime;
    }

    public String getImgUrl() {
        return ImgUrl;
    }

    public String getImgStartDate() {
        return ImgStartDate;
    }

    public String getImgEndDate() {
        return ImgEndDate;
    }

    public String getImgUpdateTime() {
        return ImgUpdateTime;
    }

    public String getBasicVersion() {
        return BasicVersion;
    }

    public String getFeedbackUrl() {
        return FeedbackUrl;
    }

    public String getCompanyUrl() {
        return CompanyUrl;
    }

    public long getMsgNotifyID() {
        return MsgNotifyID;
    }

    public char getMsgNotifyType() {
        return MsgNotifyType;
    }

    public String getMsgNotifyStartDate() {
        return MsgNotifyStartDate;
    }

    public String getMsgNotifyEndDate() {
        return MsgNotifyEndDate;
    }

    public String getMsgNotifyData() {
        return MsgNotifyData;
    }
}
