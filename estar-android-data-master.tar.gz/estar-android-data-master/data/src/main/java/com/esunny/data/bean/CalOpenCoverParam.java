package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class CalOpenCoverParam {
    private String                                                  ContractNo;         //合约编号
    private char                                                    OrderType;          //定单类型
    private char                                                    Direct;             //买卖方向
    private char                                                    Offset;             //开仓 平仓 开平 平开(内盘)
    private char                                                    Hedge;              //投机保值 投保 保投(内盘)
    private double                                                  OrderPrice;         //委托价格(市价请填写昨结算价）
    private double                                                  PreSettlePrice;     //期权对应标的的昨结算价格；
    private double                                                  StandbyDepositRatio;     //备用保证金比例，用于取不到保证金情况下的计算
    private double                                                  StandbyFeeRatio;         //备用手续费比例，用于取不到手续费情况下的计算
    private double                                                  StandbyDeposit;     //备用保证金，用于取不到保证金情况下的计算
    private double                                                  StandbyFee;         //备用手续费，用于取不到手续费情况下的计算

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getOrderType() {
        return OrderType;
    }

    public void setOrderType(char orderType) {
        OrderType = orderType;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public double getOrderPrice() {
        return OrderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        OrderPrice = orderPrice;
    }

    public double getPreSettlePrice() {
        return PreSettlePrice;
    }

    public void setPreSettlePrice(double preSettlePrice) {
        PreSettlePrice = preSettlePrice;
    }

    public double getStandbyDepositRatio() {
        return StandbyDepositRatio;
    }

    public void setStandbyDepositRatio(double standbyDepositRatio) {
        StandbyDepositRatio = standbyDepositRatio;
    }

    public double getStandbyDeposit() {
        return StandbyDeposit;
    }

    public void setStandbyDeposit(double standbyDeposit) {
        StandbyDeposit = standbyDeposit;
    }

    public double getStandbyFeeRatio() {
        return StandbyFeeRatio;
    }

    public void setStandbyFeeRatio(double standbyFeeRatio) {
        StandbyFeeRatio = standbyFeeRatio;
    }

    public double getStandbyFee() {
        return StandbyFee;
    }

    public void setStandbyFee(double standbyFee) {
        StandbyFee = standbyFee;
    }

}
