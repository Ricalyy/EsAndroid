package com.esunny.data.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/10/30
 */
public class UssUserBehaviorInfo extends ApiStruct {

    public final static short STRUCT_LENGTH = 3178;

    private String                           LocalTime;

    private String                           PackageNo;
    private String                           HostName;
    private String                           MACAddr;
    private String                           LocalIP;
    private short                             LocalPort;

    private String                           OsInfo;
    private String                           CpuId;
    private String                           CpuInfo;
    private String                           MemInfo;
    private String                           GraphicsInfo;
    private String                           DpiInfo;

    private String                           ProductInfo;
    private String                           ProductVersion;

    private String                           UserNo;
    private String                           LoginApi;


    private String                           CompanyNo;
    private String                           CompanyName;
    private String                           AddrNo;
    private String                           AddrName;
    private String                           ServerIP;                                //登录IP
    private short                             ServerPort;                              //登录端口
    private String                           BrokerId;
    private String                           TradeCert;

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(LocalTime, 21));
        buffer.put(stringToByte(PackageNo, 11));
        buffer.put(stringToByte(HostName, 51));
        buffer.put(stringToByte(MACAddr, 51));
        buffer.put(stringToByte(LocalIP, 51));
//        buffer.put(charToByte(LocalPort));
        buffer.putShort(LocalPort);
        buffer.put(stringToByte(OsInfo, 51));
        buffer.put(stringToByte(CpuId, 51));
        buffer.put(stringToByte(CpuInfo, 51));
        buffer.put(stringToByte(MemInfo, 51));
        buffer.put(stringToByte(GraphicsInfo, 51));
        buffer.put(stringToByte(DpiInfo, 51));
        buffer.put(stringToByte(ProductInfo, 21));
        buffer.put(stringToByte(ProductVersion, 21));
        buffer.put(stringToByte(UserNo, 51));
        buffer.put(stringToByte(LoginApi, 21));
        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(CompanyName, 51));
        buffer.put(stringToByte(AddrNo, 21));
        buffer.put(stringToByte(AddrName, 51));
        buffer.put(stringToByte(ServerIP, 51));
//        buffer.put(charToByte(ServerPort));
        buffer.putShort(ServerPort);
        buffer.put(stringToByte(BrokerId, 11));
        buffer.put(stringToByte(TradeCert, 21));


        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getLocalTime() {
        return LocalTime;
    }

    public void setLocalTime(String localTime) {
        LocalTime = localTime;
    }

    public String getPackageNo() {
        return PackageNo;
    }

    public void setPackageNo(String packageNo) {
        PackageNo = packageNo;
    }

    public String getHostName() {
        return HostName;
    }

    public void setHostName(String hostName) {
        HostName = hostName;
    }

    public String getMACAddr() {
        return MACAddr;
    }

    public void setMACAddr(String MACAddr) {
        this.MACAddr = MACAddr;
    }

    public String getLocalIP() {
        return LocalIP;
    }

    public void setLocalIP(String localIP) {
        LocalIP = localIP;
    }

    public short getLocalPort() {
        return LocalPort;
    }

    public void setLocalPort(short localPort) {
        LocalPort = localPort;
    }

    public String getOsInfo() {
        return OsInfo;
    }

    public void setOsInfo(String osInfo) {
        OsInfo = osInfo;
    }

    public String getCpuId() {
        return CpuId;
    }

    public void setCpuId(String cpuId) {
        CpuId = cpuId;
    }

    public String getCpuInfo() {
        return CpuInfo;
    }

    public void setCpuInfo(String cpuInfo) {
        CpuInfo = cpuInfo;
    }

    public String getMemInfo() {
        return MemInfo;
    }

    public void setMemInfo(String memInfo) {
        MemInfo = memInfo;
    }

    public String getGraphicsInfo() {
        return GraphicsInfo;
    }

    public void setGraphicsInfo(String graphicsInfo) {
        GraphicsInfo = graphicsInfo;
    }

    public String getDpiInfo() {
        return DpiInfo;
    }

    public void setDpiInfo(String dpiInfo) {
        DpiInfo = dpiInfo;
    }

    public String getProductInfo() {
        return ProductInfo;
    }

    public void setProductInfo(String productInfo) {
        ProductInfo = productInfo;
    }

    public String getProductVersion() {
        return ProductVersion;
    }

    public void setProductVersion(String productVersion) {
        ProductVersion = productVersion;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getLoginApi() {
        return LoginApi;
    }

    public void setLoginApi(String loginApi) {
        LoginApi = loginApi;
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public void setCompanyName(String companyName) {
        CompanyName = companyName;
    }

    public String getAddrNo() {
        return AddrNo;
    }

    public void setAddrNo(String addrNo) {
        AddrNo = addrNo;
    }

    public String getAddrName() {
        return AddrName;
    }

    public void setAddrName(String addrName) {
        AddrName = addrName;
    }

    public String getServerIP() {
        return ServerIP;
    }

    public void setServerIP(String serverIP) {
        ServerIP = serverIP;
    }

    public short getServerPort() {
        return ServerPort;
    }

    public void setServerPort(short serverPort) {
        ServerPort = serverPort;
    }

    public String getBrokerId() {
        return BrokerId;
    }

    public void setBrokerId(String brokerId) {
        BrokerId = brokerId;
    }

    public String getTradeCert() {
        return TradeCert;
    }

    public void setTradeCert(String tradeCert) {
        TradeCert = tradeCert;
    }
}
