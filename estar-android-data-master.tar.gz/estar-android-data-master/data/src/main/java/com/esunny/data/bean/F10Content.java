package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class F10Content {
    private String                              NewsTradeCommodityName;            //交易品种
    private String                              NewsUnit;                        //交易单位
    private String                              NewsOffUnit;                     //报价单位
    private String                              NewsTick;                        //最小变动价
    private String                              NewsRaisingLimit;                //涨跌停板幅度
    private String                              NewsTradingMargin;               //最低交易保证金
    private String                              NewsContractMonth;               //合约月份
    private String                              NewsTradingTime;                 //交易时间
    private String                              NewsLastTradingDate;             //最后交易日
    private String                              NewsLastDeliveryDate;            //交割日期
    private String                              NewsDeliveryGrade;               //交割等级
    private String                              NewsDeliverySite;                //交割地点
    private String                              NewsDeliveryMethod;              //交割方式
    private String                              NewsDeliveryUnit;                //交割单位
    private String                              NewsTradeCode;                   //交易代码
    private String                              NewsExchange;                    //上市交易所

    public String getNewsTradeCommodityName() {
        return NewsTradeCommodityName;
    }

    public void setNewsTradeCommodityName(String newsTradeCommodityName) {
        NewsTradeCommodityName = newsTradeCommodityName;
    }

    public String getNewsUnit() {
        return NewsUnit;
    }

    public void setNewsUnit(String newsUnit) {
        NewsUnit = newsUnit;
    }

    public String getNewsOffUnit() {
        return NewsOffUnit;
    }

    public void setNewsOffUnit(String newsOffUnit) {
        NewsOffUnit = newsOffUnit;
    }

    public String getNewsTick() {
        return NewsTick;
    }

    public void setNewsTick(String newsTick) {
        NewsTick = newsTick;
    }

    public String getNewsRaisingLimit() {
        return NewsRaisingLimit;
    }

    public void setNewsRaisingLimit(String newsRaisingLimit) {
        NewsRaisingLimit = newsRaisingLimit;
    }

    public String getNewsTradingMargin() {
        return NewsTradingMargin;
    }

    public void setNewsTradingMargin(String newsTradingMargin) {
        NewsTradingMargin = newsTradingMargin;
    }

    public String getNewsContractMonth() {
        return NewsContractMonth;
    }

    public void setNewsContractMonth(String newsContractMonth) {
        NewsContractMonth = newsContractMonth;
    }

    public String getNewsTradingTime() {
        return NewsTradingTime;
    }

    public void setNewsTradingTime(String newsTradingTime) {
        NewsTradingTime = newsTradingTime;
    }

    public String getNewsLastTradingDate() {
        return NewsLastTradingDate;
    }

    public void setNewsLastTradingDate(String newsLastTradingDate) {
        NewsLastTradingDate = newsLastTradingDate;
    }

    public String getNewsLastDeliveryDate() {
        return NewsLastDeliveryDate;
    }

    public void setNewsLastDeliveryDate(String newsLastDeliveryDate) {
        NewsLastDeliveryDate = newsLastDeliveryDate;
    }

    public String getNewsDeliveryGrade() {
        return NewsDeliveryGrade;
    }

    public void setNewsDeliveryGrade(String newsDeliveryGrade) {
        NewsDeliveryGrade = newsDeliveryGrade;
    }

    public String getNewsDeliverySite() {
        return NewsDeliverySite;
    }

    public void setNewsDeliverySite(String newsDeliverySite) {
        NewsDeliverySite = newsDeliverySite;
    }

    public String getNewsDeliveryMethod() {
        return NewsDeliveryMethod;
    }

    public void setNewsDeliveryMethod(String newsDeliveryMethod) {
        NewsDeliveryMethod = newsDeliveryMethod;
    }

    public String getNewsDeliveryUnit() {
        return NewsDeliveryUnit;
    }

    public void setNewsDeliveryUnit(String newsDeliveryUnit) {
        NewsDeliveryUnit = newsDeliveryUnit;
    }

    public String getNewsTradeCode() {
        return NewsTradeCode;
    }

    public void setNewsTradeCode(String newsTradeCode) {
        NewsTradeCode = newsTradeCode;
    }

    public String getNewsExchange() {
        return NewsExchange;
    }

    public void setNewsExchange(String newsExchange) {
        NewsExchange = newsExchange;
    }

}
