package com.esunny.mobile;

public class UnixJNI {
    
    static {
        System.loadLibrary("StarMobileAndroidApi");
    }

    public static native int S_RegEvent(JNICallBack jarg1);


    public static native int S_Init(String jarg1);
    public static native String S_GetPackageNo();
    public static native int S_Connect(String addr, int port);
    public static native int S_Disconnect(int key);
    public static native int S_Close(int key);

    public static native int S_SendMessage(int key, char type, int len, byte[] buf);

    public static native int S_SendAuthReq(int key, int languageType, char subSystemType);

    public static native boolean S_IsOpenTcp(int key);
//    public static native int S_PkgQuery_CodeForbidInfo(int key, int languageType);

    public static native int S_TcpFree(int key);
}
