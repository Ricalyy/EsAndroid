package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class TrdSecondCheckCodeInfo {
    private char SendType;//发送类型
    private String SendAccount;//发送账号（手机或者邮箱）

    public char getSendType() {
        return SendType;
    }

    public void setSendType(char sendType) {
        SendType = sendType;
    }

    public String getSendAccount() {
        return SendAccount;
    }

    public void setSendAccount(String sendAccount) {
        SendAccount = sendAccount;
    }
}
