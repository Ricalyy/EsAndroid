package com.esunny.data.bean;

import com.esunny.data.api.inter.ApiStruct;

/**
 * @author Peter Fu
 * @date 2020/9/21
 */
public class SQuoteUserInfo extends ApiStruct {

    private String LoginNo;            //账号
    private String PassWord;           //密码
    private int ErrorCode;          //登录错误码
    private String ErrorText;          //登录错误信息
    private String PackageNo;          //包号
    private char LoginType;          //登录类型
    private String UUId;               //用户唯一ID
    private boolean bCertSuccessed;     //认证成功
    private boolean bReLoginClose;      //二次登陆断线标识1 连上后状态重置0

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getLoginNo() {
        return LoginNo;
    }

    public void setLoginNo(String loginNo) {
        LoginNo = loginNo;
    }

    public String getPassWord() {
        return PassWord;
    }

    public void setPassWord(String passWord) {
        PassWord = passWord;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }

    public String getPackageNo() {
        return PackageNo;
    }

    public void setPackageNo(String packageNo) {
        PackageNo = packageNo;
    }

    public char getLoginType() {
        return LoginType;
    }

    public void setLoginType(char loginType) {
        LoginType = loginType;
    }

    public String getUUId() {
        return UUId;
    }

    public void setUUId(String UUId) {
        this.UUId = UUId;
    }

    public boolean getbCertSuccessed() {
        return bCertSuccessed;
    }

    public void setbCertSuccessed(boolean bCertSuccessed) {
        this.bCertSuccessed = bCertSuccessed;
    }

    public boolean getbReLoginClose() {
        return bReLoginClose;
    }

    public void setbReLoginClose(boolean bReLoginClose) {
        this.bReLoginClose = bReLoginClose;
    }
}
