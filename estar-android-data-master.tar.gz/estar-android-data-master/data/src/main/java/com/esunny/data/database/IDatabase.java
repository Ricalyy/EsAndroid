package com.esunny.data.database;

import android.database.sqlite.SQLiteDatabase;

import com.esunny.data.database.gen.DaoMaster;
import com.esunny.data.database.gen.DaoSession;

/**
 * @author Peter Fu
 * @date 2020/10/13
 */
public interface IDatabase {
    DaoSession getDaoSession();

    DaoMaster getDaoMaster();

    SQLiteDatabase getWritableDatabase();
}
