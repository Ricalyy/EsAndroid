package com.esunny.data.error;

import android.content.Context;

import com.esunny.data.R;


class DipperErrorCode {

    static String getErrorMessage(Context context, int errorCode) {

        switch (errorCode) {
            case 0 :
                return context.getResources().getString(R.string.dipper_0);
            case -1 :
                return context.getResources().getString(R.string.dipper_n1);
            case -2 :
                return context.getResources().getString(R.string.dipper_n2);
            case -3 :
                return context.getResources().getString(R.string.dipper_n3);
            case -4 :
                return context.getResources().getString(R.string.dipper_n4);
            case -5 :
                return context.getResources().getString(R.string.dipper_n5);
            case -6 :
                return context.getResources().getString(R.string.dipper_n6);
            case -7 :
                return context.getResources().getString(R.string.dipper_n7);
            case -8 :
                return context.getResources().getString(R.string.dipper_n8);
            case -9 :
                return context.getResources().getString(R.string.dipper_n9);
            case -10 :
                return context.getResources().getString(R.string.dipper_n10);
            case -11 :
                return context.getResources().getString(R.string.dipper_n11);
            case -12 :
                return context.getResources().getString(R.string.dipper_n12);
            case -13 :
                return context.getResources().getString(R.string.dipper_n13);
            case -14 :
                return context.getResources().getString(R.string.dipper_n14);
            case -15 :
                return context.getResources().getString(R.string.dipper_n15);
            case -16 :
                return context.getResources().getString(R.string.dipper_n16);
            case -17 :
                return context.getResources().getString(R.string.dipper_n17);
            case -18 :
                return context.getResources().getString(R.string.dipper_n18);
            case -19 :
                return context.getResources().getString(R.string.dipper_n19);
            case -20 :
                return context.getResources().getString(R.string.dipper_n20);
            case -21 :
                return context.getResources().getString(R.string.dipper_n21);
            case -22 :
                return context.getResources().getString(R.string.dipper_n22);
            case -23 :
                return context.getResources().getString(R.string.dipper_n23);
            case -24 :
                return context.getResources().getString(R.string.dipper_n24);
            case -25 :
                return context.getResources().getString(R.string.dipper_n25);
            case -26 :
                return context.getResources().getString(R.string.dipper_n26);
            case -27 :
                return context.getResources().getString(R.string.dipper_n27);
            case -28 :
                return context.getResources().getString(R.string.dipper_n28);
            case -29 :
                return context.getResources().getString(R.string.dipper_n29);
            case -30 :
                return context.getResources().getString(R.string.dipper_n30);
            case -31 :
                return context.getResources().getString(R.string.dipper_n31);
            case -32 :
                return context.getResources().getString(R.string.dipper_n32);
            case -33 :
                return context.getResources().getString(R.string.dipper_n33);
            case -34 :
                return context.getResources().getString(R.string.dipper_n34);
            case -35 :
                return context.getResources().getString(R.string.dipper_n35);
            case -36 :
                return context.getResources().getString(R.string.dipper_n36);
            case -37 :
                return context.getResources().getString(R.string.dipper_n37);
            case -10000 :
                return context.getResources().getString(R.string.dipper_n10000);
            case -10001 :
                return context.getResources().getString(R.string.dipper_n10001);
            case -10002 :
                return context.getResources().getString(R.string.dipper_n10002);
            case -10003 :
                return context.getResources().getString(R.string.dipper_n10003);
            case -10004 :
                return context.getResources().getString(R.string.dipper_n10004);
            case -10005 :
                return context.getResources().getString(R.string.dipper_n10005);
            case -10006 :
                return context.getResources().getString(R.string.dipper_n10006);
            case -12001 :
                return context.getResources().getString(R.string.dipper_n12001);
            case -12003 :
                return context.getResources().getString(R.string.dipper_n12003);
            case -12004 :
                return context.getResources().getString(R.string.dipper_n12004);
            case -12005 :
                return context.getResources().getString(R.string.dipper_n12005);
            case -12006 :
                return context.getResources().getString(R.string.dipper_n12006);
            case -12007 :
                return context.getResources().getString(R.string.dipper_n12007);
            case -12008 :
                return context.getResources().getString(R.string.dipper_n12008);
            case -12009 :
                return context.getResources().getString(R.string.dipper_n12009);
            case -12010 :
                return context.getResources().getString(R.string.dipper_n12010);
            case -12011 :
                return context.getResources().getString(R.string.dipper_n12011);
            case -12012 :
                return context.getResources().getString(R.string.dipper_n12012);
            case -12013 :
                return context.getResources().getString(R.string.dipper_n12013);
            case -12014 :
                return context.getResources().getString(R.string.dipper_n12014);
            case -12015 :
                return context.getResources().getString(R.string.dipper_n12015);
            case -12016 :
                return context.getResources().getString(R.string.dipper_n12016);
            case -12017 :
                return context.getResources().getString(R.string.dipper_n12017);
            case -12021 :
                return context.getResources().getString(R.string.dipper_n12021);
            case -12022 :
                return context.getResources().getString(R.string.dipper_n12022);
            case -12023 :
                return context.getResources().getString(R.string.dipper_n12023);
            case -12024 :
                return context.getResources().getString(R.string.dipper_n12024);
            case -12025 :
                return context.getResources().getString(R.string.dipper_n12025);
            case -12035 :
                return context.getResources().getString(R.string.dipper_n12035);
            case -12036 :
                return context.getResources().getString(R.string.dipper_n12036);
            case -12041 :
                return context.getResources().getString(R.string.dipper_n12041);
            case -12042 :
                return context.getResources().getString(R.string.dipper_n12042);
            case -12043 :
                return context.getResources().getString(R.string.dipper_n12043);
            case -12044 :
                return context.getResources().getString(R.string.dipper_n12044);
            case -12045 :
                return context.getResources().getString(R.string.dipper_n12045);
            case -12046 :
                return context.getResources().getString(R.string.dipper_n12046);
            case -12047 :
                return context.getResources().getString(R.string.dipper_n12047);
            case -12048 :
                return context.getResources().getString(R.string.dipper_n12048);
            case -12049 :
                return context.getResources().getString(R.string.dipper_n12049);
            case -12050 :
                return context.getResources().getString(R.string.dipper_n12050);
            case -12051 :
                return context.getResources().getString(R.string.dipper_n12051);
            case 1 :
                return context.getResources().getString(R.string.dipper_1);
            case 2 :
                return context.getResources().getString(R.string.dipper_2);
            case 3 :
                return context.getResources().getString(R.string.dipper_3);
            case 4 :
                return context.getResources().getString(R.string.dipper_4);
            case 5 :
                return context.getResources().getString(R.string.dipper_5);
            case 6 :
                return context.getResources().getString(R.string.dipper_6);
            case 7 :
                return context.getResources().getString(R.string.dipper_7);
            case 8 :
                return context.getResources().getString(R.string.dipper_8);
            case 9 :
                return context.getResources().getString(R.string.dipper_9);
            case 10 :
                return context.getResources().getString(R.string.dipper_10);
            case 11 :
                return context.getResources().getString(R.string.dipper_11);
            case 12 :
                return context.getResources().getString(R.string.dipper_12);
            case 13 :
                return context.getResources().getString(R.string.dipper_13);
            case 14 :
                return context.getResources().getString(R.string.dipper_14);
            case 15 :
                return context.getResources().getString(R.string.dipper_15);
            case 16 :
                return context.getResources().getString(R.string.dipper_16);
            case 10001 :
                return context.getResources().getString(R.string.dipper_10001);
            case 10002 :
                return context.getResources().getString(R.string.dipper_10002);
            case 10003 :
                return context.getResources().getString(R.string.dipper_10003);
            case 10004 :
                return context.getResources().getString(R.string.dipper_10004);
            case 10005 :
                return context.getResources().getString(R.string.dipper_10005);
            case 10006 :
                return context.getResources().getString(R.string.dipper_10006);
            case 10007 :
                return context.getResources().getString(R.string.dipper_10007);
            case 10008 :
                return context.getResources().getString(R.string.dipper_10008);
            case 10009 :
                return context.getResources().getString(R.string.dipper_10009);
            case 10010 :
                return context.getResources().getString(R.string.dipper_10010);
            case 10011 :
                return context.getResources().getString(R.string.dipper_10011);
            case 10012 :
                return context.getResources().getString(R.string.dipper_10012);
            case 10013 :
                return context.getResources().getString(R.string.dipper_10013);
            case 10014 :
                return context.getResources().getString(R.string.dipper_10014);
            case 10015 :
                return context.getResources().getString(R.string.dipper_10015);
            case 10016 :
                return context.getResources().getString(R.string.dipper_10016);
            case 10017 :
                return context.getResources().getString(R.string.dipper_10017);
            case 10018 :
                return context.getResources().getString(R.string.dipper_10018);
            case 10019 :
                return context.getResources().getString(R.string.dipper_10019);
            case 10020 :
                return context.getResources().getString(R.string.dipper_10020);
            case 10021 :
                return context.getResources().getString(R.string.dipper_10021);
            case 10022 :
                return context.getResources().getString(R.string.dipper_10022);
            case 10023 :
                return context.getResources().getString(R.string.dipper_10023);
            case 10050 :
                return context.getResources().getString(R.string.dipper_10050);
            case 10052 :
                return context.getResources().getString(R.string.dipper_10052);
            case 10053 :
                return context.getResources().getString(R.string.dipper_10053);
            case 10054 :
                return context.getResources().getString(R.string.dipper_10054);
            case 10055 :
                return context.getResources().getString(R.string.dipper_10055);
            case 10056 :
                return context.getResources().getString(R.string.dipper_10056);
            case 10057 :
                return context.getResources().getString(R.string.dipper_10057);
            case 10058 :
                return context.getResources().getString(R.string.dipper_10058);
            case 10059 :
                return context.getResources().getString(R.string.dipper_10059);
            case 10060 :
                return context.getResources().getString(R.string.dipper_10060);
            case 10061 :
                return context.getResources().getString(R.string.dipper_10061);
            case 10062 :
                return context.getResources().getString(R.string.dipper_10062);
            case 10101 :
                return context.getResources().getString(R.string.dipper_10101);
            case 11000 :
                return context.getResources().getString(R.string.dipper_11000);
            case 11001 :
                return context.getResources().getString(R.string.dipper_11001);
            case 11002 :
                return context.getResources().getString(R.string.dipper_11002);
            case 11003 :
                return context.getResources().getString(R.string.dipper_11003);
            case 11004 :
                return context.getResources().getString(R.string.dipper_11004);
            case 11005 :
                return context.getResources().getString(R.string.dipper_11005);
            case 11006 :
                return context.getResources().getString(R.string.dipper_11006);
            case 11007 :
                return context.getResources().getString(R.string.dipper_11007);
            case 11008 :
                return context.getResources().getString(R.string.dipper_11008);
            case 11009 :
                return context.getResources().getString(R.string.dipper_11009);
            case 11010 :
                return context.getResources().getString(R.string.dipper_11010);
            case 11011 :
                return context.getResources().getString(R.string.dipper_11011);
            case 11501 :
                return context.getResources().getString(R.string.dipper_11501);
            case 11701 :
                return context.getResources().getString(R.string.dipper_11701);
            case 11702 :
                return context.getResources().getString(R.string.dipper_11702);
            case 11703 :
                return context.getResources().getString(R.string.dipper_11703);
            case 11704 :
                return context.getResources().getString(R.string.dipper_11704);
            case 12001 :
                return context.getResources().getString(R.string.dipper_12001);
            case 12002 :
                return context.getResources().getString(R.string.dipper_12002);
            case 12003 :
                return context.getResources().getString(R.string.dipper_12003);
            case 13001 :
                return context.getResources().getString(R.string.dipper_13001);
            case 13002 :
                return context.getResources().getString(R.string.dipper_13002);
            case 14001 :
                return context.getResources().getString(R.string.dipper_14001);
            case 14002 :
                return context.getResources().getString(R.string.dipper_14002);
            case 15001 :
                return context.getResources().getString(R.string.dipper_15001);
            case 15002 :
                return context.getResources().getString(R.string.dipper_15002);
            case 15003 :
                return context.getResources().getString(R.string.dipper_15003);
            case 15004 :
                return context.getResources().getString(R.string.dipper_15004);
            case 15005 :
                return context.getResources().getString(R.string.dipper_15005);
            case 15006 :
                return context.getResources().getString(R.string.dipper_15006);
            case 20201 :
                return context.getResources().getString(R.string.dipper_20201);
            case 20701 :
                return context.getResources().getString(R.string.dipper_20701);
            case 22801 :
                return context.getResources().getString(R.string.dipper_22801);
            case 22901 :
                return context.getResources().getString(R.string.dipper_22901);
            case 28901 :
                return context.getResources().getString(R.string.dipper_28901);
            case 60001 :
                return context.getResources().getString(R.string.dipper_60001);
            case 60002 :
                return context.getResources().getString(R.string.dipper_60002);
            case 60003 :
                return context.getResources().getString(R.string.dipper_60003);
            case 60004 :
                return context.getResources().getString(R.string.dipper_60004);
            case 60005 :
                return context.getResources().getString(R.string.dipper_60005);
            case 60006 :
                return context.getResources().getString(R.string.dipper_60006);
            case 60007 :
                return context.getResources().getString(R.string.dipper_60007);
            case 60011 :
                return context.getResources().getString(R.string.dipper_60011);
            case 60012 :
                return context.getResources().getString(R.string.dipper_60012);
            case 60013 :
                return context.getResources().getString(R.string.dipper_60013);
            case 60014 :
                return context.getResources().getString(R.string.dipper_60014);
            case 60015 :
                return context.getResources().getString(R.string.dipper_60015);
            case 60021 :
                return context.getResources().getString(R.string.dipper_60021);
            case 60022 :
                return context.getResources().getString(R.string.dipper_60022);
            case 60023 :
                return context.getResources().getString(R.string.dipper_60023);
            case 60024 :
                return context.getResources().getString(R.string.dipper_60024);
            case 60025 :
                return context.getResources().getString(R.string.dipper_60025);
            case 60026 :
                return context.getResources().getString(R.string.dipper_60026);
            case 60027 :
                return context.getResources().getString(R.string.dipper_60027);
            case 60028 :
                return context.getResources().getString(R.string.dipper_60028);
            case 60029 :
                return context.getResources().getString(R.string.dipper_60029);
            case 60030 :
                return context.getResources().getString(R.string.dipper_60030);
            case 60031 :
                return context.getResources().getString(R.string.dipper_60031);
            case 60032 :
                return context.getResources().getString(R.string.dipper_60032);
            case 60033 :
                return context.getResources().getString(R.string.dipper_60033);
            case 60034 :
                return context.getResources().getString(R.string.dipper_60034);
            case 60035 :
                return context.getResources().getString(R.string.dipper_60035);
            case 60036 :
                return context.getResources().getString(R.string.dipper_60036);
            case 60037 :
                return context.getResources().getString(R.string.dipper_60037);
            case 60038 :
                return context.getResources().getString(R.string.dipper_60038);
            case 60039 :
                return context.getResources().getString(R.string.dipper_60039);
            case 60040 :
                return context.getResources().getString(R.string.dipper_60040);
            case 60041 :
                return context.getResources().getString(R.string.dipper_60041);
            case 60042 :
                return context.getResources().getString(R.string.dipper_60042);
            case 60051 :
                return context.getResources().getString(R.string.dipper_60051);
            case 60052 :
                return context.getResources().getString(R.string.dipper_60052);
            case 60053 :
                return context.getResources().getString(R.string.dipper_60053);
            case 60054 :
                return context.getResources().getString(R.string.dipper_60054);
            case 60055 :
                return context.getResources().getString(R.string.dipper_60055);
            case 60056 :
                return context.getResources().getString(R.string.dipper_60056);
            case 60057 :
                return context.getResources().getString(R.string.dipper_60057);
            case 60058 :
                return context.getResources().getString(R.string.dipper_60058);
            case 60061 :
                return context.getResources().getString(R.string.dipper_60061);
            case 60062 :
                return context.getResources().getString(R.string.dipper_60062);
            case 60063 :
                return context.getResources().getString(R.string.dipper_60063);
            case 60071 :
                return context.getResources().getString(R.string.dipper_60071);
            case 60072 :
                return context.getResources().getString(R.string.dipper_60072);
            case 60073 :
                return context.getResources().getString(R.string.dipper_60073);
            case 60074 :
                return context.getResources().getString(R.string.dipper_60074);
            case 60075 :
                return context.getResources().getString(R.string.dipper_60075);
            case 60081 :
                return context.getResources().getString(R.string.dipper_60081);
            case 60082 :
                return context.getResources().getString(R.string.dipper_60082);
            case 60091 :
                return context.getResources().getString(R.string.dipper_60091);
            case 60092 :
                return context.getResources().getString(R.string.dipper_60092);
            case 60100 :
                return context.getResources().getString(R.string.dipper_60100);
            case 60101 :
                return context.getResources().getString(R.string.dipper_60101);
            case 60102 :
                return context.getResources().getString(R.string.dipper_60102);
            case 60103 :
                return context.getResources().getString(R.string.dipper_60103);
            case 60104 :
                return context.getResources().getString(R.string.dipper_60104);
            case 60105 :
                return context.getResources().getString(R.string.dipper_60105);
            case 60106 :
                return context.getResources().getString(R.string.dipper_60106);
            case 60107 :
                return context.getResources().getString(R.string.dipper_60107);
            case 60108 :
                return context.getResources().getString(R.string.dipper_60108);
            case 60109 :
                return context.getResources().getString(R.string.dipper_60109);
            case 60110 :
                return context.getResources().getString(R.string.dipper_60110);
            case 60111 :
                return context.getResources().getString(R.string.dipper_60111);
            case 60112 :
                return context.getResources().getString(R.string.dipper_60112);
            case 60113 :
                return context.getResources().getString(R.string.dipper_60113);
            case 60114 :
                return context.getResources().getString(R.string.dipper_60114);
            case 60115 :
                return context.getResources().getString(R.string.dipper_60115);
            case 60116 :
                return context.getResources().getString(R.string.dipper_60116);
            case 60117 :
                return context.getResources().getString(R.string.dipper_60117);
            case 60118 :
                return context.getResources().getString(R.string.dipper_60118);
            case 60119 :
                return context.getResources().getString(R.string.dipper_60119);
            case 60120 :
                return context.getResources().getString(R.string.dipper_60120);
            case 60121 :
                return context.getResources().getString(R.string.dipper_60121);
            case 60122 :
                return context.getResources().getString(R.string.dipper_60122);
            case 60123 :
                return context.getResources().getString(R.string.dipper_60123);
            case 60131 :
                return context.getResources().getString(R.string.dipper_60131);
            case 60132 :
                return context.getResources().getString(R.string.dipper_60132);
            case 60141 :
                return context.getResources().getString(R.string.dipper_60141);
            case 60142 :
                return context.getResources().getString(R.string.dipper_60142);
            case 60143 :
                return context.getResources().getString(R.string.dipper_60143);
            case 60144 :
                return context.getResources().getString(R.string.dipper_60144);
            case 60145 :
                return context.getResources().getString(R.string.dipper_60145);
            case 60151 :
                return context.getResources().getString(R.string.dipper_60151);
            case 60152 :
                return context.getResources().getString(R.string.dipper_60152);
            case 60161 :
                return context.getResources().getString(R.string.dipper_60161);
            case 60162 :
                return context.getResources().getString(R.string.dipper_60162);
            case 60163 :
                return context.getResources().getString(R.string.dipper_60163);
            case 60164 :
                return context.getResources().getString(R.string.dipper_60164);
            case 60165 :
                return context.getResources().getString(R.string.dipper_60165);
            case 60166 :
                return context.getResources().getString(R.string.dipper_60166);
            case 60171 :
                return context.getResources().getString(R.string.dipper_60171);
            case 60172 :
                return context.getResources().getString(R.string.dipper_60172);
            case 60173 :
                return context.getResources().getString(R.string.dipper_60173);
            case 60174 :
                return context.getResources().getString(R.string.dipper_60174);
            case 60175 :
                return context.getResources().getString(R.string.dipper_60175);
            case 60176 :
                return context.getResources().getString(R.string.dipper_60176);
            case 60177 :
                return context.getResources().getString(R.string.dipper_60177);
            case 60181 :
                return context.getResources().getString(R.string.dipper_60181);
            case 60182 :
                return context.getResources().getString(R.string.dipper_60182);
            case 60503 :
                return context.getResources().getString(R.string.dipper_60503);
            case 60504 :
                return context.getResources().getString(R.string.dipper_60504);
            case 60505 :
                return context.getResources().getString(R.string.dipper_60505);
            case 60506 :
                return context.getResources().getString(R.string.dipper_60506);
            case 60511 :
                return context.getResources().getString(R.string.dipper_60511);
            case 60512 :
                return context.getResources().getString(R.string.dipper_60512);
            case 60513 :
                return context.getResources().getString(R.string.dipper_60513);
            case 60514 :
                return context.getResources().getString(R.string.dipper_60514);
            case 60515 :
                return context.getResources().getString(R.string.dipper_60515);
            case 60521 :
                return context.getResources().getString(R.string.dipper_60521);
            case 60522 :
                return context.getResources().getString(R.string.dipper_60522);
            case 60523 :
                return context.getResources().getString(R.string.dipper_60523);
            case 60524 :
                return context.getResources().getString(R.string.dipper_60524);
            case 60525 :
                return context.getResources().getString(R.string.dipper_60525);
            case 60526 :
                return context.getResources().getString(R.string.dipper_60526);
            case 60527 :
                return context.getResources().getString(R.string.dipper_60527);
            case 60528 :
                return context.getResources().getString(R.string.dipper_60528);
            case 60529 :
                return context.getResources().getString(R.string.dipper_60529);
            case 60530 :
                return context.getResources().getString(R.string.dipper_60530);
            case 60531 :
                return context.getResources().getString(R.string.dipper_60531);
            case 60532 :
                return context.getResources().getString(R.string.dipper_60532);
            case 60533 :
                return context.getResources().getString(R.string.dipper_60533);
            case 60534 :
                return context.getResources().getString(R.string.dipper_60534);
            case 60535 :
                return context.getResources().getString(R.string.dipper_60535);
            case 60541 :
                return context.getResources().getString(R.string.dipper_60541);
            case 60542 :
                return context.getResources().getString(R.string.dipper_60542);
            case 60551 :
                return context.getResources().getString(R.string.dipper_60551);
            case 60552 :
                return context.getResources().getString(R.string.dipper_60552);
            case 60553 :
                return context.getResources().getString(R.string.dipper_60553);
            case 60554 :
                return context.getResources().getString(R.string.dipper_60554);
            case 60555 :
                return context.getResources().getString(R.string.dipper_60555);
            case 60556 :
                return context.getResources().getString(R.string.dipper_60556);
            case 60557 :
                return context.getResources().getString(R.string.dipper_60557);
            case 60558 :
                return context.getResources().getString(R.string.dipper_60558);
            case 60561 :
                return context.getResources().getString(R.string.dipper_60561);
            case 60562 :
                return context.getResources().getString(R.string.dipper_60562);
            case 60563 :
                return context.getResources().getString(R.string.dipper_60563);
            case 60571 :
                return context.getResources().getString(R.string.dipper_60571);
            case 60572 :
                return context.getResources().getString(R.string.dipper_60572);
            case 60573 :
                return context.getResources().getString(R.string.dipper_60573);
            case 60574 :
                return context.getResources().getString(R.string.dipper_60574);
            case 60575 :
                return context.getResources().getString(R.string.dipper_60575);
            case 60581 :
                return context.getResources().getString(R.string.dipper_60581);
            case 60591 :
                return context.getResources().getString(R.string.dipper_60591);
            case 60601 :
                return context.getResources().getString(R.string.dipper_60601);
            case 60611 :
                return context.getResources().getString(R.string.dipper_60611);
            case 60612 :
                return context.getResources().getString(R.string.dipper_60612);
            case 60621 :
                return context.getResources().getString(R.string.dipper_60621);
            case 60622 :
                return context.getResources().getString(R.string.dipper_60622);
            case 60623 :
                return context.getResources().getString(R.string.dipper_60623);
            case 60631 :
                return context.getResources().getString(R.string.dipper_60631);
            case 60632 :
                return context.getResources().getString(R.string.dipper_60632);
            case 60641 :
                return context.getResources().getString(R.string.dipper_60641);
            case 60642 :
                return context.getResources().getString(R.string.dipper_60642);
            case 60643 :
                return context.getResources().getString(R.string.dipper_60643);
            case 60644 :
                return context.getResources().getString(R.string.dipper_60644);
            case 60645 :
                return context.getResources().getString(R.string.dipper_60645);
            case 60651 :
                return context.getResources().getString(R.string.dipper_60651);
            case 60652 :
                return context.getResources().getString(R.string.dipper_60652);
            case 60661 :
                return context.getResources().getString(R.string.dipper_60661);
            case 60662 :
                return context.getResources().getString(R.string.dipper_60662);
            case 60663 :
                return context.getResources().getString(R.string.dipper_60663);
            case 60664 :
                return context.getResources().getString(R.string.dipper_60664);
            case 60665 :
                return context.getResources().getString(R.string.dipper_60665);
            case 60666 :
                return context.getResources().getString(R.string.dipper_60666);
            case 60671 :
                return context.getResources().getString(R.string.dipper_60671);
            case 60672 :
                return context.getResources().getString(R.string.dipper_60672);
            case 60673 :
                return context.getResources().getString(R.string.dipper_60673);
            case 60674 :
                return context.getResources().getString(R.string.dipper_60674);
            case 60675 :
                return context.getResources().getString(R.string.dipper_60675);
            case 60676 :
                return context.getResources().getString(R.string.dipper_60676);
            case 60677 :
                return context.getResources().getString(R.string.dipper_60677);
            case 60681 :
                return context.getResources().getString(R.string.dipper_60681);
            case 60682 :
                return context.getResources().getString(R.string.dipper_60682);
            case 61001 :
                return context.getResources().getString(R.string.dipper_61001);
            case 61002 :
                return context.getResources().getString(R.string.dipper_61002);
            case 80001 :
                return context.getResources().getString(R.string.dipper_80001);
            case 80002 :
                return context.getResources().getString(R.string.dipper_80002);
            case 80003 :
                return context.getResources().getString(R.string.dipper_80003);
            case 80004 :
                return context.getResources().getString(R.string.dipper_80004);
            case 80005 :
                return context.getResources().getString(R.string.dipper_80005);
            case 80006 :
                return context.getResources().getString(R.string.dipper_80006);
            case 80007 :
                return context.getResources().getString(R.string.dipper_80007);
            case 80008 :
                return context.getResources().getString(R.string.dipper_80008);
            case 80009 :
                return context.getResources().getString(R.string.dipper_80009);
            case 80010 :
                return context.getResources().getString(R.string.dipper_80010);
            case 80011 :
                return context.getResources().getString(R.string.dipper_80011);
            case 81001 :
                return context.getResources().getString(R.string.dipper_81001);
            case 81002 :
                return context.getResources().getString(R.string.dipper_81002);
            case 81003 :
                return context.getResources().getString(R.string.dipper_81003);
            case 81004 :
                return context.getResources().getString(R.string.dipper_81004);
            case 81005 :
                return context.getResources().getString(R.string.dipper_81005);
            case 81006 :
                return context.getResources().getString(R.string.dipper_81006);
            case 81007 :
                return context.getResources().getString(R.string.dipper_81007);
            case 81008 :
                return context.getResources().getString(R.string.dipper_81008);
            case 81009 :
                return context.getResources().getString(R.string.dipper_81009);
            case 81010 :
                return context.getResources().getString(R.string.dipper_81010);
            case 81011 :
                return context.getResources().getString(R.string.dipper_81011);
            case 81012 :
                return context.getResources().getString(R.string.dipper_81012);
            case 81013 :
                return context.getResources().getString(R.string.dipper_81013);
            case 81014 :
                return context.getResources().getString(R.string.dipper_81014);
            case 81015 :
                return context.getResources().getString(R.string.dipper_81015);
            case 81016 :
                return context.getResources().getString(R.string.dipper_81016);
            case 81017 :
                return context.getResources().getString(R.string.dipper_81017);
            case 81018 :
                return context.getResources().getString(R.string.dipper_81018);
            case 81019 :
                return context.getResources().getString(R.string.dipper_81019);
            case 81020 :
                return context.getResources().getString(R.string.dipper_81020);
            case 81021 :
                return context.getResources().getString(R.string.dipper_81021);
            case 81022 :
                return context.getResources().getString(R.string.dipper_81022);
            case 81023 :
                return context.getResources().getString(R.string.dipper_81023);
            case 81024 :
                return context.getResources().getString(R.string.dipper_81024);
            case 81025 :
                return context.getResources().getString(R.string.dipper_81025);
            case 81026 :
                return context.getResources().getString(R.string.dipper_81026);
            case 81027 :
                return context.getResources().getString(R.string.dipper_81027);
            case 81028 :
                return context.getResources().getString(R.string.dipper_81028);
            case 81029 :
                return context.getResources().getString(R.string.dipper_81029);
            case 81030 :
                return context.getResources().getString(R.string.dipper_81030);
            case 90001 :
                return context.getResources().getString(R.string.dipper_90001);
            case 90002 :
                return context.getResources().getString(R.string.dipper_90002);
            case 90003 :
                return context.getResources().getString(R.string.dipper_90003);
            case 90004 :
                return context.getResources().getString(R.string.dipper_90004);
            case 90011 :
                return context.getResources().getString(R.string.dipper_90011);
            case 90012 :
                return context.getResources().getString(R.string.dipper_90012);
            case 90021 :
                return context.getResources().getString(R.string.dipper_90021);
            case 90022 :
                return context.getResources().getString(R.string.dipper_90022);
            case 90023 :
                return context.getResources().getString(R.string.dipper_90023);
            case 90024 :
                return context.getResources().getString(R.string.dipper_90024);
            case 90025 :
                return context.getResources().getString(R.string.dipper_90025);
            case 990001 :
                return context.getResources().getString(R.string.dipper_990001);
            case 990002 :
                return context.getResources().getString(R.string.dipper_990002);
            case 990003 :
                return context.getResources().getString(R.string.dipper_990003);
            case 990004 :
                return context.getResources().getString(R.string.dipper_990004);
            case 990005 :
                return context.getResources().getString(R.string.dipper_990005);
            case 990006 :
                return context.getResources().getString(R.string.dipper_990006);
            case 990007 :
                return context.getResources().getString(R.string.dipper_990007);
            case 990008 :
                return context.getResources().getString(R.string.dipper_990008);
            case 990009 :
                return context.getResources().getString(R.string.dipper_990009);
            case 990010 :
                return context.getResources().getString(R.string.dipper_990010);
            case 990011 :
                return context.getResources().getString(R.string.dipper_990011);
            case 990012 :
                return context.getResources().getString(R.string.dipper_990012);
            case 990013 :
                return context.getResources().getString(R.string.dipper_990013);
            case 990101 :
                return context.getResources().getString(R.string.dipper_990101);
            case 990102 :
                return context.getResources().getString(R.string.dipper_990102);
            case 990103 :
                return context.getResources().getString(R.string.dipper_990103);
            case 990104 :
                return context.getResources().getString(R.string.dipper_990104);
            case 990105 :
                return context.getResources().getString(R.string.dipper_990105);
            case 990106 :
                return context.getResources().getString(R.string.dipper_990106);
            case 990107 :
                return context.getResources().getString(R.string.dipper_990107);
            case 990108 :
                return context.getResources().getString(R.string.dipper_990108);
            case 990109 :
                return context.getResources().getString(R.string.dipper_990109);
            case 990110 :
                return context.getResources().getString(R.string.dipper_990110);
            case 990201 :
                return context.getResources().getString(R.string.dipper_990201);
            case 990202 :
                return context.getResources().getString(R.string.dipper_990202);
            case 990203 :
                return context.getResources().getString(R.string.dipper_990203);
            case 990204 :
                return context.getResources().getString(R.string.dipper_990204);
            case 990205 :
                return context.getResources().getString(R.string.dipper_990205);
            case 990206 :
                return context.getResources().getString(R.string.dipper_990206);
            case 990207 :
                return context.getResources().getString(R.string.dipper_990207);
            case 990208 :
                return context.getResources().getString(R.string.dipper_990208);
            case 990209 :
                return context.getResources().getString(R.string.dipper_990209);
            case 990210 :
                return context.getResources().getString(R.string.dipper_990210);
            case 990301 :
                return context.getResources().getString(R.string.dipper_990301);
            case 990302 :
                return context.getResources().getString(R.string.dipper_990302);
            case 990303 :
                return context.getResources().getString(R.string.dipper_990303);
            case 990304 :
                return context.getResources().getString(R.string.dipper_990304);
            case 990305 :
                return context.getResources().getString(R.string.dipper_990305);
            case 990306 :
                return context.getResources().getString(R.string.dipper_990306);
            case 990307 :
                return context.getResources().getString(R.string.dipper_990307);
            case 990308 :
                return context.getResources().getString(R.string.dipper_990308);
            case 990309 :
                return context.getResources().getString(R.string.dipper_990309);
            case 990310 :
                return context.getResources().getString(R.string.dipper_990310);
            case 990311 :
                return context.getResources().getString(R.string.dipper_990311);
            case 990312 :
                return context.getResources().getString(R.string.dipper_990312);
            case 990313 :
                return context.getResources().getString(R.string.dipper_990313);
            case 990314 :
                return context.getResources().getString(R.string.dipper_990314);
            default:
                return "";
        }
    }

}
