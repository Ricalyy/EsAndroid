package com.esunny.data.api;

public class EsEventConstant {

    public static final int                     S_SRVEVENT_CONNECT            = 0x01; //连接
    public static final int                     S_SRVEVENT_DISCONNECT         = 0x02; //断开
    public static final int                      S_SRVEVENT_CONNECTFAIL      = 0x03;   //接入服务器失败
    public static final int                      S_SRVEVENT_INITFAIL          = 0x04;   //初始化失败
    public static final int                     S_SRVEVENT_QUOTE              = 0x20; //即时行情
    public static final int                     S_SRVEVENT_QUOTELOGIN         = 0x21; //登录行情前置
    public static final int                     S_SRVEVENT_QINITCOMPLETED     = 0x22; //行情初始化完成
    public static final int					  S_SRVEVENT_OPTIONCOMPLETED    = 0x23;	//期权数据初始化完成

    public static final int                     S_SRVEVENT_HISQUOTE           = 0x40; //历史行情
    public static final int                     S_SRVEVENT_HISLOGIN           = 0x41; //登录历史行情
    public static final int                     S_SRVEVENT_HINITCOMPLETED     = 0x42; //历史初始化完成
    public static final int                     S_SRVEVENT_TRADELOGOUT        = 0x51;  //登出交易
    public static final int                     S_SRVEVENT_TRADELOGINED        = 0x52;  //交易登录完成
    public static final int                      S_SRVEVENT_TRADE_LOG          = 0x53;   //交易日志
    public static final int                      S_SRVEVENT_SYNC_DATA_IP    = 0x54;   //同步地址
    public static final int                      S_SRVEVENT_SYNC_DATA_CODE    = 0x55;   //从内存同步码表到数据库
    public static final int                      S_SRVEVENT_SYNC_DATA_CODE_REQ    = 0x56;   //请求码表到内存
    public static final int                      S_SRVEVENT_RESET_PWD      = 0x57;  //允许重置密码
    public static final int                      S_SRVEVENT_RESET_VER_CER  = 0x58;  //身份验证
    public static final int                      S_SRVEVENT_RESET_SEC_CER  = 0x59;  //验证码验证
    public static final int                     S_SRVEVENT_TRADE              = 0x60; //交易
    public static final int                     S_SRVEVENT_TRADELOGIN         = 0x61; //登录交易前置
    public static final int                     S_SRVEVENT_TINITCOMPLETED     = 0x62; //交易初始化完成
    public static final int                     S_SRVEVENT_TRADE_ORDER        = 0x63; //交易委托变化
    public static final int                     S_SRVEVENT_TRADE_MATCH        = 0x64; //交易成交变化
    public static final int                     S_SRVEVENT_TRADE_POSITION     = 0x65; //交易持仓变化
    public static final int                     S_SRVEVENT_TRADE_FUND         = 0x66; //交易资金变化
    public static final int                     S_SRVEVENT_CHG_TRD_PWD        = 0x67; //修改交易密码
    public static final int                     S_SRVEVENT_CHG_FUND_PWD       = 0x68; //修改资金密码
    public static final int                     S_SRVEVENT_QRY_TRANSBANK      = 0x69; //转账银行查询
    public static final int                     S_SRVEVENT_QRY_SIGNBANK       = 0x6A; //签约银行查询
    public static final int                     S_SRVEVENT_QRY_BALANCE        = 0x6B; //账户余额查询
    public static final int                     S_SRVEVENT_BANKTRANSFER       = 0x6C; //银期转账
    public static final int                     S_SRVEVENT_QRY_TRANSFER       = 0x6D; //银期转账流水
    public static final int                     S_SRVEVENT_QRY_BILL           = 0x6E; //结算单查询
    public static final int                     S_SRVEVENT_TRADE_MESSAGE      = 0x6F; //消息变化
    public static final int                     S_SRVEVENT_TRADEDATECHG       =  0x70;//交易日切换
    public static final int                     S_SRVEVENT_TRADESUMPROFITCHG      = 0x71;   //浮盈合计变化通知
    public static final int                     S_SRVEVENT_TRADEPROFITCHG         = 0x72;   //浮盈明细变化通知
    public static final int                     S_SRVEVENT_TRADE_STRATEGY_ORDER   = 0x73;   //策略单
    public static final int                     S_SRVEVENT_SMSAUTH_NOTIFY         = 0x74;   //短消息
    public static final int                      S_SRVEVENT_BILLCONFIRMNOTICE     = 0x75;   //结算单确认通知
    public static final int                      S_SRVEVENT_BILLCONFIRM           = 0x76;   //结算单确认应答
    public static final int                      S_SRVEVENT_NEWSUPDATE            = 0x77;   //新闻更新
    public static final int                      S_SRVEVENT_HISQUOTEMINUTE        = 0x78;   //历史分时行情
    public static final int                      S_SRVEVENT_NEWSTAGUPDATE         = 0x79;   //新闻检索
    public static final int                      S_SRVEVENT_REGLOGIN              = 0x7A;   //登录认证服务器
    public static final int                      S_SRVEVENT_SMSAUTHINFO_RSP       = 0x7B;    //获取认证码 请求应答信息
    public static final int                      S_SRVEVENT_NEWSFTENUPDATE        = 0x7C;   //F10新闻检索
    public static final int                      S_SRVEVENT_NEWSTCREPORT          = 0x7D;   //tc资讯
    public static final int                     S_SRVEVENT_CONTRACTSORT         = 0x7E;   //行情排序
    public static final int                     S_SRVEVENT_TRADE_LOCK_POSITION         = 0x7F;   //交易冻结值变化

    public static final int                      S_SRVEVENT_MONITOR_QRY  = 0x80;   //价格预警查询
    public static final int                      S_SRVEVENT_MONITOR_RTN  = 0x81;   //价格预警回报
    public static final int                      S_SRVEVENT_MONITOR_ACTION = 0x82;   //价格预警下单回报
    public static final int                      S_SRVEVENT_MONITOR_DELETE = 0x83;   //价格预警下单回报

    public static final int                      S_SRVEVENT_ASX_PARAM            = 0x84;   //澳交所系统参数

    public static final int                        S_DATA_EVENT_LOGIN_MALL = 0X0100;
    public static final int                        S_DATA_EVENT_MODIFY_MALL_PASSWORD = 0X0101;
    public static final int                        S_DATA_EVENT_SEARCH_DATA = 0x0110;
    public static final int                        S_DATA_EVENT_CONFIG_DATA = 0x0111;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SEND_FAVORITE_TO_SERVER = 0x01110;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_FAVORITE_FROM_SERVER = 0x01111;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PC_FAVORITE_FROM_SERVER = 0x01112;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_FROM_SERVER = 0x01113;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_SYNC_PHONE_SETTING_TO_SERVER = 0x01114;
    public static final int                        S_DATA_EVENT_CONFIG_DATA_CLEAR_DATA = 0x01115;
}
