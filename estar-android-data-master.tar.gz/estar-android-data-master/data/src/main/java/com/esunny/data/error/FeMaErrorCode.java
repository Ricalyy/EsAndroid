package com.esunny.data.error;

import android.content.Context;

import com.esunny.data.R;


class FeMaErrorCode {

    static String getErrorMessage(Context context, int errorCode) {
        switch (errorCode) {
            case 0 :
                return context.getResources().getString(R.string.fm_0);
            case 1 :
                return context.getResources().getString(R.string.fm_1);
            case 2 :
                return context.getResources().getString(R.string.fm_2);
            case 3 :
                return context.getResources().getString(R.string.fm_3);
            case 4 :
                return context.getResources().getString(R.string.fm_4);
            case 5 :
                return context.getResources().getString(R.string.fm_5);
            case 6 :
                return context.getResources().getString(R.string.fm_6);
            case 7 :
                return context.getResources().getString(R.string.fm_7);
            case 8 :
                return context.getResources().getString(R.string.fm_8);
            case 9 :
                return context.getResources().getString(R.string.fm_9);
            case 10 :
                return context.getResources().getString(R.string.fm_10);
            case 11 :
                return context.getResources().getString(R.string.fm_11);
            case 12 :
                return context.getResources().getString(R.string.fm_12);
            case 13 :
                return context.getResources().getString(R.string.fm_13);
            case 14 :
                return context.getResources().getString(R.string.fm_14);
            case 15 :
                return context.getResources().getString(R.string.fm_15);
            case 16 :
                return context.getResources().getString(R.string.fm_16);
            case 17 :
                return context.getResources().getString(R.string.fm_17);
            case 18 :
                return context.getResources().getString(R.string.fm_18);
            case 19 :
                return context.getResources().getString(R.string.fm_19);
            case 20 :
                return context.getResources().getString(R.string.fm_20);
            case 21 :
                return context.getResources().getString(R.string.fm_21);
            case 22 :
                return context.getResources().getString(R.string.fm_22);
            case 23 :
                return context.getResources().getString(R.string.fm_23);
            case 24 :
                return context.getResources().getString(R.string.fm_24);
            case 25 :
                return context.getResources().getString(R.string.fm_25);
            case 26 :
                return context.getResources().getString(R.string.fm_26);
            case 27 :
                return context.getResources().getString(R.string.fm_27);
            case 28 :
                return context.getResources().getString(R.string.fm_28);
            case 29 :
                return context.getResources().getString(R.string.fm_29);
            case 30 :
                return context.getResources().getString(R.string.fm_30);
            case 31 :
                return context.getResources().getString(R.string.fm_31);
            case 32 :
                return context.getResources().getString(R.string.fm_32);
            case 33 :
                return context.getResources().getString(R.string.fm_33);
            case 34 :
                return context.getResources().getString(R.string.fm_34);
            case 35 :
                return context.getResources().getString(R.string.fm_35);
            case 36 :
                return context.getResources().getString(R.string.fm_36);
            case 37 :
                return context.getResources().getString(R.string.fm_37);
            case 38 :
                return context.getResources().getString(R.string.fm_38);
            case 39 :
                return context.getResources().getString(R.string.fm_39);
            case 40 :
                return context.getResources().getString(R.string.fm_40);
            case 41 :
                return context.getResources().getString(R.string.fm_41);
            case 42 :
                return context.getResources().getString(R.string.fm_42);
            case 43 :
                return context.getResources().getString(R.string.fm_43);
            case 44 :
                return context.getResources().getString(R.string.fm_44);
            case 45 :
                return context.getResources().getString(R.string.fm_45);
            case 46 :
                return context.getResources().getString(R.string.fm_46);
            case 47 :
                return context.getResources().getString(R.string.fm_47);
            case 48 :
                return context.getResources().getString(R.string.fm_48);
            case 49 :
                return context.getResources().getString(R.string.fm_49);
            case 50 :
                return context.getResources().getString(R.string.fm_50);
            case 51 :
                return context.getResources().getString(R.string.fm_51);
            case 52 :
                return context.getResources().getString(R.string.fm_52);
            case 53 :
                return context.getResources().getString(R.string.fm_53);
            case 54 :
                return context.getResources().getString(R.string.fm_54);
            case 55 :
                return context.getResources().getString(R.string.fm_55);
            case 56 :
                return context.getResources().getString(R.string.fm_56);
            case 57 :
                return context.getResources().getString(R.string.fm_57);
            case 58 :
                return context.getResources().getString(R.string.fm_58);
            case 59 :
                return context.getResources().getString(R.string.fm_59);
            case 60 :
                return context.getResources().getString(R.string.fm_60);
            case 61 :
                return context.getResources().getString(R.string.fm_61);
            case 62 :
                return context.getResources().getString(R.string.fm_62);
            case 64 :
                return context.getResources().getString(R.string.fm_64);
            case 65 :
                return context.getResources().getString(R.string.fm_65);
            case 66 :
                return context.getResources().getString(R.string.fm_66);
            case 67 :
                return context.getResources().getString(R.string.fm_67);
            case 68 :
                return context.getResources().getString(R.string.fm_68);
            case 69 :
                return context.getResources().getString(R.string.fm_69);
            case 70 :
                return context.getResources().getString(R.string.fm_70);
            case 71 :
                return context.getResources().getString(R.string.fm_71);
            case 72 :
                return context.getResources().getString(R.string.fm_72);
            case 73 :
                return context.getResources().getString(R.string.fm_73);
            case 74 :
                return context.getResources().getString(R.string.fm_74);
            case 75 :
                return context.getResources().getString(R.string.fm_75);
            case 76 :
                return context.getResources().getString(R.string.fm_76);
            case 77 :
                return context.getResources().getString(R.string.fm_77);
            case 78 :
                return context.getResources().getString(R.string.fm_78);
            case 79 :
                return context.getResources().getString(R.string.fm_79);
            case 80 :
                return context.getResources().getString(R.string.fm_80);
            case 81 :
                return context.getResources().getString(R.string.fm_81);
            case 82 :
                return context.getResources().getString(R.string.fm_82);
            case 83 :
                return context.getResources().getString(R.string.fm_83);
            case 84 :
                return context.getResources().getString(R.string.fm_84);
            case 85 :
                return context.getResources().getString(R.string.fm_85);
            case 86 :
                return context.getResources().getString(R.string.fm_86);
            case 87 :
                return context.getResources().getString(R.string.fm_87);
            case 88 :
                return context.getResources().getString(R.string.fm_88);
            case 89 :
                return context.getResources().getString(R.string.fm_89);
            case 90 :
                return context.getResources().getString(R.string.fm_90);
            case 91 :
                return context.getResources().getString(R.string.fm_91);
            case 92 :
                return context.getResources().getString(R.string.fm_92);
            case 93 :
                return context.getResources().getString(R.string.fm_93);
            case 94 :
                return context.getResources().getString(R.string.fm_94);
            case 95 :
                return context.getResources().getString(R.string.fm_95);
            case 96 :
                return context.getResources().getString(R.string.fm_96);
            case 97 :
                return context.getResources().getString(R.string.fm_97);
            case 98 :
                return context.getResources().getString(R.string.fm_98);
            case 99 :
                return context.getResources().getString(R.string.fm_99);
            case 100 :
                return context.getResources().getString(R.string.fm_100);
            case 101 :
                return context.getResources().getString(R.string.fm_101);
            case 102 :
                return context.getResources().getString(R.string.fm_102);
            case 103 :
                return context.getResources().getString(R.string.fm_103);
            case 104 :
                return context.getResources().getString(R.string.fm_104);
            case 105 :
                return context.getResources().getString(R.string.fm_105);
            case 106 :
                return context.getResources().getString(R.string.fm_106);
            case 107 :
                return context.getResources().getString(R.string.fm_107);
            case 108 :
                return context.getResources().getString(R.string.fm_108);
            case 109 :
                return context.getResources().getString(R.string.fm_109);
            case 110 :
                return context.getResources().getString(R.string.fm_110);
            case 111 :
                return context.getResources().getString(R.string.fm_111);
            case 112 :
                return context.getResources().getString(R.string.fm_112);
            case 113 :
                return context.getResources().getString(R.string.fm_113);
            case 114 :
                return context.getResources().getString(R.string.fm_114);
            case 115 :
                return context.getResources().getString(R.string.fm_115);
            case 116 :
                return context.getResources().getString(R.string.fm_116);
            case 117 :
                return context.getResources().getString(R.string.fm_117);
            case 118 :
                return context.getResources().getString(R.string.fm_118);
            case 119 :
                return context.getResources().getString(R.string.fm_119);
            case 120 :
                return context.getResources().getString(R.string.fm_120);
            case 121 :
                return context.getResources().getString(R.string.fm_121);
            case 122 :
                return context.getResources().getString(R.string.fm_122);
            case 123 :
                return context.getResources().getString(R.string.fm_123);
            case 124 :
                return context.getResources().getString(R.string.fm_124);
            case 125 :
                return context.getResources().getString(R.string.fm_125);
            case 126 :
                return context.getResources().getString(R.string.fm_126);
            case 127 :
                return context.getResources().getString(R.string.fm_127);
            case 128 :
                return context.getResources().getString(R.string.fm_128);
            case 129 :
                return context.getResources().getString(R.string.fm_129);
            case 130 :
                return context.getResources().getString(R.string.fm_130);
            case 131 :
                return context.getResources().getString(R.string.fm_131);
            case 132 :
                return context.getResources().getString(R.string.fm_132);
            case 133 :
                return context.getResources().getString(R.string.fm_133);
            case 134 :
                return context.getResources().getString(R.string.fm_134);
            case 135 :
                return context.getResources().getString(R.string.fm_135);
            case 136 :
                return context.getResources().getString(R.string.fm_136);
            case 137 :
                return context.getResources().getString(R.string.fm_137);
            case 8001 :
                return context.getResources().getString(R.string.fm_8001);
            case 8002 :
                return context.getResources().getString(R.string.fm_8002);
            case 8003 :
                return context.getResources().getString(R.string.fm_8003);
            case 8004 :
                return context.getResources().getString(R.string.fm_8004);
            case 8005 :
                return context.getResources().getString(R.string.fm_8005);
            case 8006 :
                return context.getResources().getString(R.string.fm_8006);
            case 8007 :
                return context.getResources().getString(R.string.fm_8007);
            case 8008 :
                return context.getResources().getString(R.string.fm_8008);
            case 8009 :
                return context.getResources().getString(R.string.fm_8009);
            case 8010 :
                return context.getResources().getString(R.string.fm_8010);
            case 8011 :
                return context.getResources().getString(R.string.fm_8011);
            case 8012 :
                return context.getResources().getString(R.string.fm_8012);
            case 8013 :
                return context.getResources().getString(R.string.fm_8013);
            case 8014 :
                return context.getResources().getString(R.string.fm_8014);
            case 8015 :
                return context.getResources().getString(R.string.fm_8015);
            case 8016 :
                return context.getResources().getString(R.string.fm_8016);
            case 8017 :
                return context.getResources().getString(R.string.fm_8017);
            case 8018 :
                return context.getResources().getString(R.string.fm_8018);
            case 8019 :
                return context.getResources().getString(R.string.fm_8019);
            case 8020 :
                return context.getResources().getString(R.string.fm_8020);
            case 8021 :
                return context.getResources().getString(R.string.fm_8021);
            case 8022 :
                return context.getResources().getString(R.string.fm_8022);
            case 8023 :
                return context.getResources().getString(R.string.fm_8023);
            case 8024 :
                return context.getResources().getString(R.string.fm_8024);
            case 8025 :
                return context.getResources().getString(R.string.fm_8025);
            case 8026 :
                return context.getResources().getString(R.string.fm_8026);
            case 8027 :
                return context.getResources().getString(R.string.fm_8027);
            case 8028 :
                return context.getResources().getString(R.string.fm_8028);
            case 8029 :
                return context.getResources().getString(R.string.fm_8029);
            case 8030 :
                return context.getResources().getString(R.string.fm_8030);
            case 8031 :
                return context.getResources().getString(R.string.fm_8031);
            case 8032 :
                return context.getResources().getString(R.string.fm_8032);
            case 8033 :
                return context.getResources().getString(R.string.fm_8033);
            case 8034 :
                return context.getResources().getString(R.string.fm_8034);
            case 8100 :
                return context.getResources().getString(R.string.fm_8100);
            case 8101 :
                return context.getResources().getString(R.string.fm_8101);
            case 8102 :
                return context.getResources().getString(R.string.fm_8102);
            case 8103 :
                return context.getResources().getString(R.string.fm_8103);
            case 8104 :
                return context.getResources().getString(R.string.fm_8104);
            case 8105 :
                return context.getResources().getString(R.string.fm_8105);
            case 8106 :
                return context.getResources().getString(R.string.fm_8106);
            case 8107 :
                return context.getResources().getString(R.string.fm_8107);
            case 8108 :
                return context.getResources().getString(R.string.fm_8108);
            case 8109 :
                return context.getResources().getString(R.string.fm_8109);
            case 8110 :
                return context.getResources().getString(R.string.fm_8110);
            case 8111 :
                return context.getResources().getString(R.string.fm_8111);
            case 8112 :
                return context.getResources().getString(R.string.fm_8112);
            case 8113 :
                return context.getResources().getString(R.string.fm_8113);
            case 8114 :
                return context.getResources().getString(R.string.fm_8114);
            case 8115 :
                return context.getResources().getString(R.string.fm_8115);
            case 8116 :
                return context.getResources().getString(R.string.fm_8116);
            case 8117 :
                return context.getResources().getString(R.string.fm_8117);
            case 8118 :
                return context.getResources().getString(R.string.fm_8118);
            case 8119 :
                return context.getResources().getString(R.string.fm_8119);
            case 8120 :
                return context.getResources().getString(R.string.fm_8120);
            case 8121 :
                return context.getResources().getString(R.string.fm_8121);
            case 8122 :
                return context.getResources().getString(R.string.fm_8122);
            case 8123 :
                return context.getResources().getString(R.string.fm_8123);
            case 8124 :
                return context.getResources().getString(R.string.fm_8124);
            case 8125 :
                return context.getResources().getString(R.string.fm_8125);
            case 8126 :
                return context.getResources().getString(R.string.fm_8126);
            case 8127 :
                return context.getResources().getString(R.string.fm_8127);
            case 8128 :
                return context.getResources().getString(R.string.fm_8128);
            case 8129 :
                return context.getResources().getString(R.string.fm_8129);
            case 8130 :
                return context.getResources().getString(R.string.fm_8130);
            case 8131 :
                return context.getResources().getString(R.string.fm_8131);
            case 8132 :
                return context.getResources().getString(R.string.fm_8132);
            case 8133 :
                return context.getResources().getString(R.string.fm_8133);
            case 8134 :
                return context.getResources().getString(R.string.fm_8134);
            case 8135 :
                return context.getResources().getString(R.string.fm_8135);
            case 8136 :
                return context.getResources().getString(R.string.fm_8136);
            case 8137 :
                return context.getResources().getString(R.string.fm_8137);
            case 8138 :
                return context.getResources().getString(R.string.fm_8138);
            case 8139 :
                return context.getResources().getString(R.string.fm_8139);
            case 8140 :
                return context.getResources().getString(R.string.fm_8140);
            case 8200 :
                return context.getResources().getString(R.string.fm_8200);
            case 8201 :
                return context.getResources().getString(R.string.fm_8201);
            case 8202 :
                return context.getResources().getString(R.string.fm_8202);
            case 8203 :
                return context.getResources().getString(R.string.fm_8203);
            case 8204 :
                return context.getResources().getString(R.string.fm_8204);
            case 8205 :
                return context.getResources().getString(R.string.fm_8205);
            case 8206 :
                return context.getResources().getString(R.string.fm_8206);
            case 8207 :
                return context.getResources().getString(R.string.fm_8207);
            case 8208 :
                return context.getResources().getString(R.string.fm_8208);
            case 8209 :
                return context.getResources().getString(R.string.fm_8209);
            case 8210 :
                return context.getResources().getString(R.string.fm_8210);
            case 8211 :
                return context.getResources().getString(R.string.fm_8211);
            case 8212 :
                return context.getResources().getString(R.string.fm_8212);
            case 8213 :
                return context.getResources().getString(R.string.fm_8213);
            case 8214 :
                return context.getResources().getString(R.string.fm_8214);
            case 8215 :
                return context.getResources().getString(R.string.fm_8215);
            case 8216 :
                return context.getResources().getString(R.string.fm_8216);
            case 8217 :
                return context.getResources().getString(R.string.fm_8217);
            case 8218 :
                return context.getResources().getString(R.string.fm_8218);
            case 8219 :
                return context.getResources().getString(R.string.fm_8219);
            case 8220 :
                return context.getResources().getString(R.string.fm_8220);
            case 8221 :
                return context.getResources().getString(R.string.fm_8221);
            case 8222 :
                return context.getResources().getString(R.string.fm_8222);
            case 8223 :
                return context.getResources().getString(R.string.fm_8223);
            case 8224 :
                return context.getResources().getString(R.string.fm_8224);
            case 8230 :
                return context.getResources().getString(R.string.fm_8230);
            case 8231 :
                return context.getResources().getString(R.string.fm_8231);
            case 8232 :
                return context.getResources().getString(R.string.fm_8232);
            case 8233 :
                return context.getResources().getString(R.string.fm_8233);
            case 8234 :
                return context.getResources().getString(R.string.fm_8234);
            case 8235 :
                return context.getResources().getString(R.string.fm_8235);
            case 8236 :
                return context.getResources().getString(R.string.fm_8236);
            case 8237 :
                return context.getResources().getString(R.string.fm_8237);
            case 8238 :
                return context.getResources().getString(R.string.fm_8238);
            case 8239 :
                return context.getResources().getString(R.string.fm_8239);
            case 8240 :
                return context.getResources().getString(R.string.fm_8240);
            case 8241 :
                return context.getResources().getString(R.string.fm_8241);
            case 8242 :
                return context.getResources().getString(R.string.fm_8242);
            case 8243 :
                return context.getResources().getString(R.string.fm_8243);
            case 8244 :
                return context.getResources().getString(R.string.fm_8244);
            case 8300 :
                return context.getResources().getString(R.string.fm_8300);
            case 8301 :
                return context.getResources().getString(R.string.fm_8301);
            case 8321 :
                return context.getResources().getString(R.string.fm_8321);
            case 8322 :
                return context.getResources().getString(R.string.fm_8322);
            case 8323 :
                return context.getResources().getString(R.string.fm_8323);
            case 8324 :
                return context.getResources().getString(R.string.fm_8324);
            case 8325 :
                return context.getResources().getString(R.string.fm_8325);
            case 8326 :
                return context.getResources().getString(R.string.fm_8326);
            case 8327 :
                return context.getResources().getString(R.string.fm_8327);
            case 8328 :
                return context.getResources().getString(R.string.fm_8328);
            case 8329 :
                return context.getResources().getString(R.string.fm_8329);
            case 8330 :
                return context.getResources().getString(R.string.fm_8330);
            case 8331 :
                return context.getResources().getString(R.string.fm_8331);
            case 8332 :
                return context.getResources().getString(R.string.fm_8332);
            case 8333 :
                return context.getResources().getString(R.string.fm_8333);
            case 8334 :
                return context.getResources().getString(R.string.fm_8334);
            case 8335 :
                return context.getResources().getString(R.string.fm_8335);
            case 8380 :
                return context.getResources().getString(R.string.fm_8380);
            case 8381 :
                return context.getResources().getString(R.string.fm_8381);
            case 8382 :
                return context.getResources().getString(R.string.fm_8382);
            case 8383 :
                return context.getResources().getString(R.string.fm_8383);
            case 8390 :
                return context.getResources().getString(R.string.fm_8390);
            case 8391 :
                return context.getResources().getString(R.string.fm_8391);
            case 8392 :
                return context.getResources().getString(R.string.fm_8392);
            case 8400 :
                return context.getResources().getString(R.string.fm_8400);
            case 8401 :
                return context.getResources().getString(R.string.fm_8401);
            case 8402 :
                return context.getResources().getString(R.string.fm_8402);
            case 8403 :
                return context.getResources().getString(R.string.fm_8403);
            case 8404 :
                return context.getResources().getString(R.string.fm_8404);
            case 8405 :
                return context.getResources().getString(R.string.fm_8405);
            case 8406 :
                return context.getResources().getString(R.string.fm_8406);
            case 8407 :
                return context.getResources().getString(R.string.fm_8407);
            case 8408 :
                return context.getResources().getString(R.string.fm_8408);
            case 8409 :
                return context.getResources().getString(R.string.fm_8409);
            case 8420 :
                return context.getResources().getString(R.string.fm_8420);
            case 8421 :
                return context.getResources().getString(R.string.fm_8421);
            case 8422 :
                return context.getResources().getString(R.string.fm_8422);
            case 8423 :
                return context.getResources().getString(R.string.fm_8423);
            case 8424 :
                return context.getResources().getString(R.string.fm_8424);
            case 8425 :
                return context.getResources().getString(R.string.fm_8425);
            case 8426 :
                return context.getResources().getString(R.string.fm_8426);
            case 8427 :
                return context.getResources().getString(R.string.fm_8427);
            case 8428 :
                return context.getResources().getString(R.string.fm_8428);
            case 8429 :
                return context.getResources().getString(R.string.fm_8429);
            case 8430 :
                return context.getResources().getString(R.string.fm_8430);
            case 8431 :
                return context.getResources().getString(R.string.fm_8431);
            case 8432 :
                return context.getResources().getString(R.string.fm_8432);
            case 8433 :
                return context.getResources().getString(R.string.fm_8433);
            case 8434 :
                return context.getResources().getString(R.string.fm_8434);
            case 8435 :
                return context.getResources().getString(R.string.fm_8435);
            case 8436 :
                return context.getResources().getString(R.string.fm_8436);
            case 8437 :
                return context.getResources().getString(R.string.fm_8437);
            case 8438 :
                return context.getResources().getString(R.string.fm_8438);
            case 8439 :
                return context.getResources().getString(R.string.fm_8439);
            case 8440 :
                return context.getResources().getString(R.string.fm_8440);
            case 8441 :
                return context.getResources().getString(R.string.fm_8441);
            case 8442 :
                return context.getResources().getString(R.string.fm_8442);
            case 8443 :
                return context.getResources().getString(R.string.fm_8443);
            case 8444 :
                return context.getResources().getString(R.string.fm_8444);
            case 8445 :
                return context.getResources().getString(R.string.fm_8445);
            case 8446 :
                return context.getResources().getString(R.string.fm_8446);
            case 8447 :
                return context.getResources().getString(R.string.fm_8447);
            case 8448 :
                return context.getResources().getString(R.string.fm_8448);
            case 8449 :
                return context.getResources().getString(R.string.fm_8449);
            case 8452 :
                return context.getResources().getString(R.string.fm_8452);
            case 8453 :
                return context.getResources().getString(R.string.fm_8453);
            case 8454 :
                return context.getResources().getString(R.string.fm_8454);
            case 8455 :
                return context.getResources().getString(R.string.fm_8455);
            case 8456 :
                return context.getResources().getString(R.string.fm_8456);
            case 8457 :
                return context.getResources().getString(R.string.fm_8457);
            case 8458 :
                return context.getResources().getString(R.string.fm_8458);
            case 8459 :
                return context.getResources().getString(R.string.fm_8459);
            case 8460 :
                return context.getResources().getString(R.string.fm_8460);
            case 8461 :
                return context.getResources().getString(R.string.fm_8461);
            case 8462 :
                return context.getResources().getString(R.string.fm_8462);
            case 8463 :
                return context.getResources().getString(R.string.fm_8463);
            case 8464 :
                return context.getResources().getString(R.string.fm_8464);
            case 8465 :
                return context.getResources().getString(R.string.fm_8465);
            case 8466 :
                return context.getResources().getString(R.string.fm_8466);
            case 8467 :
                return context.getResources().getString(R.string.fm_8467);
            case 8468 :
                return context.getResources().getString(R.string.fm_8468);
            case 8469 :
                return context.getResources().getString(R.string.fm_8469);
            case 8470 :
                return context.getResources().getString(R.string.fm_8470);
            case 8471 :
                return context.getResources().getString(R.string.fm_8471);
            case 8472 :
                return context.getResources().getString(R.string.fm_8472);
            case 8473 :
                return context.getResources().getString(R.string.fm_8473);
            case 8474 :
                return context.getResources().getString(R.string.fm_8474);
            case 8475 :
                return context.getResources().getString(R.string.fm_8475);
            case 8476 :
                return context.getResources().getString(R.string.fm_8476);
            case 8477 :
                return context.getResources().getString(R.string.fm_8477);
            case 8478 :
                return context.getResources().getString(R.string.fm_8478);
            case 8479 :
                return context.getResources().getString(R.string.fm_8479);
            case 8480 :
                return context.getResources().getString(R.string.fm_8480);
            case 8481 :
                return context.getResources().getString(R.string.fm_8481);
            case 8482 :
                return context.getResources().getString(R.string.fm_8482);
            case 8483 :
                return context.getResources().getString(R.string.fm_8483);
            case 8484 :
                return context.getResources().getString(R.string.fm_8484);
            case 8485 :
                return context.getResources().getString(R.string.fm_8485);
            case 8486 :
                return context.getResources().getString(R.string.fm_8486);
            case 8487 :
                return context.getResources().getString(R.string.fm_8487);
            case 8488 :
                return context.getResources().getString(R.string.fm_8488);
            case 8489 :
                return context.getResources().getString(R.string.fm_8489);
            case 8490 :
                return context.getResources().getString(R.string.fm_8490);
            case 8491 :
                return context.getResources().getString(R.string.fm_8491);
            case 8492 :
                return context.getResources().getString(R.string.fm_8492);
            case 8493 :
                return context.getResources().getString(R.string.fm_8493);
            case 8494 :
                return context.getResources().getString(R.string.fm_8494);
            case 8495 :
                return context.getResources().getString(R.string.fm_8495);
            case 8496 :
                return context.getResources().getString(R.string.fm_8496);
            case 8497 :
                return context.getResources().getString(R.string.fm_8497);
            case 8598 :
                return context.getResources().getString(R.string.fm_8598);
            case 8599 :
                return context.getResources().getString(R.string.fm_8599);
            case 8600 :
                return context.getResources().getString(R.string.fm_8600);
            case 8601 :
                return context.getResources().getString(R.string.fm_8601);
            case 8602 :
                return context.getResources().getString(R.string.fm_8602);
            case 8603 :
                return context.getResources().getString(R.string.fm_8603);
            case 8604 :
                return context.getResources().getString(R.string.fm_8604);
            case 8605 :
                return context.getResources().getString(R.string.fm_8605);
            case 8606 :
                return context.getResources().getString(R.string.fm_8606);
            case 8607 :
                return context.getResources().getString(R.string.fm_8607);
            case 8608 :
                return context.getResources().getString(R.string.fm_8608);
            case 8609 :
                return context.getResources().getString(R.string.fm_8609);
            case 8610 :
                return context.getResources().getString(R.string.fm_8610);
            case 8611 :
                return context.getResources().getString(R.string.fm_8611);
            case 8612 :
                return context.getResources().getString(R.string.fm_8612);
            case 8613 :
                return context.getResources().getString(R.string.fm_8613);
            case 8614 :
                return context.getResources().getString(R.string.fm_8614);
            case 8615 :
                return context.getResources().getString(R.string.fm_8615);
            case 8616 :
                return context.getResources().getString(R.string.fm_8616);
            case 8617 :
                return context.getResources().getString(R.string.fm_8617);
            case 8618 :
                return context.getResources().getString(R.string.fm_8618);
            case 8619 :
                return context.getResources().getString(R.string.fm_8619);
            case 8620 :
                return context.getResources().getString(R.string.fm_8620);
            case 8621 :
                return context.getResources().getString(R.string.fm_8621);
            case 8622 :
                return context.getResources().getString(R.string.fm_8622);
            case 8623 :
                return context.getResources().getString(R.string.fm_8623);
            case 8624 :
                return context.getResources().getString(R.string.fm_8624);
            case 8625 :
                return context.getResources().getString(R.string.fm_8625);
            case 8626 :
                return context.getResources().getString(R.string.fm_8626);
            case 8450 :
                return context.getResources().getString(R.string.fm_8450);
            case 8451 :
                return context.getResources().getString(R.string.fm_8451);
            case 8500 :
                return context.getResources().getString(R.string.fm_8500);
            case 8501 :
                return context.getResources().getString(R.string.fm_8501);
            case 8502 :
                return context.getResources().getString(R.string.fm_8502);
            case 8503 :
                return context.getResources().getString(R.string.fm_8503);
            case 8504 :
                return context.getResources().getString(R.string.fm_8504);
            case 10000 :
                return context.getResources().getString(R.string.fm_10000);
            case 10001 :
                return context.getResources().getString(R.string.fm_10001);
            case 10002 :
                return context.getResources().getString(R.string.fm_10002);
            case 10003 :
                return context.getResources().getString(R.string.fm_10003);
            case 10004 :
                return context.getResources().getString(R.string.fm_10004);
            case 10005 :
                return context.getResources().getString(R.string.fm_10005);
            case 10006 :
                return context.getResources().getString(R.string.fm_10006);
            case 10007 :
                return context.getResources().getString(R.string.fm_10007);
            case 10008 :
                return context.getResources().getString(R.string.fm_10008);
            case 10009 :
                return context.getResources().getString(R.string.fm_10009);
            case 10010 :
                return context.getResources().getString(R.string.fm_10010);
            case 10011 :
                return context.getResources().getString(R.string.fm_10011);
            case 10012 :
                return context.getResources().getString(R.string.fm_10012);
            case 10013 :
                return context.getResources().getString(R.string.fm_10013);
            case 10014 :
                return context.getResources().getString(R.string.fm_10014);
            case 10015 :
                return context.getResources().getString(R.string.fm_10015);
            case 10016 :
                return context.getResources().getString(R.string.fm_10016);
            case 10017 :
                return context.getResources().getString(R.string.fm_10017);
            case 10018 :
                return context.getResources().getString(R.string.fm_10018);
            case 10019 :
                return context.getResources().getString(R.string.fm_10019);
            case 10020 :
                return context.getResources().getString(R.string.fm_10020);
            case 10021 :
                return context.getResources().getString(R.string.fm_10021);
            case 10022 :
                return context.getResources().getString(R.string.fm_10022);
            case 10023 :
                return context.getResources().getString(R.string.fm_10023);
            case 10024 :
                return context.getResources().getString(R.string.fm_10024);
            case 10025 :
                return context.getResources().getString(R.string.fm_10025);
            case 10026 :
                return context.getResources().getString(R.string.fm_10026);
            case 10027 :
                return context.getResources().getString(R.string.fm_10027);
            case 10028 :
                return context.getResources().getString(R.string.fm_10028);
            case 10035 :
                return context.getResources().getString(R.string.fm_10035);
            case 10036 :
                return context.getResources().getString(R.string.fm_10036);
            case 10040 :
                return context.getResources().getString(R.string.fm_10040);
            case 10041 :
                return context.getResources().getString(R.string.fm_10041);
            case 10042 :
                return context.getResources().getString(R.string.fm_10042);
            case 10043 :
                return context.getResources().getString(R.string.fm_10043);
            case 15000 :
                return context.getResources().getString(R.string.fm_15000);
            case 16001 :
                return context.getResources().getString(R.string.fm_16001);
            case 16002 :
                return context.getResources().getString(R.string.fm_16002);
            case 16003 :
                return context.getResources().getString(R.string.fm_16003);
            case 16004 :
                return context.getResources().getString(R.string.fm_16004);
            case 16005 :
                return context.getResources().getString(R.string.fm_16005);
            case 16006 :
                return context.getResources().getString(R.string.fm_16006);
            case 16007 :
                return context.getResources().getString(R.string.fm_16007);
            case 16008 :
                return context.getResources().getString(R.string.fm_16008);
            case 16009 :
                return context.getResources().getString(R.string.fm_16009);
            case 16010 :
                return context.getResources().getString(R.string.fm_16010);
            case 16011 :
                return context.getResources().getString(R.string.fm_16011);
            case 16012 :
                return context.getResources().getString(R.string.fm_16012);
            case 16013 :
                return context.getResources().getString(R.string.fm_16013);
            case 16014 :
                return context.getResources().getString(R.string.fm_16014);
            case 16015 :
                return context.getResources().getString(R.string.fm_16015);
            case 16016 :
                return context.getResources().getString(R.string.fm_16016);
            case 16017 :
                return context.getResources().getString(R.string.fm_16017);
            case 16018 :
                return context.getResources().getString(R.string.fm_16018);
            case 16019 :
                return context.getResources().getString(R.string.fm_16019);
            case 16020 :
                return context.getResources().getString(R.string.fm_16020);
            case 16021 :
                return context.getResources().getString(R.string.fm_16021);
            case 16022 :
                return context.getResources().getString(R.string.fm_16022);
            case 16024 :
                return context.getResources().getString(R.string.fm_16024);
            case 16025 :
                return context.getResources().getString(R.string.fm_16025);
            case 16026 :
                return context.getResources().getString(R.string.fm_16026);
            case 16028 :
                return context.getResources().getString(R.string.fm_16028);
            case 16032 :
                return context.getResources().getString(R.string.fm_16032);
            case 16033 :
                return context.getResources().getString(R.string.fm_16033);
            case 16034 :
                return context.getResources().getString(R.string.fm_16034);
            case 16037 :
                return context.getResources().getString(R.string.fm_16037);
            case 16038 :
                return context.getResources().getString(R.string.fm_16038);
            case 16039 :
                return context.getResources().getString(R.string.fm_16039);
            case 16040 :
                return context.getResources().getString(R.string.fm_16040);
            case 16041 :
                return context.getResources().getString(R.string.fm_16041);
            case 16043 :
                return context.getResources().getString(R.string.fm_16043);
            case 16044 :
                return context.getResources().getString(R.string.fm_16044);
            case 16052 :
                return context.getResources().getString(R.string.fm_16052);
            case 17001 :
                return context.getResources().getString(R.string.fm_17001);
            case 17002 :
                return context.getResources().getString(R.string.fm_17002);
            case 17004 :
                return context.getResources().getString(R.string.fm_17004);
            case 17005 :
                return context.getResources().getString(R.string.fm_17005);
            case 17006 :
                return context.getResources().getString(R.string.fm_17006);
            case 17007 :
                return context.getResources().getString(R.string.fm_17007);
            case 17008 :
                return context.getResources().getString(R.string.fm_17008);
            case 17009 :
                return context.getResources().getString(R.string.fm_17009);
            case 17010 :
                return context.getResources().getString(R.string.fm_17010);
            case 17011 :
                return context.getResources().getString(R.string.fm_17011);
            case 17012 :
                return context.getResources().getString(R.string.fm_17012);
            case 17013 :
                return context.getResources().getString(R.string.fm_17013);
            case 17014 :
                return context.getResources().getString(R.string.fm_17014);
            case 17015 :
                return context.getResources().getString(R.string.fm_17015);
            case 17016 :
                return context.getResources().getString(R.string.fm_17016);
            case 17018 :
                return context.getResources().getString(R.string.fm_17018);
            case 17019 :
                return context.getResources().getString(R.string.fm_17019);
            case 17020 :
                return context.getResources().getString(R.string.fm_17020);
            case 17021 :
                return context.getResources().getString(R.string.fm_17021);
            case 17024 :
                return context.getResources().getString(R.string.fm_17024);
            case 17025 :
                return context.getResources().getString(R.string.fm_17025);
            case 17026 :
                return context.getResources().getString(R.string.fm_17026);
            case 17027 :
                return context.getResources().getString(R.string.fm_17027);
            case 17028 :
                return context.getResources().getString(R.string.fm_17028);
            case 17031 :
                return context.getResources().getString(R.string.fm_17031);
            case 17032 :
                return context.getResources().getString(R.string.fm_17032);
            case 17034 :
                return context.getResources().getString(R.string.fm_17034);
            case 17038 :
                return context.getResources().getString(R.string.fm_17038);
            case 17041 :
                return context.getResources().getString(R.string.fm_17041);
            case 17042 :
                return context.getResources().getString(R.string.fm_17042);
            case 17047 :
                return context.getResources().getString(R.string.fm_17047);
            case 18001 :
                return context.getResources().getString(R.string.fm_18001);
            case 18002 :
                return context.getResources().getString(R.string.fm_18002);
            case 18003 :
                return context.getResources().getString(R.string.fm_18003);
            case 18006 :
                return context.getResources().getString(R.string.fm_18006);
            case 18007 :
                return context.getResources().getString(R.string.fm_18007);
            case 18011 :
                return context.getResources().getString(R.string.fm_18011);
            case 18013 :
                return context.getResources().getString(R.string.fm_18013);
            case 18052 :
                return context.getResources().getString(R.string.fm_18052);
            case 18053 :
                return context.getResources().getString(R.string.fm_18053);
            case 18054 :
                return context.getResources().getString(R.string.fm_18054);
            case 18091 :
                return context.getResources().getString(R.string.fm_18091);
            case 18092 :
                return context.getResources().getString(R.string.fm_18092);
            case 18093 :
                return context.getResources().getString(R.string.fm_18093);
            case 20001 :
                return context.getResources().getString(R.string.fm_20001);
            case 20002 :
                return context.getResources().getString(R.string.fm_20002);
            case 20003 :
                return context.getResources().getString(R.string.fm_20003);
            case 20004 :
                return context.getResources().getString(R.string.fm_20004);
            case 20005 :
                return context.getResources().getString(R.string.fm_20005);
            case 20006 :
                return context.getResources().getString(R.string.fm_20006);
            case 20007 :
                return context.getResources().getString(R.string.fm_20007);
            case 20008 :
                return context.getResources().getString(R.string.fm_20008);
            case 20010 :
                return context.getResources().getString(R.string.fm_20010);
            case 20011 :
                return context.getResources().getString(R.string.fm_20011);
            case 20012 :
                return context.getResources().getString(R.string.fm_20012);
            case 20013 :
                return context.getResources().getString(R.string.fm_20013);
            case 20014 :
                return context.getResources().getString(R.string.fm_20014);
            case 20015 :
                return context.getResources().getString(R.string.fm_20015);
            case 20016 :
                return context.getResources().getString(R.string.fm_20016);
            case 20017 :
                return context.getResources().getString(R.string.fm_20017);
            case 20018 :
                return context.getResources().getString(R.string.fm_20018);
            case 20019 :
                return context.getResources().getString(R.string.fm_20019);
            case 20020 :
                return context.getResources().getString(R.string.fm_20020);
            case 20021 :
                return context.getResources().getString(R.string.fm_20021);
            case 20026 :
                return context.getResources().getString(R.string.fm_20026);
            case 20028 :
                return context.getResources().getString(R.string.fm_20028);
            case 20029 :
                return context.getResources().getString(R.string.fm_20029);
            case 20030 :
                return context.getResources().getString(R.string.fm_20030);
            case 20031 :
                return context.getResources().getString(R.string.fm_20031);
            case 20032 :
                return context.getResources().getString(R.string.fm_20032);
            case 20201 :
                return context.getResources().getString(R.string.fm_20201);
            case 20202 :
                return context.getResources().getString(R.string.fm_20202);
            case 20203 :
                return context.getResources().getString(R.string.fm_20203);
            case 20205 :
                return context.getResources().getString(R.string.fm_20205);
            case 20206 :
                return context.getResources().getString(R.string.fm_20206);
            case 20208 :
                return context.getResources().getString(R.string.fm_20208);
            case 20214 :
                return context.getResources().getString(R.string.fm_20214);
            case 20215 :
                return context.getResources().getString(R.string.fm_20215);
            case 20216 :
                return context.getResources().getString(R.string.fm_20216);
            case 20217 :
                return context.getResources().getString(R.string.fm_20217);
            case 20218 :
                return context.getResources().getString(R.string.fm_20218);
            case 20219 :
                return context.getResources().getString(R.string.fm_20219);
            case 20220 :
                return context.getResources().getString(R.string.fm_20220);
            case 20229 :
                return context.getResources().getString(R.string.fm_20229);
            case 20230 :
                return context.getResources().getString(R.string.fm_20230);
            case 20231 :
                return context.getResources().getString(R.string.fm_20231);
            case 20232 :
                return context.getResources().getString(R.string.fm_20232);
            case 20221 :
                return context.getResources().getString(R.string.fm_20221);
            case 20226 :
                return context.getResources().getString(R.string.fm_20226);
            case 20227 :
                return context.getResources().getString(R.string.fm_20227);
            case 20224 :
                return context.getResources().getString(R.string.fm_20224);
            case 20225 :
                return context.getResources().getString(R.string.fm_20225);
            case 20233 :
                return context.getResources().getString(R.string.fm_20233);
            case 20234 :
                return context.getResources().getString(R.string.fm_20234);
            case 20235 :
                return context.getResources().getString(R.string.fm_20235);
            case 20236 :
                return context.getResources().getString(R.string.fm_20236);
            case 20237 :
                return context.getResources().getString(R.string.fm_20237);
            case 20301 :
                return context.getResources().getString(R.string.fm_20301);
            case 20302 :
                return context.getResources().getString(R.string.fm_20302);
            case 20303 :
                return context.getResources().getString(R.string.fm_20303);
            case 20304 :
                return context.getResources().getString(R.string.fm_20304);
            case 20305 :
                return context.getResources().getString(R.string.fm_20305);
            case 20306 :
                return context.getResources().getString(R.string.fm_20306);
            case 20307 :
                return context.getResources().getString(R.string.fm_20307);
            case 20308 :
                return context.getResources().getString(R.string.fm_20308);
            case 20309 :
                return context.getResources().getString(R.string.fm_20309);
            case 20310 :
                return context.getResources().getString(R.string.fm_20310);
            case 20311 :
                return context.getResources().getString(R.string.fm_20311);
            case 20312 :
                return context.getResources().getString(R.string.fm_20312);
            case 20313 :
                return context.getResources().getString(R.string.fm_20313);
            case 20314 :
                return context.getResources().getString(R.string.fm_20314);
            case 20315 :
                return context.getResources().getString(R.string.fm_20315);
            case 20316 :
                return context.getResources().getString(R.string.fm_20316);
            case 20317 :
                return context.getResources().getString(R.string.fm_20317);
            case 20318 :
                return context.getResources().getString(R.string.fm_20318);
            case 20319 :
                return context.getResources().getString(R.string.fm_20319);
            case 20320 :
                return context.getResources().getString(R.string.fm_20320);
            case 20321 :
                return context.getResources().getString(R.string.fm_20321);
            case 20322 :
                return context.getResources().getString(R.string.fm_20322);
            case 20323 :
                return context.getResources().getString(R.string.fm_20323);
            case 20401 :
                return context.getResources().getString(R.string.fm_20401);
            case 20402 :
                return context.getResources().getString(R.string.fm_20402);
            case 20403 :
                return context.getResources().getString(R.string.fm_20403);
            case 20404 :
                return context.getResources().getString(R.string.fm_20404);
            case 20405 :
                return context.getResources().getString(R.string.fm_20405);
            case 20406 :
                return context.getResources().getString(R.string.fm_20406);
            case 20407 :
                return context.getResources().getString(R.string.fm_20407);
            case 20408 :
                return context.getResources().getString(R.string.fm_20408);
            case 20409 :
                return context.getResources().getString(R.string.fm_20409);
            case 20410 :
                return context.getResources().getString(R.string.fm_20410);
            case 20411 :
                return context.getResources().getString(R.string.fm_20411);
            case 20412 :
                return context.getResources().getString(R.string.fm_20412);
            case 20413 :
                return context.getResources().getString(R.string.fm_20413);
            case 24000 :
                return context.getResources().getString(R.string.fm_24000);
            case 24001 :
                return context.getResources().getString(R.string.fm_24001);
            case 24002 :
                return context.getResources().getString(R.string.fm_24002);
            case 24003 :
                return context.getResources().getString(R.string.fm_24003);
            case 24004 :
                return context.getResources().getString(R.string.fm_24004);
            case 24005 :
                return context.getResources().getString(R.string.fm_24005);
            case 24006 :
                return context.getResources().getString(R.string.fm_24006);
            case 24010 :
                return context.getResources().getString(R.string.fm_24010);
            case 24011 :
                return context.getResources().getString(R.string.fm_24011);
            case 24012 :
                return context.getResources().getString(R.string.fm_24012);
            case 24013 :
                return context.getResources().getString(R.string.fm_24013);
            case 24014 :
                return context.getResources().getString(R.string.fm_24014);
            case 24015 :
                return context.getResources().getString(R.string.fm_24015);
            case 24016 :
                return context.getResources().getString(R.string.fm_24016);
            case 24017 :
                return context.getResources().getString(R.string.fm_24017);
            case 24018 :
                return context.getResources().getString(R.string.fm_24018);
            case 24019 :
                return context.getResources().getString(R.string.fm_24019);
            case 24020 :
                return context.getResources().getString(R.string.fm_24020);
            case 24021 :
                return context.getResources().getString(R.string.fm_24021);
            case 24022 :
                return context.getResources().getString(R.string.fm_24022);
            case 24023 :
                return context.getResources().getString(R.string.fm_24023);
            case 24024 :
                return context.getResources().getString(R.string.fm_24024);
            case 24025 :
                return context.getResources().getString(R.string.fm_24025);
            case 24026 :
                return context.getResources().getString(R.string.fm_24026);
            case 24027 :
                return context.getResources().getString(R.string.fm_24027);
            case 24028 :
                return context.getResources().getString(R.string.fm_24028);
            case 24029 :
                return context.getResources().getString(R.string.fm_24029);
            case 24030 :
                return context.getResources().getString(R.string.fm_24030);
            case 24031 :
                return context.getResources().getString(R.string.fm_24031);
            case 24032 :
                return context.getResources().getString(R.string.fm_24032);
            case 24033 :
                return context.getResources().getString(R.string.fm_24033);
            case 24034 :
                return context.getResources().getString(R.string.fm_24034);
            case 24035 :
                return context.getResources().getString(R.string.fm_24035);
            case 990001 :
                return context.getResources().getString(R.string.fm_990001);
            case 990002 :
                return context.getResources().getString(R.string.fm_990002);
            case 990003 :
                return context.getResources().getString(R.string.fm_990003);
            case 990004 :
                return context.getResources().getString(R.string.fm_990004);
            case 990005 :
                return context.getResources().getString(R.string.fm_990005);
            case 990006 :
                return context.getResources().getString(R.string.fm_990006);
            case 990007 :
                return context.getResources().getString(R.string.fm_990007);
            case 990008 :
                return context.getResources().getString(R.string.fm_990008);
            case 990009 :
                return context.getResources().getString(R.string.fm_990009);
            case 990010 :
                return context.getResources().getString(R.string.fm_990010);
            case 990011 :
                return context.getResources().getString(R.string.fm_990011);
            case 990012 :
                return context.getResources().getString(R.string.fm_990012);
            case 990013 :
                return context.getResources().getString(R.string.fm_990013);
            case 990101 :
                return context.getResources().getString(R.string.fm_990101);
            case 990102 :
                return context.getResources().getString(R.string.fm_990102);
            case 990103 :
                return context.getResources().getString(R.string.fm_990103);
            case 990104 :
                return context.getResources().getString(R.string.fm_990104);
            case 990105 :
                return context.getResources().getString(R.string.fm_990105);
            case 990106 :
                return context.getResources().getString(R.string.fm_990106);
            case 990107 :
                return context.getResources().getString(R.string.fm_990107);
            case 990108 :
                return context.getResources().getString(R.string.fm_990108);
            case 990109 :
                return context.getResources().getString(R.string.fm_990109);
            case 990110 :
                return context.getResources().getString(R.string.fm_990110);
            case 990201 :
                return context.getResources().getString(R.string.fm_990201);
            case 990202 :
                return context.getResources().getString(R.string.fm_990202);
            case 990203 :
                return context.getResources().getString(R.string.fm_990203);
            case 990204 :
                return context.getResources().getString(R.string.fm_990204);
            case 990205 :
                return context.getResources().getString(R.string.fm_990205);
            case 990206 :
                return context.getResources().getString(R.string.fm_990206);
            case 990207 :
                return context.getResources().getString(R.string.fm_990207);
            case 990208 :
                return context.getResources().getString(R.string.fm_990208);
            case 990209 :
                return context.getResources().getString(R.string.fm_990209);
            case 990210 :
                return context.getResources().getString(R.string.fm_990210);
            case 990301 :
                return context.getResources().getString(R.string.fm_990301);
            case 990302 :
                return context.getResources().getString(R.string.fm_990302);
            case 990303 :
                return context.getResources().getString(R.string.fm_990303);
            case 990304 :
                return context.getResources().getString(R.string.fm_990304);
            case 990305 :
                return context.getResources().getString(R.string.fm_990305);
            case 990306 :
                return context.getResources().getString(R.string.fm_990306);
            case 990307 :
                return context.getResources().getString(R.string.fm_990307);
            case 990308 :
                return context.getResources().getString(R.string.fm_990308);
            case 990309 :
                return context.getResources().getString(R.string.fm_990309);
            case 990310 :
                return context.getResources().getString(R.string.fm_990310);
            case 990311 :
                return context.getResources().getString(R.string.fm_990311);
            case 990312 :
                return context.getResources().getString(R.string.fm_990312);
            case 990313 :
                return context.getResources().getString(R.string.fm_990313);
            case 990314 :
                return context.getResources().getString(R.string.fm_990314);
            default:
                return "";
        }
    }
}
