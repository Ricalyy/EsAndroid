package com.esunny.data.bean;

public class SImpliedDepthL2 {
    private short                                BidPriceDepth;
    private short                                BidQtyDepth;
    private short                                AskPriceDepth;
    private short                                AskQtyDepth;

    public SImpliedDepthL2() {
    }

    public short getBidPriceDepth() {
        return BidPriceDepth;
    }

    public void setBidPriceDepth(short bidPriceDepth) {
        BidPriceDepth = bidPriceDepth;
    }

    public short getBidQtyDepth() {
        return BidQtyDepth;
    }

    public void setBidQtyDepth(short bidQtyDepth) {
        BidQtyDepth = bidQtyDepth;
    }

    public short getAskPriceDepth() {
        return AskPriceDepth;
    }

    public void setAskPriceDepth(short askPriceDepth) {
        AskPriceDepth = askPriceDepth;
    }

    public short getAskQtyDepth() {
        return AskQtyDepth;
    }

    public void setAskQtyDepth(short askQtyDepth) {
        AskQtyDepth = askQtyDepth;
    }
}
