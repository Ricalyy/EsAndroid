package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */
public class TradeLoginRsp {
    private String                                              companyNo;              //公司编号
    private String                                              addrTypeNo;             //公司地址类型
    private String                                              userNo;                 //登录号
    private int                                                 errorCode;              //错误码
    private String                                              errorText;              //错误信息
    private byte                                               forceChgPsw;            //强制修改密码

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getAddrTypeNo() {
        return addrTypeNo;
    }

    public void setAddrTypeNo(String addrTypeNo) {
        this.addrTypeNo = addrTypeNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorText() {
        return errorText;
    }

    public void setErrorText(String errorText) {
        this.errorText = errorText;
    }

    public byte getForceChgPsw() {
        return forceChgPsw;
    }

    public void setForceChgPsw(byte forceChgPsw) {
        this.forceChgPsw = forceChgPsw;
    }
}
