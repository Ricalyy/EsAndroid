package com.esunny.data.util.simplethread;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class SortExecutor {

    private final static ExecutorParams SORT_EXECUTOR_PARAMS = new ExecutorParams();

    static {
        SORT_EXECUTOR_PARAMS.corePoolSize = 1;
        SORT_EXECUTOR_PARAMS.maximumPoolSize = 1;
        SORT_EXECUTOR_PARAMS.keepAliveTime = 60L;
        SORT_EXECUTOR_PARAMS.unit = TimeUnit.SECONDS;
        SORT_EXECUTOR_PARAMS.workQueue = new LinkedBlockingQueue<>(Integer.MAX_VALUE);
        SORT_EXECUTOR_PARAMS.handler = new ThreadPoolExecutor.DiscardOldestPolicy();
    }

    static ThreadPoolExecutor getSortExecutor(ExecutorParams params) {
        return new ThreadPoolExecutor(params.corePoolSize,
                params.maximumPoolSize,
                params.keepAliveTime,
                params.unit,
                params.workQueue);
    }

    static ThreadPoolExecutor getDefaultSortExecutor() {
        return getSortExecutor(SORT_EXECUTOR_PARAMS);
    }
}
