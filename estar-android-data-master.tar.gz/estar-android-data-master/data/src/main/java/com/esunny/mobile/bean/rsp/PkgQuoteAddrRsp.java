package com.esunny.mobile.bean.rsp;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

public class PkgQuoteAddrRsp extends ApiStruct {

    //11+51+21+51+1+51+2
    public final static int STRUCT_LENGTH = 188;

    public final static char PKG_REAL_TIME_QUOTE = 'Q';
    public final static char PKG_HISTORY_QUOTE = 'H';

    private String CompanyNo;
    private String CompanyName;
    private String QuoteAddrNo;
    private String QuoteAddrName;

    private char            QuoteType;
    private String IP;
    private int                 Port;

    private PkgQuoteAddrRsp(byte[] data) {
       byteToBean(data);
    }


    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);
        CompanyNo = parseUtil.getString(11);
        CompanyName = parseUtil.getString(51);
        QuoteAddrNo = parseUtil.getString(21);
        QuoteAddrName = parseUtil.getString(51);

        QuoteType = parseUtil.getChar();
        IP = parseUtil.getString(51);
        Port = parseUtil.getUnsignedShort();
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public String getQuoteAddrNo() {
        return QuoteAddrNo;
    }

    public String getQuoteAddrName() {
        return QuoteAddrName;
    }

    public char getQuoteType() {
        return QuoteType;
    }

    public String getIP() {
        return IP;
    }

    public int getPort() {
        return Port;
    }

    public static PkgQuoteAddrRsp toParse(byte[] data) {
        return new PkgQuoteAddrRsp(data);
    }
}
