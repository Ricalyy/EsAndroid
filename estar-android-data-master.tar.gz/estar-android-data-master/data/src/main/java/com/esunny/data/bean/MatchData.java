package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

import java.math.BigInteger;

public class MatchData {
    private String                                                  CompanyNo;          //经纪公司编号
    private String                                                  MatchNo;            //成交号

    private String                                                  UserNo;             //资金帐号
    private String                                             AddressNo;              //地址号
    private String                                                  ContractNo;         //合约编号
    private char                                                    Direct;             //买卖
    private char                                                    Offset;             //开仓 平仓 开平 平开(内盘)
    private char                                                    Hedge;              //投机保值 投保 保投(内盘)
    private double                                                  MatchPrice;         //成交价格
    private java.math.BigInteger                                    MatchQty;           //成交数量
    private char                                                    MatchWay;           //成交来源

    private String                                                  MatchDateTime;      //成交时间
    private String                                                  OrderNo;            //委托号

    private String                                                  FeeCurrencyNo;      //手续费币种
    private double                                                  MatchFee;           //成交手续费
    private double                                                  Premium;            //权利金收支，收入为正，支出为负 = 成交价 * 成交量 * 乘数

    private boolean                                                    AddOne;             //是否T+1
    private boolean                                                    IsDeleted;          //是否删除

    private long                                                    StreamId;           //流号

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getMatchNo() {
        return MatchNo;
    }

    public void setMatchNo(String matchNo) {
        MatchNo = matchNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getAddressNo() {
        return AddressNo;
    }

    public void setAddressNo(String addressNo) {
        AddressNo = addressNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public double getMatchPrice() {
        return MatchPrice;
    }

    public void setMatchPrice(double matchPrice) {
        MatchPrice = matchPrice;
    }

    public BigInteger getMatchQty() {
        return MatchQty;
    }

    public void setMatchQty(BigInteger matchQty) {
        MatchQty = matchQty;
    }

    public char getMatchWay() {
        return MatchWay;
    }

    public void setMatchWay(char matchWay) {
        MatchWay = matchWay;
    }

    public String getMatchDateTime() {
        return MatchDateTime;
    }

    public void setMatchDateTime(String matchDateTime) {
        MatchDateTime = matchDateTime;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getFeeCurrencyNo() {
        return FeeCurrencyNo;
    }

    public void setFeeCurrencyNo(String feeCurrencyNo) {
        FeeCurrencyNo = feeCurrencyNo;
    }

    public double getMatchFee() {
        return MatchFee;
    }

    public void setMatchFee(double matchFee) {
        MatchFee = matchFee;
    }

    public double getPremium() {
        return Premium;
    }

    public void setPremium(double premium) {
        Premium = premium;
    }

    public boolean isAddOne() {
        return AddOne;
    }

    public void setAddOne(boolean addOne) {
        AddOne = addOne;
    }

    public boolean isDeleted() {
        return IsDeleted;
    }

    public void setIsDeleted(boolean isDeleted) {
        IsDeleted = isDeleted;
    }

    public long getStreamId() {
        return StreamId;
    }

    public void setStreamId(long streamId) {
        StreamId = streamId;
    }
}
