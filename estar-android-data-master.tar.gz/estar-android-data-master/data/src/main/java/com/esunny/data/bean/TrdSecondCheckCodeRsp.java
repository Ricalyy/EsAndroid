package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */
public class TrdSecondCheckCodeRsp {
    private String  secondSerialID;//序列号
    private double    effectiveTime;//二次认证验证码有效时间

    public String getSecondSerialID() {
        return secondSerialID;
    }

    public void setSecondSerialID(String secondSerialID) {
        this.secondSerialID = secondSerialID;
    }

    public double getEffectiveTime() {
        return effectiveTime;
    }

    public void setEffectiveTime(double effectiveTime) {
        this.effectiveTime = effectiveTime;
    }
}
