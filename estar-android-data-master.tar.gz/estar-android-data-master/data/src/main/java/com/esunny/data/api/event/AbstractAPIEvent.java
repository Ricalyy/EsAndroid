package com.esunny.data.api.event;

public abstract class AbstractAPIEvent extends AbstractEvent {

    AbstractAPIEvent(AbstractAPIEventBuilder builder){
        Builder = builder;
    }

    public boolean getSrvChain() {
        return ((AbstractAPIEventBuilder)Builder).srvChain;
    }

    public int getSrvErrorCode() {
        return ((AbstractAPIEventBuilder)Builder).srvErrorCode;
    }

    public String getSrvErrorText() {
        return ((AbstractAPIEventBuilder)Builder).srvErrorText;
    }
}
