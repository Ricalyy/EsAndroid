package com.esunny.data.api.server;

import com.alibaba.android.arouter.facade.template.IProvider;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public interface EsSystemInfo extends IProvider {

    String API_TYPE_DAY_STAR = "DaystarctTradeApi";
    String API_TYPE_DIPPER = "DipperctTradeApi";
    String API_TYPE_CTP = "CtpctTradeApi";
    String API_TYPE_KST = "KingstarctTradeApi";
    String API_TYPE_HUND_SUN = "HundsunctTradeApi";
    String API_TYPE_CTP_STOCK_CT = "CtpstockctTradeApi";
    String API_TYPE_CTPETF_CT = "CtpetfctTradeApi";
    String API_TYPE_FEMA_CT = "FemasctMTradeApi";

    interface SystemInfoCallback{
        void onGetSystemInfo(SystemInfo info);
    }

    class SystemInfo {
        private String SystemInfo;             //系统内部信息
        private int SystemInfoLen;            //用户端系统内部信息长度(真实长度)
        private String SystemInfoIntegrity;    //采集信息完整度
        private int SystemInfoFlag;         //采集信息标记

        public String getSystemInfo() {
            return SystemInfo;
        }

        public void setSystemInfo(String systemInfo) {
            SystemInfo = systemInfo;
        }

        public int getSystemInfoLen() {
            return SystemInfoLen;
        }

        public void setSystemInfoLen(int systemInfoLen) {
            SystemInfoLen = systemInfoLen;
        }

        public String getSystemInfoIntegrity() {
            return SystemInfoIntegrity;
        }

        public void setSystemInfoIntegrity(String systemInfoIntegrity) {
            SystemInfoIntegrity = systemInfoIntegrity;
        }

        public int getSystemInfoFlag() {
            return SystemInfoFlag;
        }

        public void setSystemInfoFlag(int systemInfoFlag) {
            SystemInfoFlag = systemInfoFlag;
        }
    }

    int getSystemInfo(String api, SystemInfoCallback callback);
}
