package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class OpenOrder {
    private char        StrategyType;       //策略类型
    private char        Offset;             //开平
    private char        OrderPriceType;     //委托价格类型(指定价 最新价 挂单价 对盘价 市价 反向停板，只有指定价时委托价格字段才有效)(限策略单使用)
    private double      OrderPriceOver;     //委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)
    private char        OrderType;          //定单类型
    private double      OrderPrice;         //委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
    private char        ValidType;          //有效类型
    private char        StopPriceType;      //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    private double      StopPrice;          //止损止盈价或价差，具体含义由止损止盈价格类型字段决定
    private double      breakPriceDiff;     //保本单的价差
    private int         status;             // 1表示是原来改单来的数据，0表示是新下单数据
    private String      PriceStr;

    public double getBreakPriceDiff() {
        return breakPriceDiff;
    }

    public void setBreakPriceDiff(double breakPriceDiff) {
        this.breakPriceDiff = breakPriceDiff;
    }

    public char getStrategyType() {
        return StrategyType;
    }

    public void setStrategyType(char strategyType) {
        StrategyType = strategyType;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public char getOrderPriceType() {
        return OrderPriceType;
    }

    public void setOrderPriceType(char orderPriceType) {
        OrderPriceType = orderPriceType;
    }

    public double getOrderPriceOver() {
        return OrderPriceOver;
    }

    public void setOrderPriceOver(double orderPriceOver) {
        OrderPriceOver = orderPriceOver;
    }

    public char getOrderType() {
        return OrderType;
    }

    public void setOrderType(char orderType) {
        OrderType = orderType;
    }

    public double getOrderPrice() {
        return OrderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        OrderPrice = orderPrice;
    }

    public char getValidType() {
        return ValidType;
    }

    public void setValidType(char validType) {
        ValidType = validType;
    }

    public char getStopPriceType() {
        return StopPriceType;
    }

    public void setStopPriceType(char stopPriceType) {
        StopPriceType = stopPriceType;
    }

    public double getStopPrice() {
        return StopPrice;
    }

    public void setStopPrice(double stopPrice) {
        StopPrice = stopPrice;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getPriceStr() {
        return PriceStr;
    }

    public void setPriceStr(String priceStr) {
        PriceStr = priceStr;
    }
}
