package com.esunny.mobile.bean.rsp;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/9/18
 */
public class PkgCodeForbidRsp extends ApiStruct {

    public final static short STRUCT_LENGTH = 51;

    private String ForbidCode;

    private PkgCodeForbidRsp(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);
        ForbidCode = parseUtil.getString(51);
    }

    public String getForbidCode() {
        return ForbidCode;
    }

    public void setForbidCode(String forbidCode) {
        ForbidCode = forbidCode;
    }

    public static PkgCodeForbidRsp toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new PkgCodeForbidRsp(data);
        } else {
            return null;
        }
    }
}
