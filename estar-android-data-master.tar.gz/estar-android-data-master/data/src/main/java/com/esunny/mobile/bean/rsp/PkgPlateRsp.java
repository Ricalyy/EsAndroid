package com.esunny.mobile.bean.rsp;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.util.Objects;

public class PkgPlateRsp extends ApiStruct {

    private String PlateNo;
    private String PlateName;
    private String ParentPlateNo;

    public PkgPlateRsp(byte[] buff) {
        byteToBean(buff);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);

        setPlateNo(parseUtil.getString(21));
        setPlateName(parseUtil.getString(51));
        setParentPlateNo(parseUtil.getString(21));
    }

    public String getPlateNo() {
        return PlateNo;
    }

    public void setPlateNo(String plateNo) {
        PlateNo = plateNo;
    }

    public String getPlateName() {
        return PlateName;
    }

    public void setPlateName(String plateName) {
        PlateName = plateName;
    }

    public String getParentPlateNo() {
        return ParentPlateNo;
    }

    public void setParentPlateNo(String parentPlateNo) {
        ParentPlateNo = parentPlateNo;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o instanceof PkgPlateRsp) {
            return Objects.equals(PlateNo, ((PkgPlateRsp) o).getPlateNo());
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(PlateNo);
    }
}
