package com.esunny.data.api.event;

/**
 * @author Peter
 * @param <T> 继承自EsEventMessage的事件类型。
 *  <p>用作构建Eventbus的事件</p>
 *   发送相对应的事件类型之后需要将父类中的接收处理中去除，
 *   否则由于子类继承于父类，Eventbus事件接收会触发两次。
 */
public abstract class AbstractEventBuilder<T extends AbstractEvent> {
    int mSender;
    int mAction;
    Object mData;

    public AbstractEventBuilder setSender(int sender) {
        this.mSender = sender;
        return this;
    }

    public AbstractEventBuilder setAction(int action) {
        this.mAction = action;
        return this;
    }

    public AbstractEventBuilder setData(Object data) {
        this.mData = data;
        return this;
    }

    abstract public T buildEvent();
}
