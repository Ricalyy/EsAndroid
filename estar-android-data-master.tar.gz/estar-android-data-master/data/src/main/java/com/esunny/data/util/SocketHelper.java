package com.esunny.data.util;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.esunny.data.util.simplethread.SimpleRunnable;
import com.esunny.data.util.simplethread.TaskManager;
import com.esunny.data.bean.Address;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

public class SocketHelper {

    private static final String TAG = "SocketHelper";
    private static final int MSG_SELECTED = 0;
    private static final int MSG_TIMEOUT = 1;

    private static final int DELAY_TIME = 5000;

    private boolean isSelected;

    public interface SocketCallback {
        void onSelectAddr(String ip, int port);
        void onSelectFail(int error);
    }

    private void connect(final String ip, final int port, final Handler handler) {
        SimpleRunnable simpleRunnable = new SimpleRunnable() {
            @Override
            public void run() {
                try {
                    Socket socket = new Socket();
                    socket.setSoTimeout (3 * 1000);//设置超时时间
                    socket.connect(new InetSocketAddress(ip, port));

                    if (socket.isConnected() && handler != null) {
                        Message msg = handler.obtainMessage(MSG_SELECTED);
                        msg.obj = ip;
                        msg.arg1 = port;
                        handler.sendMessage(msg);
                    }

                    try {
                        socket.close();
                    } catch (IOException e) {
                        EsLog.d(TAG, "connect fail", e);
                    }
                } catch (IOException e) {
                    EsLog.d(TAG, "connect fail", e);
                }
            }
        };

        TaskManager.getInstance().execute(simpleRunnable);
    }

    public void selectAddress(Address[] arr, final SocketCallback callback) {
        if (callback == null) {
            return;
        }

        if (arr == null || arr.length == 0) {
            callback.onSelectFail(0);
            return;
        }

        isSelected = false;

        Handler handler = new Handler(Looper.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                removeCallbacksAndMessages(null);
                if (!isSelected) {
                    if (msg.what == MSG_SELECTED) {
                        String ip = (String) msg.obj;
                        int port = msg.arg1;
                        callback.onSelectAddr(ip, port);
                        isSelected = true;

                        EsLog.d(TAG, "select address = " + ip + ":" + port);
                    } else if (msg.what == MSG_TIMEOUT){
                        callback.onSelectFail(1);
                        isSelected = true;

                        EsLog.d(TAG, "select address timeout ");
                    }
                }
            }
        };

        for (Address addr : arr) {
            connect(addr.getIp(), addr.getPort(), handler);
        }

        handler.sendEmptyMessageDelayed(MSG_TIMEOUT, DELAY_TIME);
    }
}
