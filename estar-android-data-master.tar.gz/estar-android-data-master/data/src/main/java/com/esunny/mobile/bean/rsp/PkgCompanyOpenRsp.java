package com.esunny.mobile.bean.rsp;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

public class PkgCompanyOpenRsp extends ApiStruct {

    private String         OpenCode;
    private String         CompanyName;
    private String         OpenUrl;

    public PkgCompanyOpenRsp(byte[] buf) {
        super(buf);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);

        OpenCode = parseUtil.getString(11);
        CompanyName = parseUtil.getString(51);
        OpenUrl = parseUtil.getString(101);
    }

    public String getOpenCode() {
        return OpenCode;
    }

    public String getCompanyName() {
        return CompanyName;
    }

    public String getOpenUrl() {
        return OpenUrl;
    }
}
