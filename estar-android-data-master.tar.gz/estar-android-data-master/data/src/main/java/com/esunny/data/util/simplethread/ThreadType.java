package com.esunny.data.util.simplethread;

public enum ThreadType {
    /**
     * 普通任务线程，将任务放入线程池中执行
     */
    NORMAL,

    /**
     * 序列任务线程，采用该线程方式时，线程池会根据任务优先级顺序先后开始执行任务
     * @see TaskPriority
     */
    SERIAL,

    /**
     * 排序任务线程，采用该线程方式时，线程池会将上一个任务执行结束之后再开始执行下一个任务。
     */
    SORT;
}
