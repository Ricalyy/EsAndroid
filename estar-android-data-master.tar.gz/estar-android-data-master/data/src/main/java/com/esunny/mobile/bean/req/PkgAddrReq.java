package com.esunny.mobile.bean.req;

import com.esunny.mobile.EsNativeProtocol;
import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/9/16
 */
public class PkgAddrReq extends ApiStruct{

    public final static int STRUCT_LENGTH = 36;

    private char TerminalOSType;

    private short LangType;

    private String PackageNo;

    private String LicenseNo;

    private char ProtocolVer;

    public PkgAddrReq() {
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(charToByte(TerminalOSType));
        buffer.putShort(LangType);
        buffer.put(stringToByte(PackageNo, 11));
        buffer.put(stringToByte(LicenseNo, 21));
        buffer.put(charToByte(ProtocolVer));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setTerminalOSType(util.getChar());
        setLangType(util.getUnsignedShort());
        setPackageNo(util.getString(11));
        setLicenseNo(util.getString(21));
        setProtocolVer(util.getChar());
    }

    public static CspSessionHead getSessionHead(int protocolCode) {
        return CspSessionHead.getCspSessionHead(protocolCode, EsNativeProtocol.CSP_SUBSYSTEM_PKGMGR, STRUCT_LENGTH);
    }

    public char getTerminalOSType() {
        return TerminalOSType;
    }

    public void setTerminalOSType(char terminalOSType) {
        this.TerminalOSType = terminalOSType;
    }

    public int getLangType() {
        return LangType;
    }

    public void setLangType(int langType) {
        this.LangType = (short) langType;
    }

    public String getPackageNo() {
        return PackageNo;
    }

    public void setPackageNo(String packageNo) {
        this.PackageNo = packageNo;
    }

    public String getLicenseNo() {
        return LicenseNo;
    }

    public void setLicenseNo(String licenseNo) {
        this.LicenseNo = licenseNo;
    }

    public char getProtocolVer() {
        return ProtocolVer;
    }

    public void setProtocolVer(char protocolVer) {
        this.ProtocolVer = protocolVer;
    }
}
