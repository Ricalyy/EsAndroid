package com.esunny.data.bean;

public class NewsContentInfo {

    private int                                 NewsID;
    private int                                 NewsClassID;
    private String                              NewsTitle;
    private String                              NewsSource;
    private String                              NewsPublishTime;

    private char                                NewsTop;
    private String                              NewsColor;

    public int getNewsID() {
        return NewsID;
    }

    public void setNewsID(int newsID) {
        NewsID = newsID;
    }

    public int getNewsClassID() {
        return NewsClassID;
    }

    public void setNewsClassID(int newsClassID) {
        NewsClassID = newsClassID;
    }

    public String getNewsTitle() {
        return NewsTitle;
    }

    public void setNewsTitle(String newsTitle) {
        NewsTitle = newsTitle;
    }

    public String getNewsSource() {
        return NewsSource;
    }

    public void setNewsSource(String newsSource) {
        NewsSource = newsSource;
    }

    public String getNewsPublishTime() {
        return NewsPublishTime;
    }

    public void setNewsPublishTime(String newsPublishTime) {
        NewsPublishTime = newsPublishTime;
    }

    public char getNewsTop() {
        return NewsTop;
    }

    public void setNewsTop(char newsTop) {
        NewsTop = newsTop;
    }

    public String getNewsColor() {
        return NewsColor;
    }

    public void setNewsColor(String newsColor) {
        NewsColor = newsColor;
    }
}
