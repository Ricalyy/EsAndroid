package com.esunny.data.api.event;

public abstract class AbstractAPIEventBuilder<T extends AbstractAPIEvent> extends AbstractEventBuilder{

    boolean srvChain;
    int srvErrorCode;
    String srvErrorText;

    public AbstractAPIEventBuilder setSrvChain(boolean srvChain) {
        this.srvChain = srvChain;
        return this;
    }

    public AbstractAPIEventBuilder setSrvErrorCode(int srvErrorCode) {
        this.srvErrorCode = srvErrorCode;
        return this;
    }

    public AbstractAPIEventBuilder setSrvErrorText(String srvErrorText) {
        this.srvErrorText = srvErrorText;
        return this;
    }
}
