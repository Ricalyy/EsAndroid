package com.esunny.mobile.bean.req;


import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/9/18 落后挨打，勿忘国耻
 */
public class PkgPhoneStartReq extends ApiStruct {

    public final static int STRUCT_LENGTH = 22;

    private char TerminalOSType;
    private short LangType;
    private String PackageNo;
    private int ScreenWidth;
    private int ScreenHeight;

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(charToByte(TerminalOSType));
        buffer.putShort(LangType);
        buffer.put(stringToByte(PackageNo, 11));
        buffer.putInt(ScreenWidth);
        buffer.putInt(ScreenHeight);
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setTerminalOSType(util.getChar());
        setLangType(util.getUnsignedShort());
        setPackageNo(util.getString(11));
        setScreenWidth(util.getInt());
        setScreenHeight(util.getInt());
    }

    public char getTerminalOSType() {
        return TerminalOSType;
    }

    public void setTerminalOSType(char terminalOSType) {
        TerminalOSType = terminalOSType;
    }

    public short getLangType() {
        return LangType;
    }

    public void setLangType(int langType) {
        this.LangType = (short) langType;
    }

    public String getPackageNo() {
        return PackageNo;
    }

    public void setPackageNo(String packageNo) {
        PackageNo = packageNo;
    }

    public int getScreenWidth() {
        return ScreenWidth;
    }

    public void setScreenWidth(int screenWidth) {
        ScreenWidth = screenWidth;
    }

    public int getScreenHeight() {
        return ScreenHeight;
    }

    public void setScreenHeight(int screenHeight) {
        ScreenHeight = screenHeight;
    }
}
