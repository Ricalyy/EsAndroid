package com.esunny.data.bean;

import java.math.BigInteger;

/**
 * @author Peter Fu
 * @date 2020/10/10
 */
public class SQuoteField {

    private char FidMean;                            //变化行情使用标识

    private char FidAttr;                            //固定行情使用属性

    private double Price;

    private BigInteger Qty;

    private double Greek;

    private double Volatility;

    private BigInteger DateTime;

    private int Date;

    private int Time;

    private char State;

    private char Str;

    private char Ptr;

    public char getFidMean() {
        return FidMean;
    }

    public void setFidMean(char fidMean) {
        FidMean = fidMean;
    }

    public char getFidAttr() {
        return FidAttr;
    }

    public void setFidAttr(char fidAttr) {
        FidAttr = fidAttr;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double price) {
        Price = price;
    }

    public BigInteger getQty() {
        return Qty;
    }

    public void setQty(BigInteger qty) {
        Qty = qty;
    }

    public double getGreek() {
        return Greek;
    }

    public void setGreek(double greek) {
        Greek = greek;
    }

    public double getVolatility() {
        return Volatility;
    }

    public void setVolatility(double volatility) {
        Volatility = volatility;
    }

    public BigInteger getDateTime() {
        return DateTime;
    }

    public void setDateTime(BigInteger dateTime) {
        DateTime = dateTime;
    }

    public int getDate() {
        return Date;
    }

    public void setDate(int date) {
        Date = date;
    }

    public int getTime() {
        return Time;
    }

    public void setTime(int time) {
        Time = time;
    }

    public char getState() {
        return State;
    }

    public void setState(char state) {
        State = state;
    }

    public char getStr() {
        return Str;
    }

    public void setStr(char str) {
        Str = str;
    }

    public char getPtr() {
        return Ptr;
    }

    public void setPtr(char ptr) {
        Ptr = ptr;
    }
}
