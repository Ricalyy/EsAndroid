package com.esunny.data.bean;

/**
 * @author xiaosa
 */
public class MonitorStateData {
    private String Value;      //具体数值用|分开;
    private String Reason;       //报警原因用|分开;
    private String UpdateTime;         //更新时间

    public MonitorStateData() {
    }

    public MonitorStateData(String value, String reason, String updateTime) {
        Value = value;
        Reason = reason;
        UpdateTime = updateTime;
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }

    public String getReason() {
        return Reason;
    }

    public void setReason(String reason) {
        Reason = reason;
    }

    public String getUpdateTime() {
        return UpdateTime;
    }

    public void setUpdateTime(String updateTime) {
        UpdateTime = updateTime;
    }
}
