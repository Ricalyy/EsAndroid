package com.esunny.data.api;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

import android.app.Application;
import android.content.Context;

import androidx.annotation.Keep;

import com.alibaba.fastjson.JSONObject;
import com.esunny.data.api.EsDataApi;
//import com.esunny.data.common.bean.QuoteLoginInfo;
//import com.esunny.quote.database.DBManager;
//import com.esunny.quote.database.ServerDatabaseHelper;
//import com.esunny.server.infocollect.EsunnyInfoTrackHelper;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EsDataTrackApi {
    private final String TAG = this.getClass().getSimpleName();
    public static final String SDK_VERSION = "1.0.0";

    private static final SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");


    public static void init(Application application) {
//        EsunnyInfoTrackHelper.init(application);
    }

    private EsDataTrackApi() {
    }


    /**
     * 检测数据库状态，当满足条件时需要发送数据。
     */
    public static void checkDatabaseStatus(Context context) {
//        long count = DBManager.getInstance().getDaoSession(ServerDatabaseHelper.USER_INFO_DATABASE_NAME).getUserInfoDataDao().queryBuilder().count();
//        if (count >= EsunnyInfoTrackHelper.DATABASE_CACHE_SIZE) {
//            EsunnyInfoTrackHelper.getInstance().sendData();
//        }
    }


    /**
     * 添加自选合约
     *
     * @param contractNo
     */
    @Keep
    public static void addUserFavoriteContract(String contractNo) {
        String number = "1010001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();

        jsonObject.put("Number", number);
        jsonObject.put("Data", contractNo);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
        infoJsonObject.put("Target", 1 << 1);
//        EsunnyInfoTrackHelper.getInstance().saveInfoToDatabase(infoJsonObject);
    }

    /**
     *  删除自选合约
     * @param contractNo 删除的自选合约号
     */
//    @Keep
    public static void removeUserContract(String contractNo) {
        String number = "1010001";
        deletetUserData(number, contractNo);
    }

    /**
     * 合约搜索
     *
     * @param contractNo
     * @param searchContent
     */
//    @Keep
    public static void addUserSearchContract(String contractNo, String searchContent) {
        String number = "1010002";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        JSONObject dataObject = new JSONObject();

        dataObject.put("SearchText", searchContent);
        dataObject.put("ContractNo", contractNo);

        jsonObject.put("Number", number);
        jsonObject.put("Data", dataObject);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
        infoJsonObject.put("Target", 1);
//        EsunnyInfoTrackHelper.getInstance().saveInfoToDatabase(infoJsonObject);
    }

    /**
     * 查看的期权合约
     *
     * @param contractNo
     */
//    @Keep
    public static void addUserOptionContract(String contractNo) {
        String number = "1020001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();

        jsonObject.put("Number", number);
        jsonObject.put("Data", contractNo);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
        infoJsonObject.put("Target", 1);
//        EsunnyInfoTrackHelper.getInstance().saveInfoToDatabase(infoJsonObject);
    }


    /**
     * 查看TC资讯
     *
     * @param contractNo
     */
//    @Keep
    public static void addTCNews(String contractNo) {
        String number = "1030001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonData = new JSONObject();

        jsonData.put("ContractNo", contractNo);
        jsonData.put("Clicks", 1);

        jsonObject.put("Number", number);
        jsonObject.put("Data", jsonData);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
        infoJsonObject.put("Target", 1);
//        EsunnyInfoTrackHelper.getInstance().saveInfoToDatabase(infoJsonObject);
    }

    /**
     * 资讯新闻搜索
     *
     * @param searchText
     * @param variety
     */
//    @Keep
    public static void addNewsSearch(String searchText, String variety) {
        String number = "1040001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonData = new JSONObject();

        jsonData.put("SearchText", searchText);
        jsonData.put("Variety", variety);

        jsonObject.put("Number", number);
        jsonObject.put("Data", jsonData);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
        infoJsonObject.put("Target", 1);
//        EsunnyInfoTrackHelper.getInstance().saveInfoToDatabase(infoJsonObject);
    }

    /**
     * 极星登录
     *
     * @param autoLogin
     */
//    @Keep
    public static void addPolestarLogin(boolean autoLogin) {
        String number = "1050001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonData = new JSONObject();

        jsonData.put("LoginTime", sf.format(new Date()));
        jsonData.put("LoginType", autoLogin ? "Auto" : "Manual");

        jsonObject.put("Number", number);
        jsonObject.put("Data", jsonData);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
        infoJsonObject.put("Target", 1);
//        EsunnyInfoTrackHelper.getInstance().saveInfoToDatabase(infoJsonObject);
    }

    /**
     * 行情K线配置
     *
     */
    @Keep
    public static void saveKlineConfiguration(char klineType, int klineSlice, float klineScaleSize, boolean showMinSubChart,
                                              boolean showMinMarketQuote, boolean showDaySubChart, int minQuoteDay) {
        String number = "1060001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonData = new JSONObject();

        jsonData.put("KlineType", klineType);
        jsonData.put("KlineSlice", klineSlice);
        jsonData.put("klineScaleSize", klineScaleSize);
        jsonData.put("ShowMinSubChart", showMinSubChart);
        jsonData.put("ShowMinMarketQuote", showMinMarketQuote);
        jsonData.put("ShowDaySubChart", showDaySubChart);
        jsonData.put("MinQuoteDay", minQuoteDay);
//        jsonData.put("TCNewsType", tcNewsType);

        jsonObject.put("Number", number);
        jsonObject.put("Data", jsonData);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
//        EsunnyInfoTrackHelper.getInstance().sendConfigurationData(infoJsonObject);
    }

    /**
     * 点价下单
     *
     * @param contractNo
     */
//    @Keep
    public static void addPointOrder(String contractNo) {
        String number = "2010001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();

        jsonObject.put("Number", number);
        jsonObject.put("Data", contractNo);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
        infoJsonObject.put("Target", 1);
//        EsunnyInfoTrackHelper.getInstance().saveInfoToDatabase(infoJsonObject);
    }

    /**
     * 交易登录
     *
     * @param userNo
     * @param loginType
     * @param ip
     * @param mac
     * @param serverIp
     * @param serverPort
     */
//    @Keep
    public static void addTradeLogin(String companyNo, String companyName, String userNo, String addressNo, String addressName,String loginType,
                                     String tradeApi, String ip, String mac, String gps, String serverIp, int serverPort) {
        String number = "2020001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonData = new JSONObject();

        jsonData.put("CompanyNo", companyNo);
        jsonData.put("CompanyName", companyName);
        jsonData.put("UserNo", userNo);
        jsonData.put("AddrNo", addressNo);
        jsonData.put("AddrName", addressName);
        jsonData.put("LoginTime", sf.format(new Date()));
        jsonData.put("LoginType", loginType);
        jsonData.put("Ip", ip);
        jsonData.put("Mac", mac);
        jsonData.put("GPS", gps);
        jsonData.put("ProductInfo", "Yi Star");
        jsonData.put("TradeApi", tradeApi);
        jsonData.put("ServerIP", serverIp);
        jsonData.put("ServerPort", serverPort);

        jsonObject.put("Number", number);
        jsonObject.put("Data", jsonData);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
        infoJsonObject.put("Target", 1);
//        EsunnyInfoTrackHelper.getInstance().saveInfoToDatabase(infoJsonObject);
    }

//    @Keep
    public static void saveSettingConfiguration(int language, boolean isDisconnectSound, boolean tradeSound, boolean messageSound,
                                                boolean isKeepScreenOn) {
        String number = "3020003";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonData = new JSONObject();

        jsonData.put("Language", language);
        jsonData.put("IsDisconnectSound", isDisconnectSound);
        jsonData.put("IsTradeSound", tradeSound);
        jsonData.put("IsMessageSound", messageSound);

        jsonData.put("IsKeepScreenOn", isKeepScreenOn);

        jsonObject.put("Number", number);
        jsonObject.put("Data", jsonData);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
//        EsunnyInfoTrackHelper.getInstance().sendConfigurationData(infoJsonObject);
    }

//    @Keep
    public static void saveTradeSettingConfiguration(int defaultPriceType, int reversePriceType, int pannelSetting, boolean isFirstCoverToday, boolean isTradeLinkage, boolean isMessageShake,
                                                     boolean isHedage, boolean isDivideOrder, boolean isOrderConfirm, boolean isReverseConfirm, boolean isClickPriceConfirm,
                                                     boolean isFingerPrinterConfirm) {
        String number = "3020002";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject jsonObject = new JSONObject();
        JSONObject jsonData = new JSONObject();

        jsonData.put("DefaultPriceType", defaultPriceType);
        jsonData.put("ReversePriceType", reversePriceType);
        jsonData.put("PannelSetting", pannelSetting);
        jsonData.put("IsFirstCoverToday", isFirstCoverToday);
        jsonData.put("IsTradeLinkage", isTradeLinkage);
        jsonData.put("IsMessageShake", isMessageShake);
        jsonData.put("IsHedge", isHedage);
        jsonData.put("IsDivideOrder", isDivideOrder);
        jsonData.put("IsOrderConfirm", isOrderConfirm);
        jsonData.put("IsReverseConfirm", isReverseConfirm);
        jsonData.put("IsClickPriceConfirm", isClickPriceConfirm);
        jsonData.put("IsFingerPrinterConfirm", isFingerPrinterConfirm);

        jsonObject.put("Number", number);
        jsonObject.put("Data", jsonData);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", jsonObject);
//        EsunnyInfoTrackHelper.getInstance().sendConfigurationData(infoJsonObject);
    }

//    @Keep
    public static void saveQuoteSettingConfiguration(JSONObject jsonData) {
        String number = "3020001";
        JSONObject infoJsonObject = new JSONObject();
        JSONObject eventObject = new JSONObject();


        eventObject.put("Number", number);
        eventObject.put("Data", jsonData);

        infoJsonObject.put("EpoleStarNo", getEpoleStarNo());
        infoJsonObject.put("Event", eventObject);
//        EsunnyInfoTrackHelper.getInstance().sendConfigurationData(infoJsonObject);
    }

//    @Keep
    private static void deletetUserData(String number, String data) {
//        EsunnyInfoTrackHelper.getInstance().removeInfoData(number, data);
    }

    private static String getEpoleStarNo() {
        String epoleStarNo = "Default";
//        QuoteLoginInfo info = EsDataApi.quoteLoginInfo();
//        if (info != null && !info.getLoginNo().trim().isEmpty()) {
//            epoleStarNo = info.getLoginNo();
//        }
        return epoleStarNo;
    }
}
