package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */

import java.io.Serializable;

public class MessageData implements Serializable {
    private long   MsgId;              //消息Id
    private String CompanyNo;          //经纪公司编号
    private String UserNo;             //接收者
    private String AddressNo;          //地址号
    private char  Level;              //消息级别
    private String SendNo;             //发送者
    private String SendDateTime;       //发送时间
    private String ValidDateTime;      //有效时间
    private String Title;              //标题
    private String Content;            //消息内容

    public void setMsgId(long value){
        MsgId=value;
    }

    public long getMsgId(){
        return MsgId;
    }

    public void setCompanyNo(String value){
        CompanyNo=value;
    }

    public String getCompanyNo(){
        return CompanyNo;
    }

    public void setUserNo(String value){
        UserNo=value;
    }

    public String getUserNo(){
        return UserNo;
    }

    public String getAddressNo() {
        return AddressNo;
    }

    public void setAddressNo(String addressNo) {
        AddressNo = addressNo;
    }

    public void setLevel(char value){
        Level=value;
    }

    public char getLevel(){
        return Level;
    }

    public void setSendNo(String value){
        SendNo=value;
    }

    public String getSendNo(){
        return SendNo;
    }

    public void setSendDateTime(String value){
        SendDateTime=value;
    }

    public String getSendDateTime(){
        return SendDateTime;
    }

    public void setValidDateTime(String value){
        ValidDateTime=value;
    }

    public String getValidDateTime(){
        return ValidDateTime;
    }

    public void setTitle(String value){
        Title=value;
    }

    public String getTitle(){
        return Title;
    }

    public void setContent(String value){
        Content=value;
    }

    public String getContent(){
        return Content;
    }
}
