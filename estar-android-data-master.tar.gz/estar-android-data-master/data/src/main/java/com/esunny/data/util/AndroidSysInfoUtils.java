package com.esunny.data.util;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class AndroidSysInfoUtils {
    /**
     * 汉字 转换为对应的 UTF-8编码
     * @param s 木
     * @return E69CA8
     */
    private static String convertStringToUTF8(String s) {
        if (s == null || s.equals("")) {
            return null;
        }
        StringBuffer sb = new StringBuffer();
        try {
            char c;
            for (int i = 0; i < s.length(); i++) {
                c = s.charAt(i);
                if (c >= 0 && c <= 255) {
                    sb.append(c);
                } else {
                    byte[] b;
                    b = Character.toString(c).getBytes("utf-8");
                    for (byte aB : b) {
                        int k = aB;
                        //转换为unsigned integer  无符号integer
                        /*if (k < 0)
                            k += 256;*/
                        k = k < 0 ? k + 256 : k;
                        //返回整数参数的字符串表示形式 作为十六进制（base16）中的无符号整数
                        //该值以十六进制（base16）转换为ASCII数字的字符串
                        sb.append(Integer.toHexString(k).toUpperCase());

                        // url转置形式
                        // sb.append("%" +Integer.toHexString(k).toUpperCase());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    //Host
    public static String getHost() {
        //return android.os.Build.HOST;
        return convertStringToUTF8(android.os.Build.HOST);
    }

    //系统名称
    public static String getOsName() {
        return "Android";
    }

    //系统版本号
    public static String getOsVersion() {
        return android.os.Build.VERSION.RELEASE;
    }

    //获取系统唯一标识
    public static String getDeviceId(android.content.Context context) {
        String uuid = null;
        try {
            android.content.SharedPreferences mShare = context.getSharedPreferences("uuid", android.content.Context.MODE_PRIVATE);
            if (mShare != null) {
                uuid = mShare.getString("uuid", "");
            }
            if (android.text.TextUtils.isEmpty(uuid)) {
                uuid = java.util.UUID.randomUUID().toString();
                uuid = uuid.toUpperCase();
                mShare.edit().putString("uuid", uuid).apply();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        //return uuid;
        return convertStringToUTF8(uuid);
    }

    //获取当前手机系统语言
    //例如：当前设置的是“中文-中国”，则返回“zh-CN”
    public static String getSystemLanguage() {
        return java.util.Locale.getDefault().getLanguage();
    }


    //获取当前系统上的语言列表(Locale列表)
    public static java.util.Locale[] getSystemLanguageList() {
        return java.util.Locale.getAvailableLocales();
    }

    //获取手机型号
    public static String getSystemModel() {
        return android.os.Build.MODEL;
    }

    //获取手机厂商
    public static String getDeviceBrand() {
        return android.os.Build.BRAND;
    }

    //获取系统主板信息
    public static String getBoard() {
        return android.os.Build.BOARD;
    }

    //获取硬件名
    public static String getHardware() {
        return android.os.Build.HARDWARE;
    }

    //硬件制造商
    public static String getManufacturer() {
        return android.os.Build.MANUFACTURER;
    }

    //设备参数
    public static String getDevice() {
        return android.os.Build.DEVICE;
    }

    //显示屏参数
    public static String getDisplay() {
        return android.os.Build.DISPLAY;
    }
}
