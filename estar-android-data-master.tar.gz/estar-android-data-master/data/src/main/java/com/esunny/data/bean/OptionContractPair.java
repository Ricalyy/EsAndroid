package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/28
 */
public class OptionContractPair {
    private String                                     StrikePrice;
    private Contract                                   Contract1;
    private Contract                                   Contract2;

    public String getStrikePrice() {
        return StrikePrice;
    }

    public void setStrikePrice(String strikePrice) {
        StrikePrice = strikePrice;
    }

    public Contract getContract1() {
        return Contract1;
    }

    public void setContract1(Contract contract1) {
        Contract1 = contract1;
    }

    public Contract getContract2() {
        return Contract2;
    }

    public void setContract2(Contract contract2) {
        Contract2 = contract2;
    }

    @Override
    public String toString() {
        return StrikePrice;
    }
}