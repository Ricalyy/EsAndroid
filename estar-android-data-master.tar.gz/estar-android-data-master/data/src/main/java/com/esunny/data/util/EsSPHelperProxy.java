package com.esunny.data.util;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

import android.content.Context;
import android.content.SharedPreferences;

import com.esunny.data.api.EsBaseApi;

public class EsSPHelperProxy {

    private static final String LOG_TAG = "EsSPHelperProxy";

    //涨跌的计算方式
    public static final int PRE_SETTLE_PRICE = 0;
    public static final int PRE_CLOSING_PRICE = 1;
    public static final int TODAY_OPEN_PRICE = 2;
    //语言选择值
    public static final int LOCALE_ENGLISH = 0x001;
    public static final int LOCALE_CHINA = 0x002;
    public static final int LOCALE_HONGKONG = 0x003;
    public static final int LOCALE_DEFAULT = 0x004;
    //行情字体大小的值
    public static final int QUOTE_TEXT_SIZE_XL = 0;
    public static final int QUOTE_TEXT_SIZE_L = 1;
    public static final int QUOTE_TEXT_SIZE_M = 2;
    public static final int QUOTE_TEXT_SIZE_S = 3;
    //铃声选择值
    public static final int RINGTONG_DEFAULT = 0x0011;
    //委托价类型
    public static final int                        S_PT_ABS                            = 0x01; //绝对价(指定价)
    public static final int                        S_PT_LSAT                           = 0x02; //最新价
    public static final int                        S_PT_QUEUE                          = 0x03; //排队价
    public static final int                        S_PT_MATCH                          = 0x04; //对手价
    public static final int                        S_PT_MARKET                         = 0x05; //市价
    public static final int                        S_PT_EXCEED                         = 0x06; //超价

    public static final int                        S_PT_EXCEED_LAST                    = 0x10; //最新价超
    public static final int                        S_PT_EXCEED_QUEUE                   = 0x11; //排队价超
    public static final int                        S_PT_EXCEED_MATCH                   = 0x12; //对手价超

    //涨跌计算方式
    private static final String PRICE_CALCULATE_METHOD = "EstarPriceCalculateMethod";
    //语言配置
    private static final String CURRENT_FAVORITE_LANGUAGE = "EstarSettingCurrentFavoriteLanguage";
    //系统配置-保持屏幕常亮
    private static final String SETTING_ISKEEPSCREENON = "EstarSettingIsKeepingScreenOn";
    //行情字体大小
    private static final String QUOTE_TEXT_SIZE = "EstarQuoteTextSize";
    //系统配置-是否启用斷線铃声
    private static final String SETTING_ISUSERINGTON = "EstarSettingIsUseRington";
    //系统配置-是否启用交易铃声
    private static final String SETTING_ISUSETRADERINGTON = "EstarSettingIsUseTradeRington";
    //系统配置-是否启用消息铃声
    private static final String SETTING_ISUSEMESSAGERINGTON = "EstarSettingIsUseMessageRington";
    //铃声种类
    private static final String SETTING_RINGTONG_TYPE = "EstarRingTongType";
    //价格预警铃声开关
    private static final String SETTING_PRICE_WARNING_RINGTONG_SWITCH = "EstarPriceWarningRingTongSwitch";
    //价格预警铃声种类
    private static final String SETTING_PRICE_WARNING_RINGTONG_TYPE = "EstarPriceWarningRingTongType";
    //交易配置-默认价格（排队价、对手价、最新价、市价）
    private static final String SETTING_DEFAULTPRICE = "EstarSettingDefaultPriceNew";
    //交易配置-反手价格（排队价、对手价、最新价、市价）
    private static final String SETTING_REVERSE_DEFAULTPRICE = "EstarSettingReverseDefaultPriceNew";
    //交易配置-止損止盈默认价格（排队价、对手价、最新价、市价）
    private static final String SETTING_DEFAULT_STOP_LOSS_PRICE = "EstarSettingDefaultStopLossPriceNew";
    //交易配置-交易信息排列方式（水平排列、竖直排列）
    private static final String SETTING_TRADE_POSITION_WAY = "EstarSettingTradePositionWay";
    //交易配置-交易资金排列方式（浮盈排列、使用率排列）
    private static final String SETTING_TRADE_POSITION_FUND = "EstarSettingTradePositionFund";
    //交易配置-上期所平仓方式（优先平昨、优先平今）
    private static final String SETTING_CLOSE_DEAL_WAY = "EstarSettingCloseDealWay";
    //交易配置-持仓添加自选
    private static final String SETTING_AUTO_ADD_FAVORITE = "EstarSettingAutoAddFavorite";
    //交易配置-委托提示震动
    private static final String SETTING_IS_ALLOW_SHAKE = "EstarSettingIsShake";
    //交易配置-交易价格联动
    private static final String SETTING_IS_TRADE_PRICE_LINKAGE = "EstarSettingIsLinkage";
    //交易配置-点价下单(撤单)操作确认提示框
    private static final String SETTING_IS_SHOW_CLICK_ORDER_PROMPT_INFO = "EstarSettingShowClickOrderPromptInfo";
    //交易配置-画线下单操作确认提示框
    private static final String SETTING_IS_SHOW_DRAW_LINE_PROMPT_INFO = "EstarSettingShowDrawLinePromptInfo";
    //交易配置-画线下单操作确认提示框
    private static final String SETTING_IS_SHOW_QUICK_TRADE_PROMPT_INFO = "EstarSettingShowQuickTradePromptInfo";
    //交易配置-反手/平仓/撤单操作确认提示框
    private static final String SETTING_IS_SHOW_REVERSE_ORDER_PROMPT_INFO = "EstarSettingShowReverseOrderPromptInfo";
    //交易配置-下单/改单操作确认提示框
    private static final String SETTING_IS_SHOW_CHANGE_ORDER_PROMPT_INFO = "EstarSettingShowChangeOrderPromptInfo";
    //交易配置-投机套保
    private static final String SETTING_IS_HEDGE = "EstarSettingIsHedge";
    //交易配置-大單拆分
    private static final String SETTING_IS_SeparateOrder= "EstarSettingIsSeparateOrder";
    //交易配置-指紋識別
    private static final String SETTING_IS_FingerPrinter= "EstarSettingIsFingerPrinter";
    //交易配置-期货平仓
    private static final String SETTING_COVER_ALL_FUTURE = "EstarSettingCoverFuture";
    //交易配置-期权平仓
    private static final String SETTING_COVER_ALL_OPTION = "EstarSettingCoverOption";
    // 画线价格设置
    public static final String DRAWLINE_PRICE_TYPE_CONFIG = "EsDrawLinePriceType";
    // 本地是否缓存码表
    private static final String IS_SAVE_CODE_TABLE_LOCALLY = "EsIsSaveCodeTableLocally";
    // 登录的易星账号
    private static final String LOGIN_ESTAR_ACCOUNT = "EsLoginEstarAccount";

    public static SharedPreferences getSP(Context context) {
        return context.getSharedPreferences(LOG_TAG, Context.MODE_PRIVATE);
    }

    //价格计算默认价格类型，是昨结算还是昨收盘或者是今开盘
    public static void setPriceCalculateMethod(Context context, int price) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor = sharedPreferences.edit();
        mEditor.putInt(PRICE_CALCULATE_METHOD, price);
        mEditor.apply();
    }

    public static int getPriceCalculateMethod() {
        Context context = EsBaseApi.getInstance().getContext();
        if (context != null) {
            SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
            return sharedPreferences.getInt(PRICE_CALCULATE_METHOD, PRE_SETTLE_PRICE);
        } else {
            return PRE_SETTLE_PRICE;
        }
    }

    //设置语言
    public static void saveFavoriteLanguage(Context context, int languageType){
        SharedPreferences sp = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(CURRENT_FAVORITE_LANGUAGE, languageType);
        editor.apply();
    }

    public static int getFavoriteLanguage(Context context){
        SharedPreferences sp = EsSPHelperProxy.getSP(context);
        return sp.getInt(CURRENT_FAVORITE_LANGUAGE, LOCALE_DEFAULT);
    }

    // 设置行情字体大小 0是特大,3是小
    public static void setQuoteTextSize(Context context, int textSize){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor= sharedPreferences.edit();
        mEditor.putInt(QUOTE_TEXT_SIZE, textSize);
        mEditor.apply();
    }

    public static int getQuoteTextSize(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getInt(QUOTE_TEXT_SIZE, QUOTE_TEXT_SIZE_M);
    }

    // 是否使用断线铃声
    public static void setIsUseRington(Context context , boolean isUseRington){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor= sharedPreferences.edit();
        mEditor.putBoolean(SETTING_ISUSERINGTON, isUseRington);
        mEditor.apply();
    }

    public static boolean getIsUseRington(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_ISUSERINGTON, false);
    }

    // 是否使用交易铃声
    public static void setIsUseTradeRington(Context context , boolean isUseRington){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor= sharedPreferences.edit();
        mEditor.putBoolean(SETTING_ISUSETRADERINGTON, isUseRington);
        mEditor.apply();
    }

    public static boolean getIsUseTradeRington(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_ISUSETRADERINGTON, true);
    }

    // 是否使用消息铃声
    public static void setIsUseMessageRington(Context context , boolean isUseRington){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor= sharedPreferences.edit();
        mEditor.putBoolean(SETTING_ISUSEMESSAGERINGTON, isUseRington);
        mEditor.apply();
    }

    public static boolean getIsUseMessageRington(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_ISUSEMESSAGERINGTON, false);
    }

    // 是否使用价格预警铃声
    public static void setIsUsePriceWarningRington(Context context , boolean isUseRington){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor= sharedPreferences.edit();
        mEditor.putBoolean(SETTING_PRICE_WARNING_RINGTONG_SWITCH, isUseRington);
        mEditor.apply();
    }

    public static boolean getIsUsePriceWarningRington(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_PRICE_WARNING_RINGTONG_SWITCH, true);
    }


    // 选用价格预警提示音类型
    public static void setPriceWarningRingtonType(Context context , int ringtongType){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor= sharedPreferences.edit();
        mEditor.putInt(SETTING_PRICE_WARNING_RINGTONG_TYPE, ringtongType);
        mEditor.apply();
    }

    public static int getPriceWarningRingtonType(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getInt(SETTING_PRICE_WARNING_RINGTONG_TYPE, 0);
    }

    // 设置铃声种类
    public static void setRingTongType(Context context , int ringtongType){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor= sharedPreferences.edit();
        mEditor.putInt(SETTING_RINGTONG_TYPE, ringtongType);
        mEditor.apply();
    }

    public static int getRingTongType(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getInt(SETTING_RINGTONG_TYPE, RINGTONG_DEFAULT);
    }

    //设置默认价格
    public static void setDefaultPriceType(Context context , int defaultPrice){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(SETTING_DEFAULTPRICE, defaultPrice);
        editor.apply();
    }

    public static int getDefaultPriceType(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getInt(SETTING_DEFAULTPRICE, S_PT_MATCH);
    }

    //设置反手默认价格
    public static void setReversePriceType(Context context , int defaultPrice){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(SETTING_REVERSE_DEFAULTPRICE, defaultPrice);
        editor.apply();
    }

    public static int getReversePriceType(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getInt(SETTING_REVERSE_DEFAULTPRICE, S_PT_MATCH);
    }

    /**
     * @param isCloseT true 是优先平今
     */
    public static void setIsCloseT(Context context , Boolean isCloseT){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_CLOSE_DEAL_WAY, isCloseT);
        editor.apply();
    }

    public static boolean getIsCloseT(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_CLOSE_DEAL_WAY, false);
    }

    /**
     * @param isHorizon true 是否水平排列
     */
    public static void setIsHorizon(Context context , Boolean isHorizon){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_TRADE_POSITION_WAY, isHorizon);
        editor.apply();
    }

    public static boolean getIsHorizon(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_TRADE_POSITION_WAY, true);
    }

    /**
     * @param isFloat true 是否浮盈排列
     */
    public static void setIsFloat(Context context , Boolean isFloat){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_TRADE_POSITION_FUND, isFloat);
        editor.apply();
    }

    public static boolean getIsFloat(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_TRADE_POSITION_FUND, true);
    }

    //保持屏幕常亮
    public static void setIsKeepScreenOn(Context context,Boolean isKeepScreenOn){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor= sharedPreferences.edit();
        mEditor.putBoolean(SETTING_ISKEEPSCREENON, isKeepScreenOn);
        mEditor.apply();
    }

    public static boolean getIsKeepScreenOn(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_ISKEEPSCREENON, false);
    }

    /**
     * @param isAutoAddFavorite True 为是
     */
    public static void setIsAutoAddFavorite(Context context , Boolean isAutoAddFavorite){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_AUTO_ADD_FAVORITE, isAutoAddFavorite);
        editor.apply();
    }

    public static boolean getIsAutoAddFavorite(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_AUTO_ADD_FAVORITE, false);
    }

    /**
     * @param isShake true 是震动
     */
    public static void setIsShake(Context context , Boolean isShake){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_ALLOW_SHAKE, isShake);
        editor.apply();
    }

    public static boolean getIsShake(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_ALLOW_SHAKE, true);
    }

    /**
     * @param isLinkage true 交易价格联动
     */
    public static void setIsLinkage(Context context , Boolean isLinkage){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_TRADE_PRICE_LINKAGE, isLinkage);
        editor.apply();
    }

    public static boolean getIsLinkage(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_TRADE_PRICE_LINKAGE, false);
    }

    /**
     * 画线下单提示信息
     * @param isShow 是否显示提示信息
     */
    public static void setIsShowDrawLinePrompt(Context context , boolean isShow) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_SHOW_DRAW_LINE_PROMPT_INFO, isShow);
        editor.apply();
    }

    public static boolean isShowDrawLinePrompt(Context context) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_SHOW_DRAW_LINE_PROMPT_INFO, true);
    }

    /**
     * 画线下单提示信息
     * @param isShow 是否显示提示信息
     */
    public static void setShowQuickTradePrompt(Context context , boolean isShow) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_SHOW_QUICK_TRADE_PROMPT_INFO, isShow);
        editor.apply();
    }

    public static boolean isShowQuickTradePrompt(Context context) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_SHOW_QUICK_TRADE_PROMPT_INFO, true);
    }

    /**
     * 点价下单(撤单)提示信息
     * @param isShow 是否显示提示信息
     */
    public static void setIsShowClickPrompt(Context context , boolean isShow) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_SHOW_CLICK_ORDER_PROMPT_INFO, isShow);
        editor.apply();
    }

    public static boolean isShowClickPrompt(Context context) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_SHOW_CLICK_ORDER_PROMPT_INFO, true);
    }
    /**
     * 反手/平仓/撤单操作确认提示信息
     * @param isShow 是否显示提示信息
     */
    public static void setIsShowReversePrompt(Context context , boolean isShow) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_SHOW_REVERSE_ORDER_PROMPT_INFO, isShow);
        editor.apply();
    }

    public static boolean isShowReversePrompt(Context context) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_SHOW_REVERSE_ORDER_PROMPT_INFO, true);
    }
    /**
     * 下单/改单操作确认提示信息
     * @param isShow 是否显示提示信息
     */
    public static void setIsShowChangeOrderPrompt(Context context , boolean isShow) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_SHOW_CHANGE_ORDER_PROMPT_INFO, isShow);
        editor.apply();
    }

    public static boolean isShowChangeOrderPrompt(Context context) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_SHOW_CHANGE_ORDER_PROMPT_INFO, true);
    }

    public static void setIsHedge(Context context , boolean isHedge){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_HEDGE, isHedge);
        editor.apply();
    }

    public static boolean getIsHedge(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_HEDGE,false);
    }

    public static void setIsSeparateOrder(Context context , boolean isSeparate){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_SeparateOrder, isSeparate);
        editor.apply();
    }

    public static boolean getIsSeparateOrder(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_SeparateOrder,true);
    }

    // 指紋識別
    public static void setIsFingerPrinter(Context context , boolean isAuthentication){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(SETTING_IS_FingerPrinter, isAuthentication);
        editor.apply();
    }

    public static boolean getIsFingerPrinter(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_IS_FingerPrinter,false);
    }

    public static void setIsCoverAllFuture(Context context, boolean coverFuture) {
        SharedPreferences.Editor editor = EsSPHelperProxy.getSP(context).edit();
        editor.putBoolean(SETTING_COVER_ALL_FUTURE, coverFuture);
        editor.apply();
    }

    public static boolean getIsCoverAllFuture(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_COVER_ALL_FUTURE,true);
    }

    public static void setIsCoverAllOption(Context context, boolean coverOption) {
        SharedPreferences.Editor editor = EsSPHelperProxy.getSP(context).edit();
        editor.putBoolean(SETTING_COVER_ALL_OPTION, coverOption);
        editor.apply();
    }

    public static boolean getIsCoverAllOption(Context context){
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        return sharedPreferences.getBoolean(SETTING_COVER_ALL_OPTION,true);
    }

    /**
     *  获取画线下单价格类型
     * @param context
     */
    public static int getDrawLinePriceType(Context context) {
        SharedPreferences sp = EsSPHelperProxy.getSP(context);
        return sp.getInt(DRAWLINE_PRICE_TYPE_CONFIG, S_PT_MATCH);
    }

    public static void setDrawLinePriceType(Context context, int priceType) {
        SharedPreferences sharedPreferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor = sharedPreferences.edit();
        mEditor.putInt(DRAWLINE_PRICE_TYPE_CONFIG, priceType);
        mEditor.apply();
    }

    /**
     *  本地是否缓存码表
     * @param context
     */
    public static void setIsSaveCodeTable(Context context, boolean isSave) {
        SharedPreferences preferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor = preferences.edit();
        mEditor.putBoolean(IS_SAVE_CODE_TABLE_LOCALLY, isSave);
        mEditor.apply();
    }

    public static boolean getIsSaveCodeTable(Context context) {
        SharedPreferences sp = EsSPHelperProxy.getSP(context);
        return sp.getBoolean(IS_SAVE_CODE_TABLE_LOCALLY, true);
    }

    /**
     * 存储登录的易星账号
     * @param context
     * @param account
     */
    public static void setEstarAccount(Context context, String account) {
        SharedPreferences preferences = EsSPHelperProxy.getSP(context);
        SharedPreferences.Editor mEditor = preferences.edit();
        mEditor.putString(LOGIN_ESTAR_ACCOUNT, account);
        mEditor.apply();
    }

    public static String getEstarAccount(Context context) {
        SharedPreferences sp = EsSPHelperProxy.getSP(context);
        return sp.getString(LOGIN_ESTAR_ACCOUNT, "");
    }
}

