package com.esunny.mobile.bean.rsp;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

public class PkgCloudAddrRsp extends ApiStruct {
    //21+51+51+2
    public final static short STRUCT_LENGTH = 125;

    private String TradeAddrNo;
    private String TradeAddrName;

    private String IP;
    private int    Port;

    private PkgCloudAddrRsp(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);

        TradeAddrNo = parseUtil.getString(21);
        TradeAddrName = parseUtil.getString(51);
        IP = parseUtil.getString(51);
        Port = parseUtil.getUnsignedShort();
    }

    public static PkgCloudAddrRsp toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new PkgCloudAddrRsp(data);
        } else {
            return null;
        }
    }

    public String getTradeAddrNo() {
        return TradeAddrNo;
    }

    public String getTradeAddrName() {
        return TradeAddrName;
    }

    public String getIP() {
        return IP;
    }

    public int getPort() {
        return Port;
    }

    @Override
    public int hashCode() {
        return IP.hashCode() + Port;
    }
}
