package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

import android.os.Parcel;
import android.os.Parcelable;

public class EsNewsData implements Parcelable {
    private Integer newsID;
    private String newsTitle;
    private String newsSummary;
    private String newsPic;
    private String newsTag;
    private Integer newsTop;
    private String newsColor;
    private String newsExpireTime;
    private String newsPublishTime;

    public EsNewsData() {
    }

    protected EsNewsData(Parcel in) {
        if (in.readByte() == 0) {
            newsID = null;
        } else {
            newsID = in.readInt();
        }
        newsTitle = in.readString();
        newsSummary = in.readString();
        newsPic = in.readString();
        newsTag = in.readString();
        if (in.readByte() == 0) {
            newsTop = null;
        } else {
            newsTop = in.readInt();
        }
        newsColor = in.readString();
        newsExpireTime = in.readString();
        newsPublishTime = in.readString();
    }

    public static final Creator<EsNewsData> CREATOR = new Creator<EsNewsData>() {
        @Override
        public EsNewsData createFromParcel(Parcel in) {
            return new EsNewsData(in);
        }

        @Override
        public EsNewsData[] newArray(int size) {
            return new EsNewsData[size];
        }
    };

    public Integer getNewsID() {
        return newsID;
    }

    public void setNewsID(Integer newsID) {
        this.newsID = newsID;
    }

    public String getNewsTitle() {
        return newsTitle;
    }

    public void setNewsTitle(String newsTitle) {
        this.newsTitle = newsTitle;
    }

    public String getNewsSummary() {
        return newsSummary;
    }

    public void setNewsSummary(String newsSummary) {
        this.newsSummary = newsSummary;
    }

    public String getNewsPic() {
        return newsPic;
    }

    public void setNewsPic(String newsPic) {
        this.newsPic = newsPic;
    }

    public String getNewsTag() {
        return newsTag;
    }

    public void setNewsTag(String newsTag) {
        this.newsTag = newsTag;
    }

    public Integer getNewsTop() {
        return newsTop;
    }

    public void setNewsTop(Integer newsTop) {
        this.newsTop = newsTop;
    }

    public String getNewsColor() {
        return newsColor;
    }

    public void setNewsColor(String newsColor) {
        this.newsColor = newsColor;
    }

    public String getNewsExpireTime() {
        return newsExpireTime;
    }

    public void setNewsExpireTime(String newsExpireTime) {
        this.newsExpireTime = newsExpireTime;
    }

    public String getNewsPublishTime() {
        return newsPublishTime;
    }

    public void setNewsPublishTime(String newsPublishTime) {
        this.newsPublishTime = newsPublishTime;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        if (newsID == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(newsID);
        }
        dest.writeString(newsTitle);
        dest.writeString(newsSummary);
        dest.writeString(newsPic);
        dest.writeString(newsTag);
        if (newsTop == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(newsTop);
        }
        dest.writeString(newsColor);
        dest.writeString(newsExpireTime);
        dest.writeString(newsPublishTime);
    }
}
