package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class AdverImageInfo {
    private String                         AdvertImageUrl;     //广告页地址(仍需加高度宽度参数,后续会慢慢遗弃，不用再加参数)
    private String                         AdvertImgStartDate; //广告页加载起始时间
    private String                         AdvertImgEndDate;   //广告页加载结束时间
    private String                         AdvertImgUpdateDate;//更新时间

    public String getAdvertImageUrl() {
        return AdvertImageUrl;
    }

    public void setAdvertImageUrl(String advertImageUrl) {
        AdvertImageUrl = advertImageUrl;
    }

    public String getAdvertImgStartDate() {
        return AdvertImgStartDate;
    }

    public void setAdvertImgStartDate(String advertImgStartDate) {
        AdvertImgStartDate = advertImgStartDate;
    }

    public String getAdvertImgEndDate() {
        return AdvertImgEndDate;
    }

    public void setAdvertImgEndDate(String advertImgEndDate) {
        AdvertImgEndDate = advertImgEndDate;
    }

    public String getAdvertImgUpdateDate() {
        return AdvertImgUpdateDate;
    }

    public void setAdvertImgUpdateDate(String advertImgUpdateDate) {
        AdvertImgUpdateDate = advertImgUpdateDate;
    }
}

