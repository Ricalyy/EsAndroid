package com.esunny.data.database.table;
import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 * @author Peter Fu
 * @date 2020/10/13
 */
@Entity(nameInDb = "TCurrency")
public class TCurrency {

    @Id()
    @Property(nameInDb = "FCurrencyNo")
    private String CurrencyNo;
    @Property(nameInDb = "FExchangeRate")
    private double ExchangeRate;
    @Property(nameInDb = "FInterestRate")
    private double InterestRate;
    @Property(nameInDb = "FUpdateId")
    private Long UpdateId = 0L;                // 更新的编号

    @Generated(hash = 1055858625)
    public TCurrency(String CurrencyNo, double ExchangeRate, double InterestRate,
            Long UpdateId) {
        this.CurrencyNo = CurrencyNo;
        this.ExchangeRate = ExchangeRate;
        this.InterestRate = InterestRate;
        this.UpdateId = UpdateId;
    }

    @Generated(hash = 317305318)
    public TCurrency() {
    }

    public String getCurrencyNo() {
        return CurrencyNo;
    }

    public void setCurrencyNo(String currencyNo) {
        CurrencyNo = currencyNo;
    }

    public double getExchangeRate() {
        return ExchangeRate;
    }

    public void setExchangeRate(double exchangeRate) {
        ExchangeRate = exchangeRate;
    }

    public double getInterestRate() {
        return InterestRate;
    }

    public void setInterestRate(double interestRate) {
        InterestRate = interestRate;
    }

    public Long getUpdateId() {
        return UpdateId;
    }

    public void setUpdateId(Long updateId) {
        UpdateId = updateId;
    }
}
