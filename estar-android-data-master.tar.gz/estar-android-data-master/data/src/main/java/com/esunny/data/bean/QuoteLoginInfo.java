package com.esunny.data.bean;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.error.EsErrorCode;

public class QuoteLoginInfo {
    private String LoginNo;             //账号
    private String PassWord;           //密码
    private int   ErrorCode;          //登录错误码
    private String ErrorText;          //登录错误信息


    public String getLoginNo() {
        return LoginNo;
    }

    public void setLoginNo(String loginNo) {
        LoginNo = loginNo;
    }

    public String getPassWord() {
        return PassWord;
    }

    public void setPassWord(String passWord) {
        PassWord = passWord;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return EsDataApi.getErrorMessage(EsErrorCode.API_TYPE_QUOTE, ErrorCode, ErrorText);
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }
}
