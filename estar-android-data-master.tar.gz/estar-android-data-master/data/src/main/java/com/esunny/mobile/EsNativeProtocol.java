package com.esunny.mobile;

/**
 * @author Peter Fu
 * @date 2020/9/15
 * 与Native协议相关的常量
 */
public class EsNativeProtocol {

    public final static char PkgAndroid = 'A';

    public final static String API_VERSION_CODE = "2.3.6";
    public final static String API_PRODUCT_VERSION = "2.3.60";

    public final static char CSP_SUBSYSTEM_CSP = 0x00;    //当前文件定义协议为公共子系统
    public final static char CSP_SUBSYSTEM_REGISTER = 0x01;    //用户注册平台
    public final static char CSP_SUBSYSTEM_QUOTE = 0x02;    //行情平台
    public final static char CSP_SUBSYSTEM_TRADE = 0x03;    //交易平台
    public final static char CSP_SUBSYSTEM_ACCPOINTER = 0x04;    //接入点
    public final static char CSP_SUBSYSTEM_PKGMGR = 0x05;    //包管理平台
    public final static char CSP_SUBSYSTEM_USERSTATS = 0x06;    //用户行为分析系统
    public final static char CSP_SUBSYSTEM_OPTIONMGR = 0x07;    //操作员管理
    public final static char CSP_SUBSYSTEM_NEWS = 0x08;    //新闻资讯平台
    public final static char CSP_SUBSYSTEM_MESSAGE = 0x09;    //消息发布平台

    /**
     * 数据帧数据内容类型
     */
    //明文数据帧
    public final static char CSP_FRAME_PLAIN = '1';
    //RSA公钥加密
    public final static char CSP_FRAME_RSA = '2';
    //压缩数据帧
    public final static char CSP_FRAME_LZO = '3';
    //加密数据帧
    public final static char CSP_FRAME_IDEA = '4';
    //压缩加密数据帧(先压缩后加密)
    public final static char CSP_FRAME_LZO_IDEA = '5';

    //统一协议版本号
    public final static short CSP_PROTOCOL_VER = 4;

    public final static short TRD_PROTOCOL_VER = 6;         //交易协议版本号

    public final static char CSP_CHAIN_END = '0';      //没有后续报文
    public final static char CSP_CHAIN_NOT_END = '1';      //还有后续报文

    //链路认证协议
    public final static int CMD_CSP_AUTH_REQ = 0x0002;
    public final static int CMD_CSP_AUTH_RSP = 0x0003;

    public final static int CMD_PKG_QUOTE_ADDR_REQ = 0x1000;
    public final static int CMD_PKG_QUOTE_ADDR_RSP = 0x1001;

    public final static int CMD_PKG_COMPANY_ADDR_REQ = 0x1020;
    public final static int CMD_PKG_COMPANY_ADDR_RSP = 0x1021;

    public final static int CMD_PKG_CLOUD_ADDR_REQ = 0x1030;
    public final static int CMD_PKG_CLOUD_ADDR_RSP = 0x1031;

    public final static int CMD_PKG_COMPANY_CLOUD_MAP_REQ = 0x1040;
    public final static int CMD_PKG_COMPANY_CLOUD_MAP_RSP = 0x1041;

    public final static int CMD_PKG_NEWS_TC_CONTRACT_REQ = 0x1040;
    public final static int CMD_PKG_NEWS_TC_CONTRACT_RSP = 0x1041;

    public final static int CMD_PKG_PLATE_INFO_REQ = 0x1080;
    public final static int CMD_PKG_PLATE_INFO_RSP = 0x1081;
    public final static int CMD_PKG_PLATE_CODE_RSP = 0x1082;

    public final static int CMD_PKG_CODE_FORBID_REQ = 0x1060;
    public final static int CMD_PKG_CODE_FORBID_RSP = 0x1061;

    public final static int CMD_PKG_CONFIG_SWITCH_REQ = 0x10a0;
    public final static int CMD_PKG_CONFIG_SWITCH_RSP = 0x10a1;

    public final static int CMD_PKG_PHONE_START_INFO_REQ = 0x10d0;
    public final static int CMD_PKG_PHONE_START_INFO_RSP = 0x10d1;

    public final static int CMD_PKG_COMPANY_OPEN_ACCOUNT_INFO_REQ = 0x10e0;
    public final static int CMD_PKG_COMPANY_OPEN_ACCOUNT_INFO_RSP = 0x10e1;

    public final static int CMD_USS_USERBEHAVIOR_REQ = 0x1000;
    public final static int CMD_USS_USERBEHAVIOR_RSP = 0x1001;

    public final static char PKG_INTERNAL = 'I';
    public final static char PKG_EXTERNAL = 'E';
    public final static char PKG_ALL = 'A';

    public final static String LICENSE_NO = "epolestar v9.3";

    //板块显示虚拟或真实合约
    public static final char S_PCODE_REAL_CONTRACT = 'R';
    public static final char S_PCODE_VIRTUAL_CONTRACT = 'V';
    public static final char S_PCODE_COMMODITY = 'C';

    //行情数据类型---------------------------------------------------------------
//    typedef U8										SFidMeanType;			  			//行情字段含义
    public final static char S_FID_PRECLOSINGPRICE = 0;        //昨收盘价
    public final static char S_FID_PRESETTLEPRICE = 1;        //昨结算价
    public final static char S_FID_PREPOSITIONQTY = 2;        //昨持仓量
    public final static char S_FID_OPENINGPRICE = 3;        //开盘价
    public final static char S_FID_LASTPRICE = 4;        //最新价
    public final static char S_FID_HIGHPRICE = 5;        //最高价
    public final static char S_FID_LOWPRICE = 6;        //最低价
    public final static char S_FID_HISHIGHPRICE = 7;        //历史最高价
    public final static char S_FID_HISLOWPRICE = 8;        //历史最低价
    public final static char S_FID_LIMITUPPRICE = 9;        //涨停价
    public final static char S_FID_LIMITDOWNPRICE = 10;        //跌停价
    public final static char S_FID_TOTALQTY = 11;        //当日总成交量
    public final static char S_FID_POSITIONQTY = 12;        //持仓量
    public final static char S_FID_AVERAGEPRICE = 13;        //均价
    public final static char S_FID_CLOSINGPRICE = 14;        //收盘价
    public final static char S_FID_SETTLEPRICE = 15;        //结算价
    public final static char S_FID_LASTQTY = 16;        //最新成交量
    public final static char S_FID_BESTBIDPRICE = 17;        //最优买价
    public final static char S_FID_BESTBIDQTY = 18;        //最优买量
    public final static char S_FID_BESTASKPRICE = 19;        //最优卖价
    public final static char S_FID_BESTASKQTY = 20;        //最优卖量
    public final static char S_FID_IMPLIEDBIDPRICE = 21;        //隐含买价
    public final static char S_FID_IMPLIEDBIDQTY = 22;        //隐含买量
    public final static char S_FID_IMPLIEDASKPRICE = 23;        //隐含卖价
    public final static char S_FID_IMPLIEDASKQTY = 24;        //隐含卖量
    public final static char S_FID_TOTALBIDQTY = 25;        //委买总量
    public final static char S_FID_TOTALASKQTY = 26;        //委卖总量
    public final static char S_FID_TOTALTURNOVER = 27;        //总成交额
    public final static char S_FID_CAPITALIZATION = 28;        //总市值
    public final static char S_FID_CIRCULATION = 29;        //流通市值
    public final static char S_FID_THEORETICALPRICE = 30;        //理论价
    public final static char S_FID_RATIO = 31;        //波动率
    public final static char S_FID_DELTA = 32;        //Delta
    public final static char S_FID_GAMMA = 33;        //Gamma
    public final static char S_FID_VEGA = 34;        //Vega
    public final static char S_FID_THETA = 35;        //Theta
    public final static char S_FID_RHO = 36;        //Rho
    public final static char S_FID_INTRINSICVALUE = 37;     //期权内在价值, QPriceFieldType类型,波动率行情
    public final static char S_FID_UNDERLYCONT = 38;     //虚拟合约对应的标的合约, QQuoteStrType类型
    public final static char S_FID_SPDLEG1BIDPRICE = 39;     //第一腿买价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG2BIDPRICE = 40;     //第二腿买价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG3BIDPRICE = 41;     //第三腿买价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG4BIDPRICE = 42;     //第四腿买价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG1ASKPRICE = 43;     //第一腿卖价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG2ASKPRICE = 44;     //第二腿卖价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG3ASKPRICE = 45;     //第三腿卖价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG4ASKPRICE = 46;     //第四腿卖价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG1LASTPRICE = 47;     //第一腿最新价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG2LASTPRICE = 48;     //第二腿最新价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG3LASTPRICE = 49;     //第三腿最新价, QPriceFieldType类型,套利行情
    public final static char S_FID_SPDLEG4LASTPRICE = 50;     //第四腿最新价, QPriceFieldType类型,套利行情
    public final static char S_FID_PREAVERAGEPRICE = 51;     //昨日均价,前海交易所推, QPriceFieldType类型

    public final static char S_FID_UPDOWN = 120;    //涨跌
    public final static char S_FID_GROWTH = 121;    //涨幅
    public final static char S_FID_NOWINTERST = 122;    //增仓
    public final static char S_FID_TURNRATE = 123;    //换手率
    public final static char S_FID_CODE = 124;    //合约代码
    public final static char S_FID_NAME = 125;    //合约名称
    public final static char S_FID_DATETIME = 126;    //更新时间

    public final static char S_FID_MEAN_COUNT = 128;    //字段总数量

    public final static char MAX_L2_DEPTH = 10;        //L2最大深度

    public final static char S_FIDATTR_NONE = 0;        //无值
    public final static char S_FIDATTR_VALID = 1;        //有值
    public final static char S_FIDATTR_IMPLIED = 2;        //隐含

    public final static int QTE_DIRECT_BID = 0x00;  //买方向
    public final static int QTE_DIRECT_ASK = 0x10;  //卖方向
    public final static int QTE_DEPTH_ADD = 0x00;  //增加深度价格
    public final static int QTE_DEPTH_CHG = 0x01;  //修改深度数量
    public final static int QTE_DEPTH_DEL = 0x02;  //删除深度价格
    public final static int QTE_DEPTH_CLR = 0x03;  //清空整个方向深度数据

    //错误码
    public final static int S_LOGIN_TCPEXIST = -1; //重复登录
    public final static int S_LOGIN_INITFAIL = -2; //内部初始化错误
    public final static int S_LOGIN_SERVERVCLOSE = -3; //云服务器维护中
    public final static int S_LOGIN_ADDRNOTEXIST = -4; //云服务器暂不支持该期货公司地址
    public final static int S_INIT_ACCESSFAIL = -5; //获取接入服务数据失败；
    public final static int S_INIT_QUOTEINITFAIL = -6; //行情初始化失败；
    public final static int S_INIT_LICENSEWRONG = -7; //证书不合法
    public final static int S_INIT_ACCOUNTEXIST = -8; //账号已登录过其他地址

    public final static int MAX_MINUTE_LINE_COUNT = 2000;  //单个数组的长度
    public final static int HOPE_MINUTE_LINE_COUNT = 800; //单次请求最大量
    public final static int MINUTE_CACHE_THRESHOLD_COUNT = 500;  //缓存阈值，当未使用数量低于此值时，需继续请求
    public final static int MAX_DAY_LINE_COUNT = 2000;
    public final static int HOPE_DAY_LINE_COUNT = 800;
    public final static int DAY_CACHE_THRESHOLD_COUNT = 500;
    public final static int MAX_TICK_LINE_COUNT = 30;

    //服务类型
    public static final char S_SRVSRC_QUOTE = 'Q';    //行情服务
    public static final char S_SRVSRC_HISQUOTE = 'H';    //历史行情服务
    public static final char S_SRVSRC_TRADE = 'T';    //交易服务
    public static final char S_SRVSRC_NEWS = 'N';    //新闻服务
    public static final char S_SRVSRC_REGISTER = 'R';    //认证服务
    public static final char S_SRVSRC_MONITOR = 'M';    //价格预警

    //账单类型
    public static final char                        S_BT_DAY                            = 'D'; //日结单
    public static final char                        S_BT_MONTH                          = 'M'; //月结单
}
