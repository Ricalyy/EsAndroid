package com.esunny.data.bean;

import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;

import java.util.Objects;

/**
 * @author Peter Fu
 * @date 2020/9/23
 */
public class Contract implements Cloneable{
    private String contractNo;
    private String contractName;
    private Commodity commodity;


    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    public void setCommodity(Commodity commodity) {
        this.commodity = commodity;
    }

    public Commodity getCommodity() {
        return commodity;
    }

    public String getContractName() {
        if (contractName == null) {
            contractName = EsDataApi.getContractName(contractNo);
        }

        if (contractName == null) {
            contractName = contractNo;
        }
        return contractName;
    }

    public boolean isForeignContract() {
        if (commodity != null) {
            return commodity.getCoverMode() == EsDataConstant.S_COVER_NONE || commodity.getCoverMode() == EsDataConstant.S_COVER_UNFINISH;
        }
        return false;
    }

    public boolean isHongKongContract() {
        return contractNo.startsWith("HK");
    }

    public boolean isSHCauContract() {
        return contractNo.startsWith("SHFE|O|CU");
    }

    public boolean isArbitrageContract() {
        if (commodity == null) {
            return false;
        }

        // 判断套利和ios保持一致，是否有单腿合约，其次是否第二个为s,m,y
        String[] arr = contractNo.split("\\|");
        return (arr[1].toLowerCase().equals("s")
                || arr[1].toLowerCase().equals("m")
                || arr[1].toLowerCase().equals("y")) && commodity.getTargetCommodity1() != null;
    }

    public boolean isPriceBelowZero() {
        if (isArbitrageContract()) {
            return true;
        }
        if (commodity == null) {
            return false;
        }

        return commodity.getCommodityName().contains("TAS");
    }

    public boolean isOptionContract() {
        String[] aar = contractNo.split("\\|");
        if (aar.length > 2) {
            String flag = aar[1];
            String type = aar[aar.length - 1];
            return flag.equals("O") && (type.contains("P") || type.contains("C"));
        }
        return false;
    }

    public boolean isStock() {
        String[] arr = contractNo.split("\\|");
        if (arr.length > 1) {
            return "T".equals(arr[1]);
        }

        return false;
    }

    public boolean isETFContract() {
        String[] split = contractNo.split("\\|");
        if (split.length > 0) {
            return contractNo.startsWith("SSE|O|510050")
                    && split[split.length - 1].contains("C");
        }
        return false;
    }

    public boolean ownTotalQty() {
        return contractNo.startsWith("ZCE");
    }

    @Override
    public boolean equals(Object o) {
        if (o instanceof Contract && contractNo != null && contractNo.equals(((Contract) o).contractNo)) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return contractNo.hashCode();
    }

    @Override
    public String toString() {
        return getContractNo();
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}