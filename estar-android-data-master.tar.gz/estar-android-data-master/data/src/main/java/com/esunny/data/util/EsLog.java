package com.esunny.data.util;

import android.util.Log;

import com.esunny.data.api.EsDataApi;

public class EsLog {

    private static final String TAG = "EsunnyLog";
    private static final int LOG_LEVEL = EsDataApi.getLogLevel();

    public static void v(String tag, String msg) {
        if (LOG_LEVEL > Log.VERBOSE) {
            return;
        }

        Log.v(TAG, tag + " : " + msg);
    }

    public static void v(String tag, String msg, Throwable tr) {
        if (LOG_LEVEL > Log.VERBOSE) {
            return;
        }

        Log.v(TAG, tag + " : " + msg, tr);
    }
    
    public static void d(String tag, String msg) {
        if (LOG_LEVEL > Log.DEBUG) {
            return;
        }

        Log.d(TAG, tag + " : " + msg);
    }

    public static void d(String tag, String msg, Object... strings) {
        if (LOG_LEVEL > Log.DEBUG) {
            return;
        }

        Log.d(TAG, tag + " : " + String.format(msg, strings));
    }

    public static void d(String tag, String msg, Throwable tr) {
        if (LOG_LEVEL > Log.DEBUG) {
            return;
        }

        Log.d(TAG, tag + " : " + msg, tr);
    }

    public static void i(String tag, String msg) {
        if (LOG_LEVEL > Log.INFO) {
            return;
        }

        Log.i(TAG, tag + " : " + msg);
    }

    public static void i(String tag, String msg, Throwable tr) {
        if (LOG_LEVEL > Log.INFO) {
            return;
        }

        Log.i(TAG, tag + " : " + msg, tr);
    }

    public static void w(String tag, String msg) {
        if (LOG_LEVEL > Log.WARN) {
            return;
        }

        Log.w(TAG, tag + " : " + msg);
    }

    public static void w(String tag, String msg, Throwable tr) {
        if (LOG_LEVEL > Log.WARN) {
            return;
        }

        Log.w(TAG, tag + " : " + msg, tr);
    }

    public static void e(String tag, String msg) {
        if (LOG_LEVEL > Log.ERROR) {
           return;
        }

        Log.e(TAG, tag + " : " + msg);
    }

    public static void e(String tag, String msg, Throwable tr) {
        if (LOG_LEVEL > Log.ERROR) {
            return;
        }

        Log.e(TAG, tag + " : " + msg, tr);
    }

    public static void push(int type, String tag, String msg) {
        if (type == Log.VERBOSE) {
            v(tag, msg);
        } else if (type == Log.DEBUG) {
            d(tag, msg);
        } else if (type == Log.INFO) {
            i(tag, msg);
        } else if (type == Log.WARN) {
            w(tag, msg);
        } else if (type == Log.ERROR) {
            e(tag, msg);
        }
    }
}
