package com.esunny.data.util.simplethread;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ThreadPoolExecutor;

public class TaskManager {

    private final static String TAG = "TaskManager";

    /**
     * 任务执行完成之后的同步Handler
     */
    public interface TaskAsyncHandler{
        void onFinished();
    }

    private Handler mHandler;

    private static class ThreadPoolManagerHolder{
        private static TaskManager INSTANCE = new TaskManager();
    }

    public static TaskManager getInstance(){
        return ThreadPoolManagerHolder.INSTANCE;
    }

    // 开辟不同线程池，通过统一管理线程池调度线程
    private ThreadPoolExecutor normalThreadExecutor;

    private ThreadPoolExecutor serialThrealExecutor;

    private ThreadPoolExecutor sortThreadExecutor;

    private TaskManager(){
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new RuntimeException("TaskManager must be created in main thread !");
        }

        normalThreadExecutor = ExecutorFactory.getExecutor(ThreadType.NORMAL);

        sortThreadExecutor = ExecutorFactory.getExecutor(ThreadType.SORT);

        serialThrealExecutor = ExecutorFactory.getExecutor(ThreadType.SERIAL);

        mHandler = new Handler(Looper.getMainLooper());
    }

    public void execute(SimpleRunnable simpleRunnable) {
        execute(simpleRunnable, ThreadType.NORMAL, null);
    }

    public void execute(SimpleRunnable simpleRunnable, ThreadType threadType) {
        execute(simpleRunnable, threadType, null);
    }

    public void execute(SimpleRunnable simpleRunnable, TaskAsyncHandler  taskAsyncHandler) {
        execute(simpleRunnable, ThreadType.NORMAL, taskAsyncHandler);
    }

    public void execute(SimpleRunnable simpleRunnable, ThreadType threadType, TaskAsyncHandler taskAsyncHandler) {
        if (simpleRunnable == null || threadType == null) {
            return;
        }

        if (threadType == ThreadType.NORMAL) {
            executeNormalTask(simpleRunnable, taskAsyncHandler);
        } else if (threadType == ThreadType.SERIAL) {
            executeSerialTask(simpleRunnable, taskAsyncHandler);
        } else if (threadType == ThreadType.SORT) {
            executeSortTask(simpleRunnable, taskAsyncHandler);
        }
    }

    private void executeNormalTask(final SimpleRunnable simpleRunnable, final TaskAsyncHandler taskAsyncHandler) {
        if (simpleRunnable == null) {
            return;
        }

        normalThreadExecutor.execute(new SimpleRunnable(simpleRunnable) {
            @Override
            public void run() {
                simpleRunnable.run();

                if (taskAsyncHandler == null) {
                    return;
                }
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        taskAsyncHandler.onFinished();
                    }
                });

            }
        });
    }

    private void executeSortTask(final SimpleRunnable simpleRunnable, final TaskAsyncHandler taskAsyncHandler) {
        if (simpleRunnable == null) {
            return;
        }

        sortThreadExecutor.execute(new SimpleRunnable(simpleRunnable) {
            @Override
            public void run() {
                simpleRunnable.run();

                if (taskAsyncHandler == null) {
                    return;
                }
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        taskAsyncHandler.onFinished();
                    }
                });

            }
        });
    }

    private void executeSerialTask(final SimpleRunnable simpleRunnable, final TaskAsyncHandler taskAsyncHandler) {
        if (simpleRunnable == null) {
            return;
        }

        serialThrealExecutor.execute(new SimpleRunnable(simpleRunnable) {
            @Override
            public void run() {
                simpleRunnable.run();

                if (taskAsyncHandler == null) {
                    return;
                }
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        taskAsyncHandler.onFinished();
                    }
                });

            }
        });
    }
}
