package com.esunny.data.util.simplethread;

import java.util.concurrent.TimeUnit;

public class ThreadPoolConstant {
    private static final int MIN_POOL_SIZE = 2;

    private static final int AVAILABLE_CORE = Runtime.getRuntime().availableProcessors();

    private static final int CPU_COUNT = (AVAILABLE_CORE < MIN_POOL_SIZE) ? MIN_POOL_SIZE : AVAILABLE_CORE;

    public static final TimeUnit EXECUTOR_TIME_UNIT = TimeUnit.SECONDS;

    public static final int NORMAL_CORE_POOL_SIZE = 0 ;
    public static final int NORMAL_MAXIMUM_POOL_SIZE = Integer.MAX_VALUE;
    public static final long NORMAL_KEEP_ALIVE_TIME = 60L;
}
