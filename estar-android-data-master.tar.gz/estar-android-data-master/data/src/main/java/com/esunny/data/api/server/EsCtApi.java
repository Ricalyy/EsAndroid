package com.esunny.data.api.server;

import com.alibaba.android.arouter.facade.template.IProvider;

public interface EsCtApi extends IProvider {

    int getSystemInfo(String api, EsSystemInfo.SystemInfoCallback callback);
}
