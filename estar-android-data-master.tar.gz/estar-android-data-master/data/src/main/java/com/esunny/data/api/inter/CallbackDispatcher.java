package com.esunny.data.api.inter;


import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.event.AbstractEvent;
import com.esunny.data.util.simplethread.SimpleRunnable;
import com.esunny.data.util.simplethread.TaskManager;
import com.esunny.mobile.bean.CspSessionHead;

import org.greenrobot.eventbus.EventBus;

public abstract class CallbackDispatcher {

    // Event
    protected final static char EVENT_TCP_CONNECT = 'C';
    protected final static char EVENT_TCP_DISCONNECT = 'D';
    protected final static char EVENT_TCP_RECV_DATA = 'R';
    protected final static char EVENT_TCP_RESET_DATA = 'S';

    protected int mPtr;

    public abstract int dispatch(char action, byte[] data);

    public void setClient(int ptr) {
        this.mPtr = ptr;
    }

    protected void sendEvent(final AbstractEvent event) {
        SimpleRunnable simpleRunnable = new SimpleRunnable() {
            @Override
            public void run() {
                EventBus.getDefault().post(event);
            }
        };

        TaskManager.getInstance().execute(simpleRunnable);
    }

    public int sendTcpMsg(char type, CspSessionHead head, byte[] data) {
        return EsBaseApi.getInstance().sendMsg(mPtr, type, head, data);
    }
}
