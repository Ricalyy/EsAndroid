package com.esunny.data.api.event;

/**
 *  当所有子类替换父类之后，该类需调整为Abstract类型。
 */
public class EsEventMessage extends AbstractEvent {
    protected Builder builder;

    public EsEventMessage(Builder builder) {
        this.builder = builder;
    }

    @Deprecated
    public EsEventMessage(int sender, int action) {
        builder = new Builder(action) {
            @Override
            public EsEventMessage buildEvent() {
                return new EsEventMessage(this);
            }
        };
        builder.setSender(sender);
    }

    @Deprecated
    public EsEventMessage(int sender, int action, String content) {
        builder = new Builder(action) {
            @Override
            public EsEventMessage buildEvent() {
                return new EsEventMessage(this);
            }
        };
        builder.setSender(sender);
        builder.setContent(content);
    }

    @Deprecated
    public EsEventMessage(int sender, int action, Object data) {
        builder = new Builder(action) {
            @Override
            public EsEventMessage buildEvent() {
                return new EsEventMessage(this);
            }
        };
        builder.setSender(sender);
        builder.setData(data);
    }

    @Deprecated
    public EsEventMessage(int sender, int action, String content, Object data) {
        builder = new Builder(action) {
            @Override
            public EsEventMessage buildEvent() {
                return new EsEventMessage(this);
            }
        };
        builder.setSender(sender);
        builder.setData(data);
        builder.setContent(content);
    }

    public static class Builder extends AbstractEventBuilder<EsEventMessage> {

        String content;

        public Builder(int action) {
            setAction(action);
        }

        @Override
        public EsEventMessage.Builder setSender(int sender) {
            return (EsEventMessage.Builder) super.setSender(sender);
        }

        @Override
        public EsEventMessage.Builder setAction(int action) {
            return (EsEventMessage.Builder) super.setAction(action);
        }

        @Override
        public EsEventMessage.Builder setData(Object data) {
            return (EsEventMessage.Builder) super.setData(data);
        }

        public EsEventMessage.Builder setContent(String content) {
            this.content = content;
            return this;
        }

        @Override
        public EsEventMessage buildEvent() {
            return new EsEventMessage(this);
        }
    }

    @Override
    public int getSender() {
        return builder.mSender;
    }

    @Override
    public int getAction() {
        return builder.mAction;
    }

    @Override
    public Object getData() {
        return builder.mData;
    }

    public String getContent() {
        return builder.content;
    }

}
