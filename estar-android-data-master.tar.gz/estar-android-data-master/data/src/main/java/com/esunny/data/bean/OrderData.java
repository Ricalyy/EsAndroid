package com.esunny.data.bean;

import com.esunny.data.api.EsDataApi;

import java.io.Serializable;
import java.math.BigInteger;

public class OrderData implements Serializable {
    private long OrderReqId;         //报单请求号
    private long ParentReqId;         //报单请求号

    private String OrderNo;            //委托号
    private String LocalNo;            //本地号
    private String SystemNo;           //系统号
    private String SeatNo;             //席位号

    private String CompanyNo;          //经纪公司编号
    private String UserNo;             //资金帐号
    private String AddressNo;          //地址号
    private String ContractNo;         //合约编号

    private String InsertNo;           //下单人
    private String InsertDateTime;     //下单时间
    private String UpdateNo;           //最后一次变更人
    private String UpdateDateTime;     //最后一次变更时间

    private char OrderType;          //定单类型
    private char OrderWay;           //委托来源
    private char ValidType;          //有效类型
    private String ValidTime;          //有效日期时间(GTD情况下使用)
    private char Direct;             //买卖方向
    private char Offset;             //开仓 平仓 开平 平开(内盘)
    private char Hedge;              //投机保值 投保 保投(内盘)

    private double OrderPrice;         //委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
    private double OrderPriceOver;     //委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)

    private java.math.BigInteger OrderQty;           //委托数量 或 期权应价数量

    private double MatchPrice;         //成交价
    private java.math.BigInteger MatchQty;           //成交量
    private char OrderState;         //委托状态

    private char StrategyType;       //策略类型
    private char OrderPriceType;     //委托价格类型(指定价 最新价 挂单价 对盘价 市价价，只有指定价时委托价格字段才有效)(限策略单使用)

    //时间条件
    private String TimeCondition;      //时间条件(HH:MM:SS)

    private double TriggerPrice;       //触发价格
    private char TriggerMode;        //触发模式
    private char TriggerCondition;   //触发条件

    private String ParentNo;          // 父单号（普通单）
    private long StreamId;
    private boolean AutoCloseFlag;             //自对冲标记


    //价格条件2
    private double TriggerPrice2;      //触发价格2
    private char TriggerMode2;       //触发模式2
    private char TriggerCondition2;  //触发条件2

    //停损
    private char StopPriceType;      //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    private double StopPrice;          //止损止盈价或价差，具体含义由止损止盈价格类型字段决定
    private String SessionNo;          //会话标识
    private String OrderRef;           //报单引用

    private boolean AddOne;             //是否T+1
    private boolean IsDeleted;          //是否被删除
    private boolean IsRiskOrder;         //是否为强平单

    private int ErrorCode;          //错误码
    private String ErrorText;          //错误信息may_20180312

    private String StParentNo;        // 父单号（条件单）

    public long getOrderReqId() {
        return OrderReqId;
    }

    public void setOrderReqId(long orderReqId) {
        OrderReqId = orderReqId;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getLocalNo() {
        return LocalNo;
    }

    public void setLocalNo(String localNo) {
        LocalNo = localNo;
    }

    public String getSystemNo() {
        return SystemNo;
    }

    public void setSystemNo(String systemNo) {
        SystemNo = systemNo;
    }

    public String getSeatNo() {
        return SeatNo;
    }

    public void setSeatNo(String seatNo) {
        SeatNo = seatNo;
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getAddressNo() {
        return AddressNo;
    }

    public void setAddressNo(String addressNo) {
        AddressNo = addressNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public String getInsertNo() {
        return InsertNo;
    }

    public void setInsertNo(String insertNo) {
        InsertNo = insertNo;
    }

    public String getInsertDateTime() {
        return InsertDateTime;
    }

    public void setInsertDateTime(String insertDateTime) {
        InsertDateTime = insertDateTime;
    }

    public String getUpdateNo() {
        return UpdateNo;
    }

    public void setUpdateNo(String updateNo) {
        UpdateNo = updateNo;
    }

    public String getUpdateDateTime() {
        return UpdateDateTime;
    }

    public void setUpdateDateTime(String updateDateTime) {
        UpdateDateTime = updateDateTime;
    }

    public char getOrderType() {
        return OrderType;
    }

    public void setOrderType(char orderType) {
        OrderType = orderType;
    }

    public char getOrderWay() {
        return OrderWay;
    }

    public void setOrderWay(char orderWay) {
        OrderWay = orderWay;
    }

    public char getValidType() {
        return ValidType;
    }

    public void setValidType(char validType) {
        ValidType = validType;
    }

    public String getValidTime() {
        return ValidTime;
    }

    public void setValidTime(String validTime) {
        ValidTime = validTime;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public double getOrderPrice() {
        return OrderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        OrderPrice = orderPrice;
    }

    public double getOrderPriceOver() {
        return OrderPriceOver;
    }

    public void setOrderPriceOver(double orderPriceOver) {
        OrderPriceOver = orderPriceOver;
    }

    public BigInteger getOrderQty() {
        return OrderQty;
    }

    public void setOrderQty(BigInteger orderQty) {
        OrderQty = orderQty;
    }

    public double getMatchPrice() {
        return MatchPrice;
    }

    public void setMatchPrice(double matchPrice) {
        MatchPrice = matchPrice;
    }

    public BigInteger getMatchQty() {
        return MatchQty;
    }

    public void setMatchQty(BigInteger matchQty) {
        MatchQty = matchQty;
    }

    public char getOrderState() {
        return OrderState;
    }

    public void setOrderState(char orderState) {
        OrderState = orderState;
    }

    public char getStrategyType() {
        return StrategyType;
    }

    public void setStrategyType(char strategyType) {
        StrategyType = strategyType;
    }

    public char getOrderPriceType() {
        return OrderPriceType;
    }

    public void setOrderPriceType(char orderPriceType) {
        OrderPriceType = orderPriceType;
    }

    public String getTimeCondition() {
        return TimeCondition;
    }

    public void setTimeCondition(String timeCondition) {
        TimeCondition = timeCondition;
    }

    public double getTriggerPrice() {
        return TriggerPrice;
    }

    public void setTriggerPrice(double triggerPrice) {
        TriggerPrice = triggerPrice;
    }

    public char getTriggerMode() {
        return TriggerMode;
    }

    public void setTriggerMode(char triggerMode) {
        TriggerMode = triggerMode;
    }

    public char getTriggerCondition() {
        return TriggerCondition;
    }

    public void setTriggerCondition(char triggerCondition) {
        TriggerCondition = triggerCondition;
    }

    public double getTriggerPrice2() {
        return TriggerPrice2;
    }

    public void setTriggerPrice2(double triggerPrice2) {
        TriggerPrice2 = triggerPrice2;
    }

    public char getTriggerMode2() {
        return TriggerMode2;
    }

    public void setTriggerMode2(char triggerMode2) {
        TriggerMode2 = triggerMode2;
    }

    public char getTriggerCondition2() {
        return TriggerCondition2;
    }

    public void setTriggerCondition2(char triggerCondition2) {
        TriggerCondition2 = triggerCondition2;
    }

    public char getStopPriceType() {
        return StopPriceType;
    }

    public void setStopPriceType(char stopPriceType) {
        StopPriceType = stopPriceType;
    }

    public double getStopPrice() {
        return StopPrice;
    }

    public void setStopPrice(double stopPrice) {
        StopPrice = stopPrice;
    }

    public String getSessionNo() {
        return SessionNo;
    }

    public void setSessionNo(String sessionNo) {
        SessionNo = sessionNo;
    }

    public String getOrderRef() {
        return OrderRef;
    }

    public void setOrderRef(String orderRef) {
        OrderRef = orderRef;
    }

    public boolean isAddOne() {
        return AddOne;
    }

    public void setAddOne(boolean addOne) {
        AddOne = addOne;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return EsDataApi.getErrorMessage(AddressNo, ErrorCode, ErrorText);
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }


    public String getParentNo() {
        return ParentNo;
    }

    public void setParentNo(String parentNo) {
        ParentNo = parentNo;
    }

    public long getStreamId() {
        return StreamId;
    }

    public void setStreamId(long streamId) {
        StreamId = streamId;
    }

    public long getParentReqId() {
        return ParentReqId;
    }

    public void setParentReqId(long parentReqId) {
        ParentReqId = parentReqId;
    }

    public boolean isAutoCloseFlag() {
        return AutoCloseFlag;
    }

    public void setAutoCloseFlag(boolean autoCloseFlag) {
        AutoCloseFlag = autoCloseFlag;
    }

    public boolean isDeleted() {
        return IsDeleted;
    }

    public void setDeleted(boolean deleted) {
        IsDeleted = deleted;
    }

    public boolean isRiskOrder() {
        return IsRiskOrder;
    }

    public void setRiskOrder(boolean riskOrder) {
        IsRiskOrder = riskOrder;
    }

    public String getStParentNo() {
        return StParentNo;
    }

    public void setStParentNo(String stParentNo) {
        StParentNo = stParentNo;
    }

    @Override
    public String toString() {
        return OrderNo;
    }
}
