package com.esunny.mobile.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/9/23
 */
public class CspFrameHead extends ApiStruct {

    public final static int STRUCT_LENGTH = 4;

    private char FrameFlag;          //数据帧头标识
    private char FrameType;          //数据帧类型
    private short FrameSize;          //数据帧长度(0-32K)

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.putChar(FrameFlag);
        buffer.putChar(FrameType);
        buffer.putShort(FrameSize);
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setFrameFlag(util.getChar());
        setFrameType(util.getChar());
        setFrameSize(util.getShort());

    }

    public char getFrameFlag() {
        return FrameFlag;
    }

    public void setFrameFlag(char frameFlag) {
        FrameFlag = frameFlag;
    }

    public char getFrameType() {
        return FrameType;
    }

    public void setFrameType(char frameType) {
        FrameType = frameType;
    }

    public short getFrameSize() {
        return FrameSize;
    }

    public void setFrameSize(short frameSize) {
        FrameSize = frameSize;
    }
}
