package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class PushClientInfo {
    private String AppId;                              //App Id
    private String AppKey;                             //App Key
    private String AppMasterSecret;                    //App Master Secret
    private String CID;                                //设备client id
    private char                             DeviceType;                         //设备类型 Android IOS
    private int                                 LangType;                           //设备系统语言

    public String getAppId() {
        return AppId;
    }

    public void setAppId(String appId) {
        AppId = appId;
    }

    public String getAppKey() {
        return AppKey;
    }

    public void setAppKey(String appKey) {
        AppKey = appKey;
    }

    public String getAppMasterSecret() {
        return AppMasterSecret;
    }

    public void setAppMasterSecret(String appMasterSecret) {
        AppMasterSecret = appMasterSecret;
    }

    public String getCID() {
        return CID;
    }

    public void setCID(String CID) {
        this.CID = CID;
    }

    public char getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(char deviceType) {
        DeviceType = deviceType;
    }

    public int getLangType() {
        return LangType;
    }

    public void setLangType(int langType) {
        LangType = langType;
    }
}
