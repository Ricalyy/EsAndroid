package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/22
 */
public class Exchange {
    private String exchangeNo;
    private String exchangeName;

    public String getExchangeNo() {
        return exchangeNo;
    }

    public void setExchangeNo(String exchangeNo) {
        this.exchangeNo = exchangeNo;
    }

    public String getExchangeName() {
        return exchangeName;
    }

    public void setExchangeName(String exchangeName) {
        this.exchangeName = exchangeName;
    }
}
