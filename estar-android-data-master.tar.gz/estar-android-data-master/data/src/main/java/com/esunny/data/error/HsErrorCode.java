package com.esunny.data.error;

import android.content.Context;

import com.esunny.data.R;

class HsErrorCode {

    static String getErrorMessage(Context context, int errorCode) {

        switch (errorCode) {

            case 0 :
                return context.getResources().getString(R.string.hs_0);
            case 1 :
                return context.getResources().getString(R.string.hs_1);
            case 2 :
                return context.getResources().getString(R.string.hs_2);
            case 3 :
                return context.getResources().getString(R.string.hs_3);
            case 4 :
                return context.getResources().getString(R.string.hs_4);
            case 5 :
                return context.getResources().getString(R.string.hs_5);
            case 6 :
                return context.getResources().getString(R.string.hs_6);
            case 7 :
                return context.getResources().getString(R.string.hs_7);
            case 8 :
                return context.getResources().getString(R.string.hs_8);
            case 9 :
                return context.getResources().getString(R.string.hs_9);
            case 10 :
                return context.getResources().getString(R.string.hs_10);
            case 11 :
                return context.getResources().getString(R.string.hs_11);
            case 12 :
                return context.getResources().getString(R.string.hs_12);
            case 13 :
                return context.getResources().getString(R.string.hs_13);
            case 14 :
                return context.getResources().getString(R.string.hs_14);
            case 15 :
                return context.getResources().getString(R.string.hs_15);
            case 16 :
                return context.getResources().getString(R.string.hs_16);
            case 17 :
                return context.getResources().getString(R.string.hs_17);
            case 18 :
                return context.getResources().getString(R.string.hs_18);
            case 19 :
                return context.getResources().getString(R.string.hs_19);
            case 20 :
                return context.getResources().getString(R.string.hs_20);
            case 21 :
                return context.getResources().getString(R.string.hs_21);
            case 22 :
                return context.getResources().getString(R.string.hs_22);
            case 23 :
                return context.getResources().getString(R.string.hs_23);
            case 24 :
                return context.getResources().getString(R.string.hs_24);
            case 25 :
                return context.getResources().getString(R.string.hs_25);
            case 26 :
                return context.getResources().getString(R.string.hs_26);
            case 27 :
                return context.getResources().getString(R.string.hs_27);
            case 28 :
                return context.getResources().getString(R.string.hs_28);
            case 29 :
                return context.getResources().getString(R.string.hs_29);
            case 30 :
                return context.getResources().getString(R.string.hs_30);
            case -1 :
                return context.getResources().getString(R.string.hs_n1);
            case -2 :
                return context.getResources().getString(R.string.hs_n2);
            case -3 :
                return context.getResources().getString(R.string.hs_n3);
            case -4 :
                return context.getResources().getString(R.string.hs_n4);
            case -5 :
                return context.getResources().getString(R.string.hs_n5);
            case -6 :
                return context.getResources().getString(R.string.hs_n6);
            case -7 :
                return context.getResources().getString(R.string.hs_n7);
            case -8 :
                return context.getResources().getString(R.string.hs_n8);
            case -9 :
                return context.getResources().getString(R.string.hs_n9);
            case -10 :
                return context.getResources().getString(R.string.hs_n10);
            case -11 :
                return context.getResources().getString(R.string.hs_n11);
            case -12 :
                return context.getResources().getString(R.string.hs_n12);
            case -13 :
                return context.getResources().getString(R.string.hs_n13);
            case -14 :
                return context.getResources().getString(R.string.hs_n14);
            case -15 :
                return context.getResources().getString(R.string.hs_n15);
            case -16 :
                return context.getResources().getString(R.string.hs_n16);
            case -17 :
                return context.getResources().getString(R.string.hs_n17);
            case -18 :
                return context.getResources().getString(R.string.hs_n18);
            case -19 :
                return context.getResources().getString(R.string.hs_n19);
            case -20 :
                return context.getResources().getString(R.string.hs_n20);
            case -21 :
                return context.getResources().getString(R.string.hs_n21);
            case -22 :
                return context.getResources().getString(R.string.hs_n22);
            case -23 :
                return context.getResources().getString(R.string.hs_n23);
            case -24 :
                return context.getResources().getString(R.string.hs_n24);
            case -25 :
                return context.getResources().getString(R.string.hs_n25);
            case -26 :
                return context.getResources().getString(R.string.hs_n26);
            case -27 :
                return context.getResources().getString(R.string.hs_n27);
            case -28 :
                return context.getResources().getString(R.string.hs_n28);
            case -29 :
                return context.getResources().getString(R.string.hs_n29);
            case -30 :
                return context.getResources().getString(R.string.hs_n30);
            case -31 :
                return context.getResources().getString(R.string.hs_n31);
            case -32 :
                return context.getResources().getString(R.string.hs_n32);
            case -33 :
                return context.getResources().getString(R.string.hs_n33);
            case -34 :
                return context.getResources().getString(R.string.hs_n34);
            case -35 :
                return context.getResources().getString(R.string.hs_n35);
            case -36 :
                return context.getResources().getString(R.string.hs_n36);
            case -37 :
                return context.getResources().getString(R.string.hs_n37);
            case -38 :
                return context.getResources().getString(R.string.hs_n38);
            case -39 :
                return context.getResources().getString(R.string.hs_n39);
            case -40 :
                return context.getResources().getString(R.string.hs_n40);
            case -41 :
                return context.getResources().getString(R.string.hs_n41);
            case -42 :
                return context.getResources().getString(R.string.hs_n42);
            case -43 :
                return context.getResources().getString(R.string.hs_n43);
            case -44 :
                return context.getResources().getString(R.string.hs_n44);
            case -45 :
                return context.getResources().getString(R.string.hs_n45);
            case -46 :
                return context.getResources().getString(R.string.hs_n46);
            case -47 :
                return context.getResources().getString(R.string.hs_n47);
            case -48 :
                return context.getResources().getString(R.string.hs_n48);
            case -49 :
                return context.getResources().getString(R.string.hs_n49);
            case -50 :
                return context.getResources().getString(R.string.hs_n50);
            case -51 :
                return context.getResources().getString(R.string.hs_n51);
            case -52 :
                return context.getResources().getString(R.string.hs_n52);
            case -53 :
                return context.getResources().getString(R.string.hs_n53);
            case -54 :
                return context.getResources().getString(R.string.hs_n54);
            case -55 :
                return context.getResources().getString(R.string.hs_n55);
            case -56 :
                return context.getResources().getString(R.string.hs_n56);
            case -57 :
                return context.getResources().getString(R.string.hs_n57);
            case -58 :
                return context.getResources().getString(R.string.hs_n58);
            case -60 :
                return context.getResources().getString(R.string.hs_n60);
            case -62 :
                return context.getResources().getString(R.string.hs_n62);
            case -63 :
                return context.getResources().getString(R.string.hs_n63);
            case -64 :
                return context.getResources().getString(R.string.hs_n64);
            case -71 :
                return context.getResources().getString(R.string.hs_n71);
            case -101 :
                return context.getResources().getString(R.string.hs_n101);
            case -102 :
                return context.getResources().getString(R.string.hs_n102);
            case -103 :
                return context.getResources().getString(R.string.hs_n103);
            case -104 :
                return context.getResources().getString(R.string.hs_n104);
            case -105 :
                return context.getResources().getString(R.string.hs_n105);
            case -106 :
                return context.getResources().getString(R.string.hs_n106);
            case -107 :
                return context.getResources().getString(R.string.hs_n107);
            case -108 :
                return context.getResources().getString(R.string.hs_n108);
            case -109 :
                return context.getResources().getString(R.string.hs_n109);
            case -110 :
                return context.getResources().getString(R.string.hs_n110);
            case -111 :
                return context.getResources().getString(R.string.hs_n111);
            case -112 :
                return context.getResources().getString(R.string.hs_n112);
            case -113 :
                return context.getResources().getString(R.string.hs_n113);
            case -114 :
                return context.getResources().getString(R.string.hs_n114);
            case -115 :
                return context.getResources().getString(R.string.hs_n115);
            case -116 :
                return context.getResources().getString(R.string.hs_n116);
            case -117 :
                return context.getResources().getString(R.string.hs_n117);
            case -118 :
                return context.getResources().getString(R.string.hs_n118);
            case -119 :
                return context.getResources().getString(R.string.hs_n119);
            case -120 :
                return context.getResources().getString(R.string.hs_n120);
            case -121 :
                return context.getResources().getString(R.string.hs_n121);
            case -122 :
                return context.getResources().getString(R.string.hs_n122);
            case -123 :
                return context.getResources().getString(R.string.hs_n123);
            case -124 :
                return context.getResources().getString(R.string.hs_n124);
            case -125 :
                return context.getResources().getString(R.string.hs_n125);
            case -126 :
                return context.getResources().getString(R.string.hs_n126);
            case -127 :
                return context.getResources().getString(R.string.hs_n127);
            case -128 :
                return context.getResources().getString(R.string.hs_n128);
            case -129 :
                return context.getResources().getString(R.string.hs_n129);
            case -130 :
                return context.getResources().getString(R.string.hs_n130);
            case -131 :
                return context.getResources().getString(R.string.hs_n131);
            case -132 :
                return context.getResources().getString(R.string.hs_n132);
            case -133 :
                return context.getResources().getString(R.string.hs_n133);
            case -134 :
                return context.getResources().getString(R.string.hs_n134);
            case -135 :
                return context.getResources().getString(R.string.hs_n135);
            case -136 :
                return context.getResources().getString(R.string.hs_n136);
            case -137 :
                return context.getResources().getString(R.string.hs_n137);
            case -138 :
                return context.getResources().getString(R.string.hs_n138);
            case -139 :
                return context.getResources().getString(R.string.hs_n139);
            case -140 :
                return context.getResources().getString(R.string.hs_n140);
            case -141 :
                return context.getResources().getString(R.string.hs_n141);
            case -142 :
                return context.getResources().getString(R.string.hs_n142);
            case -143 :
                return context.getResources().getString(R.string.hs_n143);
            case -144 :
                return context.getResources().getString(R.string.hs_n144);
            case -145 :
                return context.getResources().getString(R.string.hs_n145);
            case -146 :
                return context.getResources().getString(R.string.hs_n146);
            case -147 :
                return context.getResources().getString(R.string.hs_n147);
            case -148 :
                return context.getResources().getString(R.string.hs_n148);
            case -149 :
                return context.getResources().getString(R.string.hs_n149);
            case -150 :
                return context.getResources().getString(R.string.hs_n150);
            case -151 :
                return context.getResources().getString(R.string.hs_n151);
            case -152 :
                return context.getResources().getString(R.string.hs_n152);
            case -153 :
                return context.getResources().getString(R.string.hs_n153);
            case -154 :
                return context.getResources().getString(R.string.hs_n154);
            case -155 :
                return context.getResources().getString(R.string.hs_n155);
            case -156 :
                return context.getResources().getString(R.string.hs_n156);
            case -157 :
                return context.getResources().getString(R.string.hs_n157);
            case -158 :
                return context.getResources().getString(R.string.hs_n158);
            case -159 :
                return context.getResources().getString(R.string.hs_n159);
            case -160 :
                return context.getResources().getString(R.string.hs_n160);
            case -161 :
                return context.getResources().getString(R.string.hs_n161);
            case -162 :
                return context.getResources().getString(R.string.hs_n162);
            case -163 :
                return context.getResources().getString(R.string.hs_n163);
            case -164 :
                return context.getResources().getString(R.string.hs_n164);
            case -165 :
                return context.getResources().getString(R.string.hs_n165);
            case -166 :
                return context.getResources().getString(R.string.hs_n166);
            case -167 :
                return context.getResources().getString(R.string.hs_n167);
            case -168 :
                return context.getResources().getString(R.string.hs_n168);
            case -169 :
                return context.getResources().getString(R.string.hs_n169);
            case -170 :
                return context.getResources().getString(R.string.hs_n170);
            case -171 :
                return context.getResources().getString(R.string.hs_n171);
            case -172 :
                return context.getResources().getString(R.string.hs_n172);
            case -173 :
                return context.getResources().getString(R.string.hs_n173);
            case -174 :
                return context.getResources().getString(R.string.hs_n174);
            case -175 :
                return context.getResources().getString(R.string.hs_n175);
            case -176 :
                return context.getResources().getString(R.string.hs_n176);
            case -177 :
                return context.getResources().getString(R.string.hs_n177);
            case -178 :
                return context.getResources().getString(R.string.hs_n178);
            case -179 :
                return context.getResources().getString(R.string.hs_n179);
            case -180 :
                return context.getResources().getString(R.string.hs_n180);
            case -181 :
                return context.getResources().getString(R.string.hs_n181);
            case -182 :
                return context.getResources().getString(R.string.hs_n182);
            case -183 :
                return context.getResources().getString(R.string.hs_n183);
            case -184 :
                return context.getResources().getString(R.string.hs_n184);
            case -185 :
                return context.getResources().getString(R.string.hs_n185);
            case 1001 :
                return context.getResources().getString(R.string.hs_1001);
            case 1018 :
                return context.getResources().getString(R.string.hs_1018);
            case 1019 :
                return context.getResources().getString(R.string.hs_1019);
            case 1024 :
                return context.getResources().getString(R.string.hs_1024);
            case 1201 :
                return context.getResources().getString(R.string.hs_1201);
            case 1206 :
                return context.getResources().getString(R.string.hs_1206);
            case 1219 :
                return context.getResources().getString(R.string.hs_1219);
            case 1250 :
                return context.getResources().getString(R.string.hs_1250);
            case 1256 :
                return context.getResources().getString(R.string.hs_1256);
            case 1277 :
                return context.getResources().getString(R.string.hs_1277);
            case 1280 :
                return context.getResources().getString(R.string.hs_1280);
            case 2106 :
                return context.getResources().getString(R.string.hs_2106);
            case 2117 :
                return context.getResources().getString(R.string.hs_2117);
            case 50006 :
                return context.getResources().getString(R.string.hs_50006);
            case 50412 :
                return context.getResources().getString(R.string.hs_50412);
            case 100332 :
                return context.getResources().getString(R.string.hs_100332);
            case 100396 :
                return context.getResources().getString(R.string.hs_100396);
            case 100523 :
                return context.getResources().getString(R.string.hs_100523);
            case 100528 :
                return context.getResources().getString(R.string.hs_100528);
            case 150001 :
                return context.getResources().getString(R.string.hs_150001);
            case 150006 :
                return context.getResources().getString(R.string.hs_150006);
            case 150011 :
                return context.getResources().getString(R.string.hs_150011);
            case 105097 :
                return context.getResources().getString(R.string.hs_105097);
            case 105302 :
                return context.getResources().getString(R.string.hs_105302);
            case 112005 :
                return context.getResources().getString(R.string.hs_112005);
            case 112010 :
                return context.getResources().getString(R.string.hs_112010);
            case 112011 :
                return context.getResources().getString(R.string.hs_112011);
            case 112085 :
                return context.getResources().getString(R.string.hs_112085);
            case 120022 :
                return context.getResources().getString(R.string.hs_120022);
            case 120039 :
                return context.getResources().getString(R.string.hs_120039);
            case 120040 :
                return context.getResources().getString(R.string.hs_120040);
            case 120041 :
                return context.getResources().getString(R.string.hs_120041);
            case 120042 :
                return context.getResources().getString(R.string.hs_120042);
            case 120046 :
                return context.getResources().getString(R.string.hs_120046);
            case 150102 :
                return context.getResources().getString(R.string.hs_150102);
            case 162010 :
                return context.getResources().getString(R.string.hs_162010);
            case 200000 :
                return context.getResources().getString(R.string.hs_200000);
            case 200002 :
                return context.getResources().getString(R.string.hs_200002);
            case 200004 :
                return context.getResources().getString(R.string.hs_200004);
            case 200029 :
                return context.getResources().getString(R.string.hs_200029);
            case 200040 :
                return context.getResources().getString(R.string.hs_200040);
            case 200042 :
                return context.getResources().getString(R.string.hs_200042);
            case 200044 :
                return context.getResources().getString(R.string.hs_200044);
            case 200045 :
                return context.getResources().getString(R.string.hs_200045);
            case 200049 :
                return context.getResources().getString(R.string.hs_200049);
            case 200050 :
                return context.getResources().getString(R.string.hs_200050);
            case 200055 :
                return context.getResources().getString(R.string.hs_200055);
            case 200057 :
                return context.getResources().getString(R.string.hs_200057);
            case 200059 :
                return context.getResources().getString(R.string.hs_200059);
            case 200069 :
                return context.getResources().getString(R.string.hs_200069);
            case 200084 :
                return context.getResources().getString(R.string.hs_200084);
            case 200089 :
                return context.getResources().getString(R.string.hs_200089);
            case 200094 :
                return context.getResources().getString(R.string.hs_200094);
            case 200500 :
                return context.getResources().getString(R.string.hs_200500);
            case 200502 :
                return context.getResources().getString(R.string.hs_200502);
            case 200503 :
                return context.getResources().getString(R.string.hs_200503);
            case 200505 :
                return context.getResources().getString(R.string.hs_200505);
            case 200507 :
                return context.getResources().getString(R.string.hs_200507);
            case 200557 :
                return context.getResources().getString(R.string.hs_200557);
            case 202500 :
                return context.getResources().getString(R.string.hs_202500);
            case 202501 :
                return context.getResources().getString(R.string.hs_202501);
            case 202502 :
                return context.getResources().getString(R.string.hs_202502);
            case 202522 :
                return context.getResources().getString(R.string.hs_202522);
            case 202523 :
                return context.getResources().getString(R.string.hs_202523);
            case 250006 :
                return context.getResources().getString(R.string.hs_250006);
            case 250012 :
                return context.getResources().getString(R.string.hs_250012);
            case 250018 :
                return context.getResources().getString(R.string.hs_250018);
            case 250022 :
                return context.getResources().getString(R.string.hs_250022);
            case 250024 :
                return context.getResources().getString(R.string.hs_250024);
            case 250028 :
                return context.getResources().getString(R.string.hs_250028);
            case 250040 :
                return context.getResources().getString(R.string.hs_250040);
            case 250046 :
                return context.getResources().getString(R.string.hs_250046);
            case 250070 :
                return context.getResources().getString(R.string.hs_250070);
            case 250076 :
                return context.getResources().getString(R.string.hs_250076);
            case 250082 :
                return context.getResources().getString(R.string.hs_250082);
            case 250088 :
                return context.getResources().getString(R.string.hs_250088);
            case 250095 :
                return context.getResources().getString(R.string.hs_250095);
            case 250138 :
                return context.getResources().getString(R.string.hs_250138);
            case 250142 :
                return context.getResources().getString(R.string.hs_250142);
            case 250143 :
                return context.getResources().getString(R.string.hs_250143);
            case 250144 :
                return context.getResources().getString(R.string.hs_250144);
            case 250166 :
                return context.getResources().getString(R.string.hs_250166);
            case 250148 :
                return context.getResources().getString(R.string.hs_250148);
            case 250310 :
                return context.getResources().getString(R.string.hs_250310);
            case 250444 :
                return context.getResources().getString(R.string.hs_250444);
            case 250445 :
                return context.getResources().getString(R.string.hs_250445);
            case 250447 :
                return context.getResources().getString(R.string.hs_250447);
            case 250449 :
                return context.getResources().getString(R.string.hs_250449);
            case 250468 :
                return context.getResources().getString(R.string.hs_250468);
            case 250470 :
                return context.getResources().getString(R.string.hs_250470);
            case 250474 :
                return context.getResources().getString(R.string.hs_250474);
            case 250511 :
                return context.getResources().getString(R.string.hs_250511);
            case 250512 :
                return context.getResources().getString(R.string.hs_250512);
            case 250516 :
                return context.getResources().getString(R.string.hs_250516);
            case 250522 :
                return context.getResources().getString(R.string.hs_250522);
            case 250527 :
                return context.getResources().getString(R.string.hs_250527);
            case 250583 :
                return context.getResources().getString(R.string.hs_250583);
            case 250585 :
                return context.getResources().getString(R.string.hs_250585);
            case 251000 :
                return context.getResources().getString(R.string.hs_251000);
            case 251003 :
                return context.getResources().getString(R.string.hs_251003);
            case 251006 :
                return context.getResources().getString(R.string.hs_251006);
            case 251005 :
                return context.getResources().getString(R.string.hs_251005);
            case 251008 :
                return context.getResources().getString(R.string.hs_251008);
            case 251010 :
                return context.getResources().getString(R.string.hs_251010);
            case 251011 :
                return context.getResources().getString(R.string.hs_251011);
            case 251013 :
                return context.getResources().getString(R.string.hs_251013);
            case 251014 :
                return context.getResources().getString(R.string.hs_251014);
            case 251015 :
                return context.getResources().getString(R.string.hs_251015);
            case 251016 :
                return context.getResources().getString(R.string.hs_251016);
            case 251017 :
                return context.getResources().getString(R.string.hs_251017);
            case 251018 :
                return context.getResources().getString(R.string.hs_251018);
            case 251019 :
                return context.getResources().getString(R.string.hs_251019);
            case 251020 :
                return context.getResources().getString(R.string.hs_251020);
            case 251021 :
                return context.getResources().getString(R.string.hs_251021);
            case 251022 :
                return context.getResources().getString(R.string.hs_251022);
            case 251023 :
                return context.getResources().getString(R.string.hs_251023);
            case 251024 :
                return context.getResources().getString(R.string.hs_251024);
            case 251025 :
                return context.getResources().getString(R.string.hs_251025);
            case 251027 :
                return context.getResources().getString(R.string.hs_251027);
            case 251028 :
                return context.getResources().getString(R.string.hs_251028);
            case 251029 :
                return context.getResources().getString(R.string.hs_251029);
            case 251030 :
                return context.getResources().getString(R.string.hs_251030);
            case 251031 :
                return context.getResources().getString(R.string.hs_251031);
            case 251032 :
                return context.getResources().getString(R.string.hs_251032);
            case 251033 :
                return context.getResources().getString(R.string.hs_251033);
            case 251035 :
                return context.getResources().getString(R.string.hs_251035);
            case 251051 :
                return context.getResources().getString(R.string.hs_251051);
            case 251057 :
                return context.getResources().getString(R.string.hs_251057);
            case 251058 :
                return context.getResources().getString(R.string.hs_251058);
            case 251131 :
                return context.getResources().getString(R.string.hs_251131);
            case 251132 :
                return context.getResources().getString(R.string.hs_251132);
            case 251133 :
                return context.getResources().getString(R.string.hs_251133);
            case 251168 :
                return context.getResources().getString(R.string.hs_251168);
            case 251176 :
                return context.getResources().getString(R.string.hs_251176);
            case 251178 :
                return context.getResources().getString(R.string.hs_251178);
            case 251182 :
                return context.getResources().getString(R.string.hs_251182);
            case 251183 :
                return context.getResources().getString(R.string.hs_251183);
            case 251192 :
                return context.getResources().getString(R.string.hs_251192);
            case 251212 :
                return context.getResources().getString(R.string.hs_251212);
            case 251213 :
                return context.getResources().getString(R.string.hs_251213);
            case 251214 :
                return context.getResources().getString(R.string.hs_251214);
            case 251215 :
                return context.getResources().getString(R.string.hs_251215);
            case 251216 :
                return context.getResources().getString(R.string.hs_251216);
            case 251217 :
                return context.getResources().getString(R.string.hs_251217);
            case 251218 :
                return context.getResources().getString(R.string.hs_251218);
            case 251221 :
                return context.getResources().getString(R.string.hs_251221);
            case 251229 :
                return context.getResources().getString(R.string.hs_251229);
            case 251231 :
                return context.getResources().getString(R.string.hs_251231);
            case 251232 :
                return context.getResources().getString(R.string.hs_251232);
            case 251233 :
                return context.getResources().getString(R.string.hs_251233);
            case 251250 :
                return context.getResources().getString(R.string.hs_251250);
            case 251261 :
                return context.getResources().getString(R.string.hs_251261);
            case 251265 :
                return context.getResources().getString(R.string.hs_251265);
            case 251286 :
                return context.getResources().getString(R.string.hs_251286);
            case 252032 :
                return context.getResources().getString(R.string.hs_252032);
            case 254011 :
                return context.getResources().getString(R.string.hs_254011);
            case 254012 :
                return context.getResources().getString(R.string.hs_254012);
            case 254051 :
                return context.getResources().getString(R.string.hs_254051);
            case 254056 :
                return context.getResources().getString(R.string.hs_254056);
            case 254057 :
                return context.getResources().getString(R.string.hs_254057);
            case 302519 :
                return context.getResources().getString(R.string.hs_302519);
            case 312954 :
                return context.getResources().getString(R.string.hs_312954);
            case 330011 :
                return context.getResources().getString(R.string.hs_330011);
            case 331004 :
                return context.getResources().getString(R.string.hs_331004);
            case 331005 :
                return context.getResources().getString(R.string.hs_331005);
            case 331006 :
                return context.getResources().getString(R.string.hs_331006);
            case 331007 :
                return context.getResources().getString(R.string.hs_331007);
            case 331008 :
                return context.getResources().getString(R.string.hs_331008);
            case 331010 :
                return context.getResources().getString(R.string.hs_331010);
            case 331011 :
                return context.getResources().getString(R.string.hs_331011);
            case 331012 :
                return context.getResources().getString(R.string.hs_331012);
            case 331014 :
                return context.getResources().getString(R.string.hs_331014);
            case 331021 :
                return context.getResources().getString(R.string.hs_331021);
            case 331022 :
                return context.getResources().getString(R.string.hs_331022);
            case 331028 :
                return context.getResources().getString(R.string.hs_331028);
            case 331036 :
                return context.getResources().getString(R.string.hs_331036);
            case 331037 :
                return context.getResources().getString(R.string.hs_331037);
            case 331042 :
                return context.getResources().getString(R.string.hs_331042);
            case 331048 :
                return context.getResources().getString(R.string.hs_331048);
            case 331056 :
                return context.getResources().getString(R.string.hs_331056);
            case 331058 :
                return context.getResources().getString(R.string.hs_331058);
            case 331060 :
                return context.getResources().getString(R.string.hs_331060);
            case 331061 :
                return context.getResources().getString(R.string.hs_331061);
            case 331072 :
                return context.getResources().getString(R.string.hs_331072);
            case 331073 :
                return context.getResources().getString(R.string.hs_331073);
            case 331074 :
                return context.getResources().getString(R.string.hs_331074);
            case 331075 :
                return context.getResources().getString(R.string.hs_331075);
            case 331076 :
                return context.getResources().getString(R.string.hs_331076);
            case 331077 :
                return context.getResources().getString(R.string.hs_331077);
            case 331078 :
                return context.getResources().getString(R.string.hs_331078);
            case 331079 :
                return context.getResources().getString(R.string.hs_331079);
            case 331081 :
                return context.getResources().getString(R.string.hs_331081);
            case 341083 :
                return context.getResources().getString(R.string.hs_341083);
            case 331084 :
                return context.getResources().getString(R.string.hs_331084);
            case 331085 :
                return context.getResources().getString(R.string.hs_331085);
            case 341218 :
                return context.getResources().getString(R.string.hs_341218);
            case 341220 :
                return context.getResources().getString(R.string.hs_341220);
            case 341222 :
                return context.getResources().getString(R.string.hs_341222);
            case 341224 :
                return context.getResources().getString(R.string.hs_341224);
            case 348226 :
                return context.getResources().getString(R.string.hs_348226);
            case 348232 :
                return context.getResources().getString(R.string.hs_348232);
            case 349002 :
                return context.getResources().getString(R.string.hs_349002);
            case 349004 :
                return context.getResources().getString(R.string.hs_349004);
            case 349008 :
                return context.getResources().getString(R.string.hs_349008);
            case 349009 :
                return context.getResources().getString(R.string.hs_349009);
            case 349999 :
                return context.getResources().getString(R.string.hs_349999);
            case 390101 :
                return context.getResources().getString(R.string.hs_390101);
            case 390123 :
                return context.getResources().getString(R.string.hs_390123);
            case 390125 :
                return context.getResources().getString(R.string.hs_390125);
            case 390170 :
                return context.getResources().getString(R.string.hs_390170);
            case 390293 :
                return context.getResources().getString(R.string.hs_390293);
            case 390295 :
                return context.getResources().getString(R.string.hs_390295);
            case 514000 :
                return context.getResources().getString(R.string.hs_514000);
            case 514001 :
                return context.getResources().getString(R.string.hs_514001);
            case 514002 :
                return context.getResources().getString(R.string.hs_514002);
            case 514003 :
                return context.getResources().getString(R.string.hs_514003);
            case 514004 :
                return context.getResources().getString(R.string.hs_514004);
            case 514005 :
                return context.getResources().getString(R.string.hs_514005);
            case 51406  :
                return context.getResources().getString(R.string.hs_51406);
            case 514007 :
                return context.getResources().getString(R.string.hs_514007);
            case 514008 :
                return context.getResources().getString(R.string.hs_514008);
            case 514009 :
                return context.getResources().getString(R.string.hs_514009);
            case 514010 :
                return context.getResources().getString(R.string.hs_514010);
            case 514011 :
                return context.getResources().getString(R.string.hs_514011);
            case 514012 :
                return context.getResources().getString(R.string.hs_514012);
            case 514013 :
                return context.getResources().getString(R.string.hs_514013);
            case 514014 :
                return context.getResources().getString(R.string.hs_514014);
            case 514015 :
                return context.getResources().getString(R.string.hs_514015);
            case 514100 :
                return context.getResources().getString(R.string.hs_514100);
            case 514101 :
                return context.getResources().getString(R.string.hs_514101);
            case 514102 :
                return context.getResources().getString(R.string.hs_514102);
            case 514103 :
                return context.getResources().getString(R.string.hs_514103);
            case 514104 :
                return context.getResources().getString(R.string.hs_514104);
            case 514105 :
                return context.getResources().getString(R.string.hs_514105);
            case 514106 :
                return context.getResources().getString(R.string.hs_514106);
            case 514107 :
                return context.getResources().getString(R.string.hs_514107);
            case 514108 :
                return context.getResources().getString(R.string.hs_514108);
            case 514109 :
                return context.getResources().getString(R.string.hs_514109);
            case 514110 :
                return context.getResources().getString(R.string.hs_514110);
            case 514111 :
                return context.getResources().getString(R.string.hs_514111);
            case 514200 :
                return context.getResources().getString(R.string.hs_514200);
            case 514201 :
                return context.getResources().getString(R.string.hs_514201);
            case 514202 :
                return context.getResources().getString(R.string.hs_514202);
            case 514203 :
                return context.getResources().getString(R.string.hs_514203);
            case 514204 :
                return context.getResources().getString(R.string.hs_514204);
            case 514205 :
                return context.getResources().getString(R.string.hs_514205);
            case 514206 :
                return context.getResources().getString(R.string.hs_514206);
            case 514207 :
                return context.getResources().getString(R.string.hs_514207);
            case 514208 :
                return context.getResources().getString(R.string.hs_514208);
            case 514300 :
                return context.getResources().getString(R.string.hs_514300);
            case 514301 :
                return context.getResources().getString(R.string.hs_514301);
            case 514302 :
                return context.getResources().getString(R.string.hs_514302);
            case 514303 :
                return context.getResources().getString(R.string.hs_514303);
            case 514304 :
                return context.getResources().getString(R.string.hs_514304);
            case 514305 :
                return context.getResources().getString(R.string.hs_514305);
            case 514306 :
                return context.getResources().getString(R.string.hs_514306);
            case 514307 :
                return context.getResources().getString(R.string.hs_514307);
            case 514308 :
                return context.getResources().getString(R.string.hs_514308);
            case 514309 :
                return context.getResources().getString(R.string.hs_514309);
            case 514310 :
                return context.getResources().getString(R.string.hs_514310);
            case 514400 :
                return context.getResources().getString(R.string.hs_514400);
            case 514401 :
                return context.getResources().getString(R.string.hs_514401);
            case 514402 :
                return context.getResources().getString(R.string.hs_514402);
            case 514403 :
                return context.getResources().getString(R.string.hs_514403);
            case 514404 :
                return context.getResources().getString(R.string.hs_514404);
            case 514405 :
                return context.getResources().getString(R.string.hs_514405);
            case 514406 :
                return context.getResources().getString(R.string.hs_514406);
            case 514407 :
                return context.getResources().getString(R.string.hs_514407);
            case 514408 :
                return context.getResources().getString(R.string.hs_514408);
            case 514409 :
                return context.getResources().getString(R.string.hs_514409);
            case 514410 :
                return context.getResources().getString(R.string.hs_514410);
            case 514411 :
                return context.getResources().getString(R.string.hs_514411);
            case 514412 :
                return context.getResources().getString(R.string.hs_514412);
            case 514413 :
                return context.getResources().getString(R.string.hs_514413);
            case 514414 :
                return context.getResources().getString(R.string.hs_514414);
            case 514415 :
                return context.getResources().getString(R.string.hs_514415);
            case 514416 :
                return context.getResources().getString(R.string.hs_514416);
            case 514417 :
                return context.getResources().getString(R.string.hs_514417);
            case 514418 :
                return context.getResources().getString(R.string.hs_514418);
            case 514419 :
                return context.getResources().getString(R.string.hs_514419);
            case 514420 :
                return context.getResources().getString(R.string.hs_514420);
            case 514421 :
                return context.getResources().getString(R.string.hs_514421);
            case 514422 :
                return context.getResources().getString(R.string.hs_514422);
            case 514423 :
                return context.getResources().getString(R.string.hs_514423);
            case 514424 :
                return context.getResources().getString(R.string.hs_514424);
            case 514425 :
                return context.getResources().getString(R.string.hs_514425);
            case 514426 :
                return context.getResources().getString(R.string.hs_514426);
            case 514427 :
                return context.getResources().getString(R.string.hs_514427);
            case 514428 :
                return context.getResources().getString(R.string.hs_514428);
            case 514429 :
                return context.getResources().getString(R.string.hs_514429);
            case 514430 :
                return context.getResources().getString(R.string.hs_514430);
            case 514431 :
                return context.getResources().getString(R.string.hs_514431);
            case 514432 :
                return context.getResources().getString(R.string.hs_514432);
            case 514433 :
                return context.getResources().getString(R.string.hs_514433);
            case 514434 :
                return context.getResources().getString(R.string.hs_514434);
            case 514435 :
                return context.getResources().getString(R.string.hs_514435);
            case 514436 :
                return context.getResources().getString(R.string.hs_514436);
            case 514437 :
                return context.getResources().getString(R.string.hs_514437);
            case 514438 :
                return context.getResources().getString(R.string.hs_514438);
            case 514439 :
                return context.getResources().getString(R.string.hs_514439);
            case 514500 :
                return context.getResources().getString(R.string.hs_514500);
            case 514501 :
                return context.getResources().getString(R.string.hs_514501);
            case 514502 :
                return context.getResources().getString(R.string.hs_514502);
            case 514503 :
                return context.getResources().getString(R.string.hs_514503);
            case 514504 :
                return context.getResources().getString(R.string.hs_514504);
            case 514505 :
                return context.getResources().getString(R.string.hs_514505);
            case 514506 :
                return context.getResources().getString(R.string.hs_514506);
            case 514507 :
                return context.getResources().getString(R.string.hs_514507);
            case 514508 :
                return context.getResources().getString(R.string.hs_514508);
            case 514509 :
                return context.getResources().getString(R.string.hs_514509);
            case 514510 :
                return context.getResources().getString(R.string.hs_514510);
            case 514511 :
                return context.getResources().getString(R.string.hs_514511);
            case 514512 :
                return context.getResources().getString(R.string.hs_514512);
            case 514513 :
                return context.getResources().getString(R.string.hs_514513);
            case 514514 :
                return context.getResources().getString(R.string.hs_514514);
            case 514515 :
                return context.getResources().getString(R.string.hs_514515);
            case 514516 :
                return context.getResources().getString(R.string.hs_514516);
            case 514517 :
                return context.getResources().getString(R.string.hs_514517);
            case 514518 :
                return context.getResources().getString(R.string.hs_514518);
            case 514600 :
                return context.getResources().getString(R.string.hs_514600);
            case 514601 :
                return context.getResources().getString(R.string.hs_514601);
            case 514603 :
                return context.getResources().getString(R.string.hs_514603);
            case 514604 :
                return context.getResources().getString(R.string.hs_514604);
            case 514605 :
                return context.getResources().getString(R.string.hs_514605);
            case 514606 :
                return context.getResources().getString(R.string.hs_514606);
            case 514607 :
                return context.getResources().getString(R.string.hs_514607);
            case 514608 :
                return context.getResources().getString(R.string.hs_514608);
            case 514609 :
                return context.getResources().getString(R.string.hs_514609);
            case 514610 :
                return context.getResources().getString(R.string.hs_514610);
            case 514611 :
                return context.getResources().getString(R.string.hs_514611);
            case 514612 :
                return context.getResources().getString(R.string.hs_514612);
            case 514613 :
                return context.getResources().getString(R.string.hs_514613);
            case 514614 :
                return context.getResources().getString(R.string.hs_514614);
            case 514615 :
                return context.getResources().getString(R.string.hs_514615);
            case 514616 :
                return context.getResources().getString(R.string.hs_514616);
            case 514617 :
                return context.getResources().getString(R.string.hs_514617);
            case 514618 :
                return context.getResources().getString(R.string.hs_514618);
            case 514619 :
                return context.getResources().getString(R.string.hs_514619);
            case 514620 :
                return context.getResources().getString(R.string.hs_514620);
            case 514621 :
                return context.getResources().getString(R.string.hs_514621);
            case 514622 :
                return context.getResources().getString(R.string.hs_514622);
            case 514623 :
                return context.getResources().getString(R.string.hs_514623);
            case 514624 :
                return context.getResources().getString(R.string.hs_514624);
            case 514625 :
                return context.getResources().getString(R.string.hs_514625);
            case 514626 :
                return context.getResources().getString(R.string.hs_514626);
            case 514627 :
                return context.getResources().getString(R.string.hs_514627);
            case 514628 :
                return context.getResources().getString(R.string.hs_514628);
            case 514629 :
                return context.getResources().getString(R.string.hs_514629);
            case 514630 :
                return context.getResources().getString(R.string.hs_514630);
            case 514631 :
                return context.getResources().getString(R.string.hs_514631);
            case 514632 :
                return context.getResources().getString(R.string.hs_514632);
            case 514633 :
                return context.getResources().getString(R.string.hs_514633);
            case 514634 :
                return context.getResources().getString(R.string.hs_514634);
            case 514635 :
                return context.getResources().getString(R.string.hs_514635);
            case 514636 :
                return context.getResources().getString(R.string.hs_514636);
            case 514637 :
                return context.getResources().getString(R.string.hs_514637);
            case 514638 :
                return context.getResources().getString(R.string.hs_514638);
            case 514639 :
                return context.getResources().getString(R.string.hs_514639);
            case 514640 :
                return context.getResources().getString(R.string.hs_514640);
            case 514641 :
                return context.getResources().getString(R.string.hs_514641);
            case 514642 :
                return context.getResources().getString(R.string.hs_514642);
            case 514643 :
                return context.getResources().getString(R.string.hs_514643);
            case 514644 :
                return context.getResources().getString(R.string.hs_514644);
            case 514645 :
                return context.getResources().getString(R.string.hs_514645);
            case 514647 :
                return context.getResources().getString(R.string.hs_514647);
            case 514648 :
                return context.getResources().getString(R.string.hs_514648);
            case 514649 :
                return context.getResources().getString(R.string.hs_514649);
            case 514650 :
                return context.getResources().getString(R.string.hs_514650);
            case 514651 :
                return context.getResources().getString(R.string.hs_514651);
            case 514652 :
                return context.getResources().getString(R.string.hs_514652);
            case 514653 :
                return context.getResources().getString(R.string.hs_514653);
            case 514654 :
                return context.getResources().getString(R.string.hs_514654);
            case 514655 :
                return context.getResources().getString(R.string.hs_514655);
            case 514656 :
                return context.getResources().getString(R.string.hs_514656);
            case 514657 :
                return context.getResources().getString(R.string.hs_514657);
            case 514658 :
                return context.getResources().getString(R.string.hs_514658);
            case 514659 :
                return context.getResources().getString(R.string.hs_514659);
            case 514660 :
                return context.getResources().getString(R.string.hs_514660);
            case 514661 :
                return context.getResources().getString(R.string.hs_514661);
            case 514662 :
                return context.getResources().getString(R.string.hs_514662);
            case 514663 :
                return context.getResources().getString(R.string.hs_514663);
            case 514664 :
                return context.getResources().getString(R.string.hs_514664);
            case 514665 :
                return context.getResources().getString(R.string.hs_514665);
            case 514666 :
                return context.getResources().getString(R.string.hs_514666);
            case 514667 :
                return context.getResources().getString(R.string.hs_514667);
            case 514668 :
                return context.getResources().getString(R.string.hs_514668);
            case 514670 :
                return context.getResources().getString(R.string.hs_514670);
            case 514671 :
                return context.getResources().getString(R.string.hs_514671);
            case 514672 :
                return context.getResources().getString(R.string.hs_514672);
            case 514673 :
                return context.getResources().getString(R.string.hs_514673);
            case 514674 :
                return context.getResources().getString(R.string.hs_514674);
            case 514675 :
                return context.getResources().getString(R.string.hs_514675);
            case 514676 :
                return context.getResources().getString(R.string.hs_514676);
            case 514677 :
                return context.getResources().getString(R.string.hs_514677);
            case 514678 :
                return context.getResources().getString(R.string.hs_514678);
            case 514679 :
                return context.getResources().getString(R.string.hs_514679);
            case 514680 :
                return context.getResources().getString(R.string.hs_514680);
            case 514681 :
                return context.getResources().getString(R.string.hs_514681);
            case 514682 :
                return context.getResources().getString(R.string.hs_514682);
            case 514683 :
                return context.getResources().getString(R.string.hs_514683);
            case 514684 :
                return context.getResources().getString(R.string.hs_514684);
            case 514685 :
                return context.getResources().getString(R.string.hs_514685);
            case 514686 :
                return context.getResources().getString(R.string.hs_514686);
            case 514688 :
                return context.getResources().getString(R.string.hs_514688);
            case 514689 :
                return context.getResources().getString(R.string.hs_514689);
            case 514690 :
                return context.getResources().getString(R.string.hs_514690);
            case 514691 :
                return context.getResources().getString(R.string.hs_514691);
            case 514692 :
                return context.getResources().getString(R.string.hs_514692);
            case 514693 :
                return context.getResources().getString(R.string.hs_514693);
            case 514694 :
                return context.getResources().getString(R.string.hs_514694);
            case 514695 :
                return context.getResources().getString(R.string.hs_514695);
            case 514696 :
                return context.getResources().getString(R.string.hs_514696);
            case 514697 :
                return context.getResources().getString(R.string.hs_514697);
            case 514698 :
                return context.getResources().getString(R.string.hs_514698);
            case 514699 :
                return context.getResources().getString(R.string.hs_514699);
            case 514700 :
                return context.getResources().getString(R.string.hs_514700);
            case 514701 :
                return context.getResources().getString(R.string.hs_514701);
            case 514702 :
                return context.getResources().getString(R.string.hs_514702);
            case 514703 :
                return context.getResources().getString(R.string.hs_514703);
            case 514704 :
                return context.getResources().getString(R.string.hs_514704);
            case 514705 :
                return context.getResources().getString(R.string.hs_514705);
            case 514706 :
                return context.getResources().getString(R.string.hs_514706);
            case 514707 :
                return context.getResources().getString(R.string.hs_514707);
            case 514708 :
                return context.getResources().getString(R.string.hs_514708);
            case 514709 :
                return context.getResources().getString(R.string.hs_514709);
            case 514710 :
                return context.getResources().getString(R.string.hs_514710);
            case 514711 :
                return context.getResources().getString(R.string.hs_514711);
            case 514712 :
                return context.getResources().getString(R.string.hs_514712);
            case 514713 :
                return context.getResources().getString(R.string.hs_514713);
            case 514714 :
                return context.getResources().getString(R.string.hs_514714);
            case 514715 :
                return context.getResources().getString(R.string.hs_514715);
            case 514716 :
                return context.getResources().getString(R.string.hs_514716);
            case 514717 :
                return context.getResources().getString(R.string.hs_514717);
            case 514718 :
                return context.getResources().getString(R.string.hs_514718);
            case 514719 :
                return context.getResources().getString(R.string.hs_514719);
            case 514720 :
                return context.getResources().getString(R.string.hs_514720);
            case 514721 :
                return context.getResources().getString(R.string.hs_514721);
            case 514722 :
                return context.getResources().getString(R.string.hs_514722);
            case 514723 :
                return context.getResources().getString(R.string.hs_514723);
            case 514724 :
                return context.getResources().getString(R.string.hs_514724);
            case 514725 :
                return context.getResources().getString(R.string.hs_514725);
            case 514726 :
                return context.getResources().getString(R.string.hs_514726);
            case 514727 :
                return context.getResources().getString(R.string.hs_514727);
            case 514728 :
                return context.getResources().getString(R.string.hs_514728);
            case 514729 :
                return context.getResources().getString(R.string.hs_514729);
            case 514730 :
                return context.getResources().getString(R.string.hs_514730);
            case 514731 :
                return context.getResources().getString(R.string.hs_514731);
            case 514755 :
                return context.getResources().getString(R.string.hs_514755);
            case 514772 :
                return context.getResources().getString(R.string.hs_514772);
            case 990001 :
                return context.getResources().getString(R.string.hs_990001);
            case 990002 :
                return context.getResources().getString(R.string.hs_990002);
            case 990003 :
                return context.getResources().getString(R.string.hs_990003);
            case 990004 :
                return context.getResources().getString(R.string.hs_990004);
            case 990005 :
                return context.getResources().getString(R.string.hs_990005);
            case 990006 :
                return context.getResources().getString(R.string.hs_990006);
            case 990007 :
                return context.getResources().getString(R.string.hs_990007);
            case 990008 :
                return context.getResources().getString(R.string.hs_990008);
            case 990009 :
                return context.getResources().getString(R.string.hs_990009);
            case 990010 :
                return context.getResources().getString(R.string.hs_990010);
            case 990011 :
                return context.getResources().getString(R.string.hs_990011);
            case 990012 :
                return context.getResources().getString(R.string.hs_990012);
            case 990013 :
                return context.getResources().getString(R.string.hs_990013);
            case 990101 :
                return context.getResources().getString(R.string.hs_990101);
            case 990102 :
                return context.getResources().getString(R.string.hs_990102);
            case 990103 :
                return context.getResources().getString(R.string.hs_990103);
            case 990104 :
                return context.getResources().getString(R.string.hs_990104);
            case 990105 :
                return context.getResources().getString(R.string.hs_990105);
            case 990106 :
                return context.getResources().getString(R.string.hs_990106);
            case 990107 :
                return context.getResources().getString(R.string.hs_990107);
            case 990108 :
                return context.getResources().getString(R.string.hs_990108);
            case 990109 :
                return context.getResources().getString(R.string.hs_990109);
            case 990110 :
                return context.getResources().getString(R.string.hs_990110);
            case 990201 :
                return context.getResources().getString(R.string.hs_990201);
            case 990202 :
                return context.getResources().getString(R.string.hs_990202);
            case 990203 :
                return context.getResources().getString(R.string.hs_990203);
            case 990204 :
                return context.getResources().getString(R.string.hs_990204);
            case 990205 :
                return context.getResources().getString(R.string.hs_990205);
            case 990206 :
                return context.getResources().getString(R.string.hs_990206);
            case 990207 :
                return context.getResources().getString(R.string.hs_990207);
            case 990208 :
                return context.getResources().getString(R.string.hs_990208);
            case 990209 :
                return context.getResources().getString(R.string.hs_990209);
            case 990210 :
                return context.getResources().getString(R.string.hs_990210);
            case 990301 :
                return context.getResources().getString(R.string.hs_990301);
            case 990302 :
                return context.getResources().getString(R.string.hs_990302);
            case 990303 :
                return context.getResources().getString(R.string.hs_990303);
            case 990304 :
                return context.getResources().getString(R.string.hs_990304);
            case 990305 :
                return context.getResources().getString(R.string.hs_990305);
            case 990306 :
                return context.getResources().getString(R.string.hs_990306);
            case 990307 :
                return context.getResources().getString(R.string.hs_990307);
            case 990308 :
                return context.getResources().getString(R.string.hs_990308);
            case 990309 :
                return context.getResources().getString(R.string.hs_990309);
            case 990310 :
                return context.getResources().getString(R.string.hs_990310);
            case 990311 :
                return context.getResources().getString(R.string.hs_990311);
            case 990312 :
                return context.getResources().getString(R.string.hs_990312);
            case 990313 :
                return context.getResources().getString(R.string.hs_990313);
            case 990314 :
                return context.getResources().getString(R.string.hs_990314);
            case 319502802 :
                return context.getResources().getString(R.string.hs_319502802);
            case 319503002 :
                return context.getResources().getString(R.string.hs_319503002);
            default:
                return "";
        }
    }
}
