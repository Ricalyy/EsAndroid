package com.esunny.data.util.simplethread;

import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class SerialExecutor {

    private final static ExecutorParams SERIAL_EXECUTOR_PARAMS = new ExecutorParams();

    static {
        SERIAL_EXECUTOR_PARAMS.corePoolSize = 1;
        SERIAL_EXECUTOR_PARAMS.maximumPoolSize = 1;
        SERIAL_EXECUTOR_PARAMS.keepAliveTime = 60L;
        SERIAL_EXECUTOR_PARAMS.unit = TimeUnit.SECONDS;
        SERIAL_EXECUTOR_PARAMS.workQueue = new PriorityBlockingQueue<>();
    }

    static ThreadPoolExecutor getSerialExecutor(ExecutorParams params) {
        return new ThreadPoolExecutor(params.corePoolSize,
                params.maximumPoolSize,
                params.keepAliveTime,
                params.unit,
                params.workQueue);
    }

    static ThreadPoolExecutor getDefaultSerialExecutor() {
        return getSerialExecutor(SERIAL_EXECUTOR_PARAMS);
    }
}
