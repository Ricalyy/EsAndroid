package com.esunny.data.bean;

import java.math.BigInteger;
import java.util.ArrayList;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class HisQuoteData implements Cloneable {

    private HisQuoteData preKlineEntity;
    private boolean Validity;

    private long TradeDate;                      //交易日|tick无效，min可能和时间戳不同，day和时间戳相同
    private java.math.BigInteger DateTimeStamp;                  //时间戳|不同数据类型，精度不同

    private double OpenPrice;
    private double HighPrice;
    private double LowPrice;
    private double ClosePrice;
    private double AvgPrice;//分时图的均价
    private double SettlePrice;
    private ArrayList<Double> mList;

    private BigInteger TotalQty = new BigInteger("0");  //总成交量
    private BigInteger Volume = new BigInteger("0");
    private BigInteger Position = new BigInteger("0");

    public HisQuoteData getPreKlineEntity() {
        return preKlineEntity;
    }

    public void setPreKlineEntity(HisQuoteData preKlineEntity) {
        this.preKlineEntity = preKlineEntity;
    }

    public boolean isValidity() {
        return Validity;
    }

    public void setValidity(boolean validity) {
        Validity = validity;
    }

    public double getOpenPrice() {
        return OpenPrice;
    }

    public void setOpenPrice(double openPrice) {
        OpenPrice = openPrice;
    }

    public double getHighPrice() {
        return HighPrice;
    }

    public void setHighPrice(double highPrice) {
        HighPrice = highPrice;
    }

    public double getLowPrice() {
        return LowPrice;
    }

    public void setLowPrice(double lowPrice) {
        LowPrice = lowPrice;
    }

    public double getClosePrice() {
        return ClosePrice;
    }

    public void setClosePrice(double closePrice) {
        ClosePrice = closePrice;
    }

    public double getAvgPrice() {
        return AvgPrice;
    }

    public void setAvgPrice(double avgPrice) {
        AvgPrice = avgPrice;
    }

    public double getSettlePrice() {
        if (SettlePrice == 0){
            return ClosePrice;
        }
        return SettlePrice;
    }

    public void setSettlePrice(double settlePrice) {
        SettlePrice = settlePrice;
    }

    public BigInteger getTotalQty() {
        return TotalQty;
    }

    public void setTotalQty(BigInteger totalQty) {
        TotalQty = totalQty;
    }

    public BigInteger getVolume() {
        return Volume;
    }

    public void setVolume(BigInteger volume) {
        Volume = volume;
    }

    public BigInteger getPosition() {
        return Position;
    }

    public void setPosition(BigInteger position) {
        Position = position;
    }

    public long getTradeDate() {
        return TradeDate;
    }

    public void setTradeDate(long tradeDate) {
        TradeDate = tradeDate;
    }

    public String getDateTimeStamp() {
        if (DateTimeStamp != null) {
            return DateTimeStamp.toString();
        }
        return "0";
    }

    public void setDateTimeStamp(BigInteger dateTimeStamp) {
        DateTimeStamp = dateTimeStamp;
    }

    public HisQuoteData clone() {
        try {
            return (HisQuoteData) super.clone();
        } catch (CloneNotSupportedException e) {
            HisQuoteData data = new HisQuoteData();

            data.setPreKlineEntity(preKlineEntity);
            data.setValidity(isValidity());

            data.setTradeDate(TradeDate);
            data.setDateTimeStamp(DateTimeStamp);

            data.setOpenPrice(OpenPrice);
            data.setHighPrice(HighPrice);
            data.setLowPrice(LowPrice);
            data.setClosePrice(ClosePrice);
            data.setAvgPrice(AvgPrice);
            data.setSettlePrice(SettlePrice);
            data.setMACDIndex(mList);

            data.setTotalQty(TotalQty);
            data.setVolume(Volume);
            data.setPosition(Position);

            return data;
        }
    }

    public boolean equalDataWithPeriod(HisQuoteData data) {
        return data != null && DateTimeStamp.compareTo(data.DateTimeStamp) == 0;
    }

    public void setMACDIndex(ArrayList<Double> list){
        this.mList=list;
    }

    public ArrayList<Double> getMACDIndex(){
        return mList;
    }
}
