package com.esunny.data.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/20
 */
public class SPushClientInfo extends ApiStruct {

    public final static short STRUCT_LENGTH = 147;

    private String AppId;                              //App Id
    private String AppKey;                             //App Key
    private String AppMasterSecret;                    //App Master Secret
    private String CID;                                //设备client id
    private char DeviceType;                         //设备类型 Android IOS
    private short LangType;                           //设备系统语言

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(AppId, 31));
        buffer.put(stringToByte(AppKey, 31));
        buffer.put(stringToByte(AppMasterSecret, 31));
        buffer.put(stringToByte(CID, 51));
        buffer.put(charToByte(DeviceType));
        buffer.putShort(LangType);

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getAppId() {
        return AppId;
    }

    public void setAppId(String appId) {
        AppId = appId;
    }

    public String getAppKey() {
        return AppKey;
    }

    public void setAppKey(String appKey) {
        AppKey = appKey;
    }

    public String getAppMasterSecret() {
        return AppMasterSecret;
    }

    public void setAppMasterSecret(String appMasterSecret) {
        AppMasterSecret = appMasterSecret;
    }

    public String getCID() {
        return CID;
    }

    public void setCID(String CID) {
        this.CID = CID;
    }

    public char getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(char deviceType) {
        DeviceType = deviceType;
    }

    public short getLangType() {
        return LangType;
    }

    public void setLangType(short langType) {
        LangType = langType;
    }
}
