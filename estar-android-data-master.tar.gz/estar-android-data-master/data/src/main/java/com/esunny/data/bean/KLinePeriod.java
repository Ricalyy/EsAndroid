package com.esunny.data.bean;

import com.esunny.data.api.EsDataConstant;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class KLinePeriod implements Serializable {

    public static final char S_KLINE_MINUTE = 'M';    //分钟线
    public static final char S_KLINE_DAY = 'D';    //日线
    public static final char S_KLINE_WEEK = 'W';    //周
    public static final char S_KLINE_MONTH = 'O';    //月
    public static final char S_KLINE_HOUR = 'H';    //小时

    private int mKLineSlice;
    private char mKLineType;  //用于订阅行情的类型
    private int mKLineShowSlice;
    private char mKLineShowType;    //用于显示的行情类型（）

    public KLinePeriod(char showType, int showSlice) {

        this.mKLineShowType = showType;
        this.mKLineShowSlice = showSlice;

        switch (mKLineShowType) {
            case S_KLINE_MINUTE:
            case S_KLINE_DAY:
            case EsDataConstant.KLINE_TICK:
                mKLineSlice = mKLineShowSlice;
                mKLineType = mKLineShowType;
                break;
            case S_KLINE_HOUR:
                mKLineSlice = 60 * mKLineShowSlice;
                mKLineType = S_KLINE_MINUTE;
                break;
            case S_KLINE_WEEK:
                mKLineSlice = 7 * mKLineShowSlice;
                mKLineType = S_KLINE_DAY;
                break;
            case S_KLINE_MONTH:
                mKLineSlice = 30 * mKLineShowSlice;
                mKLineType = S_KLINE_DAY;
                break;
            default:
                break;
        }
    }

    public String getPeriodString() {
        return String.valueOf(this.mKLineShowType) + "-" + String.valueOf(this.mKLineShowSlice);
    }

    public static KLinePeriod getPeriodObject(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }

        String[] arr = text.split("-");
        if (arr.length == 2) {
            char showType = arr[0].charAt(0);
            if (showType == S_KLINE_MINUTE ||
                    showType == S_KLINE_DAY ||
                    showType == EsDataConstant.KLINE_TICK ||
                    showType == S_KLINE_HOUR ||
                    showType == S_KLINE_WEEK ||
                    showType == S_KLINE_MONTH) {
                return new KLinePeriod(arr[0].charAt(0), Integer.parseInt(arr[1]));
            }
        }
        return null;
    }

    public char getKLineType() {
        return mKLineType;
    }

    public int getKLineSlice() {
        return mKLineSlice;
    }

    public char getKLineShowType() {
        return mKLineShowType;
    }

    public int getKLineShowSlice() {
        return mKLineShowSlice;
    }

    public int getPeriodName() {
        if (mKLineShowSlice == 1) {
            if (mKLineShowType == EsDataConstant.KLINE_TICK) {
                return 0;
            } else if (mKLineShowType == S_KLINE_DAY) {
                return 1;
            }
        }
        if (mKLineShowType == S_KLINE_MINUTE) {
            return 2;
        }
        return 3;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        KLinePeriod period = (KLinePeriod) o;
        return mKLineSlice == period.mKLineSlice &&
                mKLineType == period.mKLineType &&
                mKLineShowSlice == period.mKLineShowSlice &&
                mKLineShowType == period.mKLineShowType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(mKLineSlice, mKLineType, mKLineShowSlice, mKLineShowType);
    }
}
