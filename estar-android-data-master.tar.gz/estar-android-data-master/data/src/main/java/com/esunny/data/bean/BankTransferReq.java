package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class BankTransferReq{
    private String CompanyNo;          //经纪公司编号
    private String UserNo;             //期货资金账号
    private String AddressNo;          //地址号
    private String BankNo;             //银行标志
    private String BankAccount;        //银行卡号
    private String CurrencyNo;         //币种编号
    private char                                                TransDirect;        //转账方向
    private double                                              TransFund;          //转账金额
    private String TransAuth;          //银期转账认证密码
    private String BankPsw;            //银行密码

    public BankTransferReq(){

    }

    public void setCompanyNo(String value){
        CompanyNo=value;
    }

    public String getCompanyNo(){
        return CompanyNo;
    }

    public void setUserNo(String value){
        UserNo=value;
    }

    public String getUserNo(){
        return UserNo;
    }

    public String getAddressNo() {
        return AddressNo;
    }

    public void setAddressNo(String addressNo) {
        AddressNo = addressNo;
    }

    public void setBankNo(String value){
        BankNo=value;
    }

    public String getBankNo(){
        return BankNo;
    }

    public void setBankAccount(String value){
        BankAccount=value;
    }

    public String getBankAccount(){
        return BankAccount;
    }

    public void setCurrencyNo(String value){
        CurrencyNo=value;
    }

    public String getCurrencyNo(){
        return CurrencyNo;
    }

    public void setTransDirect(char value){
        TransDirect=value;
    }

    public char getTransDirect(){
        return TransDirect;
    }

    public void setTransFund(double value){
        TransFund=value;
    }

    public double getTransFund(){
        return TransFund;
    }

    public void setTransAuth(String value){
        TransAuth=value;
    }

    public String getTransAuth(){
        return TransAuth;
    }

    public void setBankPsw(String value){
        BankPsw=value;
    }

    public String getBankPsw(){
        return BankPsw;
    }

}
