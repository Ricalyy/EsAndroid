package com.esunny.data.bean;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class TradeLogin implements Parcelable {
    private String companyNo;             //公司编号
    private String companyName;           //公司名称
    private String addrTypeNo;            //公司地址类型
    private String addrTypeName;          //公司地址名称
    private String userNo;                 //登录号
    private String tradeApi;               //交易API类型
    private String tradeDate[] = new String[]{"", ""};              //云仿真 0 内盘交易日 1 外盘交易日

    private String SystemInfo;             //系统内部信息
    private int SystemInfoLen;            //用户端系统内部信息长度(真实长度)
    private String SystemInfoIntegrity;    //采集信息完整度
    private int SystemInfoFlag;         //采集信息标记

    public TradeLogin()
    {
        companyNo="";
        addrTypeNo="";
        userNo="";
        tradeDate = new String[]{"",""};

        SystemInfo="";
        SystemInfoIntegrity="";
    }

    protected TradeLogin(Parcel in) {
        companyNo = in.readString();
        companyName = in.readString();
        addrTypeNo = in.readString();
        addrTypeName = in.readString();
        userNo = in.readString();
        tradeApi = in.readString();
        tradeDate = in.createStringArray();
        SystemInfo = in.readString();
        SystemInfoLen = in.readInt();
        SystemInfoIntegrity = in.readString();
        SystemInfoFlag = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(companyNo);
        dest.writeString(companyName);
        dest.writeString(addrTypeNo);
        dest.writeString(addrTypeName);
        dest.writeString(userNo);
        dest.writeString(tradeApi);
        dest.writeStringArray(tradeDate);
        dest.writeString(SystemInfo);
        dest.writeInt(SystemInfoLen);
        dest.writeString(SystemInfoIntegrity);
        dest.writeInt(SystemInfoFlag);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<TradeLogin> CREATOR = new Creator<TradeLogin>() {
        @Override
        public TradeLogin createFromParcel(Parcel in) {
            return new TradeLogin(in);
        }

        @Override
        public TradeLogin[] newArray(int size) {
            return new TradeLogin[size];
        }
    };

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAddrTypeNo() {
        return addrTypeNo;
    }

    public void setAddrTypeNo(String addrTypeNo) {
        this.addrTypeNo = addrTypeNo;
    }

    public String getAddrTypeName() {
        return addrTypeName;
    }

    public void setAddrTypeName(String addrTypeName) {
        this.addrTypeName = addrTypeName;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getTradeApi() {
        return tradeApi;
    }

    public void setTradeApi(String tradeApi) {
        this.tradeApi = tradeApi;
    }

    public String[] getTradeDate() {
        return tradeDate;
    }

    public void setTradeDate(String[] tradeDate) {
        short vlen=(short)tradeDate.length;
        if(vlen > 2)
            vlen = 2;
        System.arraycopy(tradeDate, 0, this.tradeDate, 0, vlen);
    }

    public String getSystemInfo() {
        return SystemInfo;
    }

    public void setSystemInfo(String systemInfo) {
        SystemInfo = systemInfo;
    }

    public int getSystemInfoLen() {
        return SystemInfoLen;
    }

    public void setSystemInfoLen(int systemInfoLen) {
        SystemInfoLen = systemInfoLen;
    }

    public String getSystemInfoIntegrity() {
        return SystemInfoIntegrity;
    }

    public void setSystemInfoIntegrity(String systemInfoIntegrity) {
        SystemInfoIntegrity = systemInfoIntegrity;
    }

    public int getSystemInfoFlag() {
        return SystemInfoFlag;
    }

    public void setSystemInfoFlag(int systemInfoFlag) {
        SystemInfoFlag = systemInfoFlag;
    }
}