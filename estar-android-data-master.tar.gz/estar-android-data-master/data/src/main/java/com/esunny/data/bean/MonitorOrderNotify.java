package com.esunny.data.bean;

public class MonitorOrderNotify {

    private String                                       ContractNo;     //监控合约
    private int                                         OrderReqId;
    private String                                          OrderNo;
    private String DateTime;
    private char                                       OrderState;
    private int                                        ErrorCode;
    private String                                        ErrorText;

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public int getOrderReqId() {
        return OrderReqId;
    }

    public void setOrderReqId(int orderReqId) {
        OrderReqId = orderReqId;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getDateTime() {
        return DateTime;
    }

    public void setDateTime(String dateTime) {
        DateTime = dateTime;
    }

    public char getOrderState() {
        return OrderState;
    }

    public void setOrderState(char orderState) {
        OrderState = orderState;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }
}
