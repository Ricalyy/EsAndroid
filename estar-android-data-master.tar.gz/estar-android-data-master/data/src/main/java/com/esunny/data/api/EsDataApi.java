package com.esunny.data.api;

import android.app.Application;
import android.util.Log;

import com.esunny.data.api.server.EsSystemInfo;
import com.esunny.data.api.server.EsTradeApi;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.AdverImageInfo;
import com.esunny.data.bean.AvailableQty;
import com.esunny.data.bean.BankBalanceQry;
import com.esunny.data.bean.BankTransferReq;
import com.esunny.data.bean.BillConfirmReq;
import com.esunny.data.bean.BillData;
import com.esunny.data.bean.CalOpenCoverParam;
import com.esunny.data.bean.CertificationSecondReq;
import com.esunny.data.bean.CloudTradeCompany;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.Exchange;
import com.esunny.data.bean.FundsBetData;
import com.esunny.data.bean.HisDetailData;
import com.esunny.data.bean.HisQuoteData;
import com.esunny.data.bean.HisQuoteTimeBucket;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.KLinePeriod;
import com.esunny.data.bean.MatchData;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.data.bean.MonitorOrderAction;
import com.esunny.data.bean.MonitorOrderInsert;
import com.esunny.data.bean.NotifyInfo;
import com.esunny.data.bean.OpenCompanyInfo;
import com.esunny.data.bean.OptionContractPair;
import com.esunny.data.bean.OptionSeries;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.Plate;
import com.esunny.data.bean.PositionData;
import com.esunny.data.bean.PushClientInfo;
import com.esunny.data.bean.QuoteField;
import com.esunny.data.bean.QuoteLoginInfo;
import com.esunny.data.bean.SASXParam;
import com.esunny.data.bean.TradeLogInfo;
import com.esunny.data.bean.TradeLogin;
import com.esunny.data.bean.TrdSecondCheckCodeInfo;
import com.esunny.data.bean.VerifyIdentityReq;
import com.esunny.data.bean.VersionInfo;
import com.esunny.mobile.bean.CspSessionHead;

import java.io.File;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class EsDataApi {

    public static int getLogLevel() {
        return 0;
    }

    /***
     * 初始化API
     * @param application 应用
     * @param packageNoStr 授权码
     * @return 0表示成功，<0表示失败
     */
    public static int init(Application application, String packageNoStr) {
        return EsBaseApi.getInstance().init(application, packageNoStr);
    }

    /***
     * 判断API是否已经完成初始化
     * @return 初始化结果
     */
    public static boolean isInit() {
        return EsBaseApi.getInstance().isInit();
    }

    /***
     * 启动API
     */
    public static void startUp() {
        EsBaseApi.getInstance().startUp();
    }

    /***
     * 、获取当前API包号
     * @return 包号
     */
    public static String getPackageNo() {
        return EsBaseApi.getInstance().getPackageNo();
    }

    /**
     * 获取当前软件语言
     * S_Android_CHS
     * S_Android_CHT
     * S_ANDROID_ENU
     */
    public static int getLanguageType(){
        return EsBaseApi.getInstance().getLanguageType();
    }

    /**
     * 当前包是否包含交易模块
     * @return 是否包含交易模块
     */
    public static boolean isContainTrade() {
        return true;
    }

    /**
     * 当前包是否包含新闻模块
     * @return 是否包含新闻模块
     */
    public static boolean isContainNews() {
        return true;
    }

    /**
     * 是否有该合约的行情权限
     * @param contract 合约
     * @return 是否有权限
     */
    public static boolean hasContractPermission(Contract contract) {
        return EsBaseApi.getInstance().hasContractPermission(contract);
    }

    /**
     * 判断交易所是否有权限
     * @param exchangeNo
     * @return
     */
    public static boolean hasExchangePermission(String exchangeNo) {
        return EsBaseApi.getInstance().hasExchangePermission(exchangeNo);
    }

    /**
     * @param contractNo
     * @return 返回合约号不转换下对应的合约
     */
    public static Contract getContract(String contractNo){
        return EsBaseApi.getInstance().getContract(contractNo);
    }

    /**
     * 通过合约号获取行情合约
     * 交易所套利合约需要转成极星套利才可以获取行情
     * @param contractNo 合约号
     * @return 行情合约
     */
    public static Contract getQuoteContract(String contractNo) {
        return EsBaseApi.getInstance().getQuoteContract(contractNo);
    }

    /**
     * 通过合约号获取交易的合约
     * 虚拟合约转换成真实合约，交易所套利合约转换为可交易的极星套利合约
     * @param contractNo 合约号
     * @return 交易合约
     */
    public static Contract getTradeContract(String contractNo) {
        return EsBaseApi.getInstance().getTradeContract(contractNo);
    }

    /**
     * 虚拟合约获取真实合约
     * 主连、近月等虚拟合约，获取相对应的真实合约
     * @param contractNo 虚拟合约号
     * @return null 则不是真实合约
     */
    public static Contract getRealContract(String contractNo) {
        return EsBaseApi.getInstance().getRealContract(contractNo);
    }

    /**
     * 通过合约号获取合约名称
     * 套利合约则获取极星套利合约名称
     * @param contractNo  合约名称
     * @return null 过期或者不存在
     */
    public static String getContractName(String contractNo) {
        return EsBaseApi.getInstance().getContractName(contractNo);
    }

    /**
     * 判断是否为非伦敦3M合约
     * @param contractNo 合约号
     * @return true LME非3M合约
     */
    public static boolean isLMEMonth(String contractNo) {
        return false;
    }

    /**
     * 获取合约编码
     * @param contractNo 合约号
     * @return NULL：获取失败或者不存在；否则为合约码
     */
    public static String getContractCode(String contractNo) {
        return EsBaseApi.getInstance().getContractCode(contractNo);
    }

    /**
     * 是否主連合約
     * @param contractNo 合約號
     * @return
     */
    public static boolean isMainContract(String contractNo) {
        return EsBaseApi.getInstance().isMainContract(contractNo);
    }

    public static boolean isOptionPlate(String plateNo) {
        return "OPTION".equals(plateNo);
    }

    public static String getMainContractNo(String realContractNo){
        return EsBaseApi.getInstance().getMainContractNo(realContractNo);
    }

    /**
     * 根据tag查询新闻请求
     * @param tag 关键字
     * @param startId 查询起始号，默认取0，从最新数据开始
     * @param isLatest 查询的方向，true为往最新数据查询，false为往历史数据查询
     * @param count 一次查询的数量
     * @return 查询会话号
     */
    @Deprecated
    public static int queryNewsByTag(String tag, int startId, boolean isLatest, int count) {
        return EsBaseApi.getInstance().queryNewsByTag(tag, startId, isLatest, count);
    }

    /**
     * 根据品种号查询F10
     */
    public static int queryF10ByCommodity(String commodityNo) {
        return EsBaseApi.getInstance().queryF10ByCommodity(commodityNo);
    }

    /**
     * 查询TC合约数量
     */
    public static int getTCContractCount() {
        return 0;
    }

    /**
     * 是否有TC授权权限
     * @return 是否有权限
     */
    public static boolean hasTCPermission() {
        return EsBaseApi.getInstance().hasTCPermission();
    }

    /**
     * <p>
     * 获取TC合约数据 contract must be MAIN contract, such as ZCE|Z|CF|MAIN.
     * </p>
     *
     * @param contractNo
     * @return true：该合约有TC数据
     * @return false：该合约无TC数据
     */
    public static boolean hasTCData(String contractNo) {
        return false;
    }

    public static String optionToTarget(String contractNo){
        return EsBaseApi.getInstance().optionToTarget(contractNo);
    }

    /**
     * <p>
     * 获取TC合约报告.
     *
     * </p>
     * @param contractNo contract must be MAIN contract, such as ZCE|Z|CF|MAIN.
     * @param timeType  SNEWS_DAY, SNEWS_DAY, SNEWS_MIDDLE_TERM, SNEWS_FIFTEEN_MINUTE
     */
    public static int qryTCReport(String contractNo, char timeType) {
        return 0;
    }

    /**
     * 是否为北斗星后台
     * @param tradeLogin 登录结构体
     * @return true 北斗星后台
     */
    public static boolean isDipperTradeStar(TradeLogin tradeLogin){
        return EsBaseApi.getInstance().isDipperTradeStar(tradeLogin);
    }

    /**
     * 是否为启明星后台
     * @param tradeLogin 登录结构体
     * @return true 启明星后台
     */
    public static boolean isVenusTradeStar(TradeLogin tradeLogin){
        return EsBaseApi.getInstance().isVenusTradeStar(tradeLogin);
    }

    /**  获取登陆IP和端口
     *  @param system 系统类型
     *  @param companyNo 公司号(仅系统类型为交易服务器时有用)
     *  @param userNo 用户名(仅系统类型为交易服务器时有用)
     *  @return NULL: 失败；否则为获取到的地址信息，包含IP和port
     */
    public static AddrInfo getAddrInfo(char system, String companyNo, String userNo, String addrNo) {
        return EsBaseApi.getInstance().getAddrInfo(system, companyNo, userNo, addrNo);
    }

    /**
     * 用户行为分析
     * @param contractNo 合约号
     */
    public static byte selectContract(String contractNo) {
        return '0';
    }

    /**
     * 是否为T+1交易所
     * @param ExChangeNo 交易所
     * @return true 可获取到
     */
    public static boolean isPlusOneExchange(String ExChangeNo){
        return EsBaseApi.getInstance().isPlusOneExchange(ExChangeNo);
    }

    /**
     * 是否为可以获取到涨跌停价格
     * @param contract 合约
     * @return true 可获取到
     */
    public static boolean isMarketPriceAvailable(Contract contract) {
        return false;
    }

    /**
     * 修改交易密码
     *
     * @param companyNo   公司名
     * @param userNo      用户名
     * @param oldPassword 旧密码
     * @param newPassword 新密码
     * @return 0: 成功; <0: 失败
     */
    public static int modifyTradePassword(String companyNo, String userNo, String addrNo, String oldPassword, String newPassword) {
        return EsBaseApi.getInstance().modifyTradePassword(companyNo, userNo, addrNo, oldPassword, newPassword);
    }

    /**
     * 修改资金密码
     *
     * @param companyNo   公司名
     * @param userNo      用户名
     * @param currencyNo  币种
     * @param oldPassword 旧密码
     * @param newPassword 新密码
     * @return 0: 成功; <0: 失败
     */
    public static int modifyMoneyPassword(String companyNo, String userNo, String addrNo, String currencyNo, String oldPassword, String newPassword) {
        return 0;
    }

    /**
     * 是否为云仿真平台
     * @param apiName api名称
     * @return true 云仿真平台
     */
    public static boolean isEstarTradeApi(String apiName) {
        return false;
    }

    /**
     * 是否为中金所交易所
     * @param contractNo 合约号
     * @return true 是中金所
     */
    public static boolean isCFFEXPlate(String contractNo) {
        return false;
    }

    /**
     * 获取APP版本更新信息
     * @return 版本信息
     */
    public static VersionInfo getVersionUpdateInfo() {
        return null;
    }

    /**
     * 获取广告页更新信息
     * @return 广告页信息
     */
    public static AdverImageInfo getAdverImageInfo() {
        return null;
    }

    /**
     * 获取用户反馈的连接
     * @return http链接
     */
    public static String getFeedbackUrl() {
        return null;
    }

    /**
     * 获取官网地址
     * @return http链接
     */
    public static String getCompanyUrl() {
        return null;
    }

    /**
     * 穿透加密数据
     * @param api 后台类型
     * @param callback 信息通过回调获取
     * @return 处理的结果 0处理成功，等待回调获取信息，1是权限不够，-1是后台类型不对，-2是插件缺失
     */
    public static int getSystemInfo(String api, EsSystemInfo.SystemInfoCallback callback) {
        return EsBaseApi.getInstance().getSystemInfo(api, callback);
    }

    /**
     * 转换错误信息
     * @param api 后台类型
     * @param code 错误码
     * @param text 备用错误信息
     * @return 错误信息
     */
    public static String getErrorMessage(String api, int code, String text) {
        return EsBaseApi.getInstance().getErrorMessage(api, code, text);
    }

    /**
     * 添加价格预警单
     * 需先登录极星账号
     * @param order 预警单
     * @return 小于0则下单失败
     */
    public static int insertMonitorOrder(MonitorOrderInsert order) {
        return 0;
    }

    /**
     * 操作价格预警单，包括撤销、挂起、激活
     * 需先登录极星账号
     * @param order 操作类型
     * @return 小于0则处理失败
     */
    public static int actionMonitorOrder(MonitorOrderAction order) {
        return EsBaseApi.getInstance().actionMonitorOrder(order);
    }

    /**
     * 删除所有已出发的价格预警单
     * 需先登录极星账号
     * @return 小于0则删除失败
     */
    public static int deleteMonitorOrder() {
        return 0;
    }

    /**
     * 获取所有价格预警单数据
     * 需先登录极星账号
     * @return 价格预警单列表
     */
    public static List<MonitorOrder> getMonitorOrder() {
        return EsBaseApi.getInstance().getMonitorOrder();
    }

    /**
     * 登录价格预警的极星账号
     * 需先登录极星账号
     * @return
     */
    public static int priceLogin() {
        return EsBaseApi.getInstance().priceLogin();
    }

    /**
     * 登出价格预警的极星账号
     * @return
     */
    public static int priceLogout() {
        return 0;
    }

    /**
     * 软件通知
     * @return
     */
    public static NotifyInfo getNotifyInfo() {
        return null;
    }

    //************************        行情        ************************************//
    //************************        行情        ************************************//
    //************************        行情        ************************************//
    //************************        行情        ************************************//
    //************************        行情        ************************************//

    /**
     * 获取所有的版本，包含一级板块和二级板块
     * @return 返回所有的板块列表
     */
    public static List<Plate> getPlate() {
        return EsBaseApi.getInstance().getPlates();
    }

    /**
     * 获取当前版本的子版块
     * @return null表示当前版本非一级版本
     */
    public static List<Plate> getChildPlate(Plate plate) {
        return EsBaseApi.getInstance().getChildPlate(plate);
    }

//    /**
//     * 获取当前板块的交易所
//     * @return 返回交易所列表
//     */
//    public static ArrayList<PlateContent> getContentOfPlate(Plate plate) {
//        return EsQuoteApi.getContentOfPlate(plate);
//    }

//    /**
//     * 获取当前板块中的合约
//     * @param content 表示板块下对应的品种
//     * @return 返回板块下某个品种所对应的合约列表
//     */
//    public static ArrayList<Contract> getContractOfContent(PlateContent content) {
//        return EsQuoteApi.getContactOfSingleContent(content);
//    }

    /**
     *
     * @param plate 板块(交易所)
     * @return 获取该板块下所对应的所有合约
     */
    public static List<Contract> getContractOfPlate(Plate plate) {
        return EsBaseApi.getInstance().getContractOfPlate(plate);
    }

    /**
     * 获取所有期权交易所
     * @return 交易所列表
     */
    public static List<Exchange> getOptionExchange() {
        return new ArrayList<>();
    }

    /**
     * 获取期权交易所下所有品种
     * @param exchange 期权交易所
     * @return 品种列表
     */
    public static List<Commodity> getCommodityOfExchange(Exchange exchange) {
        return new ArrayList<>();
    }

    /**
     * 获取所有期权品种
     * @return 品种列表
     */
    public static List<Commodity> getOptionCommodity() {
        return EsBaseApi.getInstance().getOptionCommodity();
    }

    /**
     * 获取板块的品种数据
     * @param plate
     * @return
     */
    public static List<Commodity> getCommodityOfPlate(Plate plate) {
        return EsBaseApi.getInstance().getCommodityOfPlate(plate);
    }

    /**
     * 获取期权品种的所有期权合约
     * @param commodity 品种
     * @return 期权合约列表
     */
    public static List<OptionSeries> getOptionSeriesOfCommodity(Commodity commodity) {
        return EsBaseApi.getInstance().getOptionSeriesOfCommodity(commodity);
    }

    /**
     * 根据期权合约获取合约对列表
     * @param series 期权合约
     * @return 合约对列表
     */
    public static List<OptionContractPair> getOptionContractPair(OptionSeries series) {
        return EsBaseApi.getInstance().getOptionContractPair(series);
    }

    /**
     *  根据期权合约获取合约对列表
     * @param seriesno 系列号
     * @param begin_index 开始Index
     * @return 合约对列表
     */
    public static List<OptionContractPair> getOptionContractPairData(String seriesno, int begin_index) {
        return new ArrayList<>();
    }

    /**
     * 根据合约格式化价格字符串(不带分母)
     * @param commodity 品种
     * @param price 价格
     * @return 价格字符串
     */
    public static String formatPrice(Commodity commodity, double price) {
        return formatPrice(commodity,price, false);
    }

    /**
     * 根据合约格式化价格显示
     * @param commodity 品种
     * @param price 价格
     * @param showDeno 针对分数合约，是否显示分母
     * @return 价格字符串
     */
    public static String formatPrice(Commodity commodity, double price, boolean showDeno) {
        return EsBaseApi.getInstance().formatPrice(commodity, price, showDeno);
    }

    /**
     * 格式化字符串日期数据
     * @param time 时间字符串，时间格式20180101010100000，总长度17位，不足前面不0
     * @param type 要格式化的类型，{@link EsDataConstant} 中获取
     * @return 相应的时间格式字符串
     */
    public static String formatTime(String time, int type) {
        return EsBaseApi.getInstance().formatTime(time, type);
    }

    /**
     * 订阅即时行情数据
     * @param contractNo 合约号
     * @return 0无效，> 0 返回订阅合约的次数，次数大于1表示之前已经订阅过，内存已经缓存数据
     */
    public static int subQuote(String contractNo) {
        return EsBaseApi.getInstance().subQuote(contractNo);
    }

    /**
     * 取消订阅即时行情数据
     * @param contractNo 合约号
     * @return -1 底层处理错误， 0 订阅失败， >0 表示订阅成功
     */
    public static int unSubQuote(String contractNo) {
        return EsBaseApi.getInstance().unSubQuote(contractNo);
    }

    /**
     * 取消所有即时行情订阅
     * @return 合约数量
     */
    public static int unSubAllQuote() {
        return EsBaseApi.getInstance().unSubAllQuote();
    }

    /**
     * 订阅历史行情数据
     * 建议历史行情订阅成功后，订阅即时行情，以保持数据更新
     * @param contractNo 合约号
     * @return 0无效，1等待数据，2无需等待
     */
    public static int subHisQuote(String contractNo) {
        return EsBaseApi.getInstance().subHisQuote(contractNo);
    }

    /**
     * 取消订阅历史行情数据
     * @param contractNo 合约号
     * @return <0 底层处理错误， >0 反订阅成功
     */
    public static int unSubHisQuote(String contractNo) {
        return 0;
    }

    /**
     * 订阅某天的行情数据
     * @param contractNo 合约号
     * @param day 日期，8位数，例20180101
     * @return 0无效，1等待数据，2无需等待
     */
    public static int subMinQuote(String contractNo, long day) {
        return EsBaseApi.getInstance().subMinQuote(contractNo, day);
    }

    /**
     * 取消订阅某天的行情数据
     * @param contractNo 合约号
     * @param day 日期，8位数，例20180101
     * @return 0:部分取消订阅 ；1: 完全取消订阅；-1：JNI层解析错误
     */
    public static int unSubMinQuote(String contractNo, long day) {
        return 0;
    }

    /**
     * 获取品种的基础时间模板
     *
     * @param commodityNo 品种号
     * @return 基础时间模板
     */
    @Deprecated
    public static ArrayList<HisQuoteTimeBucket> getBaseTimeBucketData(String commodityNo) {
        return (ArrayList<HisQuoteTimeBucket>) EsBaseApi.getInstance().getBaseTimeBucketData(commodityNo, 0);
    }

    /**
     * 获取品种的基础时间模板
     *
     * @param commodityNo 品种号
     * @param date        日期 20190521
     * @return 基础时间模板
     */
    public static ArrayList<HisQuoteTimeBucket> getBaseTimeBucketData(String commodityNo, long date) {
        return (ArrayList<HisQuoteTimeBucket>) EsBaseApi.getInstance().getBaseTimeBucketData(commodityNo, date);
    }

//    /**
//     * 获取品种的数据计算模板
//     * @param commodityNo 品种号
//     * @return 数据计算模板
//     */
//    @Deprecated
//    public static ArrayList<HisQuoteTimeBucket> getCalTimeBucketData(String commodityNo) {
//        return EsQuoteApi.getCalTimeBucketData(commodityNo, 0);
//    }

    /**
     * 获取品种的历史数据计算模板
     * @param commodityNo 品种号
     * @param date 日期 20190521
     * @return 数据计算模板
     */
    public static ArrayList<HisQuoteTimeBucket> getCalTimeBucketData(String commodityNo, long date) {
        return (ArrayList<HisQuoteTimeBucket>) EsBaseApi.getInstance().getCalTimeBucketData(commodityNo, date);
    }

    /**
     * 获取合约的行情，最多十挡
     * @param contract 合约
     * @return 返回二维数组，分别为买档和卖档的数组
     */
    public static QuoteField[][] getQuoteField(Contract contract) {
        return EsBaseApi.getInstance().getQuoteField(contract);
    }

    /**
     * 获取K线历史行情数据
     * @param contract 合约号
     * @param period 周期
     * @param end 数据结束编号，0为最新的数据
     * @param size 数据长度
     * @return 返回k线历史行情数据列表
     */
    public static List<HisQuoteData> getKLineData(Contract contract, KLinePeriod period, int end, int size) {
        return EsBaseApi.getInstance().getKLineData(contract, period, end, size);
    }

    /**
     * 获取分时图数据
     * @param contract 合约
     * @return 分时图数据列表
     */
    public static List<HisQuoteData> getMinData(Contract contract) {
        return EsBaseApi.getInstance().getMinData(contract);
    }

    /**
     * 获取历史分时图数据
     * @param contract 合约号
     * @param date 日期
     * @return 历史分时图数据
     */
    public static List<HisQuoteData> getHisMinData(Contract contract, long date) {
        return new ArrayList<>();
    }

    /**
     * 获取过去多日历史分时图数据（不包含当日）
     * @param contract 合约号
     * @param len      数量
     * @return 历史分时图数据
     */
    public static List<HisQuoteData> getLastMultiDayHisMinData(Contract contract, int len) {
        return new ArrayList<>();
    }

    /**
     * 取消所有已订阅的历史分时图行情数据
     */
    public static int unSubHisMinuteAll() {
        return 0;
    }

    /**
     * 获取成交明细数据
     * @param contract 合约
     * @param len 数据长度
     * @return 成交明细数据列表，没有数据则为null
     */
    public static List<HisDetailData> getDetailData(Contract contract, int len) {
        return new ArrayList<>();
    }

    /**
     *  搜索通过关键字匹配合约数据
     * @param keyWords 搜索关键字，合约名or合约号
     * @return 合约列表
     */
    public static List<Contract> getMatchContractData(String keyWords){
        return new ArrayList<>();
    }

    /**
     * 行情登录
     * @param userNo 行情账号
     * @param password 行情登录密码
     * @return 0 登录成功，1 非法输入，-1 账号已登录，-2/-3 登陆超时
     */
    public static int quoteLogin(String userNo, String password) {
        return EsBaseApi.getInstance().quoteLogin(userNo, password);
    }

    /**
     * 行情登出
     * @return 0 登出成功，1 非法输入
     */
    public static int quoteLogout() {
        return EsBaseApi.getInstance().quoteLogout();
    }

    /**
     * 获取当前登录账号信息
     * @return NULL: 失败；否则为获取当前登录账号信息，包含账号和密码
     */
    public static QuoteLoginInfo quoteLoginInfo(){
        return EsBaseApi.getInstance().quoteLoginInfo();
    }

    /**
     * 行情账号是否登录
     * @return 登录与否
     */
    public static boolean isQuoteLogin(){
        return EsBaseApi.getInstance().isQuoteLogin();
    }

    public static boolean isMallLogin() {
        return false;
    }

    /**
     * 获取套利合约的两个合约号
     * @param contract 套利合约
     * @return 两个合约号的数组，0为第一腿，1为第二腿
     */
    public static String[] getArbitrageContractNos(Contract contract) {
        return null;
    }

    /**
     * 判断合约是否为铜期权
     * @param contract 合约
     * @return 是否为铜期权，null返回false
     */
    public static boolean isCAUContract(Contract contract) {
        return false;
    }

    /**
     * 判断合约是否为大商所期权合约
     * @param contract 合约
     * @return 是否为大商所期权合约，null返回false
     */
    public static boolean isDCEOptionContract(Contract contract) {
        return false;
    }

    /**
     * 套利合约品种转换
     * @param contract 套利合约
     * @return 交易所需要的品种号
     */
    public static String switchArbitrageCommodityNo(Contract contract) {
        return null;
    }

    /**
     * 根据合约号获取交易的品种
     * @param companyNo 公司名
     * @param userNo 资金账号
     * @param commodityNo 品种号
     * @return 品种，null则没有获取到
     */
    public static Commodity getCommodityData(String companyNo, String userNo, String addrNo, String commodityNo) {
        return EsBaseApi.getInstance().getCommodityData(companyNo, userNo, addrNo, commodityNo);
    }

    /**
     * 检测合约是否有交易权限
     *@param contract 需要检测的合约
     *@return true 有权限，可以查看。false 没有权限
     */
    public static boolean checkChargeCommodity(Contract contract){
        return false;
    }

    /**
     * 行情排序请求
     * @param type 排序类型
     * @param contractNoList 排序的合约号数组
     * @return 请求结果, 返回值为0表示成功， -1 count <= 0 -2 soryType类型不对
     */
    public static int qryContractSort(char type, String[] contractNoList) {
        return 0;
    }

    public static int getQuoteCodeUpdate() {
        return EsBaseApi.getInstance().getQuoteCodeUpdate();
    }


    //************************        交易        ************************************//
    //************************        交易        ************************************//
    //************************        交易        ************************************//
    //************************        交易        ************************************//
    //************************        交易        ************************************//

    /**
     *  交易登录
     * @param tradeLogin 账户信息
     * @param password 密码
     * @return 登录结果
     */
    public static int tradeLogin(TradeLogin tradeLogin, String password){
        return EsBaseApi.getInstance().tradeLogin(tradeLogin, password);
    }

    /**
     *  查询账号是否可以修改密码
     * @param tradeLogin 账户信息
     * @return 查询结果
     */
    public static int resetPwdPermissionsQry(TradeLogin tradeLogin){
        return 0;
    }

    /**
     * 请求发送修改密码的验证码
     * @param tradeLogin 账户信息
     * @return
     */
    public static int verCertificationQry(TradeLogin tradeLogin, VerifyIdentityReq verifyIdentityReq){
        return 0;
    }

    /**
     * 强制修改密码时发送二维码结果去验证是否正确
     * @param tradeLogin 账户信息
     * @return
     */
    public static int secondCertificationQry(TradeLogin tradeLogin, CertificationSecondReq certificationSecondReq){
        return 0;
    }

    /**
     * 是否支持多账号登录
     * @return 登录结果
     */
    public static boolean isTradeMutLogin() {
        return false;
    }

    /**
     *  登出
     * @param addrTypeNo 地址号
     * @param companyNo 公司号
     * @param userNo 用户号
     * @return 0: 登出成功
     */
    public static int tradeLogout(String addrTypeNo, String companyNo, String userNo){
        return EsBaseApi.getInstance().tradeLogout(addrTypeNo, companyNo, userNo);
    }

    /**
     * 资金查询，最多16个，所有数据一次返回
     *  @param companyNo 公司号
     *  @param userNo 资金账号
     *  @return 资金列表
     */
    public static List<MoneyData> getMoneyData(String companyNo, String userNo, String addrNo) {
        return EsBaseApi.getInstance().getMoneyData(companyNo, userNo, addrNo);
    }

    /**
     *  强制修改密码
     * @param companyNo 公司号
     * @param userNo 资金账号
     * @param bankPassword 新密码
     * @return 0为成功
     */
    public static long forceChangePassword(String companyNo, String userNo, String addrNo, String bankPassword) {
        return 0;
    }

    /**
     * 处理交易价格字符串
     * @param contract 交易的合约
     * @param priceStr 价格字符串
     * @param direct 交易方向
     * @return 价格，分数合约转换为对应的小数，根据买卖方向，卖则向上取整，买则向下取整
     */
    public static double formatOrderPrice(Contract contract, String priceStr, char direct){
        return EsBaseApi.getInstance().formatOrderPrice(contract, priceStr, direct);
    }

    /**
     * 开仓下单
     * @param order 下单的信息
     * @return 下单的session号或者错误码
     */
    public static int openTradeOrder(InsertOrder order) {
        return EsBaseApi.getInstance().openTradeOrder(order);
    }

    /**
     * 下单
     * @param order 下单的信息 开仓单或者平仓当由insertOrder参数决定
     * @return 下单的session号或者错误码
     */
    public static int TradeOrder(InsertOrder order) {
        return 0;
    }

    /**
     * 开加锁、解锁单
     * @param qty 加锁的数量
     * @return 下单的session号或者错误码
     */
    public static int lockOrder(InsertOrder order, BigInteger qty) {
        return 0;
    }

    /**
     * 平仓
     * @param order 下单的信息
     * @param isCoverT 是否为平今(针对上交所合约)
     * @return 下单的session号或者错误码
     */
    public static int coverTradeOrder(InsertOrder order, boolean isCoverT) {
        return 0;
    }

    /**
     * 撤单
     * @param order 交易单数据
     * @return 下单的session号或者错误码
     */
    public static int deleteTradeOrder(OrderData order) {
        return EsBaseApi.getInstance().deleteTradeOrder(order);
    }

    /**
     * 云条件单挂起
     * @param order 交易单数据
     * @return 下单的session号或者错误码
     */
    public static int suspendTradeOrder(OrderData order) {
        return EsBaseApi.getInstance().suspendTradeOrder(order);
    }

    /**
     * 云条件单激活
     * @param order 交易单数据
     * @return 下单的session号或者错误码
     */
    public static int  resumeTradeOrder(OrderData order) {
        return EsBaseApi.getInstance().resumeTradeOrder(order);
    }

    /**
     * 外盘合约改单
     * @param data 交易单数据
     * @param price 修改后的价格
     * @param qty 修改后的手数
     * @return 下单的session号或者错误码
     */
    public static int modifyTradeOrder(OrderData data, double price, BigInteger qty) {
        return 0;
    }

    /**
     * 外盘合约改单
     * @param data 交易单数据
     * @param price 修改后的价格
     * @param qty 修改后的手数
     * @return 下单的session号或者错误码
     */
    public static int modifyTradeOrder(OrderData data, double price, BigInteger qty, BigInteger maxQty) {
        return EsBaseApi.getInstance().modifyTradeOrder(data, price, qty, maxQty);
    }

    /**
     *  获取交易日期
     * @param companyNo 公司号
     * @param userNo 资金账号
     * @return 云仿真 0 内盘交易日 1 外盘交易日
     */
    public static String[] getTradeDate(String companyNo, String userNo){
//        return new String[]{"", ""};
        return EsBaseApi.getInstance().getTradeDate(companyNo, userNo);
    }

    /**
     *  账单确认
     * @param billConfirmReq 需要确认的账单
     * @return 确认结果
     */
    public static int billConfirm(BillConfirmReq billConfirmReq){
        return EsBaseApi.getInstance().billConfirm(billConfirmReq);
    }

    /**
     *  获取云交易公司数据
     * @param companyNo 公司号
     * @param addrNo 地址号
     * @return 云交易公司列表
     */
    public static List<CloudTradeCompany> getCloudTradeCompanyData(String companyNo, String addrNo){
        return EsBaseApi.getInstance().getCloudTradeCompanyData(companyNo, addrNo);
    }

    /**
     * 获取可用持仓数据
     * @param contract 合约
     * @param direct 方向
     * @param companyNo 账户公司号
     * @param userNo 账户资金号
     * @return 合约该方向的可用持仓，null表示数据输入错误
     * */

    public static AvailableQty getAvailableQty(Contract contract, char direct, char hedge, String companyNo, String userNo, String addrNo) {
        return null;
    }

    /**
     * 获取单个合约的持仓号
     * 用于查询单个合约持仓数据
     * @param contract 合约
     * @param direct 方向
     * @param hedge 投机套保
     * @return 持仓号
     */
    public static String getPositionNo(Contract contract, char direct, char hedge) {
        return null;
    }

    /**
     * 持仓详细数据查询
     * @param companyNo 公司号
     * @param userNo 资金账号
     * @param startNo 起始持仓号，为""查询所有
     * @param len 获取数据长度
     * @param isNow 是否从当前位置开始
     * @return 持仓数据列表
     */
    public static List<PositionData> getPositionData(String companyNo, String userNo, String addrNo, String startNo, int len, boolean isNow) {
        return new ArrayList<>();
    }

    /**
     * 持仓数据汇总查询(均价)
     * @param companyNo 公司号
     * @param userNo 资金账号
     * @param startNo 起始持仓号，为""查询所有
     * @param direct 持仓方向，0:买卖方向;'B': 买方向持仓；'S':卖方向持仓
     * @param isNow 是否从当前位置开始
     * @return 持仓数据列表
     */
    public static List<PositionData> getSumPositionData(String companyNo,String userNo, String addrNo, String startNo, char direct, boolean isNow){
        return EsBaseApi.getInstance().getSumPositionData(companyNo, userNo, addrNo, startNo, direct, isNow);
    }

    /**``````````````````````````````````
     * 获取单个合约某一方向上的可用持仓
     * @param companyNo 账户公司号
     * @param user 账户资金账号
     * @param contract 合约
     * @param direct 方向
     * @param hedge 投保
     * @return 合约数据，null则表示没有持仓数据
     */
    public static PositionData getContractPositionData(String companyNo, String user, String addrNo, Contract contract, char direct, char hedge) {
        return null;
    }

    /**
     * 处理分数报价
     * @param price 价格字符串
     * @param deno 如果是省略分母的分数字符串，需要给到分母
     * @return double格式
     */
    public static String getDoubleStrFromFractionStr(String price, int deno){
        return EsBaseApi.getInstance().getDoubleStrFromFractionStr(price, deno);
    }

    /**
     * 判断是否区分开平
     * @param commodity 品种结构体
     * @return true 不区分开平
     */
    public static boolean isForeignContract(Commodity commodity){
        return EsBaseApi.getInstance().isForeignContract(commodity);
    }

    /**
     * 用户委托信息查询
     * @param companyNo 期货公司号
     * @param userNo 资金账号
     * @param strategyType 策略类型 strategyType==\0时,普通委托
     * @param orderState 定单状态，填'\0'返回所有订单
     * @param orderNo 查询起始单号
     * @param len 查询数据长度,-1则为获取所有数据
     * @param isNow 查询起始位置，true从当前开始，false从下一个开始
     * @return 委托列表
     */
    public static List<OrderData> getOrderData(String companyNo,  String userNo, String addrNo, char strategyType, char orderState, String orderNo, int len, boolean isNow) {
        return EsBaseApi.getInstance().getOrderData(companyNo, userNo, addrNo, strategyType, orderState, orderNo, len, isNow);
    }

    /**
     * 获取用户成交数据
     * @param companyNo 公司号
     * @param userNo 资金账号
     * @param startNo 起始成交号
     * @param direct 买卖方向
     * @param len 指定要查询的成交数据个数
     * @param isNow 是否从当前位置查询
     * @return 成交数据列表
     */
    public static List<MatchData> getMatchData(String companyNo, String userNo, String addrNo, String startNo, char direct, int len, boolean isNow) {
        return EsBaseApi.getInstance().getMatchData(companyNo, userNo, addrNo, startNo, direct, len, isNow);
    }

    /**
     * 挂单数据查询
     * @param companyNo 公司号
     * @param userNo 资金账号
     * @param type 策略类型 type==\0时,普通委托
     * @param beginOrderNo 起始定单号，用于续查
     * @param len 数据长度， -1则表示为所有数据长度
     * @param isNow 是否从当前位置开始查询
     * @return 委托数据列表
     */
    public static List<OrderData> getPutOrderData(String companyNo, String userNo, String addrNo, char type, String beginOrderNo, int len, boolean isNow) {
        return EsBaseApi.getInstance().getPutOrderData(companyNo, userNo, addrNo, type, beginOrderNo, len, isNow);
    }

    /**
     *  订单查询
     *  @param companyNo 公司号
     *  @param userNo 资金账号
     *  @param billDate 账单日期
     *  @return 0: 查询成功；<0: 查询失败
     */
    public static int queryBill(String companyNo, String userNo, String addrNo, String billDate) {
        return EsBaseApi.getInstance().queryBill(companyNo, userNo, addrNo, billDate);
    }

    public static BillData getBillData(String companyNo, String userNo, String addrNo) {
        // TODO 新加接口，上次账单确认崩了,加个主动获取账单的接口
        return null;
    }

    /**
     * 获取合约买卖数量
     * @param companyNo 公司号
     * @param userNo 资金账号
     * @param contract 合约
     * @param direct 方向
     * @param hedge 套利保值
     * @return 买卖数量
     */
    public static int getOrderNum(String companyNo, String userNo, String addrNo, Contract contract, char direct, char hedge) {
        return 0;
    }

    /**
     *  可开可平数量查询
     *  @param calOpenCoverParam 请求结构体
     *  @return 0: 获取成功；<0: 获取失败；>0 可开可平数量
     */
    public static int  getOpenCoverCount(String companyno,  String userno, String addrno,  CalOpenCoverParam calOpenCoverParam){
        return 0;
    }

    /**
     * 银行余额查询
     *  @param bankBalanceQry 查询结构
     *  @return 0: 查询成功；<0: 失败
     */
    public static int qryBankBalance(BankBalanceQry bankBalanceQry) {
        return 0;
    }

    /**
     *  银期转账
     *
     *  @param bankTransferReq 请求结构
     *  @return 0: 转账成功；<0: 转账失败
     */
    public static int bankTransfer(BankTransferReq bankTransferReq) {
        return 0;
    }

    /**
     * 转账银行查询
     *  @param companyNo 公司号
     *  @param userNo 用户号
     *  @return 0: 查询成功；<0: 失败
     */
    public static int qryTransBank(String companyNo, String userNo, String addrNo) {
        return 0;
    }

    /**
     *  转账银行查询
     *
     *  @param companyNo 公司号
     *  @param userNo 用户号
     *  @return 0: 查询成功；<0: 失败
     */
    public static int qrySigningBank(String companyNo, String userNo, String addrNo) {
        return 0;
    }

    /**
     *  银期转账流水查询
     *
     *  @param companyNo 公司号
     *  @param userNo 资金账户
     *  @return 0: 查询成功；<0: 查询失败
     */
    public static int qryBankTransfer(String companyNo, String userNo, String addrNo) {
        return 0;
    }

    /**
     * 判断是否区分平今和平昨
     * @param commodity 品种结构体
     * @return true 平今
     */
    public static boolean isCoverTContract(Commodity commodity){
        return EsBaseApi.getInstance().isCoverTContract(commodity);
    }

    /**
     * 获取自对冲数量
     * @param contract 合约
     * @param direct 买卖方向
     * @param company 公司
     * @param userNo 用户名
     * @return 自对冲数量
     */
    public static int getCanSelfHedgingNum(Contract contract, char direct, char hedge, String company, String userNo, String addrNo) {
        return 0;
    }

    /**
     * 个推信息注册 启动时手机端获取填入
     * @param info 推送客户端的信息对象
     * @return 注册结果
     */
    public static int registPushInfo(PushClientInfo info){
        return EsBaseApi.getInstance().registPushInfo(info);
    }

    /**
     *  二次认证
     * @param companyNo 公司号
     * @param userNo 用户名
     * @return 二次认证的信息
     */
    public static TrdSecondCheckCodeInfo getSMSAuthMethod(String companyNo, String userNo, String addrNo){
        return null;
    }

    /**
     * 获取短信验证码
     * @param companyNo 公司号
     * @param userNo  用户名
     * @param sendType 发送类型
     * @param sendAccount 发送账户
     * @return 发送结果
     */
    public static int qrySMSAuthCode(String companyNo , String userNo, String addrNo, char sendType , String sendAccount){
        return 0;
    }

    /**
     * 发送短信验证码认证
     * @param companyno 公司名
     * @param userno 用户名
     * @param Code 验证码
     * @param loginType 登录设备类型
     * @return 发送结果
     */
    public static int SMSAuthCode(String companyno, String userno, String addrno, String Code, char loginType){
        return 0;
    }

    /**
     *  消息查询
     * @param companyno 公司号
     * @param userno 用户名
     * @return 查询结果
     */
    public static int qryMessage(String companyno, String userno, String addrno) {
        return EsBaseApi.getInstance().qryMessage(companyno, userno, addrno);
    }

    /**
     * 获取在线开户的公司列表
     * @return 开户公司信息列表
     */
    public static List<OpenCompanyInfo> getOpenCompany() {
        return new ArrayList<>();
    }

    /**
     * 获取股票合约的锁定和冻结数
     * @param companyno 公司号
     * @param userno 用户号
     * @param addrno 地址号
     * @param contractNo 合约号
     * @return 数组对象，数组长度为3，0 为 锁定数量， 1 为 今锁定数量， 2 为 冻结数量
     */
    public static BigInteger[] getLockQty(String companyno, String userno, String addrno, String contractNo) {
        return null;
    }

    /**
     * 获取用户账号下品种浮盈计算参数
     * @param companyNo 公司号
     * @param userNo 用户号
     * @param addrNo 地址号
     * @param commodityNo 品种号
     * @return 浮盈计算参数， NULL 表示没有按正常计算即可
     */
    public  static SASXParam getSASXParam(String companyNo, String userNo, String addrNo, String commodityNo) {
        return null;
    }

    /**
     * @param order       普通单
     * @param lossOrder   止损单
     * @param profitOrder 止盈单
     * @param brakeOrder  保本单
     * @return
     */
    public static int openWithStopLossOrder(InsertOrder order, InsertOrder lossOrder, InsertOrder profitOrder, InsertOrder brakeOrder) {
        return 0;
    }

    /**
     * @param data        普通单订单
     * @param price       改单价格
     * @param qty         改单手数
     * @param maxQty      最大手数
     * @param lossOrder   止损单
     * @param profitOrder 止盈单
     * @param brakeOrder  保本单
     * @return
     */
    public static int modifyStopLossOrder(OrderData data, double price, BigInteger qty, BigInteger maxQty,
                                          InsertOrder lossOrder, InsertOrder profitOrder, InsertOrder brakeOrder) {
        return 0;
    }

    /**
     * @param companyNo   公司号
     * @param userNo      用户号
     * @param addrNo      地址号
     * @param orderNo     订单号
     * @return
     */
    public static List<OrderData> getStopLossOrderByOrder(String companyNo, String userNo, String addrNo, String orderNo) {
        return getStopLossOrderByOrder(companyNo, userNo, addrNo, orderNo, '\0');
    }

    /**
     * @param companyNo   公司号
     * @param userNo      用户号
     * @param addrNo      地址号
     * @param orderNo     订单号
     * @param orderType   订单类型
     * @return
     */
    public static List<OrderData> getStopLossOrderByOrder(String companyNo, String userNo, String addrNo, String orderNo, char orderType) {
        return new ArrayList<>();
    }

    /**
     * 手动更新码表
     */
    public static void mannualUpdate() {
        EsBaseApi.getInstance().mannualUpdate();
    }

    /**
     *  手动清除码表数据
     */
    public static void clearCodeTableData() {
//        EsBaseApi.clearCodeTableData();
    }

    /***
     * 获取所有资金合约
     * @return 合约号数组
     */
    public static  String[] getAllFundsContract() {
        return null;
    }

    /***
     * 获取所有资金主力合约
     * @return 合约号数组
     */
    public static String[] getAllMainFundsContract() {
        return null;
    }

    /***
     * 获取所有资金板块合约
     * @return 合约号数组
     */
    public static String[] getAllPlateFundsContract() {
        return null;
    }

    /***
     * 获取所有资金品种合约
     * @return 合约号列表
     */
    public static String[] getAllCommodityFundsContract() {
        return null;
    }

    /***
     * 通过合约号获取资金数据
     * @param contractNo 合约号
     * @return 资金数据
     */
    public static FundsBetData getFundsBetData(String contractNo) {
        return null;
    }

    /***
     * 获取交易日志
     * @param companyNo 公司号
     * @param userNo 用户号
     * @return 日志列表
     */
    public static List<TradeLogInfo> getTradeLog(String companyNo, String userNo) {
        return new ArrayList<>();
    }

    /***
     * 获取交易日志文件
     * @param companyNo 公司号
     * @param userNo 用户号
     * @return 日志文件
     */
    public static File getTradeLogFile(String companyNo, String userNo) {
        return null;
    }

    public static int sendMsg(int key, char type, CspSessionHead head, byte[] data) {
        return EsBaseApi.getInstance().sendMsg(key, type, head, data);
    }
}
