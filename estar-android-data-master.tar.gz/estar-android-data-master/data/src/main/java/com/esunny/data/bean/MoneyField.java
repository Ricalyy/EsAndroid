package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class MoneyField {
    private short                                               index;
    private double                                              value;

    public short getIndex() {
        return index;
    }

    public void setIndex(short index) {
        this.index = index;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }
}
