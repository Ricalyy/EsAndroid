package com.esunny.data.api.event;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class NewsEvent extends AbstractAPIEvent {
    private NewsEvent(AbstractAPIEventBuilder builder) {
        super(builder);
    }

    public static class Builder extends AbstractAPIEventBuilder<NewsEvent>{

        public Builder(int action) {
            setAction(action);
        }

        @Override
        public AbstractEvent buildEvent() {
            return new NewsEvent(this);
        }
    }
}