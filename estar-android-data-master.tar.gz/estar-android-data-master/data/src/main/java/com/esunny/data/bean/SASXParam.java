package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class SASXParam {

    private String             ItemNo;               //项目标号
    private String        CommodityNo;            //品种编号
    private int          ItemValue;              //周期数-c
    private int          ItemNum;                 //计息次数-Num
    private double       ItemValueDouble;        //周期利率-Ratio

    public String getItemNo() {
        return ItemNo;
    }

    public void setItemNo(String itemNo) {
        ItemNo = itemNo;
    }

    public String getCommodityNo() {
        return CommodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        CommodityNo = commodityNo;
    }

    public int getItemValue() {
        return ItemValue;
    }

    public void setItemValue(int itemValue) {
        ItemValue = itemValue;
    }

    public int getItemNum() {
        return ItemNum;
    }

    public void setItemNum(int itemValueStr) {
        ItemNum = itemValueStr;
    }

    public double getItemValueDouble() {
        return ItemValueDouble;
    }

    public void setItemValueDouble(double itemValueDouble) {
        ItemValueDouble = itemValueDouble;
    }
}
