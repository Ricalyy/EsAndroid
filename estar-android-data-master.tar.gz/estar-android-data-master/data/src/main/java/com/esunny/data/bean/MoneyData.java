package com.esunny.data.bean;

import com.esunny.data.api.EsDataConstant;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class MoneyData {
    private String                                              companyNo;          //经纪公司编号
    private String                                              userNo;             //资金账号
    private String                                              AddressNo;          //地址号
    private String                                              currencyGroupNo;    //币种组编号
    private String                                              currencyNo;         //币种号(Currency_Base表示币种组基币资金)
    private double                                              exchangeRate;       //币种汇率
    private MoneyField dataEx[];        //资金数据,Data中已经包含一个数据，field若为null则代表不存在

    public MoneyData()
    {
        dataEx=new MoneyField[EsDataConstant.S_FID_MEAN_COUNT];
    }

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getAddressNo() {
        return AddressNo;
    }

    public void setAddressNo(String addressNo) {
        AddressNo = addressNo;
    }

    public String getCurrencyGroupNo() {
        return currencyGroupNo;
    }

    public void setCurrencyGroupNo(String currencyGroupNo) {
        this.currencyGroupNo = currencyGroupNo;
    }

    public String getCurrencyNo() {
        return currencyNo;
    }

    public void setCurrencyNo(String currencyNo) {
        this.currencyNo = currencyNo;
    }

    public double getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public MoneyField[] getDataEx() {
        return dataEx;
    }

    public void setDataEx(MoneyField[] value)
    {
        short vlen=(short)value.length;

        if(vlen>EsDataConstant.S_FID_MEAN_COUNT)
            vlen=EsDataConstant.S_FID_MEAN_COUNT;

        for(short i=0;i<vlen;++i)
        {
            dataEx[i]=value[i];
        }
    }
}
