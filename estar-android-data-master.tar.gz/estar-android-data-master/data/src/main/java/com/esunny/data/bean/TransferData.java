package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

public class TransferData{
    private String CompanyNo;          //经纪公司编号
    private String UserNo;             //期货资金账号
    private String AddressNo;          //地址号
    private String BankNo;             //银行标志
    private String BankAccount;        //银行卡号
    private String CurrencyNo;         //币种编号

    private char                      TransDirect;        //转账方向
    private double                    TransFund;          //转账金额
    private char                      TransState;         //转账状态

    private long                      BankSerialId;       //银行流水号
    private long                      FutureSerialId;     //期货流水号
    private String                    TransTime;          //转账时间

    private double                    BankFee;            //银行手续费
    private double                    FutureFee;          //期货公司手续费

    private int                       ErrorCode;          //错误码
    private String                    ErrorText;          //错误信息

    private char                      Initiator;          //转账发起方

    public TransferData(){

    }

    public void setCompanyNo(String value){
        CompanyNo=value;
    }

    public String getCompanyNo(){
        return CompanyNo;
    }

    public void setUserNo(String value){
        UserNo=value;
    }

    public String getUserNo(){
        return UserNo;
    }

    public String getAddressNo() {
        return AddressNo;
    }

    public void setAddressNo(String addressNo) {
        AddressNo = addressNo;
    }

    public void setBankNo(String value){
        BankNo=value;
    }

    public String getBankNo(){
        return BankNo;
    }

    public void setBankAccount(String value){
        BankAccount=value;
    }

    public String getBankAccount(){
        return BankAccount;
    }

    public void setCurrencyNo(String value){
        CurrencyNo=value;
    }

    public String getCurrencyNo(){
        return CurrencyNo;
    }

    public void setTransDirect(char value){
        TransDirect=value;
    }

    public char getTransDirect(){
        return TransDirect;
    }

    public void setTransFund(double value){
        TransFund=value;
    }

    public double getTransFund(){
        return TransFund;
    }

    public void setTransState(char value){
        TransState=value;
    }

    public char getTransState(){
        return TransState;
    }

    public void setBankSerialId(long value){
        BankSerialId=value;
    }

    public long getBankSerialId(){
        return BankSerialId;
    }

    public void setFutureSerialId(long value){
        FutureSerialId=value;
    }

    public long getFutureSerialId(){
        return FutureSerialId;
    }

    public void setTransTime(String value){
        TransTime=value;
    }

    public String getTransTime(){
        return TransTime;
    }

    public void setBankFee(double value){
        BankFee=value;
    }

    public double getBankFee(){
        return BankFee;
    }

    public void setFutureFee(double value){
        FutureFee=value;
    }

    public double getFutureFee(){
        return FutureFee;
    }

    public void setErrorCode(int value){
        ErrorCode=value;
    }

    public int getErrorCode(){
        return ErrorCode;
    }

    public void setErrorText(String value){
        ErrorText=value;
    }

    public String getErrorText(){
        return ErrorText;
    }

    public void setInitiator(char value){
        Initiator=value;
    }

    public char getInitiator(){
        return Initiator;
    }
}
