package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */

import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.util.EsSPHelperProxy;
import com.esunny.mobile.EsNativeProtocol;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Locale;

import static java.lang.String.format;

/**
 * 行情数据
 */

public class QuoteBetData implements Cloneable {

    public final static int PRICE_UP = 1;
    public final static int PRICE_DOWN = -1;
    public final static int PRICE_NO_CHANGE = 0;

    private Contract mContract;
    private SQuoteSnapShot mSnap;

    private boolean mIsBuyPriceImplied;
    private boolean mIsSellPriceImplied;
    private boolean mIsBuyQtyImplied;
    private boolean mIsSellQtyImplied;

    private double mLastPrice;
    private double mPreSettlePrice;
    private double mDiffPrice;
    private double mBuyPrice;
    private double mSellPrice;
    private double mLimitUpPrice;
    private double mLimitDownPrice;
    private double mOpenPrice;
    private double mHighPrice;
    private double mLowPrice;
    private double mPreClosingPrice;
    private double mAveragePrice;

    private BigInteger mBuyQty;
    private BigInteger mSellQty;
    private BigInteger mTotalQty;
    private BigInteger mTotalBuyPrice;
    private BigInteger mTotalSellPrice;
    private BigInteger mPosition;
    private BigInteger mLastQty;
    private BigInteger mPrePositionQty;

    private BigInteger mTradeDay;

    public QuoteBetData(Contract contract) {
        setContractData(contract);
    }

    public QuoteBetData() {
    }

    public void setContractData(Contract contract) {
        if (contract == null) {
            return;
        }
        mContract = contract;

        mLastPrice = 0;
        mPreSettlePrice = 0;
        mDiffPrice = 0;
        mBuyPrice = 0;
        mSellPrice = 0;
        mLimitUpPrice = 0;
        mLimitDownPrice = 0;
        mOpenPrice = 0;
        mHighPrice = 0;
        mLowPrice = 0;
        mPreClosingPrice = 0;
        mAveragePrice = 0;

        mTradeDay = BigInteger.ZERO;

        mBuyQty = BigInteger.ZERO;
        mSellQty = BigInteger.ZERO;
        mTotalQty = BigInteger.ZERO;
        mTotalBuyPrice = BigInteger.ZERO;
        mTotalSellPrice = BigInteger.ZERO;
        mPosition = BigInteger.ZERO;
        mLastQty = BigInteger.ZERO;
        mPrePositionQty = BigInteger.ZERO;

        mIsBuyPriceImplied = false;
        mIsSellPriceImplied = false;
        mIsBuyQtyImplied = false;
        mIsSellQtyImplied = false;

        if (!EsDataApi.hasContractPermission(contract)) {
            return;
        }

        mSnap = EsBaseApi.getInstance().getSnapShot(contract.getContractNo());
        if (mSnap == null) {
            return;
        }

        SQuoteField field = mSnap.getData().get(EsNativeProtocol.S_FID_DATETIME);
        if (field != null) {
            mTradeDay = field.getDateTime();
        }

        field = mSnap.getData().get(EsNativeProtocol.S_FID_PRECLOSINGPRICE);
        if (field != null) {
            mPreClosingPrice = field.getPrice();
        }

        field = mSnap.getData().get(EsNativeProtocol.S_FID_PRESETTLEPRICE);
        if (field != null) {
            mPreSettlePrice = field.getPrice();
        }
        //没有做结算的情况下，使用昨收盘来替代
        //套利合约做结算为0的情况下，也用昨收盘来替代
        if (mPreSettlePrice == 0) {
            mPreSettlePrice = mPreClosingPrice;
        }

        field = mSnap.getData().get(EsNativeProtocol.S_FID_LASTPRICE);
        if (field != null) {
            mLastPrice = field.getPrice();
        }

        //highPrice
        field = mSnap.getData().get(EsNativeProtocol.S_FID_HIGHPRICE);
        if (field != null) {
            mHighPrice = field.getPrice();
        }

        //lowPrice
        field = mSnap.getData().get(EsNativeProtocol.S_FID_LOWPRICE);
        if (field != null) {
            mLowPrice = field.getPrice();
        }

        //openPrice
        field = mSnap.getData().get(EsNativeProtocol.S_FID_OPENINGPRICE);
        if (field != null) {
            mOpenPrice = field.getPrice();
        }

        //卖价
        field = mSnap.getData().get(EsNativeProtocol.S_FID_BESTASKPRICE);
        if (field != null) {
            if (field.getFidAttr() == EsNativeProtocol.S_FIDATTR_IMPLIED) {
                mIsSellPriceImplied = true;
            }
            mSellPrice = field.getPrice();
        }

        //买价
        field = mSnap.getData().get(EsNativeProtocol.S_FID_BESTBIDPRICE);
        if (field != null) {
            if (field.getFidAttr() == EsNativeProtocol.S_FIDATTR_IMPLIED) {
                mIsBuyPriceImplied = true;
            }
            mBuyPrice = field.getPrice();
        }

        // 针对集合竞价行情需求，买卖价为0的情况下，取开盘价
        // 集合竞价阶段，回推送0的买卖价
        // 买卖价不全为0的情况下，肯定不为集合竞价阶段
        if (mSellPrice == 0 && mBuyPrice == 0 && !mContract.isArbitrageContract()) {
            mSellPrice = mBuyPrice = mOpenPrice;
        }

        //卖量
        field = mSnap.getData().get(EsNativeProtocol.S_FID_BESTASKQTY);
        if (field != null) {
            if (field.getFidAttr() == EsNativeProtocol.S_FIDATTR_IMPLIED) {
                mIsSellQtyImplied = true;
            }
            mSellQty = field.getQty();
        }

        //买量
        field = mSnap.getData().get(EsNativeProtocol.S_FID_BESTBIDQTY);
        if (field != null) {
            if (field.getFidAttr() == EsNativeProtocol.S_FIDATTR_IMPLIED) {
                mIsBuyQtyImplied = true;
            }
            mBuyQty = field.getQty();
        }
        //总买
        field = mSnap.getData().get(EsNativeProtocol.S_FID_TOTALBIDQTY);
        if (field != null) {
            mTotalBuyPrice = field.getQty();
        }
        //总卖
        field = mSnap.getData().get(EsNativeProtocol.S_FID_TOTALASKQTY);
        if (field != null) {
            mTotalSellPrice = field.getQty();
        }
        //持仓量
        field = mSnap.getData().get(EsNativeProtocol.S_FID_POSITIONQTY);
        if (field != null) {
            mPosition = field.getQty();
        }

        //成交量
        field = mSnap.getData().get(EsNativeProtocol.S_FID_LASTQTY);
        if (field != null) {
            mLastQty = field.getQty();
        }

        //均价
        field = mSnap.getData().get(EsNativeProtocol.S_FID_AVERAGEPRICE);
        if (field != null) {
            mAveragePrice = field.getPrice();
        }

        //昨持仓量
        field = mSnap.getData().get(EsNativeProtocol.S_FID_PREPOSITIONQTY);
        if (field != null) {
            mPrePositionQty = field.getQty();
        }

        field = mSnap.getData().get(EsNativeProtocol.S_FID_TOTALQTY);
        if (field != null) {
            mTotalQty = field.getQty();
        }

        //limitUpPrice
        field = mSnap.getData().get(EsNativeProtocol.S_FID_LIMITUPPRICE);
        if (field != null) {
            mLimitUpPrice = field.getPrice();
        }
        //limitDownPrice
        field = mSnap.getData().get(EsNativeProtocol.S_FID_LIMITDOWNPRICE);
        if (field != null) {
            mLimitDownPrice = field.getPrice();
        }

        //计算差价
        if (mLastPrice > 0 && (mPreSettlePrice > 0 || mPreClosingPrice > 0) || contract.isPriceBelowZero()) {
            mDiffPrice = calculateDiffPrice();
        }
    }

    /**
     *
     * @return 最新价和昨结等的差价
     */
    public double calculateDiffPrice() {
        int price = EsSPHelperProxy.getPriceCalculateMethod();
        if (price == EsSPHelperProxy.PRE_SETTLE_PRICE) {
            if (mLastPrice > 0 && (mPreSettlePrice > 0 || mPreClosingPrice > 0) || mContract.isPriceBelowZero()) {
                mDiffPrice = mLastPrice - mPreSettlePrice;
            }
        } else if (price == EsSPHelperProxy.PRE_CLOSING_PRICE) {
            if (mLastPrice > 0 && (mPreSettlePrice > 0 || mPreClosingPrice > 0) || mContract.isPriceBelowZero()) {
                mDiffPrice = mLastPrice - mPreClosingPrice;
            }

        } else if (price == EsSPHelperProxy.TODAY_OPEN_PRICE) {
            if (mLastPrice > 0 && (mPreSettlePrice > 0 || mPreClosingPrice > 0) || mContract.isPriceBelowZero()) {
                mDiffPrice = mLastPrice - mOpenPrice;
            }
        }
        return mDiffPrice;
    }

    public double calculateDiffPrice(double calculatePrice) {
        int price = EsSPHelperProxy.getPriceCalculateMethod();
        if (price == EsSPHelperProxy.PRE_SETTLE_PRICE) {
            mDiffPrice = calculatePrice - mPreSettlePrice;
        } else if (price == EsSPHelperProxy.PRE_CLOSING_PRICE) {
            mDiffPrice = calculatePrice - mPreClosingPrice;
        } else if (price == EsSPHelperProxy.TODAY_OPEN_PRICE) {
            mDiffPrice = calculatePrice - mOpenPrice;
        }
        return mDiffPrice;
    }

    public String price2String(double price) {
        return EsDataApi.formatPrice(mContract.getCommodity(), price, false);
    }

    public boolean isBuyPriceImplied() {
        return mIsBuyPriceImplied;
    }

    public boolean isSellPriceImplied() {
        return mIsSellPriceImplied;
    }

    public boolean isBuyQtyImplied() {
        return mIsBuyQtyImplied;
    }

    public boolean isSellQtyImplied() {
        return mIsSellQtyImplied;
    }

    public String getHighPriceString() {
        return price2String(mHighPrice);
    }

    public String getLowPriceString() {
        return price2String(mLowPrice);
    }

    public String getOpenPriceString() {
        return price2String(mOpenPrice);
    }

    public String getLastPriceString() {
        return price2String(mLastPrice);
    }

    public String getPreSettlePriceString() {
        if (mPreSettlePrice == 0){
            return price2String(mPreClosingPrice);
        }
        return price2String(mPreSettlePrice);
    }

    public String getBuyPriceString() {
        String str = price2String(mBuyPrice);
        if (mIsBuyPriceImplied) {
            return "*" + str;
        }
        return str;
    }

    public String getSellPriceString() {
        String str = price2String(mSellPrice);
        if (mIsSellPriceImplied) {
            return "*" + str;
        }
        return str;
    }

    public String getAveragePriceString() {
        return price2String(mAveragePrice);
    }

    public String getLimitUpPriceString() {
        return price2String(mLimitUpPrice);
    }

    public String getLimitDownPriceString() {
        return price2String(mLimitDownPrice);
    }

    public String getTotalSellPriceString() {
        return mTotalSellPrice.toString();
    }

    public String getTotalBuyPriceString() {
        return mTotalBuyPrice.toString();
    }

    public double getTickPrice() {
        double tickPrice;
        if (mContract.getCommodity().getPriceDeno() == 0) {
            tickPrice = 1.0;
        } else if (mContract.getCommodity().getPriceDeno() == 1) {
            tickPrice = mContract.getCommodity().getPriceNume();
        } else {
            tickPrice = mContract.getCommodity().getPriceTick();
        }
        return tickPrice;
    }

    public double getOpenPrice() {
        return mOpenPrice;
    }

    public double getLastPrice() {
        return mLastPrice;
    }

    public double getBuyPrice() {
        return mBuyPrice;
    }

    public double getSellPrice() {
        return mSellPrice;
    }

    public double getPreClosingPrice() {
        return mPreClosingPrice;
    }

    public double getAveragePrice() {
        return mAveragePrice;
    }

    public double getPreSettlePrice() {
        return mPreSettlePrice;
    }

    public double getLimitUpPrice() {
        return mLimitUpPrice;
    }

    public double getLimitDownPrice() {
        return mLimitDownPrice;
    }

    public double getHighPrice() {
        return mHighPrice;
    }

    public double getLowPrice() {
        return mLowPrice;
    }

    public String getPriceChangeString() {
        return price2String(mDiffPrice);
    }

    public String getPriceChangeString(double priceValue) {
        int price = EsSPHelperProxy.getPriceCalculateMethod();
        if (price == EsSPHelperProxy.PRE_SETTLE_PRICE && mPreSettlePrice > 0) {
            return price2String(priceValue - mPreSettlePrice);
        } else if (price == EsSPHelperProxy.PRE_CLOSING_PRICE && mPreClosingPrice > 0) {
            return price2String(priceValue - mPreClosingPrice);
        } else if (price == EsSPHelperProxy.TODAY_OPEN_PRICE && mOpenPrice > 0) {
            return price2String(priceValue - mOpenPrice);
        }
        return price2String(0);
    }

    public String getPriceChangePercentageString() {
        int price = EsSPHelperProxy.getPriceCalculateMethod();
        if (price == EsSPHelperProxy.PRE_SETTLE_PRICE && mPreSettlePrice != 0) {
            return String.format(Locale.getDefault(), "%.2f%%", mDiffPrice * 100 / Math.abs(mPreSettlePrice));
        } else if (price == EsSPHelperProxy.PRE_CLOSING_PRICE && mPreClosingPrice != 0) {
            return String.format(Locale.getDefault(), "%.2f%%", mDiffPrice * 100 / Math.abs(mPreClosingPrice));
        } else if (price == EsSPHelperProxy.TODAY_OPEN_PRICE && mOpenPrice != 0) {
            return String.format(Locale.getDefault(), "%.2f%%", mDiffPrice * 100 / Math.abs(mOpenPrice));
        }
        return String.format(Locale.getDefault(), "%.2f%%", 0.0);
    }

    public String getPriceChangePercentageString(double priceValue) {
        int price = EsSPHelperProxy.getPriceCalculateMethod();
        if (price == EsSPHelperProxy.PRE_SETTLE_PRICE && mPreSettlePrice > 0) {
            return String.format(Locale.getDefault(), "%.2f%%", (priceValue - mPreSettlePrice) * 100 / Math.abs(mPreSettlePrice));
        } else if (price == EsSPHelperProxy.PRE_CLOSING_PRICE && mPreClosingPrice > 0) {
            return String.format(Locale.getDefault(), "%.2f%%", (priceValue - mPreClosingPrice) * 100 / Math.abs(mPreClosingPrice));
        } else if (price == EsSPHelperProxy.TODAY_OPEN_PRICE && mOpenPrice > 0) {
            return String.format(Locale.getDefault(), "%.2f%%", (priceValue - mOpenPrice) * 100 / Math.abs(mOpenPrice));
        }
        return String.format(Locale.getDefault(), "%.2f%%", 0.0);
    }

    public BigInteger getBuyQty() {
        return mBuyQty;
    }

    public BigInteger getSellQty() {
        return mSellQty;
    }

    public BigInteger getTotalQty() {
        return mTotalQty;
    }

    public BigInteger getTotalBuyPrice() {
        return mTotalBuyPrice;
    }

    public BigInteger getTotalSellPrice() {
        return mTotalSellPrice;
    }

    public BigInteger getPosition() {
        return mPosition;
    }

    public BigInteger getLastQty() {
        return mLastQty;
    }

    public BigInteger getTradeDay() {
        return mTradeDay;
    }

    public BigInteger getPrePositionQty() {
        return mPrePositionQty;
    }

    public BigInteger getMusukuraQty() {
        return mPosition.subtract(mPrePositionQty);
    }

    public String getMusukuraRatioString() {
        BigInteger qty = getMusukuraQty();
        if (mPrePositionQty.compareTo(BigInteger.ZERO) == 0) {
            return String.format(Locale.getDefault(), "%.2f%%", 0.0);
        } else {
            double per = qty.doubleValue() / mPrePositionQty.doubleValue() * 100;
            return String.format(Locale.getDefault(), "%.2f%%", per);
        }
    }

    public BigInteger getAddPositionQty() {
        return mPosition.subtract(mPrePositionQty);
    }

    public Date getTradeDate() {
        return new Date(mTradeDay.longValue() / 1000000000L);
    }

    public void setPreSettlePrice(double price) {
        mPreSettlePrice = price;
    }

    public void setPreClosingPrice(double price) {
        mPreClosingPrice = price;
    }

    public int priceUpOrDown() {
        return new BigDecimal(mDiffPrice).compareTo(BigDecimal.ZERO);
    }

    public int positionUpOrDown() {
        return mPosition.compareTo(mPrePositionQty);
    }

    public int limitHighUpOrDown() {
        if (mLimitUpPrice > 0) {
            return PRICE_UP;
        }
        return PRICE_NO_CHANGE;
    }

    public int limitLowUpOrDown() {
        if (mLimitDownPrice > 0) {
            return PRICE_DOWN;
        }
        return PRICE_NO_CHANGE;
    }

    public boolean isValid() {
//        return mSnap != null;
        return true;
    }

    public String getVolatilityString() {

        return "----";
    }

    public String getDeltaString() {

        return "----";
    }

    public String getGammaString() {
        return "----";
    }

    public double getTurnover() {

        return 0;
    }

    public double getOreticalPrice() {

        return 0;
    }

    public double getRatio() {

        return 0;
    }

    public double getDelta() {

        return 0;
    }

    public double getGamma() {

        return 0;
    }

    public double getVega() {

        return 0;
    }

    public double getTheta() {

        return 0;
    }

    public double getRho() {
        return 0;
    }

    public boolean isPriceValid(double price) {

        return (mLimitUpPrice <= 0 || price <= mLimitUpPrice) && (mLimitDownPrice <= 0 || price >= mLimitDownPrice);
    }

    @Override
    public Object clone() {
        QuoteBetData data = null;
        try {
            data = (QuoteBetData) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return data;
    }
}

