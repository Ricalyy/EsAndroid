package com.esunny.mobile.bean;

import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.UnixJNI;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class CspSessionHead extends ApiStruct {

    public final static int STRUCT_LENGTH = 56;

    private short           ProtocolVer;        //协议版本号
    private short           LangType;           //语言类型
    private String          PackageNo;          //包号
    private char            SubSystem;          //子系统号,解析协议使用，防止协议重复
    private short           ProtocolCode;       //消息类型
    private int             SessionId;          //会话号，客户端填写
    private int             LinkId;             //间接层客户端id
    private char            Chain;              //报文链标识
    private short           FieldSize;          //报文长度
    private short           FieldCount;         //报文个数
    private int             ErrorCode;          //错误码
    private String          AuthCode;           //认证串(短连接使用,服务器生成的随机串,具有有效时间,用于身份识别)

    public CspSessionHead() {
    }

    public CspSessionHead(byte[] buf) {
        byteToBean(buf);
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.putShort(ProtocolVer);
        buffer.putShort(LangType);
        buffer.put(stringToByte(PackageNo, 11));
        buffer.put(charToByte(SubSystem));
        buffer.putShort(ProtocolCode);
        buffer.putInt(SessionId);
        buffer.putInt(LinkId);
        buffer.put(charToByte(Chain));
        buffer.putShort(FieldSize);
        buffer.putShort(FieldCount);
        buffer.putInt(ErrorCode);
        buffer.put(stringToByte(AuthCode, 21));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setProtocolVer(util.getShort());
        setLangType(util.getUnsignedShort());
        setPackageNo(util.getString(11));
        setSubSystem(util.getChar());
        setProtocolCode(util.getUnsignedShort());
        setSessionId(util.getUnsignedInt());
        setLinkId(util.getUnsignedInt());
        setChain(util.getChar());
        setFieldSize(util.getUnsignedShort());
        setFieldCount(util.getUnsignedShort());
        setErrorCode(util.getUnsignedInt());
        setAuthCode(util.getString(21));
    }

    public static CspSessionHead getCspSessionHead(int protocolCode, char subSystem, int fileSize) {
        CspSessionHead head = new CspSessionHead();
        head.setProtocolVer(EsNativeProtocol.CSP_PROTOCOL_VER);
        head.setChain(EsNativeProtocol.CSP_CHAIN_END);
        head.setFieldCount(1);
        head.setLangType(EsBaseApi.getInstance().getLanguageType());
        head.setPackageNo(UnixJNI.S_GetPackageNo());
        head.setSessionId(EsBaseApi.getInstance().getmSessionId());

        head.setFieldSize(fileSize);
        head.setProtocolCode(protocolCode);
        head.setSubSystem(subSystem);
        return head;
    }

    public static CspSessionHead getCspSessionHead(short protocolVer, int protocolCode, char subSystem, int fileSize) {
        CspSessionHead head = getCspSessionHead(protocolCode, subSystem, fileSize);
        head.setProtocolVer(protocolVer);
        return head;
    }

    public short getProtocolVer() {
        return ProtocolVer;
    }

    public void setProtocolVer(short protocolVer) {
        ProtocolVer = protocolVer;
    }

    public int getLangType() {
        return unsignedShortToInt(LangType);
    }

    public void setLangType(int langType) {
        LangType = (short) langType;
    }

    public String getPackageNo() {
        return PackageNo;
    }

    public void setPackageNo(String packageNo) {
        PackageNo = packageNo;
    }

    public char getSubSystem() {
        return SubSystem;
    }

    public void setSubSystem(char subSystem) {
        SubSystem = subSystem;
    }

    public int getProtocolCode() {
        return unsignedShortToInt(ProtocolCode);
    }

    public void setProtocolCode(int protocolCode) {
        ProtocolCode = (short) protocolCode;
    }

    public long getSessionId() {
        return unsignedIntToLong(SessionId);
    }

    public void setSessionId(long sessionId) {
        SessionId = (int) sessionId;
    }

    public long getLinkId() {
        return unsignedIntToLong(LinkId);
    }

    public void setLinkId(long linkId) {
        LinkId = (int) linkId;
    }

    public char getChain() {
        return Chain;
    }

    public void setChain(char chain) {
        Chain = chain;
    }

    public int getFieldSize() {
        return unsignedShortToInt(FieldSize);
    }

    public void setFieldSize(int fieldSize) {
        FieldSize = (short) fieldSize;
    }

    public int getFieldCount() {
        return unsignedShortToInt(FieldCount);
    }

    public void setFieldCount(int fieldCount) {
        FieldCount = (short) fieldCount;
    }

    public long getErrorCode() {
        return unsignedIntToLong(ErrorCode);
    }

    public void setErrorCode(long errorCode) {
        ErrorCode = (int) errorCode;
    }

    public String getAuthCode() {
        return AuthCode;
    }

    public void setAuthCode(String authCode) {
        AuthCode = authCode;
    }
}
