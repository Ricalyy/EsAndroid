package com.esunny.data.error;

import android.content.Context;

import com.esunny.data.R;

class DaystarErrorCode {

    static String getErrorMessage(Context context, int errorCode) {

        switch (errorCode) {
            case 0 :
                return context.getResources().getString(R.string.daystar_0);
            case -1 :
                return context.getResources().getString(R.string.daystar_n1);
            case -2 :
                return context.getResources().getString(R.string.daystar_n2);
            case -3 :
                return context.getResources().getString(R.string.daystar_n3);
            case -4 :
                return context.getResources().getString(R.string.daystar_n4);
            case -5 :
                return context.getResources().getString(R.string.daystar_n5);
            case -6 :
                return context.getResources().getString(R.string.daystar_n6);
            case -7 :
                return context.getResources().getString(R.string.daystar_n7);
            case -8 :
                return context.getResources().getString(R.string.daystar_n8);
            case -9 :
                return context.getResources().getString(R.string.daystar_n9);
            case -10 :
                return context.getResources().getString(R.string.daystar_n10);
            case -11 :
                return context.getResources().getString(R.string.daystar_n11);
            case -12 :
                return context.getResources().getString(R.string.daystar_n12);
            case -13 :
                return context.getResources().getString(R.string.daystar_n13);
            case -14 :
                return context.getResources().getString(R.string.daystar_n14);
            case -15 :
                return context.getResources().getString(R.string.daystar_n15);
            case -16 :
                return context.getResources().getString(R.string.daystar_n16);
            case -17 :
                return context.getResources().getString(R.string.daystar_n17);
            case -18 :
                return context.getResources().getString(R.string.daystar_n18);
            case -19 :
                return context.getResources().getString(R.string.daystar_n19);
            case -20 :
                return context.getResources().getString(R.string.daystar_n20);
            case -21 :
                return context.getResources().getString(R.string.daystar_n21);
            case -22 :
                return context.getResources().getString(R.string.daystar_n22);
            case -23 :
                return context.getResources().getString(R.string.daystar_n23);
            case -24 :
                return context.getResources().getString(R.string.daystar_n24);
            case -25 :
                return context.getResources().getString(R.string.daystar_n25);
            case -26 :
                return context.getResources().getString(R.string.daystar_n26);
            case -27 :
                return context.getResources().getString(R.string.daystar_n27);
            case -28 :
                return context.getResources().getString(R.string.daystar_n28);
            case -29 :
                return context.getResources().getString(R.string.daystar_n29);
            case -30 :
                return context.getResources().getString(R.string.daystar_n30);
            case -31 :
                return context.getResources().getString(R.string.daystar_n31);
            case -32 :
                return context.getResources().getString(R.string.daystar_n32);
            case -33 :
                return context.getResources().getString(R.string.daystar_n33);
            case -34 :
                return context.getResources().getString(R.string.daystar_n34);
            case -35 :
                return context.getResources().getString(R.string.daystar_n35);
            case -36 :
                return context.getResources().getString(R.string.daystar_n36);
            case -37 :
                return context.getResources().getString(R.string.daystar_n37);
            case -10000 :
                return context.getResources().getString(R.string.daystar_n10000);
            case -10001 :
                return context.getResources().getString(R.string.daystar_n10001);
            case -10002 :
                return context.getResources().getString(R.string.daystar_n10002);
            case -10003 :
                return context.getResources().getString(R.string.daystar_n10003);
            case -10004 :
                return context.getResources().getString(R.string.daystar_n10004);
            case -10005 :
                return context.getResources().getString(R.string.daystar_n10005);
            case -10006 :
                return context.getResources().getString(R.string.daystar_n10006);
            case -12001 :
                return context.getResources().getString(R.string.daystar_n12001);
            case -12003 :
                return context.getResources().getString(R.string.daystar_n12003);
            case -12004 :
                return context.getResources().getString(R.string.daystar_n12004);
            case -12005 :
                return context.getResources().getString(R.string.daystar_n12005);
            case -12006 :
                return context.getResources().getString(R.string.daystar_n12006);
            case -12007 :
                return context.getResources().getString(R.string.daystar_n12007);
            case -12008 :
                return context.getResources().getString(R.string.daystar_n12008);
            case -12009 :
                return context.getResources().getString(R.string.daystar_n12009);
            case -12010 :
                return context.getResources().getString(R.string.daystar_n12010);
            case -12011 :
                return context.getResources().getString(R.string.daystar_n12011);
            case -12012 :
                return context.getResources().getString(R.string.daystar_n12012);
            case -12013 :
                return context.getResources().getString(R.string.daystar_n12013);
            case -12014 :
                return context.getResources().getString(R.string.daystar_n12014);
            case -12015 :
                return context.getResources().getString(R.string.daystar_n12015);
            case -12016 :
                return context.getResources().getString(R.string.daystar_n12016);
            case -12017 :
                return context.getResources().getString(R.string.daystar_n12017);
            case -12021 :
                return context.getResources().getString(R.string.daystar_n12021);
            case -12022 :
                return context.getResources().getString(R.string.daystar_n12022);
            case -12023 :
                return context.getResources().getString(R.string.daystar_n12023);
            case -12024 :
                return context.getResources().getString(R.string.daystar_n12024);
            case -12025 :
                return context.getResources().getString(R.string.daystar_n12025);
            case -12035 :
                return context.getResources().getString(R.string.daystar_n12035);
            case -12036 :
                return context.getResources().getString(R.string.daystar_n12036);
            case -12041 :
                return context.getResources().getString(R.string.daystar_n12041);
            case -12042 :
                return context.getResources().getString(R.string.daystar_n12042);
            case -12043 :
                return context.getResources().getString(R.string.daystar_n12043);
            case -12044 :
                return context.getResources().getString(R.string.daystar_n12044);
            case -12045 :
                return context.getResources().getString(R.string.daystar_n12045);
            case -12046 :
                return context.getResources().getString(R.string.daystar_n12046);
            case -12047 :
                return context.getResources().getString(R.string.daystar_n12047);
            case -12048 :
                return context.getResources().getString(R.string.daystar_n12048);
            case -12049 :
                return context.getResources().getString(R.string.daystar_n12049);
            case -12050 :
                return context.getResources().getString(R.string.daystar_n12050);
            case -12051 :
                return context.getResources().getString(R.string.daystar_n12051);
            case 1 :
                return context.getResources().getString(R.string.daystar_1);
            case 2 :
                return context.getResources().getString(R.string.daystar_2);
            case 3 :
                return context.getResources().getString(R.string.daystar_3);
            case 4 :
                return context.getResources().getString(R.string.daystar_4);
            case 5 :
                return context.getResources().getString(R.string.daystar_5);
            case 6 :
                return context.getResources().getString(R.string.daystar_6);
            case 7 :
                return context.getResources().getString(R.string.daystar_7);
            case 8 :
                return context.getResources().getString(R.string.daystar_8);
            case 9 :
                return context.getResources().getString(R.string.daystar_9);
            case 10 :
                return context.getResources().getString(R.string.daystar_10);
            case 11 :
                return context.getResources().getString(R.string.daystar_11);
            case 12 :
                return context.getResources().getString(R.string.daystar_12);
            case 13 :
                return context.getResources().getString(R.string.daystar_13);
            case 14 :
                return context.getResources().getString(R.string.daystar_14);
            case 15 :
                return context.getResources().getString(R.string.daystar_15);
            case 10001 :
                return context.getResources().getString(R.string.daystar_10001);
            case 10002 :
                return context.getResources().getString(R.string.daystar_10002);
            case 10003 :
                return context.getResources().getString(R.string.daystar_10003);
            case 10004 :
                return context.getResources().getString(R.string.daystar_10004);
            case 10005 :
                return context.getResources().getString(R.string.daystar_10005);
            case 10006 :
                return context.getResources().getString(R.string.daystar_10006);
            case 10007 :
                return context.getResources().getString(R.string.daystar_10007);
            case 10008 :
                return context.getResources().getString(R.string.daystar_10008);
            case 10009 :
                return context.getResources().getString(R.string.daystar_10009);
            case 10010 :
                return context.getResources().getString(R.string.daystar_10010);
            case 10011 :
                return context.getResources().getString(R.string.daystar_10011);
            case 10012 :
                return context.getResources().getString(R.string.daystar_10012);
            case 10013 :
                return context.getResources().getString(R.string.daystar_10013);
            case 10014 :
                return context.getResources().getString(R.string.daystar_10014);
            case 10015 :
                return context.getResources().getString(R.string.daystar_10015);
            case 10016 :
                return context.getResources().getString(R.string.daystar_10016);
            case 10017 :
                return context.getResources().getString(R.string.daystar_10017);
            case 10018 :
                return context.getResources().getString(R.string.daystar_10018);
            case 10019 :
                return context.getResources().getString(R.string.daystar_10019);
            case 10050 :
                return context.getResources().getString(R.string.daystar_10050);
            case 10052 :
                return context.getResources().getString(R.string.daystar_10052);
            case 10053 :
                return context.getResources().getString(R.string.daystar_10053);
            case 10054 :
                return context.getResources().getString(R.string.daystar_10054);
            case 10055 :
                return context.getResources().getString(R.string.daystar_10055);
            case 10056 :
                return context.getResources().getString(R.string.daystar_10056);
            case 10057 :
                return context.getResources().getString(R.string.daystar_10057);
            case 10058 :
                return context.getResources().getString(R.string.daystar_10058);
            case 10059 :
                return context.getResources().getString(R.string.daystar_10059);
            case 10060 :
                return context.getResources().getString(R.string.daystar_10060);
            case 10061 :
                return context.getResources().getString(R.string.daystar_10061);
            case 10062 :
                return context.getResources().getString(R.string.daystar_10062);
            case 10101 :
                return context.getResources().getString(R.string.daystar_10101);
            case 10102 :
                return context.getResources().getString(R.string.daystar_10102);
            case 10103 :
                return context.getResources().getString(R.string.daystar_10103);
            case 10104 :
                return context.getResources().getString(R.string.daystar_10104);
            case 10105 :
                return context.getResources().getString(R.string.daystar_10105);
            case 10201 :
                return context.getResources().getString(R.string.daystar_10201);
            case 10202 :
                return context.getResources().getString(R.string.daystar_10202);
            case 10203 :
                return context.getResources().getString(R.string.daystar_10203);
            case 10204 :
                return context.getResources().getString(R.string.daystar_10204);
            case 10301 :
                return context.getResources().getString(R.string.daystar_10301);
            case 10302 :
                return context.getResources().getString(R.string.daystar_10302);
            case 10303 :
                return context.getResources().getString(R.string.daystar_10303);
            case 10304 :
                return context.getResources().getString(R.string.daystar_10304);
            case 10305 :
                return context.getResources().getString(R.string.daystar_10305);
            case 10401 :
                return context.getResources().getString(R.string.daystar_10401);
            case 10402 :
                return context.getResources().getString(R.string.daystar_10402);
            case 10403 :
                return context.getResources().getString(R.string.daystar_10403);
            case 10501 :
                return context.getResources().getString(R.string.daystar_10501);
            case 10601 :
                return context.getResources().getString(R.string.daystar_10601);
            case 10602 :
                return context.getResources().getString(R.string.daystar_10602);
            case 10603 :
                return context.getResources().getString(R.string.daystar_10603);
            case 10604 :
                return context.getResources().getString(R.string.daystar_10604);
            case 10605 :
                return context.getResources().getString(R.string.daystar_10605);
            case 10701 :
                return context.getResources().getString(R.string.daystar_10701);
            case 10702 :
                return context.getResources().getString(R.string.daystar_10702);
            case 10703 :
                return context.getResources().getString(R.string.daystar_10703);
            case 10801 :
                return context.getResources().getString(R.string.daystar_10801);
            case 10802 :
                return context.getResources().getString(R.string.daystar_10802);
            case 10803 :
                return context.getResources().getString(R.string.daystar_10803);
            case 10901 :
                return context.getResources().getString(R.string.daystar_10901);
            case 10902 :
                return context.getResources().getString(R.string.daystar_10902);
            case 10903 :
                return context.getResources().getString(R.string.daystar_10903);
            case 11001 :
                return context.getResources().getString(R.string.daystar_11001);
            case 11002 :
                return context.getResources().getString(R.string.daystar_11002);
            case 11003 :
                return context.getResources().getString(R.string.daystar_11003);
            case 11101 :
                return context.getResources().getString(R.string.daystar_11101);
            case 11102 :
                return context.getResources().getString(R.string.daystar_11102);
            case 11103 :
                return context.getResources().getString(R.string.daystar_11103);
            case 11104 :
                return context.getResources().getString(R.string.daystar_11104);
            case 11201 :
                return context.getResources().getString(R.string.daystar_11201);
            case 11202 :
                return context.getResources().getString(R.string.daystar_11202);
            case 11203 :
                return context.getResources().getString(R.string.daystar_11203);
            case 11204 :
                return context.getResources().getString(R.string.daystar_11204);
            case 11301 :
                return context.getResources().getString(R.string.daystar_11301);
            case 11302 :
                return context.getResources().getString(R.string.daystar_11302);
            case 11303 :
                return context.getResources().getString(R.string.daystar_11303);
            case 11401 :
                return context.getResources().getString(R.string.daystar_11401);
            case 11402 :
                return context.getResources().getString(R.string.daystar_11402);
            case 11403 :
                return context.getResources().getString(R.string.daystar_11403);
            case 11501 :
                return context.getResources().getString(R.string.daystar_11501);
            case 11502 :
                return context.getResources().getString(R.string.daystar_11502);
            case 11503 :
                return context.getResources().getString(R.string.daystar_11503);
            case 11601 :
                return context.getResources().getString(R.string.daystar_11601);
            case 11602 :
                return context.getResources().getString(R.string.daystar_11602);
            case 11701 :
                return context.getResources().getString(R.string.daystar_11701);
            case 11702 :
                return context.getResources().getString(R.string.daystar_11702);
            case 11703 :
                return context.getResources().getString(R.string.daystar_11703);
            case 11704 :
                return context.getResources().getString(R.string.daystar_11704);
            case 11801 :
                return context.getResources().getString(R.string.daystar_11801);
            case 11802 :
                return context.getResources().getString(R.string.daystar_11802);
            case 11803 :
                return context.getResources().getString(R.string.daystar_11803);
            case 11901 :
                return context.getResources().getString(R.string.daystar_11901);
            case 12001 :
                return context.getResources().getString(R.string.daystar_12001);
            case 12002 :
                return context.getResources().getString(R.string.daystar_12002);
            case 12003 :
                return context.getResources().getString(R.string.daystar_12003);
            case 12011 :
                return context.getResources().getString(R.string.daystar_12011);
            case 12012 :
                return context.getResources().getString(R.string.daystar_12012);
            case 12013 :
                return context.getResources().getString(R.string.daystar_12013);
            case 12014 :
                return context.getResources().getString(R.string.daystar_12014);
            case 12021 :
                return context.getResources().getString(R.string.daystar_12021);
            case 12031 :
                return context.getResources().getString(R.string.daystar_12031);
            case 12032 :
                return context.getResources().getString(R.string.daystar_12032);
            case 12033 :
                return context.getResources().getString(R.string.daystar_12033);
            case 12041 :
                return context.getResources().getString(R.string.daystar_12041);
            case 12051 :
                return context.getResources().getString(R.string.daystar_12051);
            case 12061 :
                return context.getResources().getString(R.string.daystar_12061);
            case 12071 :
                return context.getResources().getString(R.string.daystar_12071);
            case 12101 :
                return context.getResources().getString(R.string.daystar_12101);
            case 12102 :
                return context.getResources().getString(R.string.daystar_12102);
            case 12103 :
                return context.getResources().getString(R.string.daystar_12103);
            case 12104 :
                return context.getResources().getString(R.string.daystar_12104);
            case 12105 :
                return context.getResources().getString(R.string.daystar_12105);
            case 12106 :
                return context.getResources().getString(R.string.daystar_12106);
            case 12201 :
                return context.getResources().getString(R.string.daystar_12201);
            case 12202 :
                return context.getResources().getString(R.string.daystar_12202);
            case 12203 :
                return context.getResources().getString(R.string.daystar_12203);
            case 12204 :
                return context.getResources().getString(R.string.daystar_12204);
            case 12301 :
                return context.getResources().getString(R.string.daystar_12301);
            case 12302 :
                return context.getResources().getString(R.string.daystar_12302);
            case 12303 :
                return context.getResources().getString(R.string.daystar_12303);
            case 14001 :
                return context.getResources().getString(R.string.daystar_14001);
            case 14002 :
                return context.getResources().getString(R.string.daystar_14002);
            case 60001 :
                return context.getResources().getString(R.string.daystar_60001);
            case 60002 :
                return context.getResources().getString(R.string.daystar_60002);
            case 60003 :
                return context.getResources().getString(R.string.daystar_60003);
            case 60004 :
                return context.getResources().getString(R.string.daystar_60004);
            case 60005 :
                return context.getResources().getString(R.string.daystar_60005);
            case 60006 :
                return context.getResources().getString(R.string.daystar_60006);
            case 60007 :
                return context.getResources().getString(R.string.daystar_60007);
            case 60011 :
                return context.getResources().getString(R.string.daystar_60011);
            case 60021 :
                return context.getResources().getString(R.string.daystar_60021);
            case 60022 :
                return context.getResources().getString(R.string.daystar_60022);
            case 60023 :
                return context.getResources().getString(R.string.daystar_60023);
            case 60024 :
                return context.getResources().getString(R.string.daystar_60024);
            case 60031 :
                return context.getResources().getString(R.string.daystar_60031);
            case 60032 :
                return context.getResources().getString(R.string.daystar_60032);
            case 60033 :
                return context.getResources().getString(R.string.daystar_60033);
            case 60034 :
                return context.getResources().getString(R.string.daystar_60034);
            case 60035 :
                return context.getResources().getString(R.string.daystar_60035);
            case 60036 :
                return context.getResources().getString(R.string.daystar_60036);
            case 60037 :
                return context.getResources().getString(R.string.daystar_60037);
            case 60038 :
                return context.getResources().getString(R.string.daystar_60038);
            case 60039 :
                return context.getResources().getString(R.string.daystar_60039);
            case 60040 :
                return context.getResources().getString(R.string.daystar_60040);
            case 60051 :
                return context.getResources().getString(R.string.daystar_60051);
            case 60052 :
                return context.getResources().getString(R.string.daystar_60052);
            case 60053 :
                return context.getResources().getString(R.string.daystar_60053);
            case 60061 :
                return context.getResources().getString(R.string.daystar_60061);
            case 60062 :
                return context.getResources().getString(R.string.daystar_60062);
            case 60063 :
                return context.getResources().getString(R.string.daystar_60063);
            case 60064 :
                return context.getResources().getString(R.string.daystar_60064);
            case 60071 :
                return context.getResources().getString(R.string.daystar_60071);
            case 60072 :
                return context.getResources().getString(R.string.daystar_60072);
            case 60081 :
                return context.getResources().getString(R.string.daystar_60081);
            case 60082 :
                return context.getResources().getString(R.string.daystar_60082);
            case 60091 :
                return context.getResources().getString(R.string.daystar_60091);
            case 60092 :
                return context.getResources().getString(R.string.daystar_60092);
            case 60100 :
                return context.getResources().getString(R.string.daystar_60100);
            case 60101 :
                return context.getResources().getString(R.string.daystar_60101);
            case 60102 :
                return context.getResources().getString(R.string.daystar_60102);
            case 60103 :
                return context.getResources().getString(R.string.daystar_60103);
            case 60104 :
                return context.getResources().getString(R.string.daystar_60104);
            case 60105 :
                return context.getResources().getString(R.string.daystar_60105);
            case 60106 :
                return context.getResources().getString(R.string.daystar_60106);
            case 60107 :
                return context.getResources().getString(R.string.daystar_60107);
            case 60108 :
                return context.getResources().getString(R.string.daystar_60108);
            case 60109 :
                return context.getResources().getString(R.string.daystar_60109);
            case 60110 :
                return context.getResources().getString(R.string.daystar_60110);
            case 60111 :
                return context.getResources().getString(R.string.daystar_60111);
            case 60112 :
                return context.getResources().getString(R.string.daystar_60112);
            case 60113 :
                return context.getResources().getString(R.string.daystar_60113);
            case 60114 :
                return context.getResources().getString(R.string.daystar_60114);
            case 60115 :
                return context.getResources().getString(R.string.daystar_60115);
            case 60116 :
                return context.getResources().getString(R.string.daystar_60116);
            case 60117 :
                return context.getResources().getString(R.string.daystar_60117);
            case 60118 :
                return context.getResources().getString(R.string.daystar_60118);
            case 60119 :
                return context.getResources().getString(R.string.daystar_60119);
            case 60120 :
                return context.getResources().getString(R.string.daystar_60120);
            case 60503 :
                return context.getResources().getString(R.string.daystar_60503);
            case 60504 :
                return context.getResources().getString(R.string.daystar_60504);
            case 60505 :
                return context.getResources().getString(R.string.daystar_60505);
            case 60506 :
                return context.getResources().getString(R.string.daystar_60506);
            case 60511 :
                return context.getResources().getString(R.string.daystar_60511);
            case 60512 :
                return context.getResources().getString(R.string.daystar_60512);
            case 60513 :
                return context.getResources().getString(R.string.daystar_60513);
            case 60514 :
                return context.getResources().getString(R.string.daystar_60514);
            case 60515 :
                return context.getResources().getString(R.string.daystar_60515);
            case 60521 :
                return context.getResources().getString(R.string.daystar_60521);
            case 60522 :
                return context.getResources().getString(R.string.daystar_60522);
            case 60523 :
                return context.getResources().getString(R.string.daystar_60523);
            case 60524 :
                return context.getResources().getString(R.string.daystar_60524);
            case 60525 :
                return context.getResources().getString(R.string.daystar_60525);
            case 60526 :
                return context.getResources().getString(R.string.daystar_60526);
            case 60527 :
                return context.getResources().getString(R.string.daystar_60527);
            case 60528 :
                return context.getResources().getString(R.string.daystar_60528);
            case 60529 :
                return context.getResources().getString(R.string.daystar_60529);
            case 60530 :
                return context.getResources().getString(R.string.daystar_60530);
            case 60531 :
                return context.getResources().getString(R.string.daystar_60531);
            case 60532 :
                return context.getResources().getString(R.string.daystar_60532);
            case 60533 :
                return context.getResources().getString(R.string.daystar_60533);
            case 60534 :
                return context.getResources().getString(R.string.daystar_60534);
            case 60535 :
                return context.getResources().getString(R.string.daystar_60535);
            case 60541 :
                return context.getResources().getString(R.string.daystar_60541);
            case 60542 :
                return context.getResources().getString(R.string.daystar_60542);
            case 60551 :
                return context.getResources().getString(R.string.daystar_60551);
            case 60552 :
                return context.getResources().getString(R.string.daystar_60552);
            case 60553 :
                return context.getResources().getString(R.string.daystar_60553);
            case 60554 :
                return context.getResources().getString(R.string.daystar_60554);
            case 60555 :
                return context.getResources().getString(R.string.daystar_60555);
            case 60556 :
                return context.getResources().getString(R.string.daystar_60556);
            case 60557 :
                return context.getResources().getString(R.string.daystar_60557);
            case 60558 :
                return context.getResources().getString(R.string.daystar_60558);
            case 60561 :
                return context.getResources().getString(R.string.daystar_60561);
            case 60562 :
                return context.getResources().getString(R.string.daystar_60562);
            case 60563 :
                return context.getResources().getString(R.string.daystar_60563);
            case 60571 :
                return context.getResources().getString(R.string.daystar_60571);
            case 60572 :
                return context.getResources().getString(R.string.daystar_60572);
            case 60573 :
                return context.getResources().getString(R.string.daystar_60573);
            case 60574 :
                return context.getResources().getString(R.string.daystar_60574);
            case 60575 :
                return context.getResources().getString(R.string.daystar_60575);
            case 60581 :
                return context.getResources().getString(R.string.daystar_60581);
            case 60591 :
                return context.getResources().getString(R.string.daystar_60591);
            case 60601 :
                return context.getResources().getString(R.string.daystar_60601);
            case 60611 :
                return context.getResources().getString(R.string.daystar_60611);
            case 60612 :
                return context.getResources().getString(R.string.daystar_60612);
            case 60621 :
                return context.getResources().getString(R.string.daystar_60621);
            case 60622 :
                return context.getResources().getString(R.string.daystar_60622);
            case 60623 :
                return context.getResources().getString(R.string.daystar_60623);
            case 60631 :
                return context.getResources().getString(R.string.daystar_60631);
            case 60632 :
                return context.getResources().getString(R.string.daystar_60632);
            case 60641 :
                return context.getResources().getString(R.string.daystar_60641);
            case 60642 :
                return context.getResources().getString(R.string.daystar_60642);
            case 60643 :
                return context.getResources().getString(R.string.daystar_60643);
            case 60644 :
                return context.getResources().getString(R.string.daystar_60644);
            case 60645 :
                return context.getResources().getString(R.string.daystar_60645);
            case 60651 :
                return context.getResources().getString(R.string.daystar_60651);
            case 60652 :
                return context.getResources().getString(R.string.daystar_60652);
            case 60661 :
                return context.getResources().getString(R.string.daystar_60661);
            case 60662 :
                return context.getResources().getString(R.string.daystar_60662);
            case 60663 :
                return context.getResources().getString(R.string.daystar_60663);
            case 60664 :
                return context.getResources().getString(R.string.daystar_60664);
            case 60665 :
                return context.getResources().getString(R.string.daystar_60665);
            case 60666 :
                return context.getResources().getString(R.string.daystar_60666);
            case 60671 :
                return context.getResources().getString(R.string.daystar_60671);
            case 60672 :
                return context.getResources().getString(R.string.daystar_60672);
            case 60673 :
                return context.getResources().getString(R.string.daystar_60673);
            case 60674 :
                return context.getResources().getString(R.string.daystar_60674);
            case 60675 :
                return context.getResources().getString(R.string.daystar_60675);
            case 60676 :
                return context.getResources().getString(R.string.daystar_60676);
            case 60677 :
                return context.getResources().getString(R.string.daystar_60677);
            case 60681 :
                return context.getResources().getString(R.string.daystar_60681);
            case 60682 :
                return context.getResources().getString(R.string.daystar_60682);
            case 61001 :
                return context.getResources().getString(R.string.daystar_61001);
            case 61002 :
                return context.getResources().getString(R.string.daystar_61002);
            case 20101 :
                return context.getResources().getString(R.string.daystar_20101);
            case 20102 :
                return context.getResources().getString(R.string.daystar_20102);
            case 20103 :
                return context.getResources().getString(R.string.daystar_20103);
            case 20104 :
                return context.getResources().getString(R.string.daystar_20104);
            case 20105 :
                return context.getResources().getString(R.string.daystar_20105);
            case 20106 :
                return context.getResources().getString(R.string.daystar_20106);
            case 20107 :
                return context.getResources().getString(R.string.daystar_20107);
            case 20201 :
                return context.getResources().getString(R.string.daystar_20201);
            case 20202 :
                return context.getResources().getString(R.string.daystar_20202);
            case 20203 :
                return context.getResources().getString(R.string.daystar_20203);
            case 20204 :
                return context.getResources().getString(R.string.daystar_20204);
            case 20205 :
                return context.getResources().getString(R.string.daystar_20205);
            case 20206 :
                return context.getResources().getString(R.string.daystar_20206);
            case 20301 :
                return context.getResources().getString(R.string.daystar_20301);
            case 20302 :
                return context.getResources().getString(R.string.daystar_20302);
            case 20303 :
                return context.getResources().getString(R.string.daystar_20303);
            case 20304 :
                return context.getResources().getString(R.string.daystar_20304);
            case 20401 :
                return context.getResources().getString(R.string.daystar_20401);
            case 20402 :
                return context.getResources().getString(R.string.daystar_20402);
            case 20403 :
                return context.getResources().getString(R.string.daystar_20403);
            case 20404 :
                return context.getResources().getString(R.string.daystar_20404);
            case 20501 :
                return context.getResources().getString(R.string.daystar_20501);
            case 20502 :
                return context.getResources().getString(R.string.daystar_20502);
            case 20503 :
                return context.getResources().getString(R.string.daystar_20503);
            case 20504 :
                return context.getResources().getString(R.string.daystar_20504);
            case 20505 :
                return context.getResources().getString(R.string.daystar_20505);
            case 20601 :
                return context.getResources().getString(R.string.daystar_20601);
            case 20602 :
                return context.getResources().getString(R.string.daystar_20602);
            case 20603 :
                return context.getResources().getString(R.string.daystar_20603);
            case 20604 :
                return context.getResources().getString(R.string.daystar_20604);
            case 20605 :
                return context.getResources().getString(R.string.daystar_20605);
            case 20701 :
                return context.getResources().getString(R.string.daystar_20701);
            case 20702 :
                return context.getResources().getString(R.string.daystar_20702);
            case 20703 :
                return context.getResources().getString(R.string.daystar_20703);
            case 20704 :
                return context.getResources().getString(R.string.daystar_20704);
            case 20705 :
                return context.getResources().getString(R.string.daystar_20705);
            case 20801 :
                return context.getResources().getString(R.string.daystar_20801);
            case 20802 :
                return context.getResources().getString(R.string.daystar_20802);
            case 20803 :
                return context.getResources().getString(R.string.daystar_20803);
            case 20804 :
                return context.getResources().getString(R.string.daystar_20804);
            case 20901 :
                return context.getResources().getString(R.string.daystar_20901);
            case 20902 :
                return context.getResources().getString(R.string.daystar_20902);
            case 20903 :
                return context.getResources().getString(R.string.daystar_20903);
            case 20904 :
                return context.getResources().getString(R.string.daystar_20904);
            case 21001 :
                return context.getResources().getString(R.string.daystar_21001);
            case 21002 :
                return context.getResources().getString(R.string.daystar_21002);
            case 21003 :
                return context.getResources().getString(R.string.daystar_21003);
            case 21004 :
                return context.getResources().getString(R.string.daystar_21004);
            case 21101 :
                return context.getResources().getString(R.string.daystar_21101);
            case 21102 :
                return context.getResources().getString(R.string.daystar_21102);
            case 21103 :
                return context.getResources().getString(R.string.daystar_21103);
            case 21201 :
                return context.getResources().getString(R.string.daystar_21201);
            case 21202 :
                return context.getResources().getString(R.string.daystar_21202);
            case 21203 :
                return context.getResources().getString(R.string.daystar_21203);
            case 21204 :
                return context.getResources().getString(R.string.daystar_21204);
            case 21205 :
                return context.getResources().getString(R.string.daystar_21205);
            case 21301 :
                return context.getResources().getString(R.string.daystar_21301);
            case 21302 :
                return context.getResources().getString(R.string.daystar_21302);
            case 21303 :
                return context.getResources().getString(R.string.daystar_21303);
            case 21304 :
                return context.getResources().getString(R.string.daystar_21304);
            case 21305 :
                return context.getResources().getString(R.string.daystar_21305);
            case 21401 :
                return context.getResources().getString(R.string.daystar_21401);
            case 21402 :
                return context.getResources().getString(R.string.daystar_21402);
            case 21403 :
                return context.getResources().getString(R.string.daystar_21403);
            case 21404 :
                return context.getResources().getString(R.string.daystar_21404);
            case 21405 :
                return context.getResources().getString(R.string.daystar_21405);
            case 21501 :
                return context.getResources().getString(R.string.daystar_21501);
            case 21502 :
                return context.getResources().getString(R.string.daystar_21502);
            case 21503 :
                return context.getResources().getString(R.string.daystar_21503);
            case 21504 :
                return context.getResources().getString(R.string.daystar_21504);
            case 21505 :
                return context.getResources().getString(R.string.daystar_21505);
            case 21601 :
                return context.getResources().getString(R.string.daystar_21601);
            case 21602 :
                return context.getResources().getString(R.string.daystar_21602);
            case 21603 :
                return context.getResources().getString(R.string.daystar_21603);
            case 21604 :
                return context.getResources().getString(R.string.daystar_21604);
            case 21605 :
                return context.getResources().getString(R.string.daystar_21605);
            case 21701 :
                return context.getResources().getString(R.string.daystar_21701);
            case 21702 :
                return context.getResources().getString(R.string.daystar_21702);
            case 21703 :
                return context.getResources().getString(R.string.daystar_21703);
            case 21704 :
                return context.getResources().getString(R.string.daystar_21704);
            case 21801 :
                return context.getResources().getString(R.string.daystar_21801);
            case 21802 :
                return context.getResources().getString(R.string.daystar_21802);
            case 21803 :
                return context.getResources().getString(R.string.daystar_21803);
            case 21804 :
                return context.getResources().getString(R.string.daystar_21804);
            case 21901 :
                return context.getResources().getString(R.string.daystar_21901);
            case 21902 :
                return context.getResources().getString(R.string.daystar_21902);
            case 21903 :
                return context.getResources().getString(R.string.daystar_21903);
            case 21904 :
                return context.getResources().getString(R.string.daystar_21904);
            case 22001 :
                return context.getResources().getString(R.string.daystar_22001);
            case 22002 :
                return context.getResources().getString(R.string.daystar_22002);
            case 22003 :
                return context.getResources().getString(R.string.daystar_22003);
            case 22004 :
                return context.getResources().getString(R.string.daystar_22004);
            case 22005 :
                return context.getResources().getString(R.string.daystar_22005);
            case 22006 :
                return context.getResources().getString(R.string.daystar_22006);
            case 22101 :
                return context.getResources().getString(R.string.daystar_22101);
            case 22102 :
                return context.getResources().getString(R.string.daystar_22102);
            case 22103 :
                return context.getResources().getString(R.string.daystar_22103);
            case 22104 :
                return context.getResources().getString(R.string.daystar_22104);
            case 22105 :
                return context.getResources().getString(R.string.daystar_22105);
            case 22106 :
                return context.getResources().getString(R.string.daystar_22106);
            case 22201 :
                return context.getResources().getString(R.string.daystar_22201);
            case 22202 :
                return context.getResources().getString(R.string.daystar_22202);
            case 22203 :
                return context.getResources().getString(R.string.daystar_22203);
            case 22204 :
                return context.getResources().getString(R.string.daystar_22204);
            case 22301 :
                return context.getResources().getString(R.string.daystar_22301);
            case 22302 :
                return context.getResources().getString(R.string.daystar_22302);
            case 22303 :
                return context.getResources().getString(R.string.daystar_22303);
            case 22304 :
                return context.getResources().getString(R.string.daystar_22304);
            case 22305 :
                return context.getResources().getString(R.string.daystar_22305);
            case 22401 :
                return context.getResources().getString(R.string.daystar_22401);
            case 22402 :
                return context.getResources().getString(R.string.daystar_22402);
            case 22403 :
                return context.getResources().getString(R.string.daystar_22403);
            case 22404 :
                return context.getResources().getString(R.string.daystar_22404);
            case 22501 :
                return context.getResources().getString(R.string.daystar_22501);
            case 22502 :
                return context.getResources().getString(R.string.daystar_22502);
            case 22503 :
                return context.getResources().getString(R.string.daystar_22503);
            case 22504 :
                return context.getResources().getString(R.string.daystar_22504);
            case 22601 :
                return context.getResources().getString(R.string.daystar_22601);
            case 22602 :
                return context.getResources().getString(R.string.daystar_22602);
            case 22603 :
                return context.getResources().getString(R.string.daystar_22603);
            case 22604 :
                return context.getResources().getString(R.string.daystar_22604);
            case 22701 :
                return context.getResources().getString(R.string.daystar_22701);
            case 22702 :
                return context.getResources().getString(R.string.daystar_22702);
            case 22703 :
                return context.getResources().getString(R.string.daystar_22703);
            case 22704 :
                return context.getResources().getString(R.string.daystar_22704);
            case 22801 :
                return context.getResources().getString(R.string.daystar_22801);
            case 22802 :
                return context.getResources().getString(R.string.daystar_22802);
            case 22803 :
                return context.getResources().getString(R.string.daystar_22803);
            case 22804 :
                return context.getResources().getString(R.string.daystar_22804);
            case 22805 :
                return context.getResources().getString(R.string.daystar_22805);
            case 22806 :
                return context.getResources().getString(R.string.daystar_22806);
            case 22807 :
                return context.getResources().getString(R.string.daystar_22807);
            case 22808 :
                return context.getResources().getString(R.string.daystar_22808);
            case 22901 :
                return context.getResources().getString(R.string.daystar_22901);
            case 22902 :
                return context.getResources().getString(R.string.daystar_22902);
            case 22903 :
                return context.getResources().getString(R.string.daystar_22903);
            case 22904 :
                return context.getResources().getString(R.string.daystar_22904);
            case 23001 :
                return context.getResources().getString(R.string.daystar_23001);
            case 23002 :
                return context.getResources().getString(R.string.daystar_23002);
            case 23003 :
                return context.getResources().getString(R.string.daystar_23003);
            case 23004 :
                return context.getResources().getString(R.string.daystar_23004);
            case 23101 :
                return context.getResources().getString(R.string.daystar_23101);
            case 23102 :
                return context.getResources().getString(R.string.daystar_23102);
            case 23103 :
                return context.getResources().getString(R.string.daystar_23103);
            case 23104 :
                return context.getResources().getString(R.string.daystar_23104);
            case 23201 :
                return context.getResources().getString(R.string.daystar_23201);
            case 23202 :
                return context.getResources().getString(R.string.daystar_23202);
            case 23203 :
                return context.getResources().getString(R.string.daystar_23203);
            case 23204 :
                return context.getResources().getString(R.string.daystar_23204);
            case 23301 :
                return context.getResources().getString(R.string.daystar_23301);
            case 23302 :
                return context.getResources().getString(R.string.daystar_23302);
            case 23303 :
                return context.getResources().getString(R.string.daystar_23303);
            case 23304 :
                return context.getResources().getString(R.string.daystar_23304);
            case 23401 :
                return context.getResources().getString(R.string.daystar_23401);
            case 23402 :
                return context.getResources().getString(R.string.daystar_23402);
            case 23403 :
                return context.getResources().getString(R.string.daystar_23403);
            case 23404 :
                return context.getResources().getString(R.string.daystar_23404);
            case 23405 :
                return context.getResources().getString(R.string.daystar_23405);
            case 23501 :
                return context.getResources().getString(R.string.daystar_23501);
            case 23502 :
                return context.getResources().getString(R.string.daystar_23502);
            case 23503 :
                return context.getResources().getString(R.string.daystar_23503);
            case 23504 :
                return context.getResources().getString(R.string.daystar_23504);
            case 23601 :
                return context.getResources().getString(R.string.daystar_23601);
            case 23602 :
                return context.getResources().getString(R.string.daystar_23602);
            case 23603 :
                return context.getResources().getString(R.string.daystar_23603);
            case 23604 :
                return context.getResources().getString(R.string.daystar_23604);
            case 23701 :
                return context.getResources().getString(R.string.daystar_23701);
            case 23702 :
                return context.getResources().getString(R.string.daystar_23702);
            case 23703 :
                return context.getResources().getString(R.string.daystar_23703);
            case 23704 :
                return context.getResources().getString(R.string.daystar_23704);
            case 23801 :
                return context.getResources().getString(R.string.daystar_23801);
            case 23802 :
                return context.getResources().getString(R.string.daystar_23802);
            case 23803 :
                return context.getResources().getString(R.string.daystar_23803);
            case 23804 :
                return context.getResources().getString(R.string.daystar_23804);
            case 23901 :
                return context.getResources().getString(R.string.daystar_23901);
            case 23902 :
                return context.getResources().getString(R.string.daystar_23902);
            case 23903 :
                return context.getResources().getString(R.string.daystar_23903);
            case 23904 :
                return context.getResources().getString(R.string.daystar_23904);
            case 24001 :
                return context.getResources().getString(R.string.daystar_24001);
            case 24002 :
                return context.getResources().getString(R.string.daystar_24002);
            case 24003 :
                return context.getResources().getString(R.string.daystar_24003);
            case 24004 :
                return context.getResources().getString(R.string.daystar_24004);
            case 24101 :
                return context.getResources().getString(R.string.daystar_24101);
            case 24102 :
                return context.getResources().getString(R.string.daystar_24102);
            case 24103 :
                return context.getResources().getString(R.string.daystar_24103);
            case 24104 :
                return context.getResources().getString(R.string.daystar_24104);
            case 24201 :
                return context.getResources().getString(R.string.daystar_24201);
            case 24202 :
                return context.getResources().getString(R.string.daystar_24202);
            case 24203 :
                return context.getResources().getString(R.string.daystar_24203);
            case 24204 :
                return context.getResources().getString(R.string.daystar_24204);
            case 24205 :
                return context.getResources().getString(R.string.daystar_24205);
            case 24206 :
                return context.getResources().getString(R.string.daystar_24206);
            case 24207 :
                return context.getResources().getString(R.string.daystar_24207);
            case 24208 :
                return context.getResources().getString(R.string.daystar_24208);
            case 24301 :
                return context.getResources().getString(R.string.daystar_24301);
            case 24302 :
                return context.getResources().getString(R.string.daystar_24302);
            case 24303 :
                return context.getResources().getString(R.string.daystar_24303);
            case 24304 :
                return context.getResources().getString(R.string.daystar_24304);
            case 24401 :
                return context.getResources().getString(R.string.daystar_24401);
            case 24402 :
                return context.getResources().getString(R.string.daystar_24402);
            case 24403 :
                return context.getResources().getString(R.string.daystar_24403);
            case 24404 :
                return context.getResources().getString(R.string.daystar_24404);
            case 24501 :
                return context.getResources().getString(R.string.daystar_24501);
            case 24502 :
                return context.getResources().getString(R.string.daystar_24502);
            case 24503 :
                return context.getResources().getString(R.string.daystar_24503);
            case 24504 :
                return context.getResources().getString(R.string.daystar_24504);
            case 24601 :
                return context.getResources().getString(R.string.daystar_24601);
            case 24602 :
                return context.getResources().getString(R.string.daystar_24602);
            case 24603 :
                return context.getResources().getString(R.string.daystar_24603);
            case 24604 :
                return context.getResources().getString(R.string.daystar_24604);
            case 24701 :
                return context.getResources().getString(R.string.daystar_24701);
            case 24702 :
                return context.getResources().getString(R.string.daystar_24702);
            case 24703 :
                return context.getResources().getString(R.string.daystar_24703);
            case 24704 :
                return context.getResources().getString(R.string.daystar_24704);
            case 24801 :
                return context.getResources().getString(R.string.daystar_24801);
            case 24802 :
                return context.getResources().getString(R.string.daystar_24802);
            case 24803 :
                return context.getResources().getString(R.string.daystar_24803);
            case 24804 :
                return context.getResources().getString(R.string.daystar_24804);
            case 24901 :
                return context.getResources().getString(R.string.daystar_24901);
            case 24902 :
                return context.getResources().getString(R.string.daystar_24902);
            case 24903 :
                return context.getResources().getString(R.string.daystar_24903);
            case 24904 :
                return context.getResources().getString(R.string.daystar_24904);
            case 25001 :
                return context.getResources().getString(R.string.daystar_25001);
            case 25002 :
                return context.getResources().getString(R.string.daystar_25002);
            case 25101 :
                return context.getResources().getString(R.string.daystar_25101);
            case 25102 :
                return context.getResources().getString(R.string.daystar_25102);
            case 25103 :
                return context.getResources().getString(R.string.daystar_25103);
            case 25104 :
                return context.getResources().getString(R.string.daystar_25104);
            case 25105 :
                return context.getResources().getString(R.string.daystar_25105);
            case 25201 :
                return context.getResources().getString(R.string.daystar_25201);
            case 25202 :
                return context.getResources().getString(R.string.daystar_25202);
            case 25203 :
                return context.getResources().getString(R.string.daystar_25203);
            case 25204 :
                return context.getResources().getString(R.string.daystar_25204);
            case 25205 :
                return context.getResources().getString(R.string.daystar_25205);
            case 25206 :
                return context.getResources().getString(R.string.daystar_25206);
            case 25207 :
                return context.getResources().getString(R.string.daystar_25207);
            case 25301 :
                return context.getResources().getString(R.string.daystar_25301);
            case 25302 :
                return context.getResources().getString(R.string.daystar_25302);
            case 25303 :
                return context.getResources().getString(R.string.daystar_25303);
            case 25304 :
                return context.getResources().getString(R.string.daystar_25304);
            case 25305 :
                return context.getResources().getString(R.string.daystar_25305);
            case 25501 :
                return context.getResources().getString(R.string.daystar_25501);
            case 25502 :
                return context.getResources().getString(R.string.daystar_25502);
            case 25503 :
                return context.getResources().getString(R.string.daystar_25503);
            case 25504 :
                return context.getResources().getString(R.string.daystar_25504);
            case 25601 :
                return context.getResources().getString(R.string.daystar_25601);
            case 25602 :
                return context.getResources().getString(R.string.daystar_25602);
            case 25603 :
                return context.getResources().getString(R.string.daystar_25603);
            case 25604 :
                return context.getResources().getString(R.string.daystar_25604);
            case 25701 :
                return context.getResources().getString(R.string.daystar_25701);
            case 25702 :
                return context.getResources().getString(R.string.daystar_25702);
            case 25703 :
                return context.getResources().getString(R.string.daystar_25703);
            case 25704 :
                return context.getResources().getString(R.string.daystar_25704);
            case 25705 :
                return context.getResources().getString(R.string.daystar_25705);
            case 25801 :
                return context.getResources().getString(R.string.daystar_25801);
            case 25802 :
                return context.getResources().getString(R.string.daystar_25802);
            case 25803 :
                return context.getResources().getString(R.string.daystar_25803);
            case 25804 :
                return context.getResources().getString(R.string.daystar_25804);
            case 25901 :
                return context.getResources().getString(R.string.daystar_25901);
            case 25902 :
                return context.getResources().getString(R.string.daystar_25902);
            case 25903 :
                return context.getResources().getString(R.string.daystar_25903);
            case 25904 :
                return context.getResources().getString(R.string.daystar_25904);
            case 26001 :
                return context.getResources().getString(R.string.daystar_26001);
            case 26002 :
                return context.getResources().getString(R.string.daystar_26002);
            case 26003 :
                return context.getResources().getString(R.string.daystar_26003);
            case 26004 :
                return context.getResources().getString(R.string.daystar_26004);
            case 26101 :
                return context.getResources().getString(R.string.daystar_26101);
            case 26201 :
                return context.getResources().getString(R.string.daystar_26201);
            case 26202 :
                return context.getResources().getString(R.string.daystar_26202);
            case 26203 :
                return context.getResources().getString(R.string.daystar_26203);
            case 26204 :
                return context.getResources().getString(R.string.daystar_26204);
            case 26301 :
                return context.getResources().getString(R.string.daystar_26301);
            case 26401 :
                return context.getResources().getString(R.string.daystar_26401);
            case 26402 :
                return context.getResources().getString(R.string.daystar_26402);
            case 26403 :
                return context.getResources().getString(R.string.daystar_26403);
            case 26404 :
                return context.getResources().getString(R.string.daystar_26404);
            case 26405 :
                return context.getResources().getString(R.string.daystar_26405);
            case 26501 :
                return context.getResources().getString(R.string.daystar_26501);
            case 26601 :
                return context.getResources().getString(R.string.daystar_26601);
            case 26701 :
                return context.getResources().getString(R.string.daystar_26701);
            case 26801 :
                return context.getResources().getString(R.string.daystar_26801);
            case 26901 :
                return context.getResources().getString(R.string.daystar_26901);
            case 27001 :
                return context.getResources().getString(R.string.daystar_27001);
            case 27101 :
                return context.getResources().getString(R.string.daystar_27101);
            case 27102 :
                return context.getResources().getString(R.string.daystar_27102);
            case 27201 :
                return context.getResources().getString(R.string.daystar_27201);
            case 27202 :
                return context.getResources().getString(R.string.daystar_27202);
            case 27301 :
                return context.getResources().getString(R.string.daystar_27301);
            case 27302 :
                return context.getResources().getString(R.string.daystar_27302);
            case 27303 :
                return context.getResources().getString(R.string.daystar_27303);
            case 27304 :
                return context.getResources().getString(R.string.daystar_27304);
            case 27401 :
                return context.getResources().getString(R.string.daystar_27401);
            case 27402 :
                return context.getResources().getString(R.string.daystar_27402);
            case 27403 :
                return context.getResources().getString(R.string.daystar_27403);
            case 27404 :
                return context.getResources().getString(R.string.daystar_27404);
            case 27501 :
                return context.getResources().getString(R.string.daystar_27501);
            case 27502 :
                return context.getResources().getString(R.string.daystar_27502);
            case 27601 :
                return context.getResources().getString(R.string.daystar_27601);
            case 27602 :
                return context.getResources().getString(R.string.daystar_27602);
            case 27603 :
                return context.getResources().getString(R.string.daystar_27603);
            case 27604 :
                return context.getResources().getString(R.string.daystar_27604);
            case 27605 :
                return context.getResources().getString(R.string.daystar_27605);
            case 27701 :
                return context.getResources().getString(R.string.daystar_27701);
            case 27801 :
                return context.getResources().getString(R.string.daystar_27801);
            case 27901 :
                return context.getResources().getString(R.string.daystar_27901);
            case 27902 :
                return context.getResources().getString(R.string.daystar_27902);
            case 27903 :
                return context.getResources().getString(R.string.daystar_27903);
            case 27904 :
                return context.getResources().getString(R.string.daystar_27904);
            case 27905 :
                return context.getResources().getString(R.string.daystar_27905);
            case 28001 :
                return context.getResources().getString(R.string.daystar_28001);
            case 28002 :
                return context.getResources().getString(R.string.daystar_28002);
            case 28003 :
                return context.getResources().getString(R.string.daystar_28003);
            case 28004 :
                return context.getResources().getString(R.string.daystar_28004);
            case 28005 :
                return context.getResources().getString(R.string.daystar_28005);
            case 28101 :
                return context.getResources().getString(R.string.daystar_28101);
            case 28102 :
                return context.getResources().getString(R.string.daystar_28102);
            case 28103 :
                return context.getResources().getString(R.string.daystar_28103);
            case 28201 :
                return context.getResources().getString(R.string.daystar_28201);
            case 28202 :
                return context.getResources().getString(R.string.daystar_28202);
            case 28203 :
                return context.getResources().getString(R.string.daystar_28203);
            case 28204 :
                return context.getResources().getString(R.string.daystar_28204);
            case 28205 :
                return context.getResources().getString(R.string.daystar_28205);
            case 28206 :
                return context.getResources().getString(R.string.daystar_28206);
            case 28207 :
                return context.getResources().getString(R.string.daystar_28207);
            case 28208 :
                return context.getResources().getString(R.string.daystar_28208);
            case 28209 :
                return context.getResources().getString(R.string.daystar_28209);
            case 28210 :
                return context.getResources().getString(R.string.daystar_28210);
            case 28211 :
                return context.getResources().getString(R.string.daystar_28211);
            case 28301 :
                return context.getResources().getString(R.string.daystar_28301);
            case 28302 :
                return context.getResources().getString(R.string.daystar_28302);
            case 28303 :
                return context.getResources().getString(R.string.daystar_28303);
            case 28304 :
                return context.getResources().getString(R.string.daystar_28304);
            case 28305 :
                return context.getResources().getString(R.string.daystar_28305);
            case 28306 :
                return context.getResources().getString(R.string.daystar_28306);
            case 28307 :
                return context.getResources().getString(R.string.daystar_28307);
            case 28401 :
                return context.getResources().getString(R.string.daystar_28401);
            case 28402 :
                return context.getResources().getString(R.string.daystar_28402);
            case 28403 :
                return context.getResources().getString(R.string.daystar_28403);
            case 28501 :
                return context.getResources().getString(R.string.daystar_28501);
            case 28502 :
                return context.getResources().getString(R.string.daystar_28502);
            case 28503 :
                return context.getResources().getString(R.string.daystar_28503);
            case 28504 :
                return context.getResources().getString(R.string.daystar_28504);
            case 28601 :
                return context.getResources().getString(R.string.daystar_28601);
            case 28602 :
                return context.getResources().getString(R.string.daystar_28602);
            case 28603 :
                return context.getResources().getString(R.string.daystar_28603);
            case 28604 :
                return context.getResources().getString(R.string.daystar_28604);
            case 28701 :
                return context.getResources().getString(R.string.daystar_28701);
            case 28702 :
                return context.getResources().getString(R.string.daystar_28702);
            case 28703 :
                return context.getResources().getString(R.string.daystar_28703);
            case 28801 :
                return context.getResources().getString(R.string.daystar_28801);
            case 28802 :
                return context.getResources().getString(R.string.daystar_28802);
            case 28803 :
                return context.getResources().getString(R.string.daystar_28803);
            case 28804 :
                return context.getResources().getString(R.string.daystar_28804);
            case 28901 :
                return context.getResources().getString(R.string.daystar_28901);
            case 28902 :
                return context.getResources().getString(R.string.daystar_28902);
            case 28903 :
                return context.getResources().getString(R.string.daystar_28903);
            case 28904 :
                return context.getResources().getString(R.string.daystar_28904);
            case 29001 :
                return context.getResources().getString(R.string.daystar_29001);
            case 29002 :
                return context.getResources().getString(R.string.daystar_29002);
            case 29003 :
                return context.getResources().getString(R.string.daystar_29003);
            case 29004 :
                return context.getResources().getString(R.string.daystar_29004);
            case 29101 :
                return context.getResources().getString(R.string.daystar_29101);
            case 29102 :
                return context.getResources().getString(R.string.daystar_29102);
            case 29103 :
                return context.getResources().getString(R.string.daystar_29103);
            case 29104 :
                return context.getResources().getString(R.string.daystar_29104);
            case 29201 :
                return context.getResources().getString(R.string.daystar_29201);
            case 29202 :
                return context.getResources().getString(R.string.daystar_29202);
            case 29203 :
                return context.getResources().getString(R.string.daystar_29203);
            case 29204 :
                return context.getResources().getString(R.string.daystar_29204);
            case 29205 :
                return context.getResources().getString(R.string.daystar_29205);
            case 29301 :
                return context.getResources().getString(R.string.daystar_29301);
            case 29302 :
                return context.getResources().getString(R.string.daystar_29302);
            case 29303 :
                return context.getResources().getString(R.string.daystar_29303);
            case 29304 :
                return context.getResources().getString(R.string.daystar_29304);
            case 29305 :
                return context.getResources().getString(R.string.daystar_29305);
            case 29401 :
                return context.getResources().getString(R.string.daystar_29401);
            case 29402 :
                return context.getResources().getString(R.string.daystar_29402);
            case 29403 :
                return context.getResources().getString(R.string.daystar_29403);
            case 29404 :
                return context.getResources().getString(R.string.daystar_29404);
            case 29411 :
                return context.getResources().getString(R.string.daystar_29411);
            case 29412 :
                return context.getResources().getString(R.string.daystar_29412);
            case 29413 :
                return context.getResources().getString(R.string.daystar_29413);
            case 29421 :
                return context.getResources().getString(R.string.daystar_29421);
            case 29422 :
                return context.getResources().getString(R.string.daystar_29422);
            case 29423 :
                return context.getResources().getString(R.string.daystar_29423);
            case 29431 :
                return context.getResources().getString(R.string.daystar_29431);
            case 29432 :
                return context.getResources().getString(R.string.daystar_29432);
            case 29433 :
                return context.getResources().getString(R.string.daystar_29433);
            case 29434 :
                return context.getResources().getString(R.string.daystar_29434);
            case 29441 :
                return context.getResources().getString(R.string.daystar_29441);
            case 29442 :
                return context.getResources().getString(R.string.daystar_29442);
            case 29443 :
                return context.getResources().getString(R.string.daystar_29443);
            case 29444 :
                return context.getResources().getString(R.string.daystar_29444);
            case 29445 :
                return context.getResources().getString(R.string.daystar_29445);
            case 29451 :
                return context.getResources().getString(R.string.daystar_29451);
            case 29452 :
                return context.getResources().getString(R.string.daystar_29452);
            case 29453 :
                return context.getResources().getString(R.string.daystar_29453);
            case 29454 :
                return context.getResources().getString(R.string.daystar_29454);
            case 29461 :
                return context.getResources().getString(R.string.daystar_29461);
            case 29462 :
                return context.getResources().getString(R.string.daystar_29462);
            case 29463 :
                return context.getResources().getString(R.string.daystar_29463);
            case 29464 :
                return context.getResources().getString(R.string.daystar_29464);
            case 29471 :
                return context.getResources().getString(R.string.daystar_29471);
            case 29472 :
                return context.getResources().getString(R.string.daystar_29472);
            case 29473 :
                return context.getResources().getString(R.string.daystar_29473);
            case 29474 :
                return context.getResources().getString(R.string.daystar_29474);
            case 29481 :
                return context.getResources().getString(R.string.daystar_29481);
            case 29482 :
                return context.getResources().getString(R.string.daystar_29482);
            case 29483 :
                return context.getResources().getString(R.string.daystar_29483);
            case 29484 :
                return context.getResources().getString(R.string.daystar_29484);
            case 29491 :
                return context.getResources().getString(R.string.daystar_29491);
            case 29492 :
                return context.getResources().getString(R.string.daystar_29492);
            case 29493 :
                return context.getResources().getString(R.string.daystar_29493);
            case 29494 :
                return context.getResources().getString(R.string.daystar_29494);
            case 29501 :
                return context.getResources().getString(R.string.daystar_29501);
            case 29502 :
                return context.getResources().getString(R.string.daystar_29502);
            case 29503 :
                return context.getResources().getString(R.string.daystar_29503);
            case 29511 :
                return context.getResources().getString(R.string.daystar_29511);
            case 29512 :
                return context.getResources().getString(R.string.daystar_29512);
            case 29513 :
                return context.getResources().getString(R.string.daystar_29513);
            case 29521 :
                return context.getResources().getString(R.string.daystar_29521);
            case 29522 :
                return context.getResources().getString(R.string.daystar_29522);
            case 29523 :
                return context.getResources().getString(R.string.daystar_29523);
            case 29524 :
                return context.getResources().getString(R.string.daystar_29524);
            case 29525 :
                return context.getResources().getString(R.string.daystar_29525);
            case 29531 :
                return context.getResources().getString(R.string.daystar_29531);
            case 29541 :
                return context.getResources().getString(R.string.daystar_29541);
            case 29542 :
                return context.getResources().getString(R.string.daystar_29542);
            case 29543 :
                return context.getResources().getString(R.string.daystar_29543);
            case 29551 :
                return context.getResources().getString(R.string.daystar_29551);
            case 29552 :
                return context.getResources().getString(R.string.daystar_29552);
            case 29553 :
                return context.getResources().getString(R.string.daystar_29553);
            case 29554 :
                return context.getResources().getString(R.string.daystar_29554);
            case 29561 :
                return context.getResources().getString(R.string.daystar_29561);
            case 29562 :
                return context.getResources().getString(R.string.daystar_29562);
            case 29563 :
                return context.getResources().getString(R.string.daystar_29563);
            case 29564 :
                return context.getResources().getString(R.string.daystar_29564);
            case 29571 :
                return context.getResources().getString(R.string.daystar_29571);
            case 29572 :
                return context.getResources().getString(R.string.daystar_29572);
            case 29573 :
                return context.getResources().getString(R.string.daystar_29573);
            case 29574 :
                return context.getResources().getString(R.string.daystar_29574);
            case 29581 :
                return context.getResources().getString(R.string.daystar_29581);
            case 29582 :
                return context.getResources().getString(R.string.daystar_29582);
            case 29583 :
                return context.getResources().getString(R.string.daystar_29583);
            case 29584 :
                return context.getResources().getString(R.string.daystar_29584);
            case 29591 :
                return context.getResources().getString(R.string.daystar_29591);
            case 29592 :
                return context.getResources().getString(R.string.daystar_29592);
            case 29593 :
                return context.getResources().getString(R.string.daystar_29593);
            case 40001 :
                return context.getResources().getString(R.string.daystar_40001);
            case 40002 :
                return context.getResources().getString(R.string.daystar_40002);
            case 40003 :
                return context.getResources().getString(R.string.daystar_40003);
            case 40004 :
                return context.getResources().getString(R.string.daystar_40004);
            case 40005 :
                return context.getResources().getString(R.string.daystar_40005);
            case 40101 :
                return context.getResources().getString(R.string.daystar_40101);
            case 40102 :
                return context.getResources().getString(R.string.daystar_40102);
            case 40103 :
                return context.getResources().getString(R.string.daystar_40103);
            case 40104 :
                return context.getResources().getString(R.string.daystar_40104);
            case 40105 :
                return context.getResources().getString(R.string.daystar_40105);
            case 40201 :
                return context.getResources().getString(R.string.daystar_40201);
            case 40202 :
                return context.getResources().getString(R.string.daystar_40202);
            case 40203 :
                return context.getResources().getString(R.string.daystar_40203);
            case 40204 :
                return context.getResources().getString(R.string.daystar_40204);
            case 40205 :
                return context.getResources().getString(R.string.daystar_40205);
            case 40206 :
                return context.getResources().getString(R.string.daystar_40206);
            case 40207 :
                return context.getResources().getString(R.string.daystar_40207);
            case 40301 :
                return context.getResources().getString(R.string.daystar_40301);
            case 40401 :
                return context.getResources().getString(R.string.daystar_40401);
            case 40402 :
                return context.getResources().getString(R.string.daystar_40402);
            case 40403 :
                return context.getResources().getString(R.string.daystar_40403);
            case 40404 :
                return context.getResources().getString(R.string.daystar_40404);
            case 40501 :
                return context.getResources().getString(R.string.daystar_40501);
            case 40502 :
                return context.getResources().getString(R.string.daystar_40502);
            case 40503 :
                return context.getResources().getString(R.string.daystar_40503);
            case 40504 :
                return context.getResources().getString(R.string.daystar_40504);
            case 40601 :
                return context.getResources().getString(R.string.daystar_40601);
            case 40602 :
                return context.getResources().getString(R.string.daystar_40602);
            case 40603 :
                return context.getResources().getString(R.string.daystar_40603);
            case 40604 :
                return context.getResources().getString(R.string.daystar_40604);
            case 40701 :
                return context.getResources().getString(R.string.daystar_40701);
            case 40801 :
                return context.getResources().getString(R.string.daystar_40801);
            case 40802 :
                return context.getResources().getString(R.string.daystar_40802);
            case 40803 :
                return context.getResources().getString(R.string.daystar_40803);
            case 40901 :
                return context.getResources().getString(R.string.daystar_40901);
            case 40902 :
                return context.getResources().getString(R.string.daystar_40902);
            case 40903 :
                return context.getResources().getString(R.string.daystar_40903);
            case 41001 :
                return context.getResources().getString(R.string.daystar_41001);
            case 41002 :
                return context.getResources().getString(R.string.daystar_41002);
            case 41003 :
                return context.getResources().getString(R.string.daystar_41003);
            case 41201 :
                return context.getResources().getString(R.string.daystar_41201);
            case 41202 :
                return context.getResources().getString(R.string.daystar_41202);
            case 41203 :
                return context.getResources().getString(R.string.daystar_41203);
            case 41301 :
                return context.getResources().getString(R.string.daystar_41301);
            case 41302 :
                return context.getResources().getString(R.string.daystar_41302);
            case 41303 :
                return context.getResources().getString(R.string.daystar_41303);
            case 41401 :
                return context.getResources().getString(R.string.daystar_41401);
            case 41402 :
                return context.getResources().getString(R.string.daystar_41402);
            case 41403 :
                return context.getResources().getString(R.string.daystar_41403);
            case 41404 :
                return context.getResources().getString(R.string.daystar_41404);
            case 41501 :
                return context.getResources().getString(R.string.daystar_41501);
            case 41502 :
                return context.getResources().getString(R.string.daystar_41502);
            case 41503 :
                return context.getResources().getString(R.string.daystar_41503);
            case 41504 :
                return context.getResources().getString(R.string.daystar_41504);
            case 41601 :
                return context.getResources().getString(R.string.daystar_41601);
            case 41602 :
                return context.getResources().getString(R.string.daystar_41602);
            case 41603 :
                return context.getResources().getString(R.string.daystar_41603);
            case 41604 :
                return context.getResources().getString(R.string.daystar_41604);
            case 41605 :
                return context.getResources().getString(R.string.daystar_41605);
            case 41701 :
                return context.getResources().getString(R.string.daystar_41701);
            case 41702 :
                return context.getResources().getString(R.string.daystar_41702);
            case 41703 :
                return context.getResources().getString(R.string.daystar_41703);
            case 41704 :
                return context.getResources().getString(R.string.daystar_41704);
            case 41801 :
                return context.getResources().getString(R.string.daystar_41801);
            case 41802 :
                return context.getResources().getString(R.string.daystar_41802);
            case 41803 :
                return context.getResources().getString(R.string.daystar_41803);
            case 41804 :
                return context.getResources().getString(R.string.daystar_41804);
            case 41901 :
                return context.getResources().getString(R.string.daystar_41901);
            case 42001 :
                return context.getResources().getString(R.string.daystar_42001);
            case 42101 :
                return context.getResources().getString(R.string.daystar_42101);
            case 42102 :
                return context.getResources().getString(R.string.daystar_42102);
            case 42201 :
                return context.getResources().getString(R.string.daystar_42201);
            case 42301 :
                return context.getResources().getString(R.string.daystar_42301);
            case 42302 :
                return context.getResources().getString(R.string.daystar_42302);
            case 42303 :
                return context.getResources().getString(R.string.daystar_42303);
            case 42304 :
                return context.getResources().getString(R.string.daystar_42304);
            case 42401 :
                return context.getResources().getString(R.string.daystar_42401);
            case 42402 :
                return context.getResources().getString(R.string.daystar_42402);
            case 42403 :
                return context.getResources().getString(R.string.daystar_42403);
            case 42501 :
                return context.getResources().getString(R.string.daystar_42501);
            case 42601 :
                return context.getResources().getString(R.string.daystar_42601);
            case 42602 :
                return context.getResources().getString(R.string.daystar_42602);
            case 42603 :
                return context.getResources().getString(R.string.daystar_42603);
            case 42604 :
                return context.getResources().getString(R.string.daystar_42604);
            case 42605 :
                return context.getResources().getString(R.string.daystar_42605);
            case 42606 :
                return context.getResources().getString(R.string.daystar_42606);
            case 42701 :
                return context.getResources().getString(R.string.daystar_42701);
            case 42702 :
                return context.getResources().getString(R.string.daystar_42702);
            case 42703 :
                return context.getResources().getString(R.string.daystar_42703);
            case 42704 :
                return context.getResources().getString(R.string.daystar_42704);
            case 42705 :
                return context.getResources().getString(R.string.daystar_42705);
            case 42706 :
                return context.getResources().getString(R.string.daystar_42706);
            case 42801 :
                return context.getResources().getString(R.string.daystar_42801);
            case 42802 :
                return context.getResources().getString(R.string.daystar_42802);
            case 42901 :
                return context.getResources().getString(R.string.daystar_42901);
            case 42902 :
                return context.getResources().getString(R.string.daystar_42902);
            case 42903 :
                return context.getResources().getString(R.string.daystar_42903);
            case 42904 :
                return context.getResources().getString(R.string.daystar_42904);
            case 43001 :
                return context.getResources().getString(R.string.daystar_43001);
            case 43002 :
                return context.getResources().getString(R.string.daystar_43002);
            case 43101 :
                return context.getResources().getString(R.string.daystar_43101);
            case 43201 :
                return context.getResources().getString(R.string.daystar_43201);
            case 43202 :
                return context.getResources().getString(R.string.daystar_43202);
            case 43203 :
                return context.getResources().getString(R.string.daystar_43203);
            case 43204 :
                return context.getResources().getString(R.string.daystar_43204);
            case 43301 :
                return context.getResources().getString(R.string.daystar_43301);
            case 43302 :
                return context.getResources().getString(R.string.daystar_43302);
            case 43303 :
                return context.getResources().getString(R.string.daystar_43303);
            case 43304 :
                return context.getResources().getString(R.string.daystar_43304);
            case 43401 :
                return context.getResources().getString(R.string.daystar_43401);
            case 43402 :
                return context.getResources().getString(R.string.daystar_43402);
            case 43403 :
                return context.getResources().getString(R.string.daystar_43403);
            case 43404 :
                return context.getResources().getString(R.string.daystar_43404);
            case 43501 :
                return context.getResources().getString(R.string.daystar_43501);
            case 43502 :
                return context.getResources().getString(R.string.daystar_43502);
            case 43601 :
                return context.getResources().getString(R.string.daystar_43601);
            case 43602 :
                return context.getResources().getString(R.string.daystar_43602);
            case 43701 :
                return context.getResources().getString(R.string.daystar_43701);
            case 43702 :
                return context.getResources().getString(R.string.daystar_43702);
            case 43703 :
                return context.getResources().getString(R.string.daystar_43703);
            case 43801 :
                return context.getResources().getString(R.string.daystar_43801);
            case 43802 :
                return context.getResources().getString(R.string.daystar_43802);
            case 43803 :
                return context.getResources().getString(R.string.daystar_43803);
            case 43804 :
                return context.getResources().getString(R.string.daystar_43804);
            case 43901 :
                return context.getResources().getString(R.string.daystar_43901);
            case 44001 :
                return context.getResources().getString(R.string.daystar_44001);
            case 44002 :
                return context.getResources().getString(R.string.daystar_44002);
            case 44003 :
                return context.getResources().getString(R.string.daystar_44003);
            case 44004 :
                return context.getResources().getString(R.string.daystar_44004);
            case 44101 :
                return context.getResources().getString(R.string.daystar_44101);
            case 44201 :
                return context.getResources().getString(R.string.daystar_44201);
            case 44301 :
                return context.getResources().getString(R.string.daystar_44301);
            case 44401 :
                return context.getResources().getString(R.string.daystar_44401);
            case 44501 :
                return context.getResources().getString(R.string.daystar_44501);
            case 446001 :
                return context.getResources().getString(R.string.daystar_446001);
            case 44602 :
                return context.getResources().getString(R.string.daystar_44602);
            case 44603 :
                return context.getResources().getString(R.string.daystar_44603);
            case 44604 :
                return context.getResources().getString(R.string.daystar_44604);
            case 44701 :
                return context.getResources().getString(R.string.daystar_44701);
            case 44702 :
                return context.getResources().getString(R.string.daystar_44702);
            case 44703 :
                return context.getResources().getString(R.string.daystar_44703);
            case 44704 :
                return context.getResources().getString(R.string.daystar_44704);
            case 44801 :
                return context.getResources().getString(R.string.daystar_44801);
            case 44802 :
                return context.getResources().getString(R.string.daystar_44802);
            case 44803 :
                return context.getResources().getString(R.string.daystar_44803);
            case 44901 :
                return context.getResources().getString(R.string.daystar_44901);
            case 44902 :
                return context.getResources().getString(R.string.daystar_44902);
            case 44903 :
                return context.getResources().getString(R.string.daystar_44903);
            case 45001 :
                return context.getResources().getString(R.string.daystar_45001);
            case 45002 :
                return context.getResources().getString(R.string.daystar_45002);
            case 45003 :
                return context.getResources().getString(R.string.daystar_45003);
            case 45004 :
                return context.getResources().getString(R.string.daystar_45004);
            case 45101 :
                return context.getResources().getString(R.string.daystar_45101);
            case 45201 :
                return context.getResources().getString(R.string.daystar_45201);
            case 45301 :
                return context.getResources().getString(R.string.daystar_45301);
            case 45401 :
                return context.getResources().getString(R.string.daystar_45401);
            case 45501 :
                return context.getResources().getString(R.string.daystar_45501);
            case 45601 :
                return context.getResources().getString(R.string.daystar_45601);
            case 45602 :
                return context.getResources().getString(R.string.daystar_45602);
            case 45603 :
                return context.getResources().getString(R.string.daystar_45603);
            case 45604 :
                return context.getResources().getString(R.string.daystar_45604);
            case 45701 :
                return context.getResources().getString(R.string.daystar_45701);
            case 45702 :
                return context.getResources().getString(R.string.daystar_45702);
            case 45703 :
                return context.getResources().getString(R.string.daystar_45703);
            case 45704 :
                return context.getResources().getString(R.string.daystar_45704);
            case 45801 :
                return context.getResources().getString(R.string.daystar_45801);
            case 70101 :
                return context.getResources().getString(R.string.daystar_70101);
            case 70102 :
                return context.getResources().getString(R.string.daystar_70102);
            case 70103 :
                return context.getResources().getString(R.string.daystar_70103);
            case 70201 :
                return context.getResources().getString(R.string.daystar_70201);
            case 70202 :
                return context.getResources().getString(R.string.daystar_70202);
            case 70203 :
                return context.getResources().getString(R.string.daystar_70203);
            case 70301 :
                return context.getResources().getString(R.string.daystar_70301);
            case 70302 :
                return context.getResources().getString(R.string.daystar_70302);
            case 70303 :
                return context.getResources().getString(R.string.daystar_70303);
            case 70401 :
                return context.getResources().getString(R.string.daystar_70401);
            case 70402 :
                return context.getResources().getString(R.string.daystar_70402);
            case 70403 :
                return context.getResources().getString(R.string.daystar_70403);
            case 70501 :
                return context.getResources().getString(R.string.daystar_70501);
            case 70502 :
                return context.getResources().getString(R.string.daystar_70502);
            case 70503 :
                return context.getResources().getString(R.string.daystar_70503);
            case 70601 :
                return context.getResources().getString(R.string.daystar_70601);
            case 70602 :
                return context.getResources().getString(R.string.daystar_70602);
            case 70603 :
                return context.getResources().getString(R.string.daystar_70603);
            case 70701 :
                return context.getResources().getString(R.string.daystar_70701);
            case 70702 :
                return context.getResources().getString(R.string.daystar_70702);
            case 70703 :
                return context.getResources().getString(R.string.daystar_70703);
            case 70801 :
                return context.getResources().getString(R.string.daystar_70801);
            case 70802 :
                return context.getResources().getString(R.string.daystar_70802);
            case 70803 :
                return context.getResources().getString(R.string.daystar_70803);
            case 70901 :
                return context.getResources().getString(R.string.daystar_70901);
            case 70902 :
                return context.getResources().getString(R.string.daystar_70902);
            case 70903 :
                return context.getResources().getString(R.string.daystar_70903);
            case 71001 :
                return context.getResources().getString(R.string.daystar_71001);
            case 71002 :
                return context.getResources().getString(R.string.daystar_71002);
            case 71003 :
                return context.getResources().getString(R.string.daystar_71003);
            case 71101 :
                return context.getResources().getString(R.string.daystar_71101);
            case 71102 :
                return context.getResources().getString(R.string.daystar_71102);
            case 71103 :
                return context.getResources().getString(R.string.daystar_71103);
            case 71201 :
                return context.getResources().getString(R.string.daystar_71201);
            case 71202 :
                return context.getResources().getString(R.string.daystar_71202);
            case 71203 :
                return context.getResources().getString(R.string.daystar_71203);
            case 71301 :
                return context.getResources().getString(R.string.daystar_71301);
            case 71302 :
                return context.getResources().getString(R.string.daystar_71302);
            case 71303 :
                return context.getResources().getString(R.string.daystar_71303);
            case 71401 :
                return context.getResources().getString(R.string.daystar_71401);
            case 71402 :
                return context.getResources().getString(R.string.daystar_71402);
            case 71403 :
                return context.getResources().getString(R.string.daystar_71403);
            case 71501 :
                return context.getResources().getString(R.string.daystar_71501);
            case 71502 :
                return context.getResources().getString(R.string.daystar_71502);
            case 71503 :
                return context.getResources().getString(R.string.daystar_71503);
            case 71601 :
                return context.getResources().getString(R.string.daystar_71601);
            case 71602 :
                return context.getResources().getString(R.string.daystar_71602);
            case 71603 :
                return context.getResources().getString(R.string.daystar_71603);
            case 71701 :
                return context.getResources().getString(R.string.daystar_71701);
            case 71702 :
                return context.getResources().getString(R.string.daystar_71702);
            case 71703 :
                return context.getResources().getString(R.string.daystar_71703);
            case 71801 :
                return context.getResources().getString(R.string.daystar_71801);
            case 71802 :
                return context.getResources().getString(R.string.daystar_71802);
            case 71803 :
                return context.getResources().getString(R.string.daystar_71803);
            case 72001 :
                return context.getResources().getString(R.string.daystar_72001);
            case 72002 :
                return context.getResources().getString(R.string.daystar_72002);
            case 72101 :
                return context.getResources().getString(R.string.daystar_72101);
            case 72102 :
                return context.getResources().getString(R.string.daystar_72102);
            case 80001 :
                return context.getResources().getString(R.string.daystar_80001);
            case 80002 :
                return context.getResources().getString(R.string.daystar_80002);
            case 80003 :
                return context.getResources().getString(R.string.daystar_80003);
            case 80004 :
                return context.getResources().getString(R.string.daystar_80004);
            case 80005 :
                return context.getResources().getString(R.string.daystar_80005);
            case 81001 :
                return context.getResources().getString(R.string.daystar_81001);
            case 81002 :
                return context.getResources().getString(R.string.daystar_81002);
            case 81003 :
                return context.getResources().getString(R.string.daystar_81003);
            case 81004 :
                return context.getResources().getString(R.string.daystar_81004);
            case 81005 :
                return context.getResources().getString(R.string.daystar_81005);
            case 81006 :
                return context.getResources().getString(R.string.daystar_81006);
            case 81007 :
                return context.getResources().getString(R.string.daystar_81007);
            case 81008 :
                return context.getResources().getString(R.string.daystar_81008);
            case 81009 :
                return context.getResources().getString(R.string.daystar_81009);
            case 81010 :
                return context.getResources().getString(R.string.daystar_81010);
            case 81011 :
                return context.getResources().getString(R.string.daystar_81011);
            case 82001 :
                return context.getResources().getString(R.string.daystar_82001);
            case 82002 :
                return context.getResources().getString(R.string.daystar_82002);
            case 82003 :
                return context.getResources().getString(R.string.daystar_82003);
            case 82004 :
                return context.getResources().getString(R.string.daystar_82004);
            case 82005 :
                return context.getResources().getString(R.string.daystar_82005);
            case 82006 :
                return context.getResources().getString(R.string.daystar_82006);
            case 82007 :
                return context.getResources().getString(R.string.daystar_82007);
            case 82008 :
                return context.getResources().getString(R.string.daystar_82008);
            case 82009 :
                return context.getResources().getString(R.string.daystar_82009);
            case 82010 :
                return context.getResources().getString(R.string.daystar_82010);
            case 82011 :
                return context.getResources().getString(R.string.daystar_82011);
            case 82012 :
                return context.getResources().getString(R.string.daystar_82012);
            case 82013 :
                return context.getResources().getString(R.string.daystar_82013);
            case 82014 :
                return context.getResources().getString(R.string.daystar_82014);
            case 82015 :
                return context.getResources().getString(R.string.daystar_82015);
            case 82016 :
                return context.getResources().getString(R.string.daystar_82016);
            case 82017 :
                return context.getResources().getString(R.string.daystar_82017);
            case 82018 :
                return context.getResources().getString(R.string.daystar_82018);
            case 82019 :
                return context.getResources().getString(R.string.daystar_82019);
            case 82020 :
                return context.getResources().getString(R.string.daystar_82020);
            case 82021 :
                return context.getResources().getString(R.string.daystar_82021);
            case 82022 :
                return context.getResources().getString(R.string.daystar_82022);
            case 83001 :
                return context.getResources().getString(R.string.daystar_83001);
            case 85001 :
                return context.getResources().getString(R.string.daystar_85001);
            case 85002 :
                return context.getResources().getString(R.string.daystar_85002);
            case 85003 :
                return context.getResources().getString(R.string.daystar_85003);
            case 85004 :
                return context.getResources().getString(R.string.daystar_85004);
            case 85011 :
                return context.getResources().getString(R.string.daystar_85011);
            case 85012 :
                return context.getResources().getString(R.string.daystar_85012);
            case 85013 :
                return context.getResources().getString(R.string.daystar_85013);
            case 85014 :
                return context.getResources().getString(R.string.daystar_85014);
            case 85021 :
                return context.getResources().getString(R.string.daystar_85021);
            case 85022 :
                return context.getResources().getString(R.string.daystar_85022);
            case 85023 :
                return context.getResources().getString(R.string.daystar_85023);
            case 85024 :
                return context.getResources().getString(R.string.daystar_85024);
            case 85031 :
                return context.getResources().getString(R.string.daystar_85031);
            case 85032 :
                return context.getResources().getString(R.string.daystar_85032);
            case 85033 :
                return context.getResources().getString(R.string.daystar_85033);
            case 85034 :
                return context.getResources().getString(R.string.daystar_85034);
            case 85041 :
                return context.getResources().getString(R.string.daystar_85041);
            case 85042 :
                return context.getResources().getString(R.string.daystar_85042);
            case 85043 :
                return context.getResources().getString(R.string.daystar_85043);
            case 85044 :
                return context.getResources().getString(R.string.daystar_85044);
            case 85051 :
                return context.getResources().getString(R.string.daystar_85051);
            case 85052 :
                return context.getResources().getString(R.string.daystar_85052);
            case 85054 :
                return context.getResources().getString(R.string.daystar_85054);
            case 90001 :
                return context.getResources().getString(R.string.daystar_90001);
            case 90002 :
                return context.getResources().getString(R.string.daystar_90002);
            case 90003 :
                return context.getResources().getString(R.string.daystar_90003);
            case 90004 :
                return context.getResources().getString(R.string.daystar_90004);
            case 90005 :
                return context.getResources().getString(R.string.daystar_90005);
            case 90006 :
                return context.getResources().getString(R.string.daystar_90006);
            case 90007 :
                return context.getResources().getString(R.string.daystar_90007);
            case 90008 :
                return context.getResources().getString(R.string.daystar_90008);
            case 90009 :
                return context.getResources().getString(R.string.daystar_90009);
            case 90010 :
                return context.getResources().getString(R.string.daystar_90010);
            case 90011 :
                return context.getResources().getString(R.string.daystar_90011);
            case 90012 :
                return context.getResources().getString(R.string.daystar_90012);
            case 90013 :
                return context.getResources().getString(R.string.daystar_90013);
            case 90014 :
                return context.getResources().getString(R.string.daystar_90014);
            case 90015 :
                return context.getResources().getString(R.string.daystar_90015);
            case 90016 :
                return context.getResources().getString(R.string.daystar_90016);
            case 90017 :
                return context.getResources().getString(R.string.daystar_90017);
            case 90018 :
                return context.getResources().getString(R.string.daystar_90018);
            case 90019 :
                return context.getResources().getString(R.string.daystar_90019);
            case 91001 :
                return context.getResources().getString(R.string.daystar_91001);
            case 91002 :
                return context.getResources().getString(R.string.daystar_91002);
            case 91003 :
                return context.getResources().getString(R.string.daystar_91003);
            case 91004 :
                return context.getResources().getString(R.string.daystar_91004);
            case 91005 :
                return context.getResources().getString(R.string.daystar_91005);
            case 91006 :
                return context.getResources().getString(R.string.daystar_91006);
            case 91007 :
                return context.getResources().getString(R.string.daystar_91007);
            case 91008 :
                return context.getResources().getString(R.string.daystar_91008);
            case 91009 :
                return context.getResources().getString(R.string.daystar_91009);
            case 91010 :
                return context.getResources().getString(R.string.daystar_91010);
            case 91011 :
                return context.getResources().getString(R.string.daystar_91011);
            case 91012 :
                return context.getResources().getString(R.string.daystar_91012);
            case 91013 :
                return context.getResources().getString(R.string.daystar_91013);
            case 91014 :
                return context.getResources().getString(R.string.daystar_91014);
            case 91015 :
                return context.getResources().getString(R.string.daystar_91015);
            case 91016 :
                return context.getResources().getString(R.string.daystar_91016);
            case 91017 :
                return context.getResources().getString(R.string.daystar_91017);
            case 91018 :
                return context.getResources().getString(R.string.daystar_91018);
            case 91019 :
                return context.getResources().getString(R.string.daystar_91019);
            case 91020 :
                return context.getResources().getString(R.string.daystar_91020);
            case 91021 :
                return context.getResources().getString(R.string.daystar_91021);
            case 91022 :
                return context.getResources().getString(R.string.daystar_91022);
            case 91023 :
                return context.getResources().getString(R.string.daystar_91023);
            case 91024 :
                return context.getResources().getString(R.string.daystar_91024);
            case 91025 :
                return context.getResources().getString(R.string.daystar_91025);
            case 990001 :
                return context.getResources().getString(R.string.daystar_990001);
            case 990002 :
                return context.getResources().getString(R.string.daystar_990002);
            case 990003 :
                return context.getResources().getString(R.string.daystar_990003);
            case 990004 :
                return context.getResources().getString(R.string.daystar_990004);
            case 990005 :
                return context.getResources().getString(R.string.daystar_990005);
            case 990006 :
                return context.getResources().getString(R.string.daystar_990006);
            case 990007 :
                return context.getResources().getString(R.string.daystar_990007);
            case 990008 :
                return context.getResources().getString(R.string.daystar_990008);
            case 990009 :
                return context.getResources().getString(R.string.daystar_990009);
            case 990010 :
                return context.getResources().getString(R.string.daystar_990010);
            case 990011 :
                return context.getResources().getString(R.string.daystar_990011);
            case 990012 :
                return context.getResources().getString(R.string.daystar_990012);
            case 990013 :
                return context.getResources().getString(R.string.daystar_990013);
            case 990101 :
                return context.getResources().getString(R.string.daystar_990101);
            case 990102 :
                return context.getResources().getString(R.string.daystar_990102);
            case 990103 :
                return context.getResources().getString(R.string.daystar_990103);
            case 990104 :
                return context.getResources().getString(R.string.daystar_990104);
            case 990105 :
                return context.getResources().getString(R.string.daystar_990105);
            case 990106 :
                return context.getResources().getString(R.string.daystar_990106);
            case 990107 :
                return context.getResources().getString(R.string.daystar_990107);
            case 990108 :
                return context.getResources().getString(R.string.daystar_990108);
            case 990109 :
                return context.getResources().getString(R.string.daystar_990109);
            case 990110 :
                return context.getResources().getString(R.string.daystar_990110);
            case 990201 :
                return context.getResources().getString(R.string.daystar_990201);
            case 990202 :
                return context.getResources().getString(R.string.daystar_990202);
            case 990203 :
                return context.getResources().getString(R.string.daystar_990203);
            case 990204 :
                return context.getResources().getString(R.string.daystar_990204);
            case 990205 :
                return context.getResources().getString(R.string.daystar_990205);
            case 990206 :
                return context.getResources().getString(R.string.daystar_990206);
            case 990207 :
                return context.getResources().getString(R.string.daystar_990207);
            case 990208 :
                return context.getResources().getString(R.string.daystar_990208);
            case 990209 :
                return context.getResources().getString(R.string.daystar_990209);
            case 990210 :
                return context.getResources().getString(R.string.daystar_990210);
            case 990301 :
                return context.getResources().getString(R.string.daystar_990301);
            case 990302 :
                return context.getResources().getString(R.string.daystar_990302);
            case 990303 :
                return context.getResources().getString(R.string.daystar_990303);
            case 990304 :
                return context.getResources().getString(R.string.daystar_990304);
            case 990305 :
                return context.getResources().getString(R.string.daystar_990305);
            case 990306 :
                return context.getResources().getString(R.string.daystar_990306);
            case 990307 :
                return context.getResources().getString(R.string.daystar_990307);
            case 990308 :
                return context.getResources().getString(R.string.daystar_990308);
            case 990309 :
                return context.getResources().getString(R.string.daystar_990309);
            case 990310 :
                return context.getResources().getString(R.string.daystar_990310);
            case 990311 :
                return context.getResources().getString(R.string.daystar_990311);
            case 990312 :
                return context.getResources().getString(R.string.daystar_990312);
            case 990313 :
                return context.getResources().getString(R.string.daystar_990313);
            case 990314 :
                return context.getResources().getString(R.string.daystar_990314);
            default:
                return "";
        }
    }
}
