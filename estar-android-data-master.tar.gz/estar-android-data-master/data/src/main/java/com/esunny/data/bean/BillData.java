package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */
public class BillData {
    private String                                              companyNo;          //经纪公司编号
    private String                                              userNo;             //资金账号
    private String                                              AddressNo;          //地址号
    private char                                                billType;           //账单类型
    private String                                              billDate;           //账单日期
    private char                                                formatType;         //账单格式
    private String                                              content;            //帐单内容

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getAddressNo() {
        return AddressNo;
    }

    public void setAddressNo(String addressNo) {
        AddressNo = addressNo;
    }

    public char getBillType() {
        return billType;
    }

    public void setBillType(char billType) {
        this.billType = billType;
    }

    public String getBillDate() {
        return billDate;
    }

    public void setBillDate(String billDate) {
        this.billDate = billDate;
    }

    public char getFormatType() {
        return formatType;
    }

    public void setFormatType(char formatType) {
        this.formatType = formatType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
