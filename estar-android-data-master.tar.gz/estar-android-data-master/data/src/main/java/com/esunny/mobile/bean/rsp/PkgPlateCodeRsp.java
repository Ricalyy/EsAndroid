package com.esunny.mobile.bean.rsp;

import androidx.annotation.Nullable;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

public class PkgPlateCodeRsp extends ApiStruct {

    private String  PlateNo;
    private String  PlateCode;
    private char    PlateCodeAttr;

    public PkgPlateCodeRsp(byte[] buf) {
        super(buf);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil parseUtil = ParseUtil.wrap(buf);

        PlateNo = parseUtil.getString(21);
        PlateCode = parseUtil.getString(51);
        PlateCodeAttr = parseUtil.getChar();
    }

    public String getPlateNo() {
        return PlateNo;
    }

    public String getPlateCode() {
        return PlateCode;
    }

    public char getPlateCodeAttr() {
        return PlateCodeAttr;
    }

    @Override
    public int hashCode() {
        return PlateNo.hashCode() + PlateCode.hashCode();
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (obj instanceof PkgPlateCodeRsp) {
            if (PlateCode.equals(((PkgPlateCodeRsp) obj).getPlateCode()) && PlateNo.equals(((PkgPlateCodeRsp) obj).getPlateNo())) {
                return true;
            } else {
                return false;
            }
        }
        return false;
    }
}
