package com.esunny.data.bean;


import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;

import java.util.Objects;

import androidx.annotation.NonNull;

@Entity(nameInDb = "server_address")
public class Address {
    @Id(autoincrement = true)
    private Long id;
    @Property(nameInDb = "Ip")
    private String ip;
    @Property(nameInDb = "Port")
    private int port;
    @Property(nameInDb = "Type")
    private int type;
    @Property(nameInDb = "Weight")
    private int weight;
    @Property(nameInDb = "Remark")
    private String remark;

    public Address(String ip, int port) {
        this.ip = ip;
        this.port = port;
        this.weight = 1;
    }

    public Address(String ip, int port, int weight) {
        this.ip = ip;
        this.port = port;
        this.weight = weight;
    }

    public Address() {
    }
    @NonNull
    @Override
    public String toString() {
        return ip + ":" + port;
    }

    @Generated(hash = 1152956922)
    public Address(Long id, String ip, int port, int type, int weight,
                   String remark) {
        this.id = id;
        this.ip = ip;
        this.port = port;
        this.type = type;
        this.weight = weight;
        this.remark = remark;
    }
    public String getIp() {
        return this.ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    public int getPort() {
        return this.port;
    }
    public void setPort(int port) {
        this.port = port;
    }
    public int getWeight() {
        return this.weight;
    }
    public void setWeight(int weight) {
        this.weight = weight;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getType() {
        return this.type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getRemark() {
        return this.remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Address address = (Address) o;
        return port == address.port &&
                ip.equals(address.ip);
    }

    @Override
    public int hashCode() {
        return Objects.hash(ip, port);
    }
}
