package com.esunny.data.api.event;

/**
 * @author Peter
 */
public class QuoteEvent extends AbstractAPIEvent {

    private QuoteEvent(AbstractAPIEventBuilder builder) {
        super(builder);
    }

    public String getContractNo() {
        return ((Builder)Builder).contractNo;
    }

    public String getUserNo() {
        return ((Builder)Builder).userNo;
    }

    public char getKLineType() {
        return ((Builder)Builder).kLineType;
    }

    public static class Builder extends AbstractAPIEventBuilder<QuoteEvent> {

        String contractNo;
        String userNo;
        char kLineType;

        public Builder(int action) {
            setAction(action);
        }

        @Override
        public Builder setSender(int sender) {
            this.mSender = sender;
            return this;
        }

        @Override
        public Builder setAction(int action) {
            this.mAction = action;
            return this;
        }

        @Override
        public Builder setData(Object data) {
            this.mData = data;
            return this;
        }

        @Override
        public Builder setSrvChain(boolean srvChain) {
            this.srvChain = srvChain;
            return this;
        }

        @Override
        public Builder setSrvErrorCode(int srvErrorCode) {
            this.srvErrorCode = srvErrorCode;
            return this;
        }

        @Override
        public Builder setSrvErrorText(String srvErrorText) {
            this.srvErrorText = srvErrorText;
            return this;
        }

        public Builder setContractNo(String contractNo) {
            this.contractNo = contractNo;
            return this;
        }

        public Builder setUserNo(String userNo) {
            this.userNo = userNo;
            return this;
        }

        public Builder setKLineType(char kLineType) {
            this.kLineType = kLineType;
            return this;
        }

        @Override
        public QuoteEvent buildEvent() {
            return new QuoteEvent(this);
        }
    }
}
