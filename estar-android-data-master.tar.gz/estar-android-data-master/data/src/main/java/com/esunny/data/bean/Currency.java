package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/22
 */
public class Currency {

    public final static int STRUCT_LENGTH = 27;

    private String currencyNo;
    private double exchangeRate;
    private double interestRate;

    public String getCurrencyNo() {
        return currencyNo;
    }

    public void setCurrencyNo(String currencyNo) {
        this.currencyNo = currencyNo;
    }

    public double getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(double exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public double getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }
}
