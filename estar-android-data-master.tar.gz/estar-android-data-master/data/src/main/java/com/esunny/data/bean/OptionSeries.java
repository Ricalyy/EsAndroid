package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/28
 */
public class OptionSeries {

    private Commodity                                   Commodity;
    private Contract                                    TargetContract;
    private String                                      SeriesNo;
    private long                                        ExpiryDate;                         //到期日期
    private int                                         ExpiryDays;                         //到期天数

    public Commodity getCommodity() {
        return Commodity;
    }

    public void setCommodity(Commodity commodity) {
        Commodity = commodity;
    }

    public Contract getTargetContract() {
        return TargetContract;
    }

    public void setTargetContract(Contract targetContract) {
        TargetContract = targetContract;
    }

    public String getSeriesNo() {
        return SeriesNo;
    }

    public void setSeriesNo(String seriesNo) {
        SeriesNo = seriesNo;
    }

    public long getExpiryDate() {
        return ExpiryDate;
    }

    public void setExpiryDate(long expiryDate) {
        ExpiryDate = expiryDate;
    }

    public int getExpiryDays() {
        return ExpiryDays;
    }

    public void setExpiryDays(int expiryDays) {
        ExpiryDays = expiryDays;
    }

    @Override
    public String toString() {
        return SeriesNo;
    }
}
