package com.esunny.data.bean;

import java.math.BigInteger;

public class AvailableQty {

    private BigInteger Total;
    private BigInteger Available;
    private BigInteger TotalT;  //SHFE
    private BigInteger AvailableT;

    public BigInteger getTotal() {
        return Total;
    }

    public void setTotal(BigInteger total) {
        Total = total;
    }

    public BigInteger getAvailable() {
        return Available;
    }

    public void setAvailable(BigInteger available) {
        Available = available;
    }

    public BigInteger getTotalT() {
        return TotalT;
    }

    public void setTotalT(BigInteger totalT) {
        TotalT = totalT;
    }

    public BigInteger getAvailableT() {
        return AvailableT;
    }

    public void setAvailableT(BigInteger availableT) {
        AvailableT = availableT;
    }
}
