package com.esunny.data.util.simplethread;


import androidx.annotation.NonNull;

public abstract class SimpleRunnable implements Runnable, Comparable<SimpleRunnable> {

    private TaskPriority taskPriority = TaskPriority.NORMAL;
    private long createTime;

    public SimpleRunnable() {
        createTime = System.currentTimeMillis();
    }

    public SimpleRunnable(TaskPriority taskPriority) {
        this.taskPriority = taskPriority;
        createTime = System.currentTimeMillis();
    }

    public SimpleRunnable(SimpleRunnable simpleRunnable) {
        this.taskPriority = simpleRunnable.taskPriority;
        this.createTime = simpleRunnable.createTime;
    }

    @Override
    public int compareTo(@NonNull SimpleRunnable o) {
        if (taskPriority.getPriorityValue() - o.taskPriority.getPriorityValue() != 0) {
            return taskPriority.getPriorityValue() - o.taskPriority.getPriorityValue();
        } else {
            return (int) (createTime - o.createTime);
        }
    }
}
