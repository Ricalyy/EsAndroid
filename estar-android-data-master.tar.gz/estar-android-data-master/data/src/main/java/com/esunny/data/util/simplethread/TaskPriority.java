package com.esunny.data.util.simplethread;

/**
 * 任务优先级，分别有HIGH,NORMAL,LOW. 根据任务优先级执行任务。
 * 当任务优先级相同时，按任务开始执行时间顺序执行。
 * (任务执行先后顺序并不意味着任务执行完成先后顺序, 先开始执行的耗时任务可能晚于后开始执行的短小任务。)
 */
public enum TaskPriority {
    HIGH(-1),

    NORMAL(10),

    LOW(20);

    private int mPriority;

    TaskPriority(int priority){
        mPriority = priority;
    }

    public int getPriorityValue(){
        return mPriority;
    }
}
