package com.esunny.data.bean;

/**
 * @author Peter Fu
 * @date 2020/9/30
 */

public class BillDetail {

    private String billDate;

    private float bfBalance = 0.00f; //期初權益

    private float cfBalance = 0.00f; //期末权益

    private float realizedPL = 0.00f; // 平盈

    private float MTMPL = 0.00f; // 浮盈

    private float commission = 0.00f; // 手续费

    private float initialMargin = 0.00f; // 保证金

    private float depositWithdrawal = 0.00f;    // 出入金

    public String getBillDate() {
        return billDate;
    }

    public void setBillDate(String billDate) {
        this.billDate = billDate;
    }

    public float getBfBalance() {
        return bfBalance;
    }

    public void setBfBalance(float bfBalance) {
        this.bfBalance = bfBalance;
    }

    public float getCfBalance() {
        return cfBalance;
    }

    public void setCfBalance(float cfBalance) {
        this.cfBalance = cfBalance;
    }

    public float getRealizedPL() {
        return realizedPL;
    }

    public void setRealizedPL(float realizedPL) {
        this.realizedPL = realizedPL;
    }

    public float getMTMPL() {
        return MTMPL;
    }

    public void setMTMPL(float MTMPL) {
        this.MTMPL = MTMPL;
    }

    public float getCommission() {
        return commission;
    }

    public void setCommission(float commission) {
        this.commission = commission;
    }

    public float getInitialMargin() {
        return initialMargin;
    }

    public void setInitialMargin(float initialMargin) {
        this.initialMargin = initialMargin;
    }

    public float getDepositWithdrawal() {
        return depositWithdrawal;
    }

    public void setDepositWithdrawal(float depositWithdrawal) {
        this.depositWithdrawal = depositWithdrawal;
    }
}

