package com.esunny.data.bean;


import java.util.ArrayList;

/**
 * @author huang
 */
public class ContractSortInfo {
    private char SortType;       //排序指标
    private int Count;          //合约数量
    private ArrayList<ContractSortData> SortData;    //具体数值

    public ContractSortInfo() {
        SortData = new ArrayList<>();
    }

    public char getSortType() {
        return SortType;
    }

    public void setSortType(char sortType) {
        SortType = sortType;
    }

    public int getCount() {
        return Count;
    }

    public void setCount(int count) {
        Count = count;
    }

    public ArrayList<ContractSortData> getSortData() {
        return SortData;
    }

    public void setSortData(ArrayList<ContractSortData> sortData) {
        SortData = sortData;
    }
}
