package com.esunny.data.bean;

public class BillConfirmReq {
    private String                                                  companyNo;           //经纪公司编号
    private String                                                  userNo;              //资金账号
    private String                                                  AddressNo;           //地址号
    private String                                                  billDate;            //账单日期
    private byte                                                   confirmed;           //是否通过确认

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getUserNo() {
        return userNo;
    }

    public void setUserNo(String userNo) {
        this.userNo = userNo;
    }

    public String getAddressNo() {
        return AddressNo;
    }

    public void setAddressNo(String addressNo) {
        this.AddressNo = addressNo;
    }

    public String getBillDate() {
        return billDate;
    }

    public void setBillDate(String billDate) {
        this.billDate = billDate;
    }

    public byte getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(byte confirmed) {
        this.confirmed = confirmed;
    }

}
