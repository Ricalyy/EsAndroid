package com.esunny.data.error;

import android.content.Context;

import com.alibaba.android.arouter.utils.TextUtils;
import com.esunny.data.R;
import com.esunny.data.api.EsBaseApi;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class EsErrorCode {

    public final static String API_TYPE_CT_DAY_STAR = "_Daystarct_";
    public final static String API_TYPE_CT_DIPPER = "_Dipperct_";
    public final static String API_TYPE_CT_CTP = "_Ctpct_";
    public final static String API_TYPE_CT_KST = "_Kstct_";
    public final static String API_TYPE_CT_KINGSTAR = "_Kingstarct_";
    public final static String API_TYPE_CT_HUND_SUN = "_Hundsunct_";
    public final static String API_TYPE_CT_CTP_STOCK = "_CTPSTOCKCT_";
    public final static String API_TYPE_CT_CTPETF = "_CTPETFCT_";
    public final static String API_TYPE_CT_FEMA = "_FEMASCTM_";
    public final static String API_TYPE_DAY_STAR = "_DAYSTAR_";
    public final static String API_TYPE_DIPPER = "_DIPPER_";
    public final static String API_TYPE_CTP = "_CTP_";
    public final static String API_TYPE_KST = "_KST_";
    public final static String API_TYPE_HUND_SUN = "_Hundsun_";
    public final static String API_TYPE_CTPETF = "_CTPETF_";
    public final static String API_TYPE_QUOTE = "QuoteApi";
    public final static String API_TYPE_ESTAR = "_Estar_";
    public final static String API_TYPE_CTP_STOCK = "_CTPSTOCK_";


    public static String getErrorMessage(String addrTypeNo, int errorCode, String text) {
        String errorMessage = text;

        Context context = EsBaseApi.getInstance().getContext();
        if (TextUtils.isEmpty(errorMessage)) {
            if (addrTypeNo.equals(API_TYPE_QUOTE)) {
                errorMessage = QuoteErrorCode.getErrorMessage(context, errorCode);
            } else if (addrTypeNo.contains(API_TYPE_ESTAR)) {
                errorMessage = EstarErrorCode.getErrorMessage(context, errorCode);
            } else if (addrTypeNo.contains(API_TYPE_DAY_STAR) || addrTypeNo.contains(API_TYPE_CT_DAY_STAR)
                    || addrTypeNo.contains(API_TYPE_DIPPER) || addrTypeNo.contains(API_TYPE_CT_DIPPER)){
                errorMessage = DaystarAndDipperErrorCode.getErrorMessage(context, errorCode);
            } else if (addrTypeNo.contains(API_TYPE_CTP) || addrTypeNo.contains(API_TYPE_CT_CTP)) {
                if (errorCode == 999997) {
                    errorMessage = text;
                } else {
                    errorMessage = CtpErrorCode.getErrorMessage(context, errorCode);
                }
            } else if (addrTypeNo.contains(API_TYPE_KST) || addrTypeNo.contains(API_TYPE_CT_KST) || addrTypeNo.contains(API_TYPE_CT_KINGSTAR)) {
                errorMessage = KstErrorCode.getErrorMessage(context, errorCode);
            } else if (addrTypeNo.contains(API_TYPE_HUND_SUN) || addrTypeNo.contains(API_TYPE_CT_HUND_SUN)) {
                errorMessage = HsErrorCode.getErrorMessage(context, errorCode);
            } else if (addrTypeNo.contains(API_TYPE_CTPETF) || addrTypeNo.contains(API_TYPE_CTP_STOCK) || addrTypeNo.contains(API_TYPE_CT_CTP_STOCK) || addrTypeNo.contains(API_TYPE_CT_CTPETF)) {
                if (errorCode == 999998) {
                    errorMessage = context.getString(R.string.no_enough_locked_qty_message, text);
                } else if (errorCode == 999997) {
                    errorMessage = text;
                } else {
                    errorMessage = CtpetfErrorCode.getErrorMessage(context, errorCode);
                }
            } else if (addrTypeNo.contains(API_TYPE_CT_FEMA)) {
                errorMessage = FeMaErrorCode.getErrorMessage(context, errorCode);
            } else {
                errorMessage = "";
            }
        }

        // 北斗星启明星共用错误码 这是原来的逻辑 暂留
//            else if (addrTypeNo.contains(API_TYPE_DAY_STAR) || addrTypeNo.contains(API_TYPE_CT_DAY_STAR)) {
//                errorMessage = DaystarErrorCode.getErrorMessage(mContext, errorCode);
//            } else if (addrTypeNo.contains(API_TYPE_DIPPER) || addrTypeNo.contains(API_TYPE_CT_DIPPER)) {
//                if (!TextUtils.isEmpty(text)) {
//                    errorMessage = text;
//                } else {
//                    errorMessage = DipperErrorCode.getErrorMessage(mContext, errorCode);
//                }
//            }

        if (TextUtils.isEmpty(errorMessage)) {
            errorMessage = text;
        }

        if (TextUtils.isEmpty(errorMessage)) {
            errorMessage = context.getString(R.string.nomessage, errorCode);
        }

        return errorMessage;
    }
}

