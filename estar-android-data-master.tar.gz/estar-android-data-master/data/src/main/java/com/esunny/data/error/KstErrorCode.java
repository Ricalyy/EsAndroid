package com.esunny.data.error;

import android.content.Context;

import com.esunny.data.R;


class KstErrorCode {

    static String getErrorMessage(Context context, int errorCode) {

        switch (errorCode) {

            case -11 :
                return context.getResources().getString(R.string.kst_n11);
            case 0 :
                return context.getResources().getString(R.string.kst_0);
            case 319500101 :
                return context.getResources().getString(R.string.kst_319500101);
            case 319500201 :
                return context.getResources().getString(R.string.kst_319500201);
            case 319501001 :
                return context.getResources().getString(R.string.kst_319501001);
            case 319501002 :
                return context.getResources().getString(R.string.kst_319501002);
            case 319501003 :
                return context.getResources().getString(R.string.kst_319501003);
            case 319501004 :
                return context.getResources().getString(R.string.kst_319501004);
            case 319501005 :
                return context.getResources().getString(R.string.kst_319501005);
            case 319501006 :
                return context.getResources().getString(R.string.kst_319501006);
            case 319501007 :
                return context.getResources().getString(R.string.kst_319501007);
            case 319501008 :
                return context.getResources().getString(R.string.kst_319501008);
            case 319501009 :
                return context.getResources().getString(R.string.kst_319501009);
            case 319501010 :
                return context.getResources().getString(R.string.kst_319501010);
            case 319501011 :
                return context.getResources().getString(R.string.kst_319501011);
            case 319501012 :
                return context.getResources().getString(R.string.kst_319501012);
            case 319501013 :
                return context.getResources().getString(R.string.kst_319501013);
            case 319501014 :
                return context.getResources().getString(R.string.kst_319501014);
            case 319501015 :
                return context.getResources().getString(R.string.kst_319501015);
            case 319501016 :
                return context.getResources().getString(R.string.kst_319501016);
            case 319501017 :
                return context.getResources().getString(R.string.kst_319501017);
            case 319501018 :
                return context.getResources().getString(R.string.kst_319501018);
            case 319501019 :
                return context.getResources().getString(R.string.kst_319501019);
            case 319501020 :
                return context.getResources().getString(R.string.kst_319501020);
            case 319501021 :
                return context.getResources().getString(R.string.kst_319501021);
            case 319501022 :
                return context.getResources().getString(R.string.kst_319501022);
            case 319501023 :
                return context.getResources().getString(R.string.kst_319501023);
            case 319501024 :
                return context.getResources().getString(R.string.kst_319501024);
            case 319501025 :
                return context.getResources().getString(R.string.kst_319501025);
            case 319501026 :
                return context.getResources().getString(R.string.kst_319501026);
            case 319501027 :
                return context.getResources().getString(R.string.kst_319501027);
            case 319501101 :
                return context.getResources().getString(R.string.kst_319501101);
            case 319501102 :
                return context.getResources().getString(R.string.kst_319501102);
            case 319501103 :
                return context.getResources().getString(R.string.kst_319501103);
            case 319501104 :
                return context.getResources().getString(R.string.kst_319501104);
            case 319501105 :
                return context.getResources().getString(R.string.kst_319501105);
            case 319501106 :
                return context.getResources().getString(R.string.kst_319501106);
            case 319501301 :
                return context.getResources().getString(R.string.kst_319501301);
            case 319501302 :
                return context.getResources().getString(R.string.kst_319501302);
            case 319501303 :
                return context.getResources().getString(R.string.kst_319501303);
            case 319501304 :
                return context.getResources().getString(R.string.kst_319501304);
            case 319501305 :
                return context.getResources().getString(R.string.kst_319501305);
            case 319501306 :
                return context.getResources().getString(R.string.kst_319501306);
            case 319501307 :
                return context.getResources().getString(R.string.kst_319501307);
            case 319501401 :
                return context.getResources().getString(R.string.kst_319501401);
            case 319501402 :
                return context.getResources().getString(R.string.kst_319501402);
            case 319501403 :
                return context.getResources().getString(R.string.kst_319501403);
            case 319501404 :
                return context.getResources().getString(R.string.kst_319501404);
            case 319501405 :
                return context.getResources().getString(R.string.kst_319501405);
            case 319501501 :
                return context.getResources().getString(R.string.kst_319501501);
            case 319501502 :
                return context.getResources().getString(R.string.kst_319501502);
            case 319501503 :
                return context.getResources().getString(R.string.kst_319501503);
            case 319501504 :
                return context.getResources().getString(R.string.kst_319501504);
            case 319501505 :
                return context.getResources().getString(R.string.kst_319501505);
            case 319501506 :
                return context.getResources().getString(R.string.kst_319501506);
            case 319501601 :
                return context.getResources().getString(R.string.kst_319501601);
            case 319501602 :
                return context.getResources().getString(R.string.kst_319501602);
            case 319501701 :
                return context.getResources().getString(R.string.kst_319501701);
            case 319501702 :
                return context.getResources().getString(R.string.kst_319501702);
            case 319501703 :
                return context.getResources().getString(R.string.kst_319501703);
            case 319501801 :
                return context.getResources().getString(R.string.kst_319501801);
            case 319501802 :
                return context.getResources().getString(R.string.kst_319501802);
            case 319501803 :
                return context.getResources().getString(R.string.kst_319501803);
            case 319501804 :
                return context.getResources().getString(R.string.kst_319501804);
            case 319501805 :
                return context.getResources().getString(R.string.kst_319501805);
            case 319501806 :
                return context.getResources().getString(R.string.kst_319501806);
            case 319501807 :
                return context.getResources().getString(R.string.kst_319501807);
            case 319501808 :
                return context.getResources().getString(R.string.kst_319501808);
            case 319501901 :
                return context.getResources().getString(R.string.kst_319501901);
            case 319501902 :
                return context.getResources().getString(R.string.kst_319501902);
            case 319502001 :
                return context.getResources().getString(R.string.kst_319502001);
            case 319502002 :
                return context.getResources().getString(R.string.kst_319502002);
            case 319502003 :
                return context.getResources().getString(R.string.kst_319502003);
            case 319502101 :
                return context.getResources().getString(R.string.kst_319502101);
            case 319502102 :
                return context.getResources().getString(R.string.kst_319502102);
            case 319502103 :
                return context.getResources().getString(R.string.kst_319502103);
            case 319502201 :
                return context.getResources().getString(R.string.kst_319502201);
            case 319502202 :
                return context.getResources().getString(R.string.kst_319502202);
            case 319502203 :
                return context.getResources().getString(R.string.kst_319502203);
            case 319502301 :
                return context.getResources().getString(R.string.kst_319502301);
            case 319502302 :
                return context.getResources().getString(R.string.kst_319502302);
            case 319502303 :
                return context.getResources().getString(R.string.kst_319502303);
            case 319502304 :
                return context.getResources().getString(R.string.kst_319502304);
            case 319502305 :
                return context.getResources().getString(R.string.kst_319502305);
            case 319502306 :
                return context.getResources().getString(R.string.kst_319502306);
            case 319502401 :
                return context.getResources().getString(R.string.kst_319502401);
            case 319502402 :
                return context.getResources().getString(R.string.kst_319502402);
            case 319502501 :
                return context.getResources().getString(R.string.kst_319502501);
            case 319502601 :
                return context.getResources().getString(R.string.kst_319502601);
            case 319502602 :
                return context.getResources().getString(R.string.kst_319502602);
            case 319502701 :
                return context.getResources().getString(R.string.kst_319502701);
            case 319502702 :
                return context.getResources().getString(R.string.kst_319502702);
            case 319502801 :
                return context.getResources().getString(R.string.kst_319502801);
            case 319502901 :
                return context.getResources().getString(R.string.kst_319502901);
            case 319503001 :
                return context.getResources().getString(R.string.kst_319503001);
            case 319503002 :
                return context.getResources().getString(R.string.kst_319503002);
            case 319503003 :
                return context.getResources().getString(R.string.kst_319503003);
            case 319503004 :
                return context.getResources().getString(R.string.kst_319503004);
            case 319503101 :
                return context.getResources().getString(R.string.kst_319503101);
            case 319503102 :
                return context.getResources().getString(R.string.kst_319503102);
            case 319503401 :
                return context.getResources().getString(R.string.kst_319503401);
            case 319503501 :
                return context.getResources().getString(R.string.kst_319503501);
            case 319503502 :
                return context.getResources().getString(R.string.kst_319503502);
            case 319503503 :
                return context.getResources().getString(R.string.kst_319503503);
            case 319503601 :
                return context.getResources().getString(R.string.kst_319503601);
            case 319503701 :
                return context.getResources().getString(R.string.kst_319503701);
            case 319503801 :
                return context.getResources().getString(R.string.kst_319503801);
            case 319503901 :
                return context.getResources().getString(R.string.kst_319503901);
            case 319503902 :
                return context.getResources().getString(R.string.kst_319503902);
            case 319504001 :
                return context.getResources().getString(R.string.kst_319504001);
            case 319504101 :
                return context.getResources().getString(R.string.kst_319504101);
            case 319504301 :
                return context.getResources().getString(R.string.kst_319504301);
            case 319504302 :
                return context.getResources().getString(R.string.kst_319504302);
            case 319504303 :
                return context.getResources().getString(R.string.kst_319504303);
            case 319504407 :
                return context.getResources().getString(R.string.kst_319504407);
            case 311000711 :
                return context.getResources().getString(R.string.kst_311000711);
            case 311000712 :
                return context.getResources().getString(R.string.kst_311000712);
            case 311000713 :
                return context.getResources().getString(R.string.kst_311000713);
            case 311000714 :
                return context.getResources().getString(R.string.kst_311000714);
            case 311000715 :
                return context.getResources().getString(R.string.kst_311000715);
            case 311000716 :
                return context.getResources().getString(R.string.kst_311000716);
            case 311000717 :
                return context.getResources().getString(R.string.kst_311000717);
            case 311000718 :
                return context.getResources().getString(R.string.kst_311000718);
            case 311000719 :
                return context.getResources().getString(R.string.kst_311000719);
            case 311000720 :
                return context.getResources().getString(R.string.kst_311000720);
            case 311000911 :
                return context.getResources().getString(R.string.kst_311000911);
            case 311000912 :
                return context.getResources().getString(R.string.kst_311000912);
            case 311000913 :
                return context.getResources().getString(R.string.kst_311000913);
            case 311000914 :
                return context.getResources().getString(R.string.kst_311000914);
            case 311000915 :
                return context.getResources().getString(R.string.kst_311000915);
            case 311000916 :
                return context.getResources().getString(R.string.kst_311000916);
            case 311000917 :
                return context.getResources().getString(R.string.kst_311000917);
            case 311000918 :
                return context.getResources().getString(R.string.kst_311000918);
            case 311000919 :
                return context.getResources().getString(R.string.kst_311000919);
            case 311001011 :
                return context.getResources().getString(R.string.kst_311001011);
            case 311001012 :
                return context.getResources().getString(R.string.kst_311001012);
            case 311001013 :
                return context.getResources().getString(R.string.kst_311001013);
            case 311001014 :
                return context.getResources().getString(R.string.kst_311001014);
            case 311001015 :
                return context.getResources().getString(R.string.kst_311001015);
            case 311001016 :
                return context.getResources().getString(R.string.kst_311001016);
            case 311000750 :
                return context.getResources().getString(R.string.kst_311000750);
            case 311000751 :
                return context.getResources().getString(R.string.kst_311000751);
            case 311000752 :
                return context.getResources().getString(R.string.kst_311000752);
            case 311000753 :
                return context.getResources().getString(R.string.kst_311000753);
            case 311000754 :
                return context.getResources().getString(R.string.kst_311000754);
            case 311000755 :
                return context.getResources().getString(R.string.kst_311000755);
            case 311000756 :
                return context.getResources().getString(R.string.kst_311000756);
            case 311000950 :
                return context.getResources().getString(R.string.kst_311000950);
            case 311000951 :
                return context.getResources().getString(R.string.kst_311000951);
            case 311000952 :
                return context.getResources().getString(R.string.kst_311000952);
            case 311000953 :
                return context.getResources().getString(R.string.kst_311000953);
            case 319500954 :
                return context.getResources().getString(R.string.kst_319500954);
            case 319500955 :
                return context.getResources().getString(R.string.kst_319500955);
            case 319502802 :
                return context.getResources().getString(R.string.kst_319502802);
            case 320700500 :
                return context.getResources().getString(R.string.kst_320700500);
            case 100001 :
                return context.getResources().getString(R.string.kst_100001);
            case 100002 :
                return context.getResources().getString(R.string.kst_100002);
            case 100003 :
                return context.getResources().getString(R.string.kst_100003);
            case 100004 :
                return context.getResources().getString(R.string.kst_100004);
            case 100005 :
                return context.getResources().getString(R.string.kst_100005);
            case 1 :
                return context.getResources().getString(R.string.kst_1);
            case 2 :
                return context.getResources().getString(R.string.kst_2);
            case 3 :
                return context.getResources().getString(R.string.kst_3);
            case 4 :
                return context.getResources().getString(R.string.kst_4);
            case 5 :
                return context.getResources().getString(R.string.kst_5);
            case 6 :
                return context.getResources().getString(R.string.kst_6);
            case 7 :
                return context.getResources().getString(R.string.kst_7);
            case 8 :
                return context.getResources().getString(R.string.kst_8);
            case 9 :
                return context.getResources().getString(R.string.kst_9);
            case 10 :
                return context.getResources().getString(R.string.kst_10);
            case 11 :
                return context.getResources().getString(R.string.kst_11);
            case 12 :
                return context.getResources().getString(R.string.kst_12);
            case 13 :
                return context.getResources().getString(R.string.kst_13);
            case 14 :
                return context.getResources().getString(R.string.kst_14);
            case 15 :
                return context.getResources().getString(R.string.kst_15);
            case 16 :
                return context.getResources().getString(R.string.kst_16);
            case 17 :
                return context.getResources().getString(R.string.kst_17);
            case 18 :
                return context.getResources().getString(R.string.kst_18);
            case 19 :
                return context.getResources().getString(R.string.kst_19);
            case 20 :
                return context.getResources().getString(R.string.kst_20);
            case 21 :
                return context.getResources().getString(R.string.kst_21);
            case 22 :
                return context.getResources().getString(R.string.kst_22);
            case 23 :
                return context.getResources().getString(R.string.kst_23);
            case 24 :
                return context.getResources().getString(R.string.kst_24);
            case 100 :
                return context.getResources().getString(R.string.kst_100);
            case 101 :
                return context.getResources().getString(R.string.kst_101);
            case 133 :
                return context.getResources().getString(R.string.kst_133);
            case 134 :
                return context.getResources().getString(R.string.kst_134);
            case 135 :
                return context.getResources().getString(R.string.kst_135);
            case 136 :
                return context.getResources().getString(R.string.kst_136);
            case 137 :
                return context.getResources().getString(R.string.kst_137);
            case 138 :
                return context.getResources().getString(R.string.kst_138);
            case 139 :
                return context.getResources().getString(R.string.kst_139);
            case 141 :
                return context.getResources().getString(R.string.kst_141);
            case 142 :
                return context.getResources().getString(R.string.kst_142);
            case 143 :
                return context.getResources().getString(R.string.kst_143);
            case 144 :
                return context.getResources().getString(R.string.kst_144);
            case 200 :
                return context.getResources().getString(R.string.kst_200);
            case 201 :
                return context.getResources().getString(R.string.kst_201);
            case 202 :
                return context.getResources().getString(R.string.kst_202);
            case 203 :
                return context.getResources().getString(R.string.kst_203);
            case 204 :
                return context.getResources().getString(R.string.kst_204);
            case 205 :
                return context.getResources().getString(R.string.kst_205);
            case 206 :
                return context.getResources().getString(R.string.kst_206);
            case 207 :
                return context.getResources().getString(R.string.kst_207);
            case 208 :
                return context.getResources().getString(R.string.kst_208);
            case 209 :
                return context.getResources().getString(R.string.kst_209);
            case 210 :
                return context.getResources().getString(R.string.kst_210);
            case 211 :
                return context.getResources().getString(R.string.kst_211);
            case 213 :
                return context.getResources().getString(R.string.kst_213);
            case 214 :
                return context.getResources().getString(R.string.kst_214);
            case 215 :
                return context.getResources().getString(R.string.kst_215);
            case 216 :
                return context.getResources().getString(R.string.kst_216);
            case 217 :
                return context.getResources().getString(R.string.kst_217);
            case 10005 :
                return context.getResources().getString(R.string.kst_10005);
            case 30002 :
                return context.getResources().getString(R.string.kst_30002);
            case 30004 :
                return context.getResources().getString(R.string.kst_30004);
            case 30006 :
                return context.getResources().getString(R.string.kst_30006);
            case 40012 :
                return context.getResources().getString(R.string.kst_40012);
            case 40013 :
                return context.getResources().getString(R.string.kst_40013);
            case 40014 :
                return context.getResources().getString(R.string.kst_40014);
            case 40015 :
                return context.getResources().getString(R.string.kst_40015);
            case 40016 :
                return context.getResources().getString(R.string.kst_40016);
            case 40017 :
                return context.getResources().getString(R.string.kst_40017);
            case 40019 :
                return context.getResources().getString(R.string.kst_40019);
            case 40020 :
                return context.getResources().getString(R.string.kst_40020);
            case 40021 :
                return context.getResources().getString(R.string.kst_40021);
            case 40022 :
                return context.getResources().getString(R.string.kst_40022);
            case 40023 :
                return context.getResources().getString(R.string.kst_40023);
            case 40024 :
                return context.getResources().getString(R.string.kst_40024);
            case 40025 :
                return context.getResources().getString(R.string.kst_40025);
            case 40026 :
                return context.getResources().getString(R.string.kst_40026);
            case 40037 :
                return context.getResources().getString(R.string.kst_40037);
            case 40038 :
                return context.getResources().getString(R.string.kst_40038);
            case 40039 :
                return context.getResources().getString(R.string.kst_40039);
            case 40046 :
                return context.getResources().getString(R.string.kst_40046);
            case 40047 :
                return context.getResources().getString(R.string.kst_40047);
            case 40048 :
                return context.getResources().getString(R.string.kst_40048);
            case 40049 :
                return context.getResources().getString(R.string.kst_40049);
            case 40050 :
                return context.getResources().getString(R.string.kst_40050);
            case 40051 :
                return context.getResources().getString(R.string.kst_40051);
            case 40058 :
                return context.getResources().getString(R.string.kst_40058);
            case 40070 :
                return context.getResources().getString(R.string.kst_40070);
            case 40071 :
                return context.getResources().getString(R.string.kst_40071);
            case 40073 :
                return context.getResources().getString(R.string.kst_40073);
            case 40074 :
                return context.getResources().getString(R.string.kst_40074);
            case 40075 :
                return context.getResources().getString(R.string.kst_40075);
            case 40076 :
                return context.getResources().getString(R.string.kst_40076);
            case 40095 :
                return context.getResources().getString(R.string.kst_40095);
            case 40102 :
                return context.getResources().getString(R.string.kst_40102);
            case 40103 :
                return context.getResources().getString(R.string.kst_40103);
            case 40104 :
                return context.getResources().getString(R.string.kst_40104);
            case 40105 :
                return context.getResources().getString(R.string.kst_40105);
            case 40106 :
                return context.getResources().getString(R.string.kst_40106);
            case 40107 :
                return context.getResources().getString(R.string.kst_40107);
            case 40108 :
                return context.getResources().getString(R.string.kst_40108);
            case 40109 :
                return context.getResources().getString(R.string.kst_40109);
            case 40110 :
                return context.getResources().getString(R.string.kst_40110);
            case 40111 :
                return context.getResources().getString(R.string.kst_40111);
            case 40112 :
                return context.getResources().getString(R.string.kst_40112);
            case 40113 :
                return context.getResources().getString(R.string.kst_40113);
            case 40114 :
                return context.getResources().getString(R.string.kst_40114);
            case 40115 :
                return context.getResources().getString(R.string.kst_40115);
            case 40116 :
                return context.getResources().getString(R.string.kst_40116);
            case 40117 :
                return context.getResources().getString(R.string.kst_40117);
            case 40118 :
                return context.getResources().getString(R.string.kst_40118);
            case 40119 :
                return context.getResources().getString(R.string.kst_40119);
            case 40120 :
                return context.getResources().getString(R.string.kst_40120);
            case 40121 :
                return context.getResources().getString(R.string.kst_40121);
            case 40122 :
                return context.getResources().getString(R.string.kst_40122);
            case 40123 :
                return context.getResources().getString(R.string.kst_40123);
            case 40124 :
                return context.getResources().getString(R.string.kst_40124);
            case 40125 :
                return context.getResources().getString(R.string.kst_40125);
            case 40126 :
                return context.getResources().getString(R.string.kst_40126);
            case 40127 :
                return context.getResources().getString(R.string.kst_40127);
            case 40128 :
                return context.getResources().getString(R.string.kst_40128);
            case 40129 :
                return context.getResources().getString(R.string.kst_40129);
            case 40130 :
                return context.getResources().getString(R.string.kst_40130);
            case 40131 :
                return context.getResources().getString(R.string.kst_40131);
            case 40132 :
                return context.getResources().getString(R.string.kst_40132);
            case 40133 :
                return context.getResources().getString(R.string.kst_40133);
            case 40134 :
                return context.getResources().getString(R.string.kst_40134);
            case 40135 :
                return context.getResources().getString(R.string.kst_40135);
            case 40136 :
                return context.getResources().getString(R.string.kst_40136);
            case 40137 :
                return context.getResources().getString(R.string.kst_40137);
            case 40146 :
                return context.getResources().getString(R.string.kst_40146);
            case 40147 :
                return context.getResources().getString(R.string.kst_40147);
            case 40148 :
                return context.getResources().getString(R.string.kst_40148);
            case 40149 :
                return context.getResources().getString(R.string.kst_40149);
            case 40150 :
                return context.getResources().getString(R.string.kst_40150);
            case 40151 :
                return context.getResources().getString(R.string.kst_40151);
            case 40152 :
                return context.getResources().getString(R.string.kst_40152);
            case 40153 :
                return context.getResources().getString(R.string.kst_40153);
            case 40154 :
                return context.getResources().getString(R.string.kst_40154);
            case 40177 :
                return context.getResources().getString(R.string.kst_40177);
            case 40207 :
                return context.getResources().getString(R.string.kst_40207);
            case 40208 :
                return context.getResources().getString(R.string.kst_40208);
            case 40209 :
                return context.getResources().getString(R.string.kst_40209);
            case 40210 :
                return context.getResources().getString(R.string.kst_40210);
            case 40211 :
                return context.getResources().getString(R.string.kst_40211);
            case 40231 :
                return context.getResources().getString(R.string.kst_40231);
            case 40237 :
                return context.getResources().getString(R.string.kst_40237);
            case 40240 :
                return context.getResources().getString(R.string.kst_40240);
            case 40241 :
                return context.getResources().getString(R.string.kst_40241);
            case 40242 :
                return context.getResources().getString(R.string.kst_40242);
            case 40243 :
                return context.getResources().getString(R.string.kst_40243);
            case 40244 :
                return context.getResources().getString(R.string.kst_40244);
            case 40245 :
                return context.getResources().getString(R.string.kst_40245);
            case 40301 :
                return context.getResources().getString(R.string.kst_40301);
            case 40302 :
                return context.getResources().getString(R.string.kst_40302);
            case 40303 :
                return context.getResources().getString(R.string.kst_40303);
            case 40304 :
                return context.getResources().getString(R.string.kst_40304);
            case 40305 :
                return context.getResources().getString(R.string.kst_40305);
            case 40409 :
                return context.getResources().getString(R.string.kst_40409);
            case 40410 :
                return context.getResources().getString(R.string.kst_40410);
            case 40411 :
                return context.getResources().getString(R.string.kst_40411);
            case 40413 :
                return context.getResources().getString(R.string.kst_40413);
            case 40414 :
                return context.getResources().getString(R.string.kst_40414);
            case 40415 :
                return context.getResources().getString(R.string.kst_40415);
            case 40416 :
                return context.getResources().getString(R.string.kst_40416);
            case 40417 :
                return context.getResources().getString(R.string.kst_40417);
            case 40418 :
                return context.getResources().getString(R.string.kst_40418);
            case 40419 :
                return context.getResources().getString(R.string.kst_40419);
            case 40420 :
                return context.getResources().getString(R.string.kst_40420);
            case 40421 :
                return context.getResources().getString(R.string.kst_40421);
            case 40422 :
                return context.getResources().getString(R.string.kst_40422);
            case 40423 :
                return context.getResources().getString(R.string.kst_40423);
            case 40454 :
                return context.getResources().getString(R.string.kst_40454);
            case 40461 :
                return context.getResources().getString(R.string.kst_40461);
            case 40477 :
                return context.getResources().getString(R.string.kst_40477);
            case 40557 :
                return context.getResources().getString(R.string.kst_40557);
            case 40642 :
                return context.getResources().getString(R.string.kst_40642);
            case 40673 :
                return context.getResources().getString(R.string.kst_40673);
            case 40691 :
                return context.getResources().getString(R.string.kst_40691);
            case 50002 :
                return context.getResources().getString(R.string.kst_50002);
            case 50003 :
                return context.getResources().getString(R.string.kst_50003);
            case 101301 :
                return context.getResources().getString(R.string.kst_101301);
            case 101302 :
                return context.getResources().getString(R.string.kst_101302);
            case 101303 :
                return context.getResources().getString(R.string.kst_101303);
            case 101304 :
                return context.getResources().getString(R.string.kst_101304);
            case 101305 :
                return context.getResources().getString(R.string.kst_101305);
            case 101306 :
                return context.getResources().getString(R.string.kst_101306);
            case 101307 :
                return context.getResources().getString(R.string.kst_101307);
            case 101308 :
                return context.getResources().getString(R.string.kst_101308);
            case 101309 :
                return context.getResources().getString(R.string.kst_101309);
            case 101310 :
                return context.getResources().getString(R.string.kst_101310);
            case 101311 :
                return context.getResources().getString(R.string.kst_101311);
            case 102101 :
                return context.getResources().getString(R.string.kst_102101);
            case 102102 :
                return context.getResources().getString(R.string.kst_102102);
            case 102103 :
                return context.getResources().getString(R.string.kst_102103);
            case 102104 :
                return context.getResources().getString(R.string.kst_102104);
            case 3110011 :
                return context.getResources().getString(R.string.kst_3110011);
            case 3110012 :
                return context.getResources().getString(R.string.kst_3110012);
            case 3110013 :
                return context.getResources().getString(R.string.kst_3110013);
            case 31100052 :
                return context.getResources().getString(R.string.kst_31100052);
            case 31100053 :
                return context.getResources().getString(R.string.kst_31100053);
            case 85400200 :
                return context.getResources().getString(R.string.kst_85400200);
            case 85400201 :
                return context.getResources().getString(R.string.kst_85400201);
            case 57000108 :
                return context.getResources().getString(R.string.kst_57000108);
            case 311000107 :
                return context.getResources().getString(R.string.kst_311000107);
            case 311000515 :
                return context.getResources().getString(R.string.kst_311000515);
            case 990001 :
                return context.getResources().getString(R.string.kst_990001);
            case 990002 :
                return context.getResources().getString(R.string.kst_990002);
            case 990003 :
                return context.getResources().getString(R.string.kst_990003);
            case 990004 :
                return context.getResources().getString(R.string.kst_990004);
            case 990005 :
                return context.getResources().getString(R.string.kst_990005);
            case 990006 :
                return context.getResources().getString(R.string.kst_990006);
            case 990007 :
                return context.getResources().getString(R.string.kst_990007);
            case 990008 :
                return context.getResources().getString(R.string.kst_990008);
            case 990009 :
                return context.getResources().getString(R.string.kst_990009);
            case 990010 :
                return context.getResources().getString(R.string.kst_990010);
            case 990011 :
                return context.getResources().getString(R.string.kst_990011);
            case 990012 :
                return context.getResources().getString(R.string.kst_990012);
            case 990013 :
                return context.getResources().getString(R.string.kst_990013);
            case 990101 :
                return context.getResources().getString(R.string.kst_990101);
            case 990102 :
                return context.getResources().getString(R.string.kst_990102);
            case 990103 :
                return context.getResources().getString(R.string.kst_990103);
            case 990104 :
                return context.getResources().getString(R.string.kst_990104);
            case 990105 :
                return context.getResources().getString(R.string.kst_990105);
            case 990106 :
                return context.getResources().getString(R.string.kst_990106);
            case 990107 :
                return context.getResources().getString(R.string.kst_990107);
            case 990108 :
                return context.getResources().getString(R.string.kst_990108);
            case 990109 :
                return context.getResources().getString(R.string.kst_990109);
            case 990110 :
                return context.getResources().getString(R.string.kst_990110);
            case 990201 :
                return context.getResources().getString(R.string.kst_990201);
            case 990202 :
                return context.getResources().getString(R.string.kst_990202);
            case 990203 :
                return context.getResources().getString(R.string.kst_990203);
            case 990204 :
                return context.getResources().getString(R.string.kst_990204);
            case 990205 :
                return context.getResources().getString(R.string.kst_990205);
            case 990206 :
                return context.getResources().getString(R.string.kst_990206);
            case 990207 :
                return context.getResources().getString(R.string.kst_990207);
            case 990208 :
                return context.getResources().getString(R.string.kst_990208);
            case 990209 :
                return context.getResources().getString(R.string.kst_990209);
            case 990210 :
                return context.getResources().getString(R.string.kst_990210);
            case 990301 :
                return context.getResources().getString(R.string.kst_990301);
            case 990302 :
                return context.getResources().getString(R.string.kst_990302);
            case 990303 :
                return context.getResources().getString(R.string.kst_990303);
            case 990304 :
                return context.getResources().getString(R.string.kst_990304);
            case 990305 :
                return context.getResources().getString(R.string.kst_990305);
            case 990306 :
                return context.getResources().getString(R.string.kst_990306);
            case 990307 :
                return context.getResources().getString(R.string.kst_990307);
            case 990308 :
                return context.getResources().getString(R.string.kst_990308);
            case 990309 :
                return context.getResources().getString(R.string.kst_990309);
            case 990310 :
                return context.getResources().getString(R.string.kst_990310);
            case 990311 :
                return context.getResources().getString(R.string.kst_990311);
            case 990312 :
                return context.getResources().getString(R.string.kst_990312);
            case 990313 :
                return context.getResources().getString(R.string.kst_990313);
            case 990314 :
                return context.getResources().getString(R.string.kst_990314);
            default:
                return "";
        }
    }
}
