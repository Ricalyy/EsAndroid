package com.esunny.data.error;

import android.content.Context;

import com.esunny.data.R;


class CtpErrorCode {

    static String getErrorMessage(Context context, int errorCode) {

        switch (errorCode) {
            case -1 :
                return context.getResources().getString(R.string.ctp_n1);
            case -2 :
                return context.getResources().getString(R.string.ctp_n2);
            case 0 :
                return context.getResources().getString(R.string.ctp_0);
            case 1 :
                return context.getResources().getString(R.string.ctp_1);
            case 2 :
                return context.getResources().getString(R.string.ctp_2);
            case 3 :
                return context.getResources().getString(R.string.ctp_3);
            case 4 :
                return context.getResources().getString(R.string.ctp_4);
            case 5 :
                return context.getResources().getString(R.string.ctp_5);
            case 6 :
                return context.getResources().getString(R.string.ctp_6);
            case 7 :
                return context.getResources().getString(R.string.ctp_7);
            case 8 :
                return context.getResources().getString(R.string.ctp_8);
            case 9 :
                return context.getResources().getString(R.string.ctp_9);
            case 10 :
                return context.getResources().getString(R.string.ctp_10);
            case 11 :
                return context.getResources().getString(R.string.ctp_11);
            case 12 :
                return context.getResources().getString(R.string.ctp_12);
            case 13 :
                return context.getResources().getString(R.string.ctp_13);
            case 14 :
                return context.getResources().getString(R.string.ctp_14);
            case 15 :
                return context.getResources().getString(R.string.ctp_15);
            case 16 :
                return context.getResources().getString(R.string.ctp_16);
            case 17 :
                return context.getResources().getString(R.string.ctp_17);
            case 18 :
                return context.getResources().getString(R.string.ctp_18);
            case 19 :
                return context.getResources().getString(R.string.ctp_19);
            case 20 :
                return context.getResources().getString(R.string.ctp_20);
            case 21 :
                return context.getResources().getString(R.string.ctp_21);
            case 22 :
                return context.getResources().getString(R.string.ctp_22);
            case 23 :
                return context.getResources().getString(R.string.ctp_23);
            case 24 :
                return context.getResources().getString(R.string.ctp_24);
            case 25 :
                return context.getResources().getString(R.string.ctp_25);
            case 26 :
                return context.getResources().getString(R.string.ctp_26);
            case 27 :
                return context.getResources().getString(R.string.ctp_27);
            case 28 :
                return context.getResources().getString(R.string.ctp_28);
            case 29 :
                return context.getResources().getString(R.string.ctp_29);
            case 30 :
                return context.getResources().getString(R.string.ctp_30);
            case 31 :
                return context.getResources().getString(R.string.ctp_31);
            case 32 :
                return context.getResources().getString(R.string.ctp_32);
            case 33 :
                return context.getResources().getString(R.string.ctp_33);
            case 34 :
                return context.getResources().getString(R.string.ctp_34);
            case 35 :
                return context.getResources().getString(R.string.ctp_35);
            case 36 :
                return context.getResources().getString(R.string.ctp_36);
            case 37 :
                return context.getResources().getString(R.string.ctp_37);
            case 38 :
                return context.getResources().getString(R.string.ctp_38);
            case 39 :
                return context.getResources().getString(R.string.ctp_39);
            case 40 :
                return context.getResources().getString(R.string.ctp_40);
            case 41 :
                return context.getResources().getString(R.string.ctp_41);
            case 42 :
                return context.getResources().getString(R.string.ctp_42);
            case 43 :
                return context.getResources().getString(R.string.ctp_43);
            case 44 :
                return context.getResources().getString(R.string.ctp_44);
            case 45 :
                return context.getResources().getString(R.string.ctp_45);
            case 46 :
                return context.getResources().getString(R.string.ctp_46);
            case 47 :
                return context.getResources().getString(R.string.ctp_47);
            case 48 :
                return context.getResources().getString(R.string.ctp_48);
            case 49 :
                return context.getResources().getString(R.string.ctp_49);
            case 50 :
                return context.getResources().getString(R.string.ctp_50);
            case 51 :
                return context.getResources().getString(R.string.ctp_51);
            case 52 :
                return context.getResources().getString(R.string.ctp_52);
            case 53 :
                return context.getResources().getString(R.string.ctp_53);
            case 54 :
                return context.getResources().getString(R.string.ctp_54);
            case 55 :
                return context.getResources().getString(R.string.ctp_55);
            case 56 :
                return context.getResources().getString(R.string.ctp_56);
            case 57 :
                return context.getResources().getString(R.string.ctp_57);
            case 58 :
                return context.getResources().getString(R.string.ctp_58);
            case 59 :
                return context.getResources().getString(R.string.ctp_59);
            case 60 :
                return context.getResources().getString(R.string.ctp_60);
            case 61 :
                return context.getResources().getString(R.string.ctp_61);
            case 62 :
                return context.getResources().getString(R.string.ctp_62);
            case 63 :
                return context.getResources().getString(R.string.ctp_63);
            case 64 :
                return context.getResources().getString(R.string.ctp_64);
            case 65 :
                return context.getResources().getString(R.string.ctp_65);
            case 66 :
                return context.getResources().getString(R.string.ctp_66);
            case 67 :
                return context.getResources().getString(R.string.ctp_67);
            case 68 :
                return context.getResources().getString(R.string.ctp_68);
            case 69 :
                return context.getResources().getString(R.string.ctp_69);
            case 70 :
                return context.getResources().getString(R.string.ctp_70);
            case 71 :
                return context.getResources().getString(R.string.ctp_71);
            case 72 :
                return context.getResources().getString(R.string.ctp_72);
            case 73 :
                return context.getResources().getString(R.string.ctp_73);
            case 74 :
                return context.getResources().getString(R.string.ctp_74);
            case 75 :
                return context.getResources().getString(R.string.ctp_75);
            case 76 :
                return context.getResources().getString(R.string.ctp_76);
            case 77 :
                return context.getResources().getString(R.string.ctp_77);
            case 78 :
                return context.getResources().getString(R.string.ctp_78);
            case 79 :
                return context.getResources().getString(R.string.ctp_79);
            case 80 :
                return context.getResources().getString(R.string.ctp_80);
            case 81 :
                return context.getResources().getString(R.string.ctp_81);
            case 82 :
                return context.getResources().getString(R.string.ctp_82);
            case 83 :
                return context.getResources().getString(R.string.ctp_83);
            case 84 :
                return context.getResources().getString(R.string.ctp_84);
            case 85 :
                return context.getResources().getString(R.string.ctp_85);
            case 86 :
                return context.getResources().getString(R.string.ctp_86);
            case 87 :
                return context.getResources().getString(R.string.ctp_87);
            case 88 :
                return context.getResources().getString(R.string.ctp_88);
            case 89 :
                return context.getResources().getString(R.string.ctp_89);
            case 90 :
                return context.getResources().getString(R.string.ctp_90);
            case 91 :
                return context.getResources().getString(R.string.ctp_91);
            case 92 :
                return context.getResources().getString(R.string.ctp_92);
            case 93 :
                return context.getResources().getString(R.string.ctp_93);
            case 94 :
                return context.getResources().getString(R.string.ctp_94);
            case 101 :
                return context.getResources().getString(R.string.ctp_101);
            case 102 :
                return context.getResources().getString(R.string.ctp_102);
            case 131 :
                return context.getResources().getString(R.string.ctp_131);
            case 132 :
                return context.getResources().getString(R.string.ctp_132);
            case 133 :
                return context.getResources().getString(R.string.ctp_133);
            case 139 :
                return context.getResources().getString(R.string.ctp_139);
            case 140 :
                return context.getResources().getString(R.string.ctp_140);
            case 141 :
                return context.getResources().getString(R.string.ctp_141);
            case 142 :
                return context.getResources().getString(R.string.ctp_142);
            case 143 :
                return context.getResources().getString(R.string.ctp_143);
            case 144 :
                return context.getResources().getString(R.string.ctp_144);
            case 1000 :
                return context.getResources().getString(R.string.ctp_1000);
            case 1001 :
                return context.getResources().getString(R.string.ctp_1001);
            case 1002 :
                return context.getResources().getString(R.string.ctp_1002);
            case 1003 :
                return context.getResources().getString(R.string.ctp_1003);
            case 1004 :
                return context.getResources().getString(R.string.ctp_1004);
            case 1005 :
                return context.getResources().getString(R.string.ctp_1005);
            case 1006 :
                return context.getResources().getString(R.string.ctp_1006);
            case 1007 :
                return context.getResources().getString(R.string.ctp_1007);
            case 1008 :
                return context.getResources().getString(R.string.ctp_1008);
            case 1009 :
                return context.getResources().getString(R.string.ctp_1009);
            case 1010 :
                return context.getResources().getString(R.string.ctp_1010);
            case 1011 :
                return context.getResources().getString(R.string.ctp_1011);
            case 1012 :
                return context.getResources().getString(R.string.ctp_1012);
            case 1013 :
                return context.getResources().getString(R.string.ctp_1013);
            case 1014 :
                return context.getResources().getString(R.string.ctp_1014);
            case 1015 :
                return context.getResources().getString(R.string.ctp_1015);
            case 1016 :
                return context.getResources().getString(R.string.ctp_1016);
            case 1017 :
                return context.getResources().getString(R.string.ctp_1017);
            case 1018 :
                return context.getResources().getString(R.string.ctp_1018);
            case 1019 :
                return context.getResources().getString(R.string.ctp_1019);
            case 1020 :
                return context.getResources().getString(R.string.ctp_1020);
            case 1021 :
                return context.getResources().getString(R.string.ctp_1021);
            case 1022 :
                return context.getResources().getString(R.string.ctp_1022);
            case 1023 :
                return context.getResources().getString(R.string.ctp_1023);
            case 1024 :
                return context.getResources().getString(R.string.ctp_1024);
            case 1025 :
                return context.getResources().getString(R.string.ctp_1025);
            case 1026 :
                return context.getResources().getString(R.string.ctp_1026);
            case 1027 :
                return context.getResources().getString(R.string.ctp_1027);
            case 1028 :
                return context.getResources().getString(R.string.ctp_1028);
            case 1029 :
                return context.getResources().getString(R.string.ctp_1029);
            case 1030 :
                return context.getResources().getString(R.string.ctp_1030);
            case 1031 :
                return context.getResources().getString(R.string.ctp_1031);
            case 1032 :
                return context.getResources().getString(R.string.ctp_1032);
            case 1033 :
                return context.getResources().getString(R.string.ctp_1033);
            case 1034 :
                return context.getResources().getString(R.string.ctp_1034);
            case 1035 :
                return context.getResources().getString(R.string.ctp_1035);
            case 1036 :
                return context.getResources().getString(R.string.ctp_1036);
            case 1037 :
                return context.getResources().getString(R.string.ctp_1037);
            case 1038 :
                return context.getResources().getString(R.string.ctp_1038);
            case 1039 :
                return context.getResources().getString(R.string.ctp_1039);
            case 1040 :
                return context.getResources().getString(R.string.ctp_1040);
            case 1041 :
                return context.getResources().getString(R.string.ctp_1041);
            case 1042 :
                return context.getResources().getString(R.string.ctp_1042);
            case 2000 :
                return context.getResources().getString(R.string.ctp_2000);
            case 2001 :
                return context.getResources().getString(R.string.ctp_2001);
            case 2004 :
                return context.getResources().getString(R.string.ctp_2004);
            case 2005 :
                return context.getResources().getString(R.string.ctp_2005);
            case 2006 :
                return context.getResources().getString(R.string.ctp_2006);
            case 2007 :
                return context.getResources().getString(R.string.ctp_2007);
            case 2008 :
                return context.getResources().getString(R.string.ctp_2008);
            case 2009 :
                return context.getResources().getString(R.string.ctp_2009);
            case 2011 :
                return context.getResources().getString(R.string.ctp_2011);
            case 2012 :
                return context.getResources().getString(R.string.ctp_2012);
            case 2013 :
                return context.getResources().getString(R.string.ctp_2013);
            case 2014 :
                return context.getResources().getString(R.string.ctp_2014);
            case 2015 :
                return context.getResources().getString(R.string.ctp_2015);
            case 2016 :
                return context.getResources().getString(R.string.ctp_2016);
            case 2017 :
                return context.getResources().getString(R.string.ctp_2017);
            case 3001 :
                return context.getResources().getString(R.string.ctp_3001);
            case 3002 :
                return context.getResources().getString(R.string.ctp_3002);
            case 3005 :
                return context.getResources().getString(R.string.ctp_3005);
            case 3006 :
                return context.getResources().getString(R.string.ctp_3006);
            case 3007 :
                return context.getResources().getString(R.string.ctp_3007);
            case 3009 :
                return context.getResources().getString(R.string.ctp_3009);
            case 3010 :
                return context.getResources().getString(R.string.ctp_3010);
            case 3011 :
                return context.getResources().getString(R.string.ctp_3011);
            case 3017 :
                return context.getResources().getString(R.string.ctp_3017);
            case 3019 :
                return context.getResources().getString(R.string.ctp_3019);
            case 3020 :
                return context.getResources().getString(R.string.ctp_3020);
            case 3021 :
                return context.getResources().getString(R.string.ctp_3021);
            case 3022 :
                return context.getResources().getString(R.string.ctp_3022);
            case 3023 :
                return context.getResources().getString(R.string.ctp_3023);
            case 3026 :
                return context.getResources().getString(R.string.ctp_3026);
            case 3030 :
                return context.getResources().getString(R.string.ctp_3030);
            case 3035 :
                return context.getResources().getString(R.string.ctp_3035);
            case 3036 :
                return context.getResources().getString(R.string.ctp_3036);
            case 3037 :
                return context.getResources().getString(R.string.ctp_3037);
            case 3038 :
                return context.getResources().getString(R.string.ctp_3038);
            case 3039 :
                return context.getResources().getString(R.string.ctp_3039);
            case 3040 :
                return context.getResources().getString(R.string.ctp_3040);
            case 3041 :
                return context.getResources().getString(R.string.ctp_3041);
            case 3042 :
                return context.getResources().getString(R.string.ctp_3042);
            case 3043 :
                return context.getResources().getString(R.string.ctp_3043);
            case 3044 :
                return context.getResources().getString(R.string.ctp_3044);
            case 3045 :
                return context.getResources().getString(R.string.ctp_3045);
            case 3046 :
                return context.getResources().getString(R.string.ctp_3046);
            case 4096 :
                return context.getResources().getString(R.string.ctp_4096);
            case 4097 :
                return context.getResources().getString(R.string.ctp_4097);
            case 4098 :
                return context.getResources().getString(R.string.ctp_4098);
            case 8193 :
                return context.getResources().getString(R.string.ctp_8193);
            case 8194 :
                return context.getResources().getString(R.string.ctp_8194);
            case 8195 :
                return context.getResources().getString(R.string.ctp_8195);
//            case 9999 :
//                return context.getResources().getString(R.string.ctp_9999);
            case 999999 :
                return context.getResources().getString(R.string.ctp_999999);
            case 990001 :
                return context.getResources().getString(R.string.ctp_990001);
            case 990002 :
                return context.getResources().getString(R.string.ctp_990002);
            case 990003 :
                return context.getResources().getString(R.string.ctp_990003);
            case 990004 :
                return context.getResources().getString(R.string.ctp_990004);
            case 990005 :
                return context.getResources().getString(R.string.ctp_990005);
            case 990006 :
                return context.getResources().getString(R.string.ctp_990006);
            case 990007 :
                return context.getResources().getString(R.string.ctp_990007);
            case 990008 :
                return context.getResources().getString(R.string.ctp_990008);
            case 990009 :
                return context.getResources().getString(R.string.ctp_990009);
            case 990010 :
                return context.getResources().getString(R.string.ctp_990010);
            case 990011 :
                return context.getResources().getString(R.string.ctp_990011);
            case 990012 :
                return context.getResources().getString(R.string.ctp_990012);
            case 990013 :
                return context.getResources().getString(R.string.ctp_990013);
            case 990101 :
                return context.getResources().getString(R.string.ctp_990101);
            case 990102 :
                return context.getResources().getString(R.string.ctp_990102);
            case 990103 :
                return context.getResources().getString(R.string.ctp_990103);
            case 990104 :
                return context.getResources().getString(R.string.ctp_990104);
            case 990105 :
                return context.getResources().getString(R.string.ctp_990105);
            case 990106 :
                return context.getResources().getString(R.string.ctp_990106);
            case 990107 :
                return context.getResources().getString(R.string.ctp_990107);
            case 990108 :
                return context.getResources().getString(R.string.ctp_990108);
            case 990109 :
                return context.getResources().getString(R.string.ctp_990109);
            case 990110 :
                return context.getResources().getString(R.string.ctp_990110);
            case 990201 :
                return context.getResources().getString(R.string.ctp_990201);
            case 990202 :
                return context.getResources().getString(R.string.ctp_990202);
            case 990203 :
                return context.getResources().getString(R.string.ctp_990203);
            case 990204 :
                return context.getResources().getString(R.string.ctp_990204);
            case 990205 :
                return context.getResources().getString(R.string.ctp_990205);
            case 990206 :
                return context.getResources().getString(R.string.ctp_990206);
            case 990207 :
                return context.getResources().getString(R.string.ctp_990207);
            case 990208 :
                return context.getResources().getString(R.string.ctp_990208);
            case 990209 :
                return context.getResources().getString(R.string.ctp_990209);
            case 990210 :
                return context.getResources().getString(R.string.ctp_990210);
            case 990301 :
                return context.getResources().getString(R.string.ctp_990301);
            case 990302 :
                return context.getResources().getString(R.string.ctp_990302);
            case 990303 :
                return context.getResources().getString(R.string.ctp_990303);
            case 990304 :
                return context.getResources().getString(R.string.ctp_990304);
            case 990305 :
                return context.getResources().getString(R.string.ctp_990305);
            case 990306 :
                return context.getResources().getString(R.string.ctp_990306);
            case 990307 :
                return context.getResources().getString(R.string.ctp_990307);
            case 990308 :
                return context.getResources().getString(R.string.ctp_990308);
            case 990309 :
                return context.getResources().getString(R.string.ctp_990309);
            case 990310 :
                return context.getResources().getString(R.string.ctp_990310);
            case 990311 :
                return context.getResources().getString(R.string.ctp_990311);
            case 990312 :
                return context.getResources().getString(R.string.ctp_990312);
            case 990313 :
                return context.getResources().getString(R.string.ctp_990313);
            case 990314 :
                return context.getResources().getString(R.string.ctp_990314);
            default:
                return "";

        }
    }
}
