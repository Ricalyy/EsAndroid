package com.esunny.data.bean;

import java.math.BigInteger;

/**
 * @author Peter Fu
 * @date 2020/10/10
 */
public class SQuoteFieldL2 {
    private double Price;
    private BigInteger Qty;

    public double getPrice() {
        return Price;
    }

    public void setPrice(double price) {
        Price = price;
    }

    public BigInteger getQty() {
        return Qty;
    }

    public void setQty(BigInteger qty) {
        Qty = qty;
    }

    public QuoteField toQuoteField() {
        QuoteField quoteField = new QuoteField();
        quoteField.setPrice(Price);
        quoteField.setQty(Qty);
        return quoteField;
    }
}
