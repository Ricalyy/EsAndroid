package com.esunny.data.bean;

import java.io.Serializable;

public class CloudTradeCompany implements Serializable {
    private String companyNo;
    private String companyName;
    private String addrTypeNo;
    private String addrTypeName;
    private String tradeApi;
    private char simulateTrade;

    public String getCompanyNo() {
        return companyNo;
    }

    public void setCompanyNo(String companyNo) {
        this.companyNo = companyNo;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAddrTypeNo() {
        return addrTypeNo;
    }

    public void setAddrTypeNo(String addrTypeNo) {
        this.addrTypeNo = addrTypeNo;
    }

    public String getAddrTypeName() {
        return addrTypeName;
    }

    public void setAddrTypeName(String addrTypeName) {
        this.addrTypeName = addrTypeName;
    }

    public String getTradeApi() {
        return tradeApi;
    }

    public void setTradeApi(String tradeApi) {
        this.tradeApi = tradeApi;
    }

    public char getSimulateTrade() {
        return simulateTrade;
    }

    public void setSimulateTrade(char simulateTrade) {
        this.simulateTrade = simulateTrade;
    }
}
