package com.esunny.data.error;

import android.content.Context;

import com.esunny.data.R;

class QuoteErrorCode {

    static String getErrorMessage(Context context, int errorCode) {

        switch (errorCode) {
            case 0 :
                return context.getResources().getString(R.string.quote_0);
            case 1001 :
                return context.getResources().getString(R.string.quote_1001);
            case 1002 :
                return context.getResources().getString(R.string.quote_1002);
            case 1003 :
                return context.getResources().getString(R.string.quote_1003);
            case 1004 :
                return context.getResources().getString(R.string.quote_1004);
            case 1005 :
                return context.getResources().getString(R.string.quote_1005);
            case 1006 :
                return context.getResources().getString(R.string.quote_1006);
            case 1007 :
                return context.getResources().getString(R.string.quote_1007);
            case 1008 :
                return context.getResources().getString(R.string.quote_1008);
            case 1009 :
                return context.getResources().getString(R.string.quote_1009);
            case 1010 :
                return context.getResources().getString(R.string.quote_1010);
            case 1011 :
                return context.getResources().getString(R.string.quote_1011);
            case 10001 :
                return context.getResources().getString(R.string.quote_10001);
            case 10002 :
                return context.getResources().getString(R.string.quote_10002);
            case 10003 :
                return context.getResources().getString(R.string.quote_10003);
            case 10004 :
                return context.getResources().getString(R.string.quote_10004);
            case 10005 :
                return context.getResources().getString(R.string.quote_10005);
            case 990001 :
                return context.getResources().getString(R.string.quote_990001);
            case 990002 :
                return context.getResources().getString(R.string.quote_990002);
            case 990003 :
                return context.getResources().getString(R.string.quote_990003);
            case 990004 :
                return context.getResources().getString(R.string.quote_990004);
            case 990005 :
                return context.getResources().getString(R.string.quote_990005);
            case 990006 :
                return context.getResources().getString(R.string.quote_990006);
            case 990007 :
                return context.getResources().getString(R.string.quote_990007);
            case 990008 :
                return context.getResources().getString(R.string.quote_990008);
            case 990009 :
                return context.getResources().getString(R.string.quote_990009);
            case 990010 :
                return context.getResources().getString(R.string.quote_990010);
            case 990011 :
                return context.getResources().getString(R.string.quote_990011);
            case 990012 :
                return context.getResources().getString(R.string.quote_990012);
            case 990013 :
                return context.getResources().getString(R.string.quote_990013);
            case 990101 :
                return context.getResources().getString(R.string.quote_990101);
            case 990102 :
                return context.getResources().getString(R.string.quote_990102);
            case 990103 :
                return context.getResources().getString(R.string.quote_990103);
            case 990104 :
                return context.getResources().getString(R.string.quote_990104);
            case 990105 :
                return context.getResources().getString(R.string.quote_990105);
            case 990106 :
                return context.getResources().getString(R.string.quote_990106);
            case 990107 :
                return context.getResources().getString(R.string.quote_990107);
            case 990108 :
                return context.getResources().getString(R.string.quote_990108);
            case 990109 :
                return context.getResources().getString(R.string.quote_990109);
            case 990110 :
                return context.getResources().getString(R.string.quote_990110);
            case 990201 :
                return context.getResources().getString(R.string.quote_990201);
            case 990202 :
                return context.getResources().getString(R.string.quote_990202);
            case 990203 :
                return context.getResources().getString(R.string.quote_990203);
            case 990204 :
                return context.getResources().getString(R.string.quote_990204);
            case 990205 :
                return context.getResources().getString(R.string.quote_990205);
            case 990206 :
                return context.getResources().getString(R.string.quote_990206);
            case 990207 :
                return context.getResources().getString(R.string.quote_990207);
            case 990208 :
                return context.getResources().getString(R.string.quote_990208);
            case 990209 :
                return context.getResources().getString(R.string.quote_990209);
            case 990210 :
                return context.getResources().getString(R.string.quote_990210);
            case 990301 :
                return context.getResources().getString(R.string.quote_990301);
            case 990302 :
                return context.getResources().getString(R.string.quote_990302);
            case 990303 :
                return context.getResources().getString(R.string.quote_990303);
            case 990304 :
                return context.getResources().getString(R.string.quote_990304);
            case 990305 :
                return context.getResources().getString(R.string.quote_990305);
            case 990306 :
                return context.getResources().getString(R.string.quote_990306);
            case 990307 :
                return context.getResources().getString(R.string.quote_990307);
            case 990308 :
                return context.getResources().getString(R.string.quote_990308);
            case 990309 :
                return context.getResources().getString(R.string.quote_990309);
            case 990310 :
                return context.getResources().getString(R.string.quote_990310);
            case 990311 :
                return context.getResources().getString(R.string.quote_990311);
            case 990312 :
                return context.getResources().getString(R.string.quote_990312);
            case 990313 :
                return context.getResources().getString(R.string.quote_990313);
            case 990314 :
                return context.getResources().getString(R.string.quote_990314);
            default:
               return "";
        }

    }
}
