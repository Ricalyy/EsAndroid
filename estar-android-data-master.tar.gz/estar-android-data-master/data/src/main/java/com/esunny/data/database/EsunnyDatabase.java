package com.esunny.data.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.esunny.data.database.gen.DaoMaster;
import com.esunny.data.database.gen.DaoSession;


/**
 * @author Peter Fu
 * @date 2020/10/13
 */
public class EsunnyDatabase implements IDatabase {
    private DaoMaster.OpenHelper devOpenHelper;
    private static DaoMaster daoMaster;
    private static DaoSession daoSession;

    private EsunnyDatabase() {}

    public EsunnyDatabase(Context context) {
        devOpenHelper = new DaoMaster.DevOpenHelper(context, ServerDatabaseHelper.ESUNNY_DATABASE_NAME);
        daoMaster = new DaoMaster(devOpenHelper.getWritableDatabase());
        daoSession = daoMaster.newSession();
    }

    @Override
    public DaoSession getDaoSession() {
        return daoSession;
    }

    @Override
    public DaoMaster getDaoMaster() {
        return daoMaster;
    }

    @Override
    public SQLiteDatabase getWritableDatabase() {
        return devOpenHelper.getWritableDatabase();
    }
}