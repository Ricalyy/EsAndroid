package com.esunny.data.bean;

import android.util.SparseArray;

import com.esunny.data.bean.SQuoteField;
import com.esunny.mobile.EsNativeProtocol;

/**
 * @author Peter Fu
 * @date 2020/10/10
 */
public class SQuoteSnapShot {

    private SparseArray<SQuoteField> Data = new SparseArray();

    public SparseArray<SQuoteField> getData() {
        return Data;
    }

    public void setData(SparseArray<SQuoteField> data) {
        Data = data;
    }
}
