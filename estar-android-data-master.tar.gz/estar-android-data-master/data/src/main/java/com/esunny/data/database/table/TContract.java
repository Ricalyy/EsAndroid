package com.esunny.data.database.table;

import android.text.TextUtils;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.annotation.Generated;

/**
 * @author Peter Fu
 * @date 2020/10/13
 */
@Entity(nameInDb = "TContract")
public class TContract {
    @Id()
    @Property(nameInDb = "FContractNo")
    private String ContractNo = "";
    @Property(nameInDb = "FCommodityId")
    private String TCommodityId = "";
    @Property(nameInDb = "FCHSContractName")
    private String CHSContractName = "";
    @Property(nameInDb = "FCHTContractName")
    private String CHTContractName = "";
    @Property(nameInDb = "FENUContractName")
    private String ENUContractName = "";
    @Property(nameInDb = "FRealContractNo")
    private String RealContractNo = "";
    @Property(nameInDb = "FUpdateId")
    private Long UpdateId = 0L;                // 更新的编号

    @Generated(hash = 781531674)
    public TContract(String ContractNo, String TCommodityId, String CHSContractName,
            String CHTContractName, String ENUContractName, String RealContractNo,
            Long UpdateId) {
        this.ContractNo = ContractNo;
        this.TCommodityId = TCommodityId;
        this.CHSContractName = CHSContractName;
        this.CHTContractName = CHTContractName;
        this.ENUContractName = ENUContractName;
        this.RealContractNo = RealContractNo;
        this.UpdateId = UpdateId;
    }

    @Generated(hash = 1018796133)
    public TContract() {
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public String getTCommodityId() {
        return TCommodityId;
    }

    public void setTCommodityId(String TCommodityId) {
        this.TCommodityId = TCommodityId;
    }

    public String getCHSContractName() {
        return CHSContractName;
    }

    public void setCHSContractName(String CHSContractName) {
        this.CHSContractName = CHSContractName;
    }

    public String getCHTContractName() {
        return CHTContractName;
    }

    public void setCHTContractName(String CHTContractName) {
        this.CHTContractName = CHTContractName;
    }

    public String getENUContractName() {
        return ENUContractName;
    }

    public void setENUContractName(String ENUContractName) {
        this.ENUContractName = ENUContractName;
    }

    public String getRealContractNo() {
        return RealContractNo;
    }

    public void setRealContractNo(String realContractNo) {
        RealContractNo = realContractNo;
    }

    public Long getUpdateId() {
        return UpdateId;
    }

    public void setUpdateId(Long updateId) {
        UpdateId = updateId;
    }

    public String getContractName() {
        String name = CHSContractName;
        if (TextUtils.isEmpty(name)) {
            name = CHTContractName;
        }
        if (TextUtils.isEmpty(name)) {
            name = ENUContractName;
        }

        return name;
    }
}
