package com.esunny.data.api.event;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class TradeEvent extends AbstractAPIEvent {

    private TradeEvent(AbstractAPIEventBuilder builder) {
        super(builder);
    }

    public String getCompanyNo() {
        return ((Builder)Builder).companyNo;
    }

    public String getUserNo() {
        return ((Builder)Builder).userNo;
    }

    public String getAddressNo() {
        return ((Builder)Builder).addressNo;
    }

    public String getTradeApi() {
        return ((Builder)Builder).tradeApi;
    }

    public static class Builder extends AbstractAPIEventBuilder<TradeEvent> {

        String companyNo;
        String userNo;
        String addressNo;
        String tradeApi;

        public Builder(int action) {
            setAction(action);
        }

        @Override
        public Builder setSender(int sender) {
            this.mSender = sender;
            return this;
        }

        @Override
        public Builder setAction(int action) {
            this.mAction = action;
            return this;
        }

        @Override
        public Builder setData(Object data) {
            this.mData = data;
            return this;
        }

        @Override
        public Builder setSrvChain(boolean srvChain) {
            this.srvChain = srvChain;
            return this;
        }

        @Override
        public Builder setSrvErrorCode(int srvErrorCode) {
            this.srvErrorCode = srvErrorCode;
            return this;
        }

        @Override
        public Builder setSrvErrorText(String srvErrorText) {
            this.srvErrorText = srvErrorText;
            return this;
        }

        public Builder setCompanyNo(String companyNo) {
            this.companyNo = companyNo;
            return this;
        }

        public Builder setUserNo(String userNo) {
            this.userNo = userNo;
            return this;
        }

        public Builder setAddressNo(String addressNo) {
            this.addressNo = addressNo;
            return this;
        }

        public Builder setTradeApi(String tradeApi) {
            this.tradeApi = tradeApi;
            return this;
        }

        @Override
        public TradeEvent buildEvent() {
            return new TradeEvent(this);
        }
    }
}