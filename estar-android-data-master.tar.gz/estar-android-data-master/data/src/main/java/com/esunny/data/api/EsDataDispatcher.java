package com.esunny.data.api;

import android.util.Log;

import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.api.server.EsQuoteApi;
import com.esunny.data.bean.PkgCompanyCloudMapRsp;
import com.esunny.mobile.bean.req.PkgCompanyOpenReq;
import com.esunny.mobile.bean.rsp.PkgCompanyOpenRsp;
import com.esunny.mobile.bean.rsp.PkgPhoneStartRsp;
import com.esunny.mobile.bean.rsp.PkgPlateCodeRsp;
import com.esunny.mobile.bean.rsp.PkgPlateRsp;
import com.esunny.data.util.simplethread.SimpleRunnable;
import com.esunny.data.util.simplethread.TaskManager;
import com.esunny.data.bean.Address;
import com.esunny.mobile.EsApiData;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.UnixJNI;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.mobile.bean.req.PkgAddrReq;
import com.esunny.mobile.bean.req.PkgPhoneStartReq;
import com.esunny.mobile.bean.rsp.PkgCloudAddrRsp;
import com.esunny.mobile.bean.rsp.PkgCompanyAddrRsp;
import com.esunny.mobile.bean.rsp.PkgQuoteAddrRsp;
import com.esunny.mobile.util.ParseUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EsDataDispatcher extends CallbackDispatcher {
    private static final String TAG = "EsDataDispatcher";


    @Override
    public int dispatch(char action, byte[] data) {
        if (action == EVENT_TCP_CONNECT) {
            //需要进行接入认证请求
            UnixJNI.S_SendAuthReq(mPtr, EsBaseApi.getInstance().getLanguageType(), EsNativeProtocol.CSP_SUBSYSTEM_ACCPOINTER);
            return 0;
        }
        if (action == EVENT_TCP_DISCONNECT || action == EVENT_TCP_RESET_DATA) {
            return 0;
        }

        // RECVDATA
        byte[] headArr = new byte[CspSessionHead.STRUCT_LENGTH];
        System.arraycopy(data, 0, headArr, 0, CspSessionHead.STRUCT_LENGTH);

        CspSessionHead head = new CspSessionHead(headArr);
        if (head.getSubSystem() == EsNativeProtocol.CSP_SUBSYSTEM_ACCPOINTER) {
            switch (head.getProtocolCode()) {
                case EsNativeProtocol.CMD_CSP_AUTH_RSP:
                    if (head.getErrorCode() == 0) {
                        queryCodeForbidInfo();
                        queryPhoneStartInfo();
                        queryConfigSwitch();
   
                        queryCloudCompany();
                        queryPlateInfo();
                        queryOpenCompanyInfo();
                        queryCloudTradeAddr();
                        queryCloudCompanyMap();

                        queryQuoteAddr();
                    }
                    break;
                default:
                    break;
            }
        } else if (head.getSubSystem() == EsNativeProtocol.CSP_SUBSYSTEM_PKGMGR) {
            int dataLen = data.length - CspSessionHead.STRUCT_LENGTH;
            byte[] buf = new byte[dataLen];
            System.arraycopy(data, CspSessionHead.STRUCT_LENGTH, buf, 0, dataLen);

            switch (head.getProtocolCode()) {
                case EsNativeProtocol.CMD_PKG_QUOTE_ADDR_RSP:
                {
                    if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
                        onQuoteAddr(buf, head);

                        startQuote();
                    }
                }
                    break;
                case EsNativeProtocol.CMD_PKG_COMPANY_ADDR_RSP:
                    onCloudCompany(buf, head);
                    OnQuoteLogin(0b1);
                    break;
                case EsNativeProtocol.CMD_PKG_CLOUD_ADDR_RSP:
                    onCloudTradeAddr(buf, head);
                    OnQuoteLogin(0b10);
                    break;
                case EsNativeProtocol.CMD_PKG_COMPANY_CLOUD_MAP_RSP:
                    OnCompanyAddrMap(buf, head);
                    OnQuoteLogin(0b100);
                    break;
                case EsNativeProtocol.CMD_PKG_PLATE_INFO_RSP:
                    onPlateInfo(buf, head);
                    OnQuoteLogin(0b1000);
                    break;
                case EsNativeProtocol.CMD_PKG_PLATE_CODE_RSP:
                    onPlateCodeInfo(buf, head);
                    OnQuoteLogin(0b10000);
                    break;
                case EsNativeProtocol.CMD_PKG_CODE_FORBID_RSP:
                    onCodeForbidRsp(buf, head);
                    OnQuoteLogin(0b100000);
                    break;
                case EsNativeProtocol.CMD_PKG_CONFIG_SWITCH_RSP:
                    onConfigSwitchInfo(buf, head);
                    OnQuoteLogin(0b1000000);
                    break;
                case EsNativeProtocol.CMD_PKG_PHONE_START_INFO_RSP:
                    onPhoneStartInfo(buf, head);
                    OnQuoteLogin(0b10000000);
                    break;
                case EsNativeProtocol.CMD_PKG_COMPANY_OPEN_ACCOUNT_INFO_RSP:
                    onCompanyOpenRsp(buf, head);
                    OnQuoteLogin(0b100000000);
                default:
                    break;

            }
        }
        return 0;
    }

    //TODO 这里好多地方还要
    private void OnQuoteLogin(int code) {
        int isReadyQuoteLogin = EsApiData.getInstance().getIsReadyQuoteLogin();
        boolean loginState = EsApiData.getInstance().getLoginState();
        isReadyQuoteLogin |= code;

        EsApiData.getInstance().setIsReadyQuoteLogin(isReadyQuoteLogin);
        if (((isReadyQuoteLogin & 0b010111000) == 0b010111000) && !loginState) {
            EsApiData.getInstance().setLoginState(true);

        }


        if(isReadyQuoteLogin == 0b111111111)//启动一共查询了9项
        {
//            if (G_QuoteUserInfo.LoginNo[0]=='\0') {
//                GAccessInfo.LoginState = 2;
//            }
            EsApiData.getInstance().setIsReadyQuoteLogin(0);//重置，重连可能要用
        }
    }

    private void queryQuoteAddr() {
        queryCommonRequest(EsNativeProtocol.CMD_PKG_QUOTE_ADDR_REQ);
    }

    private void queryCloudCompany() {
        queryCommonRequest(EsNativeProtocol.CMD_PKG_COMPANY_ADDR_REQ);
    }

    private void queryCloudTradeAddr() {
        queryCommonRequest(EsNativeProtocol.CMD_PKG_CLOUD_ADDR_REQ);
    }

    private void queryCloudCompanyMap() {
        queryCommonRequest(EsNativeProtocol.CMD_PKG_COMPANY_CLOUD_MAP_REQ);
    }

    private void queryPlateInfo() {
        queryCommonRequest(EsNativeProtocol.CMD_PKG_PLATE_INFO_REQ);
    }

    private void queryCodeForbidInfo() {
        queryCommonRequest(EsNativeProtocol.CMD_PKG_CODE_FORBID_REQ);
    }

    /**
     * 合并通用请求
     * @param protocolCode 协议码
     */
    private void queryCommonRequest(int protocolCode) {
        PkgAddrReq pkgAddrReq = new PkgAddrReq();
        pkgAddrReq.setTerminalOSType(EsNativeProtocol.PkgAndroid);
        pkgAddrReq.setPackageNo(UnixJNI.S_GetPackageNo());
        pkgAddrReq.setLicenseNo(EsNativeProtocol.LICENSE_NO);
        pkgAddrReq.setProtocolVer((char) 5);
        pkgAddrReq.setLangType(EsBaseApi.getInstance().getLanguageType());
        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA,
                PkgAddrReq.getSessionHead(protocolCode), pkgAddrReq.beanToByte());
    }

    private void queryConfigSwitch() {
        queryCommonRequest(EsNativeProtocol.CMD_PKG_CONFIG_SWITCH_REQ);
    }

    private void queryPhoneStartInfo() {
        PkgPhoneStartReq pkgPhoneStartReq = new PkgPhoneStartReq();
        pkgPhoneStartReq.setLangType(EsBaseApi.getInstance().getLanguageType());
        pkgPhoneStartReq.setTerminalOSType(EsNativeProtocol.PkgAndroid);
        pkgPhoneStartReq.setScreenWidth(EsBaseApi.getInstance().getSystemWidth());
        pkgPhoneStartReq.setScreenHeight(EsBaseApi.getInstance().getSystemHeight());
        pkgPhoneStartReq.setPackageNo(UnixJNI.S_GetPackageNo());
        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA,
                PkgAddrReq.getSessionHead(EsNativeProtocol.CMD_PKG_PHONE_START_INFO_REQ), pkgPhoneStartReq.beanToByte());
    }

    private void queryOpenCompanyInfo() {
        PkgCompanyOpenReq req = new PkgCompanyOpenReq();
        req.setLangType(EsBaseApi.getInstance().getLanguageType());
        req.setTerminalOSType(EsNativeProtocol.PkgAndroid);
        req.setPackageNo(UnixJNI.S_GetPackageNo());
        req.setLicenseNo(EsNativeProtocol.LICENSE_NO);
        req.setOpenCompanyType('A');
        req.setProtocolVer((char) 5);
        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA,
                CspSessionHead.getCspSessionHead(EsNativeProtocol.CMD_PKG_COMPANY_OPEN_ACCOUNT_INFO_REQ,
                        EsNativeProtocol.CSP_SUBSYSTEM_PKGMGR, PkgCompanyOpenReq.STRUCT_LENGTH), req.beanToByte());
    }

    private void onQuoteAddr(byte[] data, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        List<Address> quoteAddrList = new ArrayList<>();
        List<Address> hisQuoteAddrList = new ArrayList<>();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);

            PkgQuoteAddrRsp rsp = PkgQuoteAddrRsp.toParse(struct);

            Address info = new Address(rsp.getIP(), rsp.getPort());
            if (rsp.getQuoteType() == PkgQuoteAddrRsp.PKG_REAL_TIME_QUOTE) {
                quoteAddrList.add(info);
            } else {
                hisQuoteAddrList.add(info);
            }
        }

        EsApiData.getInstance().setQuoteAddress(quoteAddrList);
        EsApiData.getInstance().setHisQuoteAddress(hisQuoteAddrList);
    }

    private void onCloudCompany(byte[] data, CspSessionHead head){
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, PkgCompanyAddrRsp> tradeCompany = EsApiData.getInstance().getTradeCompanyMap();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);

            PkgCompanyAddrRsp rsp = PkgCompanyAddrRsp.toParse(struct);

            tradeCompany.put(String.format("%s_%s", rsp.getCompanyNo(), rsp.getTradeAddrNo()), rsp);
        }
//        EsApiData.getInstance().setTradeCompany(tradeCompany);
    }

    private void onCloudTradeAddr(byte[] data, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, PkgCloudAddrRsp>  tradeAddress = EsApiData.getInstance().getCloudTradeAddress();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);

            PkgCloudAddrRsp rsp = PkgCloudAddrRsp.toParse(struct);

            if (rsp == null) {
                continue;
            }

            tradeAddress.put(rsp.getTradeAddrNo(), rsp);
        }
    }

    private void OnCompanyAddrMap(byte[] data, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, PkgCompanyCloudMapRsp> map = EsApiData.getInstance().getCompanyAddrMap();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);

            ParseUtil parseUtil = ParseUtil.wrap(struct);

            String companyNo = parseUtil.getString(11);
            String cloudAddrNo = parseUtil.getString(21);
            String tradeAddrNo = parseUtil.getString(21);

            PkgCompanyCloudMapRsp rsp = new PkgCompanyCloudMapRsp();
            rsp.setCompanyNo(companyNo);
            rsp.setCloudTradeAddrNo(cloudAddrNo);
            rsp.setTradeAddrNo(tradeAddrNo);

            String key = String.format("%s_%s", companyNo, tradeAddrNo);
            map.put(key, rsp);
        }

//        EsApiData.getInstance().setTradeCompanyAddressMap(map);
    }

    private void onPlateInfo(byte[] data, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();
        List<PkgPlateRsp> list = EsApiData.getInstance().getPlateRspList();
        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);

            PkgPlateRsp pkgPlateRsp = new PkgPlateRsp(struct);
            if (!list.contains(pkgPlateRsp)) {
                list.add(pkgPlateRsp);
            }
        }

    }

    private void onPlateCodeInfo(byte[] data, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        List<PkgPlateCodeRsp> set= EsApiData.getInstance().getPlateCodeRspList();
        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);
            PkgPlateCodeRsp rsp = new PkgPlateCodeRsp(struct);

            set.add(rsp);
        }
    }

    private void onCodeForbidRsp(byte[] data, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        StringBuilder builder = new StringBuilder(len*count);
        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);
            ParseUtil parseUtil = ParseUtil.wrap(struct);

            builder.append("--");
            builder.append(parseUtil.getString(len));
        }

        EsApiData.getInstance().setCodeForbidString(builder);
    }

    private void onConfigSwitchInfo(byte[] data, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Map<String, Integer> map = new HashMap<>(count * 2);
        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);
            ParseUtil parseUtil = ParseUtil.wrap(struct);

            String key = parseUtil.getString(51);
            int value = parseUtil.getUnsignedShort();

            map.put(key, value);
        }

        EsApiData.getInstance().setConfigSwitchMap(map);
    }

    private void onPhoneStartInfo(byte[] data, CspSessionHead head) {
        PkgPhoneStartRsp rsp = new PkgPhoneStartRsp(data);

        EsApiData.getInstance().setPhoneStartRsp(rsp);
    }

    private void onCompanyOpenRsp(byte[] data, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        List<PkgCompanyOpenRsp> list = new ArrayList<>(count);
        byte[] struct = new byte[len];
        for (int i = 0; i < count && (data.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(data, start, struct, 0, len);
            PkgCompanyOpenRsp rsp = new PkgCompanyOpenRsp(struct);
            list.add(rsp);
        }

        EsApiData.getInstance().setCompanyOpenList(list);
    }

    private void startQuote() {
        SimpleRunnable simpleRunnable = new SimpleRunnable() {
            @Override
            public void run() {
                // TODO ？ 子线程中开辟了子线程进行操作，然后连接依旧在主线程
                EsBaseApi.getInstance().startUpQuote();
                EsBaseApi.getInstance().startUpHisQuote();
            }
        };

        TaskManager.getInstance().execute(simpleRunnable);
    }
}
