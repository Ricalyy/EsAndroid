package com.esunny.data.api.util;

import android.content.Context;

import com.esunny.data.R;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.bean.Contract;
import com.esunny.data.util.EsSPHelperProxy;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class EstarTransformation {

    //买卖方向转换成多空的字符串
    public static String Direct2LongShortString(Context context, char direct) {
        if (direct == EsDataConstant.S_DIRECT_BOTH) {
            return context.getString(R.string.es_baseapi_trademethods_direct_both);
        } else if (direct == EsDataConstant.S_DIRECT_BUY) {
            return context.getString(R.string.es_baseapi_trademethods_direct_long);
        } else if (direct == EsDataConstant.S_DIRECT_SELL) {
            return context.getString(R.string.es_baseapi_trademethods_direct_short);
        }
        return "";
    }

    //买卖方向转换成买卖的字符串
    public static String Direct2BuySellString(Context context, char direct) {
        if (direct == EsDataConstant.S_DIRECT_BOTH) {
            return context.getString(R.string.es_baseapi_trademethods_direct_both);
        } else if (direct == EsDataConstant.S_DIRECT_BUY) {
            return context.getString(R.string.es_baseapi_trademethods_direct_buy);
        } else if (direct == EsDataConstant.S_DIRECT_SELL) {
            return context.getString(R.string.es_baseapi_trademethods_direct_sell);
        }
        return "";
    }

    //投保字段转换成投保字符串
    public static String Hedge2String(Context context, char hedge, String contractNo) {
        if (hedge == EsDataConstant.S_HEDGE_SPECULATE) {
            if (contractNo != null && EsDataApi.isCFFEXPlate(contractNo)) {
                return context.getString(R.string.es_baseapi_trademethods_hedge_trade);
            } else {
                return context.getString(R.string.es_baseapi_trademethods_hedge_speculate);
            }
        } else if (hedge == EsDataConstant.S_HEDGE_HEDGE) {
            return context.getString(R.string.es_baseapi_trademethods_hedge_hedge);
        } else if (hedge == EsDataConstant.S_HEDGE_SPREAD) {
            return context.getString(R.string.es_baseapi_trademethods_hedge_spread);
        } else if (hedge == EsDataConstant.S_HEDGE_MARKET) {
            return context.getString(R.string.es_baseapi_trademethods_hedge_market);
        } else if (hedge == EsDataConstant.S_HEDGE_COVER) {
            return context.getString(R.string.es_baseapi_trademethods_hedge_cover);
        }
        return "";
    }

    //开平字段转换成开平字符串
    public static String Offset2String(Context context, char offset) {
        if (offset == EsDataConstant.S_OFFSET_OPEN) {
            return context.getString(R.string.es_baseapi_trademethods_offset_open);
        } else if (offset == EsDataConstant.S_OFFSET_COVER) {
            return context.getString(R.string.es_baseapi_trademethods_offset_cover);
        } else if (offset == EsDataConstant.S_OFFSET_COVERT) {
            return context.getString(R.string.es_baseapi_trademethods_offset_covert);
        } else if (offset == EsDataConstant.S_OFFSET_COVEROPEN) {
            return context.getString(R.string.es_baseapi_trademethods_offset_coveropen);
        } else if (offset == EsDataConstant.S_OFFSET_OPENCOVER) {
            return context.getString(R.string.es_baseapi_trademethods_offset_opencover);
        }
        return "";
    }

    //订单状态转换成字符串
    public static String OrderState2String(Context context, char state, char type) {
        if (context == null) {
            return "";
        }
        switch (state) {
            case EsDataConstant.S_ORDERSTATE_SENDED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_sended);
            case EsDataConstant.S_ORDERSTATE_ACCEPT:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_accept);
            case EsDataConstant.S_ORDERSTATE_TRIGGERING:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_triggering);
            case EsDataConstant.S_ORDERSTATE_ACTIVE:
                if (type == EsDataConstant.S_ORDERTYPE_STOCK_LOCK) {
                    return context.getString(R.string.es_baseapi_trademethods_orderstate_locked);
                } else if (type == EsDataConstant.S_ORDERTYPE_STOCK_UNLOCK) {
                    return context.getString(R.string.es_baseapi_trademethods_orderstate_unlocked);
                }
                return context.getString(R.string.es_baseapi_trademethods_orderstate_active);
            case EsDataConstant.S_ORDERSTATE_QUEUED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_queued);
            case EsDataConstant.S_ORDERSTATE_PARTFILLED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_partfilled);
            case EsDataConstant.S_ORDERSTATE_FILLED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_filled);
            case EsDataConstant.S_ORDERSTATE_CANCELING:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_canceling);
            case EsDataConstant.S_ORDERSTATE_MODIFYING:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_modifying);
            case EsDataConstant.S_ORDERSTATE_CANCELED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_canceled);
            case EsDataConstant.S_ORDERSTATE_PARTCANCELED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_partcanceled);
            case EsDataConstant.S_ORDERSTATE_FAIL:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_fail);
            case EsDataConstant.S_ORDERSTATE_CHECKING:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_checking);
            case EsDataConstant.S_ORDERSTATE_SUSPENDED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_suspended);
            case EsDataConstant.S_ORDERSTATE_APPLY:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_apply);
            case EsDataConstant.S_ORDERSTATE_INVALID:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_invalid);
            case EsDataConstant.S_ORDERSTATE_PARTTRIGGERED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_parttriggered);
            case EsDataConstant.S_ORDERSTATE_FILLTRIGGERED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_filltriggered);
            case EsDataConstant.S_ORDERSTATE_PARTFAILED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_partfailed);
            case EsDataConstant.S_ORDERSTATE_PAIRED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_paired);
            case EsDataConstant.S_ORDERSTATE_PAIRING:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_pairing);
            case EsDataConstant.S_ORDERSTATE_UNPAIRED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_unpaired);
            case EsDataConstant.S_ORDERSTATE_TRIGGERFAILED:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_trigger_fail);
            case EsDataConstant.S_ORDERSTATE_OPENSTOPLOSS:
            case EsDataConstant.S_ORDERSTATE_STOPLOSS:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_accept);
            // 测试说不受监控状态就显示已受理吧
            default:
                return context.getString(R.string.es_baseapi_trademethods_orderstate_orderstate_fail);
        }
    }

    //订单类型（条件单与普通单）转换成字符串
    public static String OrderType2String(Context context, char type) {
        switch (type) {
            case 'C':
                return context.getString(R.string.es_type_condition_order);
            case 'N':
                return context.getString(R.string.es_type_common_order);
            default:
                return context.getString(R.string.es_type_common_order);
        }
    }

    /**
     * @param context 上下文
     * @param type    条件单类型
     * @return 条件单类型对应的字符串
     * @author Peter 2018/02/26
     */
    public static String StrategyType2String(Context context, char type) {
        String orderTypeStr = "";
        if (type == EsDataConstant.S_ST_PREORDER) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_preorder);
        } else if (type == EsDataConstant.S_ST_AUTOORDER) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_autoorder);
        } else if (type == EsDataConstant.S_ST_CONDITION) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_conditionorder);
        } else if (type == EsDataConstant.S_ST_STOPLOSS) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_stoplossorder);
        } else if (type == EsDataConstant.S_ST_STOPPROFIT) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_stopprofitorder);
        } else if (type == EsDataConstant.S_ST_FLOATSTOPLOSS) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_floatstoplossorder);
        } else if (type == EsDataConstant.S_ST_BREAKEVEN) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_brakevenorder);
        } else if (type == EsDataConstant.S_ST_OPEN_STOPLOSS) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_open_stoplossorder);
        } else if (type == EsDataConstant.S_ST_OPEN_STOPPROFIT) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_open_stopprofitorder);
        } else if (type == EsDataConstant.S_ST_OPEN_STOP_LOSS_SFLOAT) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_open_floatstoplossorder);
        } else if (type == EsDataConstant.S_ST_OPEN_BREAKEVEN) {
            orderTypeStr = context.getString(R.string.es_baseapi_trademethods_ordertype_open_brakevenorder);
        }
        return orderTypeStr;
    }

    //消息级别字符串转化
    public static String MessageLevelType2String(Context context, char level) {
        switch (level) {
            case EsDataConstant.S_ML_Info:
                return context.getString(R.string.es_baseapi_message_level_type_info);
            case EsDataConstant.S_ML_Warning:
                return context.getString(R.string.es_baseapi_message_level_type_warning);
            case EsDataConstant.S_ML_Error:
                return context.getString(R.string.es_baseapi_message_level_type_error);
            case EsDataConstant.S_ML_Vital:
                return context.getString(R.string.es_baseapi_message_level_type_vital);
            case EsDataConstant.S_ML_Urgent:
                return context.getString(R.string.es_baseapi_message_level_type_Urgen);
            default:
                break;
        }
        return "";
    }

    /**
     * 条件单价格比较到string的转换
     *
     * @param compareType EsDataConstant里的比较字段
     * @return 字符串，没找到为空字符
     */
    public static String conditionCompareType2Str(char compareType) {
        String compareTypeStr = "";
        if (EsDataConstant.S_TC_GREATER == compareType) {
            compareTypeStr = ">";
        } else if (EsDataConstant.S_TC_GREATEREQUAL == compareType) {
            compareTypeStr = ">=";
        } else if (EsDataConstant.S_TC_LESS == compareType) {
            compareTypeStr = "<";
        } else if (EsDataConstant.S_TC_LESSEQUAL == compareType) {
            compareTypeStr = "<=";
        }
        return compareTypeStr;
    }

    /**
     * 条件单触发模式到字符串转换
     *
     * @param context     上下文
     * @param triggerMode 最新价买价卖价
     * @return 字符串，没找到为空字符
     */
    public static String triggerModeType2Str(Context context, char triggerMode) {
        String triggerModeStr = "";
        if (EsDataConstant.S_TM_LATEST == triggerMode) {
            triggerModeStr = context.getString(R.string.es_util_activity_default_price_type_choosing_item_last_price);
        } else if (EsDataConstant.S_TM_ASK == triggerMode) {
            triggerModeStr = context.getString(R.string.es_util_activity_sell_price);
        } else if (EsDataConstant.S_TM_BID == triggerMode) {
            triggerModeStr = context.getString(R.string.es_util_activity_buy_price);
        }
        return triggerModeStr;
    }

    /**
     * 止损价格类型到字符串转换
     *
     * @param context
     * @param stopPriceType
     * @return
     */
    public static String stopPriceType2Str(Context context, char stopPriceType) {
        String stopPriceTypeStr = "";
        if (EsDataConstant.S_SPT_PRICE == stopPriceType) {
            stopPriceTypeStr = context.getString(R.string.es_util_activity_price_str);
        } else if (EsDataConstant.S_SPT_DIFF == stopPriceType) {
            stopPriceTypeStr = context.getString(R.string.es_util_activity_price_diff_str);
        }
        return stopPriceTypeStr;
    }

    //有效类型转换字符串
    public static String conditionValidType2Str(Context context, char conditionValidType) {
        String conditionValidTypeStr = "";
        if (EsDataConstant.S_VALIDTYPE_GFD == conditionValidType) {
            conditionValidTypeStr = context.getString(R.string.es_util_field_trans_today);
        } else if (EsDataConstant.S_VALIDTYPE_GTC == conditionValidType) {
            conditionValidTypeStr = context.getString(R.string.es_util_field_trans_long);
        } else if (EsDataConstant.S_VALIDTYPE_FOK == conditionValidType) {
            conditionValidTypeStr = context.getString(R.string.es_util_field_trans_all);
        } else if (EsDataConstant.S_VALIDTYPE_IOC == conditionValidType) {
            conditionValidTypeStr = context.getString(R.string.es_util_field_trans_part);
        }

        return conditionValidTypeStr;
    }

    //委托价来源转换字符串
    public static String delegateWayToStr(Context context, char way) {
        String priceTypeStr = "";

        if (way == EsDataConstant.S_ORDERWAY_PROXYETRADE || way == EsDataConstant.S_ORDERWAY_PROXY_DRAWLINE) {
            priceTypeStr = context.getString(R.string.es_trade_condition_delegate_way_computer);
        } else {
            priceTypeStr = context.getString(R.string.es_trade_condition_delegate_way_mobile);
        }
        return priceTypeStr;
    }

    //委托价类型转换字符串
    public static String apiPriceTypeToStr(Context context, int priceType) {
        String priceTypeStr = "";
        if (priceType == EsDataConstant.S_PT_ABS) {
            priceTypeStr = context.getString(R.string.es_util_activity_default_price_type_choosing_item_abs_price);
        } else if (priceType == EsDataConstant.S_PT_LSAT) {
            priceTypeStr = context.getString(R.string.es_util_activity_default_price_type_choosing_item_last_price);
        } else if (priceType == EsDataConstant.S_PT_QUEUE) {
            priceTypeStr = context.getString(R.string.es_util_activity_default_price_type_choosing_item_queue_price);
        } else if (priceType == EsDataConstant.S_PT_MARKET) {
            priceTypeStr = context.getString(R.string.es_util_activity_default_price_type_choosing_item_market_price);
        } else if (priceType == EsDataConstant.S_PT_MATCH) {
            priceTypeStr = context.getString(R.string.es_util_activity_default_price_type_choosing_item_counter_price);
        }
        return priceTypeStr;
    }

    //订单类型转换字符串
    public static String convertOrderType2String(Context context, char type) {
        if (context == null) {
            return "";
        }
        switch (type) {
            case EsDataConstant.S_ORDERTYPE_MARKET:
                return context.getString(R.string.es_trade_item_trade_market_order);
            case EsDataConstant.S_ORDERTYPE_LIMIT:
                return context.getString(R.string.es_trade_item_trade_limit_order);
            case EsDataConstant.S_ORDERTYPE_MARKETSTOP:
                return context.getString(R.string.es_trade_item_trade_market_stop_order);
            case EsDataConstant.S_ORDERTYPE_LIMITSTOP:
                return context.getString(R.string.es_trade_item_trade_limit_stop_order);
            case EsDataConstant.S_ORDERTYPE_EXECUTE:
                return context.getString(R.string.es_trade_item_trade_execute_order);
            case EsDataConstant.S_ORDERTYPE_ABANDON:
                return context.getString(R.string.es_trade_item_trade_abandon_order);
            case EsDataConstant.S_ORDERTYPE_ENQUIRY:
                return context.getString(R.string.es_trade_item_trade_enquiry_order);
            case EsDataConstant.S_ORDERTYPE_OFFER:
                return context.getString(R.string.es_trade_item_trade_offer_order);
            case EsDataConstant.S_ORDERTYPE_ICEBERG:
                return context.getString(R.string.es_trade_item_trade_iceberg_order);
            case EsDataConstant.S_ORDERTYPE_GHOST:
                return context.getString(R.string.es_trade_item_trade_ghost_order);
            case EsDataConstant.S_ORDERTYPE_SWAP:
                return context.getString(R.string.es_trade_item_trade_swap_order);
            case EsDataConstant.S_ORDERTYPE_SPREADAPPLY:
                return context.getString(R.string.es_trade_item_trade_spread_apply_order);
            case EsDataConstant.S_ORDERTYPE_HEDGEAPPLY:
                return context.getString(R.string.es_trade_item_trade_hedge_apply_order);
            case EsDataConstant.S_ORDERTYPE_OPTIONAUTOCLOSE:
                return context.getString(R.string.es_trade_item_trade_option_auto_close_order);
            case EsDataConstant.S_ORDERTYPE_FUTUREAUTOCLOSE:
                return context.getString(R.string.es_trade_item_trade_future_auto_close_order);
            case EsDataConstant.S_ORDERTYPE_STOCK_LOCK:
                return context.getString(R.string.es_trade_item_trade_stock_lock_order);
            case EsDataConstant.S_ORDERTYPE_STOCK_UNLOCK:
                return context.getString(R.string.es_trade_item_trade_stock_unlock_order);
            default:
                return "";
        }
    }

    //有效类型转换字符串
    public static String convertValideType2String(Context context, char type) {
        if (context == null) {
            return "";
        }
        // bug#4900 有效类型只有“长期有效”、“当日有效”
        switch (type) {
            case EsDataConstant.S_VALIDTYPE_GTC:
                return context.getString(R.string.es_util_field_long_valide);
            default:
                return context.getString(R.string.es_util_field_today_valide);
        }
    }

    //转账状态转换字符串
    public static String bankTransferStautsToStr(Context context, char status) {
        String transferStatusStr = "";
        if (status == EsDataConstant.S_TS_Transed) {
            transferStatusStr = context.getString(R.string.es_activity_bank_transfer_successful_status);
        } else if (status == EsDataConstant.S_TS_Send) {
            transferStatusStr = context.getString(R.string.es_activity_bank_transfer_send_status);
        } else if (status == EsDataConstant.S_TS_Transing) {
            transferStatusStr = context.getString(R.string.es_activity_bank_transfer_transing_status);
        } else if (status == EsDataConstant.S_TS_TransFail) {
            transferStatusStr = context.getString(R.string.es_activity_bank_transfer_transfail_status);
        } else if (status == EsDataConstant.S_TS_Reversing) {
            transferStatusStr = context.getString(R.string.es_activity_bank_transfer_reversing_status);
        } else if (status == EsDataConstant.S_TS_Reversed) {
            transferStatusStr = context.getString(R.string.es_activity_bank_transfer_reversed_status);
        } else if (status == EsDataConstant.S_TS_ReversFail) {
            transferStatusStr = context.getString(R.string.es_activity_bank_transfer_reversfail_status);
        }
        return transferStatusStr;
    }

    //转账状态转换字符串
    public static String bankTransferDirectToStr(Context context, char direct) {
        String transferDirectStr = "";
        if (direct == EsDataConstant.S_TD_ToBank) {
            transferDirectStr = context.getString(R.string.es_activity_bank_transfer_futures_to_bank_full);
        } else if (direct == EsDataConstant.S_TD_ToFutures) {
            transferDirectStr = context.getString(R.string.es_activity_bank_transfer_bank_to_futures_full);
        }
        return transferDirectStr;
    }

    //二次认证方式转换字符串
    public static String secondaryConfirmTypeToStr(Context context, char type) {
        String confirmType = "";
        if (type == EsDataConstant.S_SENDTYPE_SMS) {
            confirmType = context.getString(R.string.es_data_login_sms_dialog_phone);
        } else if (type == EsDataConstant.S_SENDTYPE_MAIL) {
            confirmType = context.getString(R.string.es_data_login_sms_dialog_mail);
        } else if (type == EsDataConstant.S_SENDTYPE_WEIXIN) {
            confirmType = context.getString(R.string.es_data_login_sms_dialog_wechat);
        }
        return confirmType;
    }

    //价格预警的原因和值转换字符串
    public static String convertPriceMonitorReachToStr(Context context, Contract contract, String reason, String value) {
        if (context == null) {
            return "";
        }

        boolean IsRange = false;
        char[] type = reason.toCharArray();

        String reachToStr = "";
        if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_MAX1) {
            reachToStr = context.getString(R.string.es_price_warn_dialog_price_highest);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_MAX2) {
            reachToStr = context.getString(R.string.es_price_warn_dialog_price_highest);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_MIN1) {
            reachToStr = context.getString(R.string.es_price_warn_dialog_price_lowesrt);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_MIN2) {
            reachToStr = context.getString(R.string.es_price_warn_dialog_price_lowesrt);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_GROWTH_WIDTH_MAX) {
            IsRange = true;
            reachToStr = context.getString(R.string.es_price_warn_notification_price_increase_up);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_GROWTH_WIDTH_MIN) {
            IsRange = true;
            reachToStr = context.getString(R.string.es_price_warn_notification_price_increase_down);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_GROWTH_SPEED_MAX) {
            reachToStr = context.getString(R.string.es_price_warn_notification_price_speed_up);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_GROWTH_SPEED_MIN) {
            reachToStr = context.getString(R.string.es_price_warn_notification_price_speed_down);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_LAST_VOL) {
            reachToStr = context.getString(R.string.es_price_warn_notification_price_last_vol);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_VOLUME) {
            reachToStr = context.getString(R.string.es_price_warn_notification_price_volume);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_POSITION_MAX) {
            reachToStr = context.getString(R.string.es_price_warn_notification_price_position_up);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_POSITION_MIN) {
            reachToStr = context.getString(R.string.es_price_warn_notification_price_position_down);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_LIMIT_UP) {
            reachToStr = context.getString(R.string.es_price_warn_notification_price_limit_up);
        } else if (type[0] == EsDataConstant.S_PRICE_MONITOR_PRICE_LIMIT_DOWN) {
            reachToStr = context.getString(R.string.es_price_warn_notification_price_limit_down);
        }


        if (IsRange) {
            return reachToStr + ":" + value + "%";
        } else {
            if (contract == null) {
                return reachToStr + ":" + value;
            } else {
                if (contract.getCommodity().getPriceDeno() > 1) {
                    return reachToStr + ":" + value;
                } else {
                    return reachToStr + ":" + EsDataApi.formatPrice(contract.getCommodity(), Double.parseDouble(value));
                }
            }
        }

    }

    // 行情字体大小值转换字符串
    public static String quoteTextSizeToStr(Context context, int type) {
        String textStr = "";
        switch (type){
            case EsSPHelperProxy.QUOTE_TEXT_SIZE_XL:
                textStr = context.getString(R.string.es_system_setting_activity_switch_text_size_xl);
                break;
            case EsSPHelperProxy.QUOTE_TEXT_SIZE_L:
                textStr = context.getString(R.string.es_system_setting_activity_switch_text_size_l);
                break;
            case EsSPHelperProxy.QUOTE_TEXT_SIZE_M:
                textStr = context.getString(R.string.es_system_setting_activity_switch_text_size_m);
                break;
            case EsSPHelperProxy.QUOTE_TEXT_SIZE_S:
                textStr = context.getString(R.string.es_system_setting_activity_switch_text_size_s);
                break;
        }
        return textStr;

    }

    // 涨跌计算值转换字符串
    public static String priceCalculateTypeToStr(Context context, int type) {
        String textStr = "";
        switch (type){
            case EsSPHelperProxy.PRE_SETTLE_PRICE:
                textStr = context.getString(R.string.es_system_setting_activity_settle_price_yesterday);
                break;
            case EsSPHelperProxy.PRE_CLOSING_PRICE:
                textStr = context.getString(R.string.es_system_setting_activity_closing_price_yesterday);
                break;
            case EsSPHelperProxy.TODAY_OPEN_PRICE:
                textStr = context.getString(R.string.es_system_setting_activity_open_price_today);
                break;
        }
        return textStr;

    }


    //委托价来源转换字符串
    public static String contractTypeToStr(Context context, char type) {
        String contractTypeStr = "";
        switch (type){
            case EsDataConstant.QTE_COMM_TYPE_SPOT:
            case EsDataConstant.QTE_COMM_TYPE_SPOT_T:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_spot);
                break;
            case EsDataConstant.QTE_COMM_TYPE_FUTURES:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_future);
                break;
            case EsDataConstant.QTE_COMM_TYPE_OPTION:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_option);
                break;
            case EsDataConstant.QTE_COMM_TYPE_SPREADS:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_spreads);
                break;
            case EsDataConstant.QTE_COMM_TYPE_SPREADM:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_spreadm);
                break;
            case EsDataConstant.QTE_COMM_TYPE_INDEX:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_index);
                break;
            case EsDataConstant.QTE_COMM_TYPE_STOCK:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_stock);
                break;
            case EsDataConstant.QTE_COMM_TYPE_OTCOPTION:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_otc_option);
                break;
            case EsDataConstant.QTE_COMM_TYPE_EFP:
                contractTypeStr = context.getString(R.string.es_trade_contract_type_epf);
                break;
            default:
                break;
        }
        return contractTypeStr;
    }
}
