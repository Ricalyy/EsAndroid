package com.esunny.data.database;

/**
 * @author Peter Fu
 * @date 2020/10/13
 */
import android.content.Context;

import com.esunny.data.api.EsBaseApi;
import com.esunny.data.database.gen.DaoSession;
import com.esunny.data.database.gen.DaoMaster;

public class DBManager{
    private static DBManager INSTANCE;
//    private IDatabase userInfoDatabase;
//    private IDatabase addressDatabase;
    private IDatabase esunnyDatabase;

    private DBManager(){
        Context context = EsBaseApi.getInstance().getContext();
        init(context);
    }


    public static DBManager getInstance(){
        if (null == INSTANCE){
            synchronized (DBManager.class){
                if (null == INSTANCE){
                    INSTANCE = new DBManager();
                }
            }
        }
        return INSTANCE;
    }

    private void init(Context context) {
        esunnyDatabase = new EsunnyDatabase(context);
    }

    public DaoSession getDaoSession() {
        return esunnyDatabase.getDaoSession();
    }

    public DaoMaster getDaoMaster() {
        return esunnyDatabase.getDaoMaster();
    }

}
