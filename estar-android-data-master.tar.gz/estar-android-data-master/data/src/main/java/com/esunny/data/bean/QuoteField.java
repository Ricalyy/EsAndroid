package com.esunny.data.bean;

import java.math.BigInteger;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class QuoteField {
    private double                                  Price;
    private java.math.BigInteger                    Qty;

    private boolean                                 isImpliedPrice;
    private boolean                                 isImpliedQty;

    public double getPrice() {
        return Price;
    }

    public void setPrice(double price) {
        Price = price;
    }

    public BigInteger getQty() {
        return Qty;
    }

    public void setQty(BigInteger qty) {
        Qty = qty;
    }

    public boolean isImpliedPrice() {
        return isImpliedPrice;
    }

    public void setImpliedPrice(boolean impliedPrice) {
        isImpliedPrice = impliedPrice;
    }

    public boolean isImpliedQty() {
        return isImpliedQty;
    }

    public void setImpliedQty(boolean impliedQty) {
        isImpliedQty = impliedQty;
    }
}
