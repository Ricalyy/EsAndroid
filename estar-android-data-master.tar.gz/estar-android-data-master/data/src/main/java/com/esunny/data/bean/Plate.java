package com.esunny.data.bean;

import com.esunny.data.api.EsDataApi;

public class Plate {

    private String PlateNo;
    private String PlateName;
    private String ParentPlateNo;
    private String PlateCode;
    private char   PlateCodeAttr;

    public String getPlateNo() {
        return PlateNo;
    }

    public void setPlateNo(String plateNo) {
        PlateNo = plateNo;
    }

    public String getPlateName() {
        return PlateName;
    }

    public void setPlateName(String plateName) {
        PlateName = plateName;
    }

    public String getParentPlateNo() {
        return ParentPlateNo;
    }

    public void setParentPlateNo(String parentPlateNo) {
        ParentPlateNo = parentPlateNo;
    }

    public boolean isFirstPlate() {
        return "".equals(getParentPlateNo());
    }

    public String getPlateCode() {
        return PlateCode;
    }

    public void setPlateCode(String plateCode) {
        PlateCode = plateCode;
    }

    public char getPlateCodeAttr() {
        return PlateCodeAttr;
    }

    public void setPlateCodeAttr(char plateCodeAttr) {
        PlateCodeAttr = plateCodeAttr;
    }

    @Override
    public String toString() {
        return String.format("PlateNo = %s, PlateName = %s, ParentPlateNo = %s", PlateNo, PlateName, ParentPlateNo);
    }


    public boolean isOptionPlate() {
        return EsDataApi.isOptionPlate(PlateNo);
    }
}
