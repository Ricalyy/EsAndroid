package com.esunny.data.bean;

import com.esunny.data.api.EsDataConstant;

/**
 * @author Peter Fu
 * @date 2020/9/29
 */
public class MonitorOrderInsert {

    public MonitorOrderInsert() {
        PriceMax1 = EsDataConstant.S_PRICE_NOT_MONITOR;
        PriceMin1 = EsDataConstant.S_PRICE_NOT_MONITOR;
        GrowthWidthMax = EsDataConstant.S_PRICE_NOT_MONITOR;
        GrowthWidthMin = EsDataConstant.S_PRICE_NOT_MONITOR;

        MonitorNum = 'O';
    }

    private String                                      ContractNo;     //监控合约
    //====================监控指标=======================//
    private double						                      PriceMax1;	//价格上限1
    private double                                            PriceMax2;	//价格上限2
    private double						                      PriceMin1;	//价格下限1
    private double                                            PriceMin2;	//价格下限2

    private double						                      GrowthWidthMax; //涨幅上限
    private double                                            GrowthWidthMin;	//涨幅下限
    private double						                      GrowthSpeedMax; //速涨上限
    private double                                            GrowthSpeedMin;	//速涨下限

    private char                                               MonitorNum;

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public double getPriceMax1() {
        return PriceMax1;
    }

    public void setPriceMax1(double priceMax1) {
        PriceMax1 = priceMax1;
    }

    public double getPriceMin1() {
        return PriceMin1;
    }

    public void setPriceMin1(double priceMin1) {
        PriceMin1 = priceMin1;
    }

    public double getGrowthWidthMax() {
        return GrowthWidthMax;
    }

    public void setGrowthWidthMax(double growthWidthMax) {
        GrowthWidthMax = growthWidthMax;
    }

    public double getGrowthWidthMin() {
        return GrowthWidthMin;
    }

    public void setGrowthWidthMin(double growthWidthMin) {
        GrowthWidthMin = growthWidthMin;
    }

    public char getMonitorNum() {
        return MonitorNum;
    }

    public void setMonitorNum(char monitorNum) {
        MonitorNum = monitorNum;
    }

    public double getPriceMax2() {
        return PriceMax2;
    }

    public void setPriceMax2(double priceMax2) {
        PriceMax2 = priceMax2;
    }

    public double getPriceMin2() {
        return PriceMin2;
    }

    public void setPriceMin2(double priceMin2) {
        PriceMin2 = priceMin2;
    }

    public double getGrowthSpeedMax() {
        return GrowthSpeedMax;
    }

    public void setGrowthSpeedMax(double growthSpeedMax) {
        GrowthSpeedMax = growthSpeedMax;
    }

    public double getGrowthSpeedMin() {
        return GrowthSpeedMin;
    }

    public void setGrowthSpeedMin(double growthSpeedMin) {
        GrowthSpeedMin = growthSpeedMin;
    }
}
