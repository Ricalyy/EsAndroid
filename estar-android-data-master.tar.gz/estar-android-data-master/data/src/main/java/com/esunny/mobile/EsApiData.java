package com.esunny.mobile;

import com.esunny.data.bean.PkgCompanyCloudMapRsp;
import com.esunny.data.bean.Plate;
import com.esunny.data.bean.Address;
import com.esunny.data.bean.SPushClientInfo;
import com.esunny.data.bean.SQuoteUserInfo;
import com.esunny.mobile.bean.rsp.PkgCloudAddrRsp;
import com.esunny.mobile.bean.rsp.PkgCompanyAddrRsp;
import com.esunny.mobile.bean.rsp.PkgCompanyOpenRsp;
import com.esunny.mobile.bean.rsp.PkgPhoneStartRsp;
import com.esunny.mobile.bean.rsp.PkgPlateCodeRsp;
import com.esunny.mobile.bean.rsp.PkgPlateRsp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EsApiData {

    private static final Address[] V1_ACCESS_ADDR_ARRAY = {
            new Address("122.51.51.243", 55001),
            new Address("49.234.36.124", 55001),
            new Address("106.54.250.26", 55001),
            new Address("152.136.91.140", 55001),
            new Address("210.176.173.34", 55001),
            new Address("188.131.234.20", 55001),
            new Address("119.28.15.59", 55001),
            new Address("140.143.70.16", 55001),
            new Address("193.112.81.61", 55001),
    };

    private List<Address> mQuoteAddressList;
    private List<Address> mHisQuoteAddressList;
    private final Map<String, PkgCompanyAddrRsp> mCompanyAddressMap = new HashMap<>(512);
    // G_CloudTradeAddr
    private final Map<String, PkgCloudAddrRsp> mCloudTradeAddrMap = new HashMap<>();
    private final Map<String, PkgCompanyCloudMapRsp> mCompanyAddrMap = new HashMap<>();
    private List<Plate> mPlateList;
    // 相当于原始数据的板块列表
    private final List<PkgPlateRsp> mPlateRspList = new ArrayList<>();
    // 相当于 PlateContent 数据
    private final List<PkgPlateCodeRsp> mPlateCodeRspList = new ArrayList<>(256);
    private StringBuilder mCodeForbidString;
    private Map<String, Integer> mConfigSwitchMap;
    private PkgPhoneStartRsp mPhoneStartRsp;
    private List<PkgCompanyOpenRsp> mCompanyOpenList;
    private int mIsReadyQuoteLogin = 0;  //用于判断初始化查询是否完毕
    private boolean mLoginState = false;

    // 行情登录的信息
    private SQuoteUserInfo mQuoteUserInfo = new SQuoteUserInfo();
    // 推送的信息
    private SPushClientInfo mPushClientInfo;

    private EsApiData() {

    }

    private static class SingletonClassInstance {
        private static final EsApiData INSTANCE = new EsApiData();
    }

    public static EsApiData getInstance() {
        return SingletonClassInstance.INSTANCE;
    }

    public Address[] getAccessAddresses() {
        return V1_ACCESS_ADDR_ARRAY;
    }

    public Address[] getQuoteAddress() {
        return mQuoteAddressList.toArray(new Address[0]);
    }

    public Address[] getHisQuoteAddress() {
        return mHisQuoteAddressList.toArray(new Address[0]);
    }

    public void setQuoteAddress(List<Address> address) {
        mQuoteAddressList = address;
    }

    public void setHisQuoteAddress(List<Address> address) {
        mHisQuoteAddressList = address;
    }

    public Map<String, PkgCompanyAddrRsp> getTradeCompanyMap() {
        return mCompanyAddressMap;
    }

    public Map<String, PkgCloudAddrRsp> getCloudTradeAddress() {
        return mCloudTradeAddrMap;
    }

    public Map<String, PkgCompanyCloudMapRsp> getCompanyAddrMap() {
        return mCompanyAddrMap;
    }

    public List<PkgPlateRsp> getPlateRspList() {
        return mPlateRspList;
    }

    public List<PkgPlateCodeRsp> getPlateCodeRspList() {
        return mPlateCodeRspList;
    }

//    public void setPlateCodeRspList(List<PkgPlateCodeRsp> plateCodeRspList) {
//        this.mPlateCodeRspList = plateCodeRspList;
//    }

    //    public void setPlateCodeRspMap(Map<String, PkgPlateCodeRsp> map) {
//        mPlateCodeRspMap = map;
//    }
//
//    public Map<String, PkgPlateCodeRsp> getPlateCodeRspMap() {
//        return mPlateCodeRspMap;
//    }

    public void setCodeForbidString(StringBuilder builder) {
        mCodeForbidString = builder;
    }

    public void setConfigSwitchMap(Map<String, Integer> map) {
        mConfigSwitchMap = map;
    }

    public void setPhoneStartRsp(PkgPhoneStartRsp rsp) {
        mPhoneStartRsp = rsp;
    }

    public void setCompanyOpenList(List<PkgCompanyOpenRsp> list) {
        mCompanyOpenList = list;
    }

    public List<Plate> getPlates() {
        if (mPlateList != null) {
            return mPlateList;
        }

//        if (mPlateCodeRspMap == null || mPlateRspList == null) {
//            return new ArrayList<>();
//        }

        mPlateList = new ArrayList<>(mPlateRspList.size());

        for (PkgPlateRsp rsp : mPlateRspList) {
            Plate plate = new Plate();
            plate.setPlateNo(rsp.getPlateNo());
            plate.setParentPlateNo(rsp.getParentPlateNo());
            plate.setPlateName(rsp.getPlateName());

//            PkgPlateCodeRsp codeRsp = mPlateCodeRspMap.get(rsp.getPlateNo());
//            if (codeRsp != null) {
//                plate.setPlateCode(codeRsp.getPlateCode());
//                plate.setPlateCodeAttr(codeRsp.getPlateCodeAttr());
//            }
            mPlateList.add(plate);
        }

        return mPlateList;
    }

    public boolean isForbidCode(String code) {
        return mCodeForbidString.indexOf(code) > 0;
    }

    public int getIsReadyQuoteLogin() {
        return mIsReadyQuoteLogin;
    }

    public void setIsReadyQuoteLogin(int mIsReadyQuoteLogin) {
        this.mIsReadyQuoteLogin = mIsReadyQuoteLogin;
    }

    public boolean getLoginState() {
        return mLoginState;
    }

    public void setLoginState(boolean mLoginState) {
        this.mLoginState = mLoginState;
    }

    public SQuoteUserInfo getQuoteUserInfo() {
        return mQuoteUserInfo;
    }

    public SPushClientInfo getPushClientInfo() {
        return mPushClientInfo;
    }

    public void setPushClientInfo(SPushClientInfo mPushClientInfo) {
        this.mPushClientInfo = mPushClientInfo;
    }
}
