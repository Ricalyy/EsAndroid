package com.esunny.data.database.table;

import android.text.TextUtils;

import com.esunny.data.bean.Commodity;

import org.greenrobot.greendao.annotation.Convert;
import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Property;
import org.greenrobot.greendao.converter.PropertyConverter;
import org.greenrobot.greendao.annotation.Generated;

/**
 * @author Peter Fu
 * @date 2020/10/13
 */

@Entity(nameInDb = "TCommodity")
public class TCommodity {
    @Id()
    @Property(nameInDb = "FCommodityId")
    private String CommodityId = "";        //品种编号
    @Property(nameInDb = "FExchangeNo")
    private String ExchangeNo = "";         //交易所代码,必填(管理终端控制)
    @Property(nameInDb = "FCurrencyNo")
    private String CurrencyNo = "";         //币种代码,必填(管理终端控制)
    @Property(nameInDb = "FCHSName")
    private String CHSName = "";            //简体中文名称
    @Property(nameInDb = "FCHTName")
    private String CHTName = "";            //繁体中文名称
    @Property(nameInDb = "FENUName")
    private String ENUName = "";            //英文名称
    @Property(nameInDb = "FCommodityDot")
    private double CommodityDot = 0.0;       //每手乘数
    @Property(nameInDb = "FOptionType")
    private String OptionType = "";           //期权类型
    @Property(nameInDb = "FSpreadDirect")
    private String SpreadDirect = "";         //组合方向
    @Property(nameInDb = "FExecuteWay")
    private String ExecuteWay = "";           //行权方式
    @Property(nameInDb = "FCoverMode")
    private String CoverMode = "";            //平仓模式
    @Property(nameInDb = "FPriceTick")
    private double PriceTick = 0.0;          //最小变动价
    @Property(nameInDb = "FPriceDeno")
    private int PriceDeno = 0;             //报价分母
    @Property(nameInDb = "FQuoteUnitName")
    private String QuoteUnitName = "";        //报价单位名称
    @Property(nameInDb = "FTradingUnitName")
    private String TradingUnitName = "";      //交易单位名称
    @Property(nameInDb = "FDepositGroupNo")
    private String DepositGroupNo = "";       //大边保证金组组号
    @Property(nameInDb = "FPriceMultiple")
    private float PriceMultiple = 0;        //执行价格倍数
    @Property(nameInDb = "FExecuteDot")
    private double ExecuteDot = 0.0;           //行权乘数
    @Property(nameInDb = "FMaxSingleOrderQty")
    private int MaxSingleOrderQty = 0;       //最大下单量
    @Property(nameInDb = "FMaxPositionQty")
    private int MaxPositionQty = 0;          //最大持仓量
    @Property(nameInDb = "FRCommodityId1")
    private String RCommodityId1 = "";        //依赖品种1
    @Property(nameInDb = "FRCommodityId2")
    private String RCommodityId2 = "";        //依赖品种2
    @Property(nameInDb = "FRCommodityId3")
    private String RCommodityId3 = "";        //依赖品种3
    @Property(nameInDb = "FRCommodityId4")
    private String RCommodityId4 = "";        //依赖品种4
    @Property(nameInDb = "FOperator1")
    private String Operator1 = "";              //运算符1
    @Property(nameInDb = "FOperator2")
    private String Operator2 = "";              //运算符2
    @Property(nameInDb = "FOperator3")
    private String Operator3 = "";              //运算符3
    @Property(nameInDb = "FPriceProp1")
    private double PriceProp1 = 0.0;           //价格配比1
    @Property(nameInDb = "FPriceProp2")
    private double PriceProp2 = 0.0;           //价格配比2
    @Property(nameInDb = "FPriceProp3")
    private double PriceProp3 = 0.0;           //价格配比3
    @Property(nameInDb = "FPriceProp4")
    private double PriceProp4 = 0.0;           //价格配比4
    @Property(nameInDb = "FQtyProp1")
    private int QtyProp1 = 0;                //数量配比1
    @Property(nameInDb = "FQtyProp2")
    private int QtyProp2 = 0;                //数量配比2
    @Property(nameInDb = "FQtyProp3")
    private int QtyProp3 = 0;                //数量配比3
    @Property(nameInDb = "FQtyProp4")
    private int QtyProp4 = 0;                //数量配比4
    @Property(nameInDb = "FUpdateId")
    private Long UpdateId = 0L;                // 更新的编号

    @Generated(hash = 1561826977)
    public TCommodity(String CommodityId, String ExchangeNo, String CurrencyNo,
            String CHSName, String CHTName, String ENUName, double CommodityDot,
            String OptionType, String SpreadDirect, String ExecuteWay,
            String CoverMode, double PriceTick, int PriceDeno, String QuoteUnitName,
            String TradingUnitName, String DepositGroupNo, float PriceMultiple,
            double ExecuteDot, int MaxSingleOrderQty, int MaxPositionQty,
            String RCommodityId1, String RCommodityId2, String RCommodityId3,
            String RCommodityId4, String Operator1, String Operator2,
            String Operator3, double PriceProp1, double PriceProp2,
            double PriceProp3, double PriceProp4, int QtyProp1, int QtyProp2,
            int QtyProp3, int QtyProp4, Long UpdateId) {
        this.CommodityId = CommodityId;
        this.ExchangeNo = ExchangeNo;
        this.CurrencyNo = CurrencyNo;
        this.CHSName = CHSName;
        this.CHTName = CHTName;
        this.ENUName = ENUName;
        this.CommodityDot = CommodityDot;
        this.OptionType = OptionType;
        this.SpreadDirect = SpreadDirect;
        this.ExecuteWay = ExecuteWay;
        this.CoverMode = CoverMode;
        this.PriceTick = PriceTick;
        this.PriceDeno = PriceDeno;
        this.QuoteUnitName = QuoteUnitName;
        this.TradingUnitName = TradingUnitName;
        this.DepositGroupNo = DepositGroupNo;
        this.PriceMultiple = PriceMultiple;
        this.ExecuteDot = ExecuteDot;
        this.MaxSingleOrderQty = MaxSingleOrderQty;
        this.MaxPositionQty = MaxPositionQty;
        this.RCommodityId1 = RCommodityId1;
        this.RCommodityId2 = RCommodityId2;
        this.RCommodityId3 = RCommodityId3;
        this.RCommodityId4 = RCommodityId4;
        this.Operator1 = Operator1;
        this.Operator2 = Operator2;
        this.Operator3 = Operator3;
        this.PriceProp1 = PriceProp1;
        this.PriceProp2 = PriceProp2;
        this.PriceProp3 = PriceProp3;
        this.PriceProp4 = PriceProp4;
        this.QtyProp1 = QtyProp1;
        this.QtyProp2 = QtyProp2;
        this.QtyProp3 = QtyProp3;
        this.QtyProp4 = QtyProp4;
        this.UpdateId = UpdateId;
    }

    @Generated(hash = 1652565484)
    public TCommodity() {
    }


    public String getCommodityId() {
        return CommodityId;
    }

    public void setCommodityId(String commodityId) {
        CommodityId = commodityId;
    }

    public String getExchangeNo() {
        return ExchangeNo;
    }

    public void setExchangeNo(String exchangeNo) {
        ExchangeNo = exchangeNo;
    }

    public String getCurrencyNo() {
        return CurrencyNo;
    }

    public void setCurrencyNo(String currencyNo) {
        CurrencyNo = currencyNo;
    }

    public String getCHSName() {
        return CHSName;
    }

    public void setCHSName(String CHSName) {
        this.CHSName = CHSName;
    }

    public String getCHTName() {
        return CHTName;
    }

    public void setCHTName(String CHTName) {
        this.CHTName = CHTName;
    }

    public String getENUName() {
        return ENUName;
    }

    public void setENUName(String ENUName) {
        this.ENUName = ENUName;
    }

    public double getCommodityDot() {
        return CommodityDot;
    }

    public void setCommodityDot(double commodityDot) {
        CommodityDot = commodityDot;
    }

    public String getOptionType() {
        return OptionType;
    }

    public void setOptionType(String optionType) {
        OptionType = optionType;
    }

    public String getSpreadDirect() {
        return SpreadDirect;
    }

    public void setSpreadDirect(String spreadDirect) {
        SpreadDirect = spreadDirect;
    }

    public String getExecuteWay() {
        return ExecuteWay;
    }

    public void setExecuteWay(String executeWay) {
        ExecuteWay = executeWay;
    }

    public String getCoverMode() {
        return CoverMode;
    }

    public void setCoverMode(String coverMode) {
        CoverMode = coverMode;
    }

    public double getPriceTick() {
        return PriceTick;
    }

    public void setPriceTick(double priceTick) {
        PriceTick = priceTick;
    }

    public int getPriceDeno() {
        return PriceDeno;
    }

    public void setPriceDeno(int priceDeno) {
        PriceDeno = priceDeno;
    }

    public String getQuoteUnitName() {
        return QuoteUnitName;
    }

    public void setQuoteUnitName(String quoteUnitName) {
        QuoteUnitName = quoteUnitName;
    }

    public String getTradingUnitName() {
        return TradingUnitName;
    }

    public void setTradingUnitName(String tradingUnitName) {
        TradingUnitName = tradingUnitName;
    }

    public String getDepositGroupNo() {
        return DepositGroupNo;
    }

    public void setDepositGroupNo(String depositGroupNo) {
        DepositGroupNo = depositGroupNo;
    }

    public float getPriceMultiple() {
        return PriceMultiple;
    }

    public void setPriceMultiple(float priceMultiple) {
        PriceMultiple = priceMultiple;
    }

    public double getExecuteDot() {
        return ExecuteDot;
    }

    public void setExecuteDot(double executeDot) {
        ExecuteDot = executeDot;
    }

    public int getMaxSingleOrderQty() {
        return MaxSingleOrderQty;
    }

    public void setMaxSingleOrderQty(int maxSingleOrderQty) {
        MaxSingleOrderQty = maxSingleOrderQty;
    }

    public int getMaxPositionQty() {
        return MaxPositionQty;
    }

    public void setMaxPositionQty(int maxPositionQty) {
        MaxPositionQty = maxPositionQty;
    }

    public String getRCommodityId1() {
        return RCommodityId1;
    }

    public void setRCommodityId1(String RCommodityId1) {
        this.RCommodityId1 = RCommodityId1;
    }

    public String getRCommodityId2() {
        return RCommodityId2;
    }

    public void setRCommodityId2(String RCommodityId2) {
        this.RCommodityId2 = RCommodityId2;
    }

    public String getRCommodityId3() {
        return RCommodityId3;
    }

    public void setRCommodityId3(String RCommodityId3) {
        this.RCommodityId3 = RCommodityId3;
    }

    public String getRCommodityId4() {
        return RCommodityId4;
    }

    public void setRCommodityId4(String RCommodityId4) {
        this.RCommodityId4 = RCommodityId4;
    }

    public String getOperator1() {
        return Operator1;
    }

    public void setOperator1(String operator1) {
        Operator1 = operator1;
    }

    public String getOperator2() {
        return Operator2;
    }

    public void setOperator2(String operator2) {
        Operator2 = operator2;
    }

    public String getOperator3() {
        return Operator3;
    }

    public void setOperator3(String operator3) {
        Operator3 = operator3;
    }

    public double getPriceProp1() {
        return PriceProp1;
    }

    public void setPriceProp1(double priceProp1) {
        PriceProp1 = priceProp1;
    }

    public double getPriceProp2() {
        return PriceProp2;
    }

    public void setPriceProp2(double priceProp2) {
        PriceProp2 = priceProp2;
    }

    public double getPriceProp3() {
        return PriceProp3;
    }

    public void setPriceProp3(double priceProp3) {
        PriceProp3 = priceProp3;
    }

    public double getPriceProp4() {
        return PriceProp4;
    }

    public void setPriceProp4(double priceProp4) {
        PriceProp4 = priceProp4;
    }

    public int getQtyProp1() {
        return QtyProp1;
    }

    public void setQtyProp1(int qtyProp1) {
        QtyProp1 = qtyProp1;
    }

    public int getQtyProp2() {
        return QtyProp2;
    }

    public void setQtyProp2(int qtyProp2) {
        QtyProp2 = qtyProp2;
    }

    public int getQtyProp3() {
        return QtyProp3;
    }

    public void setQtyProp3(int qtyProp3) {
        QtyProp3 = qtyProp3;
    }

    public int getQtyProp4() {
        return QtyProp4;
    }

    public void setQtyProp4(int qtyProp4) {
        QtyProp4 = qtyProp4;
    }

    public Long getUpdateId() {
        return UpdateId;
    }

    public void setUpdateId(Long updateId) {
        UpdateId = updateId;
    }

    public String getCommodityName() {
        String name = CHSName;
        if (TextUtils.isEmpty(name)) {
            name = CHTName;
        }
        if (TextUtils.isEmpty(name)) {
            name = ENUName;
        }

        return name;
    }
}
