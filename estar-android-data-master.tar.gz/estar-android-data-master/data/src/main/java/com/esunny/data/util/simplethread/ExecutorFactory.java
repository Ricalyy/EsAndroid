package com.esunny.data.util.simplethread;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

public class ExecutorFactory {

    public static ThreadPoolExecutor getExecutor(ThreadType threadType) {
        ThreadPoolExecutor executor;

        switch (threadType) {
            case NORMAL:
                executor = NormalExecutor.getDefaultNormalExecutor();
                break;
            case SORT:
                executor = SortExecutor.getDefaultSortExecutor();
                break;
            case SERIAL:
                executor = SerialExecutor.getDefaultSerialExecutor();
                break;
            default:
                executor = null;
                break;
        }

        return executor;
    }

    /**
     * 根据自身需求，自定义创建线程池
     * @param threadType
     * @param params 线程池参数
     * @return
     */
    public static Executor getExecutor(ThreadType threadType, ExecutorParams params) {
        Executor executor;

        switch (threadType) {
            case SERIAL:
                executor = SerialExecutor.getSerialExecutor(params);
                break;
            default:
                executor = new ThreadPoolExecutor(params.corePoolSize, params.maximumPoolSize, params.keepAliveTime, params.unit, params.workQueue, params.handler);
                break;
        }

        return executor;
    }
}
