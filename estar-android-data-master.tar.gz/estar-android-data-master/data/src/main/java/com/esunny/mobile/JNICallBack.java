package com.esunny.mobile;

public interface JNICallBack {              //调用回调需要继承该接口

    //必须重写该方法
    int Invoke(SByteObject object);
}
