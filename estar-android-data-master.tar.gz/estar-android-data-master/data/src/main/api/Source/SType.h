//
//  SType.h
//  StarMobileApi
//
//  Created by sss on 2017/4/14.
//  Copyright © 2017年 sss. All rights reserved.
//

#ifndef SType_h
#define SType_h

typedef signed char                             B8;

typedef signed char                             I8;
typedef signed short                            I16;
typedef signed int                              I32;
typedef signed long long                        I64;

typedef unsigned char                           U8;
typedef unsigned short                          U16;
typedef unsigned int                            U32;
typedef unsigned long long                      U64;

typedef float                                   F32;
typedef double                                  F64;

typedef char                                    C8;
typedef unsigned short                          C16;

typedef void*                                   PTR;

typedef C8                                      STR10[11];
typedef C8                                      STR20[21];
typedef C8                                      STR30[31];
typedef C8                                      STR40[41];
typedef C8                                      STR50[51];
typedef C8                                      STR100[101];
typedef C8                                      STR200[201];
typedef C8                                      STR300[301];
typedef C8                                      STR400[401];
typedef C8                                      STR500[501];
typedef C8                                      STR600[601];
typedef C8                                      STR1000[1001];

typedef I32                         SCollRetType;           //失败 < 0，成功 >= 0，
typedef U16                         SEleSizeType;
typedef U32                         SEleCountType;
typedef I32                         SEleIndexType;
typedef C8*                         SEleType;

typedef I32                         STcpRetType;
typedef C8*                         STcpBufType;
typedef I32                         STcpLenType;
typedef C8*                         STcpIpType;
typedef U16                         STcpPortType;

typedef C8                          STcpActionType;
static const STcpActionType         STCP_ACTION_CONNECT             = 'C';
static const STcpActionType         STCP_ACTION_DISCONNECT          = 'D';
static const STcpActionType         STCP_ACTION_RECVDATA            = 'R';
static const STcpActionType         STCP_ACTION_RESET_DATA            = 'S';



#endif /* SType_h */
