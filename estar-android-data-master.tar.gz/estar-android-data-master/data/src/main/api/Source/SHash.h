//
//  SHash.h
//  StarMobileApi
//
//  Created by sss on 2017/4/14.
//  Copyright © 2017年 sss. All rights reserved.
//

#ifndef SHash_h
#define SHash_h


#include "SType.h"

typedef struct {} SHash;

SHash* SHash_New();
SCollRetType SHash_Free(SHash* hash);

SEleCountType SHash_Count(SHash* hash);
SCollRetType SHash_Clear(SHash* hash);
SCollRetType SHash_Delete(SHash* hash, SEleIndexType index);

SEleIndexType SHash_Begin(SHash* hash);
SEleIndexType SHash_Next(SHash* hash, SEleIndexType index);

SEleIndexType SHash_FindI64(SHash* hash, I64 key);
SEleIndexType SHash_FindStr(SHash* hash, C8* key);

SEleIndexType SHash_InsertI64(SHash* hash, I64 key);
SEleIndexType SHash_InsertStr(SHash* hash, C8* key);

SCollRetType SHash_GetI64(SHash* hash, SEleIndexType index, I64* value);
SCollRetType SHash_SetI64(SHash* hash, SEleIndexType index, I64 value);

SCollRetType SHash_GetF64(SHash* hash, SEleIndexType index, F64* value);
SCollRetType SHash_SetF64(SHash* hash, SEleIndexType index, F64 value);

SCollRetType SHash_GetPtr(SHash* hash, SEleIndexType index, PTR* value);
SCollRetType SHash_SetPtr(SHash* hash, SEleIndexType index, PTR value);

SEleIndexType SHash_GetKey(SHash* hash,SEleIndexType index, C8* key, int length);
#endif /* SHash_h */
