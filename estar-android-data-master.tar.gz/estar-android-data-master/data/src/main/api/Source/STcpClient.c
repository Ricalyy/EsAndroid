//
//  STcpClient.c
//  StarMobileApi
//
//  Created by sss on 2017/5/9.
//  Copyright © 2017年 sss. All rights reserved.
//

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <poll.h>
#include <sys/types.h>
#include <netdb.h>
#include <net/if.h>

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "SType.h"
#include "STcpClient.h"
#include "StarMobileApi.h"
#include <android/log.h>

#define TAG "STcpClient" // LOG标识
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__) // 定义LOGD类型


I32 G_ToExit = 0;

typedef struct SRealTcpClient
{
    int                         Key;                    // 标识符
    U8                          IsRunning;                  //0:关闭；1:运行
    char                        Ip[40];
    int                         Port;
    int                         Socket;
    pthread_t                   Thread;
    STcpClientCallback          CallBack;
    volatile STcpRetType        IsOpen;                     //-1 待关闭、0 已关闭、1 正常
    C8                          RecvBuf[256 * 1024];
    I32                         ReadIndex;
    I32                         WriteIndex;

    CspIdeaKeyType              SendKey;
    CspIdeaKeyType              RecvKey;
} SRealTcpClient;


int DetectWifi(int fd)
{
    struct ethtool_value
    {
        U32 cmd;
        U32 data;
        
    };
  
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, "eth0", sizeof(ifr.ifr_name) -1);
    
    struct ethtool_value edata;
    edata.cmd = 0x0000000a;
    ifr.ifr_data = (caddr_t)&edata;
    
    int err = ioctl(fd, 0x8946, &ifr);
    if(err == 0)
    {
        return edata.data;
    }
                  
    return 1;
}

STcpRetType Open(STcpClient* client)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    
    struct addrinfo hints, *result, *rp;
    memset(&hints, 0, sizeof(hints));
    
    hints.ai_family = PF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = G_SystemType == S_TT_IOS ?AI_DEFAULT:AI_PASSIVE;
    
    struct sockaddr_in addr_in;
    struct sockaddr_in6 addr_in6;
    
    int e = -1, s = -1, ret = -2;
    
    e = getaddrinfo(rclient->Ip, NULL, &hints, &result);
    
    if(0 != e) return -1;
    
    for(rp = result; rp != NULL; rp = rp->ai_next)
    {
        s = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        
        if(-1 == s)
            continue;
        
        int flags = fcntl(s, F_GETFL, 0);
        fcntl(s, F_SETFL, flags | O_NONBLOCK);
        
        int optval = 1;
        setsockopt(s, SOL_SOCKET, G_SystemType == S_TT_IOS ? _SO_NOSIGPIPE : _MSG_NOSIGNAL, (void *)&optval, sizeof(int));
        
        fd_set writeset;
        FD_ZERO(&writeset);
        FD_SET(s, &writeset);
        
        fd_set exceptset;
        FD_ZERO(&exceptset);
        FD_SET(s, &exceptset);
        
        struct timeval tv;
        tv.tv_sec = 1;
        tv.tv_usec = 0;
        
        if(AF_INET == rp->ai_family)
        {
            addr_in = *((struct sockaddr_in*)rp->ai_addr);
            addr_in.sin_port = htons(rclient->Port);
            connect(s, (struct sockaddr *)&addr_in, rp->ai_addrlen);
        }
        else if(AF_INET6 == rp->ai_family)
        {
            addr_in6 = *((struct sockaddr_in6*)rp->ai_addr);
            addr_in6.sin6_port = htons(rclient->Port);
            connect(s, (struct sockaddr *)&addr_in6, rp->ai_addrlen);
        }
        
        ret = select(s + 1, 0, &writeset, &exceptset, &tv);
        if (ret <= 0) {
            close(s);
            ret = -2;
            continue;
        }

        int error;
        socklen_t len = sizeof (error);
        ret = getsockopt(s, SOL_SOCKET, SO_ERROR, &error, &len) ;

        if (ret < 0) {
            close(s);
            continue;
        } else if (0 != error) {
            close(s);
            ret = -1;
            continue;
        }

        ret = 0;
        break;
    }

    freeaddrinfo(result);

    if(ret < 0) return ret;
    
    rclient->Socket = s;
    rclient->IsOpen = 1;
    rclient->ReadIndex = 0;
    rclient->WriteIndex = 0;
    
    if(NULL == rclient->CallBack) return -3;
    
//    rclient->CallBack(client, STCP_ACTION_CONNECT, NULL, 0);
    
    return 0;
}

STcpRetType Poll(STcpClient *client)
{
    STcpRetType ret = 0;
    
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    
    if(rclient->IsOpen <= 0) return -1;
    
    while(!G_ToExit && rclient->IsRunning)
    {
        //检查读状态
        fd_set readset;
        FD_ZERO(&readset);
        FD_SET(rclient->Socket, &readset);
        
        struct timeval tv;
        tv.tv_sec = 1;
        tv.tv_usec = 0;
        
        int sret = select(rclient->Socket + 1, &readset, 0, 0, &tv);
        if (sret < 0)
        {
            ret = -2;
            break;
        }
        
        if(rclient->IsOpen != 1)
        {
            ret = -3;
            break;
        }
        
        if (!FD_ISSET(rclient->Socket, &readset))
        {
            continue;
        }
        
        //读取数据
        if (rclient->WriteIndex >= sizeof(rclient->RecvBuf))
        {
            ret = -4;
            break;
        }
        
        ssize_t rret = recv(rclient->Socket, &rclient->RecvBuf[rclient->WriteIndex], sizeof(rclient->RecvBuf) - rclient->WriteIndex, 0);
        
        if (rret <= 0) {
            ret = -5;
            break;
        }
        
        //处理数据
        rclient->WriteIndex += rret;
        STcpRetType dret = rclient->CallBack((STcpClient*)rclient, STCP_ACTION_RECVDATA,
                                             &rclient->RecvBuf[rclient->ReadIndex], rclient->WriteIndex - rclient->ReadIndex);
        
        if (dret < 0)
        {
            ret = -6;
            break;
        }
        
        rclient->ReadIndex += dret;
        if (rclient->ReadIndex >= rclient->WriteIndex)
        {
            rclient->ReadIndex = 0;
            rclient->WriteIndex = 0;
        }
        else if (rclient->ReadIndex >= sizeof(rclient->RecvBuf) / 2)
        {
            memmove(rclient->RecvBuf, &rclient->RecvBuf[rclient->ReadIndex], rclient->WriteIndex - rclient->ReadIndex);
            rclient->WriteIndex -= rclient->ReadIndex;
            rclient->ReadIndex = 0;
        }
    }
    
    return ret;
}

void* RealTcpClientRun(void* data)
{
    STcpRetType ret = -1;
    
    SRealTcpClient* rclient = (SRealTcpClient*)data;
    
    rclient->IsRunning = 1;
    
    //int count = 0;

    while(!G_ToExit && rclient->IsRunning)
    {
        //处理主动关闭
        if (-1 == rclient->IsOpen)
        {
            shutdown(rclient->Socket, SHUT_RDWR);
            rclient->IsOpen = 0;
        }
        
        //关闭后跳出释放
        if (rclient->IsOpen <= 0)
        {
            //printf("[%d]Connect to %s:%d\n", ++count, rclient->Ip,rclient->Port);
            ret = Open((STcpClient*)rclient);
            LOGD("[%d]Connect to %s:%d\n", ret, rclient->Ip,rclient->Port);
            if(ret < 0)
            {
                usleep(3000*1000);
                continue;
            } else {
                rclient->CallBack((STcpClient*)rclient, STCP_ACTION_CONNECT, NULL, 0);
            }
        }

        STcpRetType pret = Poll((STcpClient*)rclient);
        if(pret < 0)
        {
            LOGD("[%d]Poll to %s:%d\n", pret, rclient->Ip, rclient->Port);
            shutdown(rclient->Socket, SHUT_RDWR);
            close(rclient->Socket);
            rclient->IsOpen = 0;
            rclient->CallBack((STcpClient*)rclient, STCP_ACTION_RESET_DATA, NULL, 0);
            //休息1秒再重连吧
            usleep(1000*1000);
        }
    }
    
    if(1 == rclient->IsOpen)
    {
        shutdown(rclient->Socket, SHUT_RDWR);
        close(rclient->Socket);
        rclient->IsOpen = 0;
    }
    
    rclient->IsOpen = -1;

    rclient->CallBack((STcpClient*)rclient, STCP_ACTION_DISCONNECT, NULL, 0);
    
    free(data);
    data = NULL;

    return NULL;
}

STcpRetType STcpClient_Callback(STcpClientCallback cb, STcpClient*client) {
    if (client == NULL) {
        return -1;
    }
    SRealTcpClient* rclient = (SRealTcpClient *) client;
    rclient->CallBack = cb;

    rclient->CallBack(client, STCP_ACTION_CONNECT, NULL, 0);
    return 1;
}

STcpRetType STcpClient_New(int key, STcpIpType ip, STcpPortType port, STcpClientCallback cb, STcpClient** client)
{
    SRealTcpClient* rclient = (SRealTcpClient*)malloc(sizeof(SRealTcpClient));
    strncpy(rclient->Ip, ip, strlen(ip)+1);
    rclient->Port = port;
    rclient->CallBack = cb;
    rclient->IsOpen = 0;
    rclient->IsRunning = 0;
    rclient->Key = key;

    if (client != NULL) {
        *client = (STcpClient*)rclient;
    }
    
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    pthread_create(&rclient->Thread, &attr, &RealTcpClientRun, rclient);
    pthread_attr_destroy(&attr);
    
    return 0;
}

STcpRetType STcpClient_Free(STcpClient* client)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    if(NULL == rclient)
        return -1;
    rclient->IsRunning = 0;
    return 0;
}

STcpRetType STcpClient_IsRun(STcpClient* client)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;

    if(NULL == rclient) return 0;

    return (1 == rclient->IsRunning);
}

STcpRetType STcpClient_IsOpen(STcpClient* client)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    
    if(NULL == rclient) return 0;

    return (1 == rclient->IsOpen);
}

STcpRetType STcpClient_Close(STcpClient* client)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;

    shutdown(rclient->Socket, SHUT_RDWR);
    close(rclient->Socket);
    rclient->IsOpen = 0;
    
    return 0;
}

STcpRetType STcpClient_Reset(STcpClient* client)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    if(rclient)
        rclient->IsOpen = 0;
    return 0;
}


STcpRetType STcpClient_GetAddr(STcpClient *client, STcpIpType ip, STcpPortType *port)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    if(NULL == rclient)
        return -1;
    strncpy(ip, rclient->Ip, strlen(rclient->Ip) +1);
    *port = rclient->Port;
    return 0;
}

STcpRetType STcpClient_Send(STcpClient* client, const STcpBufType buf, const STcpLenType len)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    if(rclient == NULL)
        return -1;
    if (rclient->IsOpen <= 0)
        return 0;
    
    return (STcpRetType)send(rclient->Socket, buf, len, 0);
}

int STcpClient_GetKey(STcpClient *client)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    if(NULL == rclient)
        return -1;

    return rclient->Key;
}

int STcpClient_SetIdeaKey(STcpClient *client,  CspAuthRsp *data)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    if(NULL == rclient)
        return -1;

    CspSetIdeaKey(rclient->RecvKey, data->RecvKey, (U32)strlen(data->RecvKey));
    CspSetIdeaKey(rclient->SendKey, data->SendKey, (U32)strlen(data->SendKey));
    return 0;
}

int STcpClient_getRecvKey(STcpClient *client, CspIdeaKeyType recvKey)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    if(NULL == rclient)
        return -1;

    memcpy(recvKey, &rclient->RecvKey, sizeof(rclient->RecvKey));
    return 0;
}

int STcpClient_getSendKey(STcpClient *client, CspIdeaKeyType sendKey)
{
    SRealTcpClient* rclient = (SRealTcpClient*)client;
    if(NULL == rclient)
        return -1;

    memcpy(sendKey, &rclient->SendKey, sizeof(rclient->SendKey));
    return 0;
}