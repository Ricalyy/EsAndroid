//
//  TradeUtils.c
//  StarMobileApi
//
//  Created by sss on 2017/4/13.
//  Copyright © 2017年 sss. All rights reserved.
//

#include "ComUtils.h"


//链路认证公钥和私钥
CspRsaPubKey G_RsaPubKey = "AAS4MUFOC0YTkivTW0s2gCvB4egclaJ8lY9TggA99kYVTKkvwc4Cw74EekXps"
                           "CqQibS5AngjfJZRkqD8yGu0m8gq5v3C3nCQBrhsdnbv31l2JvrWM6T33EjERdN"
                           "+tV/LOxq7lbqqgm1TkOFf0U7UA/otDLhBxlBglSTsVV47xWypVwAAAAAAAQAB";
CspRsaPriKey G_RsaPriKey = "AAS4MUFOC0YTkivTW0s2gCvB4egclaJ8lY9TggA99kYVTKkvwc4Cw74EekXps"
                           "CqQibS5AngjfJZRkqD8yGu0m8gq5v3C3nCQBrhsdnbv31l2JvrWM6T33EjERd"
                           "N+tV/LOxq7lbqqgm1TkOFf0U7UA/otDLhBxlBglSTsVV47xWypVwAAAAAAAQA"
                           "BDbzZH1wtLjkAAAAAAADhP1dvULyw57n2yufQ1ffBt/fK59DV98EAAAAAULyw"
                           "5wf4yucBAAAAlYHF5wAAAADbIo7CubOfwnA/xOesqcXnuMLN5wAAAAAAAAAAA"
                           "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAcM+cBAAAAELvhBs3QCMkVCR"
                           "STioyl14S4VhVCOLfnjonL1lafWXYgEH9ebuHD6jFBkOCOJEdeuBbxIR7RSf+"
                           "VM+Vg3kyurvc10YuW1UVFlu6Ioz3ZoRdmQq51e8YYCg14ObVemRbGLdarAhth"
                           "HqUOm+50kscQkpFwZ6DQSG3IjDXci0XvS1VT21wPqIv/zCRq/pwOBtSig43Wy"
                           "gO5qKN3UTCvk+jFdOpRVYqQ2pSIb3Zfiz8b4IcD0X79Cdqd545nGOS0jbK5qj"
                           "FVXCC4hjx/7HGa1hI2bjrJBRp0rlCSn8QO9hQwFrfqal1FQXQBsMlPugag2Bi"
                           "nLDn27OqL5rTgcPyDe5ysOnkrtTtG420XIiGWgMzftnZKx49UwGVapIMOxjRe"
                           "C3WrMP1rJvwb9EEvX0i5BihVeIPdW9TLzIT3bIGWaYeuG3QVI5==";

//明文发送接口
STcpRetType PhoneSendPlain(STcpClient* client, const STcpBufType buf, const STcpLenType len)
{
    C8 sendbuf[CSP_FRAME_MAX];
    memset(sendbuf, 0, sizeof(sendbuf));
    
    CspFrameHead* fh = (CspFrameHead*)sendbuf;
    fh->FrameFlag = CSP_FRAME_FLAG;
    fh->FrameType = CSP_FRAME_PLAIN;
    fh->FrameSize = len;
    
    memcpy(&sendbuf[sizeof(CspFrameHead)], buf, len);
    
    return STcpClient_Send(client, sendbuf, sizeof(CspFrameHead) + len);
}

//压缩发送接口
STcpRetType PhoneSendLzo(STcpClient* client, const STcpBufType buf, const STcpLenType len)
{
    C8 sendbuf[CSP_FRAME_MAX];
    memset(sendbuf, 0, sizeof(sendbuf));
    
    U64 lzo_len = len;
    
    STcpRetType ret = CspLzoCompress(buf, len, &sendbuf[sizeof(CspFrameHead)], &lzo_len);
    if(ret < 0) return -1;
    
    CspFrameHead *head = (CspFrameHead*)sendbuf;
    head->FrameFlag = CSP_FRAME_FLAG;
    head->FrameType = CSP_FRAME_LZO;
    head->FrameSize = lzo_len;
    
    return STcpClient_Send(client, sendbuf, sizeof(CspFrameHead) + (U32)lzo_len);
}

//IDEA密文发送接口
STcpRetType PhoneSendIdea(STcpClient* client, CspIdeaKeyType key, const STcpBufType buf, const STcpLenType len)
{
    C8 sendbuf[CSP_FRAME_MAX];
    
    CspFrameHead* fh = (CspFrameHead*)sendbuf;
    fh->FrameFlag = CSP_FRAME_FLAG;
    fh->FrameType = CSP_FRAME_IDEA;
    fh->FrameSize = len;
    
    CspIdeaEncrypt(buf,  &sendbuf[sizeof(CspFrameHead)], len, key);
    
    return STcpClient_Send(client, sendbuf, sizeof(CspFrameHead) + len);
}

//压缩加密发送接口
STcpRetType PhoneSendLzoIdea(STcpClient* client, CspIdeaKeyType key, const STcpBufType buf, const STcpLenType len)
{
    C8 sendbuf[CSP_FRAME_MAX];
    C8 lzobuf[CSP_FRAME_MAX];
    
    memset(sendbuf, 0, sizeof(sendbuf));
    memset(lzobuf, 0, sizeof(lzobuf));
    
    U64 lzo_len = len;
    
    STcpRetType ret = CspLzoCompress(buf, len, lzobuf, &lzo_len);
    if(ret < 0) return -1;
    
    CspIdeaEncrypt(lzobuf, &sendbuf[sizeof(CspFrameHead)], (U32)lzo_len, key);
    
    CspFrameHead *head = (CspFrameHead*)sendbuf;
    head->FrameFlag = CSP_FRAME_FLAG;
    head->FrameType = CSP_FRAME_LZO_IDEA;
    head->FrameSize = lzo_len;
    
    return STcpClient_Send(client, sendbuf, sizeof(CspFrameHead) + (U32)lzo_len);
}

//STcpRetType PhoneAuthReq(STcpClient* client)
//{
//    C8 sendbuf[sizeof(CspSessionHead) + sizeof(CspAuthReq)];
//    memset(sendbuf, 0, sizeof(sendbuf));
//
//    CspSessionHead *sh = (CspSessionHead*)sendbuf;
//
//    sh->ProtocolVer = TRD_PROTOCOL_VER;
//    sh->SubSystem = CSP_SUBSYSTEM_TRADE; //子系统号，用于协议分组
//    sh->LangType = G_QUOTE_LANG;
//    sh->ProtocolCode = CMD_CSP_AuthReq;
//    sh->Chain = CSP_CHAIN_END;
//    sh->FieldCount = 1;
//    sh->FieldSize = sizeof(CspAuthReq);
//
//    FillAuthReq(&sendbuf[sizeof(CspSessionHead)], sizeof(CspAuthReq), G_RsaPubKey, CSP_SUBSYSTEM_TRADE);
//
//    STcpRetType ret = PhoneSendLzo(client, sendbuf, sizeof(sendbuf));
//
//    return (ret > 0) ? 0 : -1;
//}
//
STcpRetType AccessAuthReq(STcpClient* client, CspLanguageType languageType, CspSubSystemType subSystemType)
{
    C8 sendbuf[sizeof(CspSessionHead) + sizeof(CspAuthReq)];
    memset(sendbuf, 0, sizeof(sendbuf));

    CspSessionHead *sh = (CspSessionHead*)sendbuf;

    sh->ProtocolVer = TRD_PROTOCOL_VER;
    sh->SubSystem = subSystemType; //子系统号，用于协议分组
    sh->LangType = languageType;
    sh->ProtocolCode = CMD_CSP_AuthReq;
    sh->Chain = CSP_CHAIN_END;
    sh->FieldCount = 1;
    sh->FieldSize = sizeof(CspAuthReq);

    FillAuthReq(&sendbuf[sizeof(CspSessionHead)], sizeof(CspAuthReq), G_RsaPubKey, subSystemType);

    STcpRetType ret = PhoneSendLzo(client, sendbuf, sizeof(sendbuf));

    return (ret > 0) ? 0 : -1;
}

