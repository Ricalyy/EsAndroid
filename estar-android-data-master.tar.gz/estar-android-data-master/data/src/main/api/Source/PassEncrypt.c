#include <string.h>
#include <stdio.h>
#include "../Others/IDEA.h"

const int G_OriPassLen = 63;
const int G_OriPassSpaceLen = G_OriPassLen + 1;
const int G_DesPassLen = G_OriPassSpaceLen * 2;


const char G_PassKey[] = "lkjlK^uw3)(hjg_3";


void HexToBin(char* out, char* in, int size)
{
	static short Convert[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9,-1,-1,-1,-1,-1,-1,
		 -1,10,11,12,13,14,15,-1,-1,-1,-1,-1,-1,-1,-1,-1,
		 -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
		 -1,10,11,12,13,14,15};

	int i = size;

	while (i > 0)
	{
		
		out[0] = (char)((Convert[in[0] - '0'] << 4) + Convert[in[1]  - '0']);
		
		out++;
		
		in += 2;
		
		i--;
	}
}


void DecodePass(char *in_pass,  char* out_pass)
{
	IDEA_KEY m_Key;
	SetCipher(&m_Key, G_PassKey, strlen(G_PassKey));
	char buf[G_OriPassSpaceLen];
	HexToBin(buf, in_pass, G_OriPassSpaceLen);

	char buf2[G_OriPassSpaceLen];
	memset(buf2, 0, sizeof(buf2));
	decipher_buffer(buf, buf2, G_OriPassSpaceLen, &m_Key);

	strncpy(out_pass, (char*)buf2, (int)G_OriPassLen);
}

