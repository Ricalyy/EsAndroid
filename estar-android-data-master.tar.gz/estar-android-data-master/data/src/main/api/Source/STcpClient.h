//
//  STcpClient.h
//  StarMobileApi
//
//  Created by sss on 2017/5/9.
//  Copyright © 2017年 sss. All rights reserved.
//

#ifndef STcpClient_h
#define STcpClient_h

#include "CspTools.h"

extern I32 G_ToExit;
static const int _SO_NOSIGPIPE = 0x1022;
static const int _MSG_NOSIGNAL = 0x4000;

typedef struct {} STcpClient;
typedef STcpRetType (*STcpClientCallback)(STcpClient* client, const STcpActionType action, const STcpBufType buf, const STcpLenType len);

STcpRetType STcpClient_Callback(STcpClientCallback cb, STcpClient* client);
STcpRetType STcpClient_New(int key, STcpIpType ip, STcpPortType port, STcpClientCallback cb, STcpClient** client);
STcpRetType STcpClient_Free(STcpClient* client);

STcpRetType STcpClient_IsRun(STcpClient* client);
STcpRetType STcpClient_IsOpen(STcpClient* client);
STcpRetType STcpClient_Reset(STcpClient* client);
STcpRetType STcpClient_GetAddr(STcpClient *client, STcpIpType ip, STcpPortType *port);
STcpRetType STcpClient_Send(STcpClient* client, const STcpBufType buf, const STcpLenType len);
STcpRetType STcpClient_Close(STcpClient* client);

int STcpClient_GetKey(STcpClient *client);
int STcpClient_SetIdeaKey(STcpClient *client,  CspAuthRsp *data);
int STcpClient_getRecvKey(STcpClient *client, CspIdeaKeyType recvKey);
int STcpClient_getSendKey(STcpClient *client, CspIdeaKeyType sendKey);
#endif /* STcpClient_h */
