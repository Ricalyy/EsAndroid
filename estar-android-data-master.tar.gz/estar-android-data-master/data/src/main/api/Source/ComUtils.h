//
//  TradeUtils.h
//  StarMobileApi
//
//  Created by fld on 20179/12.
//  Copyright © 2017年 fld. All rights reserved.
//

#ifndef ComUtils_h
#define ComUtils_h


#include "CspTools.h"
#include "SType.h"
#include "STcpClient.h"

////////////////////////////////////////////////////////
extern CspRsaPubKey G_RsaPubKey;
extern CspRsaPriKey G_RsaPriKey;

//明文发送接口
STcpRetType PhoneSendPlain(STcpClient* client, const STcpBufType buf, const STcpLenType len);

//压缩发送接口
STcpRetType PhoneSendLzo(STcpClient* client, const STcpBufType buf, const STcpLenType len);

//IDEA密文发送接口
STcpRetType PhoneSendIdea(STcpClient* client, CspIdeaKeyType key, const STcpBufType buf, const STcpLenType len);

//压缩加密发送接口
STcpRetType PhoneSendLzoIdea(STcpClient* client, CspIdeaKeyType key, const STcpBufType buf, const STcpLenType len);

////链路认证接口
//STcpRetType PhoneAuthReq(STcpClient* client);
//
////链路认证接口
STcpRetType AccessAuthReq(STcpClient* client, CspLanguageType languageType, CspSubSystemType subSystemType);



#endif /* ComUtils_h */
