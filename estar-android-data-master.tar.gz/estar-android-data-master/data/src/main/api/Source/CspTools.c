/**
 *  @file CspTools.c
 *  @brief [Brief]
 */

#include "CspTools.h"

/* rsa encrypt and decrypt */
int CspGenRsaKey(CspRsaPubKey pubKey, CspRsaPriKey priKey)
{
    RsaProtoKey protoKey = {1024};

    RsaPublicKey pubkey2;
    RsaPrivateKey prikey2;

    int status = GeneratePemKeys(&pubkey2, &prikey2, &protoKey);
    if(status) return -1;

    memset(pubKey, 0, sizeof(CspRsaPubKey));
    memset(priKey, 0, sizeof(CspRsaPriKey));

    U32 pubKeyLen = 0, priKeyLen = 0;

    status = EncodePemBlock((RPTR)pubKey, &pubKeyLen, (unsigned char*)&pubkey2, sizeof(pubkey2));

    if(status || pubKeyLen > sizeof(CspRsaPubKey))
        return -1;

    pubKey[pubKeyLen] = '\0';

    status = EncodePemBlock((RPTR)priKey, &priKeyLen, (unsigned char*)&prikey2, sizeof(prikey2));

    if(status || priKeyLen > sizeof(CspRsaPriKey))
        return -1;

    priKey[priKeyLen] = '\0';

    return 0;
}

int CspRsaPubEncrypt(C8 *output, U32 *outLen, C8 *input, U32 inLen, CspRsaPubKey pubKey)
{
    if(NULL == output || NULL == input || NULL == pubKey)
        return -1;

    //get rsa public key
    RsaPublicKey  pubkey2;
    U32           publen = 0;

    memset(&pubkey2, 0, sizeof(RsaPublicKey));

    int status = DecodePemBlock((RPTR)&pubkey2, &publen, (RPTR)pubKey, (RU32)strlen(pubKey));
    if(status || publen != sizeof(RsaPublicKey))
        return -1;

    status = RsaPublicEncrypt((RPTR)output, (RU32*)outLen, (RPTR)input, inLen, &pubkey2);
    if(status) return -1;

    return 0;
}

int CspRsaPriDecrypt(C8 *output, U32 *outLen, C8 *input, U32 inLen, CspRsaPriKey priKey)
{
    if(NULL == output || NULL == input || NULL == priKey)
        return -1;

    //get rsa public key
    RsaPrivateKey  prikey2;
    U32            prilen = 0;

    memset(&prikey2, 0, sizeof(RsaPrivateKey));

    int status = DecodePemBlock((RPTR)&prikey2, &prilen, (RPTR)priKey, (RU32)strlen(priKey));
    if(status || prilen != sizeof(RsaPrivateKey))
        return -1;

    status = RsaPrivateDecrypt((RPTR)output, outLen, (RPTR)input, inLen, &prikey2);
    if(status) return -1;

    return 0;
}

/* IDEA encrypt and decrypt */

void CspSetIdeaKey(CspIdeaKeyType key, const C8 *userKey, U32 keyLen)
{
    IDEA_KEY iKey;
    memset(&iKey, 0, sizeof(iKey));
    SetCipher(&iKey, userKey, keyLen);

    memset(key, 0, sizeof(CspIdeaKeyType));
    memcpy(key, &iKey, sizeof(iKey));
}

void CspIdeaEncrypt(const C8 *in, C8 *out, U32 len, CspIdeaKeyType key)
{
    IDEA_KEY *pKey = (IDEA_KEY*)key;
    cipher_buffer(in, out, len, pKey);
}

void CspIdeaDecrypt(const C8 *in, C8 *out, U32 len, CspIdeaKeyType key)
{
    IDEA_KEY *pKey = (IDEA_KEY*)key;
    decipher_buffer(in, out, len, pKey);
}

/* minilzo compress and decompress */
int CspLzoCompress(const C8 *src, U64 srcLen, C8 *dst, U64 *dstLen)
{
    C8 workbuf[LZO1X_1_MEM_COMPRESS];
    memset(workbuf, 0, sizeof(workbuf));
    
    int ret = lzo1x_1_compress((U8*)src, (lzo_uint)srcLen, (U8*)dst, (lzo_uintp)dstLen, workbuf);
    return (ret == LZO_E_OK) ? 0 : -1;
}

int CspLzoDecompress(const C8 *src, U64 srcLen, C8 *dst, U64 *dstLen)
{
     int ret = lzo1x_decompress_safe((U8*)src, (lzo_uint)srcLen, (U8*)dst, (lzo_uintp)dstLen, 0);
     return (ret == LZO_E_OK) ? 0 : -1;
}


/* generate session key  betwon ASCII 0x21-0x7E*/

int GenSessionKey(C8 *output, const U8 len)
{
    int i = 0;

    memset(output, 0, len);

    if(NULL == output || len <= 0)
        return -1;

    srand((unsigned int)time(NULL)+rand());

    for(i = 0; i < len; i++)
    {
        output[i] = (rand() % (0x7E - 0x21 + 1)) + 0x21;
    }

    return 0;
}

/* generate session key  betwon ASCII 0x21-0x7E*/

int GenAuthString(C8 *output, const U8 len)
{
    int i = 0;

    memset(output, 0, len);

    if(NULL == output || len <= 0)
        return -1;

    srand((unsigned int)time(NULL)+rand());

    for(i = 0; i < len; i++)
    {
        output[i] = (rand() % (0x7E - 0x21 + 1)) + 0x21;
    }

    return 0;
}

/* frame parse */
int CspOnFrame(PTR client, const C8 *buf, const size_t len, CspFrameCallback *callback)
{
    size_t pos = 0;

    if(NULL == callback->func)
        return (int)len;

    while(pos + sizeof(CspFrameHead) <= len)
    {
        CspFrameHead *head = (CspFrameHead*) &buf[pos];

        if(CSP_FRAME_FLAG != head->FrameFlag)
            return -1;

        if(head->FrameSize < CSP_FRAME_MIN || head->FrameSize > CSP_FRAME_MAX)
            return -1;

        if (pos + sizeof(CspFrameHead) + head->FrameSize > len)
            break;

        switch(head->FrameType)
        {
            case CSP_FRAME_PLAIN:
            {
                callback->func(client, &buf[pos], sizeof(CspFrameHead)+head->FrameSize);
                break;
            }
            case CSP_FRAME_LZO:
            {
                C8 lzobuf[CSP_FRAME_MAX + sizeof(CspFrameHead)];
                U64 lzolen = CSP_FRAME_MAX;

                if(0 == CspLzoDecompress(&buf[pos+sizeof(CspFrameHead)], \
                    head->FrameSize, &lzobuf[sizeof(CspFrameHead)], &lzolen))
                {
                    memcpy(lzobuf, &buf[pos], sizeof(CspFrameHead));
                    CspFrameHead *newhead = (CspFrameHead*)lzobuf;
                    newhead->FrameSize = lzolen;
                    newhead->FrameType = CSP_FRAME_PLAIN;
                    callback->func(client, lzobuf, (size_t)(lzolen + sizeof(CspFrameHead)));
                }
                break;
            }
            case CSP_FRAME_IDEA:
            {
                if(NULL == callback->data)
                    break;

                C8 ideabuf[CSP_FRAME_MAX + sizeof(CspFrameHead)];
                memset(ideabuf, 0, sizeof(ideabuf));

                CspIdeaDecrypt(&buf[pos + sizeof(CspFrameHead)], &ideabuf[sizeof(CspFrameHead)], \
                    head->FrameSize, (C8*)callback->data);

                memcpy(ideabuf, &buf[pos], sizeof(CspFrameHead));
                CspFrameHead* newhead = (CspFrameHead*)ideabuf;
                newhead->FrameType = CSP_FRAME_PLAIN;
                callback->func(client, ideabuf, head->FrameSize + sizeof(CspFrameHead));

                break;
            }

            case CSP_FRAME_LZO_IDEA:
            {
                if(NULL == callback->data)
                    break;

                C8 ideabuf[CSP_FRAME_MAX];
                C8 lzobuf[CSP_FRAME_MAX + sizeof(CspFrameHead)];

                memset(ideabuf, 0, sizeof(ideabuf));
                memset(lzobuf, 0, sizeof(lzobuf));

                CspIdeaDecrypt(&buf[pos + sizeof(CspFrameHead)], ideabuf, \
                    head->FrameSize, (C8*)callback->data);

                U64 lzolen = CSP_FRAME_MAX;
                if(0 != CspLzoDecompress(ideabuf, head->FrameSize, \
                    &lzobuf[sizeof(CspFrameHead)], &lzolen))
                {
                    break;
                }

                memcpy(lzobuf, &buf[pos], sizeof(CspFrameHead));
                CspFrameHead *newhead = (CspFrameHead*)lzobuf;
                newhead->FrameSize = lzolen;
                newhead->FrameType = CSP_FRAME_PLAIN;
                callback->func(client, lzobuf, (size_t)(lzolen + sizeof(CspFrameHead)));

                break;
            }

            default: break;
        }

        pos += sizeof(CspFrameHead) + head->FrameSize;
    }

    return (int)pos;
}

int FillAuthReq(C8 *buf, const size_t bufLen, CspRsaPubKey key, CspSubSystemType sysType)
{
    if(bufLen < sizeof(CspAuthReq))
        return -1;

    memset(buf, 0, sizeof(bufLen));

    CspAuthReq *req = (CspAuthReq*)buf;

    srand((unsigned int)time(NULL));
    req->Disturb0 = rand();
    req->SubSystemType = sysType;
    req->Disturb1 = rand();
    req->Disturb2 = rand();
    req->Disturb3 = rand();
    memcpy(req->RsaPubKey, key, strlen(key)+1);
    req->Disturb4 = rand();

    return sizeof(CspAuthReq);
}

int FillAuthRsp(C8 *buf, const size_t bufLen, CspRsaPubKey key, CspSubSystemType sysType)
{
    if(bufLen < sizeof(CspAuthRsp))
        return -1;

    memset(buf, 0, sizeof(bufLen));

    CspAuthRsp *rsp = (CspAuthRsp*)buf;
    rsp->SubSystemType = sysType;

    int ret = -1;

    C8 send_key[CSP_COMM_KEY_LEN+1];
    C8 recv_key[CSP_COMM_KEY_LEN+1];

    memset(send_key, 0, sizeof(send_key));
    memset(recv_key, 0, sizeof(recv_key));

    ret = GenSessionKey(send_key, CSP_COMM_KEY_LEN);
    if(ret < 0) return -2;

    ret = GenSessionKey(recv_key, CSP_COMM_KEY_LEN);
    if(ret < 0) return -3;

    U32 send_key_len = 0, recv_key_len = 0;

    ret = CspRsaPubEncrypt(rsp->SendKey, &send_key_len, send_key, CSP_COMM_KEY_LEN, key);

    if(ret < 0 || CSP_RSA_TEXT_LEN != send_key_len)
        return -4;

    ret = CspRsaPubEncrypt(rsp->RecvKey, &recv_key_len, recv_key, CSP_COMM_KEY_LEN, key);

    if(ret < 0 || CSP_RSA_TEXT_LEN != recv_key_len)
        return -5;

    rsp->HBStartDelay = 30 * 1000;
    rsp->HBInterval   = 10 * 1000;
    rsp->HBMaxCount   = 3;

    return sizeof(CspAuthRsp);
}

int CspOnAuth(C8 *buf, const size_t len, CspRsaPriKey key)
{
    if(len < sizeof(CspAuthRsp))
        return -1;

    CspAuthRsp *data = (CspAuthRsp*)buf;

    U32 outLen = 0;
    CspRsaCommKeyType output;
    memset(output, 0, sizeof(CspRsaCommKeyType));

    int ret = CspRsaPriDecrypt(output, &outLen, data->SendKey, CSP_RSA_TEXT_LEN, key);

    if(ret < 0) return -1;

    memcpy(data->SendKey, output, outLen);
    data->SendKey[outLen] = '\0';

    outLen = 0;
    memset(output, 0, sizeof(CspRsaCommKeyType));
    ret = CspRsaPriDecrypt(output, &outLen, data->RecvKey, CSP_RSA_TEXT_LEN, key);

    if(ret < 0) return -1;

    memcpy(data->RecvKey, output, outLen);
    data->RecvKey[outLen] = '\0';

    return 0;
}