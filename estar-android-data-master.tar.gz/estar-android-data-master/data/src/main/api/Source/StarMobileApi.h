//
// Created by DELL on 2020/9/4.
//

#ifndef StarMobileApi_h
#define StarMobileApi_h

//#define TAG "StarMobileAPI"

# include "SType.h"
#include "CspProtocol.h"
#include "CspTools.h"

typedef C8 STerminalTypeType;
static const STerminalTypeType                  S_TT_Android   = 'A';//Android
static const STerminalTypeType                  S_TT_IOS       = 'I';//IOS

STerminalTypeType G_SystemType;

//服务信息
typedef struct SServiceInfo
{
    int                          Src;
	C8                           Event;
    U32                          DataLen;
    C8                           Data[1];
} SServiceInfo;

//回调函数指针定义
typedef int (*S_SrvFunc)(SServiceInfo* service);

/**
 *  @brief 注册事件回调函数
 *
 *  @param func 回调函数指针
 *  @return 1: 注册成功；0: 注册失败或者已经注册
 *
 *  @details 注册事件回调函数，最多注册8组服务对象，超出返回失败，调用S_Init后方可使用
 */
int S_Event(S_SrvFunc func);

/**
 * @brief 初始化API
 * @param license 授权码
 * @param systemType 设备类型
 * @return 初始化结果
 */
int S_Init(const char* license, STerminalTypeType systemType);

/**
 * @brief 获取解密后的包号
 * @return 包号字符串
 */
char* S_GetPackageNo();

/**
 * @brief 创建一个线程用户维护一个新的socket连接
 * @param ip 地址
 * @param port 端口
 * @return 关键字，与socket连接一一映射
 */
int S_ConnectTcp(STcpIpType ip, STcpPortType port);

/**
 * @brief 关闭一个指定的socket连接
 * @param key 关键字
 * @return 断开结果
 */
int S_DisconnectTcp(int key);

/**
 *  释放一个TCP连接，用于行情登录，只断开，不从Hash表中删除
 * @param key
 * @return
 */
int S_CloseTcp(int key);

/**
 * @brief 向指定的socket发送数据
 * @param key 关键字
 * @param type 数据加密压缩类型
 * @param len 数据长度，包括SessionHead，不包括FrameHead
 * @param buf 明文数据，包括SessionHead，不包括FrameHead
 * @return 发送结果
 */
int S_SendMessage(int key, char type, int len, char* buf);

/**
 * @brief 发送链路认证请求
 * @param key 关键字
 * @param languageType 语言类型
 * @param subSystemType 协议号
 * @return 发送结果
 */
int S_SendAuthReq(int key, CspLanguageType languageType, CspSubSystemType subSystemType);

/**
 * @brief RSA公钥加密
 * @param input
 * @param inLen
 * @param output
 * @return
 */
int S_RsaPubEncrypt(C8* input, U32 inLen, C8* output);

/**
 * @brief RSA私钥解密
 * @param input
 * @param output
 * @return
 */
int S_RsaPriDecrypt(C8* input, CspRsaCommKeyType output);

int S_IsOpenTcp(int key);

int S_TcpClientFree(int key);
#endif /* StarMobileApi_h */