//
// Created by DELL on 2020/9/4.
//

#include <stdint.h>
#include <stdio.h>
#include <pthread.h>

#include "StarMobileApi.h"
#include "STcpClient.h"
#include "CspTools.h"
#include "PassEncrypt.h"
#include "SHash.h"
#include "ComUtils.h"
#include <android/log.h>

#define TAG "EsunnyNative" // 这个是自定义的LOG的标识
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG,TAG ,__VA_ARGS__) // 定义LOGD类型
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,TAG ,__VA_ARGS__) // 定义LOGI类型
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,TAG ,__VA_ARGS__) // 定义LOGW类型
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,TAG ,__VA_ARGS__) // 定义LOGE类型
#define LOGF(...) __android_log_print(ANDROID_LOG_FATAL,TAG ,__VA_ARGS__) // 定义LOGF类型

STerminalTypeType G_SystemType = S_TT_Android;

struct LicenseInfo G_LicenseInfo;

pthread_mutex_t          G_FuncMutex;
pthread_mutex_t          G_KeyMutex;
pthread_mutex_t          G_ClientMutex;

S_SrvFunc                G_SrvEventFunc;
SHash*                   G_Client = NULL;
int                      G_KeyIndex = 0;

int GetKey()
{
    pthread_mutex_lock(&G_KeyMutex);
    G_KeyIndex++;
    pthread_mutex_unlock(&G_KeyMutex);
    return G_KeyIndex;
}

SEleIndexType GetClient(int key, STcpClient** client)
{
    SEleIndexType index = SHash_FindI64(G_Client, key);
    if (index >= 0) {
        SHash_GetPtr(G_Client, index, (PTR) client);
    }

    return index;
}

int TriggerDataFunc(const C8 *buf, const STcpLenType len, STcpClient* client, const STcpActionType action)
{
    int size = sizeof(SServiceInfo);
    if (len > 0) {
        size += len - 1;
    }
    SServiceInfo *info;
    info = (SServiceInfo*)malloc(size);
//    memset(&info, 0, size);

    int key = STcpClient_GetKey(client);

    info->Src = key;
    info->Event = action;
    info->DataLen = len;
    if (len > 0) {
        memcpy(info->Data, buf, len + 1);
    }

    int ret = 0;
    if (G_SrvEventFunc) {
        ret = G_SrvEventFunc(info);
    }
    free(info);
    return ret;
}

//链路认证应答
void OnAuth(STcpClient* client, const STcpBufType buf, const STcpLenType len)
{
    //解析出回话密钥
    size_t headlen = sizeof(CspFrameHead)+sizeof(CspSessionHead);

    int ret = CspOnAuth(&buf[headlen], (len - headlen), G_RsaPriKey);
    if(ret < 0) return;

    CspAuthRsp *data = (CspAuthRsp*)&buf[headlen];

    STcpClient_SetIdeaKey(client, data);
}

STcpRetType RecvData(PTR client, STcpBufType buf, const size_t len)
{
//    CspFrameHead *head = (CspFrameHead*)&buf;
    CspSessionHead* sh = (CspSessionHead*)&buf[sizeof(CspFrameHead)];
    switch (sh->ProtocolCode) {
        case CMD_CSP_AuthRsp:  //认证应答 保存动态密码，发送登录包
        {
            OnAuth(client, buf, len);
            break;
        }
        default:
            break;
    }
    return TriggerDataFunc(&buf[sizeof(CspFrameHead)], (STcpLenType)len - sizeof(CspFrameHead), client, STCP_ACTION_RECVDATA);
}

STcpRetType TcpCallBack(STcpClient* client, STcpActionType action, STcpBufType buf, STcpLenType len)
{
    if (action == STCP_ACTION_RECVDATA) {
        CspFrameCallback cb;
        cb.func = (CspOnDataFunc) RecvData;

        CspIdeaKeyType key;
        if (STcpClient_getRecvKey(client, key) == 0) {
            cb.data = (PTR) key;
        }

        return CspOnFrame(client, buf, len, &cb);
    }

    TriggerDataFunc(NULL, 0, client, action);
    return 0;
}

int S_Init(const char* license, STerminalTypeType systemType)
{
    if(strlen(license) != 128)
        return S_INIT_LICENSEWRONG;

    char Decrypt[64] ={0};
    DecodePass((C8*)license, Decrypt);//解码授权码
    char *p = strchr(Decrypt, '&');
    if(p == NULL)
        return S_INIT_LICENSEWRONG;
    *p = '\0';
    strncpy(G_LicenseInfo.PackageNo, Decrypt, sizeof(G_LicenseInfo.PackageNo) - 1);
    if(strlen(G_LicenseInfo.PackageNo) != 6)
        return S_INIT_LICENSEWRONG;

    char *p1 = strchr(p+1, '&');
    if(p1 == NULL)
        return S_INIT_LICENSEWRONG;
    *p1 ='\0';
    strncpy(G_LicenseInfo.ProductName, "Yi Star", sizeof(G_LicenseInfo.ProductName) - 1);

    G_SystemType = systemType;

    G_Client = SHash_New();

    pthread_mutex_init(&G_FuncMutex, NULL);
    pthread_mutex_init(&G_KeyMutex, NULL);
    pthread_mutex_init(&G_ClientMutex, NULL);

    //注册信号
    signal(SIGPIPE, SIG_IGN);

    return 0;
}

int S_Event(S_SrvFunc func)
{
    if (NULL == func) return -1;

    pthread_mutex_lock(&G_FuncMutex);
    G_SrvEventFunc = func;
    pthread_mutex_unlock(&G_FuncMutex);

    return 0;
}

char* S_GetPackageNo()
{
    return G_LicenseInfo.PackageNo;
}

int S_ConnectTcp(STcpIpType ip, STcpPortType port)
{
    int key = GetKey();

    pthread_mutex_lock(&G_ClientMutex);

    SEleIndexType index = SHash_FindI64(G_Client, key);
    if (index >= 0) {
        pthread_mutex_unlock(&G_ClientMutex);
        return -1;
    }

    STcpClient* client;
    STcpClient_New(key, ip, port, TcpCallBack, &client);

    index = SHash_InsertI64(G_Client, key);
    SHash_SetPtr(G_Client, index, client);

    pthread_mutex_unlock(&G_ClientMutex);

    return key;
}

int S_DisconnectTcp(int key)
{
    pthread_mutex_lock(&G_ClientMutex);
    STcpClient* client = NULL;
    SEleIndexType index = GetClient(key, &client);
    pthread_mutex_unlock(&G_ClientMutex);

    if (index < 0) {
        return -1;
    }

    STcpClient_Close(client);

    SHash_Delete(G_Client, index);

    return 0;
}

// 行情登录只需要释放，不需要删除
int S_CloseTcp(int key) {
    pthread_mutex_lock(&G_ClientMutex);
    STcpClient* client = NULL;
    SEleIndexType index = GetClient(key, &client);
    pthread_mutex_unlock(&G_ClientMutex);

    if (index < 0) {
        return -1;
    }

    STcpClient_Close(client);

    return 0;
}

int S_SendMessage(int key, char type, int len, char* buf)
{
    pthread_mutex_lock(&G_ClientMutex);
    STcpClient* client = NULL;
    SEleIndexType index = GetClient(key, &client);
    pthread_mutex_unlock(&G_ClientMutex);

    if (index < 0) {
        return -1;
    }

    int ret = -3;
    switch (type) {
        case CSP_FRAME_PLAIN:
            ret = PhoneSendPlain(client, buf, len);
            break;
        case CSP_FRAME_LZO:
            ret = PhoneSendLzo(client, buf, len);
            break;
        case CSP_FRAME_IDEA: {
            CspIdeaKeyType sendKey;
            STcpClient_getSendKey(client, sendKey);

            ret = PhoneSendIdea(client, sendKey, buf, len);
        }
            break;
        case CSP_FRAME_LZO_IDEA: {
            CspIdeaKeyType sendKey;
            STcpClient_getSendKey(client, sendKey);

            ret = PhoneSendLzoIdea(client, sendKey, buf, len);
        }
            break;
        default:
            break;
    }
    return ret;
}

int S_SendAuthReq(int key, CspLanguageType languageType, CspSubSystemType subSystemType)
{
    pthread_mutex_lock(&G_ClientMutex);
    STcpClient* client = NULL;
    SEleIndexType index = GetClient(key, &client);
    pthread_mutex_unlock(&G_ClientMutex);

    if (index < 0) {
        return -1;
    }
    return AccessAuthReq(client, languageType, subSystemType);
}

int S_RsaPubEncrypt(C8* input, U32 inLen, C8* output)
{
    U32 key_len = 0;
    return CspRsaPubEncrypt(output, &key_len, input, inLen, G_RsaPubKey);
}

int S_RsaPriDecrypt(C8* input, CspRsaCommKeyType output)
{
    U32 outLen = 0;
    memset(output, 0, sizeof(CspRsaCommKeyType));

    return CspRsaPriDecrypt(output, &outLen, input, CSP_RSA_TEXT_LEN, G_RsaPriKey);
}

int S_IsOpenTcp(int key)
{
    pthread_mutex_lock(&G_ClientMutex);
    STcpClient* client = NULL;
    SEleIndexType index = GetClient(key, &client);
    pthread_mutex_unlock(&G_ClientMutex);

    if (index < 0) {
        return -1;
    }
    return STcpClient_IsOpen(client);
}

int S_TcpClientFree(int key)
{
    pthread_mutex_lock(&G_ClientMutex);
    STcpClient* client = NULL;
    SEleIndexType index = GetClient(key, &client);
    pthread_mutex_unlock(&G_ClientMutex);

    if (index < 0) {
        return -1;
    }
    STcpClient_Free(client);
}