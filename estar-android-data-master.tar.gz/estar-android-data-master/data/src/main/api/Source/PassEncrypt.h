#ifndef _PASS_ENCRYPT_
#define _PASS_ENCRYPT_
#include "../Others/IDEA.h"


#pragma pack(push, 1)

//错误码
typedef signed int                                              SErrorCodeType;
static const SErrorCodeType                                     S_LOGIN_TCPEXIST        =-1; //重复登录
static const SErrorCodeType                                     S_LOGIN_INITFAIL        =-2; //内部初始化错误
static const SErrorCodeType                                     S_LOGIN_SERVERVCLOSE    =-3; //云服务器维护中
static const SErrorCodeType                                     S_LOGIN_ADDRNOTEXIST    =-4; //云服务器暂不支持该期货公司地址
static const SErrorCodeType                                     S_INIT_ACCESSFAIL       =-5; //获取接入服务数据失败；
static const SErrorCodeType                                     S_INIT_QUOTEINITFAIL    =-6; //行情初始化失败；
static const SErrorCodeType                                     S_INIT_LICENSEWRONG     =-7; //证书不合法
static const SErrorCodeType                                     S_INIT_ACCOUNTEXIST     =-8; //账号已登录过其他地址

struct LicenseInfo
{
	char PackageNo[11];
	char ProductName[15];
	int BeginDate;
	int EndDate;
	char ReserveInfo[30];
};

void DecodePass(char* in_pass, char* out_pass);

#pragma pack(pop)


#endif
