//
//  SHash.c
//  StarMobileApi
//
//  Created by sss on 2017/4/14.
//  Copyright © 2017年 sss. All rights reserved.
//

#include <stdint.h>
#include "SHash.h"

typedef C8 SRealHashNodeFlagType;
const SRealHashNodeFlagType     HASH_NODE_EMPTY     = '\0';
const SRealHashNodeFlagType     HASH_NODE_DATA      = '\1';
const SRealHashNodeFlagType     HASH_NODE_DELETE    = '\2';

typedef struct SRealHashNode
{
    SRealHashNodeFlagType       Flag;
    C8                          Key[51];
    PTR                         Value;
} SRealHashNode;

typedef struct SRealHash
{
    SRealHashNode*               Data;
    SEleCountType                Len;
    SEleCountType                EleCount;
} SRealHash;

U32 SHash_BKDR_Code(C8* key)
{
    U32 code = 0;
    U32 ch = 0;
    while ((ch = (U32)*key++))
    {
        code = code * 131 + ch;
        // 也可以乘以31、131、1313、13131、131313..
        // 有人说将乘法分解为位运算及加减法可以提高效率，如将上式表达为：
    }
    return code;
}

void SHash_Expand_Init(SRealHash* rhash, SRealHash* nhash)
{
    nhash->Len = (rhash->Len > 0) ? rhash->Len * 2 : 16;
    nhash->EleCount = 0;
    nhash->Data = (SRealHashNode*)malloc(nhash->Len * sizeof(SRealHashNode));
    memset(nhash->Data, 0, nhash->Len * sizeof(SRealHashNode));
}

void SHash_Expand_I64(SRealHash* rhash)
{
    SRealHash nhash;
    SHash_Expand_Init(rhash, &nhash);
    
    if (rhash->EleCount > 0)
    {
        for(int i = 0; i < rhash->Len; i++)
        {
            SRealHashNode* node = &rhash->Data[i];
            if (HASH_NODE_DATA != node->Flag)
                continue;
            
            SEleIndexType index = SHash_InsertI64((SHash*)&nhash, *(I64*)node->Key);
            if (index >= 0)
                SHash_SetPtr((SHash*)&nhash, index, node->Value);
        }
    }
    
    free(rhash->Data);
    *rhash = nhash;
}

void SHash_Expand_Str(SRealHash* rhash)
{
    SRealHash nhash;
    SHash_Expand_Init(rhash, &nhash);
    
    if (rhash->EleCount > 0)
    {
        for(int i = 0; i < rhash->Len; i++)
        {
            SRealHashNode* node = &rhash->Data[i];
            if (HASH_NODE_DATA != node->Flag)
                continue;
            
            SEleIndexType index = SHash_InsertStr((SHash*)&nhash, node->Key);
            if (index >= 0)
                SHash_SetPtr((SHash*)&nhash, index, node->Value);
        }
    }
    
    free(rhash->Data);
    *rhash = nhash;
}

SHash* SHash_New()
{
    SRealHash* hash = (SRealHash*)malloc(sizeof(SRealHash));
    hash->Data = NULL;
    hash->Len = 0;
    hash->EleCount = 0;
    
    SHash_Expand_I64(hash);
    
    return (SHash*)hash;
}

SCollRetType SHash_Free(SHash* hash)
{
    SRealHash* rhash = (SRealHash*)hash;
    free(rhash->Data);
    free(rhash);
    
    return 0;
}

void SHash_Free_Item(SHash *hash)
{
    SRealHash* rhash = (SRealHash*)hash;
    
    SEleIndexType index = SHash_Begin(hash);
    
    while(1)
    {
        if (index < 0 || index >= rhash->Len)
            break;
        
        SRealHashNode* node = &rhash->Data[index];
        if(node->Value)
        {
            free(node->Value);
            node->Value = NULL;
        }
        
        memset(node->Key, 0, sizeof(node->Key));
        node->Flag = HASH_NODE_EMPTY;
        
        index = SHash_Next(hash, index);
    }
}

void SHash_Release(SHash* hash)
{
    SHash_Free_Item(hash);
    SHash_Free(hash);
}

SEleCountType SHash_Count(SHash* hash)
{
    SRealHash* rhash = (SRealHash*)hash;
    
    return rhash->EleCount;
}

SCollRetType SHash_Clear(SHash* hash)
{
    //SHash_Free_Item(hash);
    SRealHash* rhash = (SRealHash*)hash;
    if (rhash->EleCount > 0)
    {
        memset(rhash->Data, 0, rhash->Len * sizeof(SRealHashNode));
        rhash->EleCount = 0;
    }
    
    return 0;
}

SCollRetType SHash_Delete(SHash* hash, SEleIndexType index)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index < 0 || index >= rhash->Len)
        return -2;
    
    SRealHashNode* node = &rhash->Data[index];
    node->Flag = HASH_NODE_DELETE;

    return 0;
}

SEleIndexType SHash_Begin(SHash* hash)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (rhash->EleCount <= 0)
        return -2;
    
    for(SEleIndexType i = 0; i < rhash->Len; i++)
    {
        SRealHashNode* node = &rhash->Data[i];
        if (HASH_NODE_DATA == node->Flag)
            return i;
    }
    
    return -1;
}

SEleIndexType SHash_Next(SHash* hash, SEleIndexType index)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index  < 0 || index >= rhash->Len)
        return -2;
    
    for(SEleIndexType i = index + 1; i < rhash->Len; i++)
    {
        SRealHashNode* node = &rhash->Data[i];
        if (HASH_NODE_DATA == node->Flag)
            return i;
    }
    
    return -1;
}

SEleIndexType SHash_FindI64(SHash* hash, I64 key)
{
    SRealHash* rhash = (SRealHash*)hash;
    
    SEleIndexType h1 = key % rhash->Len;
    SEleIndexType h2 = ((h1 >> 1) & 0xFFFFFFFE) + 1;  //保证奇数，跳跃范围约为基础索引的一半
    
    for(SEleIndexType i = 0; i < rhash->Len / 2; i++)
    {
        SEleIndexType index = (h1 + i * h2) % rhash->Len;
        SRealHashNode* node = &rhash->Data[index];
        switch(node->Flag)
        {
            case HASH_NODE_EMPTY:
                return -1;
                break;
            case HASH_NODE_DATA:
                if (*(I64*)node->Key == key)
                    return index;
                break;
            default:
                break;
        }
    }
    
    return -1;
}

SEleIndexType SHash_FindStr(SHash* hash, C8* key)
{
    SRealHash* rhash = (SRealHash*)hash;
    
    SEleIndexType h1 = SHash_BKDR_Code(key) % rhash->Len;
    SEleIndexType h2 = ((h1 >> 1) & 0xFFFFFFFE) + 1;  //保证奇数，跳跃范围约为基础索引的一半
    
    for(SEleIndexType i = 0; i < rhash->Len / 2; i++)
    {
        SEleIndexType index = (h1 + i * h2) % rhash->Len;
        SRealHashNode* node = &rhash->Data[index];
        switch(node->Flag)
        {
            case HASH_NODE_EMPTY:
                return -1;
                break;
            case HASH_NODE_DATA:
                if (0 == strncmp(node->Key, key, sizeof(node->Key)-1))
                    return index;
                break;
            default:
                break;
        }
    }
    
    return -1;
}

SEleIndexType SHash_InsertI64(SHash* hash, I64 key)
{
    SRealHash* rhash = (SRealHash*)hash;
    
    SEleIndexType h1 = key % rhash->Len;
    SEleIndexType h2 = ((h1 >> 1) & 0xFFFFFFFE) + 1;  //保证奇数，跳跃范围约为基础索引的一半
    
    for(SEleIndexType i = 0; i < rhash->Len / 2; i++)
    {
        SEleIndexType index = (h1 + i * h2) % rhash->Len;
        SRealHashNode* node = &rhash->Data[index];
        if (HASH_NODE_DATA != node->Flag)
        {
            node->Flag = HASH_NODE_DATA;
            *(I64*)node->Key = key;
            rhash->EleCount++;
            return index;
        }
    }
    
    SHash_Expand_I64(rhash);
    
    return SHash_InsertI64(hash, key);
}

SEleIndexType SHash_InsertStr(SHash* hash, C8* key)
{
    SRealHash* rhash = (SRealHash*)hash;
    
    SEleIndexType h1 = SHash_BKDR_Code(key) % rhash->Len;
    SEleIndexType h2 = ((h1 >> 1) & 0xFFFFFFFE) + 1;  //保证奇数，跳跃范围约为基础索引的一半
    
    for(SEleIndexType i = 0; i < rhash->Len / 2; i++)
    {
        SEleIndexType index = (h1 + i * h2) % rhash->Len;
        SRealHashNode* node = &rhash->Data[index];
        if (HASH_NODE_DATA != node->Flag)
        {
            node->Flag = HASH_NODE_DATA;
            memset(node->Key, 0, sizeof(node->Key));
            strncpy(node->Key, key, sizeof(node->Key) - 1);
            rhash->EleCount++;
            return index;
        }
    }
    
    SHash_Expand_Str(rhash);
    
    return SHash_InsertStr(hash, key);
}

SEleIndexType SHash_GetKey(SHash* hash,SEleIndexType index, C8* key, int length)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index < 0 || index >= rhash->Len)
        return -2;
    
    SRealHashNode* node = &rhash->Data[index];
    if (HASH_NODE_DATA == node->Flag)
    {

        strncpy(key, node->Key, length);
//        strcpy(key, node->Key);
        return index;
    }
    
    return -1;
}

SCollRetType SHash_GetI64(SHash* hash, SEleIndexType index, I64* value)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index < 0 || index >= rhash->Len)
        return -2;
    
    SRealHashNode* node = &rhash->Data[index];
    if (HASH_NODE_DATA != node->Flag)
        return -3;
    
    *value = (I64)node->Value;
    
    return 0;
}

SCollRetType SHash_SetI64(SHash* hash, SEleIndexType index, I64 value)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index < 0 || index >= rhash->Len)
        return -2;
    
    SRealHashNode* node = &rhash->Data[index];
    if (HASH_NODE_DATA != node->Flag)
        return -3;
    
    node->Value = (PTR)value;
    
    return 0;
}

SCollRetType SHash_GetF64(SHash* hash, SEleIndexType index, F64* value)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index < 0 || index >= rhash->Len)
        return -2;
    
    SRealHashNode* node = &rhash->Data[index];
    if (HASH_NODE_DATA != node->Flag)
        return -3;
    
    *value = *(F64*)&node->Value;
    
    return 0;
}

SCollRetType SHash_SetF64(SHash* hash, SEleIndexType index, F64 value)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index < 0 || index >= rhash->Len)
        return -2;
    
    SRealHashNode* node = &rhash->Data[index];
    if (HASH_NODE_DATA != node->Flag)
        return -3;
    
    *(F64*)&node->Value = value;
    
    return 0;
}

SCollRetType SHash_GetPtr(SHash* hash, SEleIndexType index, PTR* value)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index < 0 || index >= rhash->Len)
        return -2;
    
    SRealHashNode* node = &rhash->Data[index];
    if (HASH_NODE_DATA != node->Flag)
        return -3;
    
    *value = node->Value;
    
    return 0;
}

SCollRetType SHash_SetPtr(SHash* hash, SEleIndexType index, PTR value)
{
    SRealHash* rhash = (SRealHash*)hash;
    if (index < 0 || index >= rhash->Len)
        return -2;
    
    SRealHashNode* node = &rhash->Data[index];
    if (HASH_NODE_DATA != node->Flag)
        return -3;
    
    node->Value = value;
    
    return 0;
}

