#ifndef PKG_PROTOCOL_TYPE_H
#define PKG_PROTOCOL_TYPE_H		

#define FIELD_MAX(x)			(( CSP_FRAME_MAX / sizeof(x) - 5 < 1000)? ( CSP_FRAME_MAX / sizeof(x) - 5) : 1000)


typedef		C8                          PkgQuoteTypeType;
static const		PkgQuoteTypeType            PkgRealTimeQuote = 'Q';
static const		PkgQuoteTypeType            PkgHistoryQuote = 'H';


typedef		C8                      PkgTradeServerType;
static const		PkgTradeServerType      PkgTradeFront = 'f';
static const		PkgTradeServerType      PkgTradeNameServer = 'n';
static const       PkgTradeServerType      PkgTradeServer = 't';

typedef		C8				    PkgTerminalOSType;

static const		PkgTerminalOSType           PkgWindows = 'W';
static const		PkgTerminalOSType           PkgAndroid = 'A';
static const		PkgTerminalOSType           PkgIOS = 'I';

typedef		C8				    PkgUserType;
static const		PkgUserType             PkgTrader = 'f';
static const		PkgUserType             PkgBroker = 'b';
static const       PkgUserType             PkgClient = 'c';
static const       PkgUserType             PkgOrder = 'd';


typedef     U16                 PkgLangType;

static const       PkgLangType           PkgLangNone= 0x0000;

static const       PkgLangType           PkgLangCHT = 0x0404;

static const       PkgLangType           PkgLangCHS = 0x0804;

static const       PkgLangType           PkgLangENU = 0x0409;

typedef     C8                       PkgYesOrNoType;
static const     PkgYesOrNoType           PkgRunningStateYes        ='Y';
static const     PkgYesOrNoType           PkgRunningStateNo         ='N';



typedef      C8                       PkgTradeAddrType;
static const		PkgTradeAddrType          PkgAddrTest              = 'T';
static const		PkgTradeAddrType          PkgAddrReal              = 'R';

typedef      C8                       PkgPlateCodeAttrType;

static const		PkgPlateCodeAttrType       PkgRealContract         = 'R';
static const		PkgPlateCodeAttrType       PkgVirtualContract      = 'V';
static const       PkgPlateCodeAttrType       PkgCommodity            = 'C';

typedef     C8                        PkgTerminalType;
static const        PkgTerminalType           PkgPCTerminal              = 'C';
static const        PkgTerminalType           PkgMobileTerminal          = 'M';

typedef     C8                        PkgOpenCompanyType;      //默认内盘
static const		PkgOpenCompanyType           PkgInternal            = 'I';
static const		PkgOpenCompanyType           PkgExternal            = 'E';
static const		PkgOpenCompanyType           PkgAll                 = 'A';

typedef     I32                     PkgIntType;
typedef     C8                      PkgProtocolVerType;
typedef     STR10                   PkgPackageNoType;
typedef     STR10                   PkgCompanyNoType;
typedef     STR20                   PkgLicenseNoType;

typedef     C8                      STR500[501];
typedef     STR20                   PkgAddrNoType;
typedef     STR50                   PkgNameType;
typedef     STR50                   PkgIPType;                        
typedef     U16                     PkgPortType;
typedef     STR20                   PkgTradeApiType;
typedef     STR10                   PkgBrokerIdType;
typedef     STR20                   PkgCertStrType;
typedef     U16                     PkgOrderType;
typedef     STR10                   PkgGroupNoType;
typedef     STR50                   PkgGroupNameType;
typedef     STR20                   PkgLinkType;
typedef     STR500                  PkgUrlType;
typedef     STR50                   PkgRemarkType;

typedef     STR50                   PkgCodeType;
typedef     F64                     PkgPriceType;
typedef     STR20                   PkgPlateNoType;
typedef     STR20                   PkgPluginNoType;

typedef     STR20                   PkgConfigSwitchTemplateType;
typedef     STR50                   PkgConfigSwitchNoType;
typedef     U16                     PkgValueType;

typedef     STR20                   PkgDeveloperNoType;

typedef     STR20                   PkgCommodityType;

typedef     U16                     PkgOptionWidthType;

typedef     STR10                   PkgDateType;

typedef     STR50                   PkgOperatorType;

typedef     STR20                   PkgOperatorTimeType;

typedef     STR200                  PkgContractNumberType;

typedef     STR20                   PkgVersionType;

typedef     STR300                  PkgUpdateInfoType;

typedef     STR20                   PkgTimeType;

typedef     STR100                  PkgImgUrlType;

typedef     STR10                   PkgOpenCodeType;

typedef     STR100                  PkgOpenUrlType;

typedef     STR10                   PkgOsType;

typedef      U64                    PkgMsgNotifyId;
typedef      C8                     PkgMsgNotifyType;

typedef     STR300                  PkgMsgNotifyData;

static const       CspErrorCodeType        PkgCallSqlProcedureFail  = 1;

static const       CspErrorCodeType        PkgNotSupportProtocol  = 2;



#endif
