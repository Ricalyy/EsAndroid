#ifndef _REG_PROTOCOL_TYPE_H_
#define _REG_PROTOCOL_TYPE_H_

#include "CspProtocol.h"
#pragma pack(push, 1)

#define REG_FIELD_MAX(x)			(( CSP_FRAME_MAX / sizeof(x) - 5 < 1000)? ( CSP_FRAME_MAX / sizeof(x) - 5) : 1000)
//======================================错误号===========================================
//登录相关
static const CspErrorCodeType                 REG_ERROR_LOGON               = 10001;                    //登录过程执行错误
static const CspErrorCodeType                 REG_ERROR_LOGON_NAME          = 10002;                    //用户名不存在
static const CspErrorCodeType                 REG_ERROR_LOGON_PASS          = 10003;                    //用户密码不正确
static const CspErrorCodeType                 REG_ERROR_LOGON_FROZEN        = 10004;                    //用户已被冻结
static const CspErrorCodeType                 REG_ERROR_LOGON_OVERRUN       = 10005;                    //用户超限


//注册相关
static const CspErrorCodeType                 REG_ERROR_REGISTER_EMPTY           = 10011;                    //字段填写为空
static const CspErrorCodeType                 REG_ERROR_REGISTER_USER_EXIST      = 10012;                    //用户名被注册
static const CspErrorCodeType                 REG_ERROR_REGISTER_EMAIL_EXIST     = 10013;                    //数据格式不正确
static const CspErrorCodeType                 REG_ERROR_REGISTER_PHONE_EMPTY     = 10014;                    //手机为空
static const CspErrorCodeType                 REG_ERROR_REGISTER_PASS_ERROR      = 10015;                    //原始密码错误

static const CspErrorCodeType                 REG_ERROR_SQL_EXCEPTION         = 10021;                    //存储过程执行异常


//++++++++++++++++++++++++++++++++++++++用户登录++++++++++++++++++++++++++++++++++++++++++++
typedef C8                                  RegLoginTypeType;                           //登录用户类型
static const RegLoginTypeType               REG_LOGINTYPE_ANONYMOUS         = 'A';      //匿名用户登录
static const RegLoginTypeType               REG_LOGINTYPE_CLIENT            = 'C';      //普通用户登录(不通过行情前置)
static const RegLoginTypeType               REG_LOGINTYPE_WEB               = 'W';      //网站普通用户登录
static const RegLoginTypeType               REG_LOGINTYPE_SERVER            = 'S';      //服务器登录
static const RegLoginTypeType               REG_LOGINTYPE_QUOTE             = 'Q';      //行情登陆;
static const RegLoginTypeType               REG_LOGINTYPE_API               = 'P';      //API登陆;
static const RegLoginTypeType               REG_LOGINTYPE_MOBILE            = 'M';      //手机端登录;

typedef C8                                  RegOperateType;
static const RegOperateType                 REG_OP_YES                      = 1;      
static const RegOperateType                 REG_OP_NO                       = 0;  

//++++++++++++++++++++++++++++++++++++++用户信息相关++++++++++++++++++++++++++++++++++++++++++++
typedef C8                                  RegUserStateType;                           //用户状态
static const RegUserStateType               REG_USERSTATE_NORMAL            = 'N';      //正常
static const RegUserStateType               REG_USERSTATE_FROZEN            = 'F';      //冻结(若用户为该状态则登录失败)

typedef C8                                  RegIndexStateType;                          //指数状态
static const RegIndexStateType              REG_INDEXINFO_NORMAL            = 'N';      //正常
static const RegIndexStateType              REG_INDEXINFO_HANG              = 'H';      //挂起,即不允许查询

typedef C8                                  RegIndexAccessType;                         //指数访问权限
static const RegIndexAccessType             REG_INDEXACCESS_PUBLIC          = 'P';      //公共，即都可以访问
static const RegIndexAccessType             REG_INDEXACCESS_PRIVATE         = 'V';      //私有，即需要权限



typedef C8                                 RegAuditStatusType;                        //品种组操作类型
static const RegAuditStatusType            REG_AUDIT_APPLY                  = 'A';     //申请
static const RegAuditStatusType            REG_AUDIT_PASS                   = 'P';     //通过 
static const RegAuditStatusType            REG_AUDIT_REJECT                 = 'R';     //拒绝

typedef C8                                 RegGroupOperateType;                        //品种组操作类型
static const RegGroupOperateType           REG_GROUPOPERATE_AUDIT          = 'A';      //申请后等待审核   
static const RegGroupOperateType           REG_GROUPOPERATE_BUY            = 'B';
static const RegGroupOperateType           REG_GROUPOPERATE_TRY            = 'T';      //试用


typedef STR50                               RegEMailType;                               //邮箱地址类型

typedef STR10                              RegCountryNoType;

typedef STR20                              RegMobilePhoneType;                         //手机号类型

typedef  C8                                RegSaltType[7];

typedef STR100                             RegRemarkType;                              //备注类型

typedef STR50                               RegOperatorType;                            //操作者用户名类型

typedef STR200                              RegReserveInfoType;                         //预留信息

typedef STR200                              RegDistrictType;

typedef U32                                 RegSerialIdType;                            //序列号

typedef STR10                               RegCompanyNoType;

typedef STR10                               RegPackageNoType;                           //包信息;

typedef STR50                               RegLoginNoType;                             //登录名，可为用户名、邮箱、手机号

typedef STR50                               RegPasswordType;                            //登录密码

typedef STR10                               RegUUIdType;                                //用户唯一ID

typedef U32                                 RegLoginDateType;                           //登陆日期.如20170101

typedef STR50                               RegLoginIPType;

typedef SDATETIME                           RegLoginTimeType;

typedef STR50                               RegLoginServerNameType;

typedef STR50                               RegDeveloperNoType;

typedef STR20                               RegPluginNoType;

typedef U32                                 RegLoginCountType;                          //用户最大登录数

typedef STR50                               RegIndexNoType;                             //指数编号

typedef STR50                               RegIndexNameType;                           //指数名称

typedef STR50                               RegTradeNoType;

typedef  STR50                              RegStrType;

typedef  U32                                RegIntType;

typedef  F64                                RegDoubleType;

typedef  SDATETIME                          RegTimeType;

typedef  SDATE                              RegDateType;

typedef STR20                               RegGroupNoType;                             //品种组号

typedef F64                                 RegPriceType;                               //价格类型


#pragma pack(pop)

#endif
