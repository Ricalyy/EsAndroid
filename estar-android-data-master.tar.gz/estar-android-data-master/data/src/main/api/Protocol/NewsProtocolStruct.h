#pragma once
#include "NewsProtocolType.h"
//新闻分类
static const CspProtocolCodeType            CMD_NEWS_NewsClass_Req = 0x1000;

static const CspProtocolCodeType            CMD_NEWS_NewsClass_Rsp = 0x1001;


typedef struct NEWSClassQryReq
{
    NewsLangType                        Lang;
}NEWSClassQryReq;

typedef struct NEWSClassQryRsp
{
    NEWSIntType                        NewsClassID;
    NEWSIntType                        NewsParentID;
    NEWSLanguageType                   NewsLanguage;
    NEWSStrType                        NewsClass;
}NEWSClassQryRsp;


//新闻内容查询
static const CspProtocolCodeType     CMD_NEWS_NewsAbstract_Req = 0x1010;

static const CspProtocolCodeType     CMD_NEWS_NewsAbstract_Rsp = 0x1011;



typedef struct NEWSAbstractQryReq
{
    NEWSIntType                        NewsClassID;
    NEWSIntType                        NewsID;
    NEWSIntType                        Count;
    NEWSQryDirectionType               Direction;
}NEWSAbstractQryReq;

typedef struct NEWSAbstractQryRsp
{
    NEWSIntType                        NewsID;
    NEWSTitleType                      NewsTitle;
    NEWSStrType                        NewsSource;
    NEWSIntType                        NewsClassID;
    NEWSDateTimeType                   NewsPublishTime;
    
}NEWSAbstractQryRsp;


//新闻内容查询
static const CspProtocolCodeType    CMD_NEWS_NewsTag_Qry_Req    = 0x1020;

static const CspProtocolCodeType    CMD_NEWS_NewsTag_Qry_Rsp    = 0x1021;


typedef struct NEWSTagQryReq
{
    NEWSTagType                        NewsTag;
    NEWSIntType                        NewsID;
    NEWSIntType                        Count;
    NEWSQryDirectionType               Direction;
    NEWSPackageNoType                  PackageNo;
}NEWSKeyQryReq;

typedef struct NEWSTagQryRsp
{
    NEWSIntType                     NewsID;
    NEWSTitleType                   NewsTitle;
    NEWSStrType                     NewsTag;
    NEWSIntType                     NewsClassID;
    NEWSDateTimeType                NewsPublishTime;
    NEWSTopType                     NewsTop;
    NEWSColorType                   NewsColor;
}NEWSKeyQryRsp;

//新闻内容查询
static const CspProtocolCodeType			CMD_NEWS_Commodity_Qry_Req    = 0x1030;

static const CspProtocolCodeType			CMD_NEWS_Commodity_Qry_Rsp    = 0x1031;

typedef struct NEWSCommodityQryReq
{
    NewsLangType                    Lang;               //语言类型
    NEWSCommodity                   Commodity;          //填写品种信息

}NEWSCommodityQryReq;

typedef struct NEWCommodityQryRsp
{
    NewsTradeCommodityName          TradeCommodity;     //交易品种
    NewsUnitType                    Unit;               //交易单位
    NewsUnitType                    OffUnit;            //报价单位
    NewsTickType                    Tick;               //最小变动价
    NewsRaisingLimitType            RaisingLimit;       //涨跌停板幅度
    NewsTradingMarginType           TradingMargin;      //最低交易保证金
    NewsContractMonthType           ContractMonth;      //合约月份
    NewsTradingTimeType             TradingTime;        //交易时间
    NewsTradingDateType             LastTradingDate;    //最后交易日
    NewsDeliveryDateType             LastDeliveryDate;   //交割日期
    NewsDeliveryGradeType           DeliveryGrade;      //交割等级
    NewsDeliverySiteType            DeliverySite;       //交割地点
    NewsDeliveryMethodType          DeliveryMethod;     //交割方式
    NewsDeliveryUnitType            DeliveryUnit;        //交割单位
    NewsTradeCodeType               TradeCode;           //交易代码
    NewsExchangeType                Exchange;            //上市交易所

}NEWCommodityQryRsp;

typedef struct NEWSTCReportQryReq
{
    NEWSContractType                Contract;   //填写主力合约
    NEWSTimeType                    TimeRange;

}NEWSTCReportQryReq;


static const CspProtocolCodeType			CMD_NEWS_TCContract_Qry_Req    = 0x1040;

static const CspProtocolCodeType			CMD_NEWS_TCContract_Qry_Rsp    = 0x1041;


typedef struct NEWSTCContractQryReq
{

}NEWSTCContractQryReq;

typedef struct NEWSTCContractQryRsp
{
    NEWSContractType                Contract;   //填写主力合约
    NEWSTimeType                    TimeRange;
} NEWSTCContractQryRsp;


static const CspProtocolCodeType           CMD_NEWS_TCReport_Qry_Req = 0x1050;

static const CspProtocolCodeType           CMD_NEWS_TCReport_Qry_Rsp = 0x1051;

typedef struct NEWSTCReportQryRsp
{
    NEWSContractType                Contract;   //填写主力合约
    NEWSTimeType                    TimeRange;
    NewsPriceType                   Resistance3;
    NewsPriceType                   Resistance2;
    NewsPriceType                   Resistance1;
    NewsPriceType                   Last;
    NewsPriceType                   Pivot;
    NewsPriceType                   Support1;
    NewsPriceType                   Support2;
    NewsPriceType                   Support3;
    NewsTcReportType                TcReport;
    NEWSDateTimeType                TcTime;

}NEWSTCReportQryRsp;


