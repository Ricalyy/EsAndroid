/* 
 * File:   TrdProtocolStruct.h
 * Author: Mingxiang Liu
 * 功能:   极星综合业务平台之交易协议头文件
 * 注意：  协议号定义规则——前两位表示业务分类，后两位自增
 *
 * Created on 2017年08月29日, 下午1:45
 */

#ifndef TRD_PROTOCOL_STRUCT_H
#define TRD_PROTOCOL_STRUCT_H


#pragma pack(push, 1)

static const CspProtocolVerType TRD_PROTOCOL_VER					= 6;		//交易协议版本号

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Login_REQ					= 0x0100;	//客户登录请求
static const CspProtocolCodeType CMD_TRD_Login_RSP					= 0x0101;	//客户登录应答
static const CspProtocolCodeType CMD_TRD_Logout_REQ					= 0x0102;	//客户登出请求
static const CspProtocolCodeType CMD_TRD_Logout_RTN					= 0x0103;	//客户登出通知

//key = CompanyNo + CompanyAddressNo + LoginNo
typedef struct TrdLoginReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdCompanyAddressNoType				CompanyAddressNo;						//登录地址编号	
	TrdLoginNoType						LoginNo;								//登录账号
	TrdTradePswType						LoginPsw;								//登录密码
	TrdTradePswType 					NewPsw;									//强制初始化密码
	TrdTerminalTypeType 				TerminalType;							//终端类型
    TrdAppCodeType AppCode;                                //Api版本号
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	TrdLoginInfoType					LoginInfo;								//客户登录信息(用户定位，手机号、IP、MAC等)
    
    TrdSystemInfoType                   SystemInfo;                             //用户端系统内部信息
    TrdSystemInfoLenType                SystemInfoLen;                          //用户端系统内部信息长度
	TrdSystemInfoIntegrityType          SystemInfoIntegrity;                    //采集信息完整度（恒生）
	TrdSystemInfoFlag                   SystemInfoFlag;                         //系统信息标识（恒生，填异常标识，启明星，版本号）
    TrdAppCodeType AppVersionCode;                         //App版本号
} TrdLoginReq;
typedef struct TrdLoginRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdCompanyAddressNoType				CompanyAddressNo;						//登录地址编号	
	TrdLoginNoType						LoginNo;								//登录账号
	TrdTerminalTypeType 				TerminalType;							//终端类型
	TrdAppCodeType						AppCode;								//客户端软件标识码

	TrdLoginNameType 					LoginName;								//登录帐号名称
	TrdLoginInfoType					LastLoginInfo;							//上次登录信息, 机器地址、登录和退出时间等
	TrdDateType 						TradeDate;								//当前交易日
	TrdDateTimeType 					LastSettleTime;							//最后结算日
	TrdDateTimeType 					StartTime;								//会员系统启动时间
	TrdDateTimeType 					InitTime;								//会员系统初始化时间

	TrdBoolType							ForceChgPsw;							//是否需要强制修改密码	
	TrdSessionNoType					SessionNo;								//会话编号
	
	TrdCompanyApiType					CompanyApi;								//经纪公司系统类型

	TrdErrorTextType                   ErrorText;                               //错误信息
} TrdLoginRsp;

typedef struct TrdLogoutReq
{
} TrdLogoutReq;

typedef struct TrdLogoutRtn
{}TrdLogoutRtn;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Commodity_QRY_REQ			= 0x0200;	//后台品种查询请求
static const CspProtocolCodeType CMD_TRD_Commodity_QRY_RSP			= 0x0201;	//后台品种查询应答

typedef struct TrdCommodityQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
} TrdCommodityQryReq;
//返回交易所编号或品种编号，返回交易所编号标示支持该交易所下的所有合约，返回品种编号标识支持该品种下的所有合约，具体合约以行情为准
typedef struct TrdCommodityQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
    union
    {
		TrdExchangeNoType				ExchangeNo;								//交易所编号
		TrdCommodityNoType				CommodityNo;							//品种编号    	
    };
	TrdUserNoType						UserNo;									//资金帐号
} TrdCommodityQryRsp;

////////////////////////////////////////////////////////////////
//客户登录之后，后台主动查询系统参数，通过CMD_TRD_SystemParam_RTN给客户端推送
static const CspProtocolCodeType CMD_TRD_SystemParam_QRY_REQ    = 0x2200;    //系统参数查询请求
static const CspProtocolCodeType CMD_TRD_SystemParam_QRY_RSP    = 0x2201;    //系统参数查询应答
static const CspProtocolCodeType CMD_TRD_SystemParam_RTN        = 0x2202;    //系统参数通知

static const CspProtocolCodeType CMD_TRD_ASXParam_RTN        = 0x2300;      //澳交所系统参数通知

//保证金参数查询请求
typedef struct TrdSystemParamQryReq
{
} TrdSystemParamQryReq;
//保证金参数查询应答
typedef struct TrdASXParamQryRsp
{
    STR10                   ItemNo;             ///< 项目编号
    STR20                   CommodityNo;        ///< 品种编号
    I32                     ItemValue;          ///< 项目值（周期数-c）
	I32                   ItemValue2;         ///< 项目值字符串类型值（计息次数-Num）
    F64                     ItemValueDouble;    ///< 项目值浮点型数据值（周期利率-Ratio）
} TrdASXParamQryRsp;

typedef TrdASXParamQryRsp            TrdASXParamRtn;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Currency_QRY_REQ			= 0x0300;	//币种信息查询请求
static const CspProtocolCodeType CMD_TRD_Currency_QRY_RSP			= 0x0301;	//币种信息查询应答
static const CspProtocolCodeType CMD_TRD_Currency_RTN				= 0x0302;	//币种信息通知

typedef struct TrdCurrencyQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
} TrdCurrencyQryReq;
//key = CompanyNo + CurrencyGroupNo + CurrencyNo
typedef struct TrdCurrencyQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdCurrencyGroupNoType				CurrencyGroupNo;						//币种组编号
	TrdCurrencyNoType					CurrencyNo;								//币种编号 
	TrdBoolType							IsShare;								//是否与其他币种共享计算 
	TrdExchangeRateType					USDExchangeRate;						//美元交易汇率
	TrdExchangeRateType					HKDExchangeRate;						//港币交易汇率
	TrdUserNoType						UserNo;									//资金帐号
} TrdCurrencyQryRsp;
typedef TrdCurrencyQryRsp				TrdCurrencyRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_OrderInsert_REQ			= 0x0400;	//下单请求
static const CspProtocolCodeType CMD_TRD_OrderInsert_RSP			= 0x0401;	//下单应答
static const CspProtocolCodeType CMD_TRD_Order_RTN					= 0x0402;	//定单信息通知
static const CspProtocolCodeType CMD_TRD_Order_QRY_REQ				= 0x0403;	//定单查询请求
static const CspProtocolCodeType CMD_TRD_Order_QRY_RSP				= 0x0404;	//定单查询应答
static const CspProtocolCodeType CMD_TRD_Order_QRY_DATA				= 0x0405;	//定单查询数据应答
static const CspProtocolCodeType CMD_TRD_Order_DEL_RTN				= 0x0406;	//定单删除通知
static const CspProtocolCodeType CMD_TRD_Order_ACT_REQ_OUT			= 0x0407;	//定单操作请求, 废弃版本，不再使用
static const CspProtocolCodeType CMD_TRD_Order_ACT_RSP_OUT			= 0x0408;	//定单操作应答, 废弃版本，不再使用
static const CspProtocolCodeType CMD_TRD_StrategyOrder_QRY_REQ		= 0x0409;	//策略单查询请求
static const CspProtocolCodeType CMD_TRD_StrategyOrder_QRY_RSP		= 0x040A;	//策略单查询应答
static const CspProtocolCodeType CMD_TRD_StrategyOrder_QRY_DATA		= 0x040B;	//策略单查询数据应答
static const CspProtocolCodeType CMD_TRD_Order_ACT_REQ				= 0x040C;	//定单操作请求
static const CspProtocolCodeType CMD_TRD_Order_ACT_RSP				= 0x040D;	//定单操作应答
static const CspProtocolCodeType CMD_TRD_Order_MDF_REQ				= 0x040E;	//定单修改请求
static const CspProtocolCodeType CMD_TRD_Order_MDF_RSP				= 0x040F;	//定单修改应答

//下单请求
typedef struct TrdOrderInsertReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	
	TrdContractNoType 					ContractNo;								//合约编号
	TrdOrderTypeType					OrderType;								//定单类型 
	TrdOrderWayType						OrderWay;								//委托来源 
	TrdValidTypeType					ValidType;								//有效类型 
	TrdDateTimeType						ValidTime;								//有效日期时间(GTD情况下使用)
	TrdDirectType						Direct;									//买卖方向 
	TrdOffsetType						Offset;									//开仓 平仓 开平 平开(内盘)
	TrdHedgeType						Hedge;									//投机保值(内盘)
	union
	{
		TrdPriceType					OrderPrice;								//委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
		TrdPriceType					OrderPriceOver;							//委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)
	};
	TrdQuantityType						OrderQty;								//委托数量 或 期权应价数量
	
	//价格条件1
	TrdPriceType						TriggerPrice;							//触发价格
	TrdTriggerModeType					TriggerMode;							//触发模式
	TrdTriggerConditionType				TriggerCondition;						//触发条件
	
	TrdQuantityType						MinMatchQty;							//最小成交量(内盘)
	
	//冰山单
	TrdQuantityType						MinOrderQty;							//冰山单最小随机量(外盘)
	TrdQuantityType						MaxOrderQty;							//冰山单最大随机量(外盘)
	
	TrdStrategyTypeType					StrategyType;							//策略类型(条件单，止损单、浮动止损、保本止损、止盈单)
	
	TrdMarketLevelType					MarketLevel;							//市价撮合深度,目前只有中金所支持，取值为0、1、5(内盘)

	//应价相关
	TrdOffsetType						SellOffset;								//应价卖出开平
	TrdPriceType						SellOrderPrice;							//应价卖出价格
	TrdQuantityType						SellOrderQty;							//应价卖出委托数量
	TrdHedgeType						SellHedge;								//应价卖出投保方向
	TrdEnquiryNoType					EnquiryNo;								//询价请求号，应价时用(内盘)

	TrdOrderRemarkType					OrderRemark;							//定单备注
	TrdOrderNoType						ParentNo;								//父单号,可以是TOrder::OrderNo也可以是TSpreadOrder::OrderNo等
	TrdSerialIdType						OcoId;									//OCO编号
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//云端策略单新增字段2017-11-06
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	TrdSerialIdType						OrderReqId;								//报单请求号，相当于原来包头上的SessionId
	TrdSerialIdType						ParentReqId;							//父单请求号
    TrdOrderPriceTypeType               OrderPriceType;                         //委托价格类型(指定价 最新价 挂单价 对盘价 市价 反向停板，只有指定价时委托价格字段才有效)(限策略单使用)

    //时间条件
    TrdTimeType                         TimeCondition;                          //时间条件(HH:MM:SS)

    //价格条件2
    TrdPriceType                        TriggerPrice2;                          //触发价格2
    TrdTriggerModeType                  TriggerMode2;                           //触发模式2
    TrdTriggerConditionType             TriggerCondition2;                      //触发条件2

    //停损
    TrdStopPriceTypeType                StopPriceType;                          //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    TrdPriceType                        StopPrice;                              //止损止盈价或价差，具体含义由止损止盈价格类型字段决定	

	TrdOrderRefType						OrderRef;								//报单引用
	TrdDateType							InsertTradeDate;						//下单交易日
	TrdBoolType							AddOne;									//是否T+1
    TrdBoolType                         AutoCloseFlag;                          //自对冲标记

	TrdOrderNoType                      StParentNo;                             // 条件单父单
} TrdOrderInsertReq;

//下单应答
//按请求号对应委托信息
typedef struct TrdOrderInsertRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdOrderNoType						OrderNo;								//委托号，可能为空
	TrdUserNoType						InsertNo;								//下单人
	TrdDateTimeType						InsertDateTime;							//下单时间
	TrdOrderStateType					OrderState;								//委托状态			
	TrdErrorTextType					ErrorText;								//错误信息，CTP错误号是0却仍然会有错误信息
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//新增字段2017-11-06
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	TrdErrorCodeType					ErrorCode;								//错误编号
	TrdStrategyTypeType					StrategyType;							//策略类型(条件单，止损单、浮动止损、保本止损、止盈单)
	TrdSessionNoType					SessionNo;								//会话标识
	TrdSerialIdType						OrderReqId;								//报单请求号，相当于原来包头上的SessionId
	TrdOrderNoType						ParentNo;								//父单委托号，可能为空
	TrdOrderRefType						OrderRef;								//报单引用
    TrdBoolType                         AutoCloseFlag;                          //自对冲标记
} TrdOrderInsertRsp;

//定单通知(外盘录单，定单修改通知)
//key = CompanyNo + OrderNo
//key = ContractNo(ExchangeNo) + SeatNo + LocalNo
//key = ContractNo(ExchangeNo) + SystemNo
typedef struct TrdOrderRtn
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdContractNoType 					ContractNo;								//合约编号
	TrdOrderTypeType					OrderType;								//定单类型 
	TrdOrderWayType						OrderWay;								//委托来源 
	TrdValidTypeType					ValidType;								//有效类型 
	TrdDateTimeType						ValidTime;								//有效日期时间(GTD情况下使用)
	TrdBoolType							IsRiskOrder;							//风险报单 
	TrdDirectType						Direct;									//买卖方向 
	TrdOffsetType						Offset;									//开仓 平仓 开平 平开(内盘)
	TrdHedgeType						Hedge;									//投机保值 投保 保投(内盘)
	union
	{
		TrdPriceType					OrderPrice;								//委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
		TrdPriceType					OrderPriceOver;							//委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)
	};
	TrdQuantityType						OrderQty;								//委托数量 或 期权应价数量
	
	TrdPriceType						TriggerPrice;							//触发价格
	TrdTriggerModeType					TriggerMode;							//触发模式
	TrdTriggerConditionType				TriggerCondition;						//触发条件
	
	TrdQuantityType						MinMatchQty;							//最小成交量(内盘)
	
	TrdQuantityType						MinOrderQty;							//冰山单最小随机量(外盘)
	TrdQuantityType						MaxOrderQty;							//冰山单最大随机量(外盘)
	
	TrdStrategyTypeType					StrategyType;							//策略类型
	
	TrdMarketLevelType					MarketLevel;							//市价撮合深度,目前只有中金所支持，取值为0、1、5(内盘)

	TrdOffsetType						SellOffset;								//应价卖出开平
	TrdPriceType						SellOrderPrice;							//应价卖出价格
	TrdQuantityType						SellOrderQty;							//应价卖出委托数量
	TrdHedgeType						SellHedge;								//应价卖出投保方向
	TrdEnquiryNoType					EnquiryNo;								//询价请求号，应价时用(内盘)

	TrdOrderRemarkType					OrderRemark;							//定单备注

	TrdOrderNoType						ParentNo;								//父单号
	TrdSerialIdType						OcoId;									//OCO编号	

	/**************************************************************************************************/
	TrdOrderNoType						OrderNo;								//委托号
	TrdLocalNoType						LocalNo;								//本地号
	TrdSystemNoType						SystemNo;								//系统号
	TrdSeatNoType						SeatNo;									//席位号

	TrdUserNoType						InsertNo;								//下单人
	TrdDateTimeType						InsertDateTime;							//下单时间
	TrdUserNoType						UpdateNo;								//最后一次变更人
	TrdDateTimeType						UpdateDateTime;							//最后一次变更时间

	TrdPriceType						MatchPrice;								//成交价
	TrdQuantityType						MatchQty;								//成交量
	TrdOrderStateType					OrderState;								//委托状态 
	
	TrdPriceType						SellMatchPrice;							//应价卖出成交价
	TrdQuantityType						SellMatchQty;							//应价卖出成交量	

	TrdBoolType							AddOne;									//T+1(外盘)

	TrdErrorCodeType					ErrorCode;								//错误码				
	TrdErrorTextType					ErrorText;								//错误信息
	TrdSerialIdType						StreamId;								//委托流号

	TrdDateType							InsertTradeDate;						//下单交易日
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//云端策略单新增字段2017-11-06
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
	TrdSerialIdType						OrderReqId;								//报单请求号，相当于原来包头上的SessionId
	TrdSerialIdType						ParentReqId;							//父单请求号
	
    TrdOrderPriceTypeType               OrderPriceType;                         //委托价格类型(指定价 最新价 挂单价 对盘价 市价价，只有指定价时委托价格字段才有效)(限策略单使用)

    //时间条件
    TrdTimeType                         TimeCondition;                          //时间条件(HH:MM:SS)

    //价格条件2
    TrdPriceType                        TriggerPrice2;                          //触发价格2
    TrdTriggerModeType                  TriggerMode2;                           //触发模式2
    TrdTriggerConditionType             TriggerCondition2;                      //触发条件2

    //停损
    TrdStopPriceTypeType                StopPriceType;                          //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    TrdPriceType                        StopPrice;                              //止损止盈价或价差，具体含义由止损止盈价格类型字段决定

	TrdSessionNoType					SessionNo;								//会话编号
	TrdOrderRefType						OrderRef;								//报单引用	
	
	TrdDateType							UpdateTradeDate;						//更新交易日
    TrdBoolType                         AutoCloseFlag;                          //自对冲标记
	TrdBoolType                         IsDeleted;                              //委托是否删除标志

    TrdOrderNoType                      StParentNo;                             // 条件单父单
} TrdOrderRtn;

//定单(策略单)信息查询
typedef struct TrdOrderQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdSerialIdType						SerialId;								//流控序号
} TrdOrderQryReq;
typedef TrdOrderQryReq					TrdOrderQryRsp;
typedef TrdOrderRtn						TrdOrderQryData;

//定单删除通知
typedef struct TrdOrderDelRtn
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdOrderNoType						OrderNo;								//委托号
	TrdUserNoType						UserNo;									//资金账号
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//云端策略单新增字段2017-11-06
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	TrdStrategyTypeType					StrategyType;							//策略类型(条件单，止损单、浮动止损、保本止损、止盈单)
	TrdSessionNoType					SessionNo;								//会话标识
} TrdOrderDelRtn;


//定单操作请求与应答
typedef struct TrdOrderActionReq
{
    TrdCompanyNoType                    CompanyNo;                              //经纪公司编号
    TrdUserNoType                       UserNo;                                 //资金帐号
    TrdOrderNoType                      OrderNo;                                //委托号
	TrdSingleContractNoType				ContractNo;								//合约编号
	
    TrdOrderActionTypeType              OrderActionType;                        //定单操作类型   
	TrdStrategyTypeType					StrategyType;							//策略类型(条件单，止损单、浮动止损、保本止损、止盈单)
} TrdOrderActionReq;
typedef struct TrdOrderActionRsp
{
    TrdCompanyNoType                    CompanyNo;                              //经纪公司编号
    TrdUserNoType                       UserNo;                                 //资金帐号
    TrdOrderNoType                      OrderNo;                                //委托号
	TrdSingleContractNoType				ContractNo;								//合约编号
    
    TrdUserNoType                       UpdateNo;                               //最后一次变更人
    TrdDateTimeType                     UpdateDateTime;                         //最后一次变更时间
    TrdOrderStateType                   OrderState;                             //委托状态      
    TrdErrorTextType                    ErrorText;                              //错误信息  
    TrdErrorCodeType                    ErrorCode;                              //错误编号
    TrdStrategyTypeType                 StrategyType;                           //策略类型(条件单，止损单、浮动止损、保本止损、止盈单)
    TrdSessionNoType                    SessionNo;                              //会话标识
} TrdOrderActionRsp;

//定单修改请求与应答
typedef struct TrdOrderModifyReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdOrderNoType						OrderNo;								//委托号
	TrdSingleContractNoType				ContractNo;								//合约编号
	
	TrdOrderTypeType					OrderType;								//定单类型 
	TrdOrderWayType						OrderWay;								//委托来源 
	TrdValidTypeType					ValidType;								//有效类型 
	TrdDateTimeType						ValidTime;								//有效日期时间(GTD情况下使用)
	TrdDirectType						Direct;									//买卖方向 
	TrdOffsetType						Offset;									//开仓 平仓 开平 平开(内盘)
	TrdHedgeType						Hedge;									//投机保值(内盘)
	
	TrdQuantityType						MinMatchQty;							//最小成交量(内盘)	
	TrdMarketLevelType					MarketLevel;							//市价撮合深度,目前只有中金所支持，取值为0、1、5(内盘)
	TrdOrderRemarkType					OrderRemark;							//定单备注	
	
	
	TrdOrderPriceTypeType               OrderPriceType;                         //委托价格类型(指定价 最新价 挂单价 对盘价 市价 反向停板，只有指定价时委托价格字段才有效)(限策略单使用)
	union
	{
		TrdPriceType					OrderPrice;								//委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
		TrdPriceType					OrderPriceOver;							//委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)
	};
	TrdQuantityType						OrderQty;								//委托数量 或 期权应价数量	
   
	TrdStrategyTypeType					StrategyType;							//策略类型(条件单，止损单、浮动止损、保本止损、止盈单)

	//价格条件1
	TrdPriceType						TriggerPrice;							//触发价格
	TrdTriggerModeType					TriggerMode;							//触发模式
	TrdTriggerConditionType				TriggerCondition;						//触发条件

    //时间条件
    TrdTimeType                         TimeCondition;                          //时间条件(HH:MM:SS)

    //价格条件2
    TrdPriceType                        TriggerPrice2;                          //触发价格2
    TrdTriggerModeType                  TriggerMode2;                           //触发模式2
    TrdTriggerConditionType             TriggerCondition2;                      //触发条件2

    //停损
    TrdStopPriceTypeType                StopPriceType;                          //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    TrdPriceType                        StopPrice;                              //止损止盈价或价差，具体含义由止损止盈价格类型字段决定
} TrdOrderModifyReq;
typedef TrdOrderActionRsp TrdOrderModifyRsp;


//定单操作请求与应答（废弃版本，不再使用 2018-04-16之前）
typedef struct TrdOrderActionReq_OUT
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdOrderNoType						OrderNo;								//委托号
	TrdSingleContractNoType				ContractNo;								//合约编号

	TrdOrderActionTypeType				OrderActionType;						//定单操作类型	
	union
	{
		TrdPriceType					OrderPrice;								//委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
		TrdPriceType					OrderPriceOver;							//委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)
	};
	TrdQuantityType						OrderQty;								//委托数量
	TrdPriceType						TriggerPrice;							//触发价格(价格条件1)
	TrdPriceType						SellOrderPrice;							//应价第二腿

	TrdOrderRemarkType					OrderRemark;							//定单备注，可以是二进制内容
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//云端策略单新增字段2017-11-06
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    TrdOrderPriceTypeType               OrderPriceType;                         //委托价格类型(指定价 最新价 挂单价 对盘价 市价价，只有指定价时委托价格字段才有效)(限策略单使用)

	//价格条件1
	TrdTriggerModeType					TriggerMode;							//触发模式(最新 买价 卖价)
	TrdTriggerConditionType				TriggerCondition;						//触发条件(> = <)
			
    //时间条件
    TrdTimeType                         TimeCondition;                          //时间条件(HH:MM:SS)

    //价格条件2
    TrdPriceType                        TriggerPrice2;                          //触发价格2
    TrdTriggerModeType                  TriggerMode2;                           //触发模式2
    TrdTriggerConditionType             TriggerCondition2;                      //触发条件2

    //停损
    TrdStopPriceTypeType                StopPriceType;                          //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    TrdPriceType                        StopPrice;                              //止损止盈价或价差，具体含义由止损止盈价格类型字段决定
	
	TrdStrategyTypeType					StrategyType;							//策略类型(条件单，止损单、浮动止损、保本止损、止盈单)
} TrdOrderActionReq_OUT;
typedef TrdOrderActionRsp TrdOrderActionRsp_OUT;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Match_QRY_REQ				= 0x0500;	//成交信息查询请求
static const CspProtocolCodeType CMD_TRD_Match_QRY_RSP				= 0x0501;	//成交信息查询应答
static const CspProtocolCodeType CMD_TRD_Match_QRY_DATA				= 0x0502;	//成交信息数据回报
static const CspProtocolCodeType CMD_TRD_Match_RTN					= 0x0503;	//成交信息通知
static const CspProtocolCodeType CMD_TRD_Match_DEL_RTN				= 0x0504;	//成交删除通知

//Key = CompanyNo + MatchNo + ContractNo + Direct
typedef struct TrdMatchRtn
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdMatchNoType						MatchNo;								//成交号

	TrdUserNoType						UserNo;									//资金帐号
	TrdSingleContractNoType				ContractNo;								//合约编号
	TrdDirectType						Direct;									//买卖
	TrdOffsetType						Offset;									//开仓 平仓 开平 平开(内盘)
	TrdHedgeType						Hedge;									//投机保值 投保 保投(内盘)
	TrdPriceType						MatchPrice;								//成交价格
	TrdQuantityType						MatchQty;								//成交数量
	TrdOrderWayType						MatchWay;								//成交来源
	TrdPriceType						CoverPrice;								//平仓指定价格(外盘指定价格平仓)

	TrdDateTimeType						MatchDateTime;							//成交时间
	TrdOrderNoType						OrderNo;								//委托号

	TrdCurrencyNoType					FeeCurrencyNo;							//手续费币种
	TrdFundType							MatchFee;								//成交手续费
	TrdFundType							Premium;								//权利金收支，收入为正，支出为负 = 成交价 * 成交量 * 乘数

	TrdBoolType							ManualFee;								//手工手续费(外盘)
	TrdBoolType							AddOne;									//T+1标记(外盘)

	TrdSerialIdType						StreamId;								//流号

	TrdDateType							SettleDate;								//结算日期，历史成交用
	TrdBoolType                         IsDeleted;                              //委托是否删除标志
} TrdMatchRtn;

//成交查询请求、应答
typedef struct TrdMatchQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdSerialIdType						SerialId;								//流控序号
} TrdMatchQryReq;
typedef TrdMatchQryReq					TrdMatchQryRsp;
typedef TrdMatchRtn						TrdMatchQryData;

//成交删除通知
typedef struct TrdMatchDelRtn
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdMatchNoType						MatchNo;								//成交号
	TrdSingleContractNoType				ContractNo;								//合约编号
	TrdDirectType						Direct;									//买卖
	TrdSerialIdType						StreamId;								//流号
} TrdMatchDelRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Position_QRY_REQ			= 0x0600;	//持仓信息查询请求
static const CspProtocolCodeType CMD_TRD_Position_QRY_RSP			= 0x0601;	//持仓信息查询应答
static const CspProtocolCodeType CMD_TRD_Position_RTN				= 0x0602;	//持仓信息通知
static const CspProtocolCodeType CMD_TRD_PositionCalcPrice_RTN		= 0x0603;	//持仓计算价格通知

typedef struct TrdPositionQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
} TrdPositionQryReq;
//Key = CompanyNo + PositionNo
typedef struct TrdPositionQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdPositionNoType					PositionNo;								//持仓号

	TrdUserNoType						UserNo;									//资金账号
	TrdSingleContractNoType				ContractNo;								//合约编号
	TrdDirectType						Direct;									//买卖
	TrdHedgeType						Hedge;									//投保 
	TrdPriceType						PositionPrice;							//持仓价
	TrdQuantityType						PositionQty;							//持仓量	
	TrdQuantityType						PrePositionQty;							//昨持仓量	

	TrdBoolType							IsCmb;									//是否组合持仓
	TrdMatchNoType						MatchNo;								//成交关键字
	TrdDateTimeType						MatchDateTime;							//成交时间

	TrdPriceType						ProfitCalcPrice;						//浮盈计算价
	TrdFundType							FloatProfit;							//浮盈
	TrdFundType							FloatProfitTBT;							//逐笔浮赢 trade by trade

	TrdPriceType						DepositCalcPrice;						//老仓保证金计算价（昨结算），新仓为成交价
	TrdFundType							Deposit;								//客户初始保证金
	TrdFundType							KeepDeposit;							//客户维持保证金			
	TrdFundType							MarketValue;							//期权市值 = 最新价 * 持仓量 * 乘数

	TrdQuantityType						CanCoverQty;							//可平数量(暂未使用)
	TrdQuantityType						FrozenQty;                      		//冻结数量(暂未使用)

	TrdSerialIdType						StreamId;								//流号

	TrdDateType							SettleDate;								//结算日期，历史持仓用
} TrdPositionQryRsp;
typedef TrdPositionQryRsp				TrdPositionRtn;

typedef struct TrdPositionCalcPrice
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdSingleContractNoType				ContractNo;								//合约编号
	
	TrdPriceType						ProfitCalcPrice;						//浮盈计算价（最新价）
	TrdPriceType						DepositCalcPrice;						//老仓保证金计算价（昨结算），新仓为成交价
} TrdPositionCalcPrice;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Fund_QRY_REQ				= 0x0700;	//资金查询请求
static const CspProtocolCodeType CMD_TRD_Fund_QRY_RSP				= 0x0701;	//资金查询应答
static const CspProtocolCodeType CMD_TRD_Fund_CHG_RTN				= 0x0702;	//资金变化回报

typedef struct TrdFundQryReq
{	
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
} TrdFundQryReq;
typedef struct TrdFundField			
{
	TrdFundFieldIndexType				Index;
	TrdFundType							Value;
} TrdFundField;
//Key = CompanyNo + UserNo + CurrencyGroupNo + CurrencyNo
typedef struct TrdFundQryRsp			
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdCurrencyGroupNoType				CurrencyGroupNo;						//币种组编号
	TrdCurrencyNoType					CurrencyNo;								//币种号
	TrdExchangeRateType					ExchangeRate;							//币种汇率
 
	TrdDnyFieldCountType				FundFieldCount;							//资金字段数目
	TrdFundField						FundFields[1];							//资金字段数组
} TrdFundQryRsp;
typedef TrdFundQryRsp					TrdFundChgRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_TransBank_QRY_REQ			= 0x0800;	//转账银行查询请求
static const CspProtocolCodeType CMD_TRD_TransBank_QRY_RSP			= 0x0801;	//转账银行查询应答

typedef struct TrdTransBankQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
} TrdTransBankQryReq;
//Key = CompanyNo + UserNo + BankNo + BankAccount + CurrencyNo
typedef struct TrdTransBankQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdBankNoType						BankNo;									//银行代码
	TrdBankBrchNoType					BankBrchNo;								//银行分中心代码
	TrdBankNameType						BankName;								//银行名称
	TrdUserNoType						UserNo;									//资金账号
} TrdTransBankQryRsp;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_TransBankUser_QRY_REQ		= 0x0900;	//签约银行查询请求
static const CspProtocolCodeType CMD_TRD_TransBankUser_QRY_RSP		= 0x0901;	//签约银行查询应答

typedef struct TrdTransBankUserQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
} TrdTransBankUserQryReq;
//Key = CompanyNo + UserNo + BankNo + BankAccount + CurrencyNo
typedef struct TrdTransBankUserQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//期货资金账号
	TrdBankNoType						BankNo;									//银行标志
	TrdBankAccountType					BankAccount;							//银行卡号
	TrdCurrencyNoType					CurrencyNo;								//币种编号

	TrdBankNameType						BankName;								//银行名称
	TrdBoolType							SwapState;      						//转账换汇状态
	TrdBoolType							TransState;  							//转账状态
} TrdTransBankUserQryRsp;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_BankBalance_QRY_REQ		= 0x0A00;	//银行余额查询请求
static const CspProtocolCodeType CMD_TRD_BankBalance_QRY_RSP		= 0x0A01;	//银行余额查询应答

typedef struct TrdBankBalanceQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//期货资金账号
	TrdBankNoType						BankNo;									//银行标志
	TrdBankAccountType					BankAccount;							//银行卡号
	TrdCurrencyNoType					CurrencyNo;								//币种编号

	TrdTransAuthType					TransAuth;								//银期转账认证密码
	TrdBankPswType						BankPsw;								//银行密码
} TrdBankBalanceQryReq;
//Key = CompanyNo + UserNo + BankNo + BankAccount + CurrencyNo
typedef struct TrdBankBalanceQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//期货资金账号
	TrdBankNoType						BankNo;									//银行标志
	TrdBankAccountType					BankAccount;							//银行卡号
	TrdCurrencyNoType					CurrencyNo;								//币种编号

	TrdFundType							Balance;								//可转资金
} TrdBankBalanceQryRsp;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Transfer_REQ				= 0x0B00;	//银期转账请求
static const CspProtocolCodeType CMD_TRD_Transfer_RSP				= 0x0B01;	//银期转账应答
static const CspProtocolCodeType CMD_TRD_Transfer_RTN				= 0x0B02;	//银期转账通知
static const CspProtocolCodeType CMD_TRD_Transfer_QRY_REQ			= 0x0B03;	//银期转账查询请求
static const CspProtocolCodeType CMD_TRD_Transfer_QRY_RSP			= 0x0B04;	//银期转账查询应答

typedef struct TTransferReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//期货资金账号
	TrdBankNoType						BankNo;									//银行标志
	TrdBankAccountType					BankAccount;							//银行卡号
	TrdCurrencyNoType					CurrencyNo;								//币种编号

	TrdTransAuthType					TransAuth;								//银期转账认证密码
	TrdBankPswType						BankPsw;								//银行密码
	TrdTransDirectType					TransDirect;							//转账方向
	TrdFundType							TransFund;								//转账金额
} TTransferReq;
//Key = CompanyNo + FutureSerialId + BankNo + BankSerialId
typedef struct TrdTransferRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//期货资金账号
	TrdBankNoType						BankNo;									//银行标志
	TrdBankAccountType					BankAccount;							//银行卡号
	TrdCurrencyNoType					CurrencyNo;								//币种编号

	TrdTransDirectType					TransDirect;							//转账方向
	TrdFundType							TransFund;								//转账金额
	TrdTransStateType					TransState;								//转账状态

	TrdSerialIdType						BankSerialId;							//银行流水号
	TrdSerialIdType						FutureSerialId;							//期货流水号
	TrdTimeType							TransTime;								//转账时间

	TrdFundType							BankFee;								//银行手续费
	TrdFundType							FutureFee;								//期货公司手续费

	TrdErrorCodeType					ErrorCode;								//错误码
	TrdErrorTextType	 				ErrorText;								//错误信息

	TrdTransInitiatorType 				Initiator;								//转账发起方
} TrdTransferRsp;
typedef TrdTransferRsp					TrdTransferRtn;

//转账流水查询
typedef struct TTransferQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//期货资金账号
} TTransferQryReq;
typedef TrdTransferRsp					TrdTransferQryRsp;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//0C00

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_ChangeLoginPsw_REQ			= 0x0D00;	//登录密码修改请求
static const CspProtocolCodeType CMD_TRD_ChangeLoginPsw_RSP			= 0x0D01;	//登录密码修改应答
static const CspProtocolCodeType CMD_TRD_ChangeLoginPsw_RTN			= 0x0D02;	//登录密码修改通知

typedef struct TrdChangeLoginPswReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdLoginNoType						LoginNo;								//登录帐号
	TrdTradePswType						CurrPsw;								//当前密码
	TrdTradePswType						NewPsw;									//新密码
} TrdChangeLoginPswReq;

typedef struct TrdChangeLoginPswRsp
{	
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdLoginNoType						LoginNo;								//登录帐号
} TrdChangeLoginPswRsp;
typedef TrdChangeLoginPswRsp	 		TrdChangeLoginPswRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_ChangeFundPsw_REQ			= 0x0E00;	//资金密码修改请求
static const CspProtocolCodeType CMD_TRD_ChangeFundPsw_RSP			= 0x0E01;	//资金密码修改应答
static const CspProtocolCodeType CMD_TRD_ChangeFundPsw_RTN			= 0x0E02;	//资金密码修改通知

typedef struct TrdChangeFundPswReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdCurrencyNoType					CurrencyNo;								//币种号
	TrdTradePswType						CurrPsw;								//当前密码
	TrdTradePswType						NewPsw;									//新密码
} TrdChangeFundPswReq;

typedef struct TrdChangeFundPswRsp
{	
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdCurrencyNoType					CurrencyNo;								//币种号
} TrdChangeFundPswRsp;
typedef TrdChangeFundPswRsp				TrdChangeFundPswRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Message_QRY_REQ			= 0x0F00;	//交易消息查询请求
static const CspProtocolCodeType CMD_TRD_Message_QRY_RSP			= 0x0F01;	//交易消息查询应答
static const CspProtocolCodeType CMD_TRD_Message_RTN				= 0x0F02;	//交易消息通知

typedef struct TrdMessageQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
} TrdMessageQryReq;
//Key = CompanyNo + MsgId
typedef struct TrdMessageQryRsp
{
	TrdSerialIdType						MsgId;									//消息Id
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//接收者
	TrdMessageLevelType					Level;									//消息级别
	TrdSendNoType						SendNo;									//发送者
	TrdDateTimeType						SendDateTime;							//发送时间
	TrdDateTimeType						ValidDateTime;							//有效时间
	TrdMsgTitleType						Title;									//标题
	TrdVarcharType						Content;								//消息内容
} TrdMessageQryRsp;
typedef TrdMessageQryRsp				TrdMessageRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Bill_QRY_REQ				= 0x1000;	//结算单查询请求
static const CspProtocolCodeType CMD_TRD_Bill_QRY_RSP				= 0x1001;	//结算单查询应答
static const CspProtocolCodeType CMD_TRD_BillConfirmStatus_QRY_REQ	= 0x1002;	//结算单确认状态查询请求
static const CspProtocolCodeType CMD_TRD_BillConfirmStatus_QRY_RSP	= 0x1003;	//结算单确认状态查询应答
static const CspProtocolCodeType CMD_TRD_BillConfirm_REQ			= 0x1004;	//结算单确请求
static const CspProtocolCodeType CMD_TRD_BillConfirm_RSP			= 0x1005;	//结算单确应答

//结算单查询
typedef struct TrdBillQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdBillTypeType						BillType;								//账单类型
	TrdDateType							BillDate;								//账单日期
	TrdBillFormatTypeType				FormatType;								//账单格式
} TrdBillQryReq;
//Key = CompanyNo + UserNo + BillDate + FormatType
typedef struct TrdBillQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdBillTypeType						BillType;								//账单类型
	TrdDateType							BillDate;								//账单日期
	TrdBillFormatTypeType				FormatType;								//账单格式
	TrdVarcharType						Content;								//帐单内容
} TrdBillQryRsp;

//结算单确认状态查询
typedef struct TrdBillConfirmStatusQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdDateType							BillDate;								//账单日期
} TrdBillConfirmStatusQryReq;
typedef struct TrdBillConfirmStatusQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdDateType							BillDate;								//账单日期
	TrdBoolType							Confirmed;								//是否已经确认
} TrdBillConfirmStatusQryRsp;

//结算单确请求
typedef struct TrdBillConfirmReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdDateType							BillDate;								//账单日期
	TrdBoolType							Confirmed;								//是否通过确认
} TrdBillConfirmReq;
typedef struct TrdBillConfirmRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdDateType							BillDate;								//账单日期
} TrdBillConfirmRsp;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_ErrorInfo_RTN				= 0x1100;	//错误信息通知

typedef struct TrdErrorInfo
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdErrorCodeType					ErrorCode;								//错误ID
	TrdErrorTextType					ErrorText;								//错误信息
	TrdUserNoType						UserNo;									//资金账号
} TrdErrorInfo;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_CommodityStatus_REQ		= 0x1200;	//品种状态查询请求
static const CspProtocolCodeType CMD_TRD_CommodityStatus_RSP		= 0x1201;	//品种状态查询应答
static const CspProtocolCodeType CMD_TRD_CommodityStatus_RTN		= 0x1202;	//品种状态通知

//品种状态查询请求(不包含外盘品种)
typedef struct TrdCommodityStatusReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
} TrdCommodityStatusReq;
//品种状态查询应答
typedef struct TrdCommodityStatusRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	
	TrdCommodityNoType					CommodityNo;							//品种代码
	TrdCommodityStatusType				CommodityStatus;						//品种状态
	TrdDateTimeType						ExchangeTime;							//交易所时间
} TrdCommodityStatusRsp;
//品种状态通知
typedef TrdCommodityStatusRsp			TrdCommodityStatusRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_FeeParam_QRY_REQ			= 0x1300;	//手续费参数查询请求
static const CspProtocolCodeType CMD_TRD_FeeParam_QRY_RSP			= 0x1301;	//手续费参数查询应答
static const CspProtocolCodeType CMD_TRD_FeeParam_RTN				= 0x1302;	//手续费参数通知

//手续费参数查询请求
typedef struct TrdFeeParamQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdContractNoType 					ContractNo;								//合约编号
	TrdOffsetType						Offset;									//开仓 平仓 平今(内盘)
} TrdFeeParamQryReq;
//手续费参数查询应答
typedef struct TrdFeeParamQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdContractNoType 					ContractNo;								//合约编号
	TrdOffsetType						Offset;									//开仓 平仓 平今(内盘)
 
	//所收金额 = 资产金额*比例+下单数量*定额
	TrdRatioType						Ratio;									//比例
	TrdFundType							Amount;									//数额
} TrdFeeParamQryRsp;
//手续费参数通知
typedef TrdFeeParamQryRsp				TrdFeeParamRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_DepositParam_QRY_REQ		= 0x1400;	//保证金参数查询请求
static const CspProtocolCodeType CMD_TRD_DepositParam_QRY_RSP		= 0x1401;	//保证金参数查询应答
static const CspProtocolCodeType CMD_TRD_DepositParam_RTN			= 0x1402;	//保证金参数通知

//保证金参数查询请求
typedef struct TrdDepositParamQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdContractNoType 					ContractNo;								//合约编号
	TrdDirectType						Direct;									//买卖方向 
	TrdHedgeType						Hedge;									//投保 投机 套保 套利 做市(内盘)
} TrdDepositParamQryReq;
//保证金参数查询应答
typedef struct TrdDepositParamQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdContractNoType 					ContractNo;								//合约编号
	TrdDirectType						Direct;									//买卖方向 
	TrdHedgeType						Hedge;									//投保 投机 套保 套利 做市(内盘)
 
	//所收金额 = 资产金额*比例+下单数量*定额
	TrdRatioType						Ratio;									//比例
	TrdFundType							Amount;									//数额
} TrdDepositParamQryRsp;
//保证金参数通知
typedef TrdDepositParamQryRsp			TrdDepositParamRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_TradeDateSwitch_RTN		= 0x1500;	//交易日切换通知

//交易日切换通知
typedef struct TrdTradeDateSwitchRtn
{
	TrdDateType							PreTradeDate;							//上一交易日
	TrdDateType							TradeDate;								//当前交易日
	TrdBoolType							IsChina;								//是否内盘
} TrdTradeDateSwitchRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_SMSAuth_REQ				= 0x1600;	//短信认证码验证请求
static const CspProtocolCodeType CMD_TRD_SMSAuth_RSP				= 0x1601;	//短信认证码验证应答

//短信认证码验证请求
typedef struct TrdSMSAuthReq
{
	TrdSMSAuthCodeType					SMSAuthCode;							//短信认证码
	TrdSecondLoginTypeType              SecondLoginType;                        //登录类型
} TrdSMSAuthReq;
//短信认证码验证应答
typedef TrdSMSAuthReq					TrdSMSAuthRsp;


/*
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_User_QRY_REQ				= 0x1200;	//用户信息查询请求
static const CspProtocolCodeType CMD_TRD_User_QRY_RSP				= 0x1201;	//用户信息查询应答

typedef struct TrdUserInfoQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
} TrdUserInfoQryReq;
//Key = CompanyNo + UserNo
typedef struct TrdUserInfoQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdUserNameType						UserName;								//用户名称
	TrdUserTypeType						UserType;								//用户类型，单客户、机构户
	TrdBoolType							IsMarketMaker;							//是否做市商
} TrdUserInfoQryRsp;
typedef TrdUserInfoQryRsp	 			TrdUserInfoRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Liquidate_QRY_REQ			= 0x1300;	//平仓信息查询请求
static const CspProtocolCodeType CMD_TRD_Liquidate_QRY_RSP			= 0x1301;	//平仓信息查询应答
static const CspProtocolCodeType CMD_TRD_Liquidate_RTN				= 0x1302;	//平仓信息通知

typedef struct TrdLiquidateQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
} TrdLiquidateQryReq;
//Key = CompanyNo + LiquidateNo
typedef struct TrdLiquidateQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdLiquidateNoType					LiquidateNo;							//平仓编号

	TrdUserNoType						UserNo;									//资金帐号
	TrdSingleContractNoType				ContractNo;								//合约编号
	TrdDirectType						CoverDirect;							//买卖 
	TrdHedgeType						Hedge;									//投保 
	TrdPriceType						OpenPrice;								//开仓价
	TrdPriceType						CoverPrice;								//平仓价
	TrdQuantityType						CoverQty;								//数量

	TrdMatchNoType						OpenMatchNo;							//开仓成交号
	TrdMatchNoType						CoverMatchNo;							//平仓成交号

	TrdSerialIdType						StreamId;								//流号

	TrdFundType 						Premium;								//权利金
	TrdFundType							CloseProfit;							//平仓盈亏   盯市
	TrdFundType							PreSettle;								//昨结算
	TrdFundType							CloseProfitTBT;							//平仓总盈亏 开仓价 - 平仓价 逐笔
} TrdLiquidateQryRsp;
typedef TrdLiquidateQryRsp				TrdLiquidateRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_HisOrder_QRY_REQ			= 0x1400;	//历史委托查询请求
static const CspProtocolCodeType CMD_TRD_HisOrder_QRY_RSP			= 0x1401;	//历史委托查询应答

typedef struct TrdHisOrderQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdDateType							BeginDate;								//起始日期
	TrdDateType							EndDate;								//结束日期
} TrdHisOrderQryReq;
//key = CompanyNo + OrderNo + SettleDate
//key = CompanyNo + SeatNo + LocalNo + SettleDate
//key = CompanyNo + ContractNo(ExchangeNo) + SystemNo + SettleDate
typedef TrdOrderQryRsp	 				TrdHisOrderQryRsp;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_HisMatch_QRY_REQ			= 0x1500;	//历史成交查询请求
static const CspProtocolCodeType CMD_TRD_HisMatch_QRY_RSP			= 0x1501;	//历史成交查询应答

typedef TrdHisOrderQryReq				TrdHisMatchQryReq;
//key = CompanyNo + MatchNo + SettleDate
typedef TrdMatchQryRsp	 				TrdHisMatchQryRsp;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_CfmmcToken_QRY_REQ			= 0x1600;	//监控中心登录令牌请求
static const CspProtocolCodeType CMD_TRD_CfmmcToken_QRY_RSP			= 0x1601;	//监控中心登录令牌应答

typedef struct TrdCfmmcTokenQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
} TrdCfmmcTokenQryReq;
//Key = CompanyNo + UserNo
typedef struct TrdCfmmcTokenQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdCompanyNoType					CompanyNo;								//期货公司代码(会员码)
	TrdSerialIdType						TokenId;								//令牌Id
	TrdTokenType						Token;									//令牌认证码
} TrdCfmmcTokenQryRsp;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//外盘9.0不支持
static const CspProtocolCodeType CMD_TRD_Prefreeze_QRY_REQ			= 0x1800;	//冻结手续费查询请求
static const CspProtocolCodeType CMD_TRD_Prefreeze_QRY_RSP			= 0x1801;	//冻结手续费查询应答

typedef TrdTradableQryReq				TrdPreFreezeQryReq;
//Key = CompanyNo + UserNo + ContractNo + OrderType + Direct + Offset + Hedge + OrderPrice + OrderQty + StrategyType + OrderPrice2 + Available
typedef struct TrdPreFreezeQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdContractNoType 					ContractNo;								//合约编号
	TrdOrderTypeType					OrderType;								//定单类型 
	TrdDirectType						Direct;									//买卖方向 
	TrdOffsetType						Offset;									//开仓 平仓 开平 平开(内盘)
	TrdHedgeType						Hedge;									//投机保值(内盘)
	TrdPriceType						OrderPrice;								//委托价格 或 期权应价买入价格
	TrdQuantityType						OrderQty;								//委托数量 或 期权应价数量
	TrdStrategyTypeType					StrategyType;							//策略类型
	TrdPriceType						OrderPrice2;							//应价第二腿委托价格(内盘)

	TrdFundType							Available;								//可用资金
	TrdFundType							Deposit;								//本币保证金
} TrdPreFreezeQryRsp;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_Cash_QRY_REQ				= 0x1900;	//出入金信息查询请求
static const CspProtocolCodeType CMD_TRD_Cash_QRY_RSP				= 0x1901;	//出入金信息查询应答
static const CspProtocolCodeType CMD_TRD_Cash_RTN					= 0x1902;	//出入金信息通知

typedef struct TrdCashQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
} TrdCashQryReq;
//Key = CompanyNo + StreamId
typedef struct TrdCashQryRsp
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金账号
	TrdCashTypeType						CashType;								//出入金类型
	TrdCashModeType						CashMode;								//出入金方式
	TrdCurrencyNoType					CurrencyNo;								//币种
	TrdFundType							OperAmount;								//操作金额
	TrdRemarkType						CashRemark;								//出入金备注

	TrdBankNoType						UserBankNo;								//银行标识
	TrdBankAccountType					UserAccount;							//银行账户
	TrdBoolType							UsertAccountType;						//是否本币 本外币账户标识 
	TrdBankNoType						CompanyBankNo;							//公司银行标识
	TrdBankAccountType					CompanyAccount;							//公司银行账户
	TrdBoolType							CompanyAccountType;						//公司银行帐号是否本币 本外币账户标识 

	TrdSerialIdType						StreamId;								//流号
	TrdSerialIdType						RemoteStreamId;							//远端流号
	TrdCheckStateType					CheckState;								//审核状态
	TrdDateTimeType						CheckDateTime;							//审核时间
	TrdCheckerNoType					CheckerNo;								//审核人
	TrdDateTimeType						OperDateTime;							//操作时间
	TrdOperatorNoType					OperatorNo;								//操作人

	TrdDateType							SettleDate;								//结算日期，历史数据使用
} TrdCashQryRsp;
typedef TrdCashQryRsp	 				TrdCashRtn;
*/


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//服务器与网关专有协议
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//IP地址或DNS
typedef struct TrdIpAddress
{
	TrdTransportLayerProtocolType		TransProtocol;							//传输层协议 TCP、UDP、SSL等
	TrdIpType							IP;
	TrdPortType							Port;
} TrdIpAddress;

//经纪公司系统地址信息通知结构 key = CompanyNo + CompanyAddressNo
typedef struct TrdCompanyAddressInfo
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdCompanyAddressNoType				CompanyAddressNo;						//登录地址编号

	TrdCompanyAddressNameType			CompanyAddressName;						//登录地址名称
	TrdCompanySystemStatusType			CompanySystemStatus;					//经纪公司系统状态：正常、禁用、故障
		
	TrdCompanyApiType					CompanyApi;								//经纪公司系统类型
	TrdCompanyAuthInfoType				CompanyAuthInfo;						//经纪公司认证信息
	TrdCompanyAccessTypeType			CompanyAccessType;						//登录通道类型
	TrdBrokerNoType						BrokerNo;								//会员系统内的经纪公司编号	
	TrdBoolType							StrategyActive;							//是否支持策略单

	TrdIpCountType						IpCount;								//IP地址数量
	TrdIpAddress						IpAddress[12];							//IP地址预留数组
} TrdCompanyAddressInfo;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_G_Login_REQ				= 0xC100;	//客户登录请求
static const CspProtocolCodeType CMD_TRD_G_Login_RSP				= 0xC101;	//客户登录应答

//交易把登录请求发送给网关使用 网关用来连接期货公司的、 app中不需要这个协议(潘鹏飞说的)
//key = CompanyNo + CompanyAddressNo + LoginNo
typedef struct TrdGLoginReq
{
	TrdCompanyAddressInfo				Address;								//连接地址
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdCompanyAddressNoType				CompanyAddressNo;						//登录地址编号	
	TrdLoginNoType						LoginNo;								//登录账号
	TrdTradePswType						LoginPsw;								//登录密码
	TrdTradePswType 					NewPsw;									//强制初始化密码
	TrdTerminalTypeType 				TerminalType;							//终端类型
	TrdAppCodeType						AppCode;								//客户端软件标识码 软件名、版本号等
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	TrdLoginInfoType					LoginInfo;								//客户登录信息(用户定位，手机号、IP、MAC等)
    
    TrdSystemInfoType                   SystemInfo;                             //用户端系统内部信息
    TrdSystemInfoLenType                SystemInfoLen;                          //用户端系统内部信息长度
	TrdSystemInfoIntegrityType          SystemInfoIntegrity;                    //采集信息完整度（恒生）
	TrdSystemInfoFlag                   SystemInfoFlag;                         //系统信息标识（恒生，填异常标识，启明星，版本号）
	TrdAppIdType                        ClientAppId;							//终端appid
	TrdAppIdType                        RelayAppId;								//中继appid
} TrdGLoginReq;
typedef struct TrdGLoginRsp
{
	TrdCompanyAddressInfo				Address;								//连接地址
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdCompanyAddressNoType				CompanyAddressNo;						//登录地址编号	
	TrdLoginNoType						LoginNo;								//登录账号
	TrdTerminalTypeType 				TerminalType;							//终端类型
	TrdAppCodeType						AppCode;								//客户端软件标识码
	TrdLoginNameType 					LoginName;								//登录帐号名称

	TrdLoginInfoType					LastLoginInfo;							//上次登录信息, 机器地址、登录和退出时间等
	TrdDateType 						TradeDate;								//当前交易日
	TrdDateTimeType 					LastSettleTime;							//最后结算日
	TrdDateTimeType 					StartTime;								//会员系统启动时间
	TrdDateTimeType 					InitTime;								//会员系统初始化时间

	TrdBoolType							ForceChgPsw;							//是否需要强制修改密码	
	TrdSessionNoType					SessionNo;								//会话编号
} TrdGLoginRsp;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_G_Logout_REQ				= 0xC200;	//客户登出请求
static const CspProtocolCodeType CMD_TRD_G_Logout_RSP				= 0xC201;	//客户登出应答，主动登出
static const CspProtocolCodeType CMD_TRD_G_Logout_RTN				= 0xC202;	//客户登出通知，被动登出

typedef struct TrdGLogoutReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdCompanyAddressNoType				CompanyAddressNo;						//登录地址编号	
	TrdLoginNoType						LoginNo;								//登录账号
} TrdGLogoutReq;
typedef TrdGLogoutReq TrdGLogoutRsp;
typedef TrdGLogoutReq TrdGLogoutRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_G_Commodity_QRY_REQ		= 0xC300;	//品种信息查询请求
static const CspProtocolCodeType CMD_TRD_G_Commodity_QRY_RSP		= 0xC301;	//品种信息查询应答

typedef struct TrdGCommodityQryReq
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
} TrdGCommodityQryReq;

typedef struct TrdGCommodityRsp
{
    TrdCommodityNoType         			CommodityNo;                 			//品种编号    
	TrdUserNoType						UserNo;									//资金帐号

    TrdCommodityDotType        			CommodityDot;                			//每手乘数
    TrdOptionTypeType          			OptionType;                  			//期权类型
	TrdExcuteTypeType					ExcuteType;								//行权类型
    TrdSpreadDirectType        			SpreadDirect;                			//组合方向
    TrdCoverModeType           			CoverMode;                   			//平仓模式
    TrdPriceTickType					Tick;									//最小变动价
    TrdPriceDivisorType       			TickDivisor;							//报价除数(分母),默认为1
    TrdPriceMultipleType       			PriceMultiple;               			//执行价格倍数，默认为1
    TrdExecuteDotType          			ExecuteDot;                  			//行权乘数，默认1
	
    TrdDepositGroupNoType      			DepositGroupNo;              			//大边保证金组号
    TrdMaxSingleOrderQtyType   			MaxSingleOrderQty;           			//单笔最大下单量
    TrdMaxPositionQtyType      			MaxPositionQty;              			//最大持仓量
    TrdCurrencyNoType          			CurrencyNo;                  			//币种(必填)
	
    TrdCommodityNoType         			RelateCommodityNo1;          			//依赖品种1
    TrdCommodityNoType         			RelateCommodityNo2;          			//依赖品种2
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
} TrdGCommodityRsp;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_G_Quote_TRN				= 0xC400;	//行情通知

typedef struct TrdGQuoteRtn
{
    TrdContractNoType         			ContractNo;                 			//合约编号
	
    TrdPriceType						Last;									//最新价
    TrdPriceType						PreSettle;								//昨结算
    TrdPriceType						Bid;									//买价
    TrdQuantityType          			BidQty;									//卖量
    TrdPriceType						Ask;									//卖价
    TrdQuantityType          			AskQty;									//卖量
    TrdPriceType						LimitUp;								//涨停价
    TrdPriceType						LimitDown;								//跌停价
} TrdGQuoteRtn;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_G_StrategyOrderInit_RTN	= 0xC500;	//策略单初始化通知
typedef TrdOrderRtn TrdGStrategyOrderInitRtn;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_G_InitReady_TRN			= 0xC600;	//用户数据初始化完成通知

typedef struct TrdGInitReadyRtn
{
	TrdCompanyNoType					CompanyNo;								//经纪公司编号
	TrdUserNoType						UserNo;									//资金帐号
	TrdBoolType							InitReady;								//是否初始化成功
} TrdGInitReadyRtn;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//二次认证信息请求命令 
static const CspProtocolCodeType				CMD_TRD_SecondInfo_REQ        = 0xC700;
//二次认证信息请求应答命令
static const CspProtocolCodeType				CMD_TRD_SecondInfo_RSP        = 0xC701;
//二次认证信息请求请求结构
typedef struct TrdSecondInfoReq
{
    
}TrdSecondInfoReq;
//二次认证信息请求应答结构
typedef struct TrdSecondInfoRsp
{
    TrdSendTypeType                     SendType;					//发送类型
	TrdSendAccountType                  SendAccount;               //发送账号(手机号或者邮箱)；手机依次取短信电话、开户电话、其他电话；邮箱取账单邮箱    
}TrdSecondInfoRsp;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//二次认证验证码请求命令
static const CspProtocolCodeType		CMD_TRD_SecondCheckCode_REQ    = 0xC800;
//二次认证验证码请求应答命令
static const CspProtocolCodeType		CMD_TRD_SecondCheckCode_RSP    = 0xC801;

//二次认证验证码请求请求结构
typedef struct TrdSecondCheckCodeReq
{
    TrdSendTypeType                     SendType;                   //发送类型
    TrdSendAccountType                  SendAccount;                //发送账号(手机号或者邮箱)
}TrdSecondCheckCodeReq;
//二次认证验证码请求应答结构
typedef struct TrdSecondCheckCodeRsp
{
    TrdSecondSerialIDType               SecondSerialID;						//序列号
    TrdEffectiveTimeType                EffectiveTime;                      //二次认证验证码有效时间
}TrdSecondCheckCodeRsp;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static const CspProtocolCodeType CMD_TRD_PriceMonitorInsert_REQ			= 0x2100;	//价格监控下单请求
static const CspProtocolCodeType CMD_TRD_PriceMonitorInsert_RSP			= 0x2101;	//价格监控下单应答
static const CspProtocolCodeType CMD_TRD_PriceMonitor_RTN			    = 0x2102;	//价格监控通知

static const CspProtocolCodeType CMD_TRD_PriceMonitor_QRY_REQ			= 0x2103;	//查询请求
static const CspProtocolCodeType CMD_TRD_PriceMonitor_QRY_RSP			= 0x2104;	//查询应答
static const CspProtocolCodeType CMD_TRD_PriceMonitor_QRY_DATA			= 0x2105;	//数据应答

static const CspProtocolCodeType CMD_TRD_PriceMonitor_ACT_REQ			= 0x2106;	//订单操作请求
static const CspProtocolCodeType CMD_TRD_PriceMonitor_ACT_RSP			= 0x2107;	//订单操作应答

static const CspProtocolCodeType CMD_TRD_PriceMonitor_MOF_REQ			= 0x2108;	//订单修改请求
static const CspProtocolCodeType CMD_TRD_PriceMonitor_MOF_RSP			= 0x2109;	//订单修改应答

static const CspProtocolCodeType CMD_TRD_PriceMonitor_Quote           = 0x2110;   //行情

static const CspProtocolCodeType CMD_TRD_PriceMonitor_Login_REQ       = 0x2111;   //上传用户对应的推送信息
static const CspProtocolCodeType CMD_TRD_PriceMonitor_Login_RSP       = 0x2112;

static const CspProtocolCodeType CMD_TRD_PriceMonitor_Dele_REQ        = 0x2114;     //刪除已触发订单
static const CspProtocolCodeType CMD_TRD_PriceMonitor_Dele_RSP        = 0x2115;

//登录预警服务器请求
typedef struct TrdPriceMonitorLoginInfoReq{
	TrdUserNoType                                           UserNo;
	TrdTradePswType                                         UserPwd;//暂时没有用
	TrdPushAppIdType                                        AppId; //App Id
	TrdPushAppKeyType                                       AppKey; //App Key
	TrdPushAppMasterSecretType                              AppMasterSecret; //App Master Secret
	TrdPushClientIdType                                     CID; //设备client id
	TrdTerminalTypeType                                       DeviceType; //设备类型 Android IOS PC
}TrdPriceMonitorLoginInfoReq;

//登录预警服务器回复
typedef struct TrdPriceMonitorLoginInfoRsp{
	TrdUserNoType                                           UserNo;
	TrdErrorCodeType                                        ErrorCode;
	TrdErrorTextType                                        ErrorText;
}TrdPriceMonitorLoginInfoRsp;

//监控订单请求
typedef struct TrdPriceMonitorInsertReq{
	TrdUserNoType						UserNo;		//极星账号
	TrdContractNoType                                       ContractNo;     //监控合约
	//====================监控指标=======================//
	TrdPriceType						PriceMax1;	//价格上限1
	TrdPriceType                                            PriceMax2;	//价格上限2
	TrdPriceType						PriceMin1;	//价格下限1
	TrdPriceType                                            PriceMin2;	//价格下限2
	TrdPriceType						GrowthWidthMax; //涨幅上限
	TrdPriceType                                            GrowthWidthMin;	//涨幅下限
	TrdPriceType						GrowthSpeedMax; //速涨上限
	TrdPriceType                                            GrowthSpeedMin;	//速涨下限

	TrdQuantityType						LastVol;        //现手
	TrdQuantityType						Volume;         //成交量
	TrdQuantityType 					PositionMax;	//持仓量上限
	TrdQuantityType						PositionMin;	//持仓量下限

	TrdBoolType                                             LimitUp;	//涨停价
	TrdBoolType                                             LimitDown;	//跌停价

	TrdMonitorNumType                                       MonitorNum;     //触发次数 'O'只触发一次  'C'连续触发

	TrdSerialIdType                                         OrderReqId;     //监控Id（客户自己填写）
	TrdOrderMonitorRemarkType                                      MonitorRemark;  //监控备注
}TrdPriceMonitorInsertReq;
//监控订单应答
typedef struct TrdPriceMonitorInsertRsp{
	TrdUserNoType                                           UserNo;         //极星账号
	TrdContractNoType                                       ContractNo;     //监控合约
	TrdSerialIdType                                         OrderReqId;
	TrdOrderNoType                                          OrderNo;
	TrdDateTimeType                                         InsertDateTime;
	TrdOrderStateType                                       OrderState;
	TrdErrorCodeType                                        ErrorCode;
	TrdErrorTextType                                        ErrorText;
}TrdPriceMonitorInsertRsp;
//修改订单通知
typedef struct TrdPriceMonitorModifyRsp{
	TrdUserNoType                                           UserNo;         //极星账号
	TrdContractNoType                                       ContractNo;     //监控合约
	TrdSerialIdType                                         OrderReqId;
	TrdOrderNoType                                          OrderNo;
	TrdDateTimeType                                         UpdateDateTime;
	TrdOrderStateType                                       OrderState;
	TrdErrorCodeType                                        ErrorCode;
	TrdErrorTextType                                        ErrorText;
}TrdPriceMonitorModifyRsp;
//监控订单通知
typedef struct TrdPriceMonitorStateData {
	TrdMonitorNormValueType Value;      //具体数值用|分开;
	TrdMonitorNormRtnType Reason;       //报警原因用|分开;
	TrdDateTimeType UpdateTime;         //更新时间
}TrdPriceMonitorStateData;

typedef struct TrdPriceMonitorRtn{
	TrdUserNoType						                    UserNo;		//极星账号
	TrdContractNoType                                       ContractNo;     //监控合约
	//====================监控指标=======================//
	TrdPriceType						                    PriceMax1;	//价格上限1
	TrdPriceType                                            PriceMax2;	//价格上限2
	TrdPriceType						                    PriceMin1;	//价格下限1
	TrdPriceType                                            PriceMin2;	//价格下限2
	TrdPriceType						                    GrowthWidthMax; //涨幅上限
	TrdPriceType                                            GrowthWidthMin;	//涨幅下限
	TrdPriceType						                    GrowthSpeedMax; //速涨上限
	TrdPriceType                                            GrowthSpeedMin;	//速涨下限

	TrdQuantityType						                    LastVol;        //现手
	TrdQuantityType						                    Volume;         //成交量
	TrdQuantityType 					                    PositionMax;	//持仓量上限
	TrdQuantityType						                    PositionMin;	//持仓量下限

	TrdBoolType                                             LimitUp;	//涨停价
	TrdBoolType                                             LimitDown;	//跌停价

	TrdMonitorNumType                                       MonitorNum;     //触发次数 'O'只触发一次  'C'连续触发

	TrdSerialIdType                                         OrderReqId;     //监控Id（客户自己填写）
	TrdOrderMonitorRemarkType                               MonitorRemark;  //监控备注

	TrdOrderNoType                                          OrderNo;        //订单号
	TrdDateTimeType                                         InsertDateTime; //下单时间
	TrdDateTimeType						                    UpdateDateTime;	//最后一次更新时间
	TrdOrderStateType                                       OrderState;     //订单状态
//        TrdMonitorStateType                                     MonitorState;   //监控报警原因
	TrdErrorCodeType                                        ErrorCode;
	TrdErrorTextType                                        ErrorText;
	TrdMonitorStriggerCount                                 DataCount;      //若有数据 >= 1;无数据则为0;
	TrdPriceMonitorStateData                                Data[1];
}TrdPriceMonitorRtn;
//监控订单查询通知
typedef struct TrdPriceMonitorQryReq{
	TrdUserNoType                                               UserNo;
	TrdContractNoType                                           ContractNo;
}TrdPriceMonitorQryReq;

typedef TrdPriceMonitorQryReq                                   TrdPriceMonitorQryRsp;
typedef TrdPriceMonitorRtn                                      TrdPriceMonitorQryData;

typedef TrdPriceMonitorQryReq                                   TrdPriceMonitorDeleReq;
typedef TrdPriceMonitorQryReq                                   TrdPriceMonitorDeleRsp;
//监控订单操作请求
typedef struct TrdPriceMonitorActionReq {
	TrdUserNoType UserNo;
	TrdOrderNoType OrderNo;
	TrdSingleContractNoType ContractNo; //合约编号
	TrdSerialIdType OrderReqId;
	TrdOrderActionTypeType OrderActionType; //定单操作类型
} TrdPriceMonitorActionReq;

typedef TrdPriceMonitorModifyRsp                               TrdPriceMonitorActionRsp;

typedef struct TrdPriceMonitorModifyReq{
	TrdUserNoType						UserNo;		//极星账号
	TrdContractNoType                                       ContractNo;     //监控合约
	//====================监控指标=======================//
	TrdPriceType						PriceMax1;	//价格上限1
	TrdPriceType                                            PriceMax2;	//价格上限2
	TrdPriceType						PriceMin1;	//价格下限1
	TrdPriceType                                            PriceMin2;	//价格下限2
	TrdPriceType						GrowthWidthMax; //涨幅上限
	TrdPriceType                                            GrowthWidthMin;	//涨幅下限
	TrdPriceType						GrowthSpeedMax; //速涨上限
	TrdPriceType                                            GrowthSpeedMin;	//速涨下限

	TrdQuantityType						LastVol;        //现手
	TrdQuantityType						Volume;         //成交量
	TrdQuantityType 					PositionMax;	//持仓量上限
	TrdQuantityType						PositionMin;	//持仓量下限

	TrdBoolType                                             LimitUp;	//涨停价
	TrdBoolType                                             LimitDown;	//跌停价

	TrdMonitorNumType                                       MonitorNum;     //触发次数 'O'只触发一次  'C'连续触发

	TrdSerialIdType                                         OrderReqId;     //监控Id（客户自己填写）
	TrdOrderMonitorRemarkType                                      MonitorRemark;  //监控备注

	TrdOrderNoType                                          OrderNo;        //订单号
}TrdPriceMonitorModifyReq;

//重置密码验证身份信息
static const CspProtocolCodeType CMD_TRD_VERIFY_IDENTITY_REQ = 0x2601;
static const CspProtocolCodeType CMD_TRD_VERIFY_IDENTITY_RSP = 0x2602;

typedef C8 TrdCertificateType;
static const TrdCertificateType TRD_CT_ID                       = '1';           //内地身份证
static const TrdCertificateType TRD_CT_Passport                 = '6';          //中国护照，内地港澳通行证
static const TrdCertificateType TRD_CT_BusinessLicense          = '9';          //营业执照
static const TrdCertificateType TRD_CT_OtherID                  = 'B';          //证件类型B 其他身份证
static const TrdCertificateType TRD_CT_BusinessRegistration     = 'R';          //证件类型X 商业登记证

typedef STR50 TrdCertificateNoType;
typedef STR40 TrdCertificateEMailType;
typedef STR20 TrdCertificatePhoneNoType;

typedef struct TrdVerifyIdentityReq {
	TrdUserNoType               UserNo;                 //用户UserNo
	TrdCertificateType          CertificateType;        //验证类型  大陆身份证，护照。。。
	TrdCertificateNoType        CertificateNo;          //身份证ID，护照ID。
	TrdCertificateEMailType     EMail;                  //注册的邮箱
	TrdCertificatePhoneNoType   PhoneNo;                //注册时使用的号码
}TrdVerifyIdentityReq;

typedef struct TrdVerifyIdentityRsp {
	TrdUserNoType UserNo;
}TrdVerifyIdentityRsp;

//重置密码 验证码
static const CspProtocolCodeType CMD_TRD_SEC_VERTIFICATION_REQ = 0x2605;
static const CspProtocolCodeType CMD_TRD_SEC_VERTIFICATION_RSP = 0x2606;

typedef C8      TrdPasswordType;
static const TrdPasswordType TRD_PT_Trader                     = 'T';           //交易
static const TrdPasswordType TRD_PT_Reset                      = 'R';           //重置密码
typedef STR10   TrdVertificateCodeType;
typedef STR10   TrdVertificateCodeSecondDateType;

typedef struct TrdCertificationSecondReq{
	TrdPasswordType PasswordType;
	TrdVertificateCodeType VertificateCode;
	TrdSecondLoginTypeType  LoginType;
}TrdCertificationSecondReq;

typedef struct TrdCertificationSecondRsp{
	TrdPasswordType PasswordType;
	TrdVertificateCodeType VertificateCode;
	TrdVertificateCodeSecondDateType  SecondDate;
}TrdCertificationSecondRsp;


#pragma pack(pop)

#endif