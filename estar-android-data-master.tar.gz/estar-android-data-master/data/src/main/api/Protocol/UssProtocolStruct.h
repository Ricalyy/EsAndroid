#pragma once

#pragma pack(push, 1)


static const CspProtocolCodeType       CMD_USS_UserBehavior_Req = 0x1000;

static const CspProtocolCodeType       CMD_USS_UserBehavior_Rsp = 0x1001;



struct  UssUserBehaviorInfo
{
    STR20                           LocalTime;
    
    STR10                           PackageNo;
    STR50                           HostName;
    STR50                           MACAddr;
	STR50                           LocalIP;
	U16                             LocalPort;
	
    STR50                           OsInfo;
    STR50                           CpuId;
    STR50                           CpuInfo;
    STR50                           MemInfo;
    STR50                           GraphicsInfo;
    STR50                           DpiInfo;
    
    STR20                           ProductInfo;  
    STR20                           ProductVersion; 
  
    STR50                           UserNo;
    STR20                           LoginApi;
    
                               
    STR10                           CompanyNo;
    STR50                           CompanyName;
    STR20                           AddrNo;
    STR50                           AddrName;
	STR50                           ServerIP;                                //登录IP
	U16                             ServerPort;                              //登录端口
    STR10                           BrokerId;
    STR20                           TradeCert;         
    
    
};

struct  UssUserBehaviorRsp
{
   
};


static const CspProtocolCodeType       CMD_USS_UserMainFrame_Req = 0x1010;

static const CspProtocolCodeType       CMD_USS_UserMainFrame_Rsp = 0x1011;


struct UssUserMainFrameInfo
{
    STR20                       LocalTime;
    
    STR10                       PackageNo;
    STR50						HostName;
    STR50						MACAddr;
	STR50						LocalIP;
	U16                         LocalPort;
	
    STR50                       OsInfo;
    STR50                       CpuId;
    STR50                       CpuInfo;
    STR50                       MemInfo;
    STR50                       GraphicsInfo;
    STR50                       DpiInfo;
    
    STR20                       ProductInfo;  
    STR20                       ProductVersion; 
    
    STR50                       MainClass;
    STR50                       MainCaption;
    I32                         MainX;
    I32                         MainY;
    I32                         MainW;
    I32                         MainH;
    STR50                       ChildName;
    I32                         ChildGroup;
    I32                         ChildX;
    I32                         ChildY;
    I32                         ChildW;
    I32                         ChildH;
    
    
    
};



static const CspProtocolCodeType       CMD_USS_UserSpread_Req   =0x1020;

static const CspProtocolCodeType       CMD_USS_UserSpread_Rsp = 0x1021;

struct UssUserSpreadInfo
{
    STR20                       LocalTime;
    
    STR10                       PackageNo;
    STR50						HostName;
    STR50						MACAddr;
	STR50						LocalIP;
	U16                         LocalPort;
	
    STR50                       OsInfo;
    STR50                       CpuId;
    STR50                       CpuInfo;
    STR50                       MemInfo;
    STR50                       GraphicsInfo;
    STR50                       DpiInfo;
    
    STR20                       ProductInfo;  
    STR20                       ProductVersion; 
    
    STR50                       ContractNo1;
    STR50                       ContractNo2;
    C8                          QuoteMode1;
    C8                          QuoteMode2;
    C8                          QuoteMode3;
    F64                         QuoteRate1;
    F64                         QuoteRate2;
    F64                         QuoteRate3;
    F64                         QuoteRate4;
    C8                          TradeMode;
    I32                         TradeRate1;
    I32                         TradeRate2;
    I32                         TradeRate3;
    I32                         TradeRate4;
    
};


static const CspProtocolCodeType       CMD_USS_UserStopLoss_Req = 0x1030;

static const CspProtocolCodeType       CMD_USS_UserStopLoss_Rsp = 0x1031;


struct UssUserStopLossInfo
{
    STR20                       LocalTime;
    
    STR10                       PackageNo;
    STR50						HostName;
    STR50						MACAddr;
	STR50						LocalIP;
	U16                         LocalPort;
	
    STR50                       OsInfo;
    STR50                       CpuId;
    STR50                       CpuInfo;
    STR50                       MemInfo;
    STR50                       GraphicsInfo;
    STR50                       DpiInfo;
    
    STR20                       ProductInfo;  
    STR20                       ProductVersion; 
    
    STR50                       ContractNo;
    I32                         StopLoss;
    I32                         FloatLoss;
    I32                         StopProfit;
    I32                         KeepProfit;
 };

static const CspProtocolCodeType       CMD_USS_UserSelectContract_Req = 0x1050;
typedef struct UssUserSelectContractReq
{
    STR20                       LocalTime;                              //本机时间,格式为"YYYY-MM-DD HH-mm-ss"
    
    STR10                       PackageNo;                              //包号
    STR50                       HostName;                               //主机名
    STR50                       MacAddr;                                //Mac地址
    STR50                       LocalIP;                                //本机IP
    U16                         LocalPort;                              //本机端口号
    
    STR20                       ProductInfo;                            //产品(客户端)信息
    STR20                       ProductVersion;                         //产品(客户端)版本号
    
    STR50                      ContractNo;                             //自选合约
}UssUserSelectContractReq;

#pragma pack(pop)
