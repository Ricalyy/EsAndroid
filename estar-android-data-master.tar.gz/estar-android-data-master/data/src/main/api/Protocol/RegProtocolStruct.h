#ifndef _REG_PROTOCOL_STRUCT_H
#define _REG_PROTOCOL_STRUCT_H

#pragma pack(push, 1)
#include "RegProtocolType.h"
 //用户登录
static const CspProtocolCodeType           CMD_REG_UserLogin_Req       = 0x1000;
static const CspProtocolCodeType           CMD_REG_UserLogin_Rsp       = 0x1001;
static const CspProtocolCodeType           CMD_REG_UserLogout_Req      = 0x1002;
static const CspProtocolCodeType           CMD_REG_UserLogout_Rsp      = 0x1003;

typedef  struct RegUserLoginReq
{
    RegPackageNoType                PackageNo;
    RegLoginTypeType                LoginType;                      //登录类型
    RegLoginNoType                  LoginNo;                        //登录名
    RegPasswordType                 Password;                       //登录密码
}RegUserLoginReq;

//客户端用户应答
typedef struct RegUserLoginRsp
{
   RegPackageNoType                 PackageNo;
   RegLoginTypeType                 LoginType;                      //登录类型
   RegUUIdType                      UUId;                           //用户唯一ID
   RegLoginNoType                   LoginNo;                        //登录名，用户名或邮箱地址或手机号
   RegLoginDateType                 LoginDate;                      //登录日期.客户端校验授权日期,防止用户改本地时间
   RegLoginIPType                   LastLoginIP;
   RegLoginTimeType					LastLoginTime;
   
 }RegUserLoginRsp;
 
typedef struct RegUserLogoutReq
{
    RegPackageNoType                PackageNo;
    RegLoginTypeType                LoginType;                      //登录类型
    RegUUIdType                     UUId;                           //用户唯一ID
    RegLoginNoType                  LoginNo;                        //登录名           
}RegUserLogoutReq;

typedef struct RegUserLogoutRsp
{

}RegUserLogoutRsp;
 

//用户指数查询
static const CspProtocolCodeType           CMD_REG_UserIndex_Qry_Req = 0x2010;
static const CspProtocolCodeType           CMD_REG_UserIndex_Qry_Rsp = 0x2011;
  //***********************************************

//用户指数关系查询请求
typedef struct RegUserIndexQryReq
{
      RegUUIdType                     UUId;               //用户唯一ID
      
}RegUserIndexQryReq;

  //用户指数关系查询应答
 typedef struct RegUserIndexQryRsp
  {
      RegUUIdType                     UUId;               //用户唯一ID
      RegIndexNoType                  IndexNo;            //指数编号
  }RegUserIndexQryRsp;


static  const CspProtocolCodeType           CMD_REG_UserCommGroup_Qry_Req = 0x2020;
    
static  const CspProtocolCodeType           CMD_REG_UserCommGroup_Qry_Rsp = 0x2021;

typedef struct RegUserCommGroupQryReq
{
     RegUUIdType                      UUId;               //用户唯一ID
     RegCompanyNoType                 CompanyNo;
}RegUserCommGroupQryReq;
  
typedef struct RegUserCommGroupQryRsp
{
      RegUUIdType                     UUId;               //用户唯一ID
      RegLoginNoType                  UserNo;
      RegGroupNoType                  GroupNo;            //品种组号
      SDATE                           BeginDate;         //开始日期
      SDATE                           ExpireDate;        //截止日期
}RegUserCommGroupQryRsp;


static const CspProtocolCodeType			CMD_REG_ConfigGroupQry_Req = 0x2030;

static const CspProtocolCodeType			CMD_REG_ConfigGroupQry_Rsp = 0x2031;

static const CspProtocolCodeType			CMD_REG_ConfigGroupAdd_Req = 0x2032;

static const CspProtocolCodeType			CMD_REG_ConfigGroupAdd_Rsp = 0x2033;

static const CspProtocolCodeType			CMD_REG_ConfigGroupDel_Req = 0x2034;

static const CspProtocolCodeType			CMD_REG_ConfigGroupDel_Rsp = 0x2035;

 //查询时只用前两个参数
typedef struct RegUserConfigGroupQryReq
{
    RegUUIdType              UUId;               //用户唯一ID
    RegGroupNoType           GroupNo;
    RegStrType               Key;
    RegIntType               KeyIndex;
}RegUserConfigGroupQryReq;

typedef struct RegUserConfigGroupQryRsp
{
    RegUUIdType             UUId;               //用户唯一ID
    RegGroupNoType          GroupNo;
    RegStrType              Key;
    RegIntType              KeyIndex;
    RegStrType              ValueStr;
    RegIntType              ValueInt;
    RegDoubleType           ValueDouble;
}RegUserConfigGroupQryRsp;


typedef     RegUserConfigGroupQryRsp        RegUserConfigGroupAddReq;

typedef     RegUserConfigGroupQryReq        RegUserConfigGroupDelReq;   

static const CspProtocolCodeType			CMD_REG_UserPluginInfo_Req = 0x2040;

static const CspProtocolCodeType			CMD_REG_UserPluginInfo_Rsp = 0x2041;

typedef struct  RegUserPluginQryReq
{
     RegUUIdType             UUId;               //用户唯一ID         
}RegUserPluginQryReq;

typedef struct RegUserPluginQryRsp
{
    RegUUIdType             UUId;               //用户唯一ID     
    RegLoginNoType          UserNo;
    RegPluginNoType         PluginNo;
    RegGroupNoType          GroupNo;
    SDATE                   BeginDate;
    SDATE                   EndDate;
    RegOperateType          OperateRight;
    
}RegUserPluginQryRsp;

#pragma pack(pop)

#endif
