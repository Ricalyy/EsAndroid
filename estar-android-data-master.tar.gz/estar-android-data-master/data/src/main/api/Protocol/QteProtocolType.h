/************************************************************************
Copyright (c) 2016-2017 Zhengzhou Esunny Information & Technology Co,.Ltd
File name: QteProtocolType.h
Author: Fanliangde     Version:1.0          Date:2018/1/17
Description: 极星行情后台协议,提供基础数据类型定义
1. 结构体定义采用typedef struct AAA{}AAA;方式
2. 常量定义采用static const Type A = xxx;方式
3. 统一结构和类型的前缀为Qte,常量前缀为QTE_
4. 内部字符串编码格式统一为UTF-8
5. 协议号以CMD_QTE_XXXX格式命名
6. 本协议适用于行情前置、历史行情、指数、波动率、套利、延时服务器以及客户端

History:
1. 初始创建，2018.01.17 Fanliangde
************************************************************************/

#ifndef _QTE_PROTOCOL_TYPE_H_
#define _QTE_PROTOCOL_TYPE_H_

#include "CspProtocol.h"

#pragma pack(push, 1)

//单个数据帧最大数据个体数量，x为数据体类型
#define QTE_FIELD_MAX(x)            ((CSP_FRAME_MAX / sizeof(x) - 5 < 1000) ? (CSP_FRAME_MAX / sizeof(x) - 5) : 1000)

///////////////////////////////////////币种类型定义//////////////////////////////////
typedef STR10                          QteCurrencyNoType;                        //币种编号
typedef F64                            QteExchangeRateType;                      //汇率,小数形式，不按百分制/千分制存储
typedef F64                            QteInterestRateType;                      //利率，小数形式，不按百分制/千分制存储

////////////////////////////////////////抵押品类型定义//////////////////////////////////
typedef STR10                          QteMortgageNoType;                        //币种编号
typedef F64                            QteProportionType;                        //抵押比例，小数形式，不按百分制/千分制存储

////////////////////////////////////////交易单位类型定义/////////////////////////////
typedef STR10                          QteTradingUnitNoType;                     //交易单位编号
typedef STR50                          QteTradingUnitNameType;                   //交易单位名称

///////////////////////////////////////报价单位类型定义////////////////////////////////////
typedef STR10                          QteQuoteUnitNoType;                       //报价单位编号
typedef STR50                          QteQuoteUnitNameType;                     //报价单位名称

///////////////////////////////////////交易所类型定义////////////////////////////////////
typedef STR10                          QteExchangeNoType;                        //交易所编号
typedef STR50                          QteExchangeNameType;                      //交易所名称

///////////////////////////////////////品种定义//////////////////////////////////////////
typedef STR20                          QteCommodityIdType;                       //品种编号类型
typedef STR50                          QteCommodityNameType;                     //品种名称类型
typedef F64                            QteCommodityTickType;                     //最小变动价类型
typedef U16                            QteCommodityDenoType;                     //报价分母类型
typedef F32                            QtePriceMultipleType;                     //执行价格倍数类型

typedef F64                            QteCommodityDotType;                      //每手乘数
typedef F64                            QteExecuteDotType;                        //行权乘数
typedef STR10                          QteDepositGroupNoType;                    //大边的保证金组号
typedef U32                            QteMaxSingleOrderQtyType;                 //单笔最大下单量
typedef U32                            QteMaxPositionQtyType;                    //最大持仓量

typedef U32                            QteVolChgFieldType;                       //成交量增量
typedef I32                            QtePosChgFieldType;                       //持仓增量 可以为负

typedef C8                             QteCoverModeType;                         //平仓模式
static const QteCoverModeType          QTE_COVERMODE_NONE               = 'N';   //不区分开平
static const QteCoverModeType          QTE_COVERMODE_UNFINISH           = 'U';   //平仓未了结
static const QteCoverModeType          QTE_COVERMODE_COVER              = 'C';   //开仓、平仓
static const QteCoverModeType          QTE_COVERMODE_TODAY              = 'T';   //开仓、平仓、平今

///////////////////////////////////////品种所属模块定义////////////////////////////////////
typedef U32                            QteCommodityBelongType;                   //品种所属服务器，32位，每位表示一个服务器，置1表示该品种在该服务器生效

typedef U8                             QteCommodityMaskType;                     //各模块品种掩码
static const QteCommodityMaskType      QTE_COMM_MASK_QUOTEI             =  1;    //内盘行情前置，从右到左第1位
static const QteCommodityMaskType      QTE_COMM_MASK_SIGMA              =  2;    //波动率服务器，从右到左第2位
static const QteCommodityMaskType      QTE_COMM_MASK_TRADE              =  3;    //交易服务器，  从右到左第3位
static const QteCommodityMaskType      QTE_COMM_MASK_QUOTEM             =  4;    //手机行情前置，从右到左第4位
static const QteCommodityMaskType      QTE_COMM_MASK_HISQUOTE           =  5;    //历史服务器，  从右到左第5位
static const QteCommodityMaskType      QTE_COMM_MASK_QUOTEF             =  6;    //外盘行情前置，从右到左第6位
static const QteCommodityMaskType      QTE_COMM_MASK_QUOTET             =  7;    //测试行情前置，从右到左第7位
static const QteCommodityMaskType      QTE_COMM_MASK_QUOTEB             =  8;    //自建行情前置，从右到左第8位
static const QteCommodityMaskType      QTE_COMM_MASK_SPREAD             =  9;    //套利服务器，  从右到左第9位
static const QteCommodityMaskType      QTE_COMM_MASK_RESET              =  10;   //清盘网关，    从右到左第10位
static const QteCommodityMaskType      QTE_COMM_MASK_INDEX              =  11;   //指数服务器，  从右到左第11位
static const QteCommodityMaskType      QTE_COMM_MASK_SIMTRADE           =  12;   //模拟撮合平台，从右到左第12位

///////////////////////////////////////套利定义////////////////////////////////////////////
typedef C8                             QteOperatorType;                          //运算符

typedef F64                            QtePricePropType;                         //价格配比
typedef U32                            QteQtyPropType;                           //数量配比

typedef C8                             QteSpreadDirectType;                      //组合买卖标记
static const QteSpreadDirectType       QTE_SPREADDIRECT_NONE            = '0';   //无
static const QteSpreadDirectType       QTE_SPREADDIRECT_FIRST           = '1';   //第一腿
static const QteSpreadDirectType       QTE_SPREADDIRECT_SECOND          = '2';   //第二腿

///////////////////////////////////////期权定义///////////////////////////////////////////
typedef C8                             QteOptionTypeType;                        //期权类型
static const QteOptionTypeType         QTE_OPTIONTYPE_FUTURE            = 'F';   //期货期权
static const QteOptionTypeType         QTE_OPTIONTYPE_STOCK             = 'S';   //股票期权
static const QteOptionTypeType         QTE_OPTIONTYPE_INDEX             = 'I';   //指数期权
static const QteOptionTypeType         QTE_OPTIONTYPE_RATE              = 'R';   //利率期权
static const QteOptionTypeType         QTE_OPTIONTYPE_CURRENCY          = 'C';   //货币期权

typedef C8                             QteExecuteWayType;                        //行权方式
static const QteExecuteWayType         QTE_EXECUTE_AMERICAN             = 'A';   //美式行权方式
static const QteExecuteWayType         QTE_EXECUTE_EUROPEAN             = 'E';   //欧式行权方式
static const QteExecuteWayType         QTE_EXECUTE_BERMUDA              = 'B';   //百慕大行权方式

typedef C8                             QteOptionDirectType;
static const QteOptionDirectType       QTE_CALL_OPTION                  = 'C';   //看涨期权
static const QteOptionDirectType       QTE_PUT_OPTION                   = 'P';   //看跌期权

///////////////////////////////////////指数定义///////////////////////////////////////////
typedef C8                             QteIndexCalType;                          //指数品种计算类型
static const QteIndexCalType           QTE_INDEX_CAL_NONE               = '\0';  //不计算
static const QteIndexCalType           QTE_INDEX_CAL_ALL                = '*';   //计算全部
static const QteIndexCalType           QTE_INDEX_CAL_MAIN               = 'M';   //只计算主连
static const QteIndexCalType           QTE_INDEX_CAL_NEARBY             = 'N';   //只计算近月
static const QteIndexCalType           QTE_INDEX_CAL_INDEX              = 'I';   //只计算指数

///////////////////////////////////////品种类型定义//////////////////////////////////
typedef C8                             QteCommodityTypeType;                     //品种类型类型
static const QteCommodityTypeType	   QTE_COMM_TYPE_SPOT               = 'P';   //现货
static const QteCommodityTypeType	   QTE_COMM_TYPE_SPOT_T             = 'Y';   //现货,T+1
static const QteCommodityTypeType	   QTE_COMM_TYPE_FUTURES			= 'F';   //期货
static const QteCommodityTypeType	   QTE_COMM_TYPE_OPTION			    = 'O';   //期权
static const QteCommodityTypeType	   QTE_COMM_TYPE_SPREADS		    = 'S';   //跨期套利
static const QteCommodityTypeType	   QTE_COMM_TYPE_SPREADM            = 'M';   //跨品种套利
static const QteCommodityTypeType	   QTE_COMM_TYPE_ES_SPREADS		    = 's';   //极星跨期套利
static const QteCommodityTypeType	   QTE_COMM_TYPE_ES_SPREADM         = 'm';   //极星跨品种套利
static const QteCommodityTypeType	   QTE_COMM_TYPE_ES_SPREADY         = 'y';   //极星现货期货套利
static const QteCommodityTypeType	   QTE_COMM_TYPE_INDEX			    = 'Z';   //指数
static const QteCommodityTypeType	   QTE_COMM_TYPE_STOCK			    = 'T';   //股票
static const QteCommodityTypeType	   QTE_COMM_TYPE_DIRECTFOREX		= 'X';   //外汇 直接汇率 USD是基础货币
static const QteCommodityTypeType	   QTE_COMM_TYPE_INDIRECTFOREX	    = 'I';   //外汇 间接汇率
static const QteCommodityTypeType	   QTE_COMM_TYPE_CROSSFOREX		    = 'C';   //外汇 交叉汇率
static const QteCommodityTypeType	   QTE_COMM_TYPE_OTCOPTION		    = 'Q';   //场外期权
static const QteCommodityTypeType	   QTE_COMM_TYPE_EFP    		    = 'A';   //期转现

///////////////////////////////////////合约代码类型定义//////////////////////////////////
/*
    ----------------------------------------------------------------------
    <>     必填内容,[] 可选内容, | 分割符

    EXG    交易所代码; TYPE 品种类型，单字符;  ROOT 品种代码

    YEAR   四位年份或者年份后两位数字或者年份最后一位数字,2018或18或8

    MONTH  两位月份; DAY 两位日期 ;

    CP 期权看涨看跌标识,看涨(C),看跌(P);  STRIKE 执行价

    极星跨品种套利最多支持4腿，品种之间通过运算符连接，有+(价和),-(价差),/(价比)
    ---------------------------------------------------------------------
   |品种类型         |  合约代码                                     |
    ---------------------------------------------------------------------
    期货、现货、指数 | <EXG>|<TYPE>    |<ROOT>|<YEAR><MONTH>[DAY]
    期权             | <EXG>|<TYPE>    |<ROOT>|<YEAR><MONTH>[DAY]<CP><STRIKE>
    跨期套利         | <EXG>|<TYPE>    |<ROOT>|<YEAR><MONTH>[DAY]|<YEAR><MONTH>[DAY]
    跨品种套利       | <EXG>|<TYPE>    |<ROOT&ROOT>|<YEAR><MONTH>[DAY]
    极星跨期套利     | <EXG>|s|<ROO    T>|<YEAR><MONTH>[DAY]|<YEAR><MONTH>[DAY]
    极星跨品种套利   | <EXG>|m|<ROO    T-ROOT>|<YEAR><MONTH>|<YEAR><MONTH>
    极星现货期货套利 | <EXG>|p|<ROO    T-ROOT>||<YEAR><MONTH>
*/

typedef STR50                          QteContractIdType;                        //合约编号
typedef STR50                          QteContractNameType;                      //合约名称

typedef VSTR8                          QteContType;                              //变长合约编号
typedef VSTR8                          QteContNameType;                          //变长合约名称

typedef U16                            QteContVarDataSize;                       //包含变长合约的数据个数

typedef F64                            QteContractDotType;                       //合约每手乘数

typedef STR50                          QteOptionSerialIdType;                    //期权序列类型

///////////////////////////////////////模块类型定义/////////////////////////////////////////
typedef C8                             QteModuleTypeType;                        //模块类型

static const QteModuleTypeType         QTE_MODULE_MANAGER               = 'M';   //行情管理终端
static const QteModuleTypeType         QTE_MODULE_QUOTER                = 'Q';   //行情前置
static const QteModuleTypeType         QTE_MODULE_HISQUOTER             = 'H';   //历史行情服务器
static const QteModuleTypeType         QTE_MODULE_INNER                 = 'N';   //com5
static const QteModuleTypeType         QTE_MODULE_SIGMA                 = 'V';   //波动率服务器
static const QteModuleTypeType         QTE_MODULE_SPREAD                = 'S';   //套利服务器
static const QteModuleTypeType         QTE_MODULE_WIN_CLIENT            = 'W';   //Windows客户端
static const QteModuleTypeType         QTE_MODULE_IOS_CLIENT            = 'I';   //iOS客户端
static const QteModuleTypeType         QTE_MODULE_ANDROID_CLIENT        = 'A';   //Android客户端
static const QteModuleTypeType         QTE_MODULE_TRADE                 = 'T';   //交易服务
static const QteModuleTypeType         QTE_MODULE_GATEWAY               = 'G';   //网关类型
static const QteModuleTypeType         QTE_MODULE_HISOPTER              = 'O';   //新历史整合服务器
static const QteModuleTypeType         QTE_MODULE_HISDCACHE             = 'A';   //数据中心缓存服务
static const QteModuleTypeType         QTE_MODULE_HISQCACHE             = 'B';   //行情中心缓存服务
static const QteModuleTypeType         QTE_MODULE_HISCALCULATE          = 'C';   //行情中心计算服务

typedef STR50                          QteModuleNameType;                        //模块名
typedef STR50                          QteModulePasswordType;                    //模块密码
typedef STR10                          QteDateStrType;                           //字符串日期格式，格式为YYYY-MM-DD
typedef STR100                         QteModuleCompanyType;                     //公司名称
typedef STR200                         QteModuleAddressType;                     //公式地址

///////////////////////////////////////用户类型定义///////////////////////////////////////////////

typedef STR50                          QteUserNameType;                          //用户名
typedef STR20                          QteUserPasswordType;                      //密码
typedef STR20                          QteRegisterTimeType;                      //注册时间,格式为YYYY-MM-DD HH-mm-ss
typedef I32                            QteLoginCountType;                        //最大连接数

typedef C8                             QteLicenseNoType[51];                     //软件授权号类型
static const QteLicenseNoType          QTE_DEFAULT_LICENSE_NO = "epolestar v9.3";//极星客户端授权号
static const QteLicenseNoType          QTE_DEFAULT_LICENSE_NO_NEW = "epolestar v9.3.1";//极星客户端授权号 30版以后用该授权号（客户端发送品种组）

typedef C8                             QteReservedInfoType[51];                  //客户预留信息类型

///////////////////////////////////////行情定义/////////////////////////////////////////////////////

typedef F64                            QtePriceFieldType;                        //价格字段类型

typedef U64                            QteQtyFieldType;                          //数量字段类型

typedef U64                            QteQuoteDateTimeType;                     //行情数据包日期类型,如20140506,不同的位置代表年月日

typedef U32                            QteQuoteDateType;                         //行情数据包时间类型,如093015123,不同的位置代表时分秒毫秒

typedef U32                            QteQuoteTimeType;

typedef C8                             QteQuoteStrType[8];                       //行情字段，字符串类型

typedef C8                             QteQuoteCharType;                         //行情字段，字符类型

typedef U8                             QteQuoteFieldCountType;                   //行情字段个数

typedef U8                             QteSnapShotType;                          //行情类型

static const QteSnapShotType           QTE_SNAP_LV1_RSP                 = 0x01;  //普通行情应答
static const QteSnapShotType           QTE_SNAP_LV1_NOTICE              = 0x02;  //普通行情推送
static const QteSnapShotType           QTE_SNAP_LV2_RSP                 = 0x03;  //深度行情应答
static const QteSnapShotType           QTE_SNAP_LV2_NOTICE              = 0x04;  //深度行情推送
static const QteSnapShotType           QTE_SNAP_SIGMA_RSP               = 0x05;  //波动率行情应答
static const QteSnapShotType           QTE_SNAP_SIGMA_NOTICE            = 0x06;  //波动率行情推送
static const QteSnapShotType           QTE_SNAP_COMM_STATE              = 0x07;  //品种状态
static const QteSnapShotType           QTE_SNAP_CONT_STATE              = 0x08;  //合约状态

///////////////////////////////////////深度行情定义/////////////////////////////////////////////////

typedef U16                            QteDepthLengthType;                       //价格深度类型

typedef U8                             QteDepthLevelType;                        //买卖方向类型

typedef U8                             QteDepthDirectType;                       //深度行情操作类型

typedef U8                             QteDepthActionType;                       //深度行情操作类型,高4位为买卖方向，低4位为操作标志

static const QteDepthActionType        QTE_DIRECT_BID                   = 0x00;  //买方向
static const QteDepthActionType        QTE_DIRECT_ASK                   = 0x10;  //卖方向
static const QteDepthActionType        QTE_DEPTH_ADD                    = 0x00;  //增加深度价格
static const QteDepthActionType        QTE_DEPTH_CHG                    = 0x01;  //修改深度数量
static const QteDepthActionType        QTE_DEPTH_DEL                    = 0x02;  //删除深度价格
static const QteDepthActionType        QTE_DEPTH_CLR                    = 0x03;  //清空整个方向深度数据

typedef C8                             QteLevelTypeType;                         //行情深度类型定义

static const QteLevelTypeType          QTE_LEVEL1                       = '1';   //普通行情
static const QteLevelTypeType          QTE_LEVEL2                       = '2';   //深度行情

///////////////////////////////////////行情字段定义/////////////////////////////////////////////////
//行情各字段含义定义
typedef U8                             QteQuoteFieldMeanType;

static const QteQuoteFieldMeanType     QTE_FIDM_PreClosingPrice         = 0;   //昨收盘价,QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_PreSettlePrice          = 1;   //昨结算价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_PrePositionQty          = 2;   //昨持仓量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_OpeningPrice            = 3;   //开盘价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_LastPrice               = 4;   //最新价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_HighPrice               = 5;   //最高价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_LowPrice                = 6;   //最低价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_HisHighPrice            = 7;   //历史最高价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_HisLowPrice             = 8;   //历史最低价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_LimitUpPrice            = 9;   //涨停价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_LimitDownPrice          = 10;  //跌停价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_TotalQty                = 11;  //当日总成交量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_PositionQty             = 12;  //持仓量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_AveragePrice            = 13;  //均价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_ClosingPrice            = 14;  //收盘价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_SettlePrice             = 15;  //结算价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_LastQty                 = 16;  //最新成交量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_BestBidPrice            = 17;  //最优买价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_BestBidQty              = 18;  //最优买量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_BestAskPrice            = 19;  //最优卖价 , QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_BestAskQty              = 20;  //最优卖量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_ImpliedBidPrice         = 21;  //隐含买价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_ImpliedBidQty           = 22;  //隐含买量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_ImpliedAskPrice         = 23;  //隐含卖价, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_ImpliedAskQty           = 24;  //隐含卖量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_TotalBidQty             = 25;  //委买总量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_TotalAskQty             = 26;  //委卖总量, QQtyFieldType
static const QteQuoteFieldMeanType     QTE_FIDM_TotalTurnOver           = 27;  //总成交额, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_Capitalization          = 28;  //总市值, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_Circulation             = 29;  //流通市值, QPriceFieldType类型
static const QteQuoteFieldMeanType     QTE_FIDM_TheoryPrice             = 30;  //理论价, QPriceFieldType类型,波动率行情
static const QteQuoteFieldMeanType     QTE_FIDM_Sigma                   = 31;  //波动率, QPriceFieldType类型,波动率行情
static const QteQuoteFieldMeanType     QTE_FIDM_Delta                   = 32;  //Delta, QPriceFieldType类型,波动率行情
static const QteQuoteFieldMeanType     QTE_FIDM_Gamma                   = 33;  //Gamma, QPriceFieldType类型,波动率行情
static const QteQuoteFieldMeanType     QTE_FIDM_Vega                    = 34;  //Vega, QPriceFieldType类型,波动率行情
static const QteQuoteFieldMeanType     QTE_FIDM_Theta                   = 35;  //Theta, QPriceFieldType类型,波动率行情
static const QteQuoteFieldMeanType     QTE_FIDM_Rho                     = 36;  //Rho, QPriceFieldType类型,波动率行情
static const QteQuoteFieldMeanType     QTE_FIDM_IntrinsicValue          = 37;  //期权内在价值, QPriceFieldType类型,波动率行情
static const QteQuoteFieldMeanType     QTE_FIDM_UnderlyCont             = 38;  //虚拟合约对应的标的合约, QQuoteStrType类型
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg1BidPrice         = 39;  //第一腿买价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg2BidPrice         = 40;  //第二腿买价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg3BidPrice         = 41;  //第三腿买价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg4BidPrice         = 42;  //第四腿买价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg1AskPrice         = 43;  //第一腿卖价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg2AskPrice         = 44;  //第二腿卖价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg3AskPrice         = 45;  //第三腿卖价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg4AskPrice         = 46;  //第四腿卖价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg1LastPrice        = 47;  //第一腿最新价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg2LastPrice        = 48;  //第二腿最新价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg3LastPrice        = 49;  //第三腿最新价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_SpdLeg4LastPrice        = 50;  //第四腿最新价, QPriceFieldType类型,套利行情
static const QteQuoteFieldMeanType     QTE_FIDM_PreAveragePrice         = 51;  //昨日均价,前海交易所推, QPriceFieldType类型

//注意：增加新字段时，需修改下面字段值
static const QteQuoteFieldMeanType     QTE_FIDM_Invalid                 = 52;  //增加其他字段时，该值顺移

///////////////////////////////////////K线定义/////////////////////////////////////////

typedef I32                            QteKLineIndexType;                      //K线索引号

typedef C8                             QteKLineDataType;                       //K线类型
static const QteKLineDataType          QTE_KLINE_TYPE_TICK              = 'T'; //分笔明细
static const QteKLineDataType          QTE_KLINE_TYPE_MINUTE            = 'M'; //分钟
static const QteKLineDataType          QTE_KLINE_TYPE_DAY               = 'D'; //日线

typedef U32                            QteKLineHopeCountType;                  //K线期望查询条数

///////////////////////////////////////时间模板定义////////////////////////////////////
typedef STR10                          QteTemplateNoType;                      //时间模板编号

typedef U16                            QteTemplateIndexType;                   //时间模板索引类型

typedef C8                             QteDateFlagType;                        //日期标记

static const QteDateFlagType           QTE_DATEFLAG_PRE                 = '0'; //前一日时间
static const QteDateFlagType           QTE_DATEFLAG_CUR                 = '1'; //当日
static const QteDateFlagType           QTE_DATEFLAG_NEXT                = '2'; //下一日

///////////////////////////////////////交易状态定义///////////////////////////////////

typedef C8                             QteTradingStateType;                    //交易状态

static const QteTradingStateType       QTE_TRADE_STATE_BID              = '1'; //集合竞价
static const QteTradingStateType       QTE_TRADE_STATE_MATCH            = '2'; //集合竞价撮合
static const QteTradingStateType       QTE_TRADE_STATE_CONTINUOUS       = '3'; //连续交易
static const QteTradingStateType       QTE_TRADE_STATE_PAUSED           = '4'; //交易暂停
static const QteTradingStateType       QTE_TRADE_STATE_CLOSE            = '5'; //闭市
static const QteTradingStateType       QTE_TRADE_STATE_DEALLAST         = '6'; //闭市处理时间
static const QteTradingStateType       QTE_TRADE_STATE_SWITCHTRADE      = '0'; //交易日切换时间
static const QteTradingStateType       QTE_TRADE_STATE_UNKNOWN          = 'N'; //未知状态
static const QteTradingStateType       QTE_TRADE_STATE_INITIALIZE       = 'I'; //正初始化
static const QteTradingStateType       QTE_TRADE_STATE_READY            = 'R'; //准备就绪
static const QteTradingStateType       QTE_TRADE_STATE_CLOSE_RESET      = 'S'; //闭市重置数据

///////////////////////////////////////收费品种组类型定义//////////////////////////////////

typedef STR20                          QteCommGroupNoType;                     //收费品种组编号

typedef F64                            QteCommGroupPriceType;                  //品种组收费价格，小数点后面最多8位

///////////////////////////////////////行情来源类型定义//////////////////////////////////
typedef STR20                          QteChannelNoType;                       //行情源

typedef U16                            QteQuoteUpperType;                      //行情源下品种来源
static const QteQuoteUpperType         QTE_COM_UPPER_COM5               = 0;   //直连com5
static const QteQuoteUpperType         QTE_COM_UPPER_GW                 = 1;   //直连网关
static const QteQuoteUpperType         QTE_COM_UPPER_CTP                = 2;   //直连CTP
static const QteQuoteUpperType         QTE_COM_UPPER_COM3               = 3;   //直连com3

///////////////////////////////////////假期信息定义//////////////////////////////////
typedef STR10                          QteHolidayNoType;                       //节假日编号

typedef STR100                         QteHolidayReverseType;                  //备注信息

///////////////////////////////////////流量统计类型定义//////////////////////////////////
typedef F64                            QteFlowType;                            //流量数据类型,单位为KB
typedef F64                            QteBandWidthType;                       //带宽数据类型,单位为KB
typedef I32                            QteClientOnlineType;                    //客户在线数
typedef STR20                          QteRecordTimeType;                      //统计时间

///////////////////////////////////////管理平台消息定义/////////////////////////////////

typedef STR50                          QteTableNameType;                       //操作的数据表名
typedef STR100                         QteOperationDescribeType;               //操作描述
typedef STR20                          QteOperationTimeType;                   //操作时间，格式为YYYY-MM-DD HH-mm-ss

typedef C8                             QteQryTypeType;                         //查询操作类型标志
static const QteQryTypeType            QTE_QRY_USUAL                    = '0'; //查询指定数据或者所有
static const QteQryTypeType            QTE_QRY_CONTINUE                 = '1'; //续查

typedef U32                            QteQrySerialIdType;                     //序列号

typedef C8                             QteManageOptionType;                    //管理操作类型
static const QteManageOptionType       QTE_MGR_OPT_ADD                  ='A';  //增加了数据
static const QteManageOptionType       QTE_MGR_OPT_MOD                  ='M';  //修改了数据
static const QteManageOptionType       QTE_MGR_OPT_DEL                  ='D';  //删除了数据

///////////////////////////////////////品种冬令时夏令时批量修改定义//////////////////////////////////
typedef C8                             QteWinterSummerBatchType[1000];         //批量修改品种冬令时夏令时,内为交易所编号集合，以|为分隔符

typedef C8                             QteWinterSummerType;                    //冬令时、夏令时标记类型
static const QteWinterSummerType       QTE_WINTER                       = 'N'; //冬令时
static const QteWinterSummerType       QTE_SUMMER                       = 'Y'; //夏令时
static const QteWinterSummerType       QTE_TRANSITION                   = 'I'; //过渡状态

////////////////////////////////////////交易相关定义///////////////////////////////////////
typedef STR10                          QteBrokerNoType;                        //经济公司编号
typedef STR30                          QteBrokerApiType;                       //经济公司系统类型
typedef F64                            QtePriceFactorType;                     //价格换算系数


///////////////////////////////////////经济公司系统部署类型定义//////////////////////////////////
typedef STR20                          QteBrokerAddressNoType;                 //经济公司部署地址编号
typedef STR30                          QteBrokerAddressNameType;               //经济公司机器部署地址名称

typedef C8                             QteSimulationFlagType;                  //模拟标志类型

static const QteSimulationFlagType     QTE_SIMULATIONFLAG_ETP_Y         ='Y';  //是模拟
static const QteSimulationFlagType     QTE_SIMULATIONFLAG_ETP_N         ='N';  //不是模拟

typedef C8                             QteBrokerSysStatusType;                 //经济公司系统状态
static const QteBrokerSysStatusType    QTE_SYS_STATUS_NONE              ='0';  //无
static const QteBrokerSysStatusType    QTE_SYS_STATUS_ENABLE            ='E';  //正常
static const QteBrokerSysStatusType    QTE_SYS_STATUS_DISABLE           ='D';  //禁用
static const QteBrokerSysStatusType    QTE_SYS_STATUS_ABNORMAL          ='A';  //异常

typedef C8                             QteBrokerBusinessType;
static const QteBrokerBusinessType     QTE_BUSINESS_BTCHINA             = 'C'; //内盘期货
static const QteBrokerBusinessType     QTE_BUSINESS_BTFOREIGN           = 'F'; //外盘期货
static const QteBrokerBusinessType     QTE_BUSINESS_BTGLOD              = 'G'; //现货黄金
static const QteBrokerBusinessType     QTE_BUSINESS_BTSTOCK             = 'S'; //证券

typedef STR30                          QteBrokerLoginKeyType;                  //经济公司登录认证码

typedef C8                             QteBrokerAccessTypeType;                //登录通道类型

static const QteBrokerAccessTypeType   QTE_ACCESSTYPE_NONE              ='0';  //无
static const QteBrokerAccessTypeType   QTE_ACCESSTYPE_NAMESERVER        ='N';  //命名服务
static const QteBrokerAccessTypeType   QTE_ACCESSTYPE_FRONTSERVER       ='F';  //前置服务
static const QteBrokerAccessTypeType   QTE_ACCESSTYPE_TRADESERVER       ='T';  //交易服务

typedef STR50                          QteBrokerLocationType;                  //经济公司系统部署地理位置，例如浙江杭州

typedef STR20                          QteBrokerIpType;                        //经济公司系统IP

typedef U16                            QteBrokerPortType;                      //经济公司系统端口号

typedef STR10                          QteBrokerProtocolType;                  //经济公司所用传输层协议

typedef U16                            QteContractCountType;                   //行情排序合约数量

typedef C8                             QteContractSortType;                   //行情排序指标类型
static const QteContractSortType       QTE_CONTRACTSORT_TOTALQTY              = '0';  //成交量
static const QteContractSortType       QTE_CONTRACTSORT_TURNOVER              = '1';  //成交金额
static const QteContractSortType       QTE_CONTRACTSORT_POSITIONQTY           = '2';  //持仓量
static const QteContractSortType       QTE_CONTRACTSORT_POSITIONRISEQTY       = '3';  //日增仓
static const QteContractSortType       QTE_CONTRACTSORT_POSITIONRISEPERCENT   = '4';  //日增仓比
static const QteContractSortType       QTE_CONTRACTSORT_RISE                  = '5';  //涨跌
static const QteContractSortType       QTE_CONTRACTSORT_RISEPERCENT           = '6';  //涨跌幅

typedef C8                             QteUserRightType;                              //用户权限类型
static const QteUserRightType          QTE_USERRIGHT_GROUP                    = 'G';  //品种组
static const QteUserRightType          QTE_USERRIGHT_PLUGIN                   = 'P';  //插件

typedef STR20                          QteUserRightNoType;                            //品种组or插件号

#pragma pack(pop)



#endif
