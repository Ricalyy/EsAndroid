//
//  QProtocol.h
//  StarMobileApi
//
//  Created by sss on 2017/3/4.
//  Copyright © 2017年 sss. All rights reserved.
//

#ifndef QProtocol_h
#define QProtocol_h

#pragma pack(push, 1)

//变化长度字符串类型
typedef struct
{
    U8              Len;
    C8              Data[1];
} QVarStringType;

//基础类型====================================================================================
//数据帧头标志
typedef C8                                      QFrameFlagType;
static const QFrameFlagType                     Q_FRAME_FLAG                        = '+';

//数据帧数据内容类型
typedef C8                                      QFrameTypeType;
static const QFrameTypeType                     Q_FRAME_PLAIN                       = '1';
static const QFrameTypeType                     Q_FRAME_LZO                         = '2';
static const QFrameTypeType                     Q_FRAME_IDEA                        = '3';
static const QFrameTypeType                     Q_FRAME_LZO_IDEA                    = '4';
static const QFrameTypeType                     Q_FRAME_IDEA_DYN                    = '5';
static const QFrameTypeType                     Q_FRAME_LZO_IDEA_DYN                = '6';

//数据帧数据长度类型(不包含数据帧头长度)
typedef U32                                     QFrameSizeType;
static const QFrameSizeType                     Q_FRAME_MIN                         = 0;
static const QFrameSizeType                     Q_FRAME_MAX                         = 32 * 1024;

//协议版本号
typedef U16                                     QProtocolVersionType;
static const QProtocolVersionType               QPROTOCOL_VERSION                   = 3;

//会话编号类型(标识请求与应答一组会话的对应关系)
typedef U32                                     QSessionIdType;

//终端在单一前置的唯一标识
typedef U32                                     QLinkIdType;

//协议号(每种功能请求具备单独的协议号)
typedef U16                                     QProtocolCodeType;

//语言类型定义
typedef U16                                     QLanguageType;
static const QLanguageType                      Q_LANG_NONE                         = 0x0000;   //系统默认语言
static const QLanguageType                      Q_LANG_CHS                          = 0x0804;   //简体中文
static const QLanguageType                      Q_LANG_CHT                          = 0x0404;   //繁体中文
static const QLanguageType                      Q_LANG_ENU                          = 0x0409;   //英文

//包号类型定义
typedef STR10                                   QPackageNoType;

//报文链标识(标识报文在上下文的关系)
typedef U8                                      QChainType;
static const QChainType                         Q_CHAIN_END                         = '0';      //没有后续报文
static const QChainType                         Q_CHAIN_NOTEND                      = '1';      //还有后续报文

typedef U32                                     QFieldSizeType;                                 //数据体长度
typedef U16                                     QFieldCountType;                                //数据体个数

typedef U32                                     QErrorCodeType;                                 //错误码类型
static const QErrorCodeType                     Q_ERROR_SUCCEED                     = 0;        //成功
static const QErrorCodeType                     Q_INTERNAL_ERROR                    = 20001;    //系统内部错误
static const QErrorCodeType                     Q_LOGIN_PWD_ERROR                   = 20002;    //登录密码错误
static const QErrorCodeType                     Q_LOGIN_OUT_LIMIT_ERROR             = 20003;    //登录数量超出限制
static const QErrorCodeType                     Q_DEFAULT_RIGHTS_ERROR              = 20004;    //设置默认权限错误
static const QErrorCodeType                     Q_DISCONNECT_TO_MANAGER_ERROR       = 20005;    //与管理平台断开连接

//业务类型==============================================================================

typedef STR10                                   QCurrencyNoType;                                //币种编号
typedef F64                                     QExchangeRateType;                              //汇率,小数形式，不按百分制/千分制存储
typedef F64                                     QInterestRateType;                              //利率，小数形式，不按百分制/千分制存储

typedef STR10                                   QTradingUnitNoType;                             //交易单位编号
typedef STR50                                   QTradingUnitNameType;                           //交易单位名称

typedef STR10                                   QQuoteUnitNoType;                               //报价单位编号
typedef STR50                                   QQuoteUnitNameType;                             //报价单位名称

typedef STR10                                   QExchangeNoType;                                //交易所编号
typedef STR50                                   QExchangeNameType;                              //交易所名称

typedef STR20                                   QCommodityNoType;                               //品种编号类型
typedef STR50                                   QCommodityNameType;                             //品种名称类型
typedef F64                                     QCommodityTickType;                             //最小变动价类型
typedef U16                                     QCommodityDenoType;                             //报价分母类型
typedef F32                                     QPriceMultipleType;                             //执行价格倍数类型

typedef C8                                      QChargeFlagType;                                //是否为收费品种类型
static const QChargeFlagType                    Q_COMMODITY_CHARGE                  = 'Y';      //是收费品种
static const QChargeFlagType                    Q_COMMODITY_FREE                    = 'N';      //不是收费品种

typedef C8                                      QOptionTypeType;                                //期权类型
static const QOptionTypeType                    Q_OPTIONTYPE_FUTURE                 = 'F';      //期货期权
static const QOptionTypeType                    Q_OPTIONTYPE_STOCK                  = 'S';      //股票期权
static const QOptionTypeType                    Q_OPTIONTYPE_INDEX                  = 'I';      //指数期权
static const QOptionTypeType                    Q_OPTIONTYPE_RATE                   = 'R';      //利率期权
static const QOptionTypeType                    Q_OPTIONTYPE_CURRENCY               = 'C';      //货币期权

typedef C8                                      QExecuteWayType;                                //行权方式
static const QExecuteWayType                    Q_EXECUTE_AMERICAN                  = 'A';      //美式行权方式
static const QExecuteWayType                    Q_EXECUTE_EUROPEAN                  = 'E';      //欧式行权方式

typedef C8                                      QCoverModeType;                                 //平仓模式
static const QCoverModeType                     Q_COVERMODE_NONE                    = 'N';      //不区分开平
static const QCoverModeType                     Q_COVERMODE_UNFINISH                = 'U';      //平仓未了解
static const QCoverModeType                     Q_COVERMODE_COVER                   = 'C';      //开仓、平仓
static const QCoverModeType                     Q_COVERMODE_TODAY                   = 'T';      //开仓、平仓、平今

typedef C8                                      QSpreadDirectType;                              //组合买卖标记
static const QSpreadDirectType                  Q_SPREADDIRECT_NONE                 = '0';      //无
static const QSpreadDirectType                  Q_SPREADDIRECT_FIRST                = '1';      //第一腿
static const QSpreadDirectType                  Q_SPREADDIRECT_SECOND               = '2';      //第二腿

typedef F64                                     QCommodityDotType;                              //每手乘数
typedef F64                                     QExecuteDotType;                                //行权乘数
typedef STR10                                   QDepositGroupNoType;                            //大边的保证金组号
typedef U32                                     QMaxSingleOrderQtyType;                         //单笔最大下单量
typedef U32                                     QMaxPositionQtyType;                            //最大持仓量

typedef U32                                     QVolChgFieldType;                               //成交量增量
typedef I32                                     QPosChgFieldType;                               //持仓增量 可以为负


//合约名称类型===================================================================================
//合约信息定义
//合约编号 <>内容为必须, []内容为可选  |为分隔符
//Exg-交易所代码, Type-商品类型，单字符
//OFlag-期权标志, 单字符, P或者C
//Root-商品代码, YEAR-年份后两位数字, MONTH-两位月份代码数字, DAY两位日期
//期货格式   <Exg>|<Type>|<Root>|<YEAR><MONTH>[DAY]
//期权       <Exg>|<Type>|<Root>|<YEAR><MONTH>[DAY]<OFlag><STRIKEPRICE>
//跨期套利   <Exg>|<Type>|<Root>|<YEAR><MONTH>[DAY]|<YEAR><MONTH>[DAY]
//跨品种套利 <Exg>|<Type>|<Root&Root>|<YEAR><MONTH>[DAY]|<YEAR><MONTH>[DAY]
//期权套利   <Exg>|<Type>|<Root[&Root]>|<YEAR><MONTH>[DAY]<OFlag><STRIKEPRICE>|<YEAR><MONTH>[DAY]<OFlag><STRIKEPRICE>
typedef STR50                                   QContractNoType;                                //合约编号
typedef STR50                                   QContractNameType;                              //合约名称

typedef QVarStringType                          QContType;                                      //变长合约编号
typedef QVarStringType                          QContNameType;                                  //变长合约名称

typedef STR10                                   QPlateNoType;                                   //板块号
typedef STR50                                   QPlateNameType;                                 //板块名称

typedef STR50                                   QOptionSeriesNoType;                            //期权系列代码

//板块与品种(合约)关系属性
typedef C8                                      QContAttrType;                                  //合约属性
static const QContAttrType                      Q_CONT_ATTR_NONE                    = 'N';
static const QContAttrType                      Q_CONT_ATTR_SLMULATION              = 'S';      //虚拟合约
static const QContAttrType                      Q_CONT_ATTR_UNDERLY                 = 'U';      //真实合约


typedef C8                                      QModuleTypeType;                                //模块类型
static const QModuleTypeType                    Q_MODULE_MANAGER                    = '0';      //行情管理终端
static const QModuleTypeType                    Q_MODULE_RT_QUOTER                  = '1';      //实时行情服务器
static const QModuleTypeType                    Q_MODULE_HIS_QUOTER                 = '2';      //历史行情服务器
static const QModuleTypeType                    Q_MODULE_SIGMA_SERVER               = '3';      //波动率服务器
static const QModuleTypeType                    Q_MODULE_ETP_SERVER                 = '4';      //云端交易服务
static const QModuleTypeType                    Q_MODULE_WIN_CLIENT                 = 'W';      //windows终端
static const QModuleTypeType                    Q_MODULE_IOS_CLIENT                 = 'I';      //iOS终端
static const QModuleTypeType                    Q_MODULE_ANDROID_CLIENT             = 'A';      //Android终端


//用户类型========================================================================================

typedef STR50                                   QLoginNameType;                                 //用户名
typedef STR20                                   QLoginPassType;                                 //密码
typedef I32                                     QLoginCountType;                                //最大连接数
typedef STR20                                   QRegisterTimeType;                              //注册时间,格式为YYYY-MM-DD HH-mm-ss


typedef STR50                                   QLicenseNoType;                                 //软件授权号类型
static const QLicenseNoType                     Q_DEFAULT_LICENSE_NO = "epolestar v9.3";        //极星客户端授权号

typedef STR50                                   QReservedInfoType;                              //客户预留信息类型


//实时行情定义=====================================================================================
//价格字段类型
typedef F64                                     QPriceFieldType;
//数量字段类型
typedef U64                                     QQtyFieldType;
//行情数据包日期时间类型,如20140506093015123,不同的位置代表年月日时分秒毫秒
typedef U64                                     QQuoteDateTimeType;
//行情数据包日期类型,如20140506,不同的位置代表年月日
typedef U32                                     QQuoteDateType;
//行情数据包时间类型,如093015123,不同的位置代表时分秒毫秒
typedef U32                                     QQuoteTimeType;

//行情数据包字符串
typedef C8                                      QQuoteStrType[8];
//行情字段个数
typedef U8                                      QQuoteFieldCountType;
//行情字段长度总和
typedef U16                                     QQuoteFieldLengthType;

//深度行情操作类型，高4位为买卖方向，低4位为操作标志
typedef U8                                      QDepthActionType;
static const QDepthActionType                   Q_DIRECT_BID                            = 0x00; //买方向
static const QDepthActionType                   Q_DIRECT_ASK                            = 0x10; //卖方向
static const QDepthActionType                   Q_DEPTH_ADD                             = 0x00; //增加深度价格
static const QDepthActionType                   Q_DEPTH_CHG                             = 0x01; //修改深度数量
static const QDepthActionType                   Q_DEPTH_DEL                             = 0x02; //删除深度价格
static const QDepthActionType                   Q_DEPTH_CLR                             = 0x03; //清空整个方向深度数据

//价格深度类型
typedef U8                                      QDepthLevelType;
//深度行情定单明细个数类型
typedef U8                                      QDepthOrderCountType;
//深度行情定单优先级类型
typedef U16                                     QDepthOrderLevelType;
//深度行情定单个数
typedef U32                                     QDepthOrderQtyType;

//行情各字段含义定义
typedef U8                                      QQuoteFieldMeanType;
static const QQuoteFieldMeanType                Q_FidPreClosingPrice                    = 0;   //昨收盘价
static const QQuoteFieldMeanType                Q_FidPreSettlePrice                     = 1;   //昨结算价
static const QQuoteFieldMeanType                Q_FidPrePositionQty                     = 2;   //昨持仓量
static const QQuoteFieldMeanType                Q_FidOpeningPrice                       = 3;   //开盘价
static const QQuoteFieldMeanType                Q_FidLastPrice                          = 4;   //最新价
static const QQuoteFieldMeanType                Q_FidHighPrice                          = 5;   //最高价
static const QQuoteFieldMeanType                Q_FidLowPrice                           = 6;   //最低价
static const QQuoteFieldMeanType                Q_FidHisHighPrice                       = 7;   //历史最高价
static const QQuoteFieldMeanType                Q_FidHisLowPrice                        = 8;   //历史最低价
static const QQuoteFieldMeanType                Q_FidLimitUpPrice                       = 9;   //涨停价
static const QQuoteFieldMeanType                Q_FidLimitDownPrice                     = 10;  //跌停价
static const QQuoteFieldMeanType                Q_FidTotalQty                           = 11;  //当日总成交量
static const QQuoteFieldMeanType                Q_FidPositionQty                        = 12;  //持仓量
static const QQuoteFieldMeanType                Q_FidAveragePrice                       = 13;  //均价
static const QQuoteFieldMeanType                Q_FidClosingPrice                       = 14;  //收盘价
static const QQuoteFieldMeanType                Q_FidSettlePrice                        = 15;  //结算价
static const QQuoteFieldMeanType                Q_FidLastQty                            = 16;  //最新成交量
static const QQuoteFieldMeanType                Q_FidBestBidPrice                       = 17;  //最优买价
static const QQuoteFieldMeanType                Q_FidBestBidQty                         = 18;  //最优买量
static const QQuoteFieldMeanType                Q_FidBestAskPrice                       = 19;  //最优卖价
static const QQuoteFieldMeanType                Q_FidBestAskQty                         = 20;  //最优卖量
static const QQuoteFieldMeanType                Q_FidImpliedBidPrice                    = 21;  //隐含买价
static const QQuoteFieldMeanType                Q_FidImpliedBidQty                      = 22;  //隐含买量
static const QQuoteFieldMeanType                Q_FidImpliedAskPrice                    = 23;  //隐含卖价
static const QQuoteFieldMeanType                Q_FidImpliedAskQty                      = 24;  //隐含卖量
static const QQuoteFieldMeanType                Q_FidPreDelta                           = 25;  //昨虚实度
static const QQuoteFieldMeanType                Q_FidCurrDelta                          = 26;  //今虚实度
static const QQuoteFieldMeanType                Q_FidInsideQty                          = 27;  //内盘量
static const QQuoteFieldMeanType                Q_FidOutsideQty                         = 28;  //外盘量
static const QQuoteFieldMeanType                Q_FidTotalBidQty                        = 29;  //委买总量
static const QQuoteFieldMeanType                Q_FidTotalAskQty                        = 30;  //委卖总量
static const QQuoteFieldMeanType                Q_FidTotalTurnOver                      = 31;  //总成交额
static const QQuoteFieldMeanType                Q_FidCapitalization                     = 32;  //总市值
static const QQuoteFieldMeanType                Q_FidCirculation                        = 33;  //流通市值
static const QQuoteFieldMeanType                Q_FidTheoreticalPrice                   = 34;  //理论价
static const QQuoteFieldMeanType                Q_FidRatio                              = 35;  //波动率
static const QQuoteFieldMeanType                Q_FidDelta                              = 36;  //Delta
static const QQuoteFieldMeanType                Q_FidGamma                              = 37;  //Gamma
static const QQuoteFieldMeanType                Q_FidVega                               = 38;  //Vega
static const QQuoteFieldMeanType                Q_FidTheta                              = 39;  //Theta
static const QQuoteFieldMeanType                Q_FidRho                                = 40;  //Rho

static const QQuoteFieldMeanType                Q_FidTradeState                         = 127; //合约状态


//历史行情=========================================================================================
typedef STR10                                   QTemplateNoType;                                //时间模板编号

typedef C8                                      QDateFlagType;                                  //日期标记
static const QDateFlagType                      Q_DATEFLAG_PRE                          = '0'; //前一日时间
static const QDateFlagType                      Q_DATEFLAG_CUR                          = '1'; //当日
static const QDateFlagType                      Q_DATEFLAG_NEXT                         = '2'; //下一日

typedef C8                                      QTradingStateType;                              //交易状态
static const QTradingStateType                  Q_TRADE_STATE_BID                       = '1'; //集合竞价
static const QTradingStateType                  Q_TRADE_STATE_MATCH                     = '2'; //集合竞价撮合
static const QTradingStateType                  Q_TRADE_STATE_CONTINUOUS                = '3'; //连续交易
static const QTradingStateType                  Q_TRADE_STATE_PAUSED                    = '4'; //交易暂停
static const QTradingStateType                  Q_TRADE_STATE_CLOSE                     = '5'; //闭市
static const QTradingStateType                  Q_TRADE_STATE_DEALLAST                  = '6'; //闭市处理时间
static const QTradingStateType                  Q_TRADE_STATE_SWITCHTRADE               = '0'; //交易日切换时间
static const QTradingStateType                  Q_TRADE_STATE_UNKNOWN                   = 'N'; //未知状态
static const QTradingStateType                  Q_TRADE_STATE_INITIALIZE                = 'I'; //正初始化
static const QTradingStateType                  Q_TRADE_STATE_READY                     = 'R'; //准备就绪
static const QTradingStateType                  Q_TRADE_STATE_CLOSE_RESET               = 'S'; //闭市重置数据

typedef U32                                     QKLineHopeCountType;                            //K线期望查询条数
typedef I32                                     QKLineIndexType;                                //K线索引号
typedef C8                                      QKLineDataType;                                 //K线类型
static const QKLineDataType                     Q_KLINE_TYPE_TICK                       = 'T'; //分笔明细
static const QKLineDataType                     Q_KLINE_TYPE_MINUTE                     = 'M'; //分钟
static const QKLineDataType                     Q_KLINE_TYPE_DAY                        = 'D'; //日线

//基础结构========================================================================================

//包头
typedef struct QFrameHead
{
    QFrameFlagType                              FrameFlag;                                      //数据帧头标识
    QFrameTypeType                              FrameType;                                      //数据帧类型
    QFrameSizeType                              FrameSize;                                      //数据帧长度(0-32K)
} QFrameHead;

typedef struct QSessionHead
{
    QProtocolVersionType                        ProtocolVersion;                                //协议版本号
    QSessionIdType                              SessionId;                                      //会话号，客户端填写
    QLinkIdType                                 LinkId;                                         //客户端id，服务器分配，自增
    QProtocolCodeType                           ProtocolCode;                                   //消息类型
    QLanguageType                               LangType;                                       //语言类型
    QPackageNoType                              PackageNo;                                      //包号
    QChainType                                  Chain;                                          //报文链标识
    QFieldSizeType                              FieldSize;                                      //报文长度
    QFieldCountType                             FieldCount;                                     //报文个数
    QErrorCodeType                              ErrorCode;                                      //错误码
} QSessionHead;

//心跳
static const QProtocolCodeType                  MSG_Q_Heartbeat_Req                     = 0x0000;
static const QProtocolCodeType                  MSG_Q_Heartbeat_Rsp                     = 0x0001;

//登录
static const QProtocolCodeType                  MSG_Q_Logon_Req                         = 0x0010;
static const QProtocolCodeType                  MSG_Q_Logon_Rsp                         = 0x0011;

typedef struct QLogonReq
{
    QModuleTypeType                             ModuleType;                                     //客户端要登陆的后台类型
    QLoginNameType                              LoginName;                                      //用户名
    QLoginPassType                              LoginPass;                                      //密码
    QLicenseNoType                              LicenseNo;                                      //license号
    QReservedInfoType                           ReservedInfo;                                   //预留信息
} QLogonReq;

typedef struct QLogonRsp
{
    QModuleTypeType                             ModuleType;                                     //服务端类型(实时行情/历史行情)
    QLoginNameType                              LoginName;                                      //用户名
    QReservedInfoType                           ReservedInfo;                                   //预留信息
    QQuoteDateTimeType                          InitTime;                                       //系统初始化时间
} QLogonRsp;

//管理结构========================================================================================

//币种
static const QProtocolCodeType                  MSG_Q_Currency_Req                      = 0x0100;
static const QProtocolCodeType                  MSG_Q_Currency_Rsp                      = 0x0101;
static const QProtocolCodeType                  MSG_Q_Currency_Data_Rsp                 = 0x0102;

typedef struct QCurrencyReq
{
    QCurrencyNoType                             CurrencyNo;                                     //币种号, 填空从头开始查
} QCurrencyReq;

typedef QCurrencyReq                            QCurrencyRsp;

typedef struct QCurrencyData
{
    QCurrencyNoType                             CurrencyNo;
    QExchangeRateType                           ExchangeRate;                                   //汇率，小数形式
    QInterestRateType                           InterestRate;                                   //利率，小数形式
} QCurrencyData;

//交易所
static const QProtocolCodeType                  MSG_Q_Exchange_Req                      = 0x0110;
static const QProtocolCodeType                  MSG_Q_Exchange_Rsp                      = 0x0111;
static const QProtocolCodeType                  MSG_Q_Exchange_Data_Rsp                 = 0x0112;

typedef struct QExchangeReq
{
    QExchangeNoType                             ExchangeNo;                                 //填空从头开始查，续查每次把应答包发回请求
} QExchangeReq;
typedef QExchangeReq                            QExchangeRsp;

typedef struct QExchangeData
{
    QExchangeNoType                             ExchangeNo;                                 //交易所代码
    QExchangeNameType                           ExchangeName;                               //交易所名称
} QExchangeData;

//品种
static const QProtocolCodeType                  MSG_Q_Commodity_Req                     = 0x0120;
static const QProtocolCodeType                  MSG_Q_Commodity_Rsp                     = 0x0121;
static const QProtocolCodeType                  MSG_Q_Commodity_Data_Rsp                = 0x0122;

typedef struct QCommodityReq
{
    QCommodityNoType                            CommodityNo;                                //填空从头开始查，续查每次把应答包发回请求
} QCommodityReq;
typedef QCommodityReq                           QCommodityRsp;

typedef struct QCommodityData
{
    QCommodityNoType                            CommodityNo;                                //品种编号
    QExchangeNoType                             ExchangeNo;                                 //交易所代码,必填(管理终端控制)
    QCurrencyNoType                             CurrencyNo;                                 //币种代码,必填(管理终端控制)
    QCommodityNameType                          CommodityName;                              //品种名称
    QCommodityDotType                           CommodityDot;                               //每手乘数
    QOptionTypeType                             OptionType;                                 //期权类型
    QSpreadDirectType                           SpreadDirect;                               //组合方向
    QExecuteWayType                             ExecuteWay;                                 //行权方式
    QCoverModeType                              CoverMode;                                  //平仓模式
    QCommodityTickType                          PriceTick;                                  //最小变动价
    QCommodityDenoType                          PriceDeno;                                  //报价分母
    QPriceMultipleType                          PriceMultiple;                              //执行价格倍数
    QExecuteDotType                             ExecuteDot;                                 //行权乘数
    QQuoteUnitNameType                          QuoteUnitName;                              //报价单位名称
    QTradingUnitNameType                        TradingUnitName;                            //交易单位名称
    QDepositGroupNoType                         DepositGroupNo;                             //大边保证金组组号
    QMaxSingleOrderQtyType                      MaxSingleOrderQty;                          //最大下单量
    QMaxPositionQtyType                         MaxPositionQty;                             //最大持仓量
    QCommodityNoType                            RelateCommodity1;                           //依赖品种1
    QCommodityNoType                            RelateCommodity2;                           //依赖品种2
} QCommodityData;

//合约
static const QProtocolCodeType                  MSG_Q_Contract_Req                      = 0x0130;
static const QProtocolCodeType                  MSG_Q_Contract_Rsp                      = 0x0131;
static const QProtocolCodeType                  MSG_Q_Contract_Data_Rsp                 = 0x0132;

typedef struct QContractReq
{
    QContractNoType                             ContractNo;    //合约编号 流控
} QContractReq;
typedef QContractReq                            QContractRsp;

typedef struct QContractData
{
    QContType                                   Cont;          //变长合约编号
} QContractData;

//合约名称
static const QProtocolCodeType                  MSG_Q_ContName_Req                      = 0x0133;
static const QProtocolCodeType                  MSG_Q_ContName_Rsp                      = 0x0134;
static const QProtocolCodeType                  MSG_Q_ContName_Data_Rsp                 = 0x0135;

typedef struct QContractNameReq
{
    QContractNoType                             ContractNo;    //合约编号 流控
} QContractNameReq;

typedef QContractNameReq                        QContractNameRsp;

typedef struct QContNameData1
{
    QContType                                   Cont;
} QContNameData1;
typedef struct QContNameData2
{
    QContNameType                               ContName;
} QContNameData2;

//期权序列到期日
static const QProtocolCodeType                  MSG_Q_OptionExpiration_Req            = 0x0140;
static const QProtocolCodeType                  MSG_Q_OptionExpiration_Rsp            = 0x0141;
static const QProtocolCodeType                  MSG_Q_OptionExpiration_Data_Rsp       = 0x0142;

typedef struct QOptionExpireReq
{
    QOptionSeriesNoType                         SeriesNo;             //期权系列编号
} QOptionExpireReq;
typedef QOptionExpireReq                        QOptionExpireRsp;

typedef struct QOptionExpireData
{
    QOptionSeriesNoType                         SeriesNo;             //期权系列编号
    QQuoteDateType                              ExpireDate;           //合约到期日
} QOptionExpireData;

//虚拟合约与真实合约关系
static const QProtocolCodeType                  MSG_Q_ContUnderly_Req               = 0x0150;
static const QProtocolCodeType                  MSG_Q_ContUnderly_Rsp               = 0x0151;
static const QProtocolCodeType                  MSG_Q_ContUnderly_Data_Rsp          = 0x0152;
static const QProtocolCodeType                  MSG_Q_ContUnderly_Notice            = 0x0153;

typedef struct QContUnderlyReq
{
    QContractNoType                             ContractNo;             //流控
} QContUnderlyReq;
typedef QContUnderlyReq                         QContUnderlyRsp;

typedef struct QContUnderlyData1
{
    QContType                                   SimuCont;      //虚拟合约代码
} QContUnderlyData1;

typedef struct QContUnderlyData2
{
    QContType                                   UnderlyCont;  //真实合约代码
} QContUnderlyData2;


//即时行情结构========================================================================================

//行情订阅请求,普通行情和深度行情都推送
static const QProtocolCodeType                  MSG_Q_SnapShot_Sub                  = 0x0A00;
static const QProtocolCodeType                  MSG_Q_SnapShot_UnSub                = 0x0A01;
static const QProtocolCodeType                  MSG_Q_SnapShot_LV1_Rsp              = 0x0A02;
static const QProtocolCodeType                  MSG_Q_SnapShot_LV1_Notice           = 0x0A03;
static const QProtocolCodeType                  MSG_Q_SnapShot_LV2_Rsp              = 0x0A04;
static const QProtocolCodeType                  MSG_Q_SnapShot_LV2_Notice           = 0x0A05;

typedef struct QSnapShotReq
{
    QContractNoType                             ContractNo;   //合约编号
} QSnapShotReq;

typedef struct QSnapShotCont
{
    QContType                                   Cont;
} QSnapShotCont;

typedef struct QSnapShotField
{
    QQuoteFieldMeanType                         FidMean;       //本数据域含义
    union
    {
        QPriceFieldType                         Price;           //价格字段取本值
        QQtyFieldType                           Qty;             //数量字段取本值
        QQuoteDateTimeType                      DateTime;        //日期时间字段取本值
        QQuoteDateType                          Date;            //日期字段取本值
        QQuoteTimeType                          Time;            //时间字段取本值
        QQuoteStrType                           Str;             //字符串字段取本值
        C8                                      Char;            //字符类型取本值
    };
} QSnapShotField;

//LV1
typedef struct QSnapShotLV1
{
    QQuoteDateTimeType                          UpdateTime;      //行情更新时间
    QQuoteFieldCountType                        FieldCount;      //QSnapShotField的数量
    QSnapShotField                              FieldData[1];    //数据字段的起始位置，无数据时此结构不包含此字段长度
} QSnapShotLV1;

//LV2
typedef struct QSnapShotLV2
{
    QQuoteDateTimeType                          UpdateTime;       //行情更新时间
    QQuoteFieldLengthType                       DepthLength;      //QDepDetail的总长
    QQuoteFieldCountType                        DepthCount;       //QDepDetail的数量
} QSnapShotLV2;

typedef struct QDepthNewLV2
{
    QDepthActionType                            Action;           //操作，高4位标示买卖，低4位表示增加和修改
    QDepthLevelType                             Level;            //价格深度
    QQtyFieldType                               Qty;              //深度数量
    QPriceFieldType                             Price;            //深度价格
} QDepthNewLV2;

typedef struct QDepthDelLV2
{
    QDepthActionType                            Action;           //操作，高4位标示买卖，低4位表示增加和修改
    QDepthLevelType                             Level;            //价格深度
} QDepthDelLV2;

typedef struct QDepthOrderLV2
{
    QDepthActionType                            Action;           //操作，增加、修改、删除
    QDepthOrderLevelType                        Level;            //订单优先级(成交顺序)
    QDepthOrderQtyType                          OrderQty;         //本订单的数量
} QDepthOrderLV2;

//品种清盘
typedef struct QSnapShotClear
{
    QCommodityNoType                            CommodityNo;
} QSnapShotClear;

//历史行情结构========================================================================================

//时间模板
static const QProtocolCodeType                  MSG_Q_TimeBucket_Req                = 0x0B00;
static const QProtocolCodeType                  MSG_Q_TimeBucket_Rsp                = 0x0B01;
static const QProtocolCodeType                  MSG_Q_TimeBucket_Data_Rsp           = 0x0B02;

typedef struct QTimeBucketReq
{
    QTemplateNoType                             TemplateNo;      //时间模板编号
} QTimeBucketReq;
typedef QTimeBucketReq                          QTimeBucketRsp;

typedef struct QTimeBucketDataRsp
{
    QTemplateNoType                             TemplateNo;     //时间模板编号
    QQuoteTimeType                              BeginTime;      //开始时间
    QTradingStateType                           TradingState;   //交易状态
    QDateFlagType                               DateFlag;       //日期标记
} QTimeBucketDataRsp;

//品种模板
static const QProtocolCodeType                  MSG_Q_CommTimeBucket_Req            = 0x0B06;
static const QProtocolCodeType                  MSG_Q_CommTimeBucket_Rsp            = 0x0B07;
static const QProtocolCodeType                  MSG_Q_CommTimeBucket_Data_Rsp       = 0x0B08;

typedef struct QCommTimeBucketReq
{
    QCommodityNoType                            CommodityNo;            //品种编号
} QCommTimeBucketReq;
typedef QCommTimeBucketReq                      QCommTimeBucketRsp;

typedef struct QCommTimeBucketDataRsp
{
    QCommodityNoType                            CommodityNo;            //品种编号
    QTemplateNoType                             TemplateNo;             //时间模板编号
} QCommTimeBucketDataRsp;

//K线
static const QProtocolCodeType                  MSG_Q_KLine_Req                     = 0x0B10;
static const QProtocolCodeType                  MSG_Q_KLine_Rsp                     = 0x0B11;
static const QProtocolCodeType                  MSG_Q_KLine_Data_Rsp                = 0x0B12;

typedef struct QKLineReq
{
    QKLineHopeCountType                         HopeCount;                  //期望数量（扩展使用）
    QContractNoType                             ContractNo;                 //合约ID
    QKLineDataType                              KLineType;                  //K线类型
    QQuoteDateTimeType                          BeginTime;                  //从尾部开始，表示的是截止时间，无begintime最大500
    QQuoteDateTimeType                          EndTime;                    //结束时间 0就是从末尾查，数据结果中不含与begintime和endtime相等的数据
} QKLineReq;

typedef QKLineReq                               QKLineRsp;

typedef struct QKLineHead
{
    QContractNoType                             ContractNo;                 //合约ID
    QKLineDataType                              KLineType;                  //K线类型
} QKLineHead;

typedef struct QKLineData   //sizeof 88字节
{
    QKLineIndexType                             KLineIndex;                 //K线索引  tick每笔连续序号，min交易分钟序号，day无效
    QQuoteDateType                              TradeDate;                  //交易日   tick无效，min可能和时间戳不同，day和时间戳相同
    QQuoteDateTimeType                          DateTimeStamp;              //时间戳，不同数据类型，精度不同
    QQtyFieldType                               QTotalQty;                  //行情快照 总成交量
    QQtyFieldType                               QPositionQty;               //行情快照 持仓量
    QPriceFieldType                             QLastPrice;                 //最新价（收盘价）
    
    union
    {
        struct
        {
            QQtyFieldType                       QKLineQty;                  //K线成交量 day  min
            QPriceFieldType                     QOpeningPrice;              //开盘价  day  min
            QPriceFieldType                     QHighPrice;                 //最高价  day  min
            QPriceFieldType                     QLowPrice;                  //最低价  day  min
            QPriceFieldType                     QSettlePrice;               //结算价  day  min
            
        };
        struct
        {
            QVolChgFieldType                    QLastQty;                   //明细现手  tick
            QPosChgFieldType                    QPositionChg;               //持仓量变化 tick
            QPriceFieldType                     QBuyPrice;                  //买价 tick
            QPriceFieldType                     QSellPrice;                 //卖价 tick
            QQtyFieldType                       QBuyQty;                    //买量 tick
            QQtyFieldType                       QSellQty;                   //卖量 tick
        };
    };
} QKLineData;


//历史波动率
static const QProtocolCodeType                  MSG_Q_HisSigma_Req                  = 0x0B20;
static const QProtocolCodeType                  MSG_Q_HisSigma_Rsp                  = 0x0B21;
static const QProtocolCodeType                  MSG_Q_HisSigma_Data_Rsp             = 0x0B22;

typedef struct QHisSigmaReq
{
    QKLineHopeCountType                         HopeCount;                  //期望数量（扩展使用）
    QContractNoType                             ContractNo;                 //合约ID
    QKLineDataType                              KLineType;                  //K线类型
    QQuoteDateTimeType                          BeginTime;                  //从尾部开始，表示的是截止时间，无begintime最大500
    QQuoteDateTimeType                          EndTime;                    //结束时间 0就是从末尾查，数据结果中不含与begintime和endtime相等的数据
} QHisSigmaReq;

typedef QHisSigmaReq                            QHisSigmaRsp;

typedef QKLineHead                              QHisSigmaHead;

typedef struct QHisSigmaData
{
    QKLineIndexType                             KLineIndex;
    QQuoteDateType                              TradeDate;                  //交易日   tick无效，min可能和时间戳不同，day和时间戳相同
    QQuoteDateTimeType                          DateTimeStamp;              //时间戳，不同数据类型，精度不同
    
    QPriceFieldType                             TheoryPrice;                //理论价
    QPriceFieldType                             Sigma;                      //波动率
    QPriceFieldType                             Delta;
    QPriceFieldType                             Gamma;
    QPriceFieldType                             Vega;
    QPriceFieldType                             Theta;
    QPriceFieldType                             Rho;
    
} QHisSigmaData;



#pragma pack(pop)

#endif /* QProtocol_h */
