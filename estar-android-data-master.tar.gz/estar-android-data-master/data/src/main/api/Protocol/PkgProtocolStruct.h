#pragma once

#pragma pack(push, 1)
#include "PkgProtocolType.h"

static const CspProtocolCodeType			CMD_PKG_QuoteAddr_Req = 0x1000;

static const CspProtocolCodeType			CMD_PKG_QuoteAddr_Rsp = 0x1001;

typedef struct PkgQuoteAddrReq
{
    
    PkgTerminalOSType       TerminalOSType;
    PkgLangType             LangType;
    PkgPackageNoType        PackageNo;
    PkgLicenseNoType        LicenseNo;  
    PkgProtocolVerType      ProtocolVer;

} PkgQuoteAddrReq;

struct PkgQuoteAddrRsp
{
    PkgCompanyNoType            CompanyNo;
    PkgNameType                 CompanyName;
    PkgAddrNoType               QuoteAddrNo;
    PkgNameType                 QuoteAddrName;
    
    PkgQuoteTypeType            QuoteType;
    PkgIPType                   IP;
    PkgPortType                 Port;
};

static const CspProtocolCodeType            CMD_PKG_QuoteAddrGroup_Req = 0x1002;

static const CspProtocolCodeType            CMD_PKG_QuoteAddrGroup_Rsp = 0x1003;

typedef struct PkgQuoteAddrGroupReq
{
    
    PkgTerminalOSType       TerminalOSType;
    PkgLangType             LangType;
    PkgPackageNoType        PackageNo;
    PkgLicenseNoType        LicenseNo;
    PkgProtocolVerType      ProtocolVer;

}PkgQuoteAddrGroupReq;


struct PkgQuoteAddrGroupRsp
{
    PkgGroupNoType              QuoteGroupNo;
    PkgCompanyNoType            CompanyNo;
    PkgAddrNoType               QuoteAddrNo;
    
};



static const CspProtocolCodeType			CMD_PKG_DirectTrade_Req = 0x1010;

static const CspProtocolCodeType			CMD_PKG_DirectTrade_Rsp = 0x1011;

typedef PkgQuoteAddrReq  PkgDirectTradeAddrReq;


struct PkgDirectTradeAddrRsp
{
    PkgCompanyNoType                 CompanyNo;
    PkgNameType                      CompanyName;
    PkgAddrNoType                    TradeAddrNo;
    PkgNameType                      TradeAddrName;

    PkgTradeApiType                   TradeApi;
    PkgIPType                         IP;
    PkgPortType                       Port;

    PkgTradeServerType                ServerType;         
    PkgBrokerIdType                   BrokerId;           //默认为空，API为CTP时有效
    PkgCertStrType                    CertStr;            //CTP API有效
    PkgUserType                       UserType;
    PkgTradeAddrType                  AddrType;
    
    PkgOrderType                      ShowOrder;
    
    PkgGroupNoType                    TradeGroupNo;                 
    PkgGroupNameType                  TradeGroupName;
    PkgOrderType                      GroupOrder;
    
    PkgPortType                       PortEx;
    PkgLinkType                       LinkType;
};




static const CspProtocolCodeType       CMD_PKG_CompanyAddr_Req = 0x1020;

static const CspProtocolCodeType       CMD_PKG_CompanyAddr_Rsp = 0x1021;


 typedef PkgQuoteAddrReq  PkgCompanyAddrReq;
 
 struct   PkgCompanyAddrRsp
{
    PkgCompanyNoType                  CompanyNo;
    PkgNameType                       CompanyName;
    PkgAddrNoType                     TradeAddrNo;
    PkgNameType                       TradeAddrName;
    
    PkgTradeApiType                   TradeApi;
    
    PkgTradeAddrType                  AddrType;
};

static const CspProtocolCodeType       CMD_PKG_CloudAddr_Req = 0x1030;

static const CspProtocolCodeType       CMD_PKG_CloudAddr_Rsp = 0x1031;

 typedef  PkgQuoteAddrReq  PkgCloudAddrReq;
 
 struct PkgCloudAddrRsp
{
    PkgAddrNoType                   TradeAddrNo;
    PkgNameType                     TradeAddrName;
    
    PkgIPType                       IP;
    PkgPortType                     Port;
    
};
 

static const CspProtocolCodeType       CMD_PKG_CompanyCloudMap_Req = 0x1040;

static const CspProtocolCodeType       CMD_PKG_CompanyCloudMap_Rsp = 0x1041;


 typedef  PkgQuoteAddrReq  PkgCompanyCloudMapReq;
 
 struct PkgCompanyCloudMapRsp
{
     PkgCompanyNoType           CompanyNo;
     PkgAddrNoType              CloudTradeAddrNo;   
     PkgAddrNoType              TradeAddrNo;
};




static const CspProtocolCodeType       CMD_PKG_PackageInfo_Req = 0x1050;

static const CspProtocolCodeType       CMD_PKG_PackageInfo_Rsp = 0x1051;

typedef PkgQuoteAddrReq  PkgPackageReq;

struct PkgPackageRsp
{
    PkgPackageNoType                    PackageNo;
    PkgNameType                         PackageName;
    PkgUrlType                          PackageUrl;   
};


static const CspProtocolCodeType       CMD_PKG_CodeForbid_Req = 0x1060;

static const CspProtocolCodeType       CMD_PKG_CodeForbid_Rsp = 0x1061;

typedef PkgQuoteAddrReq  PkgCodeForbidReq;

struct PkgCodeForbidRsp
{
    PkgCodeType                   ForbidCode;                   
};

static const CspProtocolCodeType       CMD_PKG_CodeMapping_Req = 0x1070;

static const CspProtocolCodeType       CMD_PKG_CodeMapping_Rsp = 0x1071;

typedef PkgQuoteAddrReq    PkgCodeMappingReq;


struct PkgCodeMappingRsp
{
    PkgCodeType                   SrcCode;       
    PkgCodeType                   ShowCode;
    PkgPriceType                  PriceMultiple;
};

static const CspProtocolCodeType       CMD_PKG_PlateInfo_Req = 0x1080;

static const CspProtocolCodeType       CMD_PKG_PlateInfo_Rsp = 0x1081;

static const CspProtocolCodeType       CMD_PKG_PlateCode_Rsp = 0x1082;

typedef PkgQuoteAddrReq    PkgPlateReq;

struct PkgPlateRsp
{
    PkgPlateNoType                   PlateNo;
    PkgNameType                      PlateName;
    PkgPlateNoType                   ParentPlateNo;
      
};

struct PkgPlateCodeRsp
{
     PkgPlateNoType              PlateNo;
     PkgCodeType                 PlateCode;
     PkgPlateCodeAttrType        PlateCodeAttr;
};


static const CspProtocolCodeType       CMD_PKG_BlackList_Req = 0x1090;

static const CspProtocolCodeType       CMD_PKG_BlackList_Rsp = 0x1091;

typedef PkgQuoteAddrReq    PkgBlackListReq;

struct PkgBlackListRsp
{
    PkgPluginNoType                   PlugInNo;
};


static const CspProtocolCodeType       CMD_PKG_ConfigSwitch_Req = 0x10a0;

static const CspProtocolCodeType       CMD_PKG_ConfigSwitch_Rsp = 0x10a1;

typedef PkgQuoteAddrReq    PkgConfigSwitchReq;

struct PkgConfigSwitchRsp
{
    PkgConfigSwitchNoType              ConfigSwitchNo;
    PkgValueType                       ConfigSwitchValue;
};

static const CspProtocolCodeType       CMD_PKG_Plugin_Req = 0x10b0;

static const CspProtocolCodeType       CMD_PKG_Plugin_Rsp = 0x10b1;

typedef PkgQuoteAddrReq      PkgPlugInReq;

struct PkgPluginRsp
{
    PkgPluginNoType                   PlugInNo;
    PkgDeveloperNoType                DeveloperNo;
    PkgValueType                      Verification;
    PkgValueType                      VerfyIndex;
};


static const CspProtocolCodeType       CMD_PKG_OptionPrecisionConfig_Req = 0x10c0;

static const CspProtocolCodeType       CMD_PKG_OptionPrecisionConfig_Rsp = 0x10c1;

typedef PkgQuoteAddrReq      PkgOptionPrecisionConfigReq;

struct PkgOptionPrecisionConfigRsp
{
    PkgCommodityType               CommodityNo;
    PkgPriceType                   PriceMultiple;
    PkgOptionWidthType             IntegerWidth;
    PkgOptionWidthType             TotalWidth;
};

static const CspProtocolCodeType       CMD_PKG_PhoneStartInfo_Req = 0x10d0;

static const CspProtocolCodeType       CMD_PKG_PhoneStartInfo_Rsp = 0x10d1;

typedef struct PkgPhoneStartReq
{
    
    PkgTerminalOSType       TerminalOSType;
    PkgLangType             LangType;
    PkgPackageNoType        PackageNo;
    PkgIntType              ScreenWidth;
    PkgIntType              ScreenHeight;
}PkgPhoneStartReq;

struct PkgPhoneStartRsp
{
    //判定是否更新
    PkgVersionType          CurVersion;             //当前版本
    PkgUpdateInfoType       UpdateInfo;             //更新内容
    PkgTimeType             UpdateTime;             //更新时间
    
    
    //启动加载图片
    PkgImgUrlType           ImgUrl;                 //启动图片加载网址
    PkgDateType             ImgStartDate;           //加载起始日期
    PkgDateType             ImgEndDate;             //加载结束日期
    PkgTimeType             ImgUpdateTime;
    
    PkgVersionType          BasicVersion;          //必须升级版本
    PkgImgUrlType           FeedbackUrl;            //反馈Url
    PkgImgUrlType           CompanyUrl;            //公司Url

    PkgMsgNotifyId          MsgNotifyID;            // 通知id
    PkgMsgNotifyType        MsgNotifyType;          // 通知类型
    PkgDateType             MsgNotifyStartDate;     // 通知的起始时间
    PkgDateType             MsgNotifyEndDate;       // 通知到结束时间
    
    PkgMsgNotifyData        MsgNotifyData;          // 通知
};

static const CspProtocolCodeType       CMD_PKG_CompanyOpenAccountInfo_Req = 0x10e0;

static const CspProtocolCodeType       CMD_PKG_CompanyOpenAccountInfo_Rsp = 0x10e1;

struct PkgCompanyOpenAccountReq
{
    PkgTerminalOSType       TerminalOSType;
    PkgLangType             LangType;
    PkgPackageNoType        PackageNo;
    PkgLicenseNoType        LicenseNo;
    PkgProtocolVerType      ProtocolVer;
    PkgOpenCompanyType      OpenCompanyType;
};

struct PkgCompanyOpenAccountRsp
{
    PkgOpenCodeType         OpenCode;
    PkgNameType             CompanyName;
    PkgOpenUrlType          OpenUrl;
};


#pragma pack(pop)