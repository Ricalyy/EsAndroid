/**
* =====================================================================
*
*       [filename    ] PushProtocol
*       [author      ] Hao Lin
*       [Description ]
*       [Timestamp   ] 2018-05-11
*
* ===========Copyright (C) 2002-2017 Esunny. All rights reserved.===========
*/

#ifndef PUSHPROTOCOL_H
#define PUSHPROTOCOL_H

#pragma pack(push, 1)


typedef C8                          PushDeviceType;                  //设备类型
static const PushDeviceType         PUSH_DEVICE_ANDROID  = 'A';      //android
static const PushDeviceType         PUSH_DEVICE_IOS      = 'I';      //IOS

//客户端信息:1.APP初始化时需要把信息发送给推送方(交易、新闻等);2.推送消息时,需要将信息一起发送过来
//AppId、AppKey、AppMasterSecret为在个推上配置的应用信息

typedef struct PushClient
{
    STR50                           CID;                             //设备client id
    PushDeviceType                  DeviceType;                      //设备类型 Android IOS

}PushClient;

typedef struct PushClientList
{
    U8                              Count;                           //目标数量
    PushClient                      Client[1];
}PushClientList;

typedef STR20                       PushUserNameType;                //用户名
typedef STR100                      PushTitleType;                   //标题
typedef C8                          PushContent[512];                //内容


//消息通知协议
static const CspProtocolCodeType    CMD_PUSH_Notice     = 0x1001;
static const CspProtocolCodeType    CMD_PUSH_App_Notice = 0x1002;

typedef struct PushNoticeData
{
    PushUserNameType                UserName;                         //用户名
    PushTitleType                   Title;                            //标题
    PushContent                     Content;                          //内容

    STR30                           AppId;                            //App Id
    STR30                           AppKey;                           //App Key
    STR30                           AppMasterSecret;                  //App Master Secret

    PushClientList                  ClientList;                       //推送消息接收列表
}PushNoticeData;

//APP发送CID和设备类型
static const CspProtocolCodeType    CMD_PUSH_Client_Info_Notice = 0x1003;

typedef struct PushClientInfoNotice
{
    STR30                           AppId;                            //App Id
    STR30                           AppKey;                           //App Key
    STR30                           AppMasterSecret;                  //App Master Secret

    PushClient                      Client;                           //client信息
}PushClientInfoNotice;

#pragma pack(pop)

#endif // PUSHPROTOCOL_H
