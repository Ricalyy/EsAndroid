/*********************************************************************************/
/* Copyright (c) 2016-2017 Zhengzhou Esunny Information & Technology Co,.Ltd     */
/* 本软件文档资料是易盛公司的资产,任何人士阅读和使用本资料必须获得相应的书面授权 */
/* 承担保密责任和接受相应的法律约束.                                             */
/*********************************************************************************/

/***********************************************************
  Copyright (c) 2016-2017 Zhengzhou Esunny Information & Technology Co,.Ltd
  File name: QuoteProtocol.h
  Author: Fanliangde     Version:1.0          Date:2018/01/23
  Description: 极星行情服务接口协议
  Others:
  Function List:
    1. ...
    2. ...
  History:
***********************************************************/

#ifndef _QTE_PROTOCOL_H_
#define _QTE_PROTOCOL_H_


#pragma pack(push, 1)

/////////////////////////////////////用户错误码定义////////////////////////////////
static const CspErrorCodeType        QTE_SUCCEED                   = 0;        //成功
static const CspErrorCodeType        QTE_USERNAME_ERROR            = 1001;     //登录用户名错误
static const CspErrorCodeType        QTE_PASSWD_ERROR              = 1002;     //登录密码错误
static const CspErrorCodeType        QTE_LOGIN_EXCEED_ERROR        = 1003;     //登录数量超出限制
static const CspErrorCodeType        QTE_LOGIN_PROCESS_ERROR       = 1004;     //登录过程错误
static const CspErrorCodeType        QTE_DISCONNECT_TO_ACP_ERROR   = 1005;     //与接入点断开连接
static const CspErrorCodeType        QTE_DISCONNECT_TO_REG_ERROR   = 1006;     //与用户注册认证断开连接
static const CspErrorCodeType        QTE_DISCONNECT_TO_MGR_ERROR   = 1007;     //与管理平台断开连接
static const CspErrorCodeType        QTE_RSA_ENCRYPT_ERROR         = 1008;     //RSA加密错误
static const CspErrorCodeType        QTE_COMMODITY_ID_ERROR        = 1009;     //品种代码错误
static const CspErrorCodeType        QTE_CONTRACT_ID_ERROR         = 1010;     //合约代码错误
static const CspErrorCodeType        QTE_KLINE_TYPE_ERROR          = 1011;     //K线类型错误


/////////////////////////////////////心跳//////////////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_HeartbeatReq          = CMD_CSP_HeartbeatReq;
static const CspProtocolCodeType     CMD_QTE_HeartbeatRsp          = CMD_CSP_HeartbeatRsp;

/////////////////////////////////////链路认证//////////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_AuthReq               = CMD_CSP_AuthReq;
static const CspProtocolCodeType     CMD_QTE_AuthRsp               = CMD_CSP_AuthRsp;

/////////////////////////////////////登录//////////////////////////////////////////

static const CspProtocolCodeType     CMD_QTE_LogonReq              = 0x0004;
static const CspProtocolCodeType     CMD_QTE_LogonRsp              = 0x0005;
static const CspProtocolCodeType     CMD_QTE_UserLogonRsp          = 0x0006;  //服务器内部使用

static const CspProtocolCodeType     CMD_QTE_NewLogonReq              = 0x0008;
static const CspProtocolCodeType     CMD_QTE_NewLogonRsp              = 0x0009;

//登录请求消息
typedef struct QteLogonReq
{
    QteModuleTypeType                ModuleType;       //客户端类型
    QteUserNameType                  UserName;         //用户名
    QteUserPasswordType              Password;         //密码
    QteLicenseNoType                 LicenseNo;        //license号
} QteLogonReq;

//登录应答消息
typedef struct QteLogonRsp
{
    QteModuleTypeType                ModuleType;       //服务端类型(
    QteUserNameType                  UserName;         //用户名
    QteLoginCountType                MaxLoginCount;    //用户最大登录数
    QteLoginCountType                LoginCount;       //用户当前登录数
} QteLogonRsp;

/////////////////////////////////////币种信息查询/////////////////////////////
static const CspProtocolCodeType     CMD_QTE_CurrencyReq           = 0x0100;
static const CspProtocolCodeType     CMD_QTE_CurrencyRsp           = 0x0101;
static const CspProtocolCodeType     CMD_QTE_CurrencyDataRsp       = 0x0102;

//币种查询请求
typedef struct QteCurrencyReq
{
    QteCurrencyNoType                CurrencyNo;       //币种号, 填空从头开始查
} QteCurrencyReq;

//币种查询应答
typedef QteCurrencyReq               QteCurrencyRsp;

//币种查询数据
typedef struct QteCurrencyData
{
    QteCurrencyNoType                CurrencyNo;
    QteExchangeRateType              ExchangeRate;     //汇率，小数形式
    QteInterestRateType              InterestRate;     //利率，小数形式
} QteCurrencyData;

/////////////////////////////////////交易所信息查询///////////////////////////
static const CspProtocolCodeType     CMD_QTE_ExchangeReq           = 0x0110;
static const CspProtocolCodeType     CMD_QTE_ExchangeRsp           = 0x0111;
static const CspProtocolCodeType     CMD_QTE_ExchangeDataRsp       = 0x0112;

//交易所信息查询请求
typedef struct QteExchangeReq
{
    QteExchangeNoType                ExchangeNo;      //填空从头开始查，续查每次把应答包发回请求
} QteExchangeReq;

//交易所信息查询应答
typedef QteExchangeReq               QteExchangeRsp;

//交易所信息查询数据
typedef struct QteExchangeData
{
    QteExchangeNoType                ExchangeNo;      //交易所代码
    QteExchangeNameType              ExchangeName;    //交易所名称
} QteExchangeData;


//////////////////////////////////////品种信息查询//////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_CommodityReq           = 0x0120;
static const CspProtocolCodeType     CMD_QTE_CommodityRsp           = 0x0121;
static const CspProtocolCodeType     CMD_QTE_CommodityDataRsp       = 0x0122;

//品种信息查询请求消息
typedef struct QteCommodityReq
{
    QteCommodityIdType               CommodityId;          //填空从头开始查，续查每次把应答包发回请求
} QteCommodityReq;

typedef QteCommodityReq              QteCommodityRsp;

//品种信息数据
typedef struct QteCommodityData
{
    QteCommodityIdType               CommodityId;          //品种编号
    QteExchangeNoType                ExchangeNo;           //交易所代码,必填(管理终端控制)
    QteCurrencyNoType                CurrencyNo;           //币种代码,必填(管理终端控制)
    QteCommodityNameType             CommodityName;        //品种名称
    QteCommodityDotType              CommodityDot;         //每手乘数
    QteOptionTypeType                OptionType;           //期权类型
    QteSpreadDirectType              SpreadDirect;         //组合方向
    QteExecuteWayType                ExecuteWay;           //行权方式
    QteCoverModeType                 CoverMode;            //平仓模式
    QteCommodityTickType             PriceTick;            //最小变动价
    QteCommodityDenoType             PriceDeno;            //报价分母
    QtePriceMultipleType             PriceMultiple;        //执行价格倍数
    QteExecuteDotType                ExecuteDot;           //行权乘数
    QteQuoteUnitNameType             QuoteUnitName;        //报价单位名称
    QteTradingUnitNameType           TradingUnitName;      //交易单位名称
    QteDepositGroupNoType            DepositGroupNo;       //大边保证金组组号
    QteMaxSingleOrderQtyType         MaxSingleOrderQty;    //最大下单量
    QteMaxPositionQtyType            MaxPositionQty;       //最大持仓量
    QteCommodityIdType               RelateCommodityId1;   //依赖品种1
    QteCommodityIdType               RelateCommodityId2;   //依赖品种2
    QteCommodityIdType               RelateCommodityId3;   //依赖品种1
    QteCommodityIdType               RelateCommodityId4;   //依赖品种2
    QteOperatorType                  Operator1;            //运算符1
    QteOperatorType                  Operator2;            //运算符2
    QteOperatorType                  Operator3;            //运算符3
    QtePricePropType                 PriceProp1;           //价格配比1
    QtePricePropType                 PriceProp2;           //价格配比2
    QtePricePropType                 PriceProp3;           //价格配比3
    QtePricePropType                 PriceProp4;           //价格配比4
    QteQtyPropType                   QtyProp1;             //数量配比1
    QteQtyPropType                   QtyProp2;             //数量配比2
    QteQtyPropType                   QtyProp3;             //数量配比3
    QteQtyPropType                   QtyProp4;             //数量配比4
} QteCommodityData;

/////////////////////////////////////收费品种查询///////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_ChargeCommodityReq     = 0x0123;
static const CspProtocolCodeType     CMD_QTE_ChargeCommodityRsp     = 0x0124;
static const CspProtocolCodeType     CMD_QTE_ChargeCommodityDataRsp = 0x0125;

typedef QteCommodityReq              QteChargeCommodityReq;
typedef QteCommodityReq              QteChargeCommodityRsp;
typedef struct QteChargeCommodityDataRsp
{
    QteCommodityIdType               CommodityId;
    QteCommGroupNoType               GroupNo;               //品种组组号
} QteChargeCommodityDataRsp;


/////////////////////////////////////合约信息查询////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_ContractReq            = 0x0130;
static const CspProtocolCodeType     CMD_QTE_ContractRsp            = 0x0131;
static const CspProtocolCodeType     CMD_QTE_ContractDataRsp        = 0x0132;

//合约信息查询请求
typedef struct QteContractReq
{
    QteContractIdType                ContractId;           //合约编号
} QteContractReq;

//合约信息查询应答
typedef QteContractReq               QteContractRsp;

//合约信息查询数据
typedef struct QteContractData
{
    QteContType                      Cont;                //变长合约编号
} QteContractData;

//////////////////////////////////////合约名称查询//////////////////////////////
static const CspProtocolCodeType     CMD_QTE_ContNameReq            = 0x0133;
static const CspProtocolCodeType     CMD_QTE_ContNameRsp            = 0x0134;
static const CspProtocolCodeType     CMD_QTE_ContNameDataRsp        = 0x0135;

//合约名称查询请求
typedef struct QteContractNameReq
{
    QteContractIdType                ContractId;          //合约编号
} QteContractNameReq;

typedef QteContractNameReq           QteContractNameRsp;

//合约名称由两部分部分组成：{合约编号}{合约名称}
typedef struct QteContNameDataPart1
{
    QteContType                      Cont;               //变长合约编号
} QteContNameDataPart1;

typedef struct QteContNameDataPart2
{
    QteContNameType                  ContName;           //变长合约名称
} QteContNameDataPart2;


/////////////////////////////////////期权序列到期日查询////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_OptionExpireReq       = 0x0140;
static const CspProtocolCodeType     CMD_QTE_OptionExpireRsp       = 0x0141;
static const CspProtocolCodeType     CMD_QTE_OptionExpireDataRsp   = 0x0142;

//期权序列到期日查询请求
typedef struct QteOptionExpireReq
{
     QteOptionSerialIdType           OptionSerialId;    //期权序列编号
} QteOptionExpireReq;

//期权序列到期日查询应答
typedef QteOptionExpireReq           QteOptionExpireRsp;

//期权序列到期日数据应答
typedef struct QteOptionExpireData
{
    QteOptionSerialIdType            OptionSerialId;    //期权序列编号
    QteQuoteDateType                 ExpireDate;        //期权序列到期日
    QteContractIdType                UnderlyContId;     //对应标的合约
} QteOptionExpireData;


/////////////////////////////////////虚拟合约与真实合约关系查询/////////////////
static const CspProtocolCodeType     CMD_QTE_ContUnderlyReq        = 0x0150;
static const CspProtocolCodeType     CMD_QTE_ContUnderlyRsp        = 0x0151;
static const CspProtocolCodeType     CMD_QTE_ContUnderlyDataRsp    = 0x0152;
static const CspProtocolCodeType     CMD_QTE_ContUnderlyNotice     = 0x0153;

//虚拟合约查询请求
typedef struct QteContUnderlyReq
{
    QteContractIdType                ContractId;       //填空从头开始查，续查每次把应答包发回请求
} QteContUnderlyReq;

//虚拟合约查询应答
typedef QteContUnderlyReq            QteContUnderlyRsp;


//数据体由两部分组成{虚拟合约代码}{真实合约代码}
typedef struct QteContUnderlyDataPart1
{
    QteContType                      SimuCont;        //虚拟合约代码
} QteContUnderlyDataPart1;

typedef struct QteContUnderlyDataPart2
{
    QteContType                      UnderlyCont;     //真实合约代码
} QteContUnderlyDataPart2;

/////////////////////////////////////抵押品汇率/////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_MortgageReq           = 0x0160;
static const CspProtocolCodeType     CMD_QTE_MortgageRsp           = 0x0161;
static const CspProtocolCodeType     CMD_QTE_MortgageDataRsp       = 0x0162;

typedef struct QteMortgageReq
{
    QteMortgageNoType                MortgageNo;     //抵押品编号
    QteCurrencyNoType                CurrencyNo;     //折抵货币编号，MortgageNo+CurrencyNo确定一条记录
} QteMortgageReq;

typedef QteMortgageReq               QteMortgageRsp;

typedef struct QteMortgageData
{
    QteMortgageNoType                MortgageNo;     //抵押品编号
    QteCurrencyNoType                CurrencyNo;     //折抵货币编号
    QteExchangeRateType              ExchangeRate;   //抵押品汇率
    QteProportionType                Proportion;     //抵押比例
} QteMortgageData;


////////////////////////////////////个股期货合约信息//////////////////////////////
static const CspProtocolCodeType     CMD_QTE_StockContReq         = 0x0170;
static const CspProtocolCodeType     CMD_QTE_StockContRsp         = 0x0171;
static const CspProtocolCodeType     CMD_QTE_StockContDataRsp     = 0x0172;

typedef struct QteStockContReq
{
    QteContractIdType                ContractId;     //个股期货合约代码
} QteStockContReq;

typedef QteStockContReq              QteStockContRsp;

typedef struct QteStockContData
{
    QteContractIdType                ContractId;     //个股期货合约代码
    QteContractDotType               ContractDot;    //个股期货合约每手乘数
} QteStockContData;


/////////////////////////////////////即时行情订阅(0x0A)/////////////////////////////////////

//行情订阅请求,普通行情和深度行情都推送
static const CspProtocolCodeType     CMD_QTE_SnapShotSub           = 0x0A00;
//普通行情退订请求
static const CspProtocolCodeType     CMD_QTE_SnapShotUnSub         = 0x0A01;
//普通行情订阅数据
static const CspProtocolCodeType     CMD_QTE_SnapShotLV1Rsp        = 0x0A02;
//普通行情推送消息
static const CspProtocolCodeType     CMD_QTE_SnapShotLV1Notice     = 0x0A03;
//深度行情订阅数据
static const CspProtocolCodeType     CMD_QTE_SnapShotLV2Rsp        = 0x0A04;
//深度行情推送消息
static const CspProtocolCodeType     CMD_QTE_SnapShotLV2Notice     = 0x0A05;
//品种或合约状态变化通知
static const CspProtocolCodeType     CMD_QTE_Stats_Notice          = 0x0A06;

/////////////////////////////////////普通行情数据结构//////////////////////////

//订阅和退订请求, 普通行情和level2行情均使用此结构
typedef struct QteSnapShotReq
{
    union
    {
        QteCommodityIdType           CommodityId;   //品种编号(后台之间订阅使用品种)
        QteContractIdType            ContractId;    //合约编号(客户端向后台订阅使用合约)
    };
} QteSnapShotReq;

//普通行情应答或推送数据组成部分为：
//QteSnapShotCont + QteSnapShotData + (FieldCount - 1)*QteSnapShotField

//合约编号部分
typedef struct QteSnapShotCont
{
    QteContType                      Cont;
} QteSnapShotCont;

//行情快照中各字段
typedef struct QteSnapShotField
{
    QteQuoteFieldMeanType            FieldMean;     //本数据域含义
    union
    {
        QtePriceFieldType            Price;         //价格字段取本值
        QteQtyFieldType              Qty;           //数量字段取本值
        QteQuoteDateTimeType         DateTime;      //日期时间字段取本值
        QteQuoteDateType             Date;          //日期字段取本值
        QteQuoteTimeType             Time;          //时间字段取本值
        QteQuoteStrType              Str;           //字符串字段取本值
        QteQuoteCharType             Char;          //字符类型取本值
    };
} QteSnapShotField;

//行情快照部分
typedef struct QteSnapShotData
{
    QteQuoteDateTimeType             UpdateTime;     //行情更新时间
    QteQuoteFieldCountType           FieldCount;     //QSnapShotField的数量
    QteSnapShotField                 FieldData[1];   //数据字段的起始位置，无数据时此结构不包含此字段长度
} QteSnapShotData;

/////////////////////////////////////深度行情数据结构//////////////////////////
//深度行情应答或者推送数据组成部分为：
//QteLV2Cont + QteLV2Data + DepthCount * QteDepthNewDetail(QteDepthDelDetail)

//合约名称部分
typedef struct QteLV2Cont
{
    QteContType                      Cont;
} QteLV2Cont;

//深度数据部分
typedef struct QteLV2Data
{
    QteQuoteDateTimeType             UpdateTime;     //行情更新时间
    QteDepthLengthType               DepthLength;    //深度部分长度,不包括本结构
    QteQuoteFieldCountType           DepthCount;     //QDepDetail的数量
} QteLV2Data;

//深度更新和修改操作部分
typedef struct QteDepthNewDetail
{
    QteDepthActionType               Action;         //操作，高4位标示买卖，低4位表示增加和修改
    QteDepthLevelType                Level;          //价格深度
    QteQtyFieldType                  Qty;            //深度数量
    QtePriceFieldType                Price;          //深度价格
} QteDepthNewDetail;

//深度删除操作部分
typedef struct QteDepthDelDetail
{
    QteDepthActionType               Action;         //操作，高4位标示买卖，低4位表示删除
    QteDepthLevelType                Level;          //价格深度
} QteDepthDelDetail;

/////////////////////////////////////合约状态数据结构////////////////////////
//品种或合约状态更新QteStateCont和QStateData组成
typedef struct QteStateCont
{
    QteContType                      Cont;           //品种或合约编号
} QteStateCont;

typedef struct QteStateData
{
    QteTradingStateType              State;          //品种或合约状态
} QteStateData;

//////////////////////////////////////历史行情协议(0x0B)///////////////////////////

//////////////////////////////////////时间模板查询/////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_TimeBucketReq         = 0x0B00;
static const CspProtocolCodeType     CMD_QTE_TimeBucketRsp         = 0x0B01;
static const CspProtocolCodeType     CMD_QTE_TimeBucketDataRsp     = 0x0B02;

//时间模板查询请求
typedef struct QteTimeBucketReq
{
    QteTemplateNoType                TemplateNo;      //时间模板编号
} QteTimeBucketReq;

//时间模板查询应答
typedef QteTimeBucketReq             QteTimeBucketRsp;

//时间模板数据应答
typedef struct QteTimeBucketDataRsp
{
    QteTemplateNoType                TemplateNo;     //时间模板编号
    QteQuoteTimeType                 BeginTime;      //开始时间
    QteTradingStateType              TradingState;   //交易状态
    QteDateFlagType                  DateFlag;       //日期标记
} QteTimeBucketDataRsp;


/////////////////////////////////////计算模板查询/////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_CalTimeBucketReq      = 0x0B03;
static const CspProtocolCodeType     CMD_QTE_CalTimeBucketRsp      = 0x0B04;
static const CspProtocolCodeType     CMD_QTE_CalTimeBucketDataRsp  = 0x0B05;

//计算模板查询请求
typedef QteTimeBucketReq             QteCalTimeBucketReq;

//计算模板查询应答
typedef QteCalTimeBucketReq          QteCalTimeBucketRsp;

//计算模板数据应答
typedef struct QteCalTimeBucketDataRsp
{
    QteTemplateNoType                TemplateNo;      //时间模板编号
    QteTemplateIndexType             Index;           //计算模板索引号，从0开始
    QteTradingStateType              TradingState;    //交易状态
    QteDateFlagType                  DateFlag;        //日期标记
    QteQuoteTimeType                 BeginTime;       //开始时间
    QteQuoteTimeType                 EndTime;         //结束时间
} QteCalTimeBucketDataRsp;


/////////////////////////////////////品种时间模板关系查询/////////////////////////
static const CspProtocolCodeType     CMD_QTE_CommTimeBucketReq      = 0x0B06;
static const CspProtocolCodeType     CMD_QTE_CommTimeBucketRsp      = 0x0B07;
static const CspProtocolCodeType     CMD_QTE_CommTimeBucketDataRsp  = 0x0B08;

//品种时间模板关系查询请求
typedef struct QteCommTimeBucketReq
{
    QteCommodityIdType               CommodityId;     //品种编号
} QteCommTimeBucketReq;

//品种时间模板查询应答
typedef QteCommTimeBucketReq         QteCommTimeBucketRsp;

//品种时间模板关系数据应答
typedef struct QteCommTimeBucketDataRsp
{
    QteCommodityIdType               CommodityId;     //品种编号
    QteTemplateNoType                TemplateNo;      //时间模板编号
} QteCommTimeBucketDataRsp;

/////////////////////////////////////K线查询///////////////////////////////////
static const CspProtocolCodeType     CMD_QTE_KLineReq              = 0x0B10;
static const CspProtocolCodeType     CMD_QTE_KLineRsp              = 0x0B11;
static const CspProtocolCodeType     CMD_QTE_KLineDataRsp          = 0x0B12;
static const CspProtocolCodeType     CMD_QTE_KLineDataNotice       = 0x0B13;

//K线查询请求
typedef struct QteKLineReq
{
    QteKLineHopeCountType            HopeCount;       //期望数量（扩展使用）
    QteContractIdType                ContractId;      //合约ID
    QteKLineDataType                 KLineType;       //K线类型
    QteQuoteDateTimeType             BeginTime;       //查询开始时间 所有数据查询均是从尾部开始，begintime表示的是截止时间，无begintime最大查询500根
    QteQuoteDateTimeType             EndTime;         //查询结束时间 0就是从末尾查，注意：数据结果中不包含与begintime和endtime相等的数据
} QteKLineReq;

//K线查询应答
typedef QteKLineReq                  QteKLineRsp;

//K线查询数据应答，此记录每包一个,后续包含多个数据体
typedef struct QteKLineHead  //sizeof 52字节
{
    QteContractIdType                ContractId;      //合约ID
    QteKLineDataType                 KLineType;       //K线类型
} QteKLineHead;

typedef struct QteKLineData //sizeof 80字节
{
    QteKLineIndexType                KLineIndex;      //K线索引  tick每笔连续序号，min交易分钟序号，day无效
    QteQuoteDateType                 TradeDate;       //交易日   tick无效，min可能和时间戳不同，day和时间戳相同
    QteQuoteDateTimeType             DateTimeStamp;   //时间戳，不同数据类型，精度不同
    QteQtyFieldType                  TotalQty;       //行情快照 总成交量
    QteQtyFieldType                  PositionQty;    //行情快照 持仓量
    QtePriceFieldType                LastPrice;      //最新价（收盘价）

    union
    {
        struct
        {
            QteQtyFieldType          KLineQty;       //K线成交量 day  min
            QtePriceFieldType        OpeningPrice;   //开盘价  day  min
            QtePriceFieldType        HighPrice;      //最高价  day  min
            QtePriceFieldType        LowPrice;       //最低价  day  min
            QtePriceFieldType        SettlePrice;    //结算价  day  min

        };
        struct
        {
            QteVolChgFieldType       LastQty;        //明细现手  tick
            QtePosChgFieldType       PositionChg;    //持仓量变化 tick
            QtePriceFieldType        BuyPrice;       //买价 tick
            QtePriceFieldType        SellPrice;      //卖价 tick
            QteQtyFieldType          BuyQty;         //买量 tick
            QteQtyFieldType          SellQty;        //卖量 tick
        };
    };
} QteKLineData;

typedef struct QteHisFileData
{
    QteKLineHead                     Head;
    QteKLineData                     Data;

} QteHisFileData;


/////////////////////////////////////历史波动率查询///////////////////////////////
static const CspProtocolCodeType     CMD_QTE_SigmaReq         = 0x0B20;
static const CspProtocolCodeType     CMD_QTE_SigmaRsp         = 0x0B21;
static const CspProtocolCodeType     CMD_QTE_SigmaDataRsp     = 0x0B22;
static const CspProtocolCodeType     CMD_QTE_SigmaDataNotice  = 0x0B23;

//历史波动率查询
typedef struct QteHisSigmaReq
{
    QteKLineHopeCountType            HopeCount;     //期望数量（扩展使用）
    QteContractIdType                ContractId;    //合约ID
    QteKLineDataType                 KLineType;     //K线类型
    QteQuoteDateTimeType             BeginTime;     //查询开始时间 所有数据查询均是从尾部开始，begintime表示的是截止时间，无begintime最大查询500根
    QteQuoteDateTimeType             EndTime;       //查询结束时间 0就是从末尾查，注意：数据结果中不包含与begintime和endtime相等的数据
} QteHisSigmaReq;

typedef QteHisSigmaReq               QteHisSigmaRsp;

//历史波动率查询数据应答
typedef struct QteHisSigmaHead
{
    QteContractIdType                ContractId;    //合约ID
    QteKLineDataType                 KLineType;     //K线类型
} QteHisSigmaHead;

typedef struct QteHisSigmaData //sizeof 72字节
{
    QteKLineIndexType                KLineIndex;    //波动率索引  tick每笔连续序号，min交易分钟序号，day无效
    QteQuoteDateType                 TradeDate;     //交易日   tick无效，min可能和时间戳不同，day和时间戳相同
    QteQuoteDateTimeType             DateTimeStamp; //时间戳，不同数据类型，精度不同
    QtePriceFieldType                TheoryPrice;   //理论价
    QtePriceFieldType                Sigma;         //隐含波动率
    QtePriceFieldType                Delta;         //期权价格变动与其标的资产价格变动的比率
    QtePriceFieldType                Gamma;         //delta的变化与其标的资产价格变化的比率
    QtePriceFieldType                Vega;          //交易组合价值变化与其标的资产波动率变化的比率
    QtePriceFieldType                Theta;         //交易组合价值变化与时间变化的比率
    QtePriceFieldType                Rho;           //交易组合价值对于利率变化的敏感性

} QteHisSigmaData;


/////////////////////////////////////客户品种组///////////////////////////////
static const CspProtocolCodeType     CMD_QTE_UserCommGroupNotice      = 0x0B30;

//用户品种组通知
typedef struct QteUserCommGroupNotice
{
    QteUserNameType                  UserName;          //用户名
    QteCommGroupNoType               GroupNo;       //收费品种组号
    QteDateStrType                   BeginDate;         //开始日期
    QteDateStrType                   ExpireDate;        //结束日期
}QteUserCommGroupNotice;

/////////////////////////////////////行情排序///////////////////////////////
static const CspProtocolCodeType     CMD_QTE_ContractSortReq      = 0x0B40;
static const CspProtocolCodeType     CMD_QTE_ContractSortRsp      = 0x0B41;

//行情排序请求
typedef struct QteContractSortReq
{
    QteContractSortType              SortType;      //排序指标
    QteContractCountType             Count;         //合约数量
    QteContractIdType                ContractId[1];    //合约ID
}QteContractSortReq;

typedef struct QteContractSortDataType
{
    QtePriceFieldType                Value;
    QteContractIdType                ContractId;
}QteContractSortDataType;

typedef struct QteContractSortRsp
{
    QteContractSortType              SortType;      //排序指标
    QteContractCountType             Count;         //合约数量
    QteContractSortDataType          SortData[1];   //具体数值
}QteContractSortRsp;

/////////////////////////////////////用于修补大商所将夜盘闭市时间缩短后分时图显示不正确的bug///////////////////////////////
static const CspProtocolCodeType CMD_QTE_HisCommodityTemplateReq      = 0x0B50;
static const CspProtocolCodeType CMD_QTE_HisCommodityTemplateRsp      = 0x0B51;
static const CspProtocolCodeType CMD_QTE_HisCommodityTemplateDataRsp  = 0x0B52;


typedef struct QteHisCommodityTemplateReq
{
    QteCommodityIdType              CommodityId;                    //品种ID 不可修改
    QteTemplateNoType               TemplateNo;                     //模板编号 不可修改
}QteHisCommodityTemplateRsp;

typedef struct QmeHisCommodityTemplateDataRsp
{
    QteCommodityIdType              CommodityId;                    //品种ID 不可修改
    QteTemplateNoType               TemplateNo;                     //模板编号 不可修改
    QteQuoteDateType                BeginDate;                      //开始日期
    QteQuoteDateType                EndDate;                        //结束日期
}QteHisCommodityTemplateDataRsp;


/////////////////////////////////////客户权限///////////////////////////////
static const CspProtocolCodeType CMD_QTE_UserRightReq      = 0x0B70;
static const CspProtocolCodeType CMD_QTE_UserRightRsp      = 0x0B71;
static const CspProtocolCodeType CMD_QTE_UserRightDataRsp  = 0x0B72;

// 用户权限查询
typedef struct QteUserRightReq
{
    QteUserNameType UserName;                                               // 行情账号用户名
}QteUserRightReq;

typedef QteUserRightReq            QteUserRightRsp;

// 用户权限数据应答
typedef struct QteUserRightDataRsp
{
    QteUserNameType                UserName;                                // 行情账号用户名
    QteUserRightType               RightType;                               // 授权项目类型
    QteUserRightNoType             RightNo;                                 // 品种组or插件号
    QteDateStrType                 BeginDate;                               // 开始日期
    QteDateStrType                 ExpireData;                              // 结束日期
}QteUserRightDataRsp;

#pragma pack(pop)

#endif
