#pragma once
#include "CspProtocol.h"
#define NEWS_FIELD_MAX(x)            (( CSP_FRAME_MAX / sizeof(x) - 5 < 1000)? ( CSP_FRAME_MAX / sizeof(x) - 5) : 1000)

typedef C8                          STR500[501];

typedef C8                          STR400[401];

typedef C8                          STR600[601];

typedef C8                          STR1000[1001];

typedef         I32                 NEWSIntType;

typedef         CspLanguageType     NewsLangType;

typedef         STR10               NEWSLanguageType;

typedef         STR50               NEWSStrType;

typedef         STR200              NEWSSummaryType;

typedef         STR200              NEWSPicType;

typedef         C8                  NEWSTitleType[256];

typedef         C8                  NEWSContentType[10240];

typedef         STIME               NewsTimeType;

typedef         SDATETIME           NEWSDateTimeType;

typedef         STR50               NEWSTagType;

typedef         C8                  NEWSKeyType[501];

typedef         SDATE               NEWSDATE;

typedef         STR10               NEWSColorType;

typedef         STR10               NEWSPackageNoType;

typedef         STR20               NEWSCommodity;

typedef         STR50               NEWSContractType;

typedef         STR100              NewsTradeCommodityName;

typedef         STR50               NewsUnitType;

typedef         STR20               NewsTickType;

typedef         STR100              NewsRaisingLimitType;

typedef         STR50               NewsTradingMarginType;

typedef         STR400               NewsContractMonthType;

typedef         STR600              NewsTradingTimeType;

typedef         STR500              NewsTradingDateType;

typedef         STR200              NewsDeliveryDateType;

typedef         STR600              NewsDeliveryGradeType;

typedef         STR100              NewsDeliverySiteType;

typedef         STR50               NewsDeliveryMethodType;

typedef         STR50               NewsDeliveryUnitType;

typedef         STR50               NewsTradeCodeType;

typedef         STR50               NewsExchangeType;

typedef         F64                 NewsPriceType;

typedef         STR1000              NewsTcReportType;

typedef         C8                              NEWSQryDirectionType;           //查询方向
static          const NEWSQryDirectionType      NEWS_QRY_UP         = 'U';      //查询最新的数据
static          const NEWSQryDirectionType      NEWS_QRY_DOWN       = 'D';      //向下查询

typedef         C8                              NEWSTagAttrType;                 //新闻Tag属性
static          const NEWSTagAttrType           NEWS_ATTR_TAG        = 'T';       //Tag
static          const NEWSTagAttrType           NEWS_ATTR_CLASS      = 'C';       //分类
static          const NEWSTagAttrType           NEWS_ATTR_SOURCE     = 'S';       //新闻源

typedef         char                             NEWSTopType;                 //新闻Tag属性
static          const NEWSTopType               NEWS_TOP_YES         = 'Y';       //Tag
static          const NEWSTopType               NEWS_TOP_NO          = 'N';       //分类



typedef         char                            NEWSTimeType;
static          const NEWSTimeType               NEWS_DAY                = 'D';       //每天
static          const NEWSTimeType               NEWS_SHORT_TERM         = 'S';       //短期
static          const NEWSTimeType               NEWS_MIDDLE_TERM        = 'M';       //中期
static          const NEWSTimeType               NEWS_FIFTEEN_MINUTE     = 'F';       //15分钟


static const       CspErrorCodeType        NEWSCallSqlProcedureFail  = 1;



