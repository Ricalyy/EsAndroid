/* 
 * File:   TrdProtocolType.h
 * Author: Mingxiang Liu
 * 功能:   协议字段类型和枚举类型定义
 *
 * Created on 2017年08月25日, 下午1:05
 */

#ifndef TRD_PROTOCOL_TYPE_H
#define TRD_PROTOCOL_TYPE_H		

typedef I8							BYTE50[50];
typedef STR20 						TrdAppCodeType;								//客户端软件标识码
typedef STR50 						TrdBankAccountType;							//银行账户
typedef STR50 						TrdBankNameType;							//银行名称
typedef STR10 						TrdBankNoType;								//银行标识
typedef STR10 						TrdBankBrchNoType;							//银行分中心编号
typedef STR20 						TrdBankPswType;								//银行密码
typedef STR30						TrdBrokerApiType;							//会员系统类型
typedef B8							TrdBoolType;								//布尔类型
typedef STR50 						TrdRemarkType;								//备注
typedef STR40 						TrdSessionNoType;							//会话标识
typedef STR10 						TrdCheckerNoType;							//审核人
typedef STR20 						TrdCommodityNoType;							//品种编号(ZCE|F|SR, ZCE|O|SR)
typedef STR10 						TrdCompanyNoType;							//期货公司代码(易盛系统内部编码)
typedef STR20						TrdCompanyAddressNoType;					//登录地址编号
typedef STR50 						TrdContractNoType;							//合约编号(含组合合约)
typedef STR30 						TrdSingleContractNoType;					//合约编号(单边合约)
typedef STR10 						TrdCurrencyGroupNoType;						//币种组编号
typedef STR20 						TrdCurrencyNameType;						//币种名称
typedef STR10 						TrdCurrencyNoType;							//币种号
typedef SDATETIME					TrdDateTimeType;		 					//日期时间(YYYY-MM-DD HH:mm:SS) 
typedef SLDATETIME					TrdDateTimeExType;							//日期时间(YYYY-MM-DD HH:mm:SS.mmm)
typedef SDATE 						TrdDateType;								//日期(YYYY-MM-DD)
typedef STR10 						TrdDepositGroupNoType;						//大边保证金组的组号
typedef STR20 						TrdEnquiryNoType;							//询价请求号，应价时用(内盘)
typedef I32 						TrdErrorCodeType;							//错误码
typedef STR200 						TrdErrorTextType;							//错误信息
typedef STR10 						TrdExchangeNoType;							//交易所编号
typedef F64		 					TrdExchangeRateType;						//币种汇率
typedef STR200 						TrdLoginInfoType;							//登录信息, 机器地址、登录和退出时间等
typedef U32							TrdContentSizeType;							//正文长度类型
typedef U8							TrdDnyFieldCountType;						//动态字段长度类型
typedef STR50 						TrdLiquidateNoType;							//平仓编号
typedef STR20 						TrdLocalNoType;								//本地号 由会员系统报单席位生成
typedef STR30 						TrdLoginNameType;	 						//登录帐号名称
typedef STR20 						TrdLoginNoType;								//登录帐号
typedef U8							TrdMarketLevelType;							//市价撮合深度,目前只有中金所支持，取值为0、1、5(内盘)
typedef STR20 						TrdMatchNoType;								//成交关键字
typedef F64	 						TrdFundType;								//资金类型
typedef STR100 						TrdMsgTitleType;							//消息标题
typedef STR20 						TrdOperatorNoType;							//操作人
typedef STR20 						TrdOrderNoType;								//委托号 由会员系统交易服务器生成
typedef BYTE50						TrdOrderRemarkType;							//定单备注(可以是二进制内容)
typedef STR50 						TrdPositionNoType;							//持仓号
typedef F64	 						TrdPriceType;								//价格类型
typedef U32							TrdQuantityType;							//数量类型
typedef F64	 						TrdRatioType;								//比例类型
typedef STR100 						TrdRiskPtlTitleType;						//风险协议标题
typedef STR10 						TrdSeatNoType;								//席位号 交易所或上手的登录帐号
typedef STR10 						TrdSendNoType;								//发送者
typedef U32							TrdSerialIdType;							//序列号
typedef STR20						TrdOrderRefType;							//报单引用
typedef STR50 						TrdSystemNoType;							//系统号 由交易所生成
typedef STIME 						TrdTimeType;								//时间类型(HH:MM:SS)
typedef STR30 						TrdTradeAuthType;	 						//认证密码
typedef STR30 						TrdTradePswType;							//登录密码
typedef STR20 						TrdTransAuthType;							//银期转账认证密码
typedef STR30 						TrdUserNameType;							//用户名称
typedef STR20 						TrdUserNoType;								//用户号
typedef VSTR16						TrdVarcharType;								//变长字符串
typedef SIPV4						TrdBrokerAddressNoType;						//后台地址编号
typedef STR10						TrdSMSAuthCodeType;							//短信认证码

// 二次认证设备
typedef C8                          TrdSecondLoginTypeType;
static const TrdSecondLoginTypeType TRD_LOGINTYPE_NORMAL = 'N';                 //信任设备
static const TrdSecondLoginTypeType TRD_LOGINTYPE_TEMPORARY = 'T';              //临时设备


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//通用的空类型和未定义类型
static const C8 TRD_C_None											= 0; // 空
static const C8 TRD_C_Undefine										= 1; // 未定义

//用户登录状态
typedef C8 TrdLoginStatusType;
static const TrdLoginStatusType TRD_LS_Disconnecting				= 'i'; //断开中
static const TrdLoginStatusType TRD_LS_Disconnected					= 'D'; //已断开
static const TrdLoginStatusType TRD_LS_Connected					= 'C'; //已连接
static const TrdLoginStatusType TRD_LS_Logging						= 'o'; //登录中
static const TrdLoginStatusType TRD_LS_Logined						= 'L'; //已登录

//终端系统类型
typedef C8 TrdTerminalTypeType;
static const TrdTerminalTypeType TRD_TT_Windows						= 'W';//Windows	
static const TrdTerminalTypeType TRD_TT_Mac							= 'M';//Mac		
static const TrdTerminalTypeType TRD_TT_Linux						= 'L';//Linux	
static const TrdTerminalTypeType TRD_TT_Android						= 'A';//Android	
static const TrdTerminalTypeType TRD_TT_IOS							= 'I';//IOS		
static const TrdTerminalTypeType TRD_TT_WinPhone					= 'w';//WinPhone
static const TrdTerminalTypeType TRD_TT_Other						= 'O';//其他	

//定单类型
typedef C8 TrdOrderTypeType;
static const TrdOrderTypeType TRD_OT_Market							= '1'; //市价单
static const TrdOrderTypeType TRD_OT_Limit							= '2'; //限价单
static const TrdOrderTypeType TRD_OT_MarketStop						= '3'; //市价止损
static const TrdOrderTypeType TRD_OT_LimitStop						= '4'; //限价止损
static const TrdOrderTypeType TRD_OT_Execute						= '5'; //行权
static const TrdOrderTypeType TRD_OT_Abandon						= '6'; //弃权
static const TrdOrderTypeType TRD_OT_Enquiry						= '7'; //询价
static const TrdOrderTypeType TRD_OT_Offer							= '8'; //应价
static const TrdOrderTypeType TRD_OT_Iceberg						= '9'; //冰山单
static const TrdOrderTypeType TRD_OT_Ghost							= 'A'; //影子单
static const TrdOrderTypeType TRD_OT_Swap							= 'B'; //互换
static const TrdOrderTypeType TRD_OT_SpreadApply					= 'C'; //套利申请
static const TrdOrderTypeType TRD_OT_HedgApply						= 'D'; //套保申请
static const TrdOrderTypeType TRD_OT_OptionAutoClose				= 'E'; //期权自对冲
static const TrdOrderTypeType TRD_OT_FutureAutoClose				= 'F'; //履约期货自对冲
static const TrdOrderTypeType TRD_OT_StockLock                      = 'L'; //证券仓位锁定单
static const TrdOrderTypeType TRD_OT_StockUnLock                    = 'U'; //证券仓位解锁单

//定单操作类型
typedef C8 TrdOrderActionTypeType;
static const TrdOrderActionTypeType TRD_OAT_Cancel					= 'C'; //撤单
static const TrdOrderActionTypeType TRD_OAT_Suspend					= 'S'; //挂起
static const TrdOrderActionTypeType TRD_OAT_Resum					= 'R'; //激活
static const TrdOrderActionTypeType TRD_OAT_Delete					= 'D'; //删除

//策略类型
typedef C8 TrdStrategyTypeType;
static const TrdStrategyTypeType TRD_ST_PreOrder					= 'p'; //预备单(埋单)
static const TrdStrategyTypeType TRD_ST_AutoOrder					= 'A'; //自动单

static const TrdStrategyTypeType TRD_ST_Condition					= 'C'; //条件单
static const TrdStrategyTypeType TRD_ST_StStopLoss                  = 'D'; //父条件单
static const TrdStrategyTypeType TRD_ST_BackHand                    = 'E'; //条件单反手
static const TrdStrategyTypeType TRD_ST_StopLoss					= 'L'; //止损单
static const TrdStrategyTypeType TRD_ST_StopProfit					= 'P'; //止盈单
static const TrdStrategyTypeType TRD_ST_FloatStopLoss				= 'F'; //浮动止损单
static const TrdStrategyTypeType TRD_ST_Breakeven					= 'B'; //保本止损单
static const TrdStrategyTypeType TRD_ST_OpenStopLoss_SLoss          = 'O'; //开仓止损
static const TrdStrategyTypeType TRD_ST_OpenStopLoss_SProfit        = 'S'; //开仓止盈
static const TrdStrategyTypeType TRD_ST_OpenStopLoss_SFloat         = 'U'; //浮动止损
static const TrdStrategyTypeType TRD_ST_OpenStopLoss_SBreakeven     = 'T'; //开仓保本

//有效类型
typedef C8 TrdValidTypeType;
static const TrdValidTypeType TRD_VT_FOK							= '1'; //即时全部
static const TrdValidTypeType TRD_VT_IOC							= '2'; //即时部分
static const TrdValidTypeType TRD_VT_GFS							= '3'; //本节有效
static const TrdValidTypeType TRD_VT_GFD							= '4'; //当日有效
static const TrdValidTypeType TRD_VT_GTC							= '5'; //长期有效
static const TrdValidTypeType TRD_VT_GTD							= '6'; //限期有效
static const TrdValidTypeType TRD_VT_NDF							= '7'; //次日首节有效(HK)

//委托来源(尽量保持客户端发送的数值)
typedef C8 TrdOrderWayType;
static const TrdOrderWayType TRD_OW_All								= 'A'; //所有
static const TrdOrderWayType TRD_OW_ETrade							= 'E'; //E-Trade
static const TrdOrderWayType TRD_OW_ProxyETrade						= 'P'; //代理单
static const TrdOrderWayType TRD_OW_JTrade							= 'J'; //J-Trade
static const TrdOrderWayType TRD_OW_Manual							= 'M'; //人工单
static const TrdOrderWayType TRD_OW_Carry							= 'C'; //Carry单
static const TrdOrderWayType TRD_OW_Delivery						= 'D'; //交割行权
static const TrdOrderWayType TRD_OW_Program							= 'S'; //程式单	
static const TrdOrderWayType TRD_OW_Execute							= 'e'; //行权
static const TrdOrderWayType TRD_OW_Abandon							= 'a'; //弃权
static const TrdOrderWayType TRD_OW_Channel							= 'c'; //通道费
static const TrdOrderWayType TRD_OW_RTS								= 'R'; //RTS
static const TrdOrderWayType TRD_OW_DrawLine						= 'd'; //划线下单
static const TrdOrderWayType TRD_OW_Strategy						= 's'; //策略单下单

//买卖
typedef C8 TrdDirectType;
static const TrdDirectType TRD_D_Buy								= 'B'; //买入
static const TrdDirectType TRD_D_Sell								= 'S'; //卖出
static const TrdDirectType TRD_D_Both								= 'A'; //双边

//开平
typedef C8 TrdOffsetType;
static const TrdOffsetType TRD_O_Open								= 'O'; //开仓
static const TrdOffsetType TRD_O_Cover								= 'C'; //平仓
static const TrdOffsetType TRD_O_CoverT								= 'T'; //平今
static const TrdOffsetType TRD_O_OpenCover							= '1'; //开平，应价时有效
static const TrdOffsetType TRD_O_CoverOpen							= '2'; //平开，应价时有效

//投保标记
typedef C8 TrdHedgeType;
static const TrdHedgeType TRD_H_Speculate							= 'T'; //投机
static const TrdHedgeType TRD_H_Hedge								= 'B'; //套保
static const TrdHedgeType TRD_H_Spread								= 'S'; //套利
static const TrdHedgeType TRD_H_Market								= 'M'; //做市
static const TrdHedgeType TRD_H_Cover								= 'C'; //做市

//委托价类型
typedef C8 TrdOrderPriceTypeType;
static const TrdOrderPriceTypeType TRD_PT_Abs						= 'A'; //绝对价(指定价)
static const TrdOrderPriceTypeType TRD_PT_Lsat						= 'L'; //最新价
static const TrdOrderPriceTypeType TRD_PT_Queue						= 'Q'; //排队价
static const TrdOrderPriceTypeType TRD_PT_Match						= 'M'; //对手价
static const TrdOrderPriceTypeType TRD_PT_Market					= 'm'; //市价

//停损价类型
typedef C8 TrdStopPriceTypeType;
static const TrdOrderPriceTypeType TRD_SPT_Price					= 'P'; //价格
static const TrdOrderPriceTypeType TRD_SPT_Diff						= 'D'; //价差

//报单状态
typedef C8 TrdOrderStateType;
static const TrdOrderStateType TRD_OS_Sended						= '0'; //已发送
static const TrdOrderStateType TRD_OS_Accept						= '1'; //已受理
static const TrdOrderStateType TRD_OS_Triggering					= '2'; //待触发
static const TrdOrderStateType TRD_OS_Active						= '3'; //已生效
static const TrdOrderStateType TRD_OS_Queued						= '4'; //已排队
static const TrdOrderStateType TRD_OS_PartFilled					= '5'; //部分成交
static const TrdOrderStateType TRD_OS_Filled						= '6'; //完全成交
static const TrdOrderStateType TRD_OS_Canceling						= '7'; //待撤
static const TrdOrderStateType TRD_OS_Modifying						= '8'; //待改
static const TrdOrderStateType TRD_OS_Canceled						= '9'; //已撤单
static const TrdOrderStateType TRD_OS_PartCanceled					= 'A'; //已撤余单
static const TrdOrderStateType TRD_OS_Fail							= 'B'; //指令失败
static const TrdOrderStateType TRD_OS_Checking						= 'C'; //待审核
static const TrdOrderStateType TRD_OS_Suspended						= 'D'; //已挂起
static const TrdOrderStateType TRD_OS_Apply							= 'E'; //已申请
static const TrdOrderStateType TRD_OS_Invalid						= 'F'; //无效单
static const TrdOrderStateType TRD_OS_PartTriggered					= 'G'; //部分触发
static const TrdOrderStateType TRD_OS_FillTriggered					= 'H'; //完全触发
static const TrdOrderStateType TRD_OS_TriggerFailed					= 'M'; //触发失败
static const TrdOrderStateType TRD_OS_PartFailed					= 'I'; //余单失败

static const TrdOrderStateType TRD_OS_StStopLoss					= 'N'; //开仓止损策略单不监控(条件单)
static const TrdOrderStateType TRD_OS_OpenStopLoss                  = 'S'; //开仓止损策略单不监控(普通单)
//本地套利定单状态
static const TrdOrderStateType TRD_OS_Paired						= 'J'; //已配对;
static const TrdOrderStateType TRD_OS_Pairing						= 'K'; //配对中;
static const TrdOrderStateType TRD_OS_Unpaired						= 'L'; //有瘸腿;

//市场状态
typedef C8 TrdCommodityStatusType;
static const TrdCommodityStatusType TRD_CS_Bidding					= 'B'; //竞价申报;
static const TrdCommodityStatusType TRD_CS_Matching					= 'M'; //竞价撮合;
static const TrdCommodityStatusType TRD_CS_Trading					= 'T'; //连续交易;
static const TrdCommodityStatusType TRD_CS_Pause					= 'P'; //暂停交易;
static const TrdCommodityStatusType TRD_CS_Closed					= 'C'; //闭市;

//帐单类型
typedef C8 TrdBillTypeType;
static const TrdBillTypeType TRD_BT_Day								= 'D'; //日结单
static const TrdBillTypeType TRD_BT_Month							= 'M'; //月结单

//账单格式类型
typedef C8 TrdBillFormatTypeType;
static const TrdBillFormatTypeType TRD_BFT_Text						= 'T'; //纯文本
static const TrdBillFormatTypeType TRD_BFT_Html						= 'H'; //网页
static const TrdBillFormatTypeType TRD_BFT_Pdf						= 'P'; //Pdf
static const TrdBillFormatTypeType TRD_BFT_Csv						= 'C'; //Csv
static const TrdBillFormatTypeType TRD_BFT_Link						= 'L'; //链接

//出入金类型
typedef C8 TrdCashTypeType;
static const TrdCashTypeType TRD_CT_Out								= 'O'; //出金
static const TrdCashTypeType TRD_CT_In								= 'I'; //入金
static const TrdCashTypeType TRD_CT_Adjust							= 'A'; //资金调整

//出入金方式
typedef C8 TrdCashModeType;
static const TrdCashModeType TRD_CM_Amount							= 'A'; //转帐
static const TrdCashModeType TRD_CM_Check							= 'B'; //支票
static const TrdCashModeType TRD_CM_Cash							= 'C'; //现金
static const TrdCashModeType TRD_CM_Exchange						= 'E'; //换汇
static const TrdCashModeType TRD_CM_Transfer						= 'T'; //银期
static const TrdCashModeType TRD_CM_FeeAdjust						= 'F'; //佣金调整
static const TrdCashModeType TRD_CM_ProfitAdjust					= 'P'; //盈亏调整
static const TrdCashModeType TRD_CM_Pledge							= 'L'; //质押资金
static const TrdCashModeType TRD_CM_Interestre						= 'I'; //利息收入

//审核状态
typedef C8 TrdCheckStateType;
static const TrdCheckStateType TRD_CS_Waiting						= 'W'; //待审核
static const TrdCheckStateType TRD_CS_Pass							= 'Y'; //已通过
static const TrdCheckStateType TRD_CS_Fail							= 'F'; //未通过
static const TrdCheckStateType TRD_CS_Transing						= 'T'; //已在途

//消息级别
typedef C8 TrdMessageLevelType;
static const TrdMessageLevelType TRD_ML_Info						= 'I'; //提示
static const TrdMessageLevelType TRD_ML_Warning						= 'W'; //警告
static const TrdMessageLevelType TRD_ML_Error						= 'E'; //错误
static const TrdMessageLevelType TRD_ML_Vital						= 'V'; //重要
static const TrdMessageLevelType TRD_ML_Urgent						= 'U'; //紧急

//询价者
typedef C8 TrdEnquirerTypeType;
static const TrdEnquirerTypeType TRD_ET_Exchange					= 'M'; //交易所
static const TrdEnquirerTypeType TRD_ET_User						= 'U'; //客户

//客户类型
typedef C8 TrdUserTypeType;
static const TrdUserTypeType TRD_UT_Personal						= 'P'; //个人
static const TrdUserTypeType TRD_UT_Organ							= 'O'; //机构
static const TrdUserTypeType TRD_UT_MarketMaker						= 'M'; //做市商

//转账方向
typedef C8 TrdTransDirectType;
static const TrdTransDirectType TRD_TD_ToFutures					= 'I'; //银行->期货(转入)
static const TrdTransDirectType TRD_TD_ToBank						= 'O'; //期货->银行(转出)

//转账状态
typedef C8 TrdTransStateType;
static const TrdTransStateType TRD_TS_Send							= 'R'; //已发出
static const TrdTransStateType TRD_TS_Transing						= 'T'; //转账中
static const TrdTransStateType TRD_TS_Transed						= 'S'; //转账成功
static const TrdTransStateType TRD_TS_TransFail						= 'F'; //转账失败
static const TrdTransStateType TRD_TS_Reversing						= 'r'; //冲正中
static const TrdTransStateType TRD_TS_Reversed						= 's'; //冲正成功
static const TrdTransStateType TRD_TS_ReversFail					= 'f'; //冲正失败,此状态多余

//转账发起方
typedef C8 TrdTransInitiatorType;
static const TrdTransInitiatorType TRD_TI_Futures					= 'F'; //期货
static const TrdTransInitiatorType TRD_TI_Bank						= 'B'; //银行

//触发模式
typedef C8 TrdTriggerModeType;
static const TrdTriggerModeType TRD_TM_Latest						= 'L'; //最新价
static const TrdTriggerModeType TRD_TM_Bid							= 'B'; //买价
static const TrdTriggerModeType TRD_TM_Ask							= 'A'; //卖价

//触发条件
typedef C8 TrdTriggerConditionType;
static const TrdTriggerConditionType TRD_TC_Greater					= 'g'; //大于
static const TrdTriggerConditionType TRD_TC_GreaterEqual			= 'G'; //大于等于
static const TrdTriggerConditionType TRD_TC_Less					= 'l'; //小于
static const TrdTriggerConditionType TRD_TC_LessEqual				= 'L'; //小于等于

//资金字段索引
typedef U8 TrdFundFieldIndexType;
//变动字段开始位置
static const TrdFundFieldIndexType TRD_FFI_PreAvailable				= 0; //昨可用
static const TrdFundFieldIndexType TRD_FFI_PreBalance				= 1; //昨账面
static const TrdFundFieldIndexType TRD_FFI_PreEquity				= 2; //昨权益
static const TrdFundFieldIndexType TRD_FFI_PreMarketEquity			= 3; //昨市值权益
static const TrdFundFieldIndexType TRD_FFI_PreUnExpProfit			= 4; //昨未结平盈
static const TrdFundFieldIndexType TRD_FFI_PreLmeFloatProfit		= 5; //昨lme浮盈

static const TrdFundFieldIndexType TRD_FFI_Adjust					= 6; //资金调整
static const TrdFundFieldIndexType TRD_FFI_CashIn					= 7; //入金
static const TrdFundFieldIndexType TRD_FFI_CashOut					= 8; //出金

static const TrdFundFieldIndexType TRD_FFI_FrozenFee				= 9; //冻结手续费20
static const TrdFundFieldIndexType TRD_FFI_FrozenDeposit			= 10; //冻结保证金19
static const TrdFundFieldIndexType TRD_FFI_Fee						= 11; //手续费(包含交割手续费)
static const TrdFundFieldIndexType TRD_FFI_TradeFee					= 12; //交易手续费17
static const TrdFundFieldIndexType TRD_FFI_DeliveryFee				= 13; //交割手续费17
static const TrdFundFieldIndexType TRD_FFI_ExchangeFee				= 14; //汇兑手续费

static const TrdFundFieldIndexType TRD_FFI_PremiumIncome			= 15; //权利金收取
static const TrdFundFieldIndexType TRD_FFI_PremiumPay				= 16; //权利金支付

static const TrdFundFieldIndexType TRD_FFI_CoverProfit				= 17; //盯市平盈
static const TrdFundFieldIndexType TRD_FFI_CoverProfitTBT			= 18; //逐笔平盈 trade by trade
static const TrdFundFieldIndexType TRD_FFI_ExpProfit				= 19; //到期平盈
static const TrdFundFieldIndexType TRD_FFI_UnExpProfit				= 20; //未结平盈
static const TrdFundFieldIndexType TRD_FFI_DeliveryProfit			= 21; //交割盈亏
static const TrdFundFieldIndexType TRD_FFI_FloatProfit				= 22; //盯市浮赢(不含LME盯市浮赢)
static const TrdFundFieldIndexType TRD_FFI_LmeFloatProfit			= 23; //LME盯市浮赢
static const TrdFundFieldIndexType TRD_FFI_FloatProfitTBT			= 24; //逐笔浮赢 trade by trade

static const TrdFundFieldIndexType TRD_FFI_MarketValue				= 25; //期权市值23
static const TrdFundFieldIndexType TRD_FFI_Premium					= 26; //权利金

static const TrdFundFieldIndexType TRD_FFI_Deposit					= 27; //保证金
static const TrdFundFieldIndexType TRD_FFI_KeepDeposit				= 28; //维持保证金

static const TrdFundFieldIndexType TRD_FFI_Discount					= 29; //LME贴现
static const TrdFundFieldIndexType TRD_FFI_AuthFund					= 30; //授信资金
static const TrdFundFieldIndexType TRD_FFI_FrozenRisk				= 31; //风险冻结

static const TrdFundFieldIndexType TRD_FFI_Balance					= 32; //今资金
static const TrdFundFieldIndexType TRD_FFI_Equity					= 33; //今权益
static const TrdFundFieldIndexType TRD_FFI_Available				= 34; //今可用
static const TrdFundFieldIndexType TRD_FFI_CanCashOut				= 35; //今可提	
static const TrdFundFieldIndexType TRD_FFI_AccoutMarketValue		= 36; //账户市值			
static const TrdFundFieldIndexType TRD_FFI_OriCash					= 37; //原始出入金(非自动汇兑资金)

static const TrdFundFieldIndexType TRD_FFI_PreFundPledgedIn			= 38; //昨货币质入
static const TrdFundFieldIndexType TRD_FFI_PreFundPledgedOut		= 39; //昨货币质出
static const TrdFundFieldIndexType TRD_FFI_FundPledgedIn			= 40; //今货币质入
static const TrdFundFieldIndexType TRD_FFI_FundPledgedOut			= 41; //今货币质出
static const TrdFundFieldIndexType TRD_FFI_FundCashPledged			= 42; //货币质押余额
static const TrdFundFieldIndexType TRD_FFI_PledgedableFund			= 43; //可质押货币
static const TrdFundFieldIndexType TRD_FFI_PositionPledged			= 44; //仓单质押
static const TrdFundFieldIndexType TRD_FFI_SpecDeposit				= 45; //特殊产品保证金
static const TrdFundFieldIndexType TRD_FFI_SpecFrozenDeposit		= 46; //特殊产品冻结保证金
static const TrdFundFieldIndexType TRD_FFI_SpecFee					= 47; //特殊产品手续费
static const TrdFundFieldIndexType TRD_FFI_SpecFrozenFee			= 48; //特殊产品冻结手续费
static const TrdFundFieldIndexType TRD_FFI_SpecFloatProfit			= 49; //特殊产品浮盈
static const TrdFundFieldIndexType TRD_FFI_SpecCoverProfit			= 50; //特殊产品平盈

static const TrdFundFieldIndexType TRD_FFI_RiskRate					= 51; //风险率
static const TrdFundFieldIndexType TRD_FFI_SelfRiskRate				= 52; //自有风险率
static const TrdFundFieldIndexType TRD_FFI_NetProfit				= 53; //净盈利
static const TrdFundFieldIndexType TRD_FFI_ProfitRate				= 54; //盈利率

static const TrdFundFieldIndexType TRD_FFI_CashPledged				= 55; //质押资金
static const TrdFundFieldIndexType TRD_FFI_FieldCount				= 56; //资金可变字段总数

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//管理
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
typedef F64	 						TrdCommodityDotType;						//每手乘数(例: [5]吨/手)
typedef STR20 						TrdCommodityNameType;						//品种名称
typedef STR20 						TrdExchangeNameType;						//交易所名称
typedef F64	 						TrdExecuteDotType;							//行权乘数，期权执行时，1手期权对应的标的手数（执行价倍数）
typedef F64							TrdPriceTickType;							//最小变动价类型
typedef U16							TrdPriceDivisorType;						//报价除数(分母),默认为1
typedef F32                         TrdPriceMultipleType;						//执行价格倍数类型
typedef U32                         TrdMaxSingleOrderQtyType;					//单笔最大下单量
typedef U32                         TrdMaxPositionQtyType;						//最大持仓量
typedef F64	 						TrdTradeUnitType;							//交易单位(例: 5[吨]/手)
typedef F64	 						TrdMeasureUnitType;	 						//计量单位(例: 元/100[克])
typedef C8 							TrdPriceUnitType;							//价格单位(例: [元]/100克)
typedef U32							TrdQuoteDotType;							//报价单位乘数(例: 元/[100]克)
typedef F64							TrdPriceFactorType;							//价格换算系数

typedef SIPV6						TrdIpType;									//IP
typedef U16							TrdPortType;								//端口
typedef STR30						TrdCompanyAddressNameType;					//后台地址名称
typedef STR30						TrdCompanyApiType;							//经济公司系统类型
typedef STR30						TrdCompanyAuthInfoType;						//经济公司认证信息
typedef STR10						TrdTransportLayerProtocolType;				//传输层协议
typedef STR10 						TrdBrokerNoType;							//经纪公司编号(会员系统内部编码)
typedef U8							TrdIpCountType;								//IP地址数量

/***********************************************************************************************/
//品种类型
typedef C8 TrdCommodityTypeType;
static const TrdCommodityTypeType TRD_CT_Goods						= 'P'; //现货
static const TrdCommodityTypeType TRD_CT_Defer						= 'Y'; //现货延期
static const TrdCommodityTypeType TRD_CT_Futures					= 'F'; //期货
static const TrdCommodityTypeType TRD_CT_Option						= 'O'; //期权
static const TrdCommodityTypeType TRD_CT_SpreadMonth				= 'S'; //跨期套利
static const TrdCommodityTypeType TRD_CT_SpreadCommodity			= 'M'; //品种套利
static const TrdCommodityTypeType TRD_CT_STD						= 'D'; //跨式套利
static const TrdCommodityTypeType TRD_CT_STG						= 'G'; //宽跨式套利
static const TrdCommodityTypeType TRD_CT_PRT						= 'R'; //备兑组合
static const TrdCommodityTypeType TRD_CT_Direct						= 'X'; //外汇直接汇率 USD是基础货币
//static const TrdCommodityTypeType TRD_CT_DirectR					= 'Y'; //外汇直接汇率1 非USD是基础货币
static const TrdCommodityTypeType TRD_CT_InDirect					= 'I'; //外汇间接汇率
static const TrdCommodityTypeType TRD_CT_Cross						= 'C'; //外汇交叉汇率
static const TrdCommodityTypeType TRD_CT_IndexNumber				= 'Z'; //指数
static const TrdCommodityTypeType TRD_CT_Stocks						= 'T'; //股票

//期权类型
typedef C8 TrdOptionTypeType;               
static const TrdOptionTypeType TRD_OT_Future						= 'F'; //期货期权
static const TrdOptionTypeType TRD_OT_Stock							= 'S'; //股票期权
static const TrdOptionTypeType TRD_OT_Index							= 'I'; //指数期权
static const TrdOptionTypeType TRD_OT_Rate							= 'R'; //利率期权
static const TrdOptionTypeType TRD_OT_Currency						= 'C'; //货币期权

//期货公司系统状态
typedef C8 TrdCompanySystemStatusType;
static const TrdCompanySystemStatusType TRD_CSS_Enable				= 'E'; //正常
static const TrdCompanySystemStatusType TRD_CSS_Disable				= 'D'; //禁用
static const TrdCompanySystemStatusType TRD_CSS_Abnomal				= 'A'; //异常

//期货公司系统接入类型
typedef C8 TrdCompanyAccessTypeType;
static const TrdCompanyAccessTypeType TRD_CAT_NameServer			= 'N'; //命名服务
static const TrdCompanyAccessTypeType TRD_CAT_FrontServer			= 'F'; //前置服务
static const TrdCompanyAccessTypeType TRD_CAT_TradeServer			= 'S'; //交易服务

//价差买卖关键合约 
typedef C8 TrdSpreadDirectType;
static const TrdSpreadDirectType TRD_DF_First						= '1'; //以第一腿为准
static const TrdSpreadDirectType TRD_DF_Second						= '2'; //以第二腿为准

//平仓方式
typedef C8 TrdCoverModeType;
static const TrdCoverModeType TRD_CM_Unfinish						= 'U'; //平仓未了解
static const TrdCoverModeType TRD_CM_Cover							= 'C'; //开仓、平仓
static const TrdCoverModeType TRD_CM_CoverToday						= 'T'; //开仓、平仓、平今

//行权类型
typedef C8 TrdExcuteTypeType;
static const TrdExcuteTypeType TRD_ET_American						= '1'; //美式期权
static const TrdExcuteTypeType TRD_ET_European						= '2'; //欧式期权

//品种、合约长期有平今策略的平仓优先级
typedef C8 TrdCoverPriorityType;
static const TrdCoverPriorityType TRD_CP_Today						= 'T'; //优先平今
static const TrdCoverPriorityType TRD_CP_Previous					= 'Y'; //优先平昨
static const TrdCoverPriorityType TRD_CP_Strategy					= 'S'; //参照策略

//二次认证发送类型
typedef C8 TrdSendTypeType;
//短信
static const TrdSendTypeType               TRD_SENDTYPE_SMS                        = 'S';
//邮件
static const TrdSendTypeType               TRD_SENDTYPE_MAIL                       = 'M';
//不发送
static const TrdSendTypeType               TRD_SENDTYPE_NULL                       = 'N';
//微信
static const TrdSendTypeType               TRD_SENDTYPE_WEIXIN                     = 'W';

//二次认证发送账号类型
typedef C8 TrdSendAccountType[201];

//二次认证序列号类型
typedef C8 TrdSecondSerialIDType[5];

//二次认证有效时间类型
typedef F64	TrdEffectiveTimeType;

//用户端系统内部信息长度
typedef int TrdSystemInfoLenType;
//用户端系统内部信息
typedef C8 TrdSystemInfoType[501];
//采集信息完整度
typedef C8 TrdSystemInfoIntegrityType[301];
//信息采集标记
typedef U32 TrdSystemInfoFlag;
//appid
typedef C8 TrdAppIdType[51];

//推送信息appid
typedef C8 TrdPushAppIdType[30];
//推送信息appkey
typedef C8 TrdPushAppKeyType[30];
//推送信息app maseter secret
typedef C8 TrdPushAppMasterSecretType[30];
//推送信息 client id
typedef C8 TrdPushClientIdType[50];
//监控订单价格.手数 涨幅具体数值用|分割
typedef STR100  TrdMonitorNormValueType;
//监控订单报警原因
typedef STR30   TrdMonitorNormRtnType;
//行情预警单触发次数
typedef U16     TrdMonitorStriggerCount;

//价格监控预警次数
typedef STR100                      TrdOrderMonitorRemarkType;
typedef C8                          TrdMonitorNumType;
static const TrdMonitorNumType      TRD_MONITOR_NUM_ONE =  'O';//只监控一次
static const TrdMonitorNumType      TRD_MONITOR_NUM_CONTINUOUS = 'C';//连续监控触发
//定义是否监控
typedef U32                         TrdIsMointor;
static const  TrdIsMointor          TRD_NOT_MONITOR  = 4294967295U;//不监控

//当前订单的报警原因
typedef C8   TrdMonitorStateType;
static const TrdMonitorStateType TRD_MS_PriceMax1					= '0'; //价格上限1触发
static const TrdMonitorStateType TRD_MS_PriceMax2					= '1'; //价格上限2触发
static const TrdMonitorStateType TRD_MS_PriceMin1					= '2'; //价格下限1
static const TrdMonitorStateType TRD_MS_PriceMin2					= '3'; //价格下限2
static const TrdMonitorStateType TRD_MS_GrowthWidthMax					= '4'; //涨幅上限
static const TrdMonitorStateType TRD_MS_GrowthWidthMin					= '5'; //涨幅下限
static const TrdMonitorStateType TRD_MS_GrowthSpeedMax					= '6'; //速涨上限
static const TrdMonitorStateType TRD_MS_GrowthSpeedMin					= '7'; //速涨下限
static const TrdMonitorStateType TRD_MS_LastVol                                         = '8'; //现手
static const TrdMonitorStateType TRD_MS_Volume                                          = '9'; //成交量
static const TrdMonitorStateType TRD_MS_PositionMax					= 'A'; //持仓量上限
static const TrdMonitorStateType TRD_MS_PositionMin					= 'B'; //持仓量下限
static const TrdMonitorStateType TRD_MS_LimitUp                                         = 'C'; //涨停价
static const TrdMonitorStateType TRD_MS_LimitDown					= 'D'; //跌停价

#endif