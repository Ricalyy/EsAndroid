#ifdef __cplusplus
extern "C" {
#endif

#include <Source/StarMobileApi.h>
#include "jni.h"

JavaVM *JNI_Jvm = NULL;

jobject JNI_SrvEventFunc;

jmethodID JNI_CallBackInvoke = NULL;

jclass JNI_ByteObjectClass = NULL;
jmethodID JNI_ByteObjectInit = NULL;
jmethodID JNI_ByteObjectKey = NULL;
jmethodID JNI_ByteObjectEvent = NULL;
jmethodID JNI_ByteObjectLen = NULL;
jmethodID JNI_ByteObjectData = NULL;

//====================================JNI native===========================================================
//加载时调用
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env = NULL;

    JNI_Jvm = vm;

    if (JNI_Jvm == NULL)
        return -1;


    if ((*JNI_Jvm)->GetEnv(JNI_Jvm, (void **) &env, JNI_VERSION_1_6) != JNI_OK) {
        return -1;
    }

    //JNICallBack
    jclass callback = (*env)->FindClass(env, "com/esunny/mobile/JNICallBack");
    if (callback == NULL)
        return -1;

    JNI_CallBackInvoke = (*env)->GetMethodID(env, callback, "Invoke", "(Lcom/esunny/mobile/SByteObject;)I");
    if (JNI_CallBackInvoke == NULL)
        return -1;

    (*env)->DeleteLocalRef(env, callback);

    //SByteObject
    jclass byteObject = (*env)->FindClass(env, "com/esunny/mobile/SByteObject");
    if (byteObject == NULL)
        return -1;

    JNI_ByteObjectInit = (*env)->GetMethodID(env, byteObject, "<init>", "()V");
    if (JNI_ByteObjectInit == NULL) {
        return -1;
    }
    JNI_ByteObjectKey = (*env)->GetMethodID(env, byteObject, "setKey", "(I)V");
    if (JNI_ByteObjectKey == NULL) {
        return -1;
    }
    JNI_ByteObjectEvent = (*env)->GetMethodID(env, byteObject, "setEvent", "(C)V");
    if (JNI_ByteObjectEvent == NULL) {
        return -1;
    }
    JNI_ByteObjectLen = (*env)->GetMethodID(env, byteObject, "setLen", "(I)V");
    if (JNI_ByteObjectLen == NULL) {
        return -1;
    }

    JNI_ByteObjectData = (*env)->GetMethodID(env, byteObject, "setData", "([B)V");
    if (JNI_ByteObjectData == NULL) {
        return -1;
    }
    JNI_ByteObjectClass = (*env)->NewGlobalRef(env, byteObject);
    (*env)->DeleteLocalRef(env, byteObject);

    return JNI_VERSION_1_6;
}

JNIEnv *JNI_GetEnv(int *attach) {
    if (JNI_Jvm == NULL)
        return NULL;

    int status;

    //判断是否有AttachCurrentThread
    *attach = 0;

    JNIEnv *_jniEnv = NULL;

    status = (*JNI_Jvm)->GetEnv(JNI_Jvm, (void **) &_jniEnv, JNI_VERSION_1_6);

    if (status == JNI_EDETACHED || _jniEnv == NULL)
    {
        status = (*JNI_Jvm)->AttachCurrentThread(JNI_Jvm, &_jniEnv, NULL);
        if (status < 0) {
            _jniEnv = NULL;
        } else {
            *attach = 1;
        }
    }
    return _jniEnv;
}

int JNI_DelEnv() {
    if (JNI_Jvm == NULL)
        return -1;

    return (*JNI_Jvm)->DetachCurrentThread(JNI_Jvm);
}

jobject JNI_ByteArrayObject(JNIEnv* env, SServiceInfo *service) {
    if (JNI_ByteObjectClass == NULL) {
        return NULL;
    }

    jobject arrayObject = (*env)->NewObject(env, JNI_ByteObjectClass, JNI_ByteObjectInit);

    (*env)->CallVoidMethod(env, arrayObject, JNI_ByteObjectKey, service->Src);
    (*env)->CallVoidMethod(env, arrayObject, JNI_ByteObjectEvent, service->Event);

    int len = service->DataLen;
    if (len > 0) {
        jbyteArray array = (*env)->NewByteArray(env, len);
        (*env)->SetByteArrayRegion(env, array, 0, len, (const jbyte *) service->Data);
        (*env)->CallVoidMethod(env, arrayObject, JNI_ByteObjectData, array);
    }

    (*env)->CallVoidMethod(env, arrayObject, JNI_ByteObjectLen, len);
    return arrayObject;
}

//API中Event回调
int JNI_EventCallBack(SServiceInfo *service) {
    if (service == NULL) {
        return 0;
    }

    jint ret = 0;
    int attach = 0;
    JNIEnv *env = JNI_GetEnv(&attach);
    if (env == NULL) {
        return 0;
    }

    jobject serviceInfo = JNI_ByteArrayObject(env, service);

    if (serviceInfo != NULL) {
        ret = (*env)->CallIntMethod(env, JNI_SrvEventFunc, JNI_CallBackInvoke, serviceInfo);
    }

    if (attach == 1)
        JNI_DelEnv();

    return ret;
}

int isUTF_8(const void* pBuffer, long size)
{
    if(size <= 0)
        return 1;
    int IsUTF8 = 1;
    unsigned char* start = (unsigned char*)pBuffer;
    unsigned char* end = (unsigned char*)pBuffer + size;
    while (start < end)
    {
        if (*start < 0x80) // (10000000): 值小于0x80的为ASCII字符
        {
            start++;
        }
        else if (*start < (0xC0)) // (11000000): 值介于0x80与0xC0之间的为无效UTF-8字符
        {
            IsUTF8 = 0;
            break;
        }
        else if (*start < (0xE0)) // (11100000): 此范围内为2字节UTF-8字符
        {
            if (start >= end - 1)
                break;
            if ((start[1] & (0xC0)) != 0x80)
            {
                IsUTF8 = 0;
                break;
            }
            start += 2;
        }
        else if (*start < (0xF0)) // (11110000): 此范围内为3字节UTF-8字符
        {
            if (start >= end - 2)
                break;
            if ((start[1] & (0xC0)) != 0x80 || (start[2] & (0xC0)) != 0x80)
            {
                IsUTF8 = 0;
                break;
            }
            start += 3;
        }
        else
        {
            IsUTF8 = 0;
            break;
        }
    }
    return IsUTF8;
}

jstring toUTF_8(JNIEnv* env, const void* pBuffer)
{
    if (pBuffer == NULL) {
        return (*env)->NewStringUTF(env, "");
    }

    int size = strlen(pBuffer);
    if (size == 0) {
        return (*env)->NewStringUTF(env, "");
    }

    if (!isUTF_8(pBuffer, strlen(pBuffer))) {
        return (*env)->NewStringUTF(env, "");
    }

    return (*env)->NewStringUTF(env, pBuffer);
}

JNIEXPORT jint JNICALL
Java_com_esunny_mobile_UnixJNI_S_1Init(JNIEnv *jenv, jclass jcls, jstring jarg1) {
    C8 *arg1;
    int result;

    (void) jenv;
    (void) jcls;
    arg1 = 0;
    if (jarg1) {
        arg1 = (char *) (*jenv)->GetStringUTFChars(jenv, jarg1, 0);
        if (!arg1) return -100;
    }

    result = S_Init((char const (*)) arg1, 'A');

    if (result < 0) {
        return result;
    }

    S_Event(JNI_EventCallBack);

    return result;
}

JNIEXPORT jint JNICALL
Java_com_esunny_mobile_UnixJNI_S_1RegEvent(JNIEnv *env, jclass clazz, jobject obj) {
    if (obj == NULL)
        return 0;

    jint jresult = 1;


    if ((*env)->IsSameObject(env, JNI_SrvEventFunc, obj) == JNI_TRUE) {
        jresult = 0;
    } else {
        JNI_SrvEventFunc = (*env)->NewGlobalRef(env, obj);
    }

    return jresult;
}

JNIEXPORT jstring JNICALL
Java_com_esunny_mobile_UnixJNI_S_1GetPackageNo(JNIEnv *env, jclass clazz) {
    char* packageNo = S_GetPackageNo();
    if (NULL == packageNo) {
        return "";
    }

    return toUTF_8(env, packageNo);
}

JNIEXPORT jint JNICALL
Java_com_esunny_mobile_UnixJNI_S_1Connect(JNIEnv *env, jclass clazz, jstring addr, jint port) {
    C8 *arg1 = 0;
    if (addr) {
        arg1 = (char *) (*env)->GetStringUTFChars(env, addr, 0);
        if (!arg1) return -100;
    }

    return S_ConnectTcp(arg1, port);
}

JNIEXPORT jint JNICALL
Java_com_esunny_mobile_UnixJNI_S_1Disconnect(JNIEnv *env, jclass clazz, jint key) {
    return S_DisconnectTcp(key);
}

JNIEXPORT jint JNICALL
Java_com_esunny_mobile_UnixJNI_S_1Close(JNIEnv *env, jclass clazz, jint key) {
    return S_CloseTcp(key);
}

JNIEXPORT jint JNICALL
Java_com_esunny_mobile_UnixJNI_S_1SendMessage(JNIEnv *env, jclass clazz, jint key, jchar type,
                                              jint len, jbyteArray jarg1) {
    if (jarg1 == NULL) {
        return -1;
    }

    jbyte *buf = (*env)->GetByteArrayElements(env, jarg1, NULL);
    int ret = S_SendMessage(key, type, len, (C8 *) buf);
    if (buf != NULL) {
        (*env)->ReleaseByteArrayElements(env, jarg1, buf, 0);
    }
    return ret;
}

JNIEXPORT jint JNICALL
Java_com_esunny_mobile_UnixJNI_S_1SendAuthReq(JNIEnv *env, jclass clazz, jint key,
                                              jint language_type, jint sub_system_type) {
    return S_SendAuthReq(key, language_type, sub_system_type);
}

JNIEXPORT jboolean JNICALL
Java_com_esunny_mobile_UnixJNI_S_1IsOpenTcp(JNIEnv *env, jclass clazz, jint key) {
    return (jboolean)(S_IsOpenTcp(key) == 1);
}

JNIEXPORT jint JNICALL
Java_com_esunny_mobile_UnixJNI_S_1TcpFree(JNIEnv *env, jclass clazz, jint key) {
    return S_TcpClientFree(key);
}

#ifdef __cplusplus
}
#endif