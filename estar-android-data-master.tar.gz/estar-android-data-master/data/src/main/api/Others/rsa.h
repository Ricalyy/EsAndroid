/*
    RSAEURO.H - header file for RSAEURO cryptographic toolkit

    Copyright (c) J.S.A.Kapp 1994 - 1996.

    RSAEURO - RSA Library compatible with RSAREF(tm) 2.0.

    All functions prototypes are the Same as for RSAREF(tm).
    To aid compatibility the source and the files follow the
    same naming conventions that RSAREF(tm) uses.  This should aid
    direct importing to your applications.

    This library is legal everywhere outside the US.  And should
    NOT be imported to the US and used there.

    This header file contains prototypes, and other definitions used
    in and by RSAEURO.

    Revision history
    0.90 First revision, implements all of RSAREF.H plus some minor
    changes.

    0.91 Second revision, Fixed a couple of problems.  SHS support
    added to header file, digest contexts altered.

    0.92 Third revision, add support at this level for the assembler
    routines and the implementation of some routines using the ANSI C
    equivalent.

    0.93 Fourth revision, Library details section added, MD4 details
    added to header file, digest contexts altered.

    1.03 Fifth revision, RSA key structures altered.

    1.04 Sixth revision, New error types added, fix under windows
    regarding IDOK define. RSAEUROINFO release stuff added.

*/

#ifndef _RSA_H_
#define _RSA_H_

#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif

///////////////////////////////////////////////////////////////
/* POINTER defines a generic pointer type */
typedef unsigned char *RPTR;

/* UINT2 defines a two byte word */
typedef unsigned short int RU16;

/* UINT4 defines a four byte word */
typedef unsigned int RU32;

/* BYTE defines a unsigned character */
typedef unsigned char RU8;

/* internal signed value */
typedef signed int RI16;

//////////////////////////////////////////////////////////////////
/* RSA exponent value */
#define EXPONENT_VALUE 65537

/* RSA key lengths. */
#define MIN_RSA_MODULUS_BITS 512
/*
     PGP 2.6.2 Now allows 2048-bit keys changing below will allow this.
     It does lengthen key generation slightly if the value is increased.
*/
#define MAX_RSA_MODULUS_BITS 1024
#define MAX_RSA_MODULUS_LEN ((MAX_RSA_MODULUS_BITS + 7) / 8)
#define MAX_RSA_EXPONENT_LEN 8
#define MAX_RSA_PRIME_BITS ((MAX_RSA_MODULUS_BITS + 1) / 2)
#define MAX_RSA_PRIME_LEN ((MAX_RSA_PRIME_BITS + 7) / 8)

////////////////////////////////////////////////////////////////////////
/* Random structure. */

typedef struct RandomStruct
{
    RU32 bytesNeeded;                             /* seed bytes required */
    RU8 state[16];                                /* state of object */
    RU32 outputAvailable;                         /* number byte available */
    RU8 output[16];                               /* output bytes */
} RandomStruct;

/* RSA public and private key. */

typedef struct RsaPublicKey
{
    RU16 bits;                                    /* length in bits of modulus */
    RU8 modulus[MAX_RSA_MODULUS_LEN];             /* modulus */
    RU8 exponent[MAX_RSA_EXPONENT_LEN];           /* public exponent */
} RsaPublicKey;

typedef struct RsaPrivateKey
{
    RU16 bits;                                    /* length in bits of modulus */
    RU8 modulus[MAX_RSA_MODULUS_LEN];             /* modulus */
    RU8 publicExponent[MAX_RSA_EXPONENT_LEN];     /* public exponent */
    RU8 exponent[MAX_RSA_MODULUS_LEN];            /* private exponent */
    RU8 prime[2][MAX_RSA_PRIME_LEN];              /* prime factors */
    RU8 primeExponent[2][MAX_RSA_PRIME_LEN];      /* exponents for CRT */
    RU8 coefficient[MAX_RSA_PRIME_LEN];           /* CRT coefficient */
} RsaPrivateKey;

/* RSA prototype key. */

typedef struct RsaProtoKey
{
    RU32 bits;                                    /* length in bits of modulus */
} RsaProtoKey;

/////////////////////////////////////////////////////////////////////
/* Key-pair generation. */
int GeneratePemKeys(RsaPublicKey *pubKey, \
    RsaPrivateKey *priKey, RsaProtoKey *protoKey);

/* Key encode or decode by base64 */
int EncodePemBlock(RPTR output, RU32 *outLen, RPTR input, RU32 inLen);
int DecodePemBlock(RPTR output, RU32 *outLen, RPTR input, RU32 inLen);

/* Rsa encrypt or decrypt */
int RsaPublicEncrypt(RPTR output, RU32 *outLen, \
    RPTR input, RU32 inLen, RsaPublicKey *pubKey);

int RsaPublicDecrypt(RPTR output, RU32 *outLen, \
    RPTR input, RU32 inLen, RsaPublicKey *pubKey);

int RsaPrivateEncrypt(RPTR output, RU32 *outLen, \
    RPTR input, RU32 inLen, RsaPrivateKey *priKey);

int RsaPrivateDecrypt(RPTR output, RU32 *outLen, \
    RPTR input, RU32 inLen, RsaPrivateKey *priKey);

///////////////////////////////////////////////////////////////
/* Error codes. */

#define ID_OK                     0
#define ID_ERROR                  1

#define RE_CONTENT_ENCODING       0x0400
#define RE_DATA                   0x0401
#define RE_DIGEST_ALGORITHM       0x0402
#define RE_ENCODING               0x0403
#define RE_KEY                    0x0404
#define RE_KEY_ENCODING           0x0405
#define RE_LEN                    0x0406
#define RE_MODULUS_LEN            0x0407
#define RE_NEED_RANDOM            0x0408
#define RE_PRIVATE_KEY            0x0409
#define RE_PUBLIC_KEY             0x040A
#define RE_ENCRYPTION_ALGORITHM   0x040B
#define RE_FILE                   0x040C

/* Internal defs. */

#define TRUE    1
#define FALSE   0

#ifndef NULL_PTR
#define NULL_PTR ((POINTER)0)
#endif

#ifndef UNUSED_ARG
#define UNUSED_ARG(x) x = *(&x);
#endif

/* Standard library routines. */
#define R_memset(x, y, z) memset(x, y, z)
#define R_memcpy(x, y, z) memcpy(x, y, z)
#define R_memcmp(x, y, z) memcmp(x, y, z)

#ifdef __cplusplus
}
#endif

#endif /* _RSAEURO_H_ */
