#include <stdio.h>
#include <string.h>
#include "rsa.h"

int main(int argc, char**argv)
{
    RsaProtoKey protoKey = {1024};
    
    RsaPublicKey public_key2;
    RsaPrivateKey private_key2;
    
    //生成公钥和私钥对
    int status = GeneratePemKeys(&public_key2, &private_key2, &protoKey);
    
    if(status)
    {
        printf("Generate key error, ret = %d\n", status);
        return 1;
    }
    
    unsigned char pub_key[1024];
    unsigned char pri_key[1024];
    
    memset(pub_key, 0, sizeof(pub_key));
    memset(pri_key, 0, sizeof(pri_key));
    
    unsigned int pub_key_len = 0;
    unsigned int pri_key_len = 0;
    
    status = EncodePemBlock(pub_key, &pub_key_len, (unsigned char*)&public_key2, sizeof(public_key2));
    if(status)
    {
        printf("Encode public key error, ret = %d\n", status);
        return 1;
    }
    
    status = EncodePemBlock(pri_key, &pri_key_len, (unsigned char*)&private_key2, sizeof(private_key2));
    if(status)
    {
        printf("Encode private key error, ret = %d\n", status);
        return 1;
    }
    
    printf("pub_len = %d, pri_len=%d\n", pub_key_len, pri_key_len);
    int i = 0;
    for(i = 0; i < pub_key_len; i++)
    {
        printf("%c", pub_key[i]);
    }
    printf("\n");
    
    for(i = 0; i < pri_key_len; i++)
    {
        printf("%c", pri_key[i]);
    }
    printf("\n");
    
    //获取公钥、私钥
    RsaPublicKey  r_pub_key2;
    RsaPrivateKey r_pri_key2;
    
    unsigned int r_pub_len = 0;
    
    memset(&r_pub_key2, 0, sizeof(r_pub_key2));
    memset(&r_pri_key2, 0, sizeof(r_pri_key2));
    
    status = DecodePemBlock((unsigned char*)&r_pub_key2, &r_pub_len, pub_key, pub_key_len);
    if(status)
    {
        printf("Decode public key error, ret = %d\n", status);
        return 1;
    }
    
    if(0 != memcmp(&r_pub_key2, &public_key2, sizeof(r_pub_key2)))
    {
        printf("Public decode error!\n");
        return 1;
    }
    
    char text[21] = "0123456789ABCDEFGHIG";
    unsigned char en_text[21];
    memset(en_text, 0, sizeof(en_text));
    
    unsigned int en_text_len = 0;
    
    //对数据公钥加密、私钥解密
    status = RsaPublicEncrypt((unsigned char*)en_text, &en_text_len, (RPTR)text, sizeof(text)-1, &r_pub_key2);
    if(status)
    {
        printf("Encrypt with public key error, ret = %d\n", status);
        return 1;
    }
    
    char de_text[21];
    unsigned int de_text_len = 0;
    memset(de_text, 0, sizeof(de_text));
    
    status = RsaPrivateDecrypt((unsigned char*)de_text, &de_text_len, en_text, en_text_len, &private_key2);
    if(status)
    {
        printf("Decrypt with private key error, ret = %d\n", status);
        return 1;
    }
    
    i = 0;
    for(i = 0; i < de_text_len; i++)
    {
        printf("%c", de_text[i]);
    }
    
    printf("\n");
    
    return 0;
}