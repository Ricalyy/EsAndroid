package com.esunny.data;

import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);

        int[] array = new int[]{3,2,1};
        nextPermutation(array);
    }

    public void nextPermutation(int[] nums) {
        int start = 0, min;
        // 找到最小顺序的位置
        for(int i = nums.length - 1; i >= 1; i--) {
            if(nums[i-1] < nums[i]) {
                start = i-1;
                break;
            }
        }
//        if (start == 0) {
//            Arrays.
//        }

        // 找到最小大于nums[start]的nums[min]
        min = start + 1;
        for(int i = nums.length - 1; i >=start+1;i--) {
            if(nums[i] > nums[start] && nums[i]< nums[min]) {
                min = i;
            }
        }

        // 交换 start 和 min
        int temp;
        temp = nums[start];
        nums[start] = nums[min];
        nums[min] = temp;

        Arrays.sort(nums,start + 1, nums.length);
        for (int j = 0; j < nums.length; j++) {
            System.out.print("  " + nums[j]);
        }
    }
}