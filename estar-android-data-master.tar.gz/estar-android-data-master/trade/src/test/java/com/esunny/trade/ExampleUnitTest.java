package com.esunny.trade;

import com.esunny.trade.bean.TrdOrderRtn;

import org.junit.Test;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {

//        Field[] fields = TrdOrderRtn.class.getDeclaredFields();
//        Method[] methods = getClass().getDeclaredMethods();
//
//        List<Field> fieldList = new ArrayList<>();
//        int currentOrder = 0;
//        for (Field field : fields) {
//            if (field.getAnnotation(FieldOrder.class) != null) {
//                fieldList.add(field);
//            }
//        }
//        fieldList.sort(new Comparator<Field>() {
//            @Override
//            public int compare(Field o1, Field o2) {
//                return o1.getAnnotation(FieldOrder.class).order() - o2.getAnnotation(FieldOrder.class).order();
//            }
//        });
//
//        for (int i =0; i < fieldList.size(); i++) {
//            Field field = fieldList.get(i);
//            Class cl  = field.getType();
//            String name = field.getName();
//            int fieldOrder = field.getAnnotation(FieldOrder.class).order();
//            if (fieldOrder == currentOrder) {
//                continue;
//            }
//
//
//
//            String methodName = String.format("set%s%s", name.substring(0,1).toUpperCase(), name.substring(1));
//            Method method = getMethod(methods, methodName);
//            try {
//                method.invoke(this, "");
//            } catch (IllegalAccessException | InvocationTargetException e) {
//                e.printStackTrace();
//            }
//        }
    }

    private Method getMethod(Method[] methods, String methodName) {
        for (Method method : methods) {
            if (methodName.equals(method.getName())) {
                return method;
            }
        }
        return null;
    }
}