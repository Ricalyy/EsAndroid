package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/18
 */
public class TrdOrderModifyReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 220;

    private String CompanyNo;                                //经纪公司编号
    private String UserNo;                                    //资金帐号
    private String OrderNo;                                //委托号
    private String ContractNo;                                //合约编号

    private char OrderType;                                //定单类型
    private char OrderWay;                                //委托来源
    private char ValidType;                                //有效类型
    private String ValidTime;                                //有效日期时间(GTD情况下使用)
    private char Direct;                                    //买卖方向
    private char Offset;                                    //开仓 平仓 开平 平开(内盘)
    private char Hedge;                                    //投机保值(内盘)

    private int MinMatchQty;                            //最小成交量(内盘)
    private char MarketLevel;                            //市价撮合深度,目前只有中金所支持，取值为0、1、5(内盘)
    private char[] OrderRemark = new char[50];                            //定单备注


    private char OrderPriceType;                         //委托价格类型(指定价 最新价 挂单价 对盘价 市价 反向停板，只有指定价时委托价格字段才有效)(限策略单使用)

    private double OrderPrice;                                //委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
    private double OrderPriceOver;                            //委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)

    private int OrderQty;                                //委托数量 或 期权应价数量

    private char StrategyType;                            //策略类型(条件单，止损单、浮动止损、保本止损、止盈单)

    //价格条件1
    private double TriggerPrice;                            //触发价格
    private char TriggerMode;                            //触发模式
    private char TriggerCondition;                        //触发条件

    //时间条件
    private String TimeCondition;                          //时间条件(HH:MM:SS)

    //价格条件2
    private double TriggerPrice2;                          //触发价格2
    private char TriggerMode2;                           //触发模式2
    private char TriggerCondition2;                      //触发条件2

    //停损
    private char StopPriceType;                          //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    private double StopPrice;                              //止损止盈价或价差，具体含义由止损止盈价格类型字段决定


    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(UserNo, 21));
        buffer.put(stringToByte(OrderNo, 21));
        buffer.put(stringToByte(ContractNo, 31));
        buffer.put(charToByte(OrderType));
        buffer.put(charToByte(OrderWay));
        buffer.put(charToByte(ValidType));
        buffer.put(stringToByte(ValidTime, 21));
        buffer.put(charToByte(Direct));
        buffer.put(charToByte(Offset));
        buffer.put(charToByte(Hedge));
        buffer.putInt(MinMatchQty);
        buffer.put(charToByte(MarketLevel));

        for (int i = 0; i < OrderRemark.length; i++) {
            buffer.put(charToByte(OrderRemark[i]));
        }
        buffer.put(charToByte(OrderPriceType));

        if (OrderPrice != 0.0) {
            buffer.putDouble(OrderPrice);
        } else {
            buffer.putDouble(OrderPriceOver);
        }
        buffer.putInt(OrderQty);
        buffer.put(charToByte(StrategyType));
        buffer.putDouble(TriggerPrice);
        buffer.put(charToByte(TriggerMode));
        buffer.put(charToByte(TriggerCondition));
        buffer.put(stringToByte(TimeCondition, 11));
        buffer.putDouble(TriggerPrice2);
        buffer.put(charToByte(TriggerMode2));
        buffer.put(charToByte(TriggerCondition2));
        buffer.put(charToByte(StopPriceType));
        buffer.putDouble(StopPrice);

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getOrderType() {
        return OrderType;
    }

    public void setOrderType(char orderType) {
        OrderType = orderType;
    }

    public char getOrderWay() {
        return OrderWay;
    }

    public void setOrderWay(char orderWay) {
        OrderWay = orderWay;
    }

    public char getValidType() {
        return ValidType;
    }

    public void setValidType(char validType) {
        ValidType = validType;
    }

    public String getValidTime() {
        return ValidTime;
    }

    public void setValidTime(String validTime) {
        ValidTime = validTime;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public int getMinMatchQty() {
        return MinMatchQty;
    }

    public void setMinMatchQty(int minMatchQty) {
        MinMatchQty = minMatchQty;
    }

    public char getMarketLevel() {
        return MarketLevel;
    }

    public void setMarketLevel(char marketLevel) {
        MarketLevel = marketLevel;
    }

    public char[] getOrderRemark() {
        return OrderRemark;
    }

    public void setOrderRemark(char[] orderRemark) {
        OrderRemark = orderRemark;
    }

    public char getOrderPriceType() {
        return OrderPriceType;
    }

    public void setOrderPriceType(char orderPriceType) {
        OrderPriceType = orderPriceType;
    }

    public double getOrderPrice() {
        return OrderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        OrderPrice = orderPrice;
    }

    public double getOrderPriceOver() {
        return OrderPriceOver;
    }

    public void setOrderPriceOver(double orderPriceOver) {
        OrderPriceOver = orderPriceOver;
    }

    public int getOrderQty() {
        return OrderQty;
    }

    public void setOrderQty(int orderQty) {
        OrderQty = orderQty;
    }

    public char getStrategyType() {
        return StrategyType;
    }

    public void setStrategyType(char strategyType) {
        StrategyType = strategyType;
    }

    public double getTriggerPrice() {
        return TriggerPrice;
    }

    public void setTriggerPrice(double triggerPrice) {
        TriggerPrice = triggerPrice;
    }

    public char getTriggerMode() {
        return TriggerMode;
    }

    public void setTriggerMode(char triggerMode) {
        TriggerMode = triggerMode;
    }

    public char getTriggerCondition() {
        return TriggerCondition;
    }

    public void setTriggerCondition(char triggerCondition) {
        TriggerCondition = triggerCondition;
    }

    public String getTimeCondition() {
        return TimeCondition;
    }

    public void setTimeCondition(String timeCondition) {
        TimeCondition = timeCondition;
    }

    public double getTriggerPrice2() {
        return TriggerPrice2;
    }

    public void setTriggerPrice2(double triggerPrice2) {
        TriggerPrice2 = triggerPrice2;
    }

    public char getTriggerMode2() {
        return TriggerMode2;
    }

    public void setTriggerMode2(char triggerMode2) {
        TriggerMode2 = triggerMode2;
    }

    public char getTriggerCondition2() {
        return TriggerCondition2;
    }

    public void setTriggerCondition2(char triggerCondition2) {
        TriggerCondition2 = triggerCondition2;
    }

    public char getStopPriceType() {
        return StopPriceType;
    }

    public void setStopPriceType(char stopPriceType) {
        StopPriceType = stopPriceType;
    }

    public double getStopPrice() {
        return StopPrice;
    }

    public void setStopPrice(double stopPrice) {
        StopPrice = stopPrice;
    }
}
