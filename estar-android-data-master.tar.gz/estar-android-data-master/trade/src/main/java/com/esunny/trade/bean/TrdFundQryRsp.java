package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Peter Fu
 * @date 2020/10/28
 */
public class TrdFundQryRsp extends ApiStruct {

    private String					CompanyNo;								//经纪公司编号
    private String						UserNo;									//资金账号
    private String				CurrencyGroupNo;						//币种组编号
    private String					CurrencyNo;								//币种号
    private double					ExchangeRate;							//币种汇率

    private char				FundFieldCount;							//资金字段数目
    private List<TrdFundField> FieldData = new ArrayList<>();

    public TrdFundQryRsp() {
    }

    public TrdFundQryRsp(byte[] struct) {
        byteToBean(struct);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getCurrencyGroupNo() {
        return CurrencyGroupNo;
    }

    public void setCurrencyGroupNo(String currencyGroupNo) {
        CurrencyGroupNo = currencyGroupNo;
    }

    public String getCurrencyNo() {
        return CurrencyNo;
    }

    public void setCurrencyNo(String currencyNo) {
        CurrencyNo = currencyNo;
    }

    public double getExchangeRate() {
        return ExchangeRate;
    }

    public void setExchangeRate(double exchangeRate) {
        ExchangeRate = exchangeRate;
    }

    public char getFundFieldCount() {
        return FundFieldCount;
    }

    public void setFundFieldCount(char fundFieldCount) {
        FundFieldCount = fundFieldCount;
    }

    public List<TrdFundField> getFieldData() {
        return FieldData;
    }

    public void setFieldData(List<TrdFundField> fieldData) {
        FieldData = fieldData;
    }
}
