package com.esunny.trade.bean;

import android.util.Log;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/10/20
 */
public class CspAuthReq extends ApiStruct {
    public final static short STRUCT_LENGTH = 322;

    private int Disturb0;
    private char SubSystemType;  //子系统类型标识,填写本端子系统号，对端认证，认证失败断开连接
    private int Disturb1;
    private int Disturb2;
    private int Disturb3;
    private String RsaPubKey;      //RSA公钥
    private int Disturb4;

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.putInt(Disturb0);
        buffer.put(charToByte(SubSystemType));
        buffer.putInt(Disturb1);
        buffer.putInt(Disturb2);
        buffer.putInt(Disturb3);
        buffer.put(stringToByte(RsaPubKey, 301));
        buffer.putInt(Disturb4);

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public int getDisturb0() {
        return Disturb0;
    }

    public void setDisturb0(int disturb0) {
        Disturb0 = disturb0;
    }

    public char getSubSystemType() {
        return SubSystemType;
    }

    public void setSubSystemType(char subSystemType) {
        SubSystemType = subSystemType;
    }

    public int getDisturb1() {
        return Disturb1;
    }

    public void setDisturb1(int disturb1) {
        Disturb1 = disturb1;
    }

    public int getDisturb2() {
        return Disturb2;
    }

    public void setDisturb2(int disturb2) {
        Disturb2 = disturb2;
    }

    public int getDisturb3() {
        return Disturb3;
    }

    public void setDisturb3(int disturb3) {
        Disturb3 = disturb3;
    }

    public String getRsaPubKey() {
        return RsaPubKey;
    }

    public void setRsaPubKey(String rsaPubKey) {
        RsaPubKey = rsaPubKey;
    }

    public int getDisturb4() {
        return Disturb4;
    }

    public void setDisturb4(int disturb4) {
        Disturb4 = disturb4;
    }
}
