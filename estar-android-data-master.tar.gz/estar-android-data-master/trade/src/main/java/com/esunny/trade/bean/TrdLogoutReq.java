package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

/**
 * @author Peter Fu
 * @date 2020/10/30
 */
public class TrdLogoutReq extends ApiStruct {
    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
