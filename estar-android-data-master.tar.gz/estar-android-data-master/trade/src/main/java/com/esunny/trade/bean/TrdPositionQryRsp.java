package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/12
 */
public class TrdPositionQryRsp extends ApiStruct {

    private String CompanyNo;                                //经纪公司编号
    private String PositionNo;                                //持仓号

    private String UserNo;                                    //资金账号
    private String ContractNo;                                //合约编号
    private char Direct;                                    //买卖
    private char Hedge;                                    //投保
    private double PositionPrice;                            //持仓价
    private int PositionQty;                            //持仓量
    private int PrePositionQty;                            //昨持仓量

    private char IsCmb;                                    //是否组合持仓
    private String MatchNo;                                //成交关键字
    private String MatchDateTime;                            //成交时间

    private double ProfitCalcPrice;                        //浮盈计算价
    private double FloatProfit;                            //浮盈
    private double FloatProfitTBT;                            //逐笔浮赢 trade by trade

    private double DepositCalcPrice;                        //老仓保证金计算价（昨结算），新仓为成交价
    private double Deposit;                                //客户初始保证金
    private double KeepDeposit;                            //客户维持保证金
    private double MarketValue;                            //期权市值 = 最新价 * 持仓量 * 乘数

    private int CanCoverQty;                            //可平数量(暂未使用)
    private int FrozenQty;                            //冻结数量(暂未使用)

    private int StreamId;                                //流号

    private String SettleDate;                                //结算日期，历史持仓用

    public TrdPositionQryRsp(byte[] struct) {
        byteToBean(struct);
    }

    public static TrdPositionQryRsp toParse(byte[] struct) {
        return new TrdPositionQryRsp(struct);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setPositionNo(util.getString(51));
        setUserNo(util.getString(21));
        setContractNo(util.getString(31));
        setDirect(util.getChar());
        setHedge(util.getChar());
        setPositionPrice(util.getDouble());
        setPositionQty(util.getInt());
        setPrePositionQty(util.getInt());
        setIsCmb(util.getChar());
        setMatchNo(util.getString(21));
        setMatchDateTime(util.getString(21));
        setProfitCalcPrice(util.getDouble());
        setFloatProfit(util.getDouble());
        setFloatProfitTBT(util.getDouble());
        setDepositCalcPrice(util.getDouble());
        setDeposit(util.getDouble());
        setKeepDeposit(util.getDouble());
        setMarketValue(util.getDouble());
        setCanCoverQty(util.getInt());
        setFrozenQty(util.getInt());
        setStreamId(util.getInt());
        setSettleDate(util.getString(11));
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getPositionNo() {
        return PositionNo;
    }

    public void setPositionNo(String positionNo) {
        PositionNo = positionNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public double getPositionPrice() {
        return PositionPrice;
    }

    public void setPositionPrice(double positionPrice) {
        PositionPrice = positionPrice;
    }

    public int getPositionQty() {
        return PositionQty;
    }

    public void setPositionQty(int positionQty) {
        PositionQty = positionQty;
    }

    public int getPrePositionQty() {
        return PrePositionQty;
    }

    public void setPrePositionQty(int prePositionQty) {
        PrePositionQty = prePositionQty;
    }

    public char getIsCmb() {
        return IsCmb;
    }

    public void setIsCmb(char isCmb) {
        IsCmb = isCmb;
    }

    public String getMatchNo() {
        return MatchNo;
    }

    public void setMatchNo(String matchNo) {
        MatchNo = matchNo;
    }

    public String getMatchDateTime() {
        return MatchDateTime;
    }

    public void setMatchDateTime(String matchDateTime) {
        MatchDateTime = matchDateTime;
    }

    public double getProfitCalcPrice() {
        return ProfitCalcPrice;
    }

    public void setProfitCalcPrice(double profitCalcPrice) {
        ProfitCalcPrice = profitCalcPrice;
    }

    public double getFloatProfit() {
        return FloatProfit;
    }

    public void setFloatProfit(double floatProfit) {
        FloatProfit = floatProfit;
    }

    public double getFloatProfitTBT() {
        return FloatProfitTBT;
    }

    public void setFloatProfitTBT(double floatProfitTBT) {
        FloatProfitTBT = floatProfitTBT;
    }

    public double getDepositCalcPrice() {
        return DepositCalcPrice;
    }

    public void setDepositCalcPrice(double depositCalcPrice) {
        DepositCalcPrice = depositCalcPrice;
    }

    public double getDeposit() {
        return Deposit;
    }

    public void setDeposit(double deposit) {
        Deposit = deposit;
    }

    public double getKeepDeposit() {
        return KeepDeposit;
    }

    public void setKeepDeposit(double keepDeposit) {
        KeepDeposit = keepDeposit;
    }

    public double getMarketValue() {
        return MarketValue;
    }

    public void setMarketValue(double marketValue) {
        MarketValue = marketValue;
    }

    public int getCanCoverQty() {
        return CanCoverQty;
    }

    public void setCanCoverQty(int canCoverQty) {
        CanCoverQty = canCoverQty;
    }

    public int getFrozenQty() {
        return FrozenQty;
    }

    public void setFrozenQty(int frozenQty) {
        FrozenQty = frozenQty;
    }

    public int getStreamId() {
        return StreamId;
    }

    public void setStreamId(int streamId) {
        StreamId = streamId;
    }

    public String getSettleDate() {
        return SettleDate;
    }

    public void setSettleDate(String settleDate) {
        SettleDate = settleDate;
    }
}
