package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

/**
 * @author Peter Fu
 * @date 2020/11/4
 */
public class TrdSecondInfoReq extends ApiStruct {

    public final static int STRUCT_LENGTH = 0;

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }
}
