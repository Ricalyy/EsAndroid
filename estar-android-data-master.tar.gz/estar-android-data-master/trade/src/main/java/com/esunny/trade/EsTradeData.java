package com.esunny.trade;

import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.SPushClientInfo;
import com.esunny.trade.bean.STradeUser;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Peter Fu
 * @date 2020/10/16
 */
public class EsTradeData {

    private AddrInfo mTradeAddressInfo = new AddrInfo();

    private EsTradeData() {
    }

    private static class SingletonClassInstance {
        private static final EsTradeData INSTANCE = new EsTradeData();
    }

    public static EsTradeData getInstance() {
        return EsTradeData.SingletonClassInstance.INSTANCE;
    }

    private List<STradeUser> mTradeUserList = new ArrayList<>();

    private int clientKey;
    private Map<CallbackDispatcher, Integer> mClientMap= new ConcurrentHashMap<>();

//    private SPushClientInfo mPushClientInfo;

    public int getClientKey() {
        return clientKey;
    }

    public void setClientKey(int clientKey) {
        this.clientKey = clientKey;
    }

    public Map<CallbackDispatcher, Integer> getClientMap() {
        return mClientMap;
    }

    public List<STradeUser> getTradeUserList() {
        return mTradeUserList;
    }

    public void setTradeUserList(List<STradeUser> mTradeUserList) {
        this.mTradeUserList = mTradeUserList;
    }

    public void setTradeAddress(AddrInfo address) {
        this.mTradeAddressInfo = address;
    }

    public AddrInfo getTradeAddress () {
        return mTradeAddressInfo;
    }

}
