package com.esunny.trade.bean;

import com.esunny.data.bean.BillData;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.MatchData;
import com.esunny.data.bean.MessageData;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.PositionData;
import com.esunny.data.bean.TradeLogin;
import com.esunny.data.bean.TrdSecondCheckCodeInfo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Peter Fu
 * @date 2020/10/16
 */
public class STradeUser {
    private TradeLogin TradeLogin = new TradeLogin();                             //登录信息
    private String Password;                               //登录密码
    private String NewPass;                               //登录密码
    private String ModifyPass;                            //修改过后的密码
    private int TcpClient;                              //连接对象
    private String[] Ip = new String[2];
    private short[] Port = new short[2];
    private String[] TradeDate = new String[]{"", ""};                           //内外盘交易日
    private String[] SettleDate = new String[2];
    private short TradeState = 0;                             //客户端状态，0-启动中；1-完成登录
    //U8                          CertState;                              //二次认证状态 0 未认证 1认证成功``,,mx
    private String LoginInfo;                              //IP MAC
    char DataInitCompleted;                      // 数据初始化状态 0-未完成 1-已完成

    private String SendKey;
    private String RecvKey;

    private final Map<String, Commodity> Commoditys = new ConcurrentHashMap<>();                             //可交易品种
    private final Map<String, OrderData> OrderData = new ConcurrentHashMap<>();                              //定单数据````
    private final Map<String, OrderData> Orders = new ConcurrentHashMap<>();                                 //委托
    private final Map<String, OrderData> StrategyOrders = new ConcurrentHashMap<>();                         //策略委托
    private final Map<String, MatchData> Matches = new ConcurrentHashMap<>();                                //成交
    private Map<String, PositionData> Positions = new ConcurrentHashMap<>();                              //持仓
    private Map<String, PositionData> SumPositions = new ConcurrentHashMap<>();                           //持仓汇总
    private final Map<String, TrdFeeParamQryRsp> Fee = new ConcurrentHashMap<>();                                    //手续费
    private final Map<String, TrdDepositParamQryRsp> Deposit = new ConcurrentHashMap<>();                                //保证金
    private Map<String, TrdCurrencyQryRsp> Currency = new ConcurrentHashMap<>();                               //币种
    private Map<String, MoneyData> BaseMoney = new ConcurrentHashMap<>();                              //基币
    private Map<String, PositionData> LockPosition = new ConcurrentHashMap<>();                           //锁定数据
    private Map<String, InsertOrder> TempOrder = new ConcurrentHashMap<>();                              //缓存的下单数据
    private Map<String, InsertOrder> StrategyOpenTempOrder = new ConcurrentHashMap<>();                  //缓存止损开仓数据
    private Map<String, SASXSystemParamData> SASXData = new ConcurrentHashMap<>();                               //浮盈计算参数

    private BillData BillData;
    private int BillQrySessionId;
    private String MessageData;                   //消息；
    private MoneyData[] Money = new MoneyData[32];                              //资金
    private short MoneyIndex;                             //当前资金记录
    private MoneyData TotalMoney = new MoneyData();                             //总基币
    private TrdSecondCheckCodeInfo SecondCheckCodeInfo;                    //二次认证验证码方式

    private int SessionInex;
    private int NowSessionIndex;

    public com.esunny.data.bean.TradeLogin getTradeLogin() {
        return TradeLogin;
    }

    public void setTradeLogin(com.esunny.data.bean.TradeLogin tradeLogin) {
        TradeLogin = tradeLogin;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getNewPass() {
        return NewPass;
    }

    public void setNewPass(String newPass) {
        NewPass = newPass;
    }

    public String getModifyPass() {
        return ModifyPass;
    }

    public void setModifyPass(String modifyPass) {
        ModifyPass = modifyPass;
    }

    public int getTcpClient() {
        return TcpClient;
    }

    public void setTcpClient(int tcpClient) {
        TcpClient = tcpClient;
    }

    public String[] getIp() {
        return Ip;
    }

    public void setIp(String[] ip) {
        Ip = ip;
    }

    public short[] getPort() {
        return Port;
    }

    public void setPort(short[] port) {
        Port = port;
    }

    public String[] getTradeDate() {
        return TradeDate;
    }

    public void setTradeDate(String[] tradeDate) {
        TradeDate = tradeDate;
    }

    public String[] getSettleDate() {
        return SettleDate;
    }

    public void setSettleDate(String[] settleDate) {
        SettleDate = settleDate;
    }

    public short getTradeState() {
        return TradeState;
    }

    public void setTradeState(short tradeState) {
        TradeState = tradeState;
    }

    public String getLoginInfo() {
        return LoginInfo;
    }

    public void setLoginInfo(String loginInfo) {
        LoginInfo = loginInfo;
    }

    public char getDataInitCompleted() {
        return DataInitCompleted;
    }

    public void setDataInitCompleted(char dataInitCompleted) {
        DataInitCompleted = dataInitCompleted;
    }

    public String getSendKey() {
        return SendKey;
    }

    public void setSendKey(String sendKey) {
        SendKey = sendKey;
    }

    public String getRecvKey() {
        return RecvKey;
    }

    public void setRecvKey(String recvKey) {
        RecvKey = recvKey;
    }

    public Map<String, Commodity> getCommoditys() {
        return Commoditys;
    }

    public Map<String, OrderData> getOrderData() {
        return OrderData;
    }

    public Map<String, OrderData> getOrders() {
        return Orders;
    }

    public Map<String, OrderData> getStrategyOrders() {
        return StrategyOrders;
    }

    public Map<String, MatchData> getMatches() {
        return Matches;
    }

    public Map<String, PositionData> getPositions() {
        return Positions;
    }

    public void setPositions(Map<String, PositionData> positions) {
        Positions = positions;
    }

    public Map<String, PositionData> getSumPositions() {
        return SumPositions;
    }

    public void setSumPositions(Map<String, PositionData> sumPositions) {
        SumPositions = sumPositions;
    }

    public Map<String, TrdFeeParamQryRsp> getFee() {
        return Fee;
    }

    public Map<String, TrdDepositParamQryRsp> getDeposit() {
        return Deposit;
    }

    public Map<String, TrdCurrencyQryRsp> getCurrency() {
        return Currency;
    }

    public void setCurrency(Map<String, TrdCurrencyQryRsp> currency) {
        Currency = currency;
    }

    public Map<String, MoneyData> getBaseMoney() {
        return BaseMoney;
    }

    public Map<String, PositionData> getLockPosition() {
        return LockPosition;
    }

    public void setLockPosition(Map<String, PositionData> lockPosition) {
        LockPosition = lockPosition;
    }

    public Map<String, InsertOrder> getTempOrder() {
        return TempOrder;
    }

    public void setTempOrder(Map<String, InsertOrder> tempOrder) {
        TempOrder = tempOrder;
    }

    public Map<String, InsertOrder> getStrategyOpenTempOrder() {
        return StrategyOpenTempOrder;
    }

    public void setStrategyOpenTempOrder(Map<String, InsertOrder> strategyOpenTempOrder) {
        StrategyOpenTempOrder = strategyOpenTempOrder;
    }

    public Map<String, SASXSystemParamData> getSASXData() {
        return SASXData;
    }

    public void setSASXData(Map<String, SASXSystemParamData> SASXData) {
        this.SASXData = SASXData;
    }

    public com.esunny.data.bean.BillData getBillData() {
        return BillData;
    }

    public void setBillData(com.esunny.data.bean.BillData billData) {
        BillData = billData;
    }

    public int getBillQrySessionId() {
        return BillQrySessionId;
    }

    public void setBillQrySessionId(int billQrySessionId) {
        BillQrySessionId = billQrySessionId;
    }

    public String getMessageData() {
        return MessageData;
    }

    public void setMessageData(String messageData) {
        MessageData = messageData;
    }

    public MoneyData[] getMoney() {
        return Money;
    }

    public void setMoney(MoneyData[] money) {
        Money = money;
    }

    public short getMoneyIndex() {
        return MoneyIndex;
    }

    public void setMoneyIndex(short moneyIndex) {
        MoneyIndex = moneyIndex;
    }

    public MoneyData getTotalMoney() {
        return TotalMoney;
    }

    public void setTotalMoney(MoneyData totalMoney) {
        TotalMoney = totalMoney;
    }

    public TrdSecondCheckCodeInfo getSecondCheckCodeInfo() {
        return SecondCheckCodeInfo;
    }

    public void setSecondCheckCodeInfo(TrdSecondCheckCodeInfo secondCheckCodeInfo) {
        SecondCheckCodeInfo = secondCheckCodeInfo;
    }

    public int getSessionInex() {
        return SessionInex;
    }

    public void setSessionInex(int sessionInex) {
        SessionInex = sessionInex;
    }

    public int getNowSessionIndex() {
        return NowSessionIndex;
    }

    public void setNowSessionIndex(int nowSessionIndex) {
        NowSessionIndex = nowSessionIndex;
    }
}
