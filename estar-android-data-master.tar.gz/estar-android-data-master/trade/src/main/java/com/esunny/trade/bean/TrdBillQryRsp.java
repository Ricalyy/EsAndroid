package com.esunny.trade.bean;

/**
 * @author Peter Fu
 * @date 2020/11/18
 */
public class TrdBillQryRsp {
    private String CompanyNo;                                //经纪公司编号
    private String UserNo;                                    //资金账号
    private char BillType;                                //账单类型
    private String BillDate;                                //账单日期
    private char FormatType;                                //账单格式
    private String Content;                                //帐单内容

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public char getBillType() {
        return BillType;
    }

    public void setBillType(char billType) {
        BillType = billType;
    }

    public String getBillDate() {
        return BillDate;
    }

    public void setBillDate(String billDate) {
        BillDate = billDate;
    }

    public char getFormatType() {
        return FormatType;
    }

    public void setFormatType(char formatType) {
        FormatType = formatType;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }
}
