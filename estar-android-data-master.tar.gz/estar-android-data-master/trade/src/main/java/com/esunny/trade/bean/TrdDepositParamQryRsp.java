package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/10/19
 */
public class TrdDepositParamQryRsp extends ApiStruct {
    String CompanyNo;                                //经纪公司编号
    String UserNo;                                    //资金帐号
    String ContractNo;                                //合约编号
    char Direct;                                    //买卖方向
    char Hedge;                                    //投保 投机 套保 套利 做市(内盘)

    //所收金额 = 资产金额*比例+下单数量*定额
    double Ratio;                                    //比例
    double Amount;                                    //数额

    public TrdDepositParamQryRsp(byte[] struct) {
        byteToBean(struct);
    }

    public static TrdDepositParamQryRsp toParse(byte[] struct) {
        return new TrdDepositParamQryRsp(struct);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setUserNo(util.getString(21));
        setContractNo(util.getString(51));
        setDirect(util.getChar());
        setHedge(util.getChar());
        setRatio(util.getDouble());
        setAmount(util.getDouble());
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public double getRatio() {
        return Ratio;
    }

    public void setRatio(double ratio) {
        Ratio = ratio;
    }

    public double getAmount() {
        return Amount;
    }

    public void setAmount(double amount) {
        Amount = amount;
    }
}
