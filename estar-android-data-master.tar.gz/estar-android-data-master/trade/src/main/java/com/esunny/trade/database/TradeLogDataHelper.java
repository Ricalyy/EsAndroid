package com.esunny.trade.database;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.os.Environment;

import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.util.EstarTransformation;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.TradeLogInfo;
import com.esunny.data.database.DBManager;
import com.esunny.data.database.gen.DaoSession;
import com.esunny.data.database.gen.LogDataDao;
import com.esunny.data.database.table.LogData;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.simplethread.SimpleRunnable;
import com.esunny.data.util.simplethread.TaskManager;
import com.esunny.data.util.simplethread.TaskPriority;
import com.esunny.data.util.simplethread.ThreadType;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * @author Peter Fu
 * @date 2020/11/18
 */
public class TradeLogDataHelper {
    private static final String TAG = "TradeLogDataHelper";

    private final static String ROOT_DIR = Environment.getExternalStorageDirectory().getPath();
    private final static String TRADE_LOG_DIR = ROOT_DIR + "/Estar/TradeLog/";

    public final static String LOGIN_EVENT_STATE = "l";
    public final static String LOGOUT_EVENT_STATE = "t";
    public final static String CONNECT_EVENT_STATE = "c";
    public final static String DISCONNECT_EVENT_STATE = "d";

    private final static String SPLIT_SYMBOLS = ",";
    private final static String FILE_SUFFIX_NAME = ".txt";

    private DaoSession mDatabase;

    private static class SingletonHolder {
        private static final TradeLogDataHelper SINGLETON = new TradeLogDataHelper();
    }

    private TradeLogDataHelper() {
        Context context = EsBaseApi.getInstance().getContext();

        mDatabase = DBManager.getInstance().getDaoSession();

        SimpleRunnable simpleRunnable = new SimpleRunnable(TaskPriority.LOW) {
            @Override
            public void run() {
                checkData();
            }
        };

        TaskManager.getInstance().execute(simpleRunnable, ThreadType.SERIAL);
    }

    public static TradeLogDataHelper getInstance() {
        return SingletonHolder.SINGLETON;
    }

    public void writeTradeEvent(final String companyNo, final String userNo, final String state) {
        SimpleRunnable simpleRunnable = new SimpleRunnable(TaskPriority.LOW) {
            @Override
            public void run() {
                insertTradeEvent(companyNo, userNo, state);
            }
        };

        TaskManager.getInstance().execute(simpleRunnable, ThreadType.SERIAL);
    }

    public void writeTradeLog(final OrderData order, final boolean isFirst) {
        SimpleRunnable simpleRunnable = new SimpleRunnable(TaskPriority.LOW) {
            @Override
            public void run() {
                insertTradeLog(order, isFirst);
            }
        };

        TaskManager.getInstance().execute(simpleRunnable, ThreadType.SERIAL);
    }


    public ArrayList<TradeLogInfo> getTradeLog(String companyNo, String userNo){
        ArrayList<TradeLogInfo> logsArr = new ArrayList<>();

        // 从database中读取数据
        if (mDatabase != null) {
            DaoSession daoSession = mDatabase;
            Cursor cursor = daoSession.getLogDataDao().queryBuilder()
                    .where(LogDataDao.Properties.CompanyNo.eq(companyNo))
                    .where(LogDataDao.Properties.UserNo.eq(userNo))
                    .orderAsc(LogDataDao.Properties.Id)
                    .buildCursor().query();

            while (cursor.moveToNext()) {
                String state = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.OrderState.columnName));
                String date = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.CreateDate.columnName));
                String time = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.CreateTime.columnName));

                TradeLogInfo info = new TradeLogInfo();
                info.setDate(date);
                info.setTime(time);

                if (LOGIN_EVENT_STATE.equals(state)) {
                    info.setContractName("登录成功");
                } else if (LOGOUT_EVENT_STATE.equals(state)) {
                    info.setContractName("登出成功");
                } else if (CONNECT_EVENT_STATE.equals(state)) {
                    info.setContractName("交易连接");
                } else if (DISCONNECT_EVENT_STATE.equals(state)) {
                    info.setContractName("交易断开");
                } else if (state != null) {
                    String content = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.Content.columnName));
                    if (content != null) {
                        String type = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.OrderType.columnName));
                        String[] singleInfo = content.split(SPLIT_SYMBOLS);
                        if (singleInfo.length == 11) {
                            info.setContractNo(singleInfo[0]);
                            info.setContractName(singleInfo[1]);
                            info.setPrice(singleInfo[2]);
                            info.setInfo(singleInfo[3]);
                            info.setOrderNo(singleInfo[4]);
                            info.setOrderState(singleInfo[5]);
                            info.setQty(singleInfo[6]);
                            info.setOffset(singleInfo[7]);
                            info.setDirect(singleInfo[8]);
                            info.setErrorText(singleInfo[9]);
                            info.setErrorCode(singleInfo[10]);
                            info.setStrategyType(type);
                        } else {
                            EsLog.d(TAG, "readTradeLog: content length = " + singleInfo.length);
                        }
                    } else {
                        EsLog.d(TAG, "readTradeLog: content is null, id = " + cursor.getInt(cursor.getColumnIndex(LogDataDao.Properties.Id.columnName)));
                    }
                } else {
                    continue;
                }
                logsArr.add(info);
            }

            cursor.close();
        }
        return logsArr;
    }

    public File getTradeFiles(String companyNo, String userNo){
        String fileName = TRADE_LOG_DIR + companyNo +"_" + userNo +  "_" + "tradelog_Android" + FILE_SUFFIX_NAME;
        File file = createFile(fileName);

        if (mDatabase == null) {
            return file;
        }

        DaoSession daoSession = mDatabase;

        try (Cursor cursor = daoSession.getLogDataDao().queryBuilder()
                .where(LogDataDao.Properties.CompanyNo.eq(companyNo))
                .where(LogDataDao.Properties.UserNo.eq(userNo))
                .orderAsc(LogDataDao.Properties.Id)
                .buildCursor().query()) {
            BufferedWriter write = new BufferedWriter(new FileWriter(file, false));
            while (cursor.moveToNext()) {
                String state = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.OrderState.columnName));
                String date = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.CreateDate.columnName));
                String time = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.CreateTime.columnName));

                String info = date + "," + time + ",";
                if (LOGIN_EVENT_STATE.equals(state)) {
                    info += "登录成功" + "\n";
                } else if (LOGOUT_EVENT_STATE.equals(state)) {
                    info += "登出成功" + "\n";
                } else if (CONNECT_EVENT_STATE.equals(state)) {
                    info += "交易连接" + "\n";
                } else if (DISCONNECT_EVENT_STATE.equals(state)) {
                    info += "交易断开" + "\n";
                } else if (state != null) {
                    String content = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.Content.columnName));
                    info += content + "\n";
                } else {
                    continue;
                }
                write.write(info);
                write.flush();
            }
            write.close();
        } catch (IOException e) {
            EsLog.e(TAG, "写文件错误！！", e);
        }

        return file;
    }

    private void checkData() {
        if (mDatabase == null) {
            return;
        }
        DaoSession daoSession = mDatabase;

        try (Cursor cursor = daoSession.getLogDataDao().queryBuilder()
                .orderDesc(LogDataDao.Properties.Id)
                .buildCursor().query()) {
            while (cursor.moveToNext()) {
                String date = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.CreateDate.columnName));
                if (date == null || checkDateOut(date)) {
                    long id = cursor.getInt(cursor.getColumnIndex(LogDataDao.Properties.Id.columnName));
                    daoSession.getLogDataDao().deleteByKey(id);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void insertTradeEvent(String companyNo, String userNo, String state){
        if (mDatabase == null) {
            return;
        }
        DaoSession daoSession = mDatabase;

        Cursor cursor = daoSession.getLogDataDao().queryBuilder()
                .where(LogDataDao.Properties.CompanyNo.eq(companyNo))
                .where(LogDataDao.Properties.UserNo.eq(userNo))
                .orderDesc(LogDataDao.Properties.Id)
                .buildCursor().query();

        if (cursor.moveToNext()) {
            String s = cursor.getString(cursor.getColumnIndex(LogDataDao.Properties.OrderState.columnName));
            if (state.equals(s)) {
                cursor.close();
                return;
            }
        }

        cursor.close();

        LogData data = new LogData();
        data.setCompanyNo(companyNo);
        data.setUserNo(userNo);
        data.setOrderState(state);
        data.setCreateDate(getLocalDateTime("yyyy-MM-dd"));
        data.setCreateTime(getLocalDateTime("HH:mm:ss"));

        long ret = daoSession.getLogDataDao().insert(data);
        EsLog.v(TAG, "insertTradeEvent user no = " + userNo + ", state = " + state + ", ret = " + ret);
    }

    private void insertTradeLog(OrderData order, boolean isFirst) {
        if (mDatabase == null || order == null) {
            return;
        }
        Contract contract = EsDataApi.getQuoteContract(order.getContractNo());
        if (contract == null){
            EsLog.w(TAG, "insertTradeLog: contract is null");
            return;
        }

        BigInteger qty = order.getOrderQty();
        if (qty == null) {
            return;
        }

        String orderNo = order.getOrderNo();
        String companyNo = order.getCompanyNo();
        String userNo = order.getUserNo();
        String state = String.valueOf(order.getOrderState());
        String insertDateTime = order.getInsertDateTime();
        String updateDateTime = order.getInsertDateTime();

        String type;
        String errorText = order.getErrorText();
        if (order.getStrategyType() == 0) {
            type = "N";
        } else {
            type = "C";
        }

        String content = order.getContractNo() + SPLIT_SYMBOLS
                + contract.getContractName() + SPLIT_SYMBOLS +
                getTradeLogPrice(order) + SPLIT_SYMBOLS +
                getTradeLogInfo(order) + SPLIT_SYMBOLS +
                order.getOrderNo() + SPLIT_SYMBOLS +
                order.getOrderState() + SPLIT_SYMBOLS +
                qty.toString() + SPLIT_SYMBOLS +
                order.getOffset() + SPLIT_SYMBOLS +
                order.getDirect() + SPLIT_SYMBOLS +
                errorText + SPLIT_SYMBOLS + order.getErrorCode();

        LogData data = new LogData();
        data.setOrderNo(orderNo);
        data.setCompanyNo(companyNo);
        data.setUserNo(userNo);
        data.setOrderState(state);
        data.setInsertDate(insertDateTime);
        data.setUpdateDate(updateDateTime);
        data.setOrderType(type);
        data.setCreateDate(getLocalDateTime("yyyy-MM-dd"));
        data.setCreateTime(getLocalDateTime("HH:mm:ss"));
        data.setContent(content);

        DaoSession daoSession = mDatabase;
        Cursor cursor = daoSession.getLogDataDao().queryBuilder()
                .where(LogDataDao.Properties.CompanyNo.eq(companyNo))
                .where(LogDataDao.Properties.UserNo.eq(userNo))
                .where(LogDataDao.Properties.OrderNo.eq(orderNo))
                .where(LogDataDao.Properties.InsertDate.eq(insertDateTime))
                .orderAsc(LogDataDao.Properties.Id)
                .buildCursor().query();

        if (cursor.getCount() > 0) {
            cursor.close();
            cursor = daoSession.getLogDataDao().queryBuilder()
                    .where(LogDataDao.Properties.CompanyNo.eq(companyNo))
                    .where(LogDataDao.Properties.UserNo.eq(userNo))
                    .where(LogDataDao.Properties.OrderNo.eq(orderNo))
                    .where(LogDataDao.Properties.OrderState.eq(state))
                    .where(LogDataDao.Properties.InsertDate.eq(insertDateTime))
                    .orderAsc(LogDataDao.Properties.Id)
                    .buildCursor().query();
            if (cursor.getCount() == 0) {
                long ret = daoSession.getLogDataDao().insert(data);
                EsLog.v(TAG, "insertTradeLog insertDate = " + insertDateTime + "user no = " + userNo + ", orderNo = " + orderNo + ", state = " + state + ", ret = " + ret);
            }
            cursor.close();
            return;
        } else if (!insertDateTime.isEmpty()) {
            cursor.close();

            String date = insertDateTime.split(" ")[0];
            cursor = daoSession.getLogDataDao().queryBuilder()
                    .where(LogDataDao.Properties.CompanyNo.eq(companyNo))
                    .where(LogDataDao.Properties.UserNo.eq(userNo))
                    .where(LogDataDao.Properties.OrderNo.eq(orderNo))
                    .where(LogDataDao.Properties.CreateDate.eq(date))
                    .orderAsc(LogDataDao.Properties.Id)
                    .buildCursor().query();
            if (cursor.getCount() > 0) {
                cursor.close();
                cursor = daoSession.getLogDataDao().queryBuilder()
                        .where(LogDataDao.Properties.CompanyNo.eq(companyNo))
                        .where(LogDataDao.Properties.UserNo.eq(userNo))
                        .where(LogDataDao.Properties.OrderNo.eq(orderNo))
                        .where(LogDataDao.Properties.OrderState.eq(state))
                        .where(LogDataDao.Properties.CreateDate.eq(date))
                        .orderAsc(LogDataDao.Properties.Id)
                        .buildCursor().query();
                if (cursor.getCount() == 0) {
                    long ret = daoSession.getLogDataDao().insert(data);
                    EsLog.v(TAG, "insertTradeLog date " + date + "user no = " + userNo + ", orderNo = " + orderNo + ", state = " + state + ", ret = " + ret);
                }
                cursor.close();
            }
        }

        if (isFirst) {
            long ret = daoSession.getLogDataDao().insert(data);
            EsLog.v(TAG, "first insertTradeLog user no = " + userNo + ", state = " + state + ", ret = " + ret);
        }
    }

    private File createFile(String fileName) {
        File file = new File(fileName);
        if(!file.exists()){
            try {
                boolean result = file.createNewFile();

                EsLog.d(TAG,"create file " + fileName + ", result = " + result);
            } catch (IOException e) {
                EsLog.e(TAG,"写文件错误！！", e);
            }
        }
        return file;
    }

    private String getTradeLogPrice(OrderData data){
        String price;
        Contract contract = EsDataApi.getQuoteContract(data.getContractNo());
        if(data.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTFILLED ||
                data.getOrderState() == EsDataConstant.S_ORDERSTATE_FILLED){
            price = EsDataApi.formatPrice(contract.getCommodity(), data.getMatchPrice(), false);
        }else{
            price = EsDataApi.formatPrice(contract.getCommodity(), data.getOrderPrice(), false);
        }
        return price;
    }

    private String getTradeLogInfo(OrderData data){
        Context context = EsBaseApi.getInstance().getContext();

        String price = getTradeLogPrice(data);
        String state = EstarTransformation.OrderState2String(context, data.getOrderState(), data.getOrderType());
        if(data.getOrderState() == EsDataConstant.S_ORDERSTATE_FAIL){
            state += " " + data.getErrorText();
        }
        return EstarTransformation.Direct2BuySellString(context, data.getDirect()) +
                EstarTransformation.Offset2String(context, data.getOffset()) +
                (data.getOrderQty() == null ? 0 : data.getOrderQty().toString())
                + "手 " + price +  " 委托状态:" + state;
    }

    private String getLocalDateTime(String patten){
        @SuppressLint("SimpleDateFormat")
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(patten);// HH:mm:ss
        Date date = new Date(System.currentTimeMillis());
        return simpleDateFormat.format(date);
    }

    private boolean checkDateOut(String dateString) {
        if (dateString == null) {
            return false;
        }

        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, -7);
        Date dateDelay = calendar.getTime();

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date;
        try {
            date = dateFormat.parse(dateString);
        } catch (ParseException e) {
            return true;
        }

        return date.before(dateDelay);
    }
}
