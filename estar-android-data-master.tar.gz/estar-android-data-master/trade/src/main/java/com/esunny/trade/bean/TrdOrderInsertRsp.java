package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/5
 */
public class TrdOrderInsertRsp extends ApiStruct {

    private String CompanyNo;                                //经纪公司编号
    private String UserNo;                                    //资金帐号
    private String OrderNo;                                //委托号，可能为空
    private String InsertNo;                                //下单人
    private String InsertDateTime;                            //下单时间
    private char OrderState;                                //委托状态
    private String ErrorText;                                //错误信息，CTP错误号是0却仍然会有错误信息

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //新增字段2017-11-06
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private int ErrorCode;                                //错误编号
    private char StrategyType;                            //策略类型(条件单，止损单、浮动止损、保本止损、止盈单)
    private String SessionNo;                                //会话标识
    private int OrderReqId;                                //报单请求号，相当于原来包头上的SessionId
    private String ParentNo;                                //父单委托号，可能为空
    private String OrderRef;                                //报单引用
    private char AutoCloseFlag;                          //自对冲标记

    public TrdOrderInsertRsp() {
    }

    public TrdOrderInsertRsp(byte[] buf) {
        byteToBean(buf);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setUserNo(util.getString(21));
        setOrderNo(util.getString(21));
        setInsertNo(util.getString(21));
        setInsertDateTime(util.getString(21));
        setOrderState(util.getChar());
        setErrorText(util.getString(201));

        setErrorCode(util.getInt());
        setStrategyType(util.getChar());
        setSessionNo(util.getString(41));
        setOrderReqId(util.getInt());
        setParentNo(util.getString(21));
        setOrderRef(util.getString(21));
        setAutoCloseFlag(util.getChar());
    }

    public static TrdOrderInsertRsp toParse(byte[] buf) {
        return new TrdOrderInsertRsp(buf);
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getInsertNo() {
        return InsertNo;
    }

    public void setInsertNo(String insertNo) {
        InsertNo = insertNo;
    }

    public String getInsertDateTime() {
        return InsertDateTime;
    }

    public void setInsertDateTime(String insertDateTime) {
        InsertDateTime = insertDateTime;
    }

    public char getOrderState() {
        return OrderState;
    }

    public void setOrderState(char orderState) {
        OrderState = orderState;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public char getStrategyType() {
        return StrategyType;
    }

    public void setStrategyType(char strategyType) {
        StrategyType = strategyType;
    }

    public String getSessionNo() {
        return SessionNo;
    }

    public void setSessionNo(String sessionNo) {
        SessionNo = sessionNo;
    }

    public int getOrderReqId() {
        return OrderReqId;
    }

    public void setOrderReqId(int orderReqId) {
        OrderReqId = orderReqId;
    }

    public String getParentNo() {
        return ParentNo;
    }

    public void setParentNo(String parentNo) {
        ParentNo = parentNo;
    }

    public String getOrderRef() {
        return OrderRef;
    }

    public void setOrderRef(String orderRef) {
        OrderRef = orderRef;
    }

    public char getAutoCloseFlag() {
        return AutoCloseFlag;
    }

    public void setAutoCloseFlag(char autoCloseFlag) {
        AutoCloseFlag = autoCloseFlag;
    }
}
