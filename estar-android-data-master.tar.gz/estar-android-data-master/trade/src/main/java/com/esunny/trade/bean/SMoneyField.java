package com.esunny.trade.bean;

/**
 * @author Peter Fu
 * @date 2020/10/28
 */
public class SMoneyField {
    private short Index;
    private double Value;

    public short getIndex() {
        return Index;
    }

    public void setIndex(short index) {
        Index = index;
    }

    public double getValue() {
        return Value;
    }

    public void setValue(double value) {
        Value = value;
    }
}
