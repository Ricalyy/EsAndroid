package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/10/28
 */
public class TrdBillConfirmStatusQryRsp extends ApiStruct {

    public final static short STRUCT_LENGTH = 44;

    private String					CompanyNo;								//经纪公司编号
    private String						UserNo;									//资金账号
    private String							BillDate;								//账单日期
    private char							Confirmed;								//是否已经确认

    public TrdBillConfirmStatusQryRsp(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setUserNo(util.getString(21));
        setBillDate(util.getString(11));
        setConfirmed(util.getChar());
    }

    public static TrdBillConfirmStatusQryRsp toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new TrdBillConfirmStatusQryRsp(data);
        } else {
            return null;
        }
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getBillDate() {
        return BillDate;
    }

    public void setBillDate(String billDate) {
        BillDate = billDate;
    }

    public char getConfirmed() {
        return Confirmed;
    }

    public void setConfirmed(char confirmed) {
        Confirmed = confirmed;
    }
}
