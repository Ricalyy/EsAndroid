package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * 手续费参数查询请求
 * @author Peter Fu
 * @date 2020/11/3
 */
public class TrdFeeParamQryReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 84;

    private String CompanyNo;                                //经纪公司编号
    private String UserNo;                                    //资金帐号
    private String ContractNo;                                //合约编号
    private char Offset;                                    //开仓 平仓 平今(内盘)

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(UserNo, 21));
        buffer.put(stringToByte(ContractNo, 51));
        buffer.put(charToByte(Offset));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }
}
