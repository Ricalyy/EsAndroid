package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/10/19
 */
public class TrdFeeParamQryRsp extends ApiStruct {
    String					CompanyNo;								//经纪公司编号
    String						UserNo;									//资金帐号
    String 					ContractNo;								//合约编号
    char						Offset;									//开仓 平仓 平今(内盘)

    //所收金额 = 资产金额*比例+下单数量*定额
    double						Ratio;									//比例
    double							Amount;									//数额

    public TrdFeeParamQryRsp(byte[] struct) {
        byteToBean(struct);
    }

    public static TrdFeeParamQryRsp toParse(byte[] struct) {
        return new TrdFeeParamQryRsp(struct);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setContractNo(util.getString(51));
        setOffset(util.getChar());
        setRatio(util.getDouble());
        setAmount(util.getDouble());
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public double getRatio() {
        return Ratio;
    }

    public void setRatio(double ratio) {
        Ratio = ratio;
    }

    public double getAmount() {
        return Amount;
    }

    public void setAmount(double amount) {
        Amount = amount;
    }
}
