package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/12
 */
public class TrdMatchRtn extends ApiStruct {

    private String					CompanyNo;								//经纪公司编号
    private String						MatchNo;								//成交号

    private String						UserNo;									//资金帐号
    private String				ContractNo;								//合约编号
    private char						Direct;									//买卖
    private char						Offset;									//开仓 平仓 开平 平开(内盘)
    private char						Hedge;									//投机保值 投保 保投(内盘)
    private double						MatchPrice;								//成交价格
    private int						MatchQty;								//成交数量
    private char							MatchWay;								//成交来源
    private double						CoverPrice;								//平仓指定价格(外盘指定价格平仓)

    private String							MatchDateTime;							//成交时间
    private String							OrderNo;								//委托号

    private String						FeeCurrencyNo;							//手续费币种
    private double							MatchFee;								//成交手续费
    private double								Premium;								//权利金收支，收入为正，支出为负 = 成交价 * 成交量 * 乘数

    private char							ManualFee;								//手工手续费(外盘)
    private char							AddOne;									//T+1标记(外盘)

    private int							StreamId;								//流号

    private String							SettleDate;								//结算日期，历史成交用
    private char                         IsDeleted;                              //委托是否删除标志

    public TrdMatchRtn(byte[] struct) {
        byteToBean(struct);
    }

    public static TrdMatchRtn toParse(byte[] struct) {
        return new TrdMatchRtn(struct);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setMatchNo(util.getString(21));
        setUserNo(util.getString(21));
        setContractNo(util.getString(31));
        setDirect(util.getChar());
        setOffset(util.getChar());
        setHedge(util.getChar());
        setMatchPrice(util.getDouble());
        setMatchQty(util.getInt());
        setMatchWay(util.getChar());
        setCoverPrice(util.getDouble());
        setMatchDateTime(util.getString(21));
        setOrderNo(util.getString(21));
        setFeeCurrencyNo(util.getString(11));
        setMatchFee(util.getDouble());
        setPremium(util.getDouble());
        setManualFee(util.getChar());
        setAddOne(util.getChar());
        setStreamId(util.getInt());
        setSettleDate(util.getString(11));
        setIsDeleted(util.getChar());
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getMatchNo() {
        return MatchNo;
    }

    public void setMatchNo(String matchNo) {
        MatchNo = matchNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public double getMatchPrice() {
        return MatchPrice;
    }

    public void setMatchPrice(double matchPrice) {
        MatchPrice = matchPrice;
    }

    public int getMatchQty() {
        return MatchQty;
    }

    public void setMatchQty(int matchQty) {
        MatchQty = matchQty;
    }

    public char getMatchWay() {
        return MatchWay;
    }

    public void setMatchWay(char matchWay) {
        MatchWay = matchWay;
    }

    public double getCoverPrice() {
        return CoverPrice;
    }

    public void setCoverPrice(double coverPrice) {
        CoverPrice = coverPrice;
    }

    public String getMatchDateTime() {
        return MatchDateTime;
    }

    public void setMatchDateTime(String matchDateTime) {
        MatchDateTime = matchDateTime;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getFeeCurrencyNo() {
        return FeeCurrencyNo;
    }

    public void setFeeCurrencyNo(String feeCurrencyNo) {
        FeeCurrencyNo = feeCurrencyNo;
    }

    public double getMatchFee() {
        return MatchFee;
    }

    public void setMatchFee(double matchFee) {
        MatchFee = matchFee;
    }

    public double getPremium() {
        return Premium;
    }

    public void setPremium(double premium) {
        Premium = premium;
    }

    public char getManualFee() {
        return ManualFee;
    }

    public void setManualFee(char manualFee) {
        ManualFee = manualFee;
    }

    public char getAddOne() {
        return AddOne;
    }

    public void setAddOne(char addOne) {
        AddOne = addOne;
    }

    public int getStreamId() {
        return StreamId;
    }

    public void setStreamId(int streamId) {
        StreamId = streamId;
    }

    public String getSettleDate() {
        return SettleDate;
    }

    public void setSettleDate(String settleDate) {
        SettleDate = settleDate;
    }

    public char getIsDeleted() {
        return IsDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        IsDeleted = isDeleted;
    }
}
