package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/10/23
 */
public class TrdLoginRsp extends ApiStruct {

    public final static short STRUCT_LENGTH = 655;

    private String CompanyNo;                                //经纪公司编号
    private String CompanyAddressNo;                        //登录地址编号
    private String LoginNo;                                //登录账号
    private char TerminalType;                            //终端类型
    private String AppCode;                                //客户端软件标识码

    private String LoginName;                                //登录帐号名称
    private String LastLoginInfo;                            //上次登录信息, 机器地址、登录和退出时间等
    private String TradeDate;                                //当前交易日
    private String LastSettleTime;                            //最后结算日
    private String StartTime;                                //会员系统启动时间
    private String InitTime;                                //会员系统初始化时间

    private char ForceChgPsw;                            //是否需要强制修改密码
    private String SessionNo;                                //会话编号

    private String CompanyApi;                                //经纪公司系统类型

    private String ErrorText;                               //错误信息

    private TrdLoginRsp(byte[] array) {
        byteToBean(array);
    }

    public static TrdLoginRsp toParse(byte[] array) {
        return new TrdLoginRsp(array);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        CompanyNo = util.getString(11);
        CompanyAddressNo = util.getString(21);
        LoginNo = util.getString(21);
        TerminalType = util.getChar();
        AppCode = util.getString(21);

        LoginName = util.getString(31);
        LastLoginInfo = util.getString(201);
        TradeDate = util.getString(11);
        LastSettleTime = util.getString(21);
        StartTime = util.getString(21);
        InitTime = util.getString(21);

        ForceChgPsw = util.getChar();
        SessionNo = util.getString(41);
        CompanyApi = util.getString(31);
        ErrorText = util.getString(201);
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getCompanyAddressNo() {
        return CompanyAddressNo;
    }

    public void setCompanyAddressNo(String companyAddressNo) {
        CompanyAddressNo = companyAddressNo;
    }

    public String getLoginNo() {
        return LoginNo;
    }

    public void setLoginNo(String loginNo) {
        LoginNo = loginNo;
    }

    public char getTerminalType() {
        return TerminalType;
    }

    public void setTerminalType(char terminalType) {
        TerminalType = terminalType;
    }

    public String getAppCode() {
        return AppCode;
    }

    public void setAppCode(String appCode) {
        AppCode = appCode;
    }

    public String getLoginName() {
        return LoginName;
    }

    public void setLoginName(String loginName) {
        LoginName = loginName;
    }

    public String getLastLoginInfo() {
        return LastLoginInfo;
    }

    public void setLastLoginInfo(String lastLoginInfo) {
        LastLoginInfo = lastLoginInfo;
    }

    public String getTradeDate() {
        return TradeDate;
    }

    public void setTradeDate(String tradeDate) {
        TradeDate = tradeDate;
    }

    public String getLastSettleTime() {
        return LastSettleTime;
    }

    public void setLastSettleTime(String lastSettleTime) {
        LastSettleTime = lastSettleTime;
    }

    public String getStartTime() {
        return StartTime;
    }

    public void setStartTime(String startTime) {
        StartTime = startTime;
    }

    public String getInitTime() {
        return InitTime;
    }

    public void setInitTime(String initTime) {
        InitTime = initTime;
    }

    public char getForceChgPsw() {
        return ForceChgPsw;
    }

    public void setForceChgPsw(char forceChgPsw) {
        ForceChgPsw = forceChgPsw;
    }

    public String getSessionNo() {
        return SessionNo;
    }

    public void setSessionNo(String sessionNo) {
        SessionNo = sessionNo;
    }

    public String getCompanyApi() {
        return CompanyApi;
    }

    public void setCompanyApi(String companyApi) {
        CompanyApi = companyApi;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }
}
