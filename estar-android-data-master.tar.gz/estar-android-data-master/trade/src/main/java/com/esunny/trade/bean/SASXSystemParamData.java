package com.esunny.trade.bean;

/**
 * @author Peter Fu
 * @date 2020/10/19
 */
public class SASXSystemParamData {
    String             ItemNo;                 //项目标号
    String        CommodityNo;            //品种编号
    int          ItemValue;              //周期数-c
    int          ItemNum;                //计息次数-Num
    double    ItemValueDouble;        //周期利率-Ratio

    public String getItemNo() {
        return ItemNo;
    }

    public void setItemNo(String itemNo) {
        ItemNo = itemNo;
    }

    public String getCommodityNo() {
        return CommodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        CommodityNo = commodityNo;
    }

    public int getItemValue() {
        return ItemValue;
    }

    public void setItemValue(int itemValue) {
        ItemValue = itemValue;
    }

    public int getItemNum() {
        return ItemNum;
    }

    public void setItemNum(int itemNum) {
        ItemNum = itemNum;
    }

    public double getItemValueDouble() {
        return ItemValueDouble;
    }

    public void setItemValueDouble(double itemValueDouble) {
        ItemValueDouble = itemValueDouble;
    }
}
