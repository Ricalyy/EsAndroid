package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * @author Peter Fu
 * @date 2020/11/11
 * <p>
 * //定单通知(外盘录单，定单修改通知)
 * //key = CompanyNo + OrderNo
 * //key = ContractNo(ExchangeNo) + SeatNo + LocalNo
 * //key = ContractNo(ExchangeNo) + SystemNo
 */

public class TrdOrderRtn extends ApiStruct {

    private String CompanyNo;                                //经纪公司编号

    private String UserNo;                                    //资金帐号

    private String ContractNo;                                //合约编号

    private char OrderType;                                //定单类型

    private char OrderWay;                                //委托来源
    private char ValidType;                                //有效类型

    private String ValidTime;                                //有效日期时间(GTD情况下使用)

    private char IsRiskOrder;                            //风险报单
    private char Direct;                                    //买卖方向
    private char Offset;                                    //开仓 平仓 开平 平开(内盘)
    private char Hedge;                                    //投机保值 投保 保投(内盘)

    private double OrderPrice;                                //委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
    private double OrderPriceOver;                            //委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)

    private int OrderQty;                                //委托数量 或 期权应价数量

    private double TriggerPrice;                            //触发价格
    private char TriggerMode;                            //触发模式
    private char TriggerCondition;                        //触发条件

    private int MinMatchQty;                            //最小成交量(内盘)

    private int MinOrderQty;                            //冰山单最小随机量(外盘)
    private int MaxOrderQty;                            //冰山单最大随机量(外盘)

    private char StrategyType;                            //策略类型

    private char MarketLevel;                            //市价撮合深度,目前只有中金所支持，取值为0、1、5(内盘)

    private char SellOffset;                                //应价卖出开平
    private double SellOrderPrice;                            //应价卖出价格
    private int SellOrderQty;                            //应价卖出委托数量
    private char SellHedge;                                //应价卖出投保方向
    private String EnquiryNo;                                //询价请求号，应价时用(内盘)

    private char[] OrderRemark = new char[50];                            //定单备注

    private String ParentNo;                                //父单号
    private int OcoId;                                    //OCO编号

    /**************************************************************************************************/
    private String OrderNo;                                //委托号
    private String LocalNo;                                //本地号
    private String SystemNo;                                //系统号
    private String SeatNo;                                    //席位号

    private String InsertNo;                                //下单人
    private String InsertDateTime;                            //下单时间
    private String UpdateNo;                                //最后一次变更人
    private String UpdateDateTime;                            //最后一次变更时间

    private double MatchPrice;                                //成交价
    private int MatchQty;                                //成交量
    private char OrderState;                                //委托状态

    private double SellMatchPrice;                            //应价卖出成交价
    private int SellMatchQty;                            //应价卖出成交量

    private char AddOne;                                    //T+1(外盘)

    private int ErrorCode;                                //错误码
    private String ErrorText;                                //错误信息
    private int StreamId;                                //委托流号

    private String InsertTradeDate;                        //下单交易日

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //云端策略单新增字段2017-11-06
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private int OrderReqId;                                //报单请求号，相当于原来包头上的SessionId
    private int ParentReqId;                            //父单请求号

    private char OrderPriceType;                         //委托价格类型(指定价 最新价 挂单价 对盘价 市价价，只有指定价时委托价格字段才有效)(限策略单使用)

    //时间条件
    private String TimeCondition;                          //时间条件(HH:MM:SS)

    //价格条件2
    private double TriggerPrice2;                          //触发价格2
    private char TriggerMode2;                           //触发模式2
    private char TriggerCondition2;                      //触发条件2

    //停损
    private char StopPriceType;                          //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    private double StopPrice;                              //止损止盈价或价差，具体含义由止损止盈价格类型字段决定

    private String SessionNo;                                //会话编号
    private String OrderRef;                                //报单引用

    private String UpdateTradeDate;                        //更新交易日
    private char AutoCloseFlag;                          //自对冲标记
    private char IsDeleted;                              //委托是否删除标志

    private String StParentNo;                             // 条件单父单

    public TrdOrderRtn(byte[] struct) {
        byteToBean(struct);
    }

    public static TrdOrderRtn toParse(byte[] struct) {
        return new TrdOrderRtn(struct);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setUserNo(util.getString(21));
        setContractNo(util.getString(51));
        setOrderType(util.getChar());
        setOrderWay(util.getChar());
        setValidType(util.getChar());
        setValidTime(util.getString(21));
        setIsRiskOrder(util.getChar());
        setDirect(util.getChar());
        setOffset(util.getChar());
        setHedge(util.getChar());
        setOrderPrice(util.getDouble());
        setOrderPriceOver(getOrderPrice());
        setOrderQty(util.getInt());
        setTriggerPrice(util.getDouble());
        setTriggerMode(util.getChar());
        setTriggerCondition(util.getChar());
        setMinMatchQty(util.getInt());
        setMinOrderQty(util.getInt());
        setMaxOrderQty(util.getInt());
        setStrategyType(util.getChar());
        setMarketLevel(util.getChar());
        setSellOffset(util.getChar());
        setSellOrderPrice(util.getDouble());
        setSellOrderQty(util.getInt());
        setSellHedge(util.getChar());
        setEnquiryNo(util.getString(21));
        for (int i =0; i< 50; i++) {
            OrderRemark[i] = util.getChar();
        }
        setParentNo(util.getString(21));
        setOcoId(util.getInt());
        setOrderNo(util.getString(21));
        setLocalNo(util.getString(21));
        setSystemNo(util.getString(51));
        setSeatNo(util.getString(11));
        setInsertNo(util.getString(21));
        setInsertDateTime(util.getString(21));
        setUpdateNo(util.getString(21));
        setUpdateDateTime(util.getString(21));
        setMatchPrice(util.getDouble());
        setMatchQty(util.getInt());
        setOrderState(util.getChar());
        setSellMatchPrice(util.getDouble());
        setSellMatchQty(util.getInt());
        setAddOne(util.getChar());
        setErrorCode(util.getInt());
        setErrorText(util.getString(201));
        setStreamId(util.getInt());
        setInsertTradeDate(util.getString(11));
        setOrderReqId(util.getInt());
        setParentReqId(util.getInt());
        setOrderPriceType(util.getChar());
        setTimeCondition(util.getString(11));
        setTriggerPrice2(util.getDouble());
        setTriggerMode2(util.getChar());
        setTriggerCondition2(util.getChar());
        setStopPriceType(util.getChar());
        setStopPrice(util.getDouble());
        setSessionNo(util.getString(41));
        setOrderRef(util.getString(21));
        setUpdateTradeDate(util.getString(11));
        setAutoCloseFlag(util.getChar());
        setIsDeleted(util.getChar());
        setStParentNo(util.getString(21));
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getOrderType() {
        return OrderType;
    }

    public void setOrderType(char orderType) {
        OrderType = orderType;
    }

    public char getOrderWay() {
        return OrderWay;
    }

    public void setOrderWay(char orderWay) {
        OrderWay = orderWay;
    }

    public char getValidType() {
        return ValidType;
    }

    public void setValidType(char validType) {
        ValidType = validType;
    }

    public String getValidTime() {
        return ValidTime;
    }

    public void setValidTime(String validTime) {
        ValidTime = validTime;
    }

    public char getIsRiskOrder() {
        return IsRiskOrder;
    }

    public void setIsRiskOrder(char isRiskOrder) {
        IsRiskOrder = isRiskOrder;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public double getOrderPrice() {
        return OrderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        OrderPrice = orderPrice;
    }

    public double getOrderPriceOver() {
        return OrderPriceOver;
    }

    public void setOrderPriceOver(double orderPriceOver) {
        OrderPriceOver = orderPriceOver;
    }

    public int getOrderQty() {
        return OrderQty;
    }

    public void setOrderQty(int orderQty) {
        OrderQty = orderQty;
    }

    public double getTriggerPrice() {
        return TriggerPrice;
    }

    public void setTriggerPrice(double triggerPrice) {
        TriggerPrice = triggerPrice;
    }

    public char getTriggerMode() {
        return TriggerMode;
    }

    public void setTriggerMode(char triggerMode) {
        TriggerMode = triggerMode;
    }

    public char getTriggerCondition() {
        return TriggerCondition;
    }

    public void setTriggerCondition(char triggerCondition) {
        TriggerCondition = triggerCondition;
    }

    public int getMinMatchQty() {
        return MinMatchQty;
    }

    public void setMinMatchQty(int minMatchQty) {
        MinMatchQty = minMatchQty;
    }

    public int getMinOrderQty() {
        return MinOrderQty;
    }

    public void setMinOrderQty(int minOrderQty) {
        MinOrderQty = minOrderQty;
    }

    public int getMaxOrderQty() {
        return MaxOrderQty;
    }

    public void setMaxOrderQty(int maxOrderQty) {
        MaxOrderQty = maxOrderQty;
    }

    public char getStrategyType() {
        return StrategyType;
    }

    public void setStrategyType(char strategyType) {
        StrategyType = strategyType;
    }

    public char getMarketLevel() {
        return MarketLevel;
    }

    public void setMarketLevel(char marketLevel) {
        MarketLevel = marketLevel;
    }

    public char getSellOffset() {
        return SellOffset;
    }

    public void setSellOffset(char sellOffset) {
        SellOffset = sellOffset;
    }

    public double getSellOrderPrice() {
        return SellOrderPrice;
    }

    public void setSellOrderPrice(double sellOrderPrice) {
        SellOrderPrice = sellOrderPrice;
    }

    public int getSellOrderQty() {
        return SellOrderQty;
    }

    public void setSellOrderQty(int sellOrderQty) {
        SellOrderQty = sellOrderQty;
    }

    public char getSellHedge() {
        return SellHedge;
    }

    public void setSellHedge(char sellHedge) {
        SellHedge = sellHedge;
    }

    public String getEnquiryNo() {
        return EnquiryNo;
    }

    public void setEnquiryNo(String enquiryNo) {
        EnquiryNo = enquiryNo;
    }

    public char[] getOrderRemark() {
        return OrderRemark;
    }

    public void setOrderRemark(char[] orderRemark) {
        OrderRemark = orderRemark;
    }

    public String getParentNo() {
        return ParentNo;
    }

    public void setParentNo(String parentNo) {
        ParentNo = parentNo;
    }

    public int getOcoId() {
        return OcoId;
    }

    public void setOcoId(int ocoId) {
        OcoId = ocoId;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getLocalNo() {
        return LocalNo;
    }

    public void setLocalNo(String localNo) {
        LocalNo = localNo;
    }

    public String getSystemNo() {
        return SystemNo;
    }

    public void setSystemNo(String systemNo) {
        SystemNo = systemNo;
    }

    public String getSeatNo() {
        return SeatNo;
    }

    public void setSeatNo(String seatNo) {
        SeatNo = seatNo;
    }

    public String getInsertNo() {
        return InsertNo;
    }

    public void setInsertNo(String insertNo) {
        InsertNo = insertNo;
    }

    public String getInsertDateTime() {
        return InsertDateTime;
    }

    public void setInsertDateTime(String insertDateTime) {
        InsertDateTime = insertDateTime;
    }

    public String getUpdateNo() {
        return UpdateNo;
    }

    public void setUpdateNo(String updateNo) {
        UpdateNo = updateNo;
    }

    public String getUpdateDateTime() {
        return UpdateDateTime;
    }

    public void setUpdateDateTime(String updateDateTime) {
        UpdateDateTime = updateDateTime;
    }

    public double getMatchPrice() {
        return MatchPrice;
    }

    public void setMatchPrice(double matchPrice) {
        MatchPrice = matchPrice;
    }

    public int getMatchQty() {
        return MatchQty;
    }

    public void setMatchQty(int matchQty) {
        MatchQty = matchQty;
    }

    public char getOrderState() {
        return OrderState;
    }

    public void setOrderState(char orderState) {
        OrderState = orderState;
    }

    public double getSellMatchPrice() {
        return SellMatchPrice;
    }

    public void setSellMatchPrice(double sellMatchPrice) {
        SellMatchPrice = sellMatchPrice;
    }

    public int getSellMatchQty() {
        return SellMatchQty;
    }

    public void setSellMatchQty(int sellMatchQty) {
        SellMatchQty = sellMatchQty;
    }

    public char getAddOne() {
        return AddOne;
    }

    public void setAddOne(char addOne) {
        AddOne = addOne;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }

    public int getStreamId() {
        return StreamId;
    }

    public void setStreamId(int streamId) {
        StreamId = streamId;
    }

    public String getInsertTradeDate() {
        return InsertTradeDate;
    }

    public void setInsertTradeDate(String insertTradeDate) {
        InsertTradeDate = insertTradeDate;
    }

    public int getOrderReqId() {
        return OrderReqId;
    }

    public void setOrderReqId(int orderReqId) {
        OrderReqId = orderReqId;
    }

    public int getParentReqId() {
        return ParentReqId;
    }

    public void setParentReqId(int parentReqId) {
        ParentReqId = parentReqId;
    }

    public char getOrderPriceType() {
        return OrderPriceType;
    }

    public void setOrderPriceType(char orderPriceType) {
        OrderPriceType = orderPriceType;
    }

    public String getTimeCondition() {
        return TimeCondition;
    }

    public void setTimeCondition(String timeCondition) {
        TimeCondition = timeCondition;
    }

    public double getTriggerPrice2() {
        return TriggerPrice2;
    }

    public void setTriggerPrice2(double triggerPrice2) {
        TriggerPrice2 = triggerPrice2;
    }

    public char getTriggerMode2() {
        return TriggerMode2;
    }

    public void setTriggerMode2(char triggerMode2) {
        TriggerMode2 = triggerMode2;
    }

    public char getTriggerCondition2() {
        return TriggerCondition2;
    }

    public void setTriggerCondition2(char triggerCondition2) {
        TriggerCondition2 = triggerCondition2;
    }

    public char getStopPriceType() {
        return StopPriceType;
    }

    public void setStopPriceType(char stopPriceType) {
        StopPriceType = stopPriceType;
    }

    public double getStopPrice() {
        return StopPrice;
    }

    public void setStopPrice(double stopPrice) {
        StopPrice = stopPrice;
    }

    public String getSessionNo() {
        return SessionNo;
    }

    public void setSessionNo(String sessionNo) {
        SessionNo = sessionNo;
    }

    public String getOrderRef() {
        return OrderRef;
    }

    public void setOrderRef(String orderRef) {
        OrderRef = orderRef;
    }

    public String getUpdateTradeDate() {
        return UpdateTradeDate;
    }

    public void setUpdateTradeDate(String updateTradeDate) {
        UpdateTradeDate = updateTradeDate;
    }

    public char getAutoCloseFlag() {
        return AutoCloseFlag;
    }

    public void setAutoCloseFlag(char autoCloseFlag) {
        AutoCloseFlag = autoCloseFlag;
    }

    public char getIsDeleted() {
        return IsDeleted;
    }

    public void setIsDeleted(char isDeleted) {
        IsDeleted = isDeleted;
    }

    public String getStParentNo() {
        return StParentNo;
    }

    public void setStParentNo(String stParentNo) {
        StParentNo = stParentNo;
    }
}
