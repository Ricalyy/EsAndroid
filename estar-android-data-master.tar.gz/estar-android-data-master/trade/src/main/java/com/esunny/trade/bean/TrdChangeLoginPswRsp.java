package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/20
 */
public class TrdChangeLoginPswRsp extends ApiStruct {

    private String					CompanyNo;								//经纪公司编号
    private String						LoginNo;								//登录帐号

    public TrdChangeLoginPswRsp(byte[] buf) {
        byteToBean(buf);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setLoginNo(util.getString(21));
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getLoginNo() {
        return LoginNo;
    }

    public void setLoginNo(String loginNo) {
        LoginNo = loginNo;
    }
}
