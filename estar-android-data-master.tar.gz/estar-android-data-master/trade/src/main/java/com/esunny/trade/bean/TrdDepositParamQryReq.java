package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/2
 */
public class TrdDepositParamQryReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 85;

    private String CompanyNo;                                //经纪公司编号
    private String UserNo;                                    //资金帐号
    private String ContractNo;                                //合约编号
    private char Direct;                                    //买卖方向
    private char Hedge;                                    //投保 投机 套保 套利 做市(内盘)

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(UserNo, 21));
        buffer.put(stringToByte(ContractNo, 51));
        buffer.put(charToByte(Direct));
        buffer.put(charToByte(Hedge));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }
}
