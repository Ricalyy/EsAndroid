package com.esunny.trade.bean;

/**
 * @author Peter Fu
 * @date 2020/11/20
 */
public class TrdOrderQryRsp extends TrdOrderQryReq{

    public TrdOrderQryRsp(byte[] buf) {
        super(buf);
    }
}
