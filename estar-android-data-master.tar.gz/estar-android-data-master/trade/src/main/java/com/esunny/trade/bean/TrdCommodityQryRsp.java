package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.bean.rsp.PkgCloudAddrRsp;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/4
 */
public class TrdCommodityQryRsp extends ApiStruct {

    public final static int STRUCT_LENGTH = 53;

    private String CompanyNo;       //经纪公司编号
    private String ExchangeNo;       //交易所编号
    private String CommodityNo;       //品种编号
    private String UserNo;       //资金帐号

    private TrdCommodityQryRsp(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCommodityNo(util.getString(11));
        setCommodityNo(util.getString(21));
        setUserNo(util.getString(21));
    }

    public static TrdCommodityQryRsp toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new TrdCommodityQryRsp(data);
        } else {
            return null;
        }
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getExchangeNo() {
        return ExchangeNo;
    }

    public void setExchangeNo(String exchangeNo) {
        ExchangeNo = exchangeNo;
    }

    public String getCommodityNo() {
        return CommodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        CommodityNo = commodityNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }
}
