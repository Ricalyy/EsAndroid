package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/20
 */
public class TrdChangeLoginPswReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 94;

    private String CompanyNo;                                //经纪公司编号
    private String LoginNo;                                //登录帐号
    private String CurrPsw;                                //当前密码
    private String NewPsw;                                    //新密码

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(LoginNo, 21));
        buffer.put(stringToByte(CurrPsw, 31));
        buffer.put(stringToByte(NewPsw, 31));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getLoginNo() {
        return LoginNo;
    }

    public void setLoginNo(String loginNo) {
        LoginNo = loginNo;
    }

    public String getCurrPsw() {
        return CurrPsw;
    }

    public void setCurrPsw(String currPsw) {
        CurrPsw = currPsw;
    }

    public String getNewPsw() {
        return NewPsw;
    }

    public void setNewPsw(String newPsw) {
        NewPsw = newPsw;
    }
}
