package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/18
 */
public class TrdOrderActionReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 86;

    private String                    CompanyNo;                              //经纪公司编号
    private String                       UserNo;                                 //资金帐号
    private String                      OrderNo;                                //委托号
    private String				ContractNo;								//合约编号

    private char              OrderActionType;                        //定单操作类型
    private char					StrategyType;							//策略类型(条件单，止损单、浮动止损、保本止损、止盈单)

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(UserNo, 21));
        buffer.put(stringToByte(OrderNo, 21));
        buffer.put(stringToByte(ContractNo, 31));
        buffer.put(charToByte(OrderActionType));
        buffer.put(charToByte(StrategyType));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getOrderActionType() {
        return OrderActionType;
    }

    public void setOrderActionType(char orderActionType) {
        OrderActionType = orderActionType;
    }

    public char getStrategyType() {
        return StrategyType;
    }

    public void setStrategyType(char strategyType) {
        StrategyType = strategyType;
    }
}
