package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/10/21
 */
public class TrdLoginReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 1169;

    private String CompanyNo;                                //经纪公司编号
    private String CompanyAddressNo;                        //登录地址编号
    private String LoginNo;                                //登录账号
    private String LoginPsw;                                //登录密码
    private String NewPsw;                                    //强制初始化密码
    private char TerminalType;                            //终端类型
    private String AppCode;                                //Api版本号
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private String LoginInfo;                                //客户登录信息(用户定位，手机号、IP、MAC等)

    private String SystemInfo;                             //用户端系统内部信息
    private int SystemInfoLen;                          //用户端系统内部信息长度
    private String SystemInfoIntegrity;                    //采集信息完整度（恒生）
    private int SystemInfoFlag;                         //系统信息标识（恒生，填异常标识，启明星，版本号）
    private String AppVersionCode;                         //App版本号

    public TrdLoginReq() {
    }

    public TrdLoginReq(byte[] data) {
        byteToBean(data);
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(CompanyAddressNo, 21));
        buffer.put(stringToByte(LoginNo, 21));
        buffer.put(stringToByte(LoginPsw, 31));
        buffer.put(stringToByte(NewPsw, 31));
        buffer.put(charToByte(TerminalType));
        buffer.put(stringToByte(AppCode, 21));
        buffer.put(stringToByte(LoginInfo, 201));
        buffer.put(stringToByte(SystemInfo, 501));
        buffer.putInt(SystemInfoLen);
        buffer.put(stringToByte(SystemInfoIntegrity, 301));
        buffer.putInt(SystemInfoFlag);
        buffer.put(stringToByte(AppVersionCode, 21));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        CompanyNo = util.getString(11);
        CompanyAddressNo = util.getString(21);
        LoginNo = util.getString(21);
        LoginPsw = util.getString(31);
        NewPsw = util.getString(31);
        TerminalType = util.getChar();
        AppCode = util.getString(21);
        LoginInfo = util.getString(201);
        SystemInfo = util.getString(501);
        SystemInfoLen = util.getInt();
        SystemInfoIntegrity = util.getString(301);
        SystemInfoFlag = util.getInt();
        AppVersionCode = util.getString(21);
    }

    public static TrdLoginReq toParse(byte[] data) {
        if (data != null && data.length == STRUCT_LENGTH) {
            return new TrdLoginReq(data);
        } else {
            return null;
        }
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getCompanyAddressNo() {
        return CompanyAddressNo;
    }

    public void setCompanyAddressNo(String companyAddressNo) {
        CompanyAddressNo = companyAddressNo;
    }

    public String getLoginNo() {
        return LoginNo;
    }

    public void setLoginNo(String loginNo) {
        LoginNo = loginNo;
    }

    public String getLoginPsw() {
        return LoginPsw;
    }

    public void setLoginPsw(String loginPsw) {
        LoginPsw = loginPsw;
    }

    public String getNewPsw() {
        return NewPsw;
    }

    public void setNewPsw(String newPsw) {
        NewPsw = newPsw;
    }

    public char getTerminalType() {
        return TerminalType;
    }

    public void setTerminalType(char terminalType) {
        TerminalType = terminalType;
    }

    public String getAppCode() {
        return AppCode;
    }

    public void setAppCode(String appCode) {
        AppCode = appCode;
    }

    public String getLoginInfo() {
        return LoginInfo;
    }

    public void setLoginInfo(String loginInfo) {
        LoginInfo = loginInfo;
    }

    public String getSystemInfo() {
        return SystemInfo;
    }

    public void setSystemInfo(String systemInfo) {
        SystemInfo = systemInfo;
    }

    public int getSystemInfoLen() {
        return SystemInfoLen;
    }

    public void setSystemInfoLen(int systemInfoLen) {
        SystemInfoLen = systemInfoLen;
    }

    public String getSystemInfoIntegrity() {
        return SystemInfoIntegrity;
    }

    public void setSystemInfoIntegrity(String systemInfoIntegrity) {
        SystemInfoIntegrity = systemInfoIntegrity;
    }

    public int getSystemInfoFlag() {
        return SystemInfoFlag;
    }

    public void setSystemInfoFlag(int systemInfoFlag) {
        SystemInfoFlag = systemInfoFlag;
    }

    public String getAppVersionCode() {
        return AppVersionCode;
    }

    public void setAppVersionCode(String appVersionCode) {
        AppVersionCode = appVersionCode;
    }
}
