package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/10/26
 */
public class PushClient extends ApiStruct {

    public final static short STRUCT_LENGTH = 52;

    private String                           CID;                             //设备client id
    private char                  DeviceType;                      //设备类型 Android IOS

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CID, 51));
        buffer.put(charToByte(DeviceType));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCID() {
        return CID;
    }

    public void setCID(String CID) {
        this.CID = CID;
    }

    public char getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(char deviceType) {
        DeviceType = deviceType;
    }
}
