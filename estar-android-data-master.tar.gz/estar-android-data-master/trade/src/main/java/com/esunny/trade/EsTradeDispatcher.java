package com.esunny.trade;

import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.Nullable;

import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.EsEventConstant;
import com.esunny.data.api.event.TradeEvent;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.bean.BillData;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.MatchData;
import com.esunny.data.bean.MessageData;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.MoneyField;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.Plate;
import com.esunny.data.bean.PositionData;
import com.esunny.data.bean.TradeLogin;
import com.esunny.data.bean.TradeLoginRsp;
import com.esunny.data.util.EsLog;
import com.esunny.mobile.EsApiData;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.mobile.util.ParseUtil;
import com.esunny.trade.bean.CspAuthReq;
import com.esunny.trade.bean.PushClient;
import com.esunny.trade.bean.PushClientInfoNotice;
import com.esunny.trade.bean.SASXSystemParamData;
import com.esunny.data.bean.SPushClientInfo;
import com.esunny.trade.bean.STradeUser;
import com.esunny.trade.bean.TrdASXParamQryRsp;
import com.esunny.trade.bean.TrdBillConfirmRsp;
import com.esunny.trade.bean.TrdBillConfirmStatusQryReq;
import com.esunny.trade.bean.TrdBillConfirmStatusQryRsp;
import com.esunny.trade.bean.TrdBillQryReq;
import com.esunny.trade.bean.TrdBillQryRsp;
import com.esunny.trade.bean.TrdChangeLoginPswRsp;
import com.esunny.trade.bean.TrdCommodityQryReq;
import com.esunny.trade.bean.TrdCommodityQryRsp;
import com.esunny.trade.bean.TrdDepositParamQryReq;
import com.esunny.trade.bean.TrdDepositParamQryRsp;
import com.esunny.trade.bean.TrdFeeParamQryReq;
import com.esunny.trade.bean.TrdFeeParamQryRsp;
import com.esunny.trade.bean.TrdFundField;
import com.esunny.trade.bean.TrdFundQryReq;
import com.esunny.trade.bean.TrdFundQryRsp;
import com.esunny.trade.bean.TrdLoginReq;
import com.esunny.trade.bean.TrdLoginRsp;
import com.esunny.trade.bean.TrdMatchDelRtn;
import com.esunny.trade.bean.TrdMatchQryReq;
import com.esunny.trade.bean.TrdMatchQryRsp;
import com.esunny.trade.bean.TrdMatchRtn;
import com.esunny.trade.bean.TrdOrderInsertRsp;
import com.esunny.trade.bean.TrdOrderQryReq;
import com.esunny.trade.bean.TrdOrderQryRsp;
import com.esunny.trade.bean.TrdOrderRtn;
import com.esunny.trade.bean.TrdPositionQryReq;
import com.esunny.trade.bean.TrdPositionQryRsp;
import com.esunny.trade.bean.TrdSecondInfoReq;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author Peter Fu
 * @date 2020/10/16
 */
public class EsTradeDispatcher extends CallbackDispatcher {

    private EsTradeApiImpl mTradeApi;

    public EsTradeDispatcher() {
        mTradeApi = new EsTradeApiImpl();
    }

    private final static String TAG = EsTradeDispatcher.class.getSimpleName();

    private SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式

    private STradeUser mTradeForceChangePwdUser = new STradeUser();

    @Override
    public int dispatch(char action, byte[] data) {
        int key = EsTradeData.getInstance().getClientMap().get(this);
        STradeUser tu = getUserByKey(key);
        if (tu == null) {
            Log.d(TAG, "key : " + key);
            return -1;
        }
        TradeLogin tradeLogin = tu.getTradeLogin();

        if (action == EVENT_TCP_CONNECT) {
            TradeEvent.Builder builder = new TradeEvent.Builder(EsEventConstant.S_SRVEVENT_CONNECT)
                    .setCompanyNo(tradeLogin.getCompanyNo())
                    .setUserNo(tradeLogin.getUserNo())
                    .setAddressNo(tradeLogin.getAddrTypeNo())
                    .setSrvErrorCode(0);
            sendEvent(builder.buildEvent());
            PhoneAuthReq();
            return 0;
        }

        if (action == EVENT_TCP_DISCONNECT) {
            TradeEvent.Builder builder = new TradeEvent.Builder(EsEventConstant.S_SRVEVENT_DISCONNECT)
                    .setCompanyNo(tradeLogin.getCompanyNo())
                    .setUserNo(tradeLogin.getUserNo())
                    .setAddressNo(tradeLogin.getAddrTypeNo())
                    .setSrvErrorCode(0);
            sendEvent(builder.buildEvent());

            return 0;
        }

        if (action == EVENT_TCP_RESET_DATA) {
            return 0;
        }

        byte[] headArr = new byte[CspSessionHead.STRUCT_LENGTH];
        System.arraycopy(data, 0, headArr, 0, CspSessionHead.STRUCT_LENGTH);

        int dataLen = data.length - CspSessionHead.STRUCT_LENGTH;
        byte[] buf = new byte[dataLen];
        System.arraycopy(data, CspSessionHead.STRUCT_LENGTH, buf, 0, dataLen);
        CspSessionHead head = new CspSessionHead(headArr);

        switch (head.getProtocolCode()) {
            case EsTradeProtocol.CMD_CSP_AUTHRSP:
                OnAuth(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_LOGIN_RSP:
                OnLogin(tu, buf, head);
                ClearUserInfo(tu);
                break;
            case EsTradeProtocol.CMD_TRD_LOGOUT_RTN:
                OnLogout(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_COMMODITY_QRY_RSP:
                OnTCommodity(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_MESSAGE_QRY_RSP:
            case EsTradeProtocol.CMD_TRD_MESSAGE_RTN:
                OnTMessage(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_ASXPARAM_RTN:
                onSASXSystemParam(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_ORDER_QRY_RSP:     //委托查询应答
                OnTOrder(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_STRATEGYORDER_QRY_RSP:
                OnTStrategyOrder(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_ORDERINSERT_RSP:   //委托应答
                OnTOrderInsert(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_ORDER_ACT_RSP:     //委托操作应答
            case EsTradeProtocol.CMD_TRD_ORDER_MDF_RSP:     //委托操作应答
                OnTOrderAction(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_STRATEGYORDER_QRY_DATA:
            case EsTradeProtocol.CMD_TRD_ORDER_RTN:         //委托数据
            case EsTradeProtocol.CMD_TRD_ORDER_QRY_DATA:
                OnTOrderData(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_MATCH_QRY_RSP:     //成交查询应答
                OnTMatch(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_MATCH_RTN:         //成交数据
            case EsTradeProtocol.CMD_TRD_MATCH_QRY_DATA:
                OnTMatchData(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_MATCH_DEL_RTN:
                OnTMatchDataDelete(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_POSITION_QRY_RSP:
            case EsTradeProtocol.CMD_TRD_POSITION_RTN:      //持仓数据
                OnTPositionData(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_FUND_QRY_RSP:
            case EsTradeProtocol.CMD_TRD_FUND_CHG_RTN:     //资金数据
                OnTMoneyData(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_CHANGELOGINPSW_RSP:     //修改密码
                OnTChangePwd(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_CHANGEFUNDPSW_RSP:
                OnTChgFundPwd(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_TRANSBANK_QRY_RSP:
                OnTTransBank(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_TRANSBANKUSER_QRY_RSP:
                OnTSigningBank(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_BANKBALANCE_QRY_RSP:
                OnTBankBalance(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_TRANSFER_RSP:
            case EsTradeProtocol.CMD_TRD_TRANSFER_RTN:
                OnTBankTransfer(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_TRANSFER_QRY_RSP:
                OnTQryBankTransfer(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_BILL_QRY_RSP:
                OnTQryBill(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_BILLCONFIRMSTATUS_QRY_RSP:
                OnTQryBillConfirmStatus(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_BILLCONFIRM_RSP:
                OnTBillConfirm(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_CURRENCY_QRY_RSP:
            case EsTradeProtocol.CMD_TRD_CURRENCY_RTN:
                OnCurrency(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_FEEPARAM_QRY_RSP:
            case EsTradeProtocol.CMD_TRD_FEEPARAM_RTN:
                OnFee(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_DEPOSITPARAM_QRY_RSP:
            case EsTradeProtocol.CMD_TRD_DEPOSITPARAM_RTN:
                OnDeposit(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_POSITIONCALCPRICE_RTN:
                OnPositionCalcPrice(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_TRD_TRADEDATESWITCH_RTN:
            {
                OnTradeDateSwitch(tu, buf, head);
                break;
            }
            case EsTradeProtocol.CMD_TRD_SMSAUTH_RSP:
            {
                OnSMSAuth(tu,buf, head);
                break;
            }
            case EsTradeProtocol.CMD_TRD_SECONDINFO_RSP:
            {
                OnSMSAuthMethod(tu,buf, head);
                break;
            }
            case EsTradeProtocol.CMD_TRD_SECONDCHECKCODE_RSP:
            {
                OnSMSAuthInfo(tu,buf, head);
                break;
            }
            case EsTradeProtocol.CMD_TRD_VERIFY_IDENTITY_RSP:
            {
                OnVerifyInendity(tu, buf, head);
                break;
            }
            case EsTradeProtocol.CMD_TRD_SEC_VERTIFICATION_RSP:
            {
                OnSecondeCertification(tu, buf, head);
                break;
            }
            case EsTradeProtocol.CMD_TRD_G_INITREADY_TRN:
                InitReadyTRN(tu, buf, head);
                break;
            case EsTradeProtocol.CMD_QTE_HEARTBEATREQ:  // 处理心跳协议
            {
//                sh->ProtocolCode = EsTradeProtocol.CMD_QTE_HEARTBEATRSP;
//                STcpClient_Send(tu->TcpClient, buf, head);
                break;
            }
            default:
                break;
        }

        tradeRecvCall(tu, head);
        return 0;
    }

    private void OnSecondeCertification(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnVerifyInendity(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnSMSAuthInfo(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnSMSAuthMethod(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnSMSAuth(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnTradeDateSwitch(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnPositionCalcPrice(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnDeposit(STradeUser tu, byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        byte[] struct = new byte[len];

        Map<String, TrdDepositParamQryRsp> userDeposit = tu.getDeposit();

        for (int i = 0; i < count; i++) {
            int start = i * len;
            System.arraycopy(buf, start, struct, 0, len);
            TrdDepositParamQryRsp rsp = TrdDepositParamQryRsp.toParse(struct);
            if (TextUtils.isEmpty(rsp.getContractNo())) {
                continue;
            }

            String key = String.format("%s_%c_%c", rsp.getContractNo(), rsp.getDirect(), rsp.getHedge());
            userDeposit.put(key, rsp);
        }
    }

    private void OnCurrency(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnTBillConfirm(STradeUser tu, byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        byte[] struct = new byte[len];

        for (int i = 0; i < count; i++) {
            int start = i * len;
            System.arraycopy(buf, start, struct, 0, len);
            TrdBillConfirmRsp rsp = new TrdBillConfirmRsp(struct);

            if (tu.getTradeState() == EsTradeProtocol.TS_BILLQRY) {
                tu.setTradeState((short) EsTradeProtocol.TS_BILLCONFIRMED);
            }

            sendEvent(EsDataConstant.S_SRVEVENT_BILLCONFIRM, rsp, tu, head, "");
        }

        if (count == 0) {
            sendEvent(EsDataConstant.S_SRVEVENT_BILLCONFIRM, null, tu, head, "");
        }
    }

    private void OnTQryBill(STradeUser tu, byte[] buf, CspSessionHead head) {
        if (tu.getBillQrySessionId() != head.getSessionId()) {
            return;
        }

        int count = head.getFieldCount();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            if (tu.getBillData() == null) {
                tu.setBillData(new BillData());
            }
            BillData data = tu.getBillData();
            TrdBillQryRsp rsp = new TrdBillQryRsp();

            if (util.getPoint() + 47 >= buf.length) {
                if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
                    if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
                        if (tu.getTradeState() == EsTradeProtocol.TS_BILLQRY) {
                            sendEvent(EsDataConstant.S_SRVEVENT_BILLCONFIRMNOTICE, data, tu, head, "");
                        } else {
                            sendEvent(EsDataConstant.S_SRVEVENT_QRY_BILL, data, tu, head, "");
                        }
                    }
                }
                break;
            }
            String companyNo = util.getString(11);
            rsp.setCompanyNo(companyNo);
            String userNo = util.getString(21);
            rsp.setUserNo(userNo);
            char billtype = util.getChar();
            rsp.setBillType(billtype);
            String billData = util.getString(11);
            rsp.setBillDate(billData);
            char formatType = util.getChar();
            rsp.setFormatType(formatType);
            short len = util.getShort();
            String content = util.getString(len);
            rsp.setContent(content);

            if (TextUtils.isEmpty(rsp.getCompanyNo())) {
                data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
            } else {
                data.setCompanyNo(rsp.getCompanyNo());
            }

            if (TextUtils.isEmpty(rsp.getUserNo())) {
                data.setUserNo(tu.getTradeLogin().getUserNo());
            } else {
                data.setUserNo(rsp.getUserNo());
            }

            data.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
            data.setBillDate(rsp.getBillDate());

            if (!TextUtils.isEmpty(rsp.getContent())) {
                if (data.getContent() != null) {
                    data.setContent(data.getContent() + rsp.getContent());
                } else {
                    data.setContent(rsp.getContent());
                }
            }
            data.setBillType(rsp.getBillType());
            data.setFormatType(rsp.getFormatType());

            if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
                if (tu.getTradeState() == EsTradeProtocol.TS_BILLQRY) {
                    sendEvent(EsDataConstant.S_SRVEVENT_BILLCONFIRMNOTICE, data, tu, head, "");
                } else {
                    sendEvent(EsDataConstant.S_SRVEVENT_QRY_BILL, data, tu, head, "");
                }
            }
        }

        if (count == 0) {
            sendEvent(EsDataConstant.S_SRVEVENT_QRY_BILL, null, tu, head, "");
        }
    }

    private void OnTQryBankTransfer(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnTBankTransfer(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnTBankBalance(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnTSigningBank(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnTTransBank(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnTChgFundPwd(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    private void OnTChangePwd(STradeUser tu, byte[] buf, CspSessionHead head) {
        TrdChangeLoginPswRsp rsp = new TrdChangeLoginPswRsp(buf);

        if (head.getErrorCode() == 0 && tu.getModifyPass().length() != 0) {
            tu.setPassword(tu.getModifyPass());
        }
        sendEvent(EsDataConstant.S_SRVEVENT_CHG_TRD_PWD, null, tu, head, "");
    }

    private void OnTPositionData(STradeUser tu, byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        Map<String, PositionData> userLockPosition = tu.getLockPosition();
        Map<String, PositionData> userPosition = tu.getPositions();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            if (tu.getTradeState() == 0) {
                return;
            }

            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdPositionQryRsp rsp = TrdPositionQryRsp.toParse(struct);
            if (rsp == null) {
                continue;
            }

            String key = rsp.getPositionNo();
            if (rsp.getContractNo() != null && rsp.getContractNo().equals(rsp.getPositionNo())) {
                PositionData data = userLockPosition.get(key);
                if (data == null) {
                    data = new PositionData();
                    userLockPosition.put(key, data);
                }

                fillPositionData(data, rsp, tu);
                sendEvent(EsDataConstant.S_SRVEVENT_TRADE_LOCK_POSITION, null, tu, head, "");
                continue;
            }

            //是否有老持仓
            boolean pre_flag = false;
            PositionData  data = userLockPosition.get(key);
            PositionData pre_data = new PositionData();
            if (data != null) {
                pre_flag = true;
                pre_data = data;
            } else {
                data = new PositionData();
                userPosition.put(key, data);
            }

            fillPositionData(data, rsp, tu);

            SumTPosition(tu, data, pre_data, pre_flag);

            //持仓状态变化回调
            if (i == count - 1 && head.getChain() ==  EsNativeProtocol.CSP_CHAIN_END) {
                sendEvent(EsDataConstant.S_SRVEVENT_TRADE_POSITION, data, tu, head, "");
            }
        }

        if (head.getFieldCount() == 0) {
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_POSITION, null, tu, head, "");
        }
    }

    private void SumTPosition(STradeUser tu, PositionData data, PositionData pre_data, boolean flag) {
        char hedge = data.getHedge();
        if (hedge == '0' || hedge == ' ') {
            hedge = 0;
        }

        Map<String, PositionData> userSumPositions = tu.getSumPositions();

        String key = String.format("%s%c%c", data.getContractNo(), data.getDirect(), hedge);
        PositionData target = userSumPositions.get(key);
        if (target == null) {
            if (data.getPositionQty().compareTo(BigInteger.ZERO) > 0) {
                target = data;
                userSumPositions.put(key, target);
            }

            return;
        }

        //有老持仓，在原有汇总结果中去掉已经汇总的持仓
        if (flag && pre_data.getPositionQty() != null && pre_data.getPositionQty().compareTo(BigInteger.ZERO) > 0
                && target.getPositionQty().compareTo(pre_data.getPositionQty()) >= 0) {
            if (!tu.getTradeLogin().getTradeApi().contains("Kingstar")) {
                if (target.getPositionQty().compareTo(pre_data.getPositionQty()) != 0) {
                    double positionPrice = (target.getPositionPrice() * target.getPositionQty().intValue() - pre_data.getPositionQty().intValue() * pre_data.getPositionPrice())
                            / (target.getPositionQty().intValue() - pre_data.getPositionQty().intValue());
                    target.setPositionPrice(positionPrice);
                } else {
                    target.setPositionPrice(0.0);
                }
            }
            target.setPositionQty(target.getPositionQty().subtract(pre_data.getPositionQty()));
            target.setPrePositionQty(target.getPrePositionQty().subtract(pre_data.getPrePositionQty()));

            //浮盈
            target.setFloatProfit(target.getFloatProfit() - pre_data.getFloatProfit());
            target.setFloatProfitTBT(target.getFloatProfitTBT() - pre_data.getFloatProfitTBT());

            //保证金
            target.setDeposit(target.getDeposit() - pre_data.getDeposit());
            target.setKeepDeposit(target.getKeepDeposit() - pre_data.getKeepDeposit());

            //期权市值
            target.setMarketValue(target.getMarketValue() - pre_data.getMarketValue());
        }

        //过滤持仓量为0的数据
        if (data.getPositionQty().compareTo(BigInteger.ZERO) <= 0) {
            return;
        }

        //持仓价
        //金仕达不用计算
        if (!tu.getTradeLogin().getTradeApi().contains("Kingstar")) {
            double positionPrice = (target.getPositionPrice() * target.getPositionQty().intValue() + data.getPositionQty().intValue() * data.getPositionPrice())
                    / (target.getPositionQty().intValue() + data.getPositionQty().intValue());
            target.setPositionPrice(positionPrice);
        } else {
            target.setPositionPrice(data.getPositionPrice());
        }

        target.setPositionQty(target.getPositionQty().add(data.getPositionQty()));
        target.setPrePositionQty(target.getPrePositionQty().add(data.getPrePositionQty()));

        //浮盈
        target.setFloatProfit(target.getFloatProfit() + data.getFloatProfit());
        target.setFloatProfitTBT(target.getFloatProfitTBT() + data.getFloatProfitTBT());

        //保证金
        target.setDeposit(target.getDeposit() + data.getDeposit());
        target.setKeepDeposit(target.getKeepDeposit() + data.getKeepDeposit());

        //期权市值
        target.setMarketValue(target.getMarketValue() + data.getMarketValue());

        //其他字段取最后一笔
        target.setHedge(hedge);
        target.setProfitCalcPrice(data.getProfitCalcPrice());
        target.setDepositCalcPrice(data.getDepositCalcPrice());
        target.setCanCoverQty(data.getCanCoverQty());
        target.setFrozenQty(data.getFrozenQty());
        target.setStreamId(data.getStreamId());

        target.setMatchNo(data.getMatchNo());
        target.setMatchDateTime(data.getMatchDateTime());
    }

    private void fillPositionData(PositionData data, TrdPositionQryRsp rsp, STradeUser tu) {
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());
        data.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
        data.setPositionNo(rsp.getPositionNo());
        data.setContractNo(rsp.getContractNo());
        data.setDirect(rsp.getDirect());
        data.setHedge(rsp.getHedge());
        data.setPositionPrice(rsp.getPositionPrice());
        data.setPositionQty(BigInteger.valueOf(rsp.getPositionQty()));
        data.setPrePositionQty(BigInteger.valueOf(rsp.getPrePositionQty()));
        data.setMatchNo(rsp.getMatchNo());
        data.setMatchDateTime(rsp.getMatchDateTime());
        data.setProfitCalcPrice(rsp.getProfitCalcPrice());
        data.setFloatProfit(rsp.getFloatProfit());
        data.setFloatProfitTBT(rsp.getFloatProfitTBT());
        data.setDepositCalcPrice(rsp.getDepositCalcPrice());
        data.setDeposit(rsp.getDeposit());
        data.setKeepDeposit(rsp.getKeepDeposit());
        data.setMarketValue(rsp.getMarketValue());
        data.setCanCoverQty(BigInteger.valueOf(rsp.getCanCoverQty()));
        data.setFrozenQty(BigInteger.valueOf(rsp.getFrozenQty()));
        data.setStreamId(rsp.getStreamId());
    }

    private void OnTMatchDataDelete(STradeUser tu, byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        Map<String, MatchData> userMatchData = tu.getMatches();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdMatchDelRtn rsp = TrdMatchDelRtn.toParse(struct);
            if (rsp == null) {
                continue;
            }

            //分公司分用户存储，key不需要加公司号，某些交易所系统买卖成交号相同，加方向
            String key = String.format("%s%c", rsp.getMatchNo(), rsp.getDirect());
            MatchData matchData = userMatchData.get(key);
            if (matchData != null) {
                matchData.setIsDeleted(true);
            } else {
                continue;
            }

            //成交状态变化回调
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_MATCH, matchData, tu, head, "");
        }

        if(count == 0) {
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_MATCH, null, tu, head, "");
        }
    }

    /**
     * 成交数据
     * @param tu
     * @param buf
     * @param head
     */
    private void OnTMatchData(STradeUser tu, byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        Map<String, MatchData> userMatchData = tu.getMatches();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            if (tu.getTradeState() == 0) {
                return;
            }

            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdMatchRtn rsp = TrdMatchRtn.toParse(struct);
            if (rsp == null) {
                continue;
            }
            String key = String.format("%s%c", rsp.getMatchNo(), rsp.getDirect());
            MatchData matchData = userMatchData.get(key);
            if (matchData != null) {
                fillMatchData(matchData, rsp, tu);
//                matchData.setCompanyNo(tu.getTradeLogin().getCompanyNo());
//                matchData.setUserNo(tu.getTradeLogin().getUserNo());
//                matchData.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
//                matchData.setMatchNo(rsp.getMatchNo());
//                matchData.setContractNo(rsp.getContractNo());
//                matchData.setDirect(rsp.getDirect());
//                matchData.setOffset(rsp.getOffset());
//                matchData.setHedge(rsp.getHedge());
//                matchData.setMatchPrice(rsp.getMatchPrice());
//                matchData.setMatchQty(BigInteger.valueOf(rsp.getMatchQty()));
//                matchData.setMatchWay(rsp.getMatchWay());
//                matchData.setMatchDateTime(rsp.getMatchDateTime());
//                matchData.setOrderNo(rsp.getOrderNo());
//                matchData.setFeeCurrencyNo(rsp.getFeeCurrencyNo());
//                matchData.setMatchFee(rsp.getMatchFee());
//                matchData.setPremium(rsp.getPremium());
//                matchData.setStreamId(rsp.getStreamId());
//                matchData.setAddOne(rsp.getAddOne() == 1);
//                matchData.setIsDeleted(rsp.getIsDeleted() == 1);
            } else {
                matchData = new MatchData();
                fillMatchData(matchData, rsp, tu);
                userMatchData.put(key, matchData);
            }

            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_MATCH, matchData, tu, head, "");
        }
    }

    private void fillMatchData(MatchData matchData, TrdMatchRtn rsp, STradeUser tu) {
        matchData.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        matchData.setUserNo(tu.getTradeLogin().getUserNo());
        matchData.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
        matchData.setMatchNo(rsp.getMatchNo());
        matchData.setContractNo(rsp.getContractNo());
        matchData.setDirect(rsp.getDirect());
        matchData.setOffset(rsp.getOffset());
        matchData.setHedge(rsp.getHedge());
        matchData.setMatchPrice(rsp.getMatchPrice());
        matchData.setMatchQty(BigInteger.valueOf(rsp.getMatchQty()));
        matchData.setMatchWay(rsp.getMatchWay());
        matchData.setMatchDateTime(rsp.getMatchDateTime());
        matchData.setOrderNo(rsp.getOrderNo());
        matchData.setFeeCurrencyNo(rsp.getFeeCurrencyNo());
        matchData.setMatchFee(rsp.getMatchFee());
        matchData.setPremium(rsp.getPremium());
        matchData.setStreamId(rsp.getStreamId());
        matchData.setAddOne(rsp.getAddOne() == 1);
        matchData.setIsDeleted(rsp.getIsDeleted() == 1);
    }

    private void OnTMatch(STradeUser tu, byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdMatchQryRsp rsp = new TrdMatchQryRsp(struct);

            if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
                sendEvent(EsDataConstant.S_SRVEVENT_TRADE_MATCH, null, tu, head, "");
            } else {
                TradeQryMatch(tu, rsp.getSerialId());
            }
        }
    }

    private void TradeQryMatch(STradeUser tu, int serialId) {
        TrdMatchQryReq data = new TrdMatchQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());
        data.setSerialId(serialId);

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_MATCH_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdMatchQryReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    //定单数据，保存在tu->Orders结构
    private void OnTOrderData(STradeUser tu, byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            if (tu.getTradeState() == 0) {
                return;
            }

            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdOrderRtn rsp = TrdOrderRtn.toParse(struct);
            if (rsp == null) {
                continue;
            }

            if (rsp.getStrategyType() == '\0') {
                DealOrder(tu, head, i, rsp);
            } else {
                DealStrategyOrder(tu,head, i, rsp);
            }
        }
    }

    private void DealStrategyOrder(STradeUser tu, CspSessionHead head, int i, TrdOrderRtn rsp) {
        Map<String, OrderData> userOrders = tu.getOrderData();
        OrderData data = userOrders.get(String.valueOf(head.getSessionId()));

        if (data != null) {
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_LOG, data, tu, head, "");
            userOrders.remove(data);
        }

        String key = rsp.getOrderNo();
        Map<String, OrderData> userStrategyOrders = tu.getStrategyOrders();
        data = userStrategyOrders.get(key);
        if (data == null) {
            data = new OrderData();
        }

        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());
        data.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
        data.setContractNo(rsp.getContractNo());
        data.setOrderType(rsp.getOrderType());
        data.setOrderWay(rsp.getOrderWay());
//        data.setRiskOrder(rsp.getIsRiskOrder() == 1);
        data.setValidType(rsp.getValidType());
        data.setValidTime(rsp.getValidTime());
        data.setDirect(rsp.getDirect());
        data.setOffset(rsp.getOffset());
        data.setHedge(rsp.getHedge());
        data.setOrderPrice(rsp.getOrderPrice());
        data.setOrderQty(BigInteger.valueOf(rsp.getOrderQty()));
        data.setOrderNo(rsp.getOrderNo());
        data.setLocalNo(rsp.getLocalNo());
        data.setSystemNo(rsp.getSystemNo());
        data.setSeatNo(rsp.getSeatNo());
        data.setInsertNo(rsp.getInsertNo());
        data.setInsertDateTime(rsp.getInsertDateTime());
        data.setUpdateNo(rsp.getUpdateNo());
        data.setUpdateDateTime(rsp.getUpdateDateTime());
        data.setMatchPrice(rsp.getMatchPrice());
        data.setMatchQty(BigInteger.valueOf(rsp.getMatchQty()));
        data.setOrderState(rsp.getOrderState());
        data.setErrorCode(rsp.getErrorCode());
        data.setErrorText(rsp.getErrorText());
        data.setStreamId(rsp.getStreamId());
        data.setTriggerPrice(rsp.getTriggerPrice());
        data.setTriggerMode(rsp.getTriggerMode());
        data.setTriggerCondition(rsp.getTriggerCondition());
        data.setStrategyType(rsp.getStrategyType());
        data.setAddOne(rsp.getAddOne() == 1);
        data.setParentNo(rsp.getParentNo());
        data.setOrderReqId(rsp.getOrderReqId());
        data.setParentReqId(rsp.getParentReqId());
        data.setOrderPriceType(rsp.getOrderPriceType());
        data.setTimeCondition(rsp.getTimeCondition());
        data.setTriggerPrice2(rsp.getTriggerPrice2());
        data.setTriggerMode2(rsp.getTriggerMode2());
        data.setTriggerCondition2(rsp.getTriggerCondition2());
        data.setStopPriceType(rsp.getStopPriceType());
        data.setStopPrice(rsp.getStopPrice());
        data.setSessionNo(rsp.getSessionNo());
        data.setOrderRef(rsp.getOrderRef());
        data.setAutoCloseFlag(rsp.getAutoCloseFlag() == 1);
        data.setDeleted(rsp.getIsDeleted() == 1);
        data.setStParentNo(rsp.getStParentNo());

        if (!TextUtils.isEmpty(rsp.getErrorText()) && rsp.getErrorCode() != 0) {
            data.setErrorText(rsp.getErrorText());
        }

        userStrategyOrders.put(key, data);
        if (data.getStrategyType() == EsTradeProtocol.TRD_ST_STSTOPLOSS) {
            InsertStopLossOpenStrategyOrders(tu, data);
        }

        sendEvent(EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER, data, tu, head, "");
    }

    private void DealOrder(STradeUser tu, CspSessionHead head, int i, TrdOrderRtn rsp) {
        Map<String, OrderData> userOrderData = tu.getOrderData();
        OrderData data = userOrderData.get(String.valueOf(head.getSessionId()));
        if (data != null) {
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_LOG, data, tu, head, rsp.getErrorText());
            userOrderData.remove(String.valueOf(head.getSessionId()));
        }

        //分公司分用户存储，key不需要CompanyNo
        //先在委托列表中查找，找到更新数据，找不到在定单表中查找
        Map<String, OrderData> userOrders = tu.getOrders();
        data = userOrders.get(rsp.getOrderNo());
        //可能是系统启动，从后台查询过来的数据
        if (data == null) {
            data = new OrderData();
            data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
            data.setUserNo(tu.getTradeLogin().getUserNo());
            data.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
            data.setContractNo(rsp.getContractNo());
            data.setOrderType(rsp.getOrderType());
            data.setOrderWay(rsp.getOrderWay());
            data.setRiskOrder(rsp.getIsRiskOrder() == 1);
            data.setValidType(rsp.getValidType());
            data.setValidTime(rsp.getValidTime());
            data.setDirect(rsp.getDirect());
            data.setOffset(rsp.getOffset());
            data.setHedge(rsp.getHedge());
            data.setOrderNo(rsp.getOrderNo());
            data.setLocalNo(rsp.getLocalNo());
            data.setSystemNo(rsp.getSystemNo());
            data.setSeatNo(rsp.getSeatNo());
            data.setInsertNo(rsp.getInsertNo());
            data.setStreamId(rsp.getStreamId());
            data.setTriggerPrice(rsp.getTriggerPrice());
            data.setTriggerMode(rsp.getTriggerMode());
            data.setTriggerCondition(rsp.getTriggerCondition());
            data.setStrategyType(rsp.getStrategyType());
            data.setAddOne(rsp.getAddOne() == 1);
            data.setParentNo(rsp.getParentNo());
            data.setOrderReqId(rsp.getOrderReqId());
            data.setParentReqId(rsp.getParentReqId());
            data.setOrderPriceType(rsp.getOrderPriceType());
            data.setTimeCondition(rsp.getTimeCondition());
            data.setTriggerPrice2(rsp.getTriggerPrice2());
            data.setTriggerMode2(rsp.getTriggerMode2());
            data.setTriggerCondition2(rsp.getTriggerCondition2());
            data.setStopPriceType(rsp.getStopPriceType());
            data.setStopPrice(rsp.getStopPrice());
            data.setSessionNo(rsp.getSessionNo());
            data.setOrderRef(rsp.getOrderRef());
            data.setAutoCloseFlag(rsp.getAutoCloseFlag() == 1);
            data.setDeleted(rsp.getIsDeleted() == 1);
        }

        if (!TextUtils.isEmpty(rsp.getInsertDateTime()) && rsp.getInsertDateTime().charAt(0) != '\0') {
            data.setInsertDateTime(rsp.getInsertDateTime());
        }
        data.setOrderPrice(rsp.getOrderPrice());
        data.setOrderQty(BigInteger.valueOf(rsp.getOrderQty()));
        data.setUpdateNo(rsp.getUpdateNo());
        if (!TextUtils.isEmpty(rsp.getUpdateDateTime()) && rsp.getUpdateDateTime().charAt(0) != '\0') {
            data.setUpdateDateTime(rsp.getUpdateDateTime());
        }
        data.setMatchPrice(rsp.getMatchPrice());
        data.setMatchQty(BigInteger.valueOf(rsp.getMatchQty()));
        data.setOrderState(rsp.getOrderState());
        if (rsp.getOrderState() == EsDataConstant.S_ORDERSTATE_CANCELED && rsp.getMatchQty() > 0) {
            data.setOrderState(EsDataConstant.S_ORDERSTATE_PARTCANCELED);
        }
        data.setErrorCode(rsp.getErrorCode());
        data.setErrorText(rsp.getErrorText());
        if (!TextUtils.isEmpty(rsp.getErrorText())) {
            if (rsp.getErrorCode() == 0 && (data.getOrderType() == EsDataConstant.S_ORDERTYPE_EXECUTE || data.getOrderType() == EsDataConstant.S_ORDERTYPE_ABANDON
                    || data.getOrderType() == EsDataConstant.S_ORDERTYPE_ENQUIRY)) {
                if (data.getOrderState() == EsDataConstant.S_ORDERSTATE_FAIL) {
                    data.setErrorCode(-10000);
                }
            }
        }

        //撤单下单
        Map<String, InsertOrder> userTempOrder = tu.getTempOrder();
        InsertOrder reqorder = userTempOrder.get(data.getOrderNo());
        if (reqorder != null) {
            if (data.getOrderState() == EsDataConstant.S_ORDERSTATE_CANCELED) {
                Map<String, InsertOrder> userStrategyTempOrder = tu.getStrategyOpenTempOrder();
                boolean isContrains = userStrategyTempOrder.containsKey(data.getOrderNo());
                if (isContrains) {
                    //止损开仓改单
                    InsertOrder[] order = new InsertOrder[3];
                    for (int index = 0; index < 3; index++) {
                        if (isContrains) {
                            order[index] = userStrategyTempOrder.get(data.getOrderNo());
                            userStrategyTempOrder.remove(data.getOrderNo());
                            // TODO 此处问问飞总怎么写，没看懂
                        }
                    }
                } else {
                    //普通改单
                    int ret = EsDataApi.openTradeOrder(reqorder);
                    reqorder.setOrderReqId(ret);
                }
            }
            userTempOrder.remove(data.getOrderNo());
        }

        //还没有加入委托列表
        userOrders.put(rsp.getOrderNo(), data);
        InsertStopLossOpenStrategyOrders(tu, data);

        EsLog.d(TAG, "onDeal Order() order state : " + data.getOrderState());

        sendEvent(EsDataConstant.S_SRVEVENT_TRADE_ORDER, data, tu, head, data.getErrorText());
    }

    private void OnTOrderAction(STradeUser tu, byte[] buf, CspSessionHead head) {

    }

    /**
     * 下单应答
     * @param tu
     * @param buf
     * @param head
     */
    private void OnTOrderInsert(STradeUser tu, byte[] buf, CspSessionHead head) {
        Log.d(TAG, "OnTOrderInsert()");

        int count = head.getFieldCount();
        int len = head.getFieldSize();

        long sessionId = head.getSessionId();

        Map<String, OrderData> userOrderDataMap = tu.getOrderData();
        OrderData data = userOrderDataMap.get(String.valueOf(sessionId));

        if (count == 0) {
            if (data == null) {
                return;
            }
            data.setErrorCode((int) head.getErrorCode());

            if (data.getErrorCode() != 0) {
                data.setOrderState(EsDataConstant.S_ORDERSTATE_FAIL);
            }

            if (data.getStrategyType() == '\0') {
                sendEvent(EsDataConstant.S_SRVEVENT_TRADE_ORDER, data, tu, head, data.getErrorText());
            } else {
                sendEvent(EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER, data, tu, head, data.getErrorText());
            }

            // 清除该订单数据
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_LOG, data, tu, head, data.getErrorText());
            userOrderDataMap.remove(sessionId);
        }

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdOrderInsertRsp rsp = TrdOrderInsertRsp.toParse(struct);
            if (rsp == null) {
                continue;
            }

            if (data == null) {
                continue;
            }

            data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
            data.setUserNo(tu.getTradeLogin().getUserNo());
            data.setAddressNo(tu.getTradeLogin().getAddrTypeNo());

            data.setOrderNo(rsp.getOrderNo());

            data.setInsertNo(rsp.getInsertNo());
            data.setInsertDateTime(rsp.getInsertDateTime());
            data.setErrorText(rsp.getErrorText());

            data.setErrorCode(rsp.getErrorCode() == 0 ? (int) head.getErrorCode() : rsp.getErrorCode());
            data.setOrderState(rsp.getOrderState());

            data.setSessionNo(rsp.getSessionNo());
            data.setParentNo(rsp.getParentNo());
            data.setOrderReqId(rsp.getOrderReqId());
            data.setOrderRef(rsp.getOrderRef());
            data.setAutoCloseFlag(rsp.getAutoCloseFlag() == EsDataConstant.S_NEXT_YES);

            if (!TextUtils.isEmpty(rsp.getErrorText()) && rsp.getErrorCode() != 0) {
                data.setErrorText(rsp.getErrorText());
            }
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_LOG, data, tu, head, data.getErrorText());

            if(data.getStrategyType() == '\0') {
                InsertStopLossOpenStrategyOrders(tu, data);
                if (i == count -1 && head.getChain() ==  EsNativeProtocol.CSP_CHAIN_END) {
                    sendEvent(EsDataConstant.S_SRVEVENT_TRADE_ORDER, data, tu, head, data.getErrorText());
                }
            } else {
                if (data.getStrategyType() == EsTradeProtocol.TRD_ST_STSTOPLOSS) {
                    InsertStopLossOpenStrategyOrders(tu, data);
                }

                if (i == count -1 && head.getChain() ==  EsNativeProtocol.CSP_CHAIN_END) {
                    sendEvent(EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER, data, tu, head, data.getErrorText());
                }
            }

            // 清除该订单数据
            userOrderDataMap.remove(sessionId);
        }
    }

    //止损开仓 策略单下单
    private void InsertStopLossOpenStrategyOrders(STradeUser tu, OrderData order) {
        if (TextUtils.isEmpty(order.getOrderNo())) {
            return;
        }
        Map<String, InsertOrder> userStrategyOrderMap = tu.getStrategyOpenTempOrder();
        InsertOrder insertOrder;
        if (userStrategyOrderMap.size() == 0) {
            return;
        }

        String key = String.valueOf(order.getOrderReqId());
        for (int i =0; i < 3; i++) {
            insertOrder= userStrategyOrderMap.get(key);

            if (order.getStrategyType() == EsTradeProtocol.TRD_ST_STSTOPLOSS) {
                insertOrder.setStParentNo(order.getOrderNo());
            } else {
                insertOrder.setParentNo(order.getOrderNo());
            }

            int ret = mTradeApi.TradeOrderInsert(tu, insertOrder);
            if (ret < 0) {
//                sendEvent(EsDataConstant.S_SRVEVENT_STOPLOSSOPEN_FAIL, insertOrder);
            }
            userStrategyOrderMap.remove(key);

            if (userStrategyOrderMap.size() > 0) {
                Set<String> keySet = userStrategyOrderMap.keySet();
                for (String value : keySet) {
                    key = value;
                    break;
                }
            }
        }
    }

    private void sendEvent(int action, Object data, STradeUser tu, CspSessionHead head, String errortext) {
        if (tu == null || tu.getTradeLogin() == null) {
            return;
        }

        if (action == EsDataConstant.S_SRVEVENT_TRADE_MATCH || action == EsDataConstant.S_SRVEVENT_TRADE_ORDER || action == EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER
                    || action == EsDataConstant.S_SRVEVENT_TRADE_POSITION) {
            if (tu.getTradeState() <= EsTradeProtocol.TS_DEPOSITQRY || tu.getDataInitCompleted() != 1) {
                return;
            }
        }

        String errorMessage = EsDataApi.getErrorMessage(tu.getTradeLogin().getAddrTypeNo(), (int) head.getErrorCode(), errortext);

        TradeEvent event = new TradeEvent.Builder(action)
                .setCompanyNo(tu.getTradeLogin().getCompanyNo())
                .setUserNo(tu.getTradeLogin().getUserNo())
                .setAddressNo(tu.getTradeLogin().getAddrTypeNo())
                .setData(data)
                .setSrvChain(head.getChain() == EsNativeProtocol.CSP_CHAIN_END)
                .setSrvErrorCode((int) head.getErrorCode())
                .setSrvErrorText(errorMessage)
                .buildEvent();

        sendEvent(event);
    }

    private void OnTStrategyOrder(STradeUser tu, byte[] buf, CspSessionHead head) {
        TrdOrderQryRsp data = new TrdOrderQryRsp(buf);
        if (head.getChain() != EsNativeProtocol.CSP_CHAIN_END) {
            TradeQryStrategyOrder(tu, data.getSerialId());
        } else {
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_STRATEGY_ORDER, null, tu, head, "");
        }
    }

    //定单查询应答
    private void OnTOrder(STradeUser tu, byte[] buf, CspSessionHead head) {
        TrdOrderQryRsp data = new TrdOrderQryRsp(buf);
        if (head.getChain() != EsNativeProtocol.CSP_CHAIN_END) {
            TradeQryOrder(tu, data.getSerialId());
        } else {
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_ORDER, null, tu, head, "");
        }
    }

    //澳交所参数 应答
    private void onSASXSystemParam(STradeUser tu, byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        Map<String, SASXSystemParamData> userSasxParamDataMap = tu.getSASXData();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdASXParamQryRsp rsp = new TrdASXParamQryRsp(struct);
            // 简单通过合约号长度，过滤部分不合法数据
            if (rsp == null || rsp.getCommodityNo() != null || rsp.getCommodityNo().length() <= 5) {
                continue;
            }

            SASXSystemParamData paramData = new SASXSystemParamData();
            paramData.setItemNo(rsp.getItemNo());
            paramData.setCommodityNo(rsp.getCommodityNo());
            paramData.setItemValue(rsp.getItemValue());
            paramData.setItemNum(rsp.getItemValue2());
            paramData.setItemValueDouble(rsp.getItemValueDouble());

            if (!userSasxParamDataMap.containsKey(rsp.getCommodityNo())) {
                userSasxParamDataMap.put(rsp.getCommodityNo(), paramData);
            }

            if (i == count -1) {
                sendEvent(EsDataConstant.S_SRVEVENT_ASX_PARAM, null, tu, head, "");
            }
        }

    }

    private void OnTMessage(STradeUser tu, byte[] buf, CspSessionHead head) {
//        int len = head.getFieldSize();
        int count = head.getFieldCount();

        ParseUtil util = ParseUtil.wrap(buf);
        for (int i = 0; i < count; i++) {
            if (util.getPoint() + 193 >= buf.length) {
                break;
            }

            int msgId = util.getInt();
            String company = util.getString(11);
            String userNo = util.getString(21);
            char level = util.getChar();
            String sendNo = util.getString(11);
            String sendDataTime = util.getString(21);
            String validDateTime = util.getString(21);
            String title = util.getString(101);
            short len = util.getShort();
            String content = util.getString(len);

            MessageData messageData = new MessageData();
            messageData.setMsgId(msgId);
            messageData.setCompanyNo(tu.getTradeLogin().getCompanyNo());
            messageData.setUserNo(tu.getTradeLogin().getUserNo());
            messageData.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
            messageData.setLevel(level);
            messageData.setSendNo(sendNo);
            messageData.setSendDateTime(sendDataTime);
            messageData.setValidDateTime(validDateTime);
            messageData.setTitle(title);
            messageData.setContent(content);

            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_MESSAGE, messageData, tu, head, "");
        }

        if (head.getFieldCount() == 0) {
            sendEvent(EsDataConstant.S_SRVEVENT_TRADE_MESSAGE, null, tu, head, "");
        }
    }

    private void OnFee(STradeUser tu, byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        byte[] struct = new byte[len];

       Map<String, TrdFeeParamQryRsp> userFee = tu.getFee();

        for (int i = 0; i < count; i++) {
            int start = i * len;
            System.arraycopy(buf, start, struct, 0, len);
            TrdFeeParamQryRsp rsp = TrdFeeParamQryRsp.toParse(struct);
            if (TextUtils.isEmpty(rsp.getContractNo())) {
                continue;
            }

            String key = String.format("%s_%c", rsp.getContractNo(), rsp.getOffset());
            userFee.put(key, rsp);
        }
    }

    private void OnTCommodity(STradeUser tu, byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        Log.d(TAG, "OnTCommodity len : " + len + ", count : " +count);

       Map<String, Commodity> userCommodityMap = tu.getCommoditys();

        byte[] struct = new byte[len];
        for (int i = 0; i < count; i++) {
            int start = i * len;
            System.arraycopy(buf, start, struct, 0, len);

            TrdCommodityQryRsp rsp = TrdCommodityQryRsp.toParse(struct);
            if (rsp == null || userCommodityMap.get(rsp.getCommodityNo()) != null) {
                continue;
            }

            // 可能是品种号也可能是交易所号
            String commodityNo = rsp.getCommodityNo();

            Commodity commodity = EsBaseApi.getInstance().getCommodity(commodityNo);
            if (commodity != null) {
                userCommodityMap.put(commodityNo, commodity);
            } else {
                // 那么就为交易所号
                List<Plate> plates = EsApiData.getInstance().getPlates();
                Plate plate = getPlate(plates, commodityNo);

                List<Commodity> commodityList = EsDataApi.getCommodityOfPlate(plate);
                for (Commodity commodity1 : commodityList) {
                    userCommodityMap.put(commodity1.getCommodityNo(), commodity1);
                }

                if (plate != null && commodityList.size() == 0 ) {
                    Log.d(TAG, "commodity list size : 0, plate no : " + plate.getPlateNo());
                }
            }

        }
    }

    private Plate getPlate(List<Plate> plates, String commodityNo) {
        Plate res = null;
        if (TextUtils.isEmpty(commodityNo)) {
            return res;
        }

        for (Plate plate : plates) {
            if (commodityNo.equals(plate.getPlateNo())) {
                res = plate;
                break;
            }
        }

        return res;
    }

    private void OnLogout(STradeUser tu, byte[] buf, CspSessionHead head) {
        sendEvent(EsDataConstant.S_SRVEVENT_TRADELOGOUT, null, tu, head, "");
    }

    private void InitReadyTRN(STradeUser tu, byte[] buf, CspSessionHead head) {
        tu.setDataInitCompleted((char) 1);
        sendEvent(EsDataConstant.S_SRVEVENT_TINITCOMPLETED, null, tu, head, "");
    }

    /**
     * 资金查询数据应答
     * @param tu
     * @param buf
     * @param head
     */
    private void OnTMoneyData(STradeUser tu, byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();

        ParseUtil util = ParseUtil.wrap(buf);
        int start = 0;
        for (int i = 0; i < count; i++) {
            TrdFundQryRsp rsp = new TrdFundQryRsp();

            String companyNo = util.getString(11);
            start += 11;
            String userNo = util.getString(21);
            start += 21;
            String currencyGroupNo = util.getString(11);
            start += 11;
            String currencyNo = util.getString(11);
            start += 11;
            double exchangeRate= util.getDouble();
            start += 8;
            short fundFieldCount = util.getUnsignedChar();

            List<TrdFundField> fundFieldList = new ArrayList<>();
            for (int j =0; j < fundFieldCount; j++) {
                TrdFundField trdFundField = new TrdFundField();
                trdFundField.setIndex(util.getUnsignedChar());
                start += 1;
                trdFundField.setValue(util.getDouble());
                start += 8;
                fundFieldList.add(trdFundField);
            }

            rsp.setCompanyNo(companyNo);
            rsp.setUserNo(userNo);
            rsp.setCurrencyGroupNo(currencyGroupNo);
            rsp.setCurrencyNo(currencyNo);
            rsp.setExchangeRate(exchangeRate);
            rsp.setFundFieldCount((char) fundFieldCount);
            rsp.setFieldData(fundFieldList);

            //非当前用户的资金信息，不处理
            if (!tu.getTradeLogin().getUserNo().equals(rsp.getUserNo())) {
                continue;
            }
            if (TextUtils.isEmpty(rsp.getCurrencyNo()) && TextUtils.isEmpty(rsp.getCurrencyGroupNo())) {
                continue;
            }

            if (TextUtils.isEmpty(rsp.getCurrencyGroupNo())) {
                rsp.setCurrencyGroupNo("Total");
            }

            MoneyData data = null;

            for (int j = 0; j < tu.getMoneyIndex(); j++) {
                if (rsp.getCompanyNo().equals(tu.getMoney()[i].getCurrencyNo()) && rsp.getCurrencyGroupNo().equals(tu.getMoney()[i].getCurrencyGroupNo())) {
                    data = tu.getMoney()[i];
                    break;
                }
            }

            MoneyData baseData = null;
            MoneyData totalData = tu.getTotalMoney();
            baseData = tu.getBaseMoney().get(rsp.getCurrencyGroupNo());
            if (baseData == null) {
                baseData = new MoneyData();
            }

            //添加一个资金信息
            if (data == null) {
                if (tu.getMoneyIndex() >= tu.getMoney().length) {
                    return;
                };

                checkArray(tu.getMoney(), tu.getMoneyIndex());

                data = tu.getMoney()[tu.getMoneyIndex()];
                tu.setMoneyIndex((short) (tu.getMoneyIndex() + 1));
                data.setCompanyNo(rsp.getCompanyNo());
                data.setUserNo(rsp.getUserNo());
                data.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
                data.setCurrencyGroupNo(rsp.getCurrencyGroupNo());
                data.setCurrencyNo(rsp.getCurrencyNo());
                data.setExchangeRate(rsp.getExchangeRate());

                baseData.setCompanyNo(rsp.getCompanyNo());
                baseData.setUserNo(rsp.getUserNo());
                baseData.setCurrencyGroupNo(rsp.getCurrencyGroupNo());
                baseData.setCurrencyNo("Base");
                baseData.setExchangeRate(1);

                totalData.setCompanyNo(rsp.getCompanyNo());
                totalData.setUserNo(rsp.getUserNo());
                totalData.setCurrencyGroupNo("Total");
                totalData.setCurrencyNo("Base");
                totalData.setExchangeRate(1);
            }

            MoneyField[] baseDataEx = baseData.getDataEx();
            MoneyField[] totalDataEx = totalData.getDataEx();
            MoneyField[] dataEx = data.getDataEx();

            //更新可变字段处理
            for (int j =0; j< rsp.getFundFieldCount(); j++) {
                TrdFundField field = rsp.getFieldData().get(j);
                if (field.getIndex() >= 128) {
                    continue;
                }

                checkArray(baseDataEx, field.getIndex());
                checkArray(dataEx, field.getIndex());

                baseDataEx[field.getIndex()].setIndex(field.getIndex());
                baseDataEx[field.getIndex()].setValue(baseDataEx[field.getIndex()].getValue() + (field.getValue() - dataEx[field.getIndex()].getValue())
                        * data.getExchangeRate());

                checkArray(totalDataEx, field.getIndex());

                totalDataEx[field.getIndex()].setIndex(field.getIndex());
                totalDataEx[field.getIndex()].setValue(totalDataEx[field.getIndex()].getValue() + (field.getValue() - data.getDataEx()[field.getIndex()].getValue())
                        * data.getExchangeRate());

                dataEx[field.getIndex()].setIndex(field.getIndex());
                dataEx[field.getIndex()].setValue(field.getValue());
            }

            checkArray(dataEx, new int[]{EsDataConstant.S_NETPROFIT, EsDataConstant.S_PROFITRATE, EsDataConstant.S_PREAVAILABLE, EsDataConstant.S_CASHIN,
                    EsDataConstant.S_CASHOUT, EsDataConstant.S_ADJUST, EsDataConstant.S_RISKRATE, EsDataConstant.S_EQUITY, EsDataConstant.S_COVERPROFITTBT,
                    EsDataConstant.S_COVERPROFIT});

            dataEx[EsDataConstant.S_NETPROFIT].setIndex(EsDataConstant.S_NETPROFIT);
            dataEx[EsDataConstant.S_PROFITRATE].setIndex(EsDataConstant.S_PROFITRATE);

            if (Math.abs(dataEx[EsDataConstant.S_COVERPROFITTBT].getIndex()) < 0.0001 && Math.abs(dataEx[EsDataConstant.S_COVERPROFIT].getValue()) > 0.0001) {
                dataEx[EsDataConstant.S_NETPROFIT].setValue(dataEx[EsDataConstant.S_COVERPROFIT].getValue() - dataEx[EsDataConstant.S_FEE].getValue());
            } else {
                dataEx[EsDataConstant.S_NETPROFIT].setValue(dataEx[EsDataConstant.S_COVERPROFITTBT].getValue() - dataEx[EsDataConstant.S_FEE].getValue());
            }

            double tmp = dataEx[EsDataConstant.S_PREAVAILABLE].getValue() + dataEx[EsDataConstant.S_CASHIN].getValue() - dataEx[EsDataConstant.S_CASHOUT].getValue()
                    + dataEx[EsDataConstant.S_ADJUST].getValue();

            if (Math.abs(tmp) > 0.0001) {
                dataEx[EsDataConstant.S_PROFITRATE].setValue(dataEx[EsDataConstant.S_NETPROFIT].getValue() / tmp);
            } else {
                dataEx[EsDataConstant.S_PROFITRATE].setValue(0);
            }

            dataEx[EsDataConstant.S_RISKRATE].setIndex(EsDataConstant.S_RISKRATE);
            if (Math.abs(dataEx[EsDataConstant.S_EQUITY].getValue()) > 0.0001) {
                dataEx[EsDataConstant.S_RISKRATE].setValue(dataEx[EsDataConstant.S_DEPOSIT].getValue() / dataEx[EsDataConstant.S_EQUITY].getValue());
            } else {
                dataEx[EsDataConstant.S_RISKRATE].setValue(0);
            }

            checkArray(baseDataEx, new int[]{EsDataConstant.S_NETPROFIT, EsDataConstant.S_PROFITRATE, EsDataConstant.S_COVERPROFITTBT, EsDataConstant.S_PREAVAILABLE,
                    EsDataConstant.S_CASHIN, EsDataConstant.S_CASHOUT, EsDataConstant.S_ADJUST, EsDataConstant.S_RISKRATE});

            //计算基币信息；
            baseDataEx[EsDataConstant.S_NETPROFIT].setIndex(EsDataConstant.S_NETPROFIT);
            baseDataEx[EsDataConstant.S_PROFITRATE].setIndex(EsDataConstant.S_PROFITRATE);
            if (Math.abs(baseDataEx[EsDataConstant.S_COVERPROFITTBT].getValue()) > 0.0001 && Math.abs(baseDataEx[EsDataConstant.S_COVERPROFIT].getValue()) > 0.0001) {
                baseDataEx[EsDataConstant.S_NETPROFIT].setValue(baseDataEx[EsDataConstant.S_COVERPROFIT].getValue() - baseDataEx[EsDataConstant.S_FEE].getValue());
            } else {
                baseDataEx[EsDataConstant.S_NETPROFIT].setValue(baseDataEx[EsDataConstant.S_COVERPROFITTBT].getValue() - baseDataEx[EsDataConstant.S_FEE].getValue());
            }

            tmp = baseDataEx[EsDataConstant.S_PREAVAILABLE].getValue() + baseDataEx[EsDataConstant.S_CASHIN].getValue() - baseDataEx[EsDataConstant.S_CASHOUT].getValue()
                        + baseDataEx[EsDataConstant.S_ADJUST].getValue();

            if (Math.abs(tmp) > 0.0001) {
                baseDataEx[EsDataConstant.S_PROFITRATE].setValue(baseDataEx[EsDataConstant.S_NETPROFIT].getValue() / tmp);
            } else {
                baseDataEx[EsDataConstant.S_PROFITRATE].setValue(0);
            }

            if ("DipperTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
                baseDataEx[EsDataConstant.S_RISKRATE].setIndex(EsDataConstant.S_RISKRATE);
                if (Math.abs(baseDataEx[EsDataConstant.S_EQUITY].getValue()) > 0.0001) {
                    baseDataEx[EsDataConstant.S_RISKRATE].setValue(baseDataEx[EsDataConstant.S_DEPOSIT].getValue() / baseDataEx[EsDataConstant.S_EQUITY].getValue());
                } else {
                    baseDataEx[EsDataConstant.S_RISKRATE].setValue(0);
                }

                checkArray(totalDataEx, new int[]{EsDataConstant.S_NETPROFIT, EsDataConstant.S_PROFITRATE, EsDataConstant.S_COVERPROFITTBT, EsDataConstant.S_COVERPROFIT,
                        EsDataConstant.S_FEE, EsDataConstant.S_PREAVAILABLE, EsDataConstant.S_CASHIN, EsDataConstant.S_CASHOUT, EsDataConstant.S_ADJUST,
                        EsDataConstant.S_RISKRATE, EsDataConstant.S_NETPROFIT, EsDataConstant.S_PROFITRATE});

                if(Math.abs(totalDataEx[EsDataConstant.S_COVERPROFITTBT].getValue()) < 0.0001  && Math.abs(totalDataEx[EsDataConstant.S_COVERPROFIT].getValue()) > 0.0001) {
                    totalDataEx[EsDataConstant.S_NETPROFIT].setValue(totalDataEx[EsDataConstant.S_COVERPROFIT].getValue() - totalDataEx[EsDataConstant.S_FEE].getValue());
                } else {
                    totalDataEx[EsDataConstant.S_NETPROFIT].setValue(totalDataEx[EsDataConstant.S_COVERPROFITTBT].getValue() - totalDataEx[EsDataConstant.S_FEE].getValue());
                }

                tmp = totalDataEx[EsDataConstant.S_PREAVAILABLE].getValue() + totalDataEx[EsDataConstant.S_CASHIN].getValue()
                        - totalDataEx[EsDataConstant.S_CASHOUT].getValue() +totalDataEx[EsDataConstant.S_ADJUST].getValue() ;

                if( Math.abs(tmp) > 0.0001) {
                    totalDataEx[EsDataConstant.S_PROFITRATE].setValue(totalDataEx[EsDataConstant.S_NETPROFIT].getValue() / tmp);
                } else {
                    totalDataEx[EsDataConstant.S_PROFITRATE].setValue(0);
                }

               totalDataEx[EsDataConstant.S_RISKRATE].setIndex(EsDataConstant.S_RISKRATE);
                if(Math.abs(totalDataEx[EsDataConstant.S_EQUITY].getValue()) > 0.0001) {
                    totalDataEx[EsDataConstant.S_RISKRATE].setValue(totalDataEx[EsDataConstant.S_DEPOSIT].getValue() / totalDataEx[EsDataConstant.S_EQUITY].getValue());
                } else {
                    totalDataEx[EsDataConstant.S_RISKRATE].setValue(0);
                }

                //资金变化回调
                TradeEvent event = new TradeEvent.Builder(EsDataConstant.S_SRVEVENT_TRADE_FUND)
                        .setCompanyNo(tu.getTradeLogin().getCompanyNo())
                        .setUserNo(tu.getTradeLogin().getUserNo())
                        .setAddressNo(tu.getTradeLogin().getAddrTypeNo())
                        .setSrvErrorCode((int) head.getErrorCode()).buildEvent();
                sendEvent(event);
            }
            
            if (head.getFieldCount() == 0) {
                TradeEvent event = new TradeEvent.Builder(EsDataConstant.S_SRVEVENT_TRADE_FUND)
                        .setCompanyNo(tu.getTradeLogin().getCompanyNo())
                        .setUserNo(tu.getTradeLogin().getUserNo())
                        .setAddressNo(tu.getTradeLogin().getAddrTypeNo())
                        .setSrvErrorCode((int) head.getErrorCode()).buildEvent();
                sendEvent(event);
            }
        }
    }

    private void checkArray(Object[] array, int index) {
        if (array.length < index) {
            return;
        }
        if (array[index] == null) {
            Class cls = array.getClass().getComponentType();
            try {
                array[index] = cls.newInstance();
            } catch (IllegalAccessException | InstantiationException e) {
                e.printStackTrace();
            }
        }
    }

    private void checkArray(Object[] array, int[] index) {
        for (int i = 0; i < index.length; i++) {
            checkArray(array, index[i]);
        }
    }

    /**
     *  结算单确认状态查询
     * @param tu
     * @param buf
     * @param head
     */
    private void OnTQryBillConfirmStatus(STradeUser tu, byte[] buf, CspSessionHead head) {
        int len = head.getFieldSize();
        int count = head.getFieldCount();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdBillConfirmStatusQryRsp rsp = new TrdBillConfirmStatusQryRsp(struct);
            if (rsp != null && rsp.getConfirmed() == 1 && tu.getTradeState() == EsTradeProtocol.TS_LOGINED) {
                tu.setTradeState((short) EsTradeProtocol.TS_BILLCONFIRMED);
            }
        }
    }

    private void tradeRecvCall(STradeUser tu, CspSessionHead head) {
        EsLog.d(TAG, "protocolCode : " + head.getProtocolCode() +", error cdoe : " + head.getErrorCode() + ", trade state : " + tu.getTradeState());
        if (tu.getTradeState() >= EsTradeProtocol.TS_LOGINED && tu.getTradeState() <= EsTradeProtocol.TS_DEPOSITQRY) {
            if ((head.getProtocolCode() == EsTradeProtocol.CMD_TRD_LOGIN_RSP || head.getProtocolCode() == EsTradeProtocol.CMD_TRD_SMSAUTH_RSP)
                &&  head.getErrorCode() == 0
                && tu.getTradeState() == EsTradeProtocol.TS_LOGINED) {
                TrdQryBillConfirmStatus(tu);
            } else if (head.getProtocolCode() == EsTradeProtocol.CMD_TRD_BILLCONFIRMSTATUS_QRY_RSP) {
                if (tu.getTradeState() == EsTradeProtocol.TS_BILLCONFIRMED) {
                    tu.setTradeState((short) (tu.getTradeState() +1));
                    TradeQryMoney(tu);
                } else {
                    //账单查询
                    tu.setTradeState((short) (tu.getTradeState() +1));
                    TrdQryBill(tu);
                }
            } else if (head.getProtocolCode() == EsTradeProtocol.CMD_TRD_BILLCONFIRM_RSP && tu.getTradeState() == EsTradeProtocol.TS_BILLCONFIRMED){
                tu.setTradeState((short) (tu.getTradeState() +1));
                TradeQryMoney(tu);
            } else if ((head.getProtocolCode() == EsTradeProtocol.CMD_TRD_FUND_CHG_RTN || head.getProtocolCode() == EsTradeProtocol.CMD_TRD_FUND_QRY_RSP)
                        && head.getChain() == EsTradeProtocol.CSP_CHAIN_END && tu.getTradeState() == EsTradeProtocol.TS_MONEYQRY) {
                tu.setTradeState((short) (tu.getTradeState() +1));
                TradeQryCommodity(tu);
            } else if (head.getProtocolCode() == EsTradeProtocol.CMD_TRD_COMMODITY_QRY_RSP && head.getChain() == EsTradeProtocol.CSP_CHAIN_END
                            && tu.getTradeState() == EsTradeProtocol.TS_COMMODITYQRY) {
                tu.setTradeState((short) (tu.getTradeState() +1));
                // 北斗星v2后台不会主动推送持仓数据
                TradeQryPosition(tu);

                tu.setTradeState((short) (tu.getTradeState() +1));
                // 北斗星v2后台不查询没有数据初始化完成回报
                TradeQryOrder(tu, 0);

                tu.setTradeState((short) (tu.getTradeState() +1));
                TradeQryStrategyOrder(tu, 0);
            } else if (head.getProtocolCode() == EsTradeProtocol.CMD_TRD_STRATEGYORDER_QRY_RSP && head.getChain() == EsTradeProtocol.CSP_CHAIN_END
                    && tu.getTradeState() == EsTradeProtocol.TS_STRATEGYQRY) {
                tu.setTradeState((short) (tu.getTradeState() +1));

                tu.setTradeState((short) (tu.getTradeState() +1));
                TradeQryFee(tu);
            } else if (head.getProtocolCode() == EsTradeProtocol.CMD_TRD_FEEPARAM_QRY_RSP && head.getChain() == EsTradeProtocol.CSP_CHAIN_END
                    && tu.getTradeState() == EsTradeProtocol.TS_FEEQRY) {

                tu.setTradeState((short) (tu.getTradeState() +1));
                TradeQryDeposit(tu);

                TradeEvent event = new TradeEvent.Builder(EsDataConstant.S_SRVEVENT_TRADELOGINED)
                                                    .setCompanyNo(tu.getTradeLogin().getCompanyNo())
                                                    .setUserNo(tu.getTradeLogin().getUserNo())
                                                    .setAddressNo(tu.getTradeLogin().getAddrTypeNo())
                                                    .setSrvErrorCode((int) head.getErrorCode())
                                                    .buildEvent();
                sendEvent(event);
            } else if (head.getProtocolCode() == EsTradeProtocol.CMD_TRD_DEPOSITPARAM_QRY_RSP && head.getChain() == EsTradeProtocol.CSP_CHAIN_END
                    && tu.getTradeState() == EsTradeProtocol.TS_DEPOSITQRY) {

                tu.setTradeState((short) (tu.getTradeState() +1));

                if (tu.getDataInitCompleted() == 1) {
                    TradeEvent event = new TradeEvent.Builder(EsDataConstant.S_SRVEVENT_TINITCOMPLETED)
                            .setCompanyNo(tu.getTradeLogin().getCompanyNo())
                            .setUserNo(tu.getTradeLogin().getUserNo())
                            .setAddressNo(tu.getTradeLogin().getAddrTypeNo())
                            .setSrvErrorCode((int) head.getErrorCode())
                            .buildEvent();
                    sendEvent(event);
                }
            }
        }
    }

    private void TradeQryDeposit(STradeUser tu) {
        TrdDepositParamQryReq data = new TrdDepositParamQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_DEPOSITPARAM_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdDepositParamQryReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void TradeQryFee(STradeUser tu) {
        TrdFeeParamQryReq data = new TrdFeeParamQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_FEEPARAM_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdFeeParamQryReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void TradeQryStrategyOrder(STradeUser tu, int serilId) {
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_STRATEGYORDER_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdOrderQryReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        TrdOrderQryReq data = new TrdOrderQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());
        data.setSerialId(serilId);

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void TradeQryOrder(STradeUser tu, int serilId) {
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_ORDER_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdOrderQryReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        TrdOrderQryReq data = new TrdOrderQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());
        data.setSerialId(serilId);

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void TradeQryPosition(STradeUser tu) {
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_POSITION_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdPositionQryReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        TrdPositionQryReq data = new TrdPositionQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void TradeQryCommodity(STradeUser tu) {
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_COMMODITY_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdCommodityQryReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        TrdCommodityQryReq data = new TrdCommodityQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void TrdQryBill(STradeUser tu) {
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_BILL_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdBillQryReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setBillQrySessionId((int) head.getSessionId());
        tu.setBillData(null);

        TrdBillQryReq data = new TrdBillQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void TradeQryMoney(STradeUser tu) {
        TrdFundQryReq data = new TrdFundQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_FUND_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdFundQryReq.STRUCT_LENGTH);
//        head.setProtocolVer(EsNativeProtocol.TRD_PROTOCOL_VER);
        head.setSessionId(mTradeApi.AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());
        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void TrdQryBillConfirmStatus(STradeUser tu) {
        TrdBillConfirmStatusQryReq data = new TrdBillConfirmStatusQryReq();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());
        data.setBillDate("");

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_BILLCONFIRMSTATUS_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdBillConfirmStatusQryReq.STRUCT_LENGTH);
        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void ClearUserInfo(STradeUser tu) {
        if (tu == null) {
            return;
        }
        tu.getPositions().clear();
        tu.getSumPositions().clear();
        tu.setMoney(new MoneyData[32]);
        tu.setMoneyIndex((short) 0);
        if ("DipperTradeApi".equals(tu.getTradeLogin().getTradeApi()) || "EstarTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            tu.getBaseMoney().clear();
        }
    }

    private void OnLogin(STradeUser tu, byte[] buf, CspSessionHead head) {
        Log.d(TAG, "OnLogin error code : " + head.getErrorCode());

        TradeLogin tradeLogin = tu.getTradeLogin();
        TradeLoginRsp data = new TradeLoginRsp();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setAddrTypeNo(tu.getTradeLogin().getAddrTypeNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());
        data.setErrorCode((int) head.getErrorCode());

        if (head.getErrorCode() == 0) {
            tu.setTradeState((short) 1);
            if (tu.getModifyPass() != null && tu.getModifyPass().length() != 0) {
                tu.setPassword(tu.getModifyPass());
            }
        } else {
            if ("DipperTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
                switch ((int) head.getErrorCode()) {
                    case 10003:
                        if (head.getFieldSize() != 0) {
                            TrdLoginRsp trdLoginRsp = TrdLoginRsp.toParse(buf);
                            if (UpdateUserInfo(tu,head, trdLoginRsp)) {
                                return;
                            }
                        }
                        TrdQrySMSAuthMethod(tu);
                        return;
                    case 10065:
                    case 10066:
                    case 10067:
                    case 10068:
                        TradeEvent event = new TradeEvent.Builder(EsDataConstant.S_SRVEVENT_RESET_PWD).setSrvErrorCode((int)head.getErrorCode()).buildEvent();
                        sendEvent(event);
                        return;
                    default:
                        break;
                }
            }
        }

        //登录回调
        if (head.getFieldSize() != 0) {
            TrdLoginRsp rsp = TrdLoginRsp.toParse(buf);
            data.setForceChgPsw((byte) rsp.getForceChgPsw());
            data.setErrorText(rsp.getErrorText());
            // 看看 char == 1还是 == '1'
            if (rsp.getForceChgPsw() == 1) {
                mTradeForceChangePwdUser = tu;
            }
            TradeEvent event = new TradeEvent.Builder(EsDataConstant.S_SRVEVENT_TRADELOGIN)
                    .setData(data)
                    .setSrvErrorCode((int) head.getErrorCode())
                    .setCompanyNo(tradeLogin.getCompanyNo())
                    .setUserNo(tradeLogin.getUserNo())
                    .setAddressNo(tradeLogin.getAddrTypeNo()).buildEvent();
            sendEvent(event);

            if (head.getErrorCode() != 0) {
                //已经登陆过，密码错误为其他机器修改了密码
                if (tu.getTradeState() == 1) {
                    //网关将密码错误的错误码全部统一成990204，但是之前的还要保留
                    if (head.getErrorCode() == 990204 ||
                            ("DipperTradeApi".equals(tu.getTradeLogin().getTradeApi()) && head.getErrorCode() == 10008) ||  //北斗星密码错误
                            ("Daystar".equals(tu.getTradeLogin().getTradeApi()) && head.getErrorCode() == 10008) || //启明星密码错误
                            ("Estar".equals(tu.getTradeLogin().getTradeApi()) && head.getErrorCode() == 10003) ||    //易盛云仿真 密码错误
                            ("Ctp".equals(tu.getTradeLogin().getTradeApi()) && head.getErrorCode() == 3) ||  //ctp密码错误
                            ("Kingstar".equals(tu.getTradeLogin().getTradeApi()) && head.getErrorCode() == 40454)) {    //金仕达密码错误
                        TradeEvent event1 = new TradeEvent.Builder(EsDataConstant.S_SRVEVENT_TRADELOGOUT)
                                .setSrvErrorCode((int) head.getErrorCode()).buildEvent();
                        sendEvent(event1);
                    }
                }
                return;
            }
            if (UpdateUserInfo(tu, head, rsp)) {
                return;
            }
            SendPushInformation(tu);
        }
    }

    private void SendPushInformation(STradeUser tu) { ;
        SPushClientInfo pushClientInfo = EsApiData.getInstance().getPushClientInfo();
        if (pushClientInfo == null) {
            return;
        }

        PushClientInfoNotice req = new PushClientInfoNotice();
        req.setAppId(pushClientInfo.getAppId());
        req.setAppKey(pushClientInfo.getAppKey());
        req.setAppMasterSecret(pushClientInfo.getAppMasterSecret());
        PushClient pushClient = new PushClient();
        pushClient.setCID(pushClientInfo.getCID());
        pushClient.setDeviceType(pushClientInfo.getDeviceType());
        req.setClient(pushClient);

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_PUSH_CLIENT_INFO_NOTICE,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, PushClientInfoNotice.STRUCT_LENGTH);
        head.setLangType(pushClientInfo.getLangType());

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());
    }

    private boolean UpdateUserInfo(STradeUser tu, CspSessionHead head, TrdLoginRsp trdLoginRsp) {
        String lastLoginInfo = trdLoginRsp.getLastLoginInfo();
        String[] array = lastLoginInfo.split(";");
        String ip = array[0].substring("ip=".length());
        String port = array[1].substring("port=".length());
        tu.getIp()[1] = ip;
        tu.getPort()[1] = Short.parseShort(port);

//        TradeLog(tu);

        if (!"EstarTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            tu.getTradeLogin().getTradeDate()[0] = trdLoginRsp.getTradeDate();
        } else {
            tu.getTradeLogin().getTradeDate()[0] = trdLoginRsp.getTradeDate();
            tu.getTradeLogin().getTradeDate()[1] = trdLoginRsp.getLastSettleTime();
        }

//        if (tu.getTradeDate()[0].length() != 0 && (!tu.getTradeDate()[0].equals(tu.getTradeLogin().getTradeDate()[0]) || ! tu.getTradeDate()[1].equals(tu.getTradeLogin().getTradeDate()[1]))) {
//
//        }

        if (tu.getTradeDate()[0].length() != 0 && tu.getTradeDate() != tu.getTradeLogin().getTradeDate()) {
            TradeEvent event = new TradeEvent.Builder(EsDataConstant.S_SRVEVENT_TRADEDATECHG)
                    .setData(trdLoginRsp)
                    .setSrvErrorCode((int) head.getErrorCode())
                    .setCompanyNo(tu.getTradeLogin().getCompanyNo())
                    .setUserNo(tu.getTradeLogin().getUserNo())
                    .setAddressNo(tu.getTradeLogin().getAddrTypeNo()).buildEvent();
            sendEvent(event);

            tu.getTradeDate()[0] = tu.getTradeLogin().getTradeDate()[0];
            tu.getTradeDate()[1] = tu.getTradeLogin().getTradeDate()[1];

            return true;
        } else {
            tu.getTradeDate()[0] = tu.getTradeLogin().getTradeDate()[0];
            tu.getTradeDate()[1] = tu.getTradeLogin().getTradeDate()[1];
        }

        return false;
    }

    private void TrdQrySMSAuthMethod(STradeUser tu) {
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_SECONDINFO_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdSecondInfoReq.STRUCT_LENGTH);
        head.setSessionId(mTradeApi.AddTSessionId(tu));

        TrdSecondInfoReq data = new TrdSecondInfoReq();

        sendTcpMsg(EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
    }

    private void PhoneAuthReq() {
        CspAuthReq req = new CspAuthReq();
        req.setDisturb0((int)( Math.random () * ( 352324 +1) ));
        req.setSubSystemType(EsNativeProtocol.CSP_SUBSYSTEM_TRADE);
        req.setDisturb1((int)( Math.random () * ( 352324 +1) ));
        req.setDisturb2((int)( Math.random () * ( 352324 +1) ));
        req.setDisturb3((int)( Math.random () * ( 352324 +1) ));
        req.setRsaPubKey(EsTradeProtocol.G_RSAPUBKEY);
        req.setDisturb4((int)( Math.random () * ( 352324 +1) ));
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_CSP_AUTHREQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, CspAuthReq.STRUCT_LENGTH);
        sendTcpMsg(EsNativeProtocol.CSP_FRAME_LZO, head, req.beanToByte());
    }

    private void OnAuth(STradeUser tu, byte[] buf, CspSessionHead head) {
        Log.d(TAG, "OnAuth error code : " + head.getErrorCode());
        //LoginReq()
        if (head.getErrorCode() != 0) {
            return;
        }

        //交易数据请求
        //登录请求
        TrdLoginReq trdLoginReq = new TrdLoginReq();
        trdLoginReq.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        trdLoginReq.setCompanyAddressNo(tu.getTradeLogin().getAddrTypeNo());
        trdLoginReq.setLoginNo(tu.getTradeLogin().getUserNo());
        trdLoginReq.setLoginPsw(tu.getPassword());
        if (tu.getNewPass() != null && tu.getNewPass().length() != 0) {
            trdLoginReq.setNewPsw(tu.getNewPass());
            tu.setModifyPass(tu.getNewPass());
        }
        trdLoginReq.setTerminalType(EsNativeProtocol.PkgAndroid);
        trdLoginReq.setAppCode(String.format("EStar_%s", EsNativeProtocol.API_VERSION_CODE));
        trdLoginReq.setAppVersionCode(String.format("EStar_%s", EsNativeProtocol.API_PRODUCT_VERSION));
        trdLoginReq.setLoginInfo(tu.getLoginInfo());

        if ("KingstarctTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            trdLoginReq.setSystemInfoFlag(tu.getTradeLogin().getSystemInfoLen());
        } else {
            trdLoginReq.setSystemInfoLen(tu.getTradeLogin().getSystemInfoLen());
            trdLoginReq.setSystemInfo(tu.getTradeLogin().getSystemInfo());
            trdLoginReq.setSystemInfoIntegrity(tu.getTradeLogin().getSystemInfoIntegrity());
            trdLoginReq.setSystemInfoFlag(tu.getTradeLogin().getSystemInfoFlag());
        }

        CspSessionHead cspSessionHead = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_LOGIN_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdLoginReq.STRUCT_LENGTH);
        sendTcpMsg(EsNativeProtocol.CSP_FRAME_LZO_IDEA, cspSessionHead, trdLoginReq.beanToByte());
    }

    private STradeUser getUserByKey(int key) {
        STradeUser res = null;
       List<STradeUser> tradeUserList = EsTradeData.getInstance().getTradeUserList();

       for (STradeUser user : tradeUserList) {
           if (user != null && user.getTcpClient() == key) {
               res = user;
               break;
           }
       }
       return res;
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        return super.equals(obj);
    }
}
