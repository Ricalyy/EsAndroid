package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/20
 */
public class TrdASXParamQryRsp extends ApiStruct {

    public final static short STRUCT_LENGTH = 48;

    private String ItemNo;             ///< 项目编号
    private String CommodityNo;        ///< 品种编号
    private int ItemValue;          ///< 项目值（周期数-c）
    private int ItemValue2;         ///< 项目值字符串类型值（计息次数-Num）
    private double ItemValueDouble;    ///< 项目值浮点型数据值（周期利率-Ratio）

    public TrdASXParamQryRsp(byte[] struct) {
        byteToBean(struct);
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(ItemNo, 11));
        buffer.put(stringToByte(CommodityNo, 21));
        buffer.putInt(ItemValue);
        buffer.putInt(ItemValue2);
        buffer.putDouble(ItemValueDouble);

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getItemNo() {
        return ItemNo;
    }

    public void setItemNo(String itemNo) {
        ItemNo = itemNo;
    }

    public String getCommodityNo() {
        return CommodityNo;
    }

    public void setCommodityNo(String commodityNo) {
        CommodityNo = commodityNo;
    }

    public int getItemValue() {
        return ItemValue;
    }

    public void setItemValue(int itemValue) {
        ItemValue = itemValue;
    }

    public int getItemValue2() {
        return ItemValue2;
    }

    public void setItemValue2(int itemValue2) {
        ItemValue2 = itemValue2;
    }

    public double getItemValueDouble() {
        return ItemValueDouble;
    }

    public void setItemValueDouble(double itemValueDouble) {
        ItemValueDouble = itemValueDouble;
    }
}
