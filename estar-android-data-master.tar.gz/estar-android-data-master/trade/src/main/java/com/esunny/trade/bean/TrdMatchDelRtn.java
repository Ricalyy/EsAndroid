package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/12
 */
public class TrdMatchDelRtn extends ApiStruct {

    private String CompanyNo;                                //经纪公司编号
    private String UserNo;                                    //资金账号
    private String MatchNo;                                //成交号
    private String ContractNo;                                //合约编号
    private char Direct;                                    //买卖
    private int StreamId;                                //流号

    public TrdMatchDelRtn(byte[] struct) {
        byteToBean(struct);
    }

    public static TrdMatchDelRtn toParse(byte[] struct) {
        return new TrdMatchDelRtn(struct);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setCompanyNo(util.getString(11));
        setUserNo(util.getString(21));
        setMatchNo(util.getString(21));
        setContractNo(util.getString(31));
        setDirect(util.getChar());
        setStreamId(util.getInt());
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getMatchNo() {
        return MatchNo;
    }

    public void setMatchNo(String matchNo) {
        MatchNo = matchNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public int getStreamId() {
        return StreamId;
    }

    public void setStreamId(int streamId) {
        StreamId = streamId;
    }
}
