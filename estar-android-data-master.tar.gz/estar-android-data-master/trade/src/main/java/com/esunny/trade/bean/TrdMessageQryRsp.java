package com.esunny.trade.bean;

/**
 * @author Peter Fu
 * @date 2020/11/19
 */
public class TrdMessageQryRsp {
    private int MsgId;                                    //消息Id
    private String CompanyNo;                                //经纪公司编号
    private String UserNo;                                    //接收者
    private char Level;                                    //消息级别
    private String SendNo;                                    //发送者
    private String SendDateTime;                            //发送时间
    private String ValidDateTime;                            //有效时间
    private String Title;                                    //标题
    private String Content;                                //消息内容

    public int getMsgId() {
        return MsgId;
    }

    public void setMsgId(int msgId) {
        MsgId = msgId;
    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public char getLevel() {
        return Level;
    }

    public void setLevel(char level) {
        Level = level;
    }

    public String getSendNo() {
        return SendNo;
    }

    public void setSendNo(String sendNo) {
        SendNo = sendNo;
    }

    public String getSendDateTime() {
        return SendDateTime;
    }

    public void setSendDateTime(String sendDateTime) {
        SendDateTime = sendDateTime;
    }

    public String getValidDateTime() {
        return ValidDateTime;
    }

    public void setValidDateTime(String validDateTime) {
        ValidDateTime = validDateTime;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }
}
