package com.esunny.trade;

import android.content.Context;
import android.text.TextUtils;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.EsDataApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.Interface.IGetAddress;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.api.server.EsTradeApi;
import com.esunny.data.api.server.RoutingTable;
import com.esunny.data.bean.AddrInfo;
import com.esunny.data.bean.Address;
import com.esunny.data.bean.BillConfirmReq;
import com.esunny.data.bean.CloudTradeCompany;
import com.esunny.data.bean.Commodity;
import com.esunny.data.bean.Contract;
import com.esunny.data.bean.InsertOrder;
import com.esunny.data.bean.MatchData;
import com.esunny.data.bean.MoneyData;
import com.esunny.data.bean.OrderData;
import com.esunny.data.bean.PkgCompanyCloudMapRsp;
import com.esunny.data.bean.PositionData;
import com.esunny.data.bean.PushClientInfo;
import com.esunny.data.bean.TradeLogin;
import com.esunny.data.util.EsLog;
import com.esunny.data.util.EsNetHelper;
import com.esunny.mobile.EsApiData;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.UnixJNI;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.mobile.bean.rsp.PkgCloudAddrRsp;
import com.esunny.mobile.bean.rsp.PkgCompanyAddrRsp;
import com.esunny.data.bean.SPushClientInfo;
import com.esunny.trade.bean.STradeUser;
import com.esunny.trade.bean.TrdBillConfirmReq;
import com.esunny.trade.bean.TrdBillQryReq;
import com.esunny.trade.bean.TrdChangeLoginPswReq;
import com.esunny.trade.bean.TrdDepositParamQryReq;
import com.esunny.trade.bean.TrdFeeParamQryReq;
import com.esunny.trade.bean.TrdLogoutReq;
import com.esunny.trade.bean.TrdMessageQryReq;
import com.esunny.trade.bean.TrdOrderActionReq;
import com.esunny.trade.bean.TrdOrderInsertReq;
import com.esunny.trade.bean.TrdOrderModifyReq;
import com.esunny.trade.database.TradeLogDataHelper;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import static com.esunny.data.api.EsDataConstant.TRADE_ORDER_INPUT_ERROR;

/**
 * @author Peter Fu
 * @date 2020/10/16
 */

@Route(path = RoutingTable.ES_TRADE_API)
public class EsTradeApiImpl implements EsTradeApi {

    private static final String TAG = "EsTradeApiImpl";

    @Override
    public void init(Context context) {

    }

    @Override
    public void setClientKey(String companyNo, String userNo, int key, CallbackDispatcher dispatcher) {
        Map<CallbackDispatcher, Integer> dispatcherMap = EsTradeData.getInstance().getClientMap();
       dispatcherMap.put(dispatcher, key);

       for (STradeUser tu : EsTradeData.getInstance().getTradeUserList()) {
           if (tu == null) continue;
           if (tu.getTradeLogin().getCompanyNo().equals(companyNo) && tu.getTradeLogin().getUserNo().equals(userNo)) {
               tu.setTcpClient(key);
               break;
           }
       }

    }

    @Override
    public CallbackDispatcher getDispatcher() {
        return new EsTradeDispatcher();
    }

    @Override
    public int tradeLogin(TradeLogin tradeLogin, String password, IGetAddress callback) {
        if (tradeLogin == null) {
            return EsDataConstant.TRADE_ORDER_INPUT_ERROR;
        }

        STradeUser tu = getTradeUser(tradeLogin.getCompanyNo(), tradeLogin.getUserNo());
        if (tu != null) {
            if (UnixJNI.S_IsOpenTcp(tu.getTcpClient())) {
                return EsNativeProtocol.S_LOGIN_TCPEXIST;
            }

            TradeLogin innerTradeLogin = tu.getTradeLogin();
            if (innerTradeLogin == null || !tradeLogin.getAddrTypeNo().equals(innerTradeLogin.getAddrTypeNo())) {
                if (tu.getTradeDate()[0].charAt(0) != '\0') {
                    return EsNativeProtocol.S_INIT_ACCOUNTEXIST;
                } else {
                    innerTradeLogin.setAddrTypeNo(tradeLogin.getAddrTypeNo());
                }
            }
        } else {
            tu = addTradeUser(tradeLogin, password, "");
            if (tu == null) {
                return EsNativeProtocol.S_LOGIN_INITFAIL;
            }
        }

        Map<String, PkgCloudAddrRsp> tradeAddress = EsApiData.getInstance().getCloudTradeAddress();
        Map<String, PkgCompanyAddrRsp> pkgCompanyAddrRspMap = EsApiData.getInstance().getTradeCompanyMap();
        Map<String, PkgCompanyCloudMapRsp> pkgCompanyCloudMapRspMap = EsApiData.getInstance().getCompanyAddrMap();

        List<PkgCloudAddrRsp> addressList = new ArrayList<>();

        PkgCompanyAddrRsp pkgCompanyAddrRsp = pkgCompanyAddrRspMap.get(String.format("%s_%s", tradeLogin.getCompanyNo(), tradeLogin.getAddrTypeNo()));
        if (pkgCompanyAddrRsp != null) {
            if (tradeLogin.getCompanyNo().equals(pkgCompanyAddrRsp.getCompanyNo()) && tradeLogin.getAddrTypeNo().equals(pkgCompanyAddrRsp.getTradeAddrNo())
                    && tradeLogin.getTradeApi().equals(pkgCompanyAddrRsp.getTradeApi())) {
                PkgCompanyCloudMapRsp pkgCompanyCloudMapRsp = pkgCompanyCloudMapRspMap.get(String.format("%s_%s", tradeLogin.getCompanyNo(), tradeLogin.getAddrTypeNo()));
                if (pkgCompanyCloudMapRsp != null) {
                    String cloudTradeAddrNo = pkgCompanyCloudMapRsp.getCloudTradeAddrNo();
                    PkgCloudAddrRsp pkgCloudAddrRsp = tradeAddress.get(cloudTradeAddrNo);
                    if (pkgCloudAddrRsp != null && !addressList.contains(pkgCloudAddrRsp)) {
                        addressList.add(pkgCloudAddrRsp);
                    }
                }
            }
        }

        if (addressList.size() == 0) {
            removeTradeUser(tu);
            return EsDataConstant.S_LOGIN_SERVERVCLOSE;
        }

        Address[] addresses = new Address[addressList.size()];
         for (int i =0; i < addressList.size(); i++) {
            if (TextUtils.isEmpty(addressList.get(i).getIP()) || addressList.get(i).getPort() < 0) {
                removeTradeUser(tu);
                return EsDataConstant.S_LOGIN_ADDRNOTEXIST;
            }
            addresses[i] = new Address(addressList.get(i).getIP(), addressList.get(i).getPort());
        }

         tu.getIp()[0] = addresses[0].getIp();
         tu.getPort()[0] = (short) addresses[0].getPort();

        callback.getAddress(addresses);

        return 0;
    }

    @Override
    public List<CloudTradeCompany> getCloudTradeCompanyData(String companyNo, String addrNo) {
        Map<String, PkgCompanyAddrRsp>  companyAddrRspMap = EsApiData.getInstance().getTradeCompanyMap();
        List<CloudTradeCompany> result = new ArrayList<>();
        for (String key : companyAddrRspMap.keySet()) {
            CloudTradeCompany cloudTradeCompany = new CloudTradeCompany();
            cloudTradeCompany.setCompanyNo(companyAddrRspMap.get(key).getCompanyNo());
            cloudTradeCompany.setCompanyName(companyAddrRspMap.get(key).getCompanyName());
            cloudTradeCompany.setAddrTypeNo(companyAddrRspMap.get(key).getTradeAddrNo());
            cloudTradeCompany.setAddrTypeName(companyAddrRspMap.get(key).getTradeAddrName());
            cloudTradeCompany.setSimulateTrade(companyAddrRspMap.get(key).getAddrType());
            cloudTradeCompany.setTradeApi(companyAddrRspMap.get(key).getTradeApi());
            result.add(cloudTradeCompany);
        }
        EsLog.d(TAG, "companyAddrRspMap size = " + companyAddrRspMap.size());
        return result;
    }

    @Override
    public int tradeLogout(String companyNo, String userNo, String addrTypeNo) {
        STradeUser tu = getTradeUser(companyNo, userNo);
        if (tu == null) {
            return -1;
        }
        if (tu.getTcpClient() > 0) {
            //登出
            LoginOutReq(tu);
            UnixJNI.S_TcpFree(tu.getTcpClient());
            tu.setTradeState((short) 0);

            removeTradeUser(tu);

            TradeLogDataHelper.getInstance().writeTradeEvent(companyNo, userNo, TradeLogDataHelper.LOGOUT_EVENT_STATE);
        }
        return 0;
    }

    @Override
    public String[] getTradeDate(String companyNo, String userNo) {
        STradeUser tradeUser = getTradeUser(companyNo, userNo);

        return tradeUser.getTradeDate();
    }

    @Override
    public Commodity getCommodityData(String companyNo, String userNo, String addrNo, String commodityNo) {
        STradeUser tu = getTradeUser(companyNo, userNo);
        Map<String, Commodity> userCommodityMap = tu.getCommoditys();
        return userCommodityMap.get(commodityNo);
    }

    @Override
    public int openTradeOrder(InsertOrder order) {
        if (order == null) {
            return TRADE_ORDER_INPUT_ERROR;
        }

        Contract contract = order.getContract();

        if (contract == null) {
            return TRADE_ORDER_INPUT_ERROR;
        }

        String contractNo = contract.getContractNo();

        if (contractNo == null || contractNo.isEmpty()) {
            return TRADE_ORDER_INPUT_ERROR;
        }

        // 取消自动行权所下手数需要为0
        if (order.getOrderQty().compareTo(BigInteger.ZERO) < 0) {
            return TRADE_ORDER_INPUT_ERROR;
        }

        double price = formatOrderPrice(contract, order.getOrderPrice(), order.getDirect());

        order.setOrderPrice(String.valueOf(price));

        if (contract.isForeignContract()) {
            order.setOffset(EsDataConstant.S_OFFSET_NONE);
        } else {
            order.setOffset(EsDataConstant.S_OFFSET_OPEN);
        }

        STradeUser tu = getTradeUser(order.getCompanyNo(), order.getUserNo());
        if (tu == null) {
            return -1;
        }

        int ret = TradeOrderInsert(tu, order);
        EsLog.d(TAG, "openTradeOrder ret = " + ret);
        return ret;
    }

    static double formatOrderPrice(Contract contract, String priceStr, char direct){
        if (contract == null || priceStr == null) {
            return 0;
        }

        Commodity commodity = contract.getCommodity();

        double tick = commodity.getPriceTick();
        int deno = commodity.getPriceDeno();

        double price;
        boolean hasDeno = false;

        //分数报价合约处理
        //分数报价合约显示的几种情况
        //14+20/32,20/32,14+0/32,14+20,14+0,20
        if (deno > 1 && priceStr.length() > 0 && Character.isDigit(priceStr.charAt(0)) && !priceStr.contains(".")) {
            String num = priceStr;
            if (priceStr.contains("/")) {
                num = priceStr.split("/")[0];
                hasDeno = true;
            }

            String integerStr;
            String numeratorStr;

            if (num.contains("+")) {
                integerStr = num.split("\\+")[0];
                numeratorStr = num.split("\\+")[1];
            } else {
                integerStr = "0";
                numeratorStr = num;
            }

            try {
                price = Double.parseDouble(integerStr) + Double.parseDouble(numeratorStr) / deno;
            } catch (NumberFormatException | NullPointerException e) {
                price = 0;
            }
        } else {
            try {
                price = Double.parseDouble(priceStr);
            } catch (NumberFormatException | NullPointerException e) {
                price = 0;
            }
        }

        //将价格变为邻近的最小变动价，向上取整-
        int quotient = (int)(price/tick);

        double minPrice, maxPrice;

        if (price > 0) {
            minPrice = tick * quotient;
            maxPrice = tick * (quotient + 1);
        } else if (price < 0) {
            minPrice = tick * (quotient - 1);
            maxPrice = tick * quotient;
        } else {
            return 0;
        }

        //通过转换后的字符串比较大小
        String mixPriceStr = EsDataApi.formatPrice(commodity, minPrice, hasDeno);
        String maxPriceStr = EsDataApi.formatPrice(commodity, maxPrice, hasDeno);
//        String priceTemp = EsDataApi.formatPrice(commodity, price);

        if (!priceStr.contains("+") && !priceStr.contains("/") && !mixPriceStr.contains("+") && !mixPriceStr.contains("/")) {
            // double类型的价格不能通过字符串equals
            if (Double.parseDouble(priceStr) == Double.parseDouble(mixPriceStr)) {
                return minPrice;
            } else if (Double.parseDouble(priceStr) == Double.parseDouble(maxPriceStr)) {
                return maxPrice;
            }
        } else if (priceStr.equals(mixPriceStr) || String.valueOf(minPrice).equals(priceStr)) {
            return minPrice;
        } else if (priceStr.equals(maxPriceStr) || String.valueOf(maxPrice).equals(priceStr)) {
            return maxPrice;
        }
        if (direct == EsDataConstant.S_DIRECT_BUY) {
            return minPrice;
        } else {
            return maxPrice;
        }
    }

    @Override
    public AddrInfo getAddrInfo(char system, String companyNo, String userNo, String addrNo) {
        return EsTradeData.getInstance().getTradeAddress();
    }

    @Override
    public List<PositionData> getSumPositionData(String companyNo, String userNo, String addrNo, String startNo, char direct, boolean isNow) {
        List<PositionData> res = new ArrayList<>();
        STradeUser tu = getTradeUser(companyNo, userNo);

        if (tu == null) {
            return res;
        }

        Map<String, PositionData> userSumPosition = tu.getSumPositions();

        if (!TextUtils.isEmpty(startNo)) {
            res.add(userSumPosition.get(startNo));
        } else {
            for (String key : userSumPosition.keySet()) {
                res.add(userSumPosition.get(key));
            }
        }

        return res;
    }

    @Override
    public List<OrderData> getPutOrderData(String companyNo, String userNo, String addrNo, char type, String beginOrderNo, int len, boolean isNow) {
        List<OrderData> res = new ArrayList<>();
        STradeUser tu = getTradeUser(companyNo, userNo);

        if (tu == null) {
            return res;
        }

        Map<String, OrderData> userOrder;
        
        if (type == 0) {
            userOrder = tu.getOrders();
        } else {
            userOrder = tu.getStrategyOrders();
        }

        if (!TextUtils.isEmpty(beginOrderNo)) {
            res.add(userOrder.get(beginOrderNo));
        } else {
            for (String key : userOrder.keySet()) {
                OrderData orderData = userOrder.get(key);
                if (orderData != null && (orderData.getOrderState() >= EsDataConstant.S_ORDERSTATE_TRIGGERING &&
                        orderData.getOrderState() <= EsDataConstant.S_ORDERSTATE_PARTFILLED) ||
                        orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_CANCELING ||
                        orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_MODIFYING ||
                       orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_PARTTRIGGERED ||
                       orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_PAIRING||
                       orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_CHECKING||
                       orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_SUSPENDED||
                       orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_APPLY||
                       orderData.getOrderState() == EsDataConstant.S_ORDERSTATE_ACCEPT) {
                            res.add(orderData);
                }
            }
        }

        return res;
    }

    @Override
    public List<MatchData> getMatchData(String companyNo, String userNo, String addrNo, String startNo, char direct, int len, boolean isNow) {
        List<MatchData> res = new ArrayList<>();
        STradeUser tu = getTradeUser(companyNo, userNo);

        if (tu == null) {
            return res;
        }

        Map<String, MatchData> userMatch = tu.getMatches();

        if (!TextUtils.isEmpty(startNo)) {
            String key = String.format("%s%c", startNo, direct);
            res.add(userMatch.get(key));
        } else {
            for (String key : userMatch.keySet()) {
                res.add(userMatch.get(key));
            }
        }

        return res;
    }

    @Override
    public List<OrderData> getOrderData(String companyNo, String userNo, String addrNo, char strategyType, char orderState, String orderNo, int len, boolean isNow) {
        List<OrderData> res = new ArrayList<>();
        STradeUser tu = getTradeUser(companyNo, userNo);

        if (tu == null) {
            return res;
        }

        Map<String, OrderData> userOrder;

        if (strategyType == 0) {
            userOrder = tu.getOrders();
        } else {
            userOrder = tu.getStrategyOrders();
        }

        if (!TextUtils.isEmpty(orderNo)) {
            res.add(userOrder.get(orderNo));
        } else {
            for (String key : userOrder.keySet()) {
                OrderData orderData = userOrder.get(key);
                res.add(orderData);
            }
        }

        return res;
    }

    @Override
    public int deleteTradeOrder(OrderData order) {
        return deleteTradeOrder(EsDataConstant.S_OAT_CANCEL, order);
    }

    @Override
    public int suspendTradeOrder(OrderData order) {
        return deleteTradeOrder(EsDataConstant.S_OAT_SUSPEND, order);
    }

    @Override
    public int resumeTradeOrder(OrderData order) {
        return deleteTradeOrder(EsDataConstant.S_OAT_RESUME, order);
    }

    @Override
    public int modifyTradeOrder(OrderData req, double price, BigInteger qty, BigInteger maxQty) {
        if (!EsDataApi.isContainTrade()) {
            return EsDataConstant.NOT_TRADE_MODULE;
        }

        if (req == null) {
            return EsDataConstant.TRADE_ORDER_INPUT_ERROR;
        }

        String contractNo = req.getContractNo();
        Contract contract = EsDataApi.getTradeContract(contractNo);
        if (contract == null) {
            return EsDataConstant.TRADE_ORDER_INPUT_ERROR;
        }

        //没有任何修改
        if (qty.equals(req.getOrderQty()) && price == req.getOrderPrice()) {
            return EsDataConstant.TRADE_MODIFY_ORDER_NOT_CHANGE;
        }

        if (qty.compareTo(BigInteger.ZERO) <= 0) {
            return TRADE_ORDER_INPUT_ERROR;
        }

        STradeUser tu = getTradeUser(req.getCompanyNo(), req.getUserNo());
        if (tu == null) {
            return -1;
        }
        if (TextUtils.isEmpty(req.getContractNo())) {
            return -3;
        }

        req.setOrderPrice(price);
        req.setOrderQty(qty);

        int ret = 0;
        if (req.getStrategyType() == '\0' && !"DipperTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            Map<String, OrderData> userOrders = tu.getOrders();
            OrderData data = userOrders.get(req.getOrderNo());
            if (data != null) {
                //重新下单 存储信息
                Map<String, InsertOrder> userTempOrder = tu.getTempOrder();
                InsertOrder reqorder = userTempOrder.get(req.getOrderNo());
                if (reqorder == null) {
                    reqorder = new InsertOrder();
                    userTempOrder.put(req.getOrderNo(), reqorder);
                }
                reqorder.setCompanyNo(req.getCompanyNo());
                reqorder.setUserNo(req.getUserNo());
                reqorder.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
                reqorder.setContractNo(req.getContractNo());
                reqorder.setOrderType(req.getOrderType());
                reqorder.setOrderWay(req.getOrderWay());
                reqorder.setValidType(req.getValidType());
                reqorder.setValidTime(req.getValidTime());
                reqorder.setDirect(req.getDirect());
                reqorder.setOffset(req.getOffset());
                reqorder.setHedge(req.getHedge());
                reqorder.setOrderPrice(String.valueOf(price));
                reqorder.setOrderQty(qty);
                reqorder.setTriggerPrice(req.getTriggerPrice());
                reqorder.setTriggerMode(req.getTriggerMode());
                reqorder.setTriggerCondition(req.getTriggerCondition());
                reqorder.setStrategyType(req.getStrategyType());
                reqorder.setOrderPriceType(req.getOrderPriceType());
                reqorder.setTimeCondition(req.getTimeCondition());
                reqorder.setTriggerPrice2(req.getTriggerPrice2());
                reqorder.setTriggerMode2(req.getTriggerMode2());
                reqorder.setTriggerCondition2(req.getTriggerCondition2());
                reqorder.setStopPriceType(req.getStopPriceType());
                reqorder.setStopPrice(req.getStopPrice());
                reqorder.setAddOne(data.isAddOne());
                reqorder.setAutoCloseFlag(data.isAutoCloseFlag());
                reqorder.setMaxOrderQty(maxQty);

                //撤单
                req.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
                ret = deleteTradeOrder(req);
            }
        } else {
            ret = TradeOrderModify(tu, req);
        }
        return ret;
    }

    @Override
    public int queryBill(String companyNo, String userNo, String addrNo, String billDate) {
        if (!EsDataApi.isContainTrade()) {
            return EsDataConstant.NOT_TRADE_MODULE;
        }

        STradeUser tu = getTradeUser(companyNo, userNo);
        if (tu == null) {
            return -1;
        }

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_BILL_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdBillQryReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));
        tu.setBillQrySessionId((int) head.getSessionId());
        tu.setBillData(null);

        TrdBillQryReq data = new TrdBillQryReq();
        data.setCompanyNo(companyNo);
        data.setUserNo(userNo);
        data.setBillDate(billDate);
        data.setBillType(EsNativeProtocol.S_BT_DAY);
        data.setFormatType(EsDataConstant.S_BFT_Text);

        int sendRes = EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
        return sendRes;
    }

    @Override
    public int billConfirm(BillConfirmReq billConfirmReq) {
        if (!EsDataApi.isContainTrade()) {
            return EsDataConstant.NOT_TRADE_MODULE;
        }

        STradeUser tu = getTradeUser(billConfirmReq.getCompanyNo(), billConfirmReq.getUserNo());
        if (tu == null) {
            return -1;
        }

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_BILLCONFIRM_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdBillConfirmReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));

        TrdBillConfirmReq data = new TrdBillConfirmReq();
        data.setCompanyNo(billConfirmReq.getCompanyNo());
        data.setUserNo(billConfirmReq.getUserNo());
        data.setBillDate("");
        data.setConfirmed((char) 1);

        int ret = EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
        ret = ret > 0 ? 0 : -1;
        return ret;
    }

    @Override
    public int registPushInfo(PushClientInfo info) {
        SPushClientInfo pushClientInfo = new SPushClientInfo();
        pushClientInfo.setAppId(info.getAppId());
        pushClientInfo.setAppKey(info.getAppKey());
        pushClientInfo.setAppMasterSecret(info.getAppMasterSecret());
        pushClientInfo.setCID(info.getCID());
        pushClientInfo.setDeviceType(info.getDeviceType());
        pushClientInfo.setLangType((short) info.getLangType());

        EsApiData.getInstance().setPushClientInfo(pushClientInfo);
        return 0;
    }

    @Override
    public int qryMessage(String companyno, String userno, String addrno) {
        STradeUser tu = getTradeUser(companyno, userno);
        if (tu == null) {
            return -1;
        }

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_MESSAGE_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdMessageQryReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));

        TrdMessageQryReq data = new TrdMessageQryReq();
        data.setCompanyNo(companyno);
        data.setUserNo(userno);

        int ret = EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
        ret = ret > 0 ? 0 : -1;
        return ret;
    }

    @Override
    public List<MoneyData> getMoneyData(String companyNo, String userNo, String addrNo) {
        STradeUser tu = getTradeUser(companyNo, userNo);
        if (tu == null || tu.getMoneyIndex() <= 0) {
            return new ArrayList<>();
        }

        // 先计算数据的总个数, 总基币为1，所以从1开始
        int rsize = 1;
        rsize = rsize + tu.getMoneyIndex();
        if ("DipperTradeApi".equals(tu.getTradeLogin().getTradeApi()) || "EstarTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            Map<String, MoneyData> baseMoney = tu.getBaseMoney();
            for (String key : baseMoney.keySet()) {
                if (baseMoney.get(key) != null) {
                    rsize++;
                }
            }
        }

        List<MoneyData> res = new ArrayList<>();

        if ("DipperTradeApi".equals(tu.getTradeLogin().getTradeApi()) || "EstarTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            //先发总基币
            res.add(tu.getTotalMoney());

            //币种组基币
            List<MoneyData> array = new ArrayList<>();
            Map<String, MoneyData> baseMoney = tu.getBaseMoney();
            for (String key : baseMoney.keySet()) {
                if (array.size() >= 8) {
                    break;
                }
                MoneyData moneyData = baseMoney.get(key);
                if (moneyData == null) {
                    continue;
                }
                array.add(moneyData);
            }

            //币种
            List<MoneyData> marray = new ArrayList<>();
            for (int i =0; i < tu.getMoneyIndex(); i++) {
                marray.add(tu.getMoney()[i]);
            }

            for (int j =0; j < 32; j++) {
                if (res.size() >= rsize) {
                    break;
                }
                if (array.get(j) == null) {
                    break;
                }

                for (int i =0; i < tu.getMoneyIndex(); i++) {
                    if (marray.get(i) == null) {
                        continue;
                    }
                    if (array.get(j).getCurrencyGroupNo().equals(marray.get(i).getCurrencyGroupNo())) {
                        //币种组基币
                        if (res.size() >= rsize) {
                            break;
                        }

                        if (res.size() >0 && res.get(res.size() -1).getCurrencyGroupNo().equals(array.get(j).getCurrencyGroupNo()) && res.size() < rsize) {
                            res.add(array.get(j));
                        }

                        //币种
                        if (res.size() >= rsize) {
                            break;
                        }
                        res.add(marray.get(i));
                    }
                }
            }
        } else {
            for(int i =0; i < tu.getMoneyIndex(); i++) {
                if (res.size() >= rsize) {
                    break;
                }
                res.add(tu.getMoney()[i]);
            }
        }

        return res;
    }

    @Override
    public boolean isDipperTradeStar(TradeLogin tradeLogin) {
        return tradeLogin != null && (tradeLogin.getTradeApi().equals("DipperTradeApi") || tradeLogin.getTradeApi().equals("EstarTradeApi"));
    }

    @Override
    public boolean isVenusTradeStar(TradeLogin tradeLogin) {
        return tradeLogin != null && (tradeLogin.getTradeApi().equals("DaystarctTradeApi"));
    }

    @Override
    public int modifyTradePassword(String companyNo, String userNo, String addrNo, String oldPassword, String newPassword) {
        STradeUser tu = getTradeUser(companyNo, userNo);
        if (tu == null || tu.getMoneyIndex() <= 0) {
            return -1;
        }

        TrdChangeLoginPswReq data = new TrdChangeLoginPswReq();
        data.setCompanyNo(companyNo);
        data.setLoginNo(userNo);
        data.setCurrPsw(oldPassword);
        data.setNewPsw(newPassword);
        tu.setModifyPass(newPassword);

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_CHANGELOGINPSW_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdChangeLoginPswReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));
        int ret = (int) head.getSessionId();

        int sendRes = EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, data.beanToByte());
        sendRes = (sendRes > 0) ? 0 : -2;
        if (sendRes == 0) {
            return ret;
        }
        return sendRes;
    }

    private int TradeOrderModify(STradeUser tu, OrderData order) {
        TrdOrderModifyReq req = new TrdOrderModifyReq();
        req.setCompanyNo(order.getCompanyNo());
        req.setUserNo(order.getUserNo());
        req.setOrderNo(order.getOrderNo());
        req.setContractNo(order.getContractNo());
        req.setOrderType(order.getOrderType());
        req.setOrderWay(order.getOrderWay());
        req.setValidType(order.getValidType());
        req.setValidTime(order.getValidTime());
        req.setDirect(order.getDirect());
        req.setOffset(order.getOffset());
        req.setHedge(order.getHedge());
        req.setOrderPrice(order.getOrderPrice());
        req.setOrderQty(order.getOrderQty().intValue());
        req.setTriggerPrice(order.getTriggerPrice());
        req.setOrderPriceType(order.getOrderPriceType());
        req.setTriggerMode(order.getTriggerMode());
        req.setTriggerCondition(order.getTriggerCondition());
        req.setTimeCondition(order.getTimeCondition());
        req.setTriggerPrice2(order.getTriggerPrice2());
        req.setTriggerMode2(order.getTriggerMode2());
        req.setStopPriceType(order.getStopPriceType());
        req.setStopPrice(order.getStopPrice());
        req.setStrategyType(order.getStrategyType());

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_ORDER_MDF_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdOrderModifyReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));
        int ret = (int) head.getSessionId();

        int sendRes = EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());
        sendRes = (sendRes > 0) ? 0 : -2;
        if (sendRes == 0) {
            return ret;
        }
        return sendRes;
    }

    private int deleteTradeOrder(char action, OrderData order) {
        if (!EsDataApi.isContainTrade()) {
            return EsDataConstant.NOT_TRADE_MODULE;
        }

        if (order == null) {
            return EsDataConstant.TRADE_ORDER_CANNOT_DELETE;
        }

        if (order.isRiskOrder() && action == EsDataConstant.S_OAT_CANCEL) {
            return EsDataConstant.TRADE_ORDER_CANNOT_DELETE;
        }

        STradeUser tu = getTradeUser(order.getCompanyNo(), order.getUserNo());
        if (tu == null) {
            return -1;
        }
        if (TextUtils.isEmpty(order.getContractNo())) {
            return -3;
        }

        TrdOrderActionReq req = new TrdOrderActionReq();
        req.setCompanyNo(order.getCompanyNo());
        req.setUserNo(order.getUserNo());
        req.setContractNo(order.getContractNo());
        req.setOrderNo(order.getOrderNo());
        req.setOrderActionType(action);
        req.setStrategyType(order.getStrategyType());

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_ORDER_ACT_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdOrderActionReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));
        int ret = (int) head.getSessionId();

        int sendRes = EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());
        sendRes = (sendRes > 0) ? 0 : -2;
        if (sendRes == 0) {
            TradeLogDataHelper.getInstance().writeTradeLog(order, true);
            return ret;
        }

        return sendRes;
    }

    public int TradeOrderInsert(STradeUser tu, InsertOrder order) {
        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_ORDERINSERT_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdOrderInsertReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));
        int ret = (int) head.getSessionId();

        TrdOrderInsertReq req = new TrdOrderInsertReq();
        req.setCompanyNo(order.getCompanyNo());
        req.setUserNo(order.getUserNo());

        String contractNo = order.getContractNo();

        //针对黄金交易所 SGE|Y|AG(T+D)| 进行处理
        // TODO ? 怎么处理
        String[] array = contractNo.split("|");
        if (array == null || array.length == 0) {
            return -1;
        }


        req.setContractNo(contractNo);
        req.setOrderType(order.getOrderType());
        req.setOrderWay(order.getOrderWay());
        req.setValidType(order.getValidType());
        req.setValidTime("");

        req.setDirect(order.getDirect());
        req.setOffset(order.getOffset());
        req.setHedge(order.getHedge());
        req.setOrderPrice(Double.parseDouble(order.getOrderPrice()));
        req.setOrderQty(order.getOrderQty().intValue());

        req.setTriggerPrice(order.getTriggerPrice());
        req.setTriggerMode(order.getTriggerMode());
        req.setTriggerCondition(order.getTriggerCondition());

        req.setStrategyType(order.getStrategyType());

        req.setParentNo(order.getParentNo());

        req.setOrderReqId((int) head.getSessionId());
        req.setParentReqId((int) order.getParentReqId());

        req.setOrderPriceType(order.getOrderPriceType());
        req.setTimeCondition(order.getTimeCondition());
        req.setTriggerPrice2(order.getTriggerPrice2());
        req.setTriggerMode2(order.getTriggerMode2());
        req.setTriggerCondition2(order.getTriggerCondition2());

        req.setStopPriceType(order.getStopPriceType());
        req.setStopPrice(order.getStopPrice());
        req.setOrderRef("");
        if ("EstarTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            if (req.getOffset() != '\0') {
                // 内盘
                req.setInsertTradeDate(tu.getTradeDate()[0]);
            } else {
                req.setInsertTradeDate(tu.getTradeDate()[1]);
            }
        } else {
            req.setInsertTradeDate(tu.getTradeDate()[0]);
        }

        req.setAddOne((char) (order.isAddOne() ? EsDataConstant.S_NEXT_YES : EsDataConstant.S_NEXT_NO));
        req.setAutoCloseFlag((char) (order.isAutoCloseFlag() ? EsDataConstant.S_NEXT_YES : EsDataConstant.S_NEXT_NO));
        req.setStParentNo("");

        if (order.getStrategyType() == 0) {
            // 大单拆分
            BigInteger sumQty = order.getOrderQty();
            BigInteger maxQty = order.getMaxOrderQty();
            if (maxQty.compareTo(BigInteger.ZERO) > 0) {
                while (sumQty.compareTo(maxQty) > 0) {
                    req.setOrderQty(maxQty.intValue());

                    // TODO 调用发送消息的接口，是否需要修改，若EsBaseAPI 混淆？
                    int sendRes = EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());

                    if (sendRes > 0) {
                        saveOrderToTradeUser(tu, order, req, head.getSessionId());
                    }
                    sumQty = sumQty.subtract(maxQty);
                    head.setSessionId(AddTSessionId(tu));
                    req.setOrderQty(sumQty.intValue());
                }
                req.setOrderQty(sumQty.intValue());
            }
        }

        int sendRes = EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());
        if (sendRes <= 0) {
            return -1;
        }

        //定单已经发送到后台，本地保存
        saveOrderToTradeUser(tu, order, req, head.getSessionId());

        TrdQryFeeParam(tu, req.getContractNo(), req.getOffset(), true);
        TrdQryDepositParam(tu, req.getContractNo(), req.getDirect(), req.getHedge(), true);
        return ret;
    }

    private void TrdQryFeeParam(STradeUser tu, String contractNo, char offset, boolean needQry) {
        if ("DipperTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            return;
        }

        if (offset != EsTradeProtocol.TRD_O_OPEN) {
            return;
        }
        if (needQry) {
            if (CheckFeeParam(tu, contractNo, offset) == 1) {
                return;
            }
        }

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_FEEPARAM_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdFeeParamQryReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        TrdFeeParamQryReq req = new TrdFeeParamQryReq();
        req.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        req.setUserNo(tu.getTradeLogin().getUserNo());
        req.setOffset(offset);
        req.setContractNo(contractNo);

        EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());
    }

    private int CheckFeeParam(STradeUser tu, String contractNo, char offset) {
        //TODO
        return 0;
    }

    private void TrdQryDepositParam(STradeUser tu, String contractNo, char direct, char hedge, boolean needQry) {
        if ("DipperTradeApi".equals(tu.getTradeLogin().getTradeApi())) {
            return;
        }
        if (needQry) {
            if (CheckDepositParam (tu, contractNo, direct, hedge) == 1) {
                return;
            }
        }

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_DEPOSITPARAM_QRY_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdDepositParamQryReq.STRUCT_LENGTH);
        head.setSessionId(AddTSessionId(tu));
        tu.setNowSessionIndex((int) head.getSessionId());

        TrdDepositParamQryReq req = new TrdDepositParamQryReq();
        req.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        req.setUserNo(tu.getTradeLogin().getUserNo());
        req.setContractNo(contractNo);
        req.setDirect(direct);
        req.setHedge(hedge);

        EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());
    }

    private int CheckDepositParam(STradeUser tu, String contractNo, char direct, char hedge) {
        //TODO
        return 0;
    }

    private void saveOrderToTradeUser(STradeUser tu, InsertOrder order, TrdOrderInsertReq req, long sessionId) {
        Map<String, OrderData> userOrderDataMap = tu.getOrderData();

        OrderData data = new OrderData();
        data.setCompanyNo(tu.getTradeLogin().getCompanyNo());
        data.setUserNo(tu.getTradeLogin().getUserNo());
        data.setAddressNo(tu.getTradeLogin().getAddrTypeNo());
        data.setContractNo(order.getContractNo());
        data.setOrderType(order.getOrderType());
        data.setOrderWay(order.getOrderWay());
        data.setValidType(order.getValidType());
        data.setValidTime("");
        data.setDirect(order.getDirect());
        data.setOffset(order.getOffset());
        data.setHedge(order.getHedge());
        data.setOrderPrice(Double.parseDouble(order.getOrderPrice()));
        data.setOrderQty(BigInteger.valueOf(req.getOrderQty()));

        data.setTriggerPrice(order.getTriggerPrice());
        data.setTriggerMode(order.getTriggerMode());
        data.setTriggerCondition(order.getTriggerCondition());

        data.setStrategyType(order.getStrategyType());

        data.setParentNo(order.getParentNo());

        data.setOrderReqId(order.getParentReqId());
        data.setParentReqId(order.getParentReqId());

        data.setOrderPriceType(order.getOrderPriceType());
        data.setTimeCondition(order.getTimeCondition());
        data.setTriggerPrice2(order.getTriggerPrice2());
        data.setTriggerMode2(order.getTriggerMode2());
        data.setTriggerCondition2(order.getTriggerCondition2());

        data.setStopPriceType(order.getStopPriceType());
        data.setStopPrice(order.getStopPrice());
        data.setAddOne(order.isAddOne());
        data.setAutoCloseFlag(order.isAutoCloseFlag());
        req.setStParentNo("");

        userOrderDataMap.put(String.valueOf(sessionId), data);
    }

    public long AddTSessionId(STradeUser tu) {
        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);
        int minute = now.get(Calendar.MINUTE);
        int second = now.get(Calendar.SECOND);
        int time = (hour * 10000 + minute * 100 + second) * 100;
        if (time > tu.getSessionInex()) {
            tu.setSessionInex(time);
        } else {
            tu.setSessionInex(tu.getSessionInex() +1);
        }

        return tu.getSessionInex();
    }

    private void LoginOutReq(STradeUser tu) {
        TrdLogoutReq req = new TrdLogoutReq();

        CspSessionHead head = CspSessionHead.getCspSessionHead(EsNativeProtocol.TRD_PROTOCOL_VER, EsTradeProtocol.CMD_TRD_LOGOUT_REQ,
                EsNativeProtocol.CSP_SUBSYSTEM_TRADE, TrdLogoutReq.STRUCT_LENGTH);
        EsDataApi.sendMsg(tu.getTcpClient(), EsNativeProtocol.CSP_FRAME_IDEA, head, req.beanToByte());
    }

    private STradeUser addTradeUser(TradeLogin tradeLogin, String password, String newPassword) {
        List<STradeUser> tradeUserList = EsTradeData.getInstance().getTradeUserList();

        STradeUser tradeUser = new STradeUser();
        TradeLogin innerTradeLogin = tradeUser.getTradeLogin();
        innerTradeLogin.setCompanyNo(tradeLogin.getCompanyNo());
        innerTradeLogin.setCompanyName(tradeLogin.getCompanyName());
        innerTradeLogin.setAddrTypeNo(tradeLogin.getAddrTypeNo());
        innerTradeLogin.setAddrTypeName(tradeLogin.getAddrTypeName());
        innerTradeLogin.setUserNo(tradeLogin.getUserNo());
        innerTradeLogin.setTradeApi(tradeLogin.getTradeApi());
        innerTradeLogin.setSystemInfo(tradeLogin.getSystemInfo());
        innerTradeLogin.setSystemInfoLen(tradeLogin.getSystemInfoLen());
        innerTradeLogin.setSystemInfoIntegrity(tradeLogin.getSystemInfoIntegrity());
        innerTradeLogin.setSystemInfoFlag(tradeLogin.getSystemInfoFlag());

        tradeUser.setPassword(password);
        tradeUser.setLoginInfo(String.format("ip=%s;mac=%s", EsNetHelper.getIpAddress(EsBaseApi.getInstance().getContext()), EsNetHelper.getMac(EsBaseApi.getInstance().getContext())));

        tradeUserList.add(tradeUser);
        return tradeUser;
    }

    private void removeTradeUser(STradeUser tu) {
        List<STradeUser> tradeUserList = EsTradeData.getInstance().getTradeUserList();
        tradeUserList.remove(tu);
    }

    private STradeUser getTradeUser(String companyNo, String userNo) {
        List<STradeUser> tradeUsers = EsTradeData.getInstance().getTradeUserList();
        STradeUser res = null;
        for (STradeUser user : tradeUsers) {
            TradeLogin tradeLogin = user.getTradeLogin();
            if (tradeLogin != null && companyNo.equals(tradeLogin.getCompanyNo()) && userNo.equals(tradeLogin.getUserNo())) {
                res = user;
                break;
            }
        }
        return res;
    }

}
