package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/4
 */
public class TrdOrderInsertReq extends ApiStruct {

    public final static int STRUCT_LENGTH = 350;

    private String CompanyNo;                                //经纪公司编号
    private String UserNo;                                    //资金帐号

    private String ContractNo;                                //合约编号
    private char OrderType;                                //定单类型
    private char OrderWay;                                //委托来源
    private char ValidType;                                //有效类型
    private String ValidTime;                                //有效日期时间(GTD情况下使用)
    private char Direct;                                    //买卖方向
    private char Offset;                                    //开仓 平仓 开平 平开(内盘)
    private char Hedge;                                    //投机保值(内盘)

    private double OrderPrice;                                //委托价格 或 期权应价买入价格(委托价格类型为指定时有效)（策略单委托价格类型为指定价时有效）
    private double OrderPriceOver;                            //委托价超出值(委托价格类型为最新价 挂单价 对盘价时有效)(限策略单使用)

    private int OrderQty;                                //委托数量 或 期权应价数量

    //价格条件1
    private double TriggerPrice;                            //触发价格
    private char TriggerMode;                            //触发模式
    private char TriggerCondition;                        //触发条件

    private int MinMatchQty;                            //最小成交量(内盘)

    //冰山单
    private int MinOrderQty;                            //冰山单最小随机量(外盘)
    private int MaxOrderQty;                            //冰山单最大随机量(外盘)

    private char StrategyType;                            //策略类型(条件单，止损单、浮动止损、保本止损、止盈单)

    private char MarketLevel;                            //市价撮合深度,目前只有中金所支持，取值为0、1、5(内盘)

    //应价相关
    private char SellOffset;                                //应价卖出开平
    private double SellOrderPrice;                            //应价卖出价格
    private int SellOrderQty;                            //应价卖出委托数量
    private char SellHedge;                                //应价卖出投保方向
    private String EnquiryNo;                                //询价请求号，应价时用(内盘)

    private char[] OrderRemark = new char[50];                            //定单备注
    private String ParentNo;                                //父单号,可以是TOrder::OrderNo也可以是TSpreadOrder::OrderNo等
    private int OcoId;                                    //OCO编号

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //云端策略单新增字段2017-11-06
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private int OrderReqId;                                //报单请求号，相当于原来包头上的SessionId
    private int ParentReqId;                            //父单请求号
    private char OrderPriceType;                         //委托价格类型(指定价 最新价 挂单价 对盘价 市价 反向停板，只有指定价时委托价格字段才有效)(限策略单使用)

    //时间条件
    private String TimeCondition;                          //时间条件(HH:MM:SS)

    //价格条件2
    private double TriggerPrice2;                          //触发价格2
    private char TriggerMode2;                           //触发模式2
    private char TriggerCondition2;                      //触发条件2

    //停损
    private char StopPriceType;                          //止损止盈价格类型：价格(停损价)、价差(停损价差、浮动止损回撤价差、保本盈利价差)
    private double StopPrice;                              //止损止盈价或价差，具体含义由止损止盈价格类型字段决定

    private String OrderRef;                                //报单引用
    private String InsertTradeDate;                        //下单交易日
    private char AddOne;                                    //是否T+1
    private char AutoCloseFlag;                          //自对冲标记

    private String StParentNo;                             // 条件单父单

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(UserNo, 21));
        buffer.put(stringToByte(ContractNo, 51));
        buffer.put(charToByte(OrderType));
        buffer.put(charToByte(OrderWay));
        buffer.put(charToByte(ValidType));
        buffer.put(stringToByte(ValidTime, 21));
        buffer.put(charToByte(Direct));
        buffer.put(charToByte(Offset));
        buffer.put(charToByte(Hedge));
        if (OrderPrice != 0.0) {
            buffer.putDouble(OrderPrice);
        } else {
            buffer.putDouble(OrderPriceOver);
        }
        buffer.putInt(OrderQty);
        buffer.putDouble(TriggerPrice);
        buffer.put(charToByte(TriggerMode));
        buffer.put(charToByte(TriggerCondition));
        buffer.putInt(MinMatchQty);
        buffer.putInt(MinOrderQty);
        buffer.putInt(MaxOrderQty);
        buffer.put(charToByte(StrategyType));
        buffer.put(charToByte(MarketLevel));
        buffer.put(charToByte(SellOffset));
        buffer.putDouble(SellOrderPrice);
        buffer.putInt(SellOrderQty);
        buffer.put(charToByte(SellHedge));
        buffer.put(stringToByte(EnquiryNo, 21));
        for (int i = 0; i < OrderRemark.length; i++) {
            buffer.put(charToByte(OrderRemark[i]));
        }
        buffer.put(stringToByte(ParentNo, 21));
        buffer.putInt(OcoId);
        buffer.putInt(OrderReqId);
        buffer.putInt(ParentReqId);
        buffer.put(charToByte(OrderPriceType));
        buffer.put(stringToByte(TimeCondition, 11));
        buffer.putDouble(TriggerPrice2);
        buffer.put(charToByte(TriggerMode2));
        buffer.put(charToByte(TriggerCondition2));
        buffer.put(charToByte(StopPriceType));
        buffer.putDouble(StopPrice);
        buffer.put(stringToByte(OrderRef, 21));
        buffer.put(stringToByte(InsertTradeDate, 11));
        buffer.put(charToByte(AddOne));
        buffer.put(charToByte(AutoCloseFlag));
        buffer.put(stringToByte(StParentNo, 21));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public char getOrderType() {
        return OrderType;
    }

    public void setOrderType(char orderType) {
        OrderType = orderType;
    }

    public char getOrderWay() {
        return OrderWay;
    }

    public void setOrderWay(char orderWay) {
        OrderWay = orderWay;
    }

    public char getValidType() {
        return ValidType;
    }

    public void setValidType(char validType) {
        ValidType = validType;
    }

    public String getValidTime() {
        return ValidTime;
    }

    public void setValidTime(String validTime) {
        ValidTime = validTime;
    }

    public char getDirect() {
        return Direct;
    }

    public void setDirect(char direct) {
        Direct = direct;
    }

    public char getOffset() {
        return Offset;
    }

    public void setOffset(char offset) {
        Offset = offset;
    }

    public char getHedge() {
        return Hedge;
    }

    public void setHedge(char hedge) {
        Hedge = hedge;
    }

    public double getOrderPrice() {
        return OrderPrice;
    }

    public void setOrderPrice(double orderPrice) {
        OrderPrice = orderPrice;
    }

    public double getOrderPriceOver() {
        return OrderPriceOver;
    }

    public void setOrderPriceOver(double orderPriceOver) {
        OrderPriceOver = orderPriceOver;
    }

    public int getOrderQty() {
        return OrderQty;
    }

    public void setOrderQty(int orderQty) {
        OrderQty = orderQty;
    }

    public double getTriggerPrice() {
        return TriggerPrice;
    }

    public void setTriggerPrice(double triggerPrice) {
        TriggerPrice = triggerPrice;
    }

    public char getTriggerMode() {
        return TriggerMode;
    }

    public void setTriggerMode(char triggerMode) {
        TriggerMode = triggerMode;
    }

    public char getTriggerCondition() {
        return TriggerCondition;
    }

    public void setTriggerCondition(char triggerCondition) {
        TriggerCondition = triggerCondition;
    }

    public int getMinMatchQty() {
        return MinMatchQty;
    }

    public void setMinMatchQty(int minMatchQty) {
        MinMatchQty = minMatchQty;
    }

    public int getMinOrderQty() {
        return MinOrderQty;
    }

    public void setMinOrderQty(int minOrderQty) {
        MinOrderQty = minOrderQty;
    }

    public int getMaxOrderQty() {
        return MaxOrderQty;
    }

    public void setMaxOrderQty(int maxOrderQty) {
        MaxOrderQty = maxOrderQty;
    }

    public char getStrategyType() {
        return StrategyType;
    }

    public void setStrategyType(char strategyType) {
        StrategyType = strategyType;
    }

    public char getMarketLevel() {
        return MarketLevel;
    }

    public void setMarketLevel(char marketLevel) {
        MarketLevel = marketLevel;
    }

    public char getSellOffset() {
        return SellOffset;
    }

    public void setSellOffset(char sellOffset) {
        SellOffset = sellOffset;
    }

    public double getSellOrderPrice() {
        return SellOrderPrice;
    }

    public void setSellOrderPrice(double sellOrderPrice) {
        SellOrderPrice = sellOrderPrice;
    }

    public int getSellOrderQty() {
        return SellOrderQty;
    }

    public void setSellOrderQty(int sellOrderQty) {
        SellOrderQty = sellOrderQty;
    }

    public char getSellHedge() {
        return SellHedge;
    }

    public void setSellHedge(char sellHedge) {
        SellHedge = sellHedge;
    }

    public String getEnquiryNo() {
        return EnquiryNo;
    }

    public void setEnquiryNo(String enquiryNo) {
        EnquiryNo = enquiryNo;
    }

    public char[] getOrderRemark() {
        return OrderRemark;
    }

    public void setOrderRemark(char[] orderRemark) {
        OrderRemark = orderRemark;
    }

    public String getParentNo() {
        return ParentNo;
    }

    public void setParentNo(String parentNo) {
        ParentNo = parentNo;
    }

    public int getOcoId() {
        return OcoId;
    }

    public void setOcoId(int ocoId) {
        OcoId = ocoId;
    }

    public int getOrderReqId() {
        return OrderReqId;
    }

    public void setOrderReqId(int orderReqId) {
        OrderReqId = orderReqId;
    }

    public int getParentReqId() {
        return ParentReqId;
    }

    public void setParentReqId(int parentReqId) {
        ParentReqId = parentReqId;
    }

    public char getOrderPriceType() {
        return OrderPriceType;
    }

    public void setOrderPriceType(char orderPriceType) {
        OrderPriceType = orderPriceType;
    }

    public String getTimeCondition() {
        return TimeCondition;
    }

    public void setTimeCondition(String timeCondition) {
        TimeCondition = timeCondition;
    }

    public double getTriggerPrice2() {
        return TriggerPrice2;
    }

    public void setTriggerPrice2(double triggerPrice2) {
        TriggerPrice2 = triggerPrice2;
    }

    public char getTriggerMode2() {
        return TriggerMode2;
    }

    public void setTriggerMode2(char triggerMode2) {
        TriggerMode2 = triggerMode2;
    }

    public char getTriggerCondition2() {
        return TriggerCondition2;
    }

    public void setTriggerCondition2(char triggerCondition2) {
        TriggerCondition2 = triggerCondition2;
    }

    public char getStopPriceType() {
        return StopPriceType;
    }

    public void setStopPriceType(char stopPriceType) {
        StopPriceType = stopPriceType;
    }

    public double getStopPrice() {
        return StopPrice;
    }

    public void setStopPrice(double stopPrice) {
        StopPrice = stopPrice;
    }

    public String getOrderRef() {
        return OrderRef;
    }

    public void setOrderRef(String orderRef) {
        OrderRef = orderRef;
    }

    public String getInsertTradeDate() {
        return InsertTradeDate;
    }

    public void setInsertTradeDate(String insertTradeDate) {
        InsertTradeDate = insertTradeDate;
    }

    public char getAddOne() {
        return AddOne;
    }

    public void setAddOne(char addOne) {
        AddOne = addOne;
    }

    public char getAutoCloseFlag() {
        return AutoCloseFlag;
    }

    public void setAutoCloseFlag(char autoCloseFlag) {
        AutoCloseFlag = autoCloseFlag;
    }

    public String getStParentNo() {
        return StParentNo;
    }

    public void setStParentNo(String stParentNo) {
        StParentNo = stParentNo;
    }
}
