package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/3
 */
public class TrdBillQryReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 45;

    private String					CompanyNo;								//经纪公司编号
    private String				UserNo;									//资金账号
    private char						BillType;								//账单类型
    private String							BillDate;								//账单日期
    private char				FormatType;								//账单格式

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(CompanyNo, 11));
        buffer.put(stringToByte(UserNo, 21));
        buffer.put(charToByte(BillType));
        buffer.put(stringToByte(BillDate, 11));
        buffer.put(charToByte(FormatType));
        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getCompanyNo() {
        return CompanyNo;
    }

    public void setCompanyNo(String companyNo) {
        CompanyNo = companyNo;
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public char getBillType() {
        return BillType;
    }

    public void setBillType(char billType) {
        BillType = billType;
    }

    public String getBillDate() {
        return BillDate;
    }

    public void setBillDate(String billDate) {
        BillDate = billDate;
    }

    public char getFormatType() {
        return FormatType;
    }

    public void setFormatType(char formatType) {
        FormatType = formatType;
    }
}
