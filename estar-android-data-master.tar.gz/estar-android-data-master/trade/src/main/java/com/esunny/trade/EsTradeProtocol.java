package com.esunny.trade;

/**
 * @author Peter Fu
 * @date 2020/10/20
 */
public class EsTradeProtocol {

    //链路认证公钥和私钥
    public final static String G_RSAPUBKEY = "AAS4MUFOC0YTkivTW0s2gCvB4egclaJ8lY9TggA99kYVTKkvwc4Cw74EekXps" +
            "CqQibS5AngjfJZRkqD8yGu0m8gq5v3C3nCQBrhsdnbv31l2JvrWM6T33EjERdN" +
            "+tV/LOxq7lbqqgm1TkOFf0U7UA/otDLhBxlBglSTsVV47xWypVwAAAAAAAQAB";
    public final static String G_RSAPRIKEY = "AAS4MUFOC0YTkivTW0s2gCvB4egclaJ8lY9TggA99kYVTKkvwc4Cw74EekXps" +
            "CqQibS5AngjfJZRkqD8yGu0m8gq5v3C3nCQBrhsdnbv31l2JvrWM6T33EjERd" +
            "N+tV/LOxq7lbqqgm1TkOFf0U7UA/otDLhBxlBglSTsVV47xWypVwAAAAAAAQA" +
            "BDbzZH1wtLjkAAAAAAADhP1dvULyw57n2yufQ1ffBt/fK59DV98EAAAAAULyw" +
            "5wf4yucBAAAAlYHF5wAAAADbIo7CubOfwnA/xOesqcXnuMLN5wAAAAAAAAAAA" +
            "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAcM+cBAAAAELvhBs3QCMkVCR" +
            "STioyl14S4VhVCOLfnjonL1lafWXYgEH9ebuHD6jFBkOCOJEdeuBbxIR7RSf+" +
            "VM+Vg3kyurvc10YuW1UVFlu6Ioz3ZoRdmQq51e8YYCg14ObVemRbGLdarAhth" +
            "HqUOm+50kscQkpFwZ6DQSG3IjDXci0XvS1VT21wPqIv/zCRq/pwOBtSig43Wy" +
            "gO5qKN3UTCvk+jFdOpRVYqQ2pSIb3Zfiz8b4IcD0X79Cdqd545nGOS0jbK5qj" +
            "FVXCC4hjx/7HGa1hI2bjrJBRp0rlCSn8QO9hQwFrfqal1FQXQBsMlPugag2Bi" +
            "nLDn27OqL5rTgcPyDe5ysOnkrtTtG420XIiGWgMzftnZKx49UwGVapIMOxjRe" +
            "C3WrMP1rJvwb9EEvX0i5BihVeIPdW9TLzIT3bIGWaYeuG3QVI5==";

    public final static int TS_INITING = 0;
    public final static int TS_LOGINED = TS_INITING + 1;
    public final static int TS_BILLQRY = TS_LOGINED + 1;
    public final static int TS_BILLCONFIRMED = TS_BILLQRY + 1;
    public final static int TS_MONEYQRY = TS_BILLCONFIRMED + 1;
    public final static int TS_COMMODITYQRY = TS_MONEYQRY + 1;
    public final static int TS_POSITIONQRY = TS_COMMODITYQRY + 1;
    public final static int TS_ORDERQRY = TS_POSITIONQRY + 1;
    public final static int TS_STRATEGYQRY = TS_ORDERQRY + 1;
    public final static int TS_MATCHQRY = TS_STRATEGYQRY + 1;
    public final static int TS_FEEQRY = TS_MATCHQRY + 1;
    public final static int TS_DEPOSITQRY = TS_FEEQRY + 1;

    public final static char CSP_CHAIN_END = '0';      //没有后续报文
    public final static char CSP_CHAIN_NOTEND = '1';      //还有后续报文

    //开平
    public final static char TRD_O_OPEN = 'O'; //开仓
    public final static char TRD_O_COVER = 'C'; //平仓
    public final static char TRD_O_COVERT = 'T'; //平今
    public final static char TRD_O_OPENCOVER = '1'; //开平，应价时有效
    public final static char TRD_O_COVEROPEN = '2'; //平开，应价时有效

    //策略类型
    public final static char TRD_ST_PREORDER = 'p'; //预备单(埋单)
    public final static char TRD_ST_AUTOORDER = 'A'; //自动单

    public final static char TRD_ST_CONDITION = 'C'; //条件单
    public final static char TRD_ST_STSTOPLOSS = 'D'; //父条件单
    public final static char TRD_ST_BACKHAND = 'E'; //条件单反手
    public final static char TRD_ST_STOPLOSS = 'L'; //止损单
    public final static char TRD_ST_STOPPROFIT = 'P'; //止盈单
    public final static char TRD_ST_FLOATSTOPLOSS = 'F'; //浮动止损单
    public final static char TRD_ST_BREAKEVEN = 'B'; //保本止损单
    public final static char TRD_ST_OPENSTOPLOSS_SLOSS = 'O'; //开仓止损
    public final static char TRD_ST_OPENSTOPLOSS_SPROFIT = 'S'; //开仓止盈
    public final static char TRD_ST_OPENSTOPLOSS_SFLOAT = 'U'; //浮动止损
    public final static char TRD_ST_OPENSTOPLOSS_SBREAKEVEN = 'T'; //开仓保本

    //链路认证协议
    public final static int CMD_CSP_AUTHREQ = 0x0002;
    public final static int CMD_CSP_AUTHRSP = 0x0003;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_LOGIN_REQ = 0x0100;    //客户登录请求
    public final static int CMD_TRD_LOGIN_RSP = 0x0101;    //客户登录应答
    public final static int CMD_TRD_LOGOUT_REQ = 0x0102;    //客户登出请求
    public final static int CMD_TRD_LOGOUT_RTN = 0x0103;    //客户登出通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_SMSAUTH_REQ = 0x1600;    //短信认证码验证请求
    public final static int CMD_TRD_SMSAUTH_RSP = 0x1601;    //短信认证码验证应答

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_BILL_QRY_REQ = 0x1000;    //结算单查询请求
    public final static int CMD_TRD_BILL_QRY_RSP = 0x1001;    //结算单查询应答
    public final static int CMD_TRD_BILLCONFIRMSTATUS_QRY_REQ = 0x1002;    //结算单确认状态查询请求
    public final static int CMD_TRD_BILLCONFIRMSTATUS_QRY_RSP = 0x1003;    //结算单确认状态查询应答
    public final static int CMD_TRD_BILLCONFIRM_REQ = 0x1004;    //结算单确请求
    public final static int CMD_TRD_BILLCONFIRM_RSP = 0x1005;    //结算单确应答

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_CURRENCY_QRY_REQ = 0x0300;    //币种信息查询请求
    public final static int CMD_TRD_CURRENCY_QRY_RSP = 0x0301;    //币种信息查询应答
    public final static int CMD_TRD_CURRENCY_RTN = 0x0302;    //币种信息通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_FUND_QRY_REQ = 0x0700;    //资金查询请求
    public final static int CMD_TRD_FUND_QRY_RSP = 0x0701;    //资金查询应答
    public final static int CMD_TRD_FUND_CHG_RTN = 0x0702;    //资金变化回报

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_COMMODITY_QRY_REQ = 0x0200;    //后台品种查询请求
    public final static int CMD_TRD_COMMODITY_QRY_RSP = 0x0201;    //后台品种查询应答

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_ORDERINSERT_REQ = 0x0400;    //下单请求
    public final static int CMD_TRD_ORDERINSERT_RSP = 0x0401;    //下单应答
    public final static int CMD_TRD_ORDER_RTN = 0x0402;    //定单信息通知
    public final static int CMD_TRD_ORDER_QRY_REQ = 0x0403;    //定单查询请求
    public final static int CMD_TRD_ORDER_QRY_RSP = 0x0404;    //定单查询应答
    public final static int CMD_TRD_ORDER_QRY_DATA = 0x0405;    //定单查询数据应答
    public final static int CMD_TRD_ORDER_DEL_RTN = 0x0406;    //定单删除通知
    public final static int CMD_TRD_ORDER_ACT_REQ_OUT = 0x0407;    //定单操作请求, 废弃版本，不再使用
    public final static int CMD_TRD_ORDER_ACT_RSP_OUT = 0x0408;    //定单操作应答, 废弃版本，不再使用
    public final static int CMD_TRD_STRATEGYORDER_QRY_REQ = 0x0409;    //策略单查询请求
    public final static int CMD_TRD_STRATEGYORDER_QRY_RSP = 0x040A;    //策略单查询应答
    public final static int CMD_TRD_STRATEGYORDER_QRY_DATA = 0x040B;    //策略单查询数据应答
    public final static int CMD_TRD_ORDER_ACT_REQ = 0x040C;    //定单操作请求
    public final static int CMD_TRD_ORDER_ACT_RSP = 0x040D;    //定单操作应答
    public final static int CMD_TRD_ORDER_MDF_REQ = 0x040E;    //定单修改请求
    public final static int CMD_TRD_ORDER_MDF_RSP = 0x040F;    //定单修改应答

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_FEEPARAM_QRY_REQ = 0x1300;    //手续费参数查询请求
    public final static int CMD_TRD_FEEPARAM_QRY_RSP = 0x1301;    //手续费参数查询应答
    public final static int CMD_TRD_FEEPARAM_RTN = 0x1302;    //手续费参数通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_DEPOSITPARAM_QRY_REQ = 0x1400;    //保证金参数查询请求
    public final static int CMD_TRD_DEPOSITPARAM_QRY_RSP = 0x1401;    //保证金参数查询应答
    public final static int CMD_TRD_DEPOSITPARAM_RTN = 0x1402;    //保证金参数通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_POSITION_QRY_REQ = 0x0600;    //持仓信息查询请求
    public final static int CMD_TRD_POSITION_QRY_RSP = 0x0601;    //持仓信息查询应答
    public final static int CMD_TRD_POSITION_RTN = 0x0602;    //持仓信息通知
    public final static int CMD_TRD_POSITIONCALCPRICE_RTN = 0x0603;    //持仓计算价格通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_G_INITREADY_TRN = 0xC600;    //用户数据初始化完成通知

    //二次认证信息请求命令 
    public final static int CMD_TRD_SECONDINFO_REQ = 0xC700;
    //二次认证信息请求应答命令
    public final static int CMD_TRD_SECONDINFO_RSP = 0xC701;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_MESSAGE_QRY_REQ = 0x0F00;    //交易消息查询请求
    public final static int CMD_TRD_MESSAGE_QRY_RSP = 0x0F01;    //交易消息查询应答
    public final static int CMD_TRD_MESSAGE_RTN = 0x0F02;    //交易消息通知

    public final static int CMD_TRD_ASXPARAM_RTN = 0x2300;      //澳交所系统参数通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_MATCH_QRY_REQ = 0x0500;    //成交信息查询请求
    public final static int CMD_TRD_MATCH_QRY_RSP = 0x0501;    //成交信息查询应答
    public final static int CMD_TRD_MATCH_QRY_DATA = 0x0502;    //成交信息数据回报
    public final static int CMD_TRD_MATCH_RTN = 0x0503;    //成交信息通知
    public final static int CMD_TRD_MATCH_DEL_RTN = 0x0504;    //成交删除通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_CHANGELOGINPSW_REQ = 0x0D00;    //登录密码修改请求
    public final static int CMD_TRD_CHANGELOGINPSW_RSP = 0x0D01;    //登录密码修改应答
    public final static int CMD_TRD_CHANGELOGINPSW_RTN = 0x0D02;    //登录密码修改通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_CHANGEFUNDPSW_REQ = 0x0E00;    //资金密码修改请求
    public final static int CMD_TRD_CHANGEFUNDPSW_RSP = 0x0E01;    //资金密码修改应答
    public final static int CMD_TRD_CHANGEFUNDPSW_RTN = 0x0E02;    //资金密码修改通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_TRANSBANK_QRY_REQ = 0x0800;    //转账银行查询请求
    public final static int CMD_TRD_TRANSBANK_QRY_RSP = 0x0801;    //转账银行查询应答

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_TRANSBANKUSER_QRY_REQ = 0x0900;    //签约银行查询请求
    public final static int CMD_TRD_TRANSBANKUSER_QRY_RSP = 0x0901;    //签约银行查询应答

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_BANKBALANCE_QRY_REQ = 0x0A00;    //银行余额查询请求
    public final static int CMD_TRD_BANKBALANCE_QRY_RSP = 0x0A01;    //银行余额查询应答

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_TRANSFER_REQ = 0x0B00;    //银期转账请求
    public final static int CMD_TRD_TRANSFER_RSP = 0x0B01;    //银期转账应答
    public final static int CMD_TRD_TRANSFER_RTN = 0x0B02;    //银期转账通知
    public final static int CMD_TRD_TRANSFER_QRY_REQ = 0x0B03;    //银期转账查询请求
    public final static int CMD_TRD_TRANSFER_QRY_RSP = 0x0B04;    //银期转账查询应答

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public final static int CMD_TRD_TRADEDATESWITCH_RTN = 0x1500;    //交易日切换通知

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//二次认证验证码请求命令
    public final static int CMD_TRD_SECONDCHECKCODE_REQ = 0xC800;
    //二次认证验证码请求应答命令
    public final static int CMD_TRD_SECONDCHECKCODE_RSP = 0xC801;

    //重置密码验证身份信息
    public final static int CMD_TRD_VERIFY_IDENTITY_REQ = 0x2601;
    public final static int CMD_TRD_VERIFY_IDENTITY_RSP = 0x2602;

    //重置密码 验证码
    public final static int CMD_TRD_SEC_VERTIFICATION_REQ = 0x2605;
    public final static int CMD_TRD_SEC_VERTIFICATION_RSP = 0x2606;

    //心跳协议,无数据实体
    public final static int CMD_CSP_HEARTBEATREQ = 0x0000;
    public final static int CMD_CSP_HEARTBEATRSP = 0x0001;
    /////////////////////////////////////心跳//////////////////////////////////////////
    public final static int CMD_QTE_HEARTBEATREQ = CMD_CSP_HEARTBEATREQ;
    public final static int CMD_QTE_HEARTBEATRSP = CMD_CSP_HEARTBEATRSP;

    //APP发送CID和设备类型
    public final static int CMD_PUSH_CLIENT_INFO_NOTICE = 0x1003;
}
