package com.esunny.trade.bean;

/**
 * @author Peter Fu
 * @date 2020/10/19
 */
public class TrdCurrencyQryRsp {
    String					CompanyNo;								//经纪公司编号
    String				CurrencyGroupNo;						//币种组编号
    String					CurrencyNo;								//币种编号
    boolean							IsShare;								//是否与其他币种共享计算
    double					USDExchangeRate;						//美元交易汇率
    double					HKDExchangeRate;						//港币交易汇率
    String						UserNo;									//资金帐号
}
