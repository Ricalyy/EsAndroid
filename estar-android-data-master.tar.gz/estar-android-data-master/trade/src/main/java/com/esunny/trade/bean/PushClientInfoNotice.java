package com.esunny.trade.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/10/26
 */
public class PushClientInfoNotice extends ApiStruct {

    public final static short STRUCT_LENGTH = 145;

    private String                   AppId;                            //App Id
    private String                AppKey;                           //App Key
    private String                AppMasterSecret;                  //App Master Secret

    PushClient                      Client;                           //client信息

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(AppId, 31));
        buffer.put(stringToByte(AppKey, 31));
        buffer.put(stringToByte(AppMasterSecret, 31));
        buffer.put(Client.beanToByte());

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getAppId() {
        return AppId;
    }

    public void setAppId(String appId) {
        AppId = appId;
    }

    public String getAppKey() {
        return AppKey;
    }

    public void setAppKey(String appKey) {
        AppKey = appKey;
    }

    public String getAppMasterSecret() {
        return AppMasterSecret;
    }

    public void setAppMasterSecret(String appMasterSecret) {
        AppMasterSecret = appMasterSecret;
    }

    public PushClient getClient() {
        return Client;
    }

    public void setClient(PushClient client) {
        Client = client;
    }
}
