package com.esunny.ct;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Base64;

import androidx.core.content.ContextCompat;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.server.EsSystemInfo;
import com.esunny.data.api.server.RoutingTable;
import com.esunny.data.util.EsLog;
import com.esunny.datacollect.info.EsDataCollect;
import com.hundsun.base.HsSysInfoUtils;
import com.kingstar.info.infomanager;
import com.sfit.ctp.info.DeviceInfoManager;

import org.skylark.deepsupervise.UserApi;

/**
 * @author Peter Fu
 * @date 2020/10/22
 */

@Route(path = RoutingTable.ES_CT_SYSTEM_INFO_API)
public class DeviceInfo implements EsSystemInfo {
    private static final String TAG = "DeviceInfo";

    private Context mContext;

    @Override
    public void init(Context context) {
        mContext = context;

        HsSysInfoUtils.getInstance().init(context);
    }

    @Override
    public int getSystemInfo(String api, SystemInfoCallback callback) {
        if (API_TYPE_DAY_STAR.equals(api) || API_TYPE_DIPPER.equals(api) || API_TYPE_CTP.equals(api)
                || API_TYPE_KST.equals(api) || API_TYPE_HUND_SUN.equals(api)
                || API_TYPE_CTP_STOCK_CT.equals(api) || API_TYPE_CTPETF_CT.equals(api)
                || API_TYPE_FEMA_CT.equals(api)) {

            if (checkPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION)
                    && checkPermission(mContext, Manifest.permission.ACCESS_WIFI_STATE)
                    && checkPermission(mContext, Manifest.permission.READ_PHONE_STATE)) {
                new Thread(new InfoThread(api, callback)).start();
                return 0;
            }
            return 1;
        }
        return -1;
    }

    /**
     * 校验Permission权限
     *
     * @param context    Context
     * @param permission 权限名
     * @return 是否有权限
     */
    private boolean checkPermission(Context context, String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED;
        } else {
            PackageManager pm = context.getPackageManager();
            return pm.checkPermission(permission, context.getPackageName()) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private SystemInfo getSystemInfo(String api) {
        SystemInfo info = new SystemInfo();
        try {
            if (API_TYPE_DAY_STAR.equals(api) || API_TYPE_DIPPER.equals(api)) {
                String infoStr = EsDataCollect.esunny_getsysteminfo(mContext);
                info.setSystemInfo(infoStr);
                info.setSystemInfoLen(infoStr.length());
                info.setSystemInfoFlag(EsDataCollect.esunny_getkeyversion());

                EsLog.d(TAG, "getSystemInfo: estar" + infoStr);
                return info;
            } else if (API_TYPE_CTP.equals(api) || API_TYPE_CTP_STOCK_CT.equals(api) || API_TYPE_CTPETF_CT.equals(api)) {
                byte[] infoArr = DeviceInfoManager.getCollectInfo(mContext);
                if (infoArr != null) {
                    info.setSystemInfoLen(infoArr.length);
                    info.setSystemInfo(Base64.encodeToString(infoArr, Base64.NO_WRAP));
                    EsLog.d(TAG, "getSystemInfo: ctp" + info.getSystemInfo());
                    return info;
                }
            } else if (API_TYPE_KST.equals(api)) {
                String infoStr = infomanager.KingStar_GetSystemInfo(mContext);
                info.setSystemInfo(infoStr);
                info.setSystemInfoLen(infoStr.length());

                EsLog.d(TAG, "getSystemInfo: kst" + infoStr);
                return info;
            } else if (API_TYPE_HUND_SUN.equals(api)) {
                int type = 0;
                try {
                    type = Integer.valueOf(HsSysInfoUtils.getInstance().getAbnormalType());
                } catch (NumberFormatException e) {
                    EsLog.e(TAG, "getSystemInfo: error", e);
                }

                if (type != 0) {
                    EsLog.d(TAG, "getSystemInfo: error text = " + HsSysInfoUtils.getInstance().getDetailError());
                }

                String infoStr = HsSysInfoUtils.getInstance().getSysInfo();
                info.setSystemInfo(infoStr);
                info.setSystemInfoLen(infoStr.length());
                info.setSystemInfoIntegrity(HsSysInfoUtils.getInstance().getSysInfoCompletion());
                info.setSystemInfoFlag(type);

                EsLog.d(TAG, "getSystemInfo: hund sun" + infoStr);
                return info;
            }
        } catch (Exception e) {
            EsLog.e(TAG, "getSystemInfo, error", e);
        }

        return null;
    }

    private void getFemaInfo(final Handler handler) {
        UserApi userApi = UserApi.getInstance(mContext);
        UserApi.Listener listener = new UserApi.Listener() {
            @Override
            public void onPrepared(int i, String s) {

            }

            @Override
            public void onCompleted(int i, String s) {
                if (handler != null) {
                    SystemInfo systemInfo = new SystemInfo();
                    systemInfo.setSystemInfo(s);
                    systemInfo.setSystemInfoLen(s.length());

                    EsLog.d(TAG, "getSystemInfo: femal" + s);
                    Message message = handler.obtainMessage(0, systemInfo);
                    handler.sendMessage(message);
                }
            }
        };
        Looper.prepare();
        userApi.cffexit_staticGetSystemInfo(listener);
        Looper.loop();
    }

    private class InfoThread implements Runnable{
        private String mAPI;
        private Handler mHandle;

        InfoThread(String api, final SystemInfoCallback callback) {
            mAPI = api;

            mHandle = new Handler(Looper.getMainLooper(), new Handler.Callback() {
                @Override
                public boolean handleMessage(Message msg) {
                    if (callback != null) {
                        SystemInfo info = (SystemInfo) msg.obj;
                        callback.onGetSystemInfo(info);
                    }
                    return false;
                }
            });
        }

        @Override
        public void run() {
            if (mHandle != null) {
                if (mAPI.equals(API_TYPE_FEMA_CT)) {
                    getFemaInfo(mHandle);
                } else {
                    SystemInfo info = getSystemInfo(mAPI);
                    Message message = mHandle.obtainMessage(0, info);
                    mHandle.sendMessage(message);
                }
            }
        }
    }
}
