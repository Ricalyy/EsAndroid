package com.esunny.ct;

import android.content.Context;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.esunny.data.api.server.EsCtApi;
import com.esunny.data.api.server.EsSystemInfo;
import com.esunny.data.api.server.RoutingTable;

/**
 * @author Peter Fu
 * @date 2020/10/22
 */

@Route(path = RoutingTable.ES_CT_API)
public class EsCtApiImpl implements EsCtApi {

    @Override
    public int getSystemInfo(String api, EsSystemInfo.SystemInfoCallback callback) {
        EsSystemInfo infoClass = (EsSystemInfo) ARouter.getInstance().build(RoutingTable.ES_CT_SYSTEM_INFO_API).navigation();
        if (infoClass != null && callback != null) {
            return infoClass.getSystemInfo(api, callback);
        }
        return -2;
    }

    @Override
    public void init(Context context) {

    }
}
