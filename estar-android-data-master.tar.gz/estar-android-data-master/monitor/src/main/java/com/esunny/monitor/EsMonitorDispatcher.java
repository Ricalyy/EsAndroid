package com.esunny.monitor;

import android.util.Log;

import com.esunny.data.api.EsBaseApi;
import com.esunny.data.api.EsDataConstant;
import com.esunny.data.api.EsEventConstant;
import com.esunny.data.api.event.MonitorEvent;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.data.bean.MonitorStateData;
import com.esunny.data.bean.SPushClientInfo;
import com.esunny.data.bean.SQuoteUserInfo;
import com.esunny.data.util.EsLog;
import com.esunny.mobile.EsApiData;
import com.esunny.mobile.EsNativeProtocol;
import com.esunny.mobile.UnixJNI;
import com.esunny.mobile.bean.CspSessionHead;
import com.esunny.monitor.bean.SPMonitorOrder;
import com.esunny.monitor.bean.SPMonitorOrderNotify;
import com.esunny.monitor.bean.SPMonitorStateData;
import com.esunny.monitor.bean.TrdPriceMonitorActionRsp;
import com.esunny.monitor.bean.TrdPriceMonitorInsertRsp;
import com.esunny.monitor.bean.TrdPriceMonitorLoginInfoReq;
import com.esunny.monitor.bean.TrdPriceMonitorLoginInfoRsp;
import com.esunny.monitor.bean.TrdPriceMonitorQryData;
import com.esunny.monitor.bean.TrdPriceMonitorQryReq;
import com.esunny.monitor.bean.TrdPriceMonitorRtn;
import com.esunny.monitor.bean.TrdPriceMonitorStateData;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Peter Fu
 * @date 2020/11/23
 */
public class EsMonitorDispatcher extends CallbackDispatcher {

    private final static String TAG = "EsMonitorDispatcher";

    @Override
    public int dispatch(char action, byte[] data) {

        if (action == EVENT_TCP_CONNECT) {
            return LoginMonitor();
        }

        if (action == EVENT_TCP_DISCONNECT) {
            Map<String, MonitorOrder> monitorOrderMap =  EsMonitorData.getInstance().getMonitorOrder();
            monitorOrderMap.clear();
            EsMonitorData.getInstance().setClientKey(0);
            MonitorEvent.Builder builder = new MonitorEvent.Builder(EsEventConstant.S_SRVEVENT_DISCONNECT).setSrvErrorCode(0);
            sendEvent(builder.buildEvent());
            return 0;
        }

        if (action == EVENT_TCP_RESET_DATA) {
            return 0;
        }

        byte[] headArr = new byte[CspSessionHead.STRUCT_LENGTH];
        System.arraycopy(data, 0, headArr, 0, CspSessionHead.STRUCT_LENGTH);

        int dataLen = data.length - CspSessionHead.STRUCT_LENGTH;
        byte[] buf = new byte[dataLen];
        System.arraycopy(data, CspSessionHead.STRUCT_LENGTH, buf, 0, dataLen);
        CspSessionHead head = new CspSessionHead(headArr);
        switch (head.getProtocolCode()) {
            case EsMonitorProtocol.CMD_TRD_PRICEMONITOR_LOGIN_RSP:
                OnLoginRsp(buf, head);
                break;
            case EsMonitorProtocol.CMD_TRD_PRICEMONITOR_INSERT_RSP:
                OnOrderInsertRsp(buf, head);
                break;
            case EsMonitorProtocol.CMD_TRD_PRICEMONITOR_RTN:
                OnOrderRTN(buf, head);
                break;
            case EsMonitorProtocol.CMD_TRD_PRICEMONITOR_QRY_RSP:
                if (head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
                    EsLog.d(TAG, "CMD_TRD_PRICEMONITOR_QRY_RSP end");
                    sendEvent(EsDataConstant.S_SRVEVENT_MONITOR_QRY, null, 0, "");
                } else {
                    EsLog.d(TAG, "CMD_TRD_PRICEMONITOR_QRY_RSP continue to send");
                    head.setProtocolCode(EsMonitorProtocol.CMD_TRD_PRICEMONITOR_QRY_REQ);
                    sendTcpMsg(EsNativeProtocol.CSP_FRAME_LZO, head, buf);
                }
                break;
            case EsMonitorProtocol.CMD_TRD_PRICEMONITOR_QRY_DATA:
                OnOrderQryData(buf, head);
                break;
            case EsMonitorProtocol.CMD_TRD_PRICEMONITOR_ACT_RSP:
                OnOrderActionRsp(buf, head);
                break;
            case EsMonitorProtocol.CMD_TRD_PRICEMONITOR_MOF_RSP:
                OnOrderModifyRsp(buf, head);
                break;
            case EsMonitorProtocol.CMD_TRD_PRICEMONITOR_DELE_RSP:
                OnOrderDeleteRsp(buf, head);
                break;
            default:
                break;
        }

        return 0;
    }

    private void OnLoginRsp(byte[] buf, CspSessionHead head) { ;
        TrdPriceMonitorLoginInfoRsp rsp = new TrdPriceMonitorLoginInfoRsp(buf);

        EsLog.d(TAG, "OnLoginRsp(), rsp error : " + rsp.getErrorCode());
        if (rsp.getErrorCode() != 0) {
            sendEvent(EsDataConstant.S_SRVEVENT_CONNECTFAIL, null, 400, "");
            LogoutMonitor();
        } else {
            Map<String, MonitorOrder> userMonitorMap = EsMonitorData.getInstance().getMonitorOrder();
            userMonitorMap.clear();
            sendEvent(EsDataConstant.S_SRVEVENT_CONNECT, null, 0, "");

            QryOrderRsp();
        }
    }

    private void QryOrderRsp() {
        if (EsMonitorData.getInstance().getClientKey() <= 0) {
            return;
        }
        EsLog.d(TAG, "QryOrderRsp");

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();

        CspSessionHead head = getMonitorSessionHead(EsMonitorProtocol.CMD_TRD_PRICEMONITOR_QRY_REQ, TrdPriceMonitorQryReq.STRUCT_LENGTH);
        TrdPriceMonitorQryReq req = new TrdPriceMonitorQryReq();
        req.setUserNo(userInfo.getLoginNo());
//        sendTcpMsg(head, req.beanToByte());
        sendTcpMsg(EsNativeProtocol.CSP_FRAME_LZO, head, req.beanToByte());
    }

    private void LogoutMonitor() {
        UnixJNI.S_Close(EsMonitorData.getInstance().getClientKey());
    }

    private void OnOrderInsertRsp(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        if (head.getErrorCode() == 0 && head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            QryOrderRsp();
        }

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdPriceMonitorInsertRsp rsp = new TrdPriceMonitorInsertRsp(struct);

            if (userInfo.getLoginNo().equals(rsp.getUserNo())) {
                SPMonitorOrderNotify data = new SPMonitorOrderNotify();
                data.setContractNo(rsp.getContractNo());
                data.setOrderNo(rsp.getOrderNo());
                data.setUpdateDateTime(rsp.getInsertDateTime());
                data.setErrorText(rsp.getErrorText());
                data.setOrderReqId(rsp.getOrderReqId());
                data.setErrorCode(rsp.getErrorCode());
                data.setOrderState(rsp.getOrderState());

                sendEvent(EsDataConstant.S_SRVEVENT_MONITOR_ACTION, data, 0, "");
            }
        }
    }

    private void OnOrderRTN(byte[] buf, CspSessionHead head) {
        Log.d(TAG, "OnOrderRTN()");

        int count = head.getFieldCount();
        int len = head.getFieldSize();

        if (head.getErrorCode() == 0 && head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            QryOrderRsp();
        }

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        Map<String, MonitorOrder> userMonitorOrderMap = EsMonitorData.getInstance().getMonitorOrder();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdPriceMonitorRtn rsp = new TrdPriceMonitorRtn(struct);

            String key = rsp.getOrderNo();
            if (userInfo.getLoginNo().equals(rsp.getUserNo())) {
                MonitorOrder data = userMonitorOrderMap.get(key);
                if (data == null) {
                    data = new MonitorOrder();
                    userMonitorOrderMap.put(key, data);
                }


                fillTrdPriceMonitorRtnData(rsp, data);
                sendEvent(EsDataConstant.S_SRVEVENT_MONITOR_RTN, data, 0, "");
            }
        }
    }

    private void OnOrderQryData(byte[] buf, CspSessionHead head) {
        EsLog.d(TAG, "OnOrderQryData");

        int count = head.getFieldCount();
        int len = head.getFieldSize();

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        Map<String, MonitorOrder> userMonitorOrderMap = EsMonitorData.getInstance().getMonitorOrder();

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdPriceMonitorQryData rsp = new TrdPriceMonitorQryData(struct);

            String key = rsp.getOrderNo();
            if (userInfo.getLoginNo() != null && userInfo.getLoginNo().equals(rsp.getUserNo())) {
                MonitorOrder data = userMonitorOrderMap.get(key);
                if (data == null) {
                    data = new MonitorOrder();
                    userMonitorOrderMap.put(key, data);
                }

                fillTrdPriceMonitorRtnData(rsp, data);
            }
        }
    }

    private void fillTrdPriceMonitorRtnData(TrdPriceMonitorRtn rsp, MonitorOrder data) {
        data.setContractNo(rsp.getContractNo());
        data.setPriceMax1(rsp.getPriceMax1());
        data.setPriceMax2(rsp.getPriceMax2());
        data.setPriceMin1(rsp.getPriceMin1());
        data.setPriceMin2(rsp.getPriceMin2());
        data.setGrowthWidthMax(rsp.getGrowthWidthMax());
        data.setGrowthWidthMin(rsp.getGrowthWidthMin());
        data.setGrowthSpeedMax(rsp.getGrowthSpeedMax());
        data.setGrowthSpeedMin(rsp.getGrowthSpeedMin());
        data.setLastVol(BigInteger.valueOf(rsp.getLastVol()));
        data.setVolume(BigInteger.valueOf(rsp.getVolume()));
        data.setPositionMax(BigInteger.valueOf(rsp.getPositionMax()));
        data.setPositionMin(BigInteger.valueOf(rsp.getPositionMin()));
        data.setLimitUp(rsp.isLimitUp());
        data.setLimitDown(rsp.isLimitDown());
        data.setMonitorNum(rsp.getMonitorNum());
        data.setMonitorRemark(rsp.getMonitorRemark());
        data.setOrderNo(rsp.getOrderNo());
        data.setInsertDateTime(rsp.getInsertDateTime());
        data.setUpdateDateTime(rsp.getUpdateDateTime());
        data.setOrderState(rsp.getOrderState());
        data.setErrorCode(rsp.getErrorCode());
        data.setErrorText(rsp.getErrorText());
        List<MonitorStateData> list = new ArrayList<>();
        for (int j = 0; j < rsp.getDataCount();j++) {
            if (j >= 16) {
                break;
            }
            TrdPriceMonitorStateData field = rsp.getData().get(j);
            if (field == null) {
                continue;
            }

            MonitorStateData stateData = new MonitorStateData();
            stateData.setValue(field.getValue());
            stateData.setReason(field.getReason());
            stateData.setUpdateTime(field.getUpdateTime());
            list.add(stateData);
        }

        MonitorStateData[] array = new MonitorStateData[list.size()];
        for (int i = 0; i < list.size();i++) {
            array[i] = list.get(i);
        }

        data.setData(array);
    }

    private void OnOrderActionRsp(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        Map<String, MonitorOrder> userMonitorOrderMap = EsMonitorData.getInstance().getMonitorOrder();

        int tmp = 0;

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdPriceMonitorActionRsp rsp = new TrdPriceMonitorActionRsp(struct);
            if (userInfo.getLoginNo().equals(rsp.getUserNo())) {
                SPMonitorOrderNotify data = new SPMonitorOrderNotify();
                data.setContractNo(rsp.getContractNo());
                data.setOrderNo(rsp.getOrderNo());
                data.setUpdateDateTime(rsp.getUpdateDateTime());
                data.setErrorText(rsp.getErrorText());

                data.setOrderReqId(rsp.getOrderReqId());
                data.setErrorCode(rsp.getErrorCode());
                data.setOrderState(rsp.getOrderState());

                sendEvent(EsDataConstant.S_SRVEVENT_MONITOR_ACTION, data, 0, "");
                if (!userMonitorOrderMap.containsKey(rsp.getOrderNo())) {
                    tmp++;
                } else {
                    MonitorOrder order = userMonitorOrderMap.get(rsp.getOrderNo());
                    order.setOrderState(rsp.getOrderState());
                }
            }
        }

        if (tmp > 0 && head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            QryOrderRsp();
        }
    }

    private void OnOrderModifyRsp(byte[] buf, CspSessionHead head) {
        OnOrderActionRsp(buf, head);
    }

    private void OnOrderDeleteRsp(byte[] buf, CspSessionHead head) {
        int count = head.getFieldCount();
        int len = head.getFieldSize();

        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        Map<String, MonitorOrder> userMonitorOrderMap = EsMonitorData.getInstance().getMonitorOrder();

        if (head.getErrorCode() == 0 && head.getChain() == EsNativeProtocol.CSP_CHAIN_END) {
            userMonitorOrderMap.clear();
            QryOrderRsp();
        }

        byte[] struct = new byte[len];
        for (int i = 0; i < count && (buf.length >= (i + 1) * len); i++) {
            int start = i * len;

            System.arraycopy(buf, start, struct, 0, len);

            TrdPriceMonitorQryReq rsp = new TrdPriceMonitorQryReq(struct);
            if (userInfo.getLoginNo().equals(rsp.getUserNo())) {
                sendEvent(EsDataConstant.S_SRVEVENT_MONITOR_DELETE, null, 0, "");
            }
        }

    }

    private int LoginMonitor() {
        EsLog.d(TAG, "LoginMonitor()");
        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();
        SPushClientInfo pushClientInfo = EsApiData.getInstance().getPushClientInfo();

        TrdPriceMonitorLoginInfoReq req = new TrdPriceMonitorLoginInfoReq();
        req.setUserNo(userInfo.getLoginNo());
        req.setUserPwd(userInfo.getPassWord());
        req.setAppId(pushClientInfo.getAppId());
        req.setAppKey(pushClientInfo.getAppKey());
        req.setAppMasterSecret(pushClientInfo.getAppMasterSecret());
        req.setCID(pushClientInfo.getCID());
        req.setDeviceType(EsNativeProtocol.PkgAndroid);

        CspSessionHead head =  getMonitorSessionHead(EsMonitorProtocol.CMD_TRD_PRICEMONITOR_LOGIN_REQ, TrdPriceMonitorLoginInfoReq.STRUCT_LENGTH);

        int ret = sendTcpMsg(EsNativeProtocol.CSP_FRAME_PLAIN, head, req.beanToByte());
        return ret;
    }

    private CspSessionHead getMonitorSessionHead(int protocolCode, int fieldSize) {
        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();

        CspSessionHead head = new CspSessionHead();
        head.setProtocolVer(EsNativeProtocol.CSP_PROTOCOL_VER);
        head.setChain(EsNativeProtocol.CSP_CHAIN_END);
        head.setLangType(EsBaseApi.getInstance().getLanguageType());
        head.setProtocolCode(protocolCode);
        head.setFieldCount(1);
        head.setFieldSize(fieldSize);
        head.setAuthCode(userInfo.getLoginNo());
        head.setPackageNo(UnixJNI.S_GetPackageNo());

        return head;
    }

    private void sendEvent(int action, Object data, int errorCode, String errortext) {
        SQuoteUserInfo userInfo = EsApiData.getInstance().getQuoteUserInfo();

        MonitorEvent event = new MonitorEvent.Builder(action)
                .setUserNo(userInfo.getLoginNo())
                .setData(data)
                .setSrvChain(true)
                .setUserNo(userInfo.getLoginNo())
                .setSrvErrorCode(errorCode)
                .setSrvErrorText(errortext)
                .buildEvent();

        sendEvent(event);
    }
}
