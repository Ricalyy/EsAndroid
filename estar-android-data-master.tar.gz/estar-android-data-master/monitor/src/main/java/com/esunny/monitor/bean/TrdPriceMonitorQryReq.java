package com.esunny.monitor.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/25
 */
public class TrdPriceMonitorQryReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 72;

    private String                                               UserNo;
    private String                                           ContractNo;

    public TrdPriceMonitorQryReq() {
    }

    public TrdPriceMonitorQryReq(byte[] struct) {
        byteToBean(struct);
    }

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(UserNo, 21));
        buffer.put(stringToByte(ContractNo, 51));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setUserNo(util.getString(21));
        setContractNo(util.getString(51));
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }
}
