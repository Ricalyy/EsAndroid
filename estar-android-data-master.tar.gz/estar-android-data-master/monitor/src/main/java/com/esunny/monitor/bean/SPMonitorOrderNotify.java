package com.esunny.monitor.bean;

import com.esunny.data.api.inter.ApiStruct;

/**
 * @author Peter Fu
 * @date 2020/11/26
 */
public class SPMonitorOrderNotify {
    private String                                       ContractNo;     //监控合约
    private int                                         OrderReqId;
    private String                                          OrderNo;
    private String                                         UpdateDateTime;
    private char                                       OrderState;
    private int                                        ErrorCode;
    private String                                        ErrorText;

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public int getOrderReqId() {
        return OrderReqId;
    }

    public void setOrderReqId(int orderReqId) {
        OrderReqId = orderReqId;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getUpdateDateTime() {
        return UpdateDateTime;
    }

    public void setUpdateDateTime(String updateDateTime) {
        UpdateDateTime = updateDateTime;
    }

    public char getOrderState() {
        return OrderState;
    }

    public void setOrderState(char orderState) {
        OrderState = orderState;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }
}
