package com.esunny.monitor.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/26
 */
public class TrdPriceMonitorModifyRsp extends ApiStruct {

    private String                                           UserNo;         //极星账号
    private String                                       ContractNo;     //监控合约
    private int                                         OrderReqId;
    private String                                          OrderNo;
    private String                                         UpdateDateTime;
    private char                                       OrderState;
    private int                                        ErrorCode;
    private String                                        ErrorText;

    public TrdPriceMonitorModifyRsp(byte[] buf) {
        byteToBean(buf);
    }

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setUserNo(util.getString(21));
        setContractNo(util.getString(51));
        setOrderReqId(util.getInt());
        setOrderNo(util.getString(21));
        setUpdateDateTime(util.getString(21));
        setOrderState(util.getChar());
        setErrorCode(util.getInt());
        setErrorText(util.getString(201));
    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public int getOrderReqId() {
        return OrderReqId;
    }

    public void setOrderReqId(int orderReqId) {
        OrderReqId = orderReqId;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getUpdateDateTime() {
        return UpdateDateTime;
    }

    public void setUpdateDateTime(String updateDateTime) {
        UpdateDateTime = updateDateTime;
    }

    public char getOrderState() {
        return OrderState;
    }

    public void setOrderState(char orderState) {
        OrderState = orderState;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }
}
