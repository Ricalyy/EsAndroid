package com.esunny.monitor.bean;

/**
 * @author Peter Fu
 * @date 2020/11/26
 */
public class TrdPriceMonitorActionRsp extends TrdPriceMonitorModifyRsp{

    public TrdPriceMonitorActionRsp(byte[] buf) {
        super(buf);
    }
}
