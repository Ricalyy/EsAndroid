package com.esunny.monitor.bean;

import com.esunny.data.api.inter.ApiStruct;

/**
 * @author Peter Fu
 * @date 2020/11/25
 */
public class TrdPriceMonitorQryData extends TrdPriceMonitorRtn {

    public TrdPriceMonitorQryData(byte[] struct) {
        super(struct);
    }

}
