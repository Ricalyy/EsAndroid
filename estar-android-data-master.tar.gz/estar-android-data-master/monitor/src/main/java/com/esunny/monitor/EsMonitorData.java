package com.esunny.monitor;

import com.esunny.data.bean.MonitorOrder;
import com.esunny.monitor.bean.SPMonitorOrder;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Peter Fu
 * @date 2020/11/23
 */
public class EsMonitorData {

    private Map<String, MonitorOrder> mMonitorOrder = new ConcurrentHashMap<>();

    private int clientKey = 0;


    private EsMonitorData() {
    }

    private static class SingletonClassInstance {
        private static final EsMonitorData INSTANCE = new EsMonitorData();
    }

    public static EsMonitorData getInstance() {
        return EsMonitorData.SingletonClassInstance.INSTANCE;
    }

    public Map<String, MonitorOrder> getMonitorOrder() {
        return mMonitorOrder;
    }

    public int getClientKey() {
        return clientKey;
    }

    public void setClientKey(int clientKey) {
        this.clientKey = clientKey;
    }
}
