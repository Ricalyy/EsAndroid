package com.esunny.monitor.bean;

import com.esunny.data.api.inter.ApiStruct;
import com.esunny.mobile.util.ParseUtil;

/**
 * @author Peter Fu
 * @date 2020/11/25
 */
public class TrdPriceMonitorStateData extends ApiStruct {
    private String Value;      //具体数值用|分开;
    private String Reason;       //报警原因用|分开;
    private String UpdateTime;         //更新时间

    @Override
    public byte[] beanToByte() {
        return new byte[0];
    }

    @Override
    protected void byteToBean(byte[] buf) {
        ParseUtil util = ParseUtil.wrap(buf);
        setValue(util.getString(101));
        setReason(util.getString(31));
        setUpdateTime(util.getString(21));
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }

    public String getReason() {
        return Reason;
    }

    public void setReason(String reason) {
        Reason = reason;
    }

    public String getUpdateTime() {
        return UpdateTime;
    }

    public void setUpdateTime(String updateTime) {
        UpdateTime = updateTime;
    }
}
