package com.esunny.monitor;

/**
 * @author Peter Fu
 * @date 2020/11/23
 */
public class EsMonitorProtocol {

    public final static int CMD_TRD_PRICEMONITOR_INSERT_REQ = 0x2100;    //价格监控下单请求
    public final static int CMD_TRD_PRICEMONITOR_INSERT_RSP = 0x2101;    //价格监控下单应答
    public final static int CMD_TRD_PRICEMONITOR_RTN = 0x2102;    //价格监控通知

    public final static int CMD_TRD_PRICEMONITOR_QRY_REQ = 0x2103;    //查询请求
    public final static int CMD_TRD_PRICEMONITOR_QRY_RSP = 0x2104;    //查询应答
    public final static int CMD_TRD_PRICEMONITOR_QRY_DATA = 0x2105;    //数据应答

    public final static int CMD_TRD_PRICEMONITOR_ACT_REQ = 0x2106;    //订单操作请求
    public final static int CMD_TRD_PRICEMONITOR_ACT_RSP = 0x2107;    //订单操作应答

    public final static int CMD_TRD_PRICEMONITOR_MOF_REQ = 0x2108;    //订单修改请求
    public final static int CMD_TRD_PRICEMONITOR_MOF_RSP = 0x2109;    //订单修改应答

    public final static int CMD_TRD_PRICEMONITOR_QUOTE = 0x2110;   //行情

    public final static int CMD_TRD_PRICEMONITOR_LOGIN_REQ = 0x2111;   //上传用户对应的推送信息
    public final static int CMD_TRD_PRICEMONITOR_LOGIN_RSP = 0x2112;

    public final static int CMD_TRD_PRICEMONITOR_DELE_REQ = 0x2114;     //刪除已触发订单
    public final static int CMD_TRD_PRICEMONITOR_DELE_RSP = 0x2115;
}
