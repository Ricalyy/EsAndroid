package com.esunny.monitor.bean;

import com.esunny.data.bean.MonitorOrder;
import com.esunny.data.bean.MonitorStateData;

import java.math.BigInteger;

/**
 * @author Peter Fu
 * @date 2020/11/23
 */
public class SPMonitorOrder {
    private String                                       ContractNo;     //监控合约
    //====================监控指标=======================//
    private double						                      PriceMax1;	//价格上限1
    private double                                            PriceMax2;	//价格上限2
    private double						                      PriceMin1;	//价格下限1
    private double                                            PriceMin2;	//价格下限2
    private double						                      GrowthWidthMax; //涨幅上限
    private double                                            GrowthWidthMin;	//涨幅下限
    private double						                      GrowthSpeedMax; //速涨上限
    private double                                            GrowthSpeedMin;	//速涨下限

    private BigInteger						                      LastVol;        //现手
    private BigInteger						                      Volume;         //成交量
    private BigInteger 					                          PositionMax;	//持仓量上限
    private BigInteger						                      PositionMin;	//持仓量下限

    private boolean                                             LimitUp;	//涨停价
    private boolean                                             LimitDown;	//跌停价

    private char                                      MonitorNum;     //触发次数 'O'只触发一次  'C'连续触发

    private String                                   MonitorRemark;  //监控备注

    private String                                        OrderNo;        //订单号
    private String                                        InsertDateTime; //下单时间
    private String  						              UpdateDateTime;	//最后一次更新时间
    private char                                       OrderState;     //订单状态
    //        TrdMonitorStateType                                     MonitorState;   //监控报警原因
    private int                                        ErrorCode;
    private String                                        ErrorText;
    private short                                                   DataCount;
    private SPMonitorStateData                                    Data[] = new SPMonitorStateData[16];

    public String getContractNo() {
        return ContractNo;
    }

    public void setContractNo(String contractNo) {
        ContractNo = contractNo;
    }

    public double getPriceMax1() {
        return PriceMax1;
    }

    public void setPriceMax1(double priceMax1) {
        PriceMax1 = priceMax1;
    }

    public double getPriceMax2() {
        return PriceMax2;
    }

    public void setPriceMax2(double priceMax2) {
        PriceMax2 = priceMax2;
    }

    public double getPriceMin1() {
        return PriceMin1;
    }

    public void setPriceMin1(double priceMin1) {
        PriceMin1 = priceMin1;
    }

    public double getPriceMin2() {
        return PriceMin2;
    }

    public void setPriceMin2(double priceMin2) {
        PriceMin2 = priceMin2;
    }

    public double getGrowthWidthMax() {
        return GrowthWidthMax;
    }

    public void setGrowthWidthMax(double growthWidthMax) {
        GrowthWidthMax = growthWidthMax;
    }

    public double getGrowthWidthMin() {
        return GrowthWidthMin;
    }

    public void setGrowthWidthMin(double growthWidthMin) {
        GrowthWidthMin = growthWidthMin;
    }

    public double getGrowthSpeedMax() {
        return GrowthSpeedMax;
    }

    public void setGrowthSpeedMax(double growthSpeedMax) {
        GrowthSpeedMax = growthSpeedMax;
    }

    public double getGrowthSpeedMin() {
        return GrowthSpeedMin;
    }

    public void setGrowthSpeedMin(double growthSpeedMin) {
        GrowthSpeedMin = growthSpeedMin;
    }

    public BigInteger getLastVol() {
        return LastVol;
    }

    public void setLastVol(BigInteger lastVol) {
        LastVol = lastVol;
    }

    public BigInteger getVolume() {
        return Volume;
    }

    public void setVolume(BigInteger volume) {
        Volume = volume;
    }

    public BigInteger getPositionMax() {
        return PositionMax;
    }

    public void setPositionMax(BigInteger positionMax) {
        PositionMax = positionMax;
    }

    public BigInteger getPositionMin() {
        return PositionMin;
    }

    public void setPositionMin(BigInteger positionMin) {
        PositionMin = positionMin;
    }

    public boolean isLimitUp() {
        return LimitUp;
    }

    public void setLimitUp(boolean limitUp) {
        LimitUp = limitUp;
    }

    public boolean isLimitDown() {
        return LimitDown;
    }

    public void setLimitDown(boolean limitDown) {
        LimitDown = limitDown;
    }

    public char getMonitorNum() {
        return MonitorNum;
    }

    public void setMonitorNum(char monitorNum) {
        MonitorNum = monitorNum;
    }

    public String getMonitorRemark() {
        return MonitorRemark;
    }

    public void setMonitorRemark(String monitorRemark) {
        MonitorRemark = monitorRemark;
    }

    public String getOrderNo() {
        return OrderNo;
    }

    public void setOrderNo(String orderNo) {
        OrderNo = orderNo;
    }

    public String getInsertDateTime() {
        return InsertDateTime;
    }

    public void setInsertDateTime(String insertDateTime) {
        InsertDateTime = insertDateTime;
    }

    public String getUpdateDateTime() {
        return UpdateDateTime;
    }

    public void setUpdateDateTime(String updateDateTime) {
        UpdateDateTime = updateDateTime;
    }

    public char getOrderState() {
        return OrderState;
    }

    public void setOrderState(char orderState) {
        OrderState = orderState;
    }

    public int getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(int errorCode) {
        ErrorCode = errorCode;
    }

    public String getErrorText() {
        return ErrorText;
    }

    public void setErrorText(String errorText) {
        ErrorText = errorText;
    }

    public short getDataCount() {
        return DataCount;
    }

    public void setDataCount(short dataCount) {
        DataCount = dataCount;
    }

    public SPMonitorStateData[] getData() {
        return Data;
    }

    public void setData(SPMonitorStateData[] data) {
        Data = data;
    }

    public MonitorOrder getMonitorOrder() {
        MonitorOrder monitorOrder = new MonitorOrder();
        monitorOrder.setContractNo(ContractNo);
        monitorOrder.setOrderNo(OrderNo);
        monitorOrder.setInsertDateTime(InsertDateTime);
        monitorOrder.setUpdateDateTime(UpdateDateTime);
        monitorOrder.setOrderState(OrderState);
        monitorOrder.setErrorCode(ErrorCode);
        monitorOrder.setErrorText(ErrorText);

        MonitorStateData[] monitorStateData = new MonitorStateData[Data.length];
        for (int i = 0; i < monitorStateData.length; i++) {
            if (Data[i] == null) {
                continue;
            }

            monitorStateData[i] = Data[i].getMonitorStateData();
        }
        monitorOrder.setData(monitorStateData);



        return monitorOrder;
    }
}
