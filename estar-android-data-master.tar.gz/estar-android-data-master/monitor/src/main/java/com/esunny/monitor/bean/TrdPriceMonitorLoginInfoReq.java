package com.esunny.monitor.bean;

import com.esunny.data.api.inter.ApiStruct;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * @author Peter Fu
 * @date 2020/11/23
 */
public class TrdPriceMonitorLoginInfoReq extends ApiStruct {

    public final static short STRUCT_LENGTH = 193;

    private String UserNo;
    private String UserPwd;//暂时没有用
    private String AppId; //App Id
    private String AppKey; //App Key
    private String AppMasterSecret; //App Master Secret
    private String CID; //设备client id
    private char DeviceType; //设备类型 Android IOS PC

    @Override
    public byte[] beanToByte() {
        ByteBuffer buffer = ByteBuffer.allocate(STRUCT_LENGTH);
        buffer.order(ByteOrder.LITTLE_ENDIAN);

        buffer.put(stringToByte(UserNo, 21));
        buffer.put(stringToByte(UserPwd, 31));
        buffer.put(stringToByte(AppId, 30));
        buffer.put(stringToByte(AppKey, 30));
        buffer.put(stringToByte(AppMasterSecret, 30));
        buffer.put(stringToByte(CID, 50));
        buffer.put(charToByte(DeviceType));

        return buffer.array();
    }

    @Override
    protected void byteToBean(byte[] buf) {

    }

    public String getUserNo() {
        return UserNo;
    }

    public void setUserNo(String userNo) {
        UserNo = userNo;
    }

    public String getUserPwd() {
        return UserPwd;
    }

    public void setUserPwd(String userPwd) {
        UserPwd = userPwd;
    }

    public String getAppId() {
        return AppId;
    }

    public void setAppId(String appId) {
        AppId = appId;
    }

    public String getAppKey() {
        return AppKey;
    }

    public void setAppKey(String appKey) {
        AppKey = appKey;
    }

    public String getAppMasterSecret() {
        return AppMasterSecret;
    }

    public void setAppMasterSecret(String appMasterSecret) {
        AppMasterSecret = appMasterSecret;
    }

    public String getCID() {
        return CID;
    }

    public void setCID(String CID) {
        this.CID = CID;
    }

    public char getDeviceType() {
        return DeviceType;
    }

    public void setDeviceType(char deviceType) {
        DeviceType = deviceType;
    }
}
