package com.esunny.monitor.bean;

import com.esunny.data.bean.MonitorStateData;

/**
 * @author Peter Fu
 * @date 2020/11/23
 */
public class SPMonitorStateData {
    private String Value;      //具体数值用|分开;
    private String Reason;       //报警原因用|分开;
    private String UpdateTime;         //更新时间

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }

    public String getReason() {
        return Reason;
    }

    public void setReason(String reason) {
        Reason = reason;
    }

    public String getUpdateTime() {
        return UpdateTime;
    }

    public void setUpdateTime(String updateTime) {
        UpdateTime = updateTime;
    }

    public MonitorStateData getMonitorStateData() {
        return new MonitorStateData(Value, Reason, UpdateTime);
    }
}
