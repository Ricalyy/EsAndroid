package com.esunny.monitor;

import android.content.Context;
import android.text.TextUtils;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.esunny.data.api.inter.CallbackDispatcher;
import com.esunny.data.api.server.EsMonitorApi;
import com.esunny.data.api.server.RoutingTable;
import com.esunny.data.bean.MonitorOrder;
import com.esunny.data.bean.MonitorOrderAction;
import com.esunny.data.bean.SQuoteUserInfo;
import com.esunny.mobile.EsApiData;
import com.esunny.monitor.bean.SPMonitorOrder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Peter Fu
 * @date 2020/11/23
 */

@Route(path = RoutingTable.ES_MONITOR_API)
public class EsMonitorApiImpl implements EsMonitorApi {

    @Override
    public void init(Context context) {

    }

    @Override
    public CallbackDispatcher getDispatcher() {
        return new EsMonitorDispatcher();
    }

    @Override
    public void setClientKey(int ret) {
        EsMonitorData.getInstance().setClientKey(ret);
    }

    @Override
    public int getClientKey() {
        return EsMonitorData.getInstance().getClientKey();
    }

    @Override
    public List<MonitorOrder> getMonitorOrder() {
        List<MonitorOrder> res = new ArrayList<>();

        Map<String, MonitorOrder> userMonitorOrder =  EsMonitorData.getInstance().getMonitorOrder();

        for (String key : userMonitorOrder.keySet()) {
            MonitorOrder spMonitorOrder = userMonitorOrder.get(key);
            if (spMonitorOrder == null) {
                continue;
            }

            res.add(spMonitorOrder);
        }
        return res;
    }

    @Override
    public int actionMonitorOrder(MonitorOrderAction order) {
        if (order == null) {
            return -1;
        }

        return 0;
    }
}
